# NMD Network — Stage 15 Deployment & Operations Guide

> **Deployment Status Notice**: This directory provides deployable server source code (`:bootstrap-service` and `:signaling-service`) and deployment templates. No public bootstrap or signaling servers are pre-deployed or embedded in the APK. Never claim public NMD infrastructure is live until operators externally deploy these services and verify external connectivity.

## 1. Architecture & Trust Boundaries

- **Bootstrap Service (`:bootstrap-service`)**: Provides `/health`, `/v1/network-config`, `POST /v1/peers/register`, `/v1/peers`, and `/metrics`. It is purely a bounded, TTL-expiring peer directory. It never holds user private keys, never authorizes blocks, never overrides BFT consensus, and never acts as a blockchain database.
- **Signaling Service (`:signaling-service`)**: Provides RFC 6455 WebSocket (`/ws`) relay + `/health` & `/metrics`. It routes signed Stage 14 `SignalingEnvelope` messages between online/offline peers (`REGISTER`, `ENVELOPE`). It cannot forge or mutate Ed25519 peer signatures or read Stage 13 `ChaCha20-Poly1305` encrypted P2P sessions.

Deploy `:bootstrap-service` and `:signaling-service` on separate hosts, containers, or reverse-proxy upstreams so signaling relay restarts do not disrupt peer directory availability and vice versa.

## 2. Building Deployable Distributions

```bash
gradle :bootstrap-service:installDist :signaling-service:installDist
```

Generated runnable distributions:
- `bootstrap-service/build/install/bootstrap-service`
- `signaling-service/build/install/signaling-service`

## 3. Deploying Multiple Bootstrap Endpoints (Redundancy)

1. Provision at least 2–3 independent hosts/regions.
2. Copy `deploy/.env.bootstrap.example` to `/etc/nmd/bootstrap.env` on each host, setting identical `NMD_NETWORK_PROFILE`, `NMD_CHAIN_ID`, and `NMD_GENESIS_HASH`.
3. Optionally generate distinct Ed25519 response-signing seeds (`NMD_BOOTSTRAP_SIGNING_PRIVATE_KEY_HEX`) per bootstrap host and pin their public keys on clients.
4. Install `deploy/systemd/nmd-bootstrap.service.template` and configure Nginx TLS (`deploy/nginx-tls-proxy.conf.template`).
5. Clients evaluate endpoints by ascending `priority`, applying exponential backoff + jitter cooldowns and automatic failover if any bootstrap instance becomes unavailable.

## 4. Separating Signaling Deployment

1. Copy `deploy/.env.signaling.example` to `/etc/nmd/signaling.env`.
2. Ensure `NMD_CHAIN_ID` matches the target profile (`TESTNET` or `MAINNET`).
3. Front the WebSocket listener (`127.0.0.1:8845`) with TLS 1.2/1.3 reverse proxy (`wss://<SIGNALING_DOMAIN>/ws`) or set PKCS12 paths directly in `NMD_TLS_KEYSTORE_PATH`.

## 5. Required Ports & Firewall Rules

| Service | Protocol | Public Port | Internal Bind | Notes |
|---|---|---|---|---|
| Reverse Proxy (TLS) | TCP HTTPS / WSS | `443` | `0.0.0.0:443` | Terminates TLS for Bootstrap + Signaling |
| Bootstrap Service | HTTP (behind proxy) | Blocked externally | `127.0.0.1:8844` | Restrict `/metrics` to monitoring IPs |
| Signaling Service | HTTP + WS (behind proxy) | Blocked externally | `127.0.0.1:8845` | Requires `Upgrade: websocket` |
| P2P Direct TCP (Optional) | TCP | `8765` | Device LAN / P2P | Fallback when not using WebRTC ICE |
| External STUN / TURN (Optional) | UDP / TCP / TLS | `3478` / `5349` | External TURN host | Configured separately in Stage 14 |

Deny direct external access to `8844` and `8845` when terminating TLS on `443`.

## 6. TLS & Certificate Pinning (Optional Hardening)

Extract SPKI SHA-256 pin from a deployed server certificate:

```bash
openssl s_client -servername <HOST> -connect <HOST>:443 </dev/null 2>/dev/null \
  | openssl x509 -pubkey -noout \
  | openssl pkey -pubin -outform der \
  | openssl dgst -sha256 -binary \
  | openssl enc -base64
```

Prefix the output with `sha256/` when entering `pinnedTlsSha256` in the Android client configuration dialog.

## 7. Monitoring & Health Checks

- Bootstrap health: `GET https://<BOOTSTRAP_DOMAIN>/health` (expects HTTP 200 and matching `chain_id` + `genesis_hash`).
- Bootstrap metrics: `GET http://127.0.0.1:8844/metrics` (`registrations_accepted`, `rate_limited_requests`, `wrong_chain_rejected`, `expired_pruned`).
- Signaling health: `GET https://<SIGNALING_DOMAIN>/health` (`active_sessions`, `registered_nodes`).
- Both services emit single-line JSON structured logs (`ts`, `svc`, `level`, `event`, `detail`) compatible with `journalctl` / Loki / Datadog.

## 8. Configuration Backup & Recovery

Back up only:
- `/etc/nmd/bootstrap.env` & `/etc/nmd/signaling.env` (restrict `chmod 600 root/nmd`).
- Reverse proxy TLS configuration & certificate store (`/etc/letsencrypt/`).

Peer directories (`DirectoryPeerEntry`) and signaling offline queues are intentionally ephemeral and TTL-bounded; they repopulate automatically upon service restart without database dumps.

## 9. Configuring the Android Application

1. Open **Network -> Dashboard -> Public Infrastructure & Bootstrap**.
2. Tap **Configure Endpoints & Profile**.
3. Select `TESTNET` (or `DEVELOPMENT` for local tests; `MAINNET` stays disabled unless explicitly activated with valid non-loopback TLS endpoints).
4. Enter the deployed Bootstrap host/port (`https`), `wss://` Signaling URL, and optional `sha256/...` TLS pin.
5. Confirm in the safety dialog. Tap **Check Health** and **Bootstrap & Sync** to verify Chain ID, Genesis Hash, and peer onboarding.
