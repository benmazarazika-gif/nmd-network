package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.manager.BlockIngestionResult
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.blockchain.model.TransactionReference
import com.example.blockchain.validation.ValidationErrorCode
import com.example.consensus.NmdConsensusCoordinatorRegistry
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.crypto.ConsensusCryptoSigner
import com.example.consensus.engine.ConsensusEngine
import com.example.consensus.engine.LocalSignVoteResult
import com.example.consensus.engine.ProposalSubmissionResult
import com.example.consensus.engine.VoteSubmissionResult
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ConsensusErrorCode
import com.example.consensus.model.ConsensusPhase
import com.example.consensus.model.ConsensusVote
import com.example.consensus.model.EquivocationType
import com.example.consensus.model.RoundChangeMessage
import com.example.consensus.model.ValidatorAvailability
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorStatus
import com.example.consensus.model.ValidatorStatusAnnouncement
import com.example.consensus.model.VotePhase
import com.example.consensus.p2p.ConsensusInboundResult
import com.example.consensus.p2p.ConsensusP2pGateway
import com.example.consensus.quorum.QuorumCalculator
import com.example.consensus.storage.RoomConsensusStorage
import com.example.consensus.validation.ConsensusBlockValidationHook
import com.example.consensus.validator.MobileParticipationPolicy
import com.example.consensus.validator.ValidatorEligibilityRegistry
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.Ed25519KeyPairResult
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.data.DeviceTelemetry
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerCapability
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.session.P2pSessionState
import com.example.p2p.session.PeerSession
import com.example.transaction.NmdTransactionEngineRegistry
import com.example.transaction.TransactionEngineManager
import com.example.transaction.WalletTxCreationOutcome
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.TransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Comprehensive Automated & Adversarial Verification Suite for Stage 10:
 * Distributed Consensus Mechanism.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdConsensusStage10Test {

    private lateinit var context: Context
    private lateinit var testScope: CoroutineScope
    private val crypto = BouncyCastleEd25519Provider()
    private val signer = ConsensusCryptoSigner(crypto)
    private val config = ConsensusConfig()
    private val blockHasher = BlockHasher(crypto)

    private val testDbFiles = listOf(
        "nmd_consensus_test.db",
        "nmd_consensus_restart_test.db",
        "nmd_blockchain_consensus_test.db",
        "nmd_tx_consensus_test.db"
    )

    private data class TestValidatorNode(
        val name: String,
        val keyPair: Ed25519KeyPairResult,
        val validatorId: String,
        val publicKeyHex: String,
        val info: ValidatorInfo
    )

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testScope = CoroutineScope(Dispatchers.IO + Job())
        NmdConsensusCoordinatorRegistry.resetForTests()
        NmdTransactionEngineRegistry.resetForTests()
        cleanupArtifacts()
    }

    @After
    fun tearDown() {
        testScope.cancel()
        NmdConsensusCoordinatorRegistry.resetForTests()
        NmdTransactionEngineRegistry.resetForTests()
        cleanupArtifacts()
    }

    private fun cleanupArtifacts() {
        testDbFiles.forEach { context.deleteDatabase(it) }
        context.deleteSharedPreferences("test_stage10_wallet_prefs")
    }

    private fun createValidatorNodes(count: Int, startTimeMs: Long = 1_700_000_000_000L): List<TestValidatorNode> {
        return (0 until count).map { idx ->
            val kp = crypto.generateEd25519KeyPair()
            val pubHex = crypto.toHex(kp.publicKeyBytes).lowercase()
            val valId = signer.deriveValidatorId(kp.publicKeyBytes)
            TestValidatorNode(
                name = "Validator-${idx + 1}",
                keyPair = kp,
                validatorId = valId,
                publicKeyHex = pubHex,
                info = ValidatorInfo(
                    validatorId = valId,
                    nodeId = crypto.deriveNodeId(kp.publicKeyBytes),
                    publicKeyHex = pubHex,
                    displayName = "Validator-${idx + 1}",
                    votingPower = 1L,
                    status = ValidatorStatus.ACTIVE,
                    registeredAtMs = startTimeMs
                )
            )
        }.sortedBy { it.validatorId }
    }

    private fun buildValidStage8Block(
        height: Long,
        previousHash: String,
        txRefs: List<TransactionReference> = emptyList(),
        timestamp: Long = 1_700_000_000_000L + height * 5_000L,
        consensusMetadata: String = ""
    ): Block {
        val body = BlockBody(
            transactionRefs = txRefs,
            extraData = if (txRefs.isEmpty()) "consensus-block-$height" else ""
        )
        val merkleRoot = blockHasher.computeBodyMerkleRoot(body)
        val header = BlockHeader(
            height = height,
            previousHash = previousHash.lowercase(),
            timestamp = timestamp,
            chainId = config.chainId,
            protocolVersion = config.protocolVersion,
            merkleRoot = merkleRoot,
            transactionCount = txRefs.size,
            producerId = "stage10-proposer",
            consensusMetadata = consensusMetadata
        )
        val hash = blockHasher.computeHeaderHash(header)
        return Block(
            header = header,
            body = body,
            hash = hash
        )
    }

    @Test
    fun test01_quorumCalculatorMathematicalSafetyProperties() {
        for (n in 4..10) {
            val q = QuorumCalculator.calculate(n)
            assertTrue("N=$n must satisfy BFT safety", q.isBftSafetyAchieved)
            val overlap = 2 * q.requiredQuorum - n
            assertEquals(overlap, q.minIntersectionGuaranteed)
            assertTrue(
                "N=$n overlap=$overlap must exceed F=${q.toleratedByzantineFaults}",
                overlap >= q.toleratedByzantineFaults + 1
            )
        }

        val q4 = QuorumCalculator.calculate(4)
        assertEquals(1, q4.toleratedByzantineFaults)
        assertEquals(3, q4.requiredQuorum)

        val q5 = QuorumCalculator.calculate(5)
        assertEquals(1, q5.toleratedByzantineFaults)
        assertEquals(4, q5.requiredQuorum) // Ensures 2Q-N = 3 > F=1

        val q6 = QuorumCalculator.calculate(6)
        assertEquals(1, q6.toleratedByzantineFaults)
        assertEquals(5, q6.requiredQuorum)

        val q7 = QuorumCalculator.calculate(7)
        assertEquals(2, q7.toleratedByzantineFaults)
        assertEquals(5, q7.requiredQuorum)

        for (smallN in 0..3) {
            val qSmall = QuorumCalculator.calculate(smallN)
            assertFalse("N=$smallN must flag insufficient BFT safety", qSmall.isBftSafetyAchieved)
        }
    }

    @Test
    fun test02_validatorEligibilityAntiSelfAppointmentAndDeterministicSchedule() = runBlocking {
        val nodes = createValidatorNodes(4)
        val outsiderKey = crypto.generateEd25519KeyPair()
        val outsiderPubHex = crypto.toHex(outsiderKey.publicKeyBytes)
        val outsiderValId = signer.deriveValidatorId(outsiderKey.publicKeyBytes)

        val engine = ConsensusEngine(
            config = config,
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true)
        )
        engine.initialize(initialValidators = nodes.map { it.info })

        val gateway = ConsensusP2pGateway(engine)
        val outsiderSession = PeerSession(
            sessionId = "sess-outsider",
            peerId = "peer-outsider",
            remotePublicKeyHex = outsiderPubHex,
            endpoint = PeerEndpoint("127.0.0.1", 9200, "peer-outsider"),
            state = P2pSessionState.ACTIVE
        )

        // Outsider tries to self-appoint via P2P VALIDATOR_STATUS announcement
        val selfAppointAnnouncement = signer.signValidatorStatusWithKeyPair(
            ValidatorStatusAnnouncement(
                chainId = config.chainId,
                validatorId = outsiderValId,
                publicKeyHex = outsiderPubHex,
                availability = ValidatorAvailability.ONLINE_AVAILABLE,
                currentHeight = 1L,
                currentRound = 0,
                timestamp = System.currentTimeMillis()
            ),
            outsiderKey.privateKeyBytes
        )
        val p2pResult = gateway.handleIncomingConsensusMessage(
            fromSession = outsiderSession,
            message = P2pMessage(
                senderPeerId = outsiderSession.peerId,
                recipientPeerId = P2pMessage.BROADCAST_RECIPIENT,
                messageType = P2pMessageType.VALIDATOR_STATUS,
                payload = selfAppointAnnouncement.toJson()
            )
        )
        assertTrue(p2pResult is ConsensusInboundResult.Rejected)
        assertNull(engine.getCurrentValidatorSetSnapshot().findValidator(outsiderValId))

        // Verify identical deterministic proposer schedule on two separate partitioned nodes
        val registryA = ValidatorEligibilityRegistry(config)
        val registryB = ValidatorEligibilityRegistry(config)
        registryA.loadRestoredValidators(nodes.map { it.info })
        registryB.loadRestoredValidators(nodes.map { it.info }.reversed())

        val snapA = registryA.buildSnapshot(1L)
        val snapB = registryB.buildSnapshot(1L)
        assertEquals(snapA.snapshotHash, snapB.snapshotHash)

        for (h in 1L..5L) {
            for (r in 0..3) {
                val pA = registryA.selectDeterministicProposer(snapA, h, r)
                val pB = registryB.selectDeterministicProposer(snapB, h, r)
                assertNotNull(pA)
                assertEquals(pA?.validatorId, pB?.validatorId)
            }
        }
        engine.close()
    }

    @Test
    fun test03_proposalValidationStage8IntegrityAndProposerScheduleEnforcement() = runBlocking {
        val nodes = createValidatorNodes(4)
        val now = System.currentTimeMillis()
        val blockchainManager = BlockchainManager(
            context = context,
            config = BlockchainConfig(databaseName = "nmd_blockchain_consensus_test.db"),
            inMemoryStorage = true
        )
        blockchainManager.initialize().getOrThrow()
        val genesis = blockchainManager.getGenesisBlock()!!

        val engine = ConsensusEngine(
            config = config,
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true),
            blockchainManager = blockchainManager
        )
        engine.initialize(initialValidators = nodes.map { it.info }, nowMs = now)

        val expectedProposer = engine.registry.selectDeterministicProposer(
            engine.getCurrentValidatorSetSnapshot(),
            height = 1L,
            round = 0
        )!!
        val expectedNode = nodes.first { it.validatorId == expectedProposer.validatorId }
        val wrongNode = nodes.first { it.validatorId != expectedProposer.validatorId }

        val validBlock = buildValidStage8Block(height = 1L, previousHash = genesis.hash, timestamp = now)

        // 1. Out-of-turn validator proposes -> Rejected INVALID_PROPOSER
        val wrongTurnProposal = signer.signProposalWithKeyPair(
            BlockProposal(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = 1L,
                round = 0,
                proposedBlockHash = validBlock.hash,
                previousBlockHash = genesis.hash,
                proposerId = wrongNode.validatorId,
                proposerPublicKeyHex = wrongNode.publicKeyHex,
                timestamp = now,
                attachedBlock = validBlock
            ),
            wrongNode.keyPair.privateKeyBytes
        )
        val wrongRes = engine.submitProposal(wrongTurnProposal, now)
        assertTrue(wrongRes is ProposalSubmissionResult.Rejected)
        assertEquals(ConsensusErrorCode.INVALID_PROPOSER, (wrongRes as ProposalSubmissionResult.Rejected).code)

        // 2. Stage 8 corrupted Merkle root block proposed by legitimate proposer -> Rejected BLOCK_STRUCTURAL_INVALID
        val corruptedHeader = validBlock.header.copy(merkleRoot = "f".repeat(64))
        val corruptedBlock = validBlock.copy(
            header = corruptedHeader,
            hash = blockHasher.computeHeaderHash(corruptedHeader)
        )
        val badBlockProposal = signer.signProposalWithKeyPair(
            BlockProposal(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = 1L,
                round = 0,
                proposedBlockHash = corruptedBlock.hash,
                previousBlockHash = genesis.hash,
                proposerId = expectedNode.validatorId,
                proposerPublicKeyHex = expectedNode.publicKeyHex,
                timestamp = now,
                attachedBlock = corruptedBlock
            ),
            expectedNode.keyPair.privateKeyBytes
        )
        val badBlockRes = engine.submitProposal(badBlockProposal, now)
        assertTrue(badBlockRes is ProposalSubmissionResult.Rejected)
        assertEquals(ConsensusErrorCode.BLOCK_STRUCTURAL_INVALID, (badBlockRes as ProposalSubmissionResult.Rejected).code)

        // 3. Valid scheduled proposal -> Accepted
        val validProposal = signer.signProposalWithKeyPair(
            BlockProposal(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = 1L,
                round = 0,
                proposedBlockHash = validBlock.hash,
                previousBlockHash = genesis.hash,
                proposerId = expectedNode.validatorId,
                proposerPublicKeyHex = expectedNode.publicKeyHex,
                timestamp = now,
                attachedBlock = validBlock
            ),
            expectedNode.keyPair.privateKeyBytes
        )
        val validRes = engine.submitProposal(validProposal, now)
        assertTrue(validRes is ProposalSubmissionResult.Accepted)
        assertEquals(ConsensusPhase.PRE_VOTING, engine.state.value.phase)

        engine.close()
        blockchainManager.close()
    }

    @Test
    fun test04_voteValidationQuorumThresholdAndNoCommitWithoutQuorum() = runBlocking {
        val nodes = createValidatorNodes(4)
        val outsider = crypto.generateEd25519KeyPair()
        val now = System.currentTimeMillis()
        val engine = ConsensusEngine(
            config = config,
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true)
        )
        engine.initialize(initialValidators = nodes.map { it.info }, nowMs = now)

        val proposerNode = nodes.first {
            it.validatorId == engine.registry.selectDeterministicProposer(
                engine.getCurrentValidatorSetSnapshot(),
                1L,
                0
            )!!.validatorId
        }
        val block = buildValidStage8Block(height = 1L, previousHash = ConsensusConstants.NIL_BLOCK_HASH, timestamp = now)
        val proposal = signer.signProposalWithKeyPair(
            BlockProposal(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = 1L,
                round = 0,
                proposedBlockHash = block.hash,
                previousBlockHash = ConsensusConstants.NIL_BLOCK_HASH,
                proposerId = proposerNode.validatorId,
                proposerPublicKeyHex = proposerNode.publicKeyHex,
                timestamp = now
            ),
            proposerNode.keyPair.privateKeyBytes
        )
        assertTrue(engine.submitProposal(proposal, now) is ProposalSubmissionResult.Accepted)

        val unauthVote = signer.signVoteWithKeyPair(
            ConsensusVote(
                chainId = config.chainId,
                blockHeight = 1L,
                round = 0,
                votePhase = VotePhase.PREVOTE,
                validatorId = signer.deriveValidatorId(outsider.publicKeyBytes),
                validatorPublicKeyHex = crypto.toHex(outsider.publicKeyBytes),
                proposedBlockHash = block.hash,
                timestamp = now
            ),
            outsider.privateKeyBytes
        )
        val unauthRes = engine.submitVote(unauthVote, now)
        assertEquals(ConsensusErrorCode.UNAUTHORIZED_VALIDATOR, (unauthRes as VoteSubmissionResult.Rejected).code)

        // Submit only 2 prevotes (< quorum 3) -> MUST NOT enter PRE_COMMITTING or finalize
        for (i in 0..1) {
            val v = signer.signVoteWithKeyPair(
                ConsensusVote(
                    chainId = config.chainId,
                    blockHeight = 1L,
                    round = 0,
                    votePhase = VotePhase.PREVOTE,
                    validatorId = nodes[i].validatorId,
                    validatorPublicKeyHex = nodes[i].publicKeyHex,
                    proposedBlockHash = block.hash,
                    timestamp = now
                ),
                nodes[i].keyPair.privateKeyBytes
            )
            val res = engine.submitVote(v, now)
            assertTrue(res is VoteSubmissionResult.Accepted)
            assertFalse((res as VoteSubmissionResult.Accepted).quorumReached)
        }

        // Duplicate identical vote from validator 0 ignored
        val dupVote = signer.signVoteWithKeyPair(
            ConsensusVote(
                chainId = config.chainId,
                blockHeight = 1L,
                round = 0,
                votePhase = VotePhase.PREVOTE,
                validatorId = nodes[0].validatorId,
                validatorPublicKeyHex = nodes[0].publicKeyHex,
                proposedBlockHash = block.hash,
                timestamp = now + 5
            ),
            nodes[0].keyPair.privateKeyBytes
        )
        assertTrue(engine.submitVote(dupVote, now + 5) is VoteSubmissionResult.Duplicate)

        // Local validator precommit MUST be refused when prevote quorum is not reached
        val earlyPrecommit = engine.signLocalVote(
            votePhase = VotePhase.PRECOMMIT,
            targetBlockHash = block.hash,
            privateKeyBytesForTest = nodes[0].keyPair.privateKeyBytes,
            nowMs = now
        )
        assertTrue(earlyPrecommit is LocalSignVoteResult.Refused)
        assertEquals(0L, engine.state.value.latestFinalizedHeight)
        assertEquals(ConsensusPhase.PRE_VOTING, engine.state.value.phase)

        engine.close()
    }

    @Test
    fun test05_fullFourValidatorBftCycleCommitsBlockAndMarksTransactionsConfirmed() = runBlocking {
        val nodes = createValidatorNodes(4)
        val now = System.currentTimeMillis()
        val blockchainManager = BlockchainManager(
            context = context,
            config = BlockchainConfig(databaseName = "nmd_blockchain_consensus_test.db"),
            inMemoryStorage = true
        )
        blockchainManager.initialize().getOrThrow()
        val genesis = blockchainManager.getGenesisBlock()!!

        val txEngine = TransactionEngineManager(
            context = context,
            dbName = "nmd_tx_consensus_test.db",
            inMemoryStorage = true,
            blockchainManager = blockchainManager
        )
        txEngine.initialize()

        val keyStoreStorage = KeyStoreStorageService(
            context = context,
            preferencesName = "test_stage10_wallet_prefs",
            allowTestEnvironmentFallback = true
        )
        val idRepo = IdentityRepositoryImpl(
            cryptoProvider = crypto,
            storageService = keyStoreStorage
        )
        val identityMgr = NodeIdentityManager(idRepo)
        val walletIdentity = identityMgr.generateNewIdentity()
        val senderAddr = txEngine.deriveSenderAddress(walletIdentity)!!
        val txOutcome = txEngine.createSignAndSubmit(
            identityRepository = idRepo,
            recipientAddress = senderAddr,
            amountUnits = 500_000L,
            txType = TransactionType.ACCOUNT_INITIALIZATION,
            attemptBroadcast = false,
            nowMs = now
        )
        assertTrue(txOutcome is WalletTxCreationOutcome.Submitted)
        val submittedTx = (txOutcome as WalletTxCreationOutcome.Submitted).record.transaction

        val engine = ConsensusEngine(
            config = config,
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true),
            blockchainManager = blockchainManager,
            txBlockBridge = txEngine.blockBridge
        )
        engine.initialize(initialValidators = nodes.map { it.info }, nowMs = now)

        val scheduledId = engine.state.value.currentProposerId!!
        val proposer = nodes.first { it.validatorId == scheduledId }
        val block = buildValidStage8Block(
            height = 1L,
            previousHash = genesis.hash,
            txRefs = txEngine.blockBridge!!.toTransactionReferences(listOf(submittedTx)),
            timestamp = now
        )

        val proposal = signer.signProposalWithKeyPair(
            BlockProposal(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = 1L,
                round = 0,
                proposedBlockHash = block.hash,
                previousBlockHash = genesis.hash,
                proposerId = proposer.validatorId,
                proposerPublicKeyHex = proposer.publicKeyHex,
                timestamp = now,
                attachedBlock = block
            ),
            proposer.keyPair.privateKeyBytes
        )
        assertTrue(engine.submitProposal(proposal, now) is ProposalSubmissionResult.Accepted)

        for (i in 0..2) {
            val prevote = signer.signVoteWithKeyPair(
                ConsensusVote(
                    chainId = config.chainId,
                    blockHeight = 1L,
                    round = 0,
                    votePhase = VotePhase.PREVOTE,
                    validatorId = nodes[i].validatorId,
                    validatorPublicKeyHex = nodes[i].publicKeyHex,
                    proposedBlockHash = block.hash,
                    timestamp = now + 10
                ),
                nodes[i].keyPair.privateKeyBytes
            )
            assertTrue(engine.submitVote(prevote, now + 10) is VoteSubmissionResult.Accepted)
        }
        assertEquals(ConsensusPhase.PRE_COMMITTING, engine.state.value.phase)
        assertEquals(0L, engine.state.value.latestFinalizedHeight)

        var cert: CommitCertificate? = null
        for (i in 0..2) {
            val precommit = signer.signVoteWithKeyPair(
                ConsensusVote(
                    chainId = config.chainId,
                    blockHeight = 1L,
                    round = 0,
                    votePhase = VotePhase.PRECOMMIT,
                    validatorId = nodes[i].validatorId,
                    validatorPublicKeyHex = nodes[i].publicKeyHex,
                    proposedBlockHash = block.hash,
                    timestamp = now + 20
                ),
                nodes[i].keyPair.privateKeyBytes
            )
            val res = engine.submitVote(precommit, now + 20) as VoteSubmissionResult.Accepted
            if (res.commitCertificate != null) cert = res.commitCertificate
        }

        assertNotNull("CommitCertificate must be produced at quorum", cert)
        assertEquals(1L, cert!!.blockHeight)
        assertEquals(block.hash, cert.blockHash)

        assertEquals(1L, engine.state.value.latestFinalizedHeight)
        assertEquals(block.hash, engine.state.value.latestFinalizedHash)
        assertEquals(2L, engine.state.value.currentHeight)
        assertEquals(0, engine.state.value.currentRound)

        assertEquals(1L, blockchainManager.getCurrentHeight())
        assertEquals(block.hash, blockchainManager.getLatestBlock()?.hash)

        val lookup = txEngine.lookupTransaction(submittedTx.txId)
        assertNotNull(lookup)
        assertEquals(MempoolTxStatus.CONFIRMED, lookup!!.mempoolRecord?.status)
        assertEquals(1L, lookup.includedInBlockHeight)

        engine.close()
        txEngine.close()
        blockchainManager.close()
    }

    @Test
    fun test06_equivocationDetectionAndCryptographicProofGuard() = runBlocking {
        val nodes = createValidatorNodes(4)
        val now = System.currentTimeMillis()
        val engine = ConsensusEngine(
            config = config,
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true)
        )
        engine.initialize(initialValidators = nodes.map { it.info }, nowMs = now)

        val hashA = crypto.toHex(crypto.sha256("blockA".toByteArray()))
        val hashB = crypto.toHex(crypto.sha256("blockB".toByteArray()))

        val maliciousNode = nodes[0]
        val vote1 = signer.signVoteWithKeyPair(
            ConsensusVote(
                chainId = config.chainId,
                blockHeight = 1L,
                round = 0,
                votePhase = VotePhase.PREVOTE,
                validatorId = maliciousNode.validatorId,
                validatorPublicKeyHex = maliciousNode.publicKeyHex,
                proposedBlockHash = hashA,
                timestamp = now
            ),
            maliciousNode.keyPair.privateKeyBytes
        )
        val vote2 = signer.signVoteWithKeyPair(
            ConsensusVote(
                chainId = config.chainId,
                blockHeight = 1L,
                round = 0,
                votePhase = VotePhase.PREVOTE,
                validatorId = maliciousNode.validatorId,
                validatorPublicKeyHex = maliciousNode.publicKeyHex,
                proposedBlockHash = hashB,
                timestamp = now + 5
            ),
            maliciousNode.keyPair.privateKeyBytes
        )

        assertTrue(engine.submitVote(vote1, now) is VoteSubmissionResult.Accepted)
        val conflictRes = engine.submitVote(vote2, now + 5)
        assertTrue(conflictRes is VoteSubmissionResult.Rejected)
        val rejected = conflictRes as VoteSubmissionResult.Rejected
        assertEquals(ConsensusErrorCode.CONFLICTING_VOTE, rejected.code)
        assertNotNull(rejected.equivocationEvidence)
        assertEquals(EquivocationType.CONFLICTING_PREVOTE, rejected.equivocationEvidence!!.evidenceType)
        assertTrue(rejected.equivocationEvidence!!.verifiedCryptographically)

        val updatedMalicious = engine.getCurrentValidatorSetSnapshot().findValidator(maliciousNode.validatorId)
        assertEquals(ValidatorStatus.SLASHED_PENDING_REVIEW, updatedMalicious?.status)
        assertEquals(1, engine.equivocationHistory.value.size)

        val honestNode = nodes[1]
        val honestVote1 = signer.signVoteWithKeyPair(
            ConsensusVote(
                chainId = config.chainId,
                blockHeight = 1L,
                round = 0,
                votePhase = VotePhase.PREVOTE,
                validatorId = honestNode.validatorId,
                validatorPublicKeyHex = honestNode.publicKeyHex,
                proposedBlockHash = hashA,
                timestamp = now
            ),
            honestNode.keyPair.privateKeyBytes
        )
        val forgedVote2 = honestVote1.copy(proposedBlockHash = hashB)
        val forgedEvidence = engine.validators.verifyAndBuildVoteEquivocationEvidence(
            firstVote = honestVote1,
            secondVote = forgedVote2,
            snapshot = engine.getCurrentValidatorSetSnapshot()
        )
        assertNull("Forged equivocation claim must never pass verification", forgedEvidence)
        assertEquals(
            ValidatorStatus.ACTIVE,
            engine.getCurrentValidatorSetSnapshot().findValidator(honestNode.validatorId)?.status
        )

        engine.close()
    }

    @Test
    fun test07_roundChangeAndTimeoutAdvanceRoundAndProposerSafely() = runBlocking {
        val nodes = createValidatorNodes(4)
        val now = 1_700_000_000_000L
        val engine = ConsensusEngine(
            config = ConsensusConfig(baseProposalTimeoutMs = 1_000L),
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true)
        )
        engine.initialize(initialValidators = nodes.map { it.info }, nowMs = now)

        val round0Proposer = engine.state.value.currentProposerId
        assertNotNull(round0Proposer)

        assertFalse(engine.checkAndAdvanceOnTimeout(now + 500L))
        assertEquals(0, engine.state.value.currentRound)

        assertTrue(engine.checkAndAdvanceOnTimeout(now + 1_200L))
        assertEquals(1, engine.state.value.currentRound)
        val round1Proposer = engine.state.value.currentProposerId
        assertNotNull(round1Proposer)
        assertNotEquals(round0Proposer, round1Proposer)

        val rcMsg = signer.signRoundChangeWithKeyPair(
            RoundChangeMessage(
                chainId = config.chainId,
                blockHeight = 1L,
                fromRound = 0,
                toRound = 1,
                validatorId = nodes[0].validatorId,
                validatorPublicKeyHex = nodes[0].publicKeyHex,
                reason = "ROUND_TIMEOUT",
                timestamp = now + 1_200L
            ),
            nodes[0].keyPair.privateKeyBytes
        )
        assertTrue(engine.processRoundChangeMessage(rcMsg, now + 1_200L).isValid)

        engine.close()
    }

    @Test
    fun test08_consensusBlockValidationHookValidatesAndRejectsBlocks() = runBlocking {
        val nodes = createValidatorNodes(4)
        val now = System.currentTimeMillis()
        val blockchainManager = BlockchainManager(
            context = context,
            config = BlockchainConfig(databaseName = "nmd_blockchain_consensus_test.db"),
            inMemoryStorage = true
        )
        blockchainManager.initialize().getOrThrow()
        val genesis = blockchainManager.getGenesisBlock()!!

        val engine = ConsensusEngine(
            config = config,
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true)
        )
        engine.initialize(initialValidators = nodes.map { it.info }, nowMs = now)
        val snapshot = engine.getCurrentValidatorSetSnapshot()
        val hook = ConsensusBlockValidationHook(engine.validators, { snapshot }, blockHasher)

        val draftBlock = buildValidStage8Block(height = 1L, previousHash = genesis.hash, timestamp = now)
        val validVotes = nodes.take(3).map { node ->
            signer.signVoteWithKeyPair(
                ConsensusVote(
                    chainId = config.chainId,
                    blockHeight = 1L,
                    round = 0,
                    votePhase = VotePhase.PRECOMMIT,
                    validatorId = node.validatorId,
                    validatorPublicKeyHex = node.publicKeyHex,
                    proposedBlockHash = draftBlock.hash,
                    timestamp = now
                ),
                node.keyPair.privateKeyBytes
            )
        }
        val cert = CommitCertificate(
            chainId = config.chainId,
            protocolVersion = config.protocolVersion,
            blockHeight = 1L,
            round = 0,
            blockHash = draftBlock.hash,
            previousBlockHash = genesis.hash,
            validatorSetHash = snapshot.snapshotHash,
            requiredQuorum = 3,
            precommitVotes = validVotes,
            finalizedAtMs = now
        )

        val missingRes = blockchainManager.submitIncomingBlock(draftBlock, nowMs = now, consensusHook = hook)
        assertTrue(missingRes is BlockIngestionResult.Rejected)
        assertEquals(ValidationErrorCode.CONSENSUS_REJECTED, (missingRes as BlockIngestionResult.Rejected).code)

        val certifiedHeader = draftBlock.header.copy(consensusMetadata = cert.toJson())
        val certifiedBlock = draftBlock.copy(
            header = certifiedHeader,
            hash = blockHasher.computeHeaderHash(certifiedHeader)
        )
        val okRes = blockchainManager.submitIncomingBlock(certifiedBlock, nowMs = now, consensusHook = hook)
        assertTrue("Expected Accepted with ConsensusHook, got $okRes", okRes is BlockIngestionResult.Accepted)
        assertTrue((okRes as BlockIngestionResult.Accepted).consensusValidated)

        engine.close()
        blockchainManager.close()
    }

    @Test
    fun test09_crashRecoveryPreservesHeightRoundVotesAndBlocksDoubleSigning() = runBlocking {
        val nodes = createValidatorNodes(4)
        val localNode = nodes[0]
        val dbName = "nmd_consensus_restart_test.db"
        val now = System.currentTimeMillis()

        val hash1 = crypto.toHex(crypto.sha256("candidate-block-1".toByteArray()))
        val hash2 = crypto.toHex(crypto.sha256("conflicting-block-2".toByteArray()))

        val storage1 = RoomConsensusStorage(context, dbName, inMemory = false)
        val engine1 = ConsensusEngine(config = config, storage = storage1)
        engine1.initialize(
            initialValidators = nodes.map { it.info },
            localDevicePublicKeyHex = localNode.publicKeyHex,
            nowMs = now
        )
        val round0Proposer = nodes.first { it.validatorId == engine1.state.value.currentProposerId!! }
        val proposal = signer.signProposalWithKeyPair(
            BlockProposal(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = 1L,
                round = 0,
                proposedBlockHash = hash1,
                previousBlockHash = ConsensusConstants.NIL_BLOCK_HASH,
                proposerId = round0Proposer.validatorId,
                proposerPublicKeyHex = round0Proposer.publicKeyHex,
                timestamp = now
            ),
            round0Proposer.keyPair.privateKeyBytes
        )
        engine1.submitProposal(proposal, now)

        val localVoteRes = engine1.signLocalVote(
            votePhase = VotePhase.PREVOTE,
            targetBlockHash = hash1,
            privateKeyBytesForTest = localNode.keyPair.privateKeyBytes,
            nowMs = now
        )
        assertTrue(localVoteRes is LocalSignVoteResult.Signed)
        engine1.submitVote((localVoteRes as LocalSignVoteResult.Signed).vote, now)
        assertEquals(1, engine1.state.value.prevotesReceived)
        engine1.close()

        val storage2 = RoomConsensusStorage(context, dbName, inMemory = false)
        val engine2 = ConsensusEngine(config = config, storage = storage2)
        val restored = engine2.initialize(
            localDevicePublicKeyHex = localNode.publicKeyHex,
            nowMs = now + 500
        )
        assertEquals(1L, restored.currentHeight)
        assertEquals(0, restored.currentRound)
        assertEquals(4, restored.activeValidatorCount)
        assertEquals(1, restored.prevotesReceived)
        assertEquals(ConsensusPhase.PRE_VOTING, restored.phase)

        val doubleSignAttempt = engine2.signLocalVote(
            votePhase = VotePhase.PREVOTE,
            targetBlockHash = hash2,
            privateKeyBytesForTest = localNode.keyPair.privateKeyBytes,
            nowMs = now + 600
        )
        assertTrue(doubleSignAttempt is LocalSignVoteResult.Refused)
        assertEquals(
            ConsensusErrorCode.SAFETY_DOUBLE_SIGN_PREVENTED,
            (doubleSignAttempt as LocalSignVoteResult.Refused).code
        )

        engine2.close()
    }

    @Test
    fun test10_offlinePartitionHealingMobileBatteryGuardAndP2pSecurity() = runBlocking {
        val nodes = createValidatorNodes(4)
        val now = System.currentTimeMillis()
        val peerRegistry = DistributedPeerRegistry(
            context = null,
            scope = testScope,
            ioDispatcher = Dispatchers.IO
        )
        val engine = ConsensusEngine(
            config = config,
            storage = RoomConsensusStorage(context, "nmd_consensus_test.db", inMemory = true)
        )
        engine.initialize(
            initialValidators = nodes.map { it.info },
            localDevicePublicKeyHex = nodes[0].publicKeyHex,
            nowMs = now
        )
        val gateway = ConsensusP2pGateway(engine, peerRegistry)

        val peer1Session = PeerSession(
            sessionId = "sess-v1",
            peerId = "peer-v1",
            remotePublicKeyHex = nodes[1].publicKeyHex,
            endpoint = PeerEndpoint("192.168.1.21", 9200, "peer-v1"),
            state = P2pSessionState.ACTIVE
        )
        peerRegistry.registerOrUpdatePeer(
            peerId = "peer-v1",
            endpoint = PeerEndpoint("192.168.1.21", 9200, "peer-v1"),
            source = DiscoverySource.MANUAL,
            publicKeyHex = nodes[1].publicKeyHex,
            reachability = ReachabilityStatus.CONNECTED,
            capabilities = listOf(PeerCapability.BLOCK_SYNC)
        )
        val initialRep = peerRegistry.getPeer("peer-v1")!!.reputationScore

        val forgedProposal = BlockProposal(
            chainId = config.chainId,
            protocolVersion = config.protocolVersion,
            blockHeight = 1L,
            round = 0,
            proposedBlockHash = crypto.toHex(crypto.sha256("bad".toByteArray())),
            previousBlockHash = ConsensusConstants.NIL_BLOCK_HASH,
            proposerId = nodes[1].validatorId,
            proposerPublicKeyHex = nodes[1].publicKeyHex,
            timestamp = now,
            signatureHex = "00".repeat(64)
        )
        val gwReject = gateway.handleIncomingConsensusMessage(
            fromSession = peer1Session,
            message = P2pMessage(
                senderPeerId = "peer-v1",
                recipientPeerId = P2pMessage.BROADCAST_RECIPIENT,
                messageType = P2pMessageType.BLOCK_PROPOSAL,
                payload = forgedProposal.toJson()
            ),
            nowMs = now
        )
        assertTrue(gwReject is ConsensusInboundResult.Rejected)
        assertTrue((gwReject as ConsensusInboundResult.Rejected).penalizedPeer)
        assertTrue(peerRegistry.getPeer("peer-v1")!!.reputationScore < initialRep)

        val healedBlock = buildValidStage8Block(height = 1L, previousHash = ConsensusConstants.NIL_BLOCK_HASH, timestamp = now)
        val snap = engine.getCurrentValidatorSetSnapshot()
        val quorumVotes = listOf(0, 1, 3).map { idx ->
            signer.signVoteWithKeyPair(
                ConsensusVote(
                    chainId = config.chainId,
                    blockHeight = 1L,
                    round = 0,
                    votePhase = VotePhase.PRECOMMIT,
                    validatorId = nodes[idx].validatorId,
                    validatorPublicKeyHex = nodes[idx].publicKeyHex,
                    proposedBlockHash = healedBlock.hash,
                    timestamp = now + 50
                ),
                nodes[idx].keyPair.privateKeyBytes
            )
        }
        val cert = CommitCertificate(
            chainId = config.chainId,
            protocolVersion = config.protocolVersion,
            blockHeight = 1L,
            round = 0,
            blockHash = healedBlock.hash,
            previousBlockHash = ConsensusConstants.NIL_BLOCK_HASH,
            validatorSetHash = snap.snapshotHash,
            requiredQuorum = 3,
            precommitVotes = quorumVotes,
            finalizedAtMs = now + 50
        )
        val healRes = gateway.handleIncomingConsensusMessage(
            fromSession = peer1Session,
            message = P2pMessage(
                senderPeerId = "peer-v1",
                recipientPeerId = P2pMessage.BROADCAST_RECIPIENT,
                messageType = P2pMessageType.CONSENSUS_COMMIT,
                payload = cert.toJson()
            ),
            nowMs = now + 60
        )
        assertTrue("Partitioned node must accept verified CommitCertificate, got $healRes", healRes is ConsensusInboundResult.Accepted)
        assertEquals(1L, engine.state.value.latestFinalizedHeight)
        assertEquals(2L, engine.state.value.currentHeight)

        val lowBattery = DeviceTelemetry(
            availableRamMb = 2048L,
            totalRamMb = 4096L,
            batteryPercent = 9,
            isCharging = false,
            networkType = "Wi-Fi"
        )
        val eval = MobileParticipationPolicy.evaluateDevice(lowBattery, config)
        assertTrue(eval.shouldPauseActiveSigning)
        val updatedState = engine.updateLocalDeviceTelemetry(lowBattery, now + 100)
        assertTrue(updatedState.localMobilePaused)

        val blockedVote = engine.signLocalVote(
            votePhase = VotePhase.PREVOTE,
            targetBlockHash = crypto.toHex(crypto.sha256("block2".toByteArray())),
            privateKeyBytesForTest = nodes[0].keyPair.privateKeyBytes,
            nowMs = now + 100
        )
        assertTrue(blockedVote is LocalSignVoteResult.Refused)
        assertEquals(ConsensusErrorCode.MOBILE_RESOURCE_PAUSED, (blockedVote as LocalSignVoteResult.Refused).code)

        engine.close()
    }
}
