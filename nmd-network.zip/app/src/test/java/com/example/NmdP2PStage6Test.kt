package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.protocol.MessageValidationResult
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.reliable.DeliveryResult
import com.example.p2p.reliable.DeliveryStatus
import com.example.p2p.reliable.MessageDeduplicationCache
import com.example.p2p.reliable.ReliableDeliveryManager
import com.example.p2p.repository.NetworkTransportRepository
import com.example.p2p.session.ConnectionHealth
import com.example.p2p.session.P2pSessionState
import com.example.p2p.session.PeerSession
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdP2PStage6Test {

    private lateinit var context: Context
    private lateinit var testScope: CoroutineScope
    private val cryptoProvider = BouncyCastleEd25519Provider()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testScope = CoroutineScope(Dispatchers.IO)
    }

    @After
    fun tearDown() {
        // Clean up SharedPreferences between tests
        val prefs = context.getSharedPreferences("nmd_p2p_handshake_replay_cache", Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
    }

    private fun createTestIdentity(alias: String): NodeIdentityManager {
        val storage = KeyStoreStorageService(
            context = context,
            preferencesName = "test_nmd_prefs_stage6_$alias",
            allowTestEnvironmentFallback = true
        )
        val repo = IdentityRepositoryImpl(
            cryptoProvider = cryptoProvider,
            storageService = storage
        )
        val mgr = NodeIdentityManager(repo)
        mgr.generateNewIdentity()
        return mgr
    }

    // ==========================================
    // 1. Message Protocol & Integrity Tests
    // ==========================================

    @Test
    fun testP2pMessageSerializationAndCanonicalBytes() {
        val msg = P2pMessage(
            messageId = "msg-uuid-12345",
            protocolVersion = 1,
            senderPeerId = "node_sender_abc",
            recipientPeerId = "node_recipient_xyz",
            messageType = P2pMessageType.DATA,
            timestamp = 1700000000000L,
            sequenceNumber = 42L,
            payload = "{\"tx_count\":10}",
            signatureHex = "deadbeef01020304"
        )

        val json = msg.toJson()
        val deserialized = P2pMessage.fromJson(json)

        assertNotNull("Deserialized message must not be null", deserialized)
        assertEquals(msg.messageId, deserialized!!.messageId)
        assertEquals(msg.senderPeerId, deserialized.senderPeerId)
        assertEquals(msg.recipientPeerId, deserialized.recipientPeerId)
        assertEquals(msg.messageType, deserialized.messageType)
        assertEquals(msg.timestamp, deserialized.timestamp)
        assertEquals(msg.sequenceNumber, deserialized.sequenceNumber)
        assertEquals(msg.payload, deserialized.payload)
        assertEquals(msg.signatureHex, deserialized.signatureHex)

        val canonicalBytes = msg.getCanonicalBytes()
        assertTrue("Canonical bytes must not be empty", canonicalBytes.isNotEmpty())
        val header = String(canonicalBytes.copyOfRange(0, 15), Charsets.UTF_8)
        assertEquals("NMD-P2P-MSG-V1\u0000", header)
    }

    @Test
    fun testP2pMessageSigningAndValidationSuccess() {
        val idMgr = createTestIdentity("signer_1")
        val activeId = idMgr.getActiveIdentity()!!

        val message = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            senderPeerId = activeId.nodeId,
            recipientPeerId = "peer_target_001",
            messageType = P2pMessageType.DATA,
            timestamp = System.currentTimeMillis(),
            sequenceNumber = 1L,
            payload = "{\"action\":\"sync_state\"}"
        )

        val canonicalBytes = message.getCanonicalBytes()
        val sigBytes = idMgr.signRawData(canonicalBytes)
        val sigHex = cryptoProvider.toHex(sigBytes)

        val signedMessage = message.copy(signatureHex = sigHex)
        val pubBytes = cryptoProvider.fromHex(activeId.publicKeyHex)

        val result = signedMessage.validate(
            expectedRecipientPeerId = "peer_target_001",
            cryptoProvider = cryptoProvider,
            senderPublicKeyBytes = pubBytes
        )

        assertTrue("Validation must succeed for authentic signed message", result is MessageValidationResult.Valid)
    }

    @Test
    fun testP2pMessageTamperingRejected() {
        val idMgr = createTestIdentity("tamper_test")
        val activeId = idMgr.getActiveIdentity()!!

        val originalMessage = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            senderPeerId = activeId.nodeId,
            recipientPeerId = "peer_recipient_abc",
            messageType = P2pMessageType.DATA,
            timestamp = System.currentTimeMillis(),
            payload = "{\"transfer_amount\":50}"
        )

        val sigBytes = idMgr.signRawData(originalMessage.getCanonicalBytes())
        val sigHex = cryptoProvider.toHex(sigBytes)
        val pubBytes = cryptoProvider.fromHex(activeId.publicKeyHex)

        // 1. Tamper payload
        val tamperedPayload = originalMessage.copy(
            payload = "{\"transfer_amount\":50000}",
            signatureHex = sigHex
        )
        val r1 = tamperedPayload.validate("peer_recipient_abc", cryptoProvider, pubBytes)
        assertTrue("Tampered payload must be rejected", r1 is MessageValidationResult.Invalid)

        // 2. Tamper recipient
        val tamperedRecipient = originalMessage.copy(
            recipientPeerId = "peer_attacker_xyz",
            signatureHex = sigHex
        )
        val r2 = tamperedRecipient.validate("peer_recipient_abc", cryptoProvider, pubBytes)
        assertTrue("Tampered recipient must be rejected", r2 is MessageValidationResult.Invalid)
    }

    @Test
    fun testP2pMessageRejectsExpiredTimestamp() {
        val idMgr = createTestIdentity("ts_test")
        val activeId = idMgr.getActiveIdentity()!!

        // Timestamp 5 minutes in the past
        val expiredMessage = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            senderPeerId = activeId.nodeId,
            recipientPeerId = "*",
            messageType = P2pMessageType.DATA,
            timestamp = System.currentTimeMillis() - 300_000L,
            payload = "{\"expired\":true}"
        )

        val r = expiredMessage.validate()
        assertTrue("Expired message must be rejected by freshness window", r is MessageValidationResult.Invalid)
        assertTrue((r as MessageValidationResult.Invalid).reason.contains("drift"))
    }

    // ==========================================
    // 2. Reliable Delivery & ACK Engine Tests
    // ==========================================

    @Test
    fun testReliableDeliverySuccessWithAck() = runBlocking {
        val deliveryManager = ReliableDeliveryManager(testScope)

        val msg = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            senderPeerId = "nodeA",
            recipientPeerId = "nodeB",
            messageType = P2pMessageType.DATA,
            payload = "{\"ping_test\":1}"
        )

        // Mock remote peer replying with ACK after 50ms
        val sendAction: suspend (P2pMessage) -> Unit = { outboundMsg ->
            testScope.launch {
                delay(50)
                val ack = P2pMessage.createAck(outboundMsg, "nodeB")
                deliveryManager.handleAckReceived(ack)
            }
        }

        val result = deliveryManager.sendReliably(
            message = msg,
            targetSessionId = "sess-1",
            sendAction = sendAction,
            maxRetries = 2,
            ackTimeoutMs = 1000L
        )

        assertTrue("Delivery must be ACKNOWLEDGED", result.isSuccess)
        assertEquals(DeliveryStatus.ACKNOWLEDGED, result.status)
        assertTrue("Round trip latency must be recorded", result.roundTripLatencyMs >= 30L)
        assertEquals(1, result.attempts)
        deliveryManager.clear()
    }

    @Test
    fun testControlledRetryAndTimeoutHandling() = runBlocking {
        val deliveryManager = ReliableDeliveryManager(testScope)
        var attemptCounter = 0

        val msg = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            senderPeerId = "nodeA",
            recipientPeerId = "nodeB",
            messageType = P2pMessageType.DATA,
            payload = "{\"timeout_test\":true}"
        )

        val sendAction: suspend (P2pMessage) -> Unit = {
            attemptCounter++
            // Simulate dropped network packet (no ACK sent)
        }

        val result = deliveryManager.sendReliably(
            message = msg,
            targetSessionId = "sess-drop",
            sendAction = sendAction,
            maxRetries = 2,
            ackTimeoutMs = 200L
        )

        assertFalse("Delivery must fail on timeout", result.isSuccess)
        assertEquals(DeliveryStatus.TIMED_OUT, result.status)
        assertTrue("Must have attempted controlled retries (at least 2 attempts)", attemptCounter >= 2)
        deliveryManager.clear()
    }

    // ==========================================
    // 3. Duplicate Message Detection Tests
    // ==========================================

    @Test
    fun testMessageDeduplicationSuppressesDuplicateProcessing() = runBlocking {
        val cache = MessageDeduplicationCache(maxCapacity = 100, expirationMs = 60_000L)
        val msgId = "unique-msg-${UUID.randomUUID()}"

        val firstArrival = cache.checkAndMarkProcessed(msgId)
        assertTrue("First arrival of message must return true (new)", firstArrival)

        val secondArrival = cache.checkAndMarkProcessed(msgId)
        assertFalse("Second arrival of same message ID must return false (duplicate)", secondArrival)

        val thirdArrival = cache.checkAndMarkProcessed(msgId)
        assertFalse("Subsequent arrival must still be identified as duplicate", thirdArrival)

        val otherMsgId = "unique-msg-${UUID.randomUUID()}"
        val otherArrival = cache.checkAndMarkProcessed(otherMsgId)
        assertTrue("Different message ID must be accepted as new", otherArrival)
    }

    // ==========================================
    // 4. Peer Session & Heartbeat Tests
    // ==========================================

    @Test
    fun testPeerSessionStateTransitionsAndHealth() {
        val endpoint = PeerEndpoint("192.168.1.50", 9876)
        val session = PeerSession(
            sessionId = "sess-xyz",
            peerId = "node-alpha",
            remotePublicKeyHex = "00".repeat(32),
            endpoint = endpoint,
            state = P2pSessionState.CONNECTING
        )

        assertFalse("CONNECTING state must not be trusted", session.isTrusted)

        val connected = session.copy(state = P2pSessionState.CONNECTED)
        assertFalse("CONNECTED state without handshake must not be trusted", connected.isTrusted)

        val authenticated = connected.copy(state = P2pSessionState.AUTHENTICATED)
        assertTrue("AUTHENTICATED state must be trusted", authenticated.isTrusted)

        val active = authenticated.copy(state = P2pSessionState.ACTIVE)
        assertTrue("ACTIVE state must be trusted", active.isTrusted)

        // Health evaluation
        val now = System.currentTimeMillis()
        val excellent = ConnectionHealth.computeHealth(P2pSessionState.ACTIVE, now - 2000L, 25L, now)
        assertEquals(ConnectionHealth.EXCELLENT, excellent)

        val degraded = ConnectionHealth.computeHealth(P2pSessionState.ACTIVE, now - 25000L, 600L, now)
        assertEquals(ConnectionHealth.DEGRADED, degraded)

        val unresponsive = ConnectionHealth.computeHealth(P2pSessionState.ACTIVE, now - 50000L, 0L, now)
        assertEquals(ConnectionHealth.UNRESPONSIVE, unresponsive)
    }

    // ==========================================
    // 5. Live TCP Loopback Bidirectional Messaging Tests
    // ==========================================

    @Test
    fun testBidirectionalReliableMessageExchangeOverRealTcp() = runBlocking {
        val idMgr1 = createTestIdentity("real_tcp_node_1")
        val idMgr2 = createTestIdentity("real_tcp_node_2")

        val repo1 = NetworkTransportRepository(
            context = context,
            identityManager = idMgr1,
            scope = testScope
        )

        val repo2 = NetworkTransportRepository(
            context = context,
            identityManager = idMgr2,
            scope = testScope
        )

        // Repo 1 starts listening on ephemeral port
        val port1 = repo1.startListening(0)
        assertTrue("Repo 1 port must be valid", port1 > 0)

        // Repo 2 connects to Repo 1
        val connectResult = repo2.connectToPeer(PeerEndpoint("127.0.0.1", port1))
        assertTrue("Connection must succeed: ${connectResult.exceptionOrNull()?.message}", connectResult.isSuccess)

        // Allow accept & handshake completion
        delay(400)

        val repo2Peers = repo2.authenticatedPeers.value
        assertEquals(1, repo2Peers.size)
        val session2Id = repo2Peers[0].connectionId

        // Prepare message listener on Repo 1
        var repo1ReceivedPayload: String? = null
        val receiveJob = testScope.launch {
            repo1.reliableMessagingService.incomingMessages.collect { (_, p2pMsg) ->
                repo1ReceivedPayload = p2pMsg.payload
            }
        }

        // Repo 2 sends reliable DATA message to Repo 1
        val testPayload = "{\"block_number\":1849220,\"miner\":\"NMD-POOL-01\"}"
        val sendResult = repo2.sendReliableP2pMessage(
            sessionId = session2Id,
            messageType = P2pMessageType.DATA,
            payload = testPayload
        )

        assertTrue("Reliable message send must succeed with ACK: ${sendResult.exceptionOrNull()?.message}", sendResult.isSuccess)
        val delivery = sendResult.getOrThrow()
        assertEquals(DeliveryStatus.ACKNOWLEDGED, delivery.status)
        assertTrue("RTT must be positive", delivery.roundTripLatencyMs >= 0L)

        // Poll for message receipt on Repo 1
        var received = false
        for (i in 1..25) {
            if (repo1ReceivedPayload != null) {
                received = true
                break
            }
            delay(100)
        }

        assertTrue("Repo 1 must receive message payload over TCP loopback", received)
        assertEquals(testPayload, repo1ReceivedPayload)

        receiveJob.cancel()
        repo1.close()
        repo2.close()
    }

    @Test
    fun testDuplicateMessageOverRealTcpReturnsAckWithoutDuplicateDelivery() = runBlocking {
        val idMgr1 = createTestIdentity("dup_tcp_node_1")
        val idMgr2 = createTestIdentity("dup_tcp_node_2")

        val repo1 = NetworkTransportRepository(context = context, identityManager = idMgr1, scope = testScope)
        val repo2 = NetworkTransportRepository(context = context, identityManager = idMgr2, scope = testScope)

        val port1 = repo1.startListening(0)
        val connectResult = repo2.connectToPeer(PeerEndpoint("127.0.0.1", port1))
        assertTrue("Connection must succeed", connectResult.isSuccess)
        delay(300)

        val repo2Peers = repo2.authenticatedPeers.value
        val session2Id = repo2Peers[0].connectionId

        var deliveryCount = 0
        val receiveJob = testScope.launch {
            repo1.reliableMessagingService.incomingMessages.collect {
                deliveryCount++
            }
        }

        val testPayload = "{\"unique_nonce\":98214}"
        // First delivery
        val res1 = repo2.sendReliableP2pMessage(session2Id, P2pMessageType.DATA, testPayload)
        assertTrue("First send must succeed", res1.isSuccess)

        delay(200)
        assertEquals("Exactly 1 delivery should have occurred", 1, deliveryCount)

        // Send same message payload again via raw frame with identical messageId
        val fixedMessageId = res1.getOrThrow().messageId
        val dupMessage = P2pMessage(
            messageId = fixedMessageId,
            senderPeerId = idMgr2.getActiveIdentity()!!.nodeId,
            recipientPeerId = idMgr1.getActiveIdentity()!!.nodeId,
            messageType = P2pMessageType.DATA,
            payload = testPayload
        )
        val json = dupMessage.toJson()
        repo2.connectionManager.sendRawFrame(session2Id, com.example.p2p.model.FrameType.RELIABLE_MSG, json.toByteArray(Charsets.UTF_8))

        delay(300)

        // Assert deliveryCount is STILL 1 (duplicate payload was suppressed)
        assertEquals("Duplicate message must NOT trigger second delivery callback", 1, deliveryCount)

        // But verify duplicate was recorded in message log with duplicate indicator
        val repo1Logs = repo1.reliableMessageHistory.value
        val duplicateRecord = repo1Logs.find { it.id == fixedMessageId && it.isDuplicate }
        assertNotNull("Duplicate message must be logged with isDuplicate = true", duplicateRecord)

        receiveJob.cancel()
        repo1.close()
        repo2.close()
    }

    // ==========================================
    // 6. Localization Parity Tests (Stage 6)
    // ==========================================

    @Test
    fun testStage6StringResourcesExistAcrossAllLanguages() {
        val stage6Keys = listOf(
            R.string.p2p_dashboard_title,
            R.string.p2p_active_sessions_stat,
            R.string.p2p_total_tx_stat,
            R.string.p2p_total_rx_stat,
            R.string.p2p_acked_stat,
            R.string.p2p_delivery_rate_stat,
            R.string.p2p_peer_details_title,
            R.string.p2p_session_outbound,
            R.string.p2p_session_inbound,
            R.string.p2p_field_node_id_label,
            R.string.p2p_field_endpoint_label,
            R.string.p2p_field_duration_label,
            R.string.p2p_delivery_metrics_title,
            R.string.p2p_composer_title,
            R.string.p2p_field_type_label,
            R.string.p2p_field_payload_label,
            R.string.p2p_action_send_reliable,
            R.string.p2p_action_ping,
            R.string.p2p_action_disconnect_peer,
            R.string.p2p_action_view_details,
            R.string.p2p_test_lab_title,
            R.string.p2p_test_lab_tag,
            R.string.p2p_test_lab_desc,
            R.string.p2p_test_lab_environment_notice,
            R.string.p2p_test_lab_target_label,
            R.string.p2p_test_lab_no_active_peer,
            R.string.p2p_test_lab_action_run,
            R.string.p2p_test_lab_running_status,
            R.string.p2p_test_lab_all_passed,
            R.string.p2p_reliable_log_title,
            R.string.p2p_no_reliable_messages_hint,
            R.string.p2p_badge_ack,
            R.string.p2p_badge_duplicate,
            R.string.p2p_badge_timeout,
            R.string.p2p_badge_failed
        )

        val locales = listOf(
            java.util.Locale.ENGLISH,
            java.util.Locale.forLanguageTag("ar"),
            java.util.Locale.FRENCH
        )

        for (locale in locales) {
            val config = android.content.res.Configuration(context.resources.configuration)
            config.setLocale(locale)
            val localizedContext = context.createConfigurationContext(config)
            val localizedResources = localizedContext.resources

            for (resId in stage6Keys) {
                val str = localizedResources.getString(resId)
                assertNotNull("Resource $resId must exist in locale $locale", str)
                assertTrue("Resource $resId in $locale must not be empty", str.isNotBlank())
            }
        }
    }
}
