package com.example

import android.content.Context
import android.content.res.Configuration
import androidx.test.core.app.ApplicationProvider
import com.example.data.DeviceResourceMonitor
import com.example.data.DeviceTelemetry
import com.example.data.NetworkTab
import com.example.data.NetworkTelemetry
import com.example.data.NodeConfiguration
import com.example.data.NodeManager
import com.example.data.NodePreferences
import com.example.data.NodeRole
import com.example.data.NodeStatus
import com.example.data.PeerConnectionState
import com.example.data.PeerInfo
import com.example.ui.screens.NetworkViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdNetworkStage3Test {

    private lateinit var context: Context
    private lateinit var viewModel: NetworkViewModel
    private lateinit var nodePrefs: NodePreferences
    private lateinit var nodeManager: NodeManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        nodePrefs = NodePreferences(context)
        // Reset SharedPreferences before each test
        context.getSharedPreferences(NodePreferences.PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
        context.getSharedPreferences("nmd_p2p_registry", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()

        nodeManager = NodeManager(nodePrefs)
        viewModel = NetworkViewModel(ApplicationProvider.getApplicationContext(), nodeManager)
    }

    // =========================================================================
    // 1. Node Roles Model & Specification Tests
    // =========================================================================

    @Test
    fun testFiveNodeRolesExistWithCompleteSpecifications() {
        assertEquals(5, NodeRole.entries.size)

        val roles = listOf(
            NodeRole.VALIDATOR,
            NodeRole.FULL_NODE,
            NodeRole.LIGHT_NODE,
            NodeRole.RELAY_NODE,
            NodeRole.STORAGE_NODE
        )

        for (role in roles) {
            assertTrue("Role $role must have positive titleRes", role.titleRes != 0)
            assertTrue("Role $role must have positive descRes", role.descRes != 0)
            assertTrue("Role $role must have positive responsibilitiesRes", role.responsibilitiesRes != 0)
            assertTrue("Role $role must have estimated RAM", role.estimatedRam.isNotBlank())
            assertTrue("Role $role must have estimated Storage", role.estimatedStorage.isNotBlank())
            assertTrue("Role $role must have estimated Battery", role.estimatedBattery.isNotBlank())
        }

        // Specific hardware check: Validator requires highest specs
        assertEquals("4 GB - 8 GB", NodeRole.VALIDATOR.estimatedRam)
        assertEquals("100 GB+ SSD", NodeRole.VALIDATOR.estimatedStorage)

        // Light node must be suitable for mobile
        assertEquals("256 MB - 512 MB", NodeRole.LIGHT_NODE.estimatedRam)
        assertEquals("Minimal (Mobile Optimized)", NodeRole.LIGHT_NODE.estimatedBattery)
    }

    // =========================================================================
    // 2. NodeManager Lifecycle & Activation Verification
    // =========================================================================

    @Test
    fun testNodeManagerRoleSelectionAndStatusTransitions() {
        // Initial state
        assertEquals(NodeRole.LIGHT_NODE, nodeManager.nodeConfig.value.selectedRole)
        assertEquals(NodeStatus.INACTIVE, nodeManager.nodeStatus.value)
        assertFalse(nodeManager.isValidatorRoleSelected())

        // Test all 5 roles selection
        val allRoles = NodeRole.entries
        for (role in allRoles) {
            val updated = nodeManager.selectRole(role)
            assertEquals(role, updated.selectedRole)
            assertEquals(role, nodeManager.nodeConfig.value.selectedRole)
        }

        // Validator check
        nodeManager.selectRole(NodeRole.VALIDATOR)
        assertTrue(nodeManager.isValidatorRoleSelected())

        // Activation into Demo Mode
        val activeConfig = nodeManager.setDemoActive(true)
        assertTrue(activeConfig.isDemoActive)
        assertEquals(NodeStatus.ACTIVE_DEMO, nodeManager.nodeStatus.value)

        // Deactivation
        val inactiveConfig = nodeManager.setDemoActive(false)
        assertFalse(inactiveConfig.isDemoActive)
        assertEquals(NodeStatus.INACTIVE, nodeManager.nodeStatus.value)
    }

    // =========================================================================
    // 3. Node Configuration Persistence (Survives Application Restart)
    // =========================================================================

    @Test
    fun testDefaultNodeConfiguration() {
        val defaultConfig = nodePrefs.loadConfiguration()
        assertEquals(NodeRole.LIGHT_NODE, defaultConfig.selectedRole)
        assertEquals(NodePreferences.DEFAULT_DISPLAY_NAME, defaultConfig.displayName)
        assertFalse(defaultConfig.isDemoActive)
        assertTrue(defaultConfig.autoSyncEnabled)
    }

    @Test
    fun testSaveAndReloadNodeConfigurationSurvivesRestart() {
        // Configure node before restart
        nodeManager.updateConfiguration(
            role = NodeRole.STORAGE_NODE,
            displayName = "Tokyo-Mobile-Storage-01",
            isDemoActive = true,
            autoSyncEnabled = false
        )

        // Simulate app termination and restart by instantiating fresh components from context
        val restartedPrefs = NodePreferences(context)
        val restartedNodeManager = NodeManager(restartedPrefs)

        val reloaded = restartedNodeManager.nodeConfig.value
        assertEquals(NodeRole.STORAGE_NODE, reloaded.selectedRole)
        assertEquals("Tokyo-Mobile-Storage-01", reloaded.displayName)
        assertTrue(reloaded.isDemoActive)
        assertFalse(reloaded.autoSyncEnabled)
        assertEquals(NodeStatus.ACTIVE_DEMO, restartedNodeManager.nodeStatus.value)
    }

    @Test
    fun testFakePeerConnectionsNeverRestoredAsLive() {
        // Ensure that SharedPreferences only stores local configuration keys,
        // and never attempts to serialize fake live network connections
        val sp = context.getSharedPreferences(NodePreferences.PREFS_NAME, Context.MODE_PRIVATE)
        val allKeys = sp.all.keys

        for (key in allKeys) {
            assertFalse("Peer sockets or live connections must never be persisted", key.contains("peer_live"))
            assertFalse("Blockchain consensus session must never be persisted", key.contains("consensus"))
        }

        // On restart, peers list starts empty until real P2P peers connect
        val restartedManager = NodeManager(context)
        val peers = restartedManager.peers.value
        assertTrue("Peers list must start empty with no fake fixtures", peers.isEmpty())
    }

    // =========================================================================
    // 4. NetworkViewModel Operations & Reactive State
    // =========================================================================

    @Test
    fun testViewModelTabNavigation() {
        assertEquals(NetworkTab.DASHBOARD, viewModel.currentTab.value)

        viewModel.setTab(NetworkTab.ROLES)
        assertEquals(NetworkTab.ROLES, viewModel.currentTab.value)

        viewModel.setTab(NetworkTab.PEERS)
        assertEquals(NetworkTab.PEERS, viewModel.currentTab.value)

        viewModel.setTab(NetworkTab.ACTIVITY)
        assertEquals(NetworkTab.ACTIVITY, viewModel.currentTab.value)

        viewModel.setTab(NetworkTab.DEVICE)
        assertEquals(NetworkTab.DEVICE, viewModel.currentTab.value)

        viewModel.setTab(NetworkTab.DASHBOARD)
        assertEquals(NetworkTab.DASHBOARD, viewModel.currentTab.value)
    }

    @Test
    fun testViewModelSaveConfigurationAndTimelineEvent() {
        val initialActivityCount = viewModel.networkActivities.value.size

        viewModel.saveNodeConfiguration(
            newRole = NodeRole.RELAY_NODE,
            newDisplayName = "Frankfurt-Relay-Demo",
            newDemoActive = true
        )

        val config = viewModel.nodeConfig.value
        assertEquals(NodeRole.RELAY_NODE, config.selectedRole)
        assertEquals("Frankfurt-Relay-Demo", config.displayName)
        assertTrue(config.isDemoActive)

        // Event should be appended to timeline
        val activities = viewModel.networkActivities.value
        assertEquals(initialActivityCount + 1, activities.size)
        val latestEvent = activities.first()
        assertFalse("Latest event must not be flagged as fake demo", latestEvent.isDemo)
        assertTrue("Event description must mention Frankfurt-Relay-Demo", latestEvent.description.contains("Frankfurt-Relay-Demo"))
    }

    @Test
    fun testViewModelDisplayNameBlankFallback() {
        viewModel.saveNodeConfiguration(
            newRole = NodeRole.FULL_NODE,
            newDisplayName = "   ",
            newDemoActive = true
        )

        // Should fall back to default
        assertEquals(NodePreferences.DEFAULT_DISPLAY_NAME, viewModel.nodeConfig.value.displayName)
    }

    @Test
    fun testViewModelToggleDemoNodeActive() {
        viewModel.toggleDemoNodeActive(true)
        assertTrue(viewModel.nodeConfig.value.isDemoActive)

        viewModel.toggleDemoNodeActive(false)
        assertFalse(viewModel.nodeConfig.value.isDemoActive)
    }

    // =========================================================================
    // 5. Peer Management: Live Updating, Filtering, and Search
    // =========================================================================

    @Test
    fun testPeersStartEmptyAndUpdateWithLivePeers() {
        val isolatedManager = NodeManager(nodePrefs)
        assertTrue("Peers must start empty with zero fake data", isolatedManager.peers.value.isEmpty())

        val sampleLive = listOf(
            PeerInfo("nmd-peer-01", "Zurich-Validator", NodeRole.VALIDATOR, PeerConnectionState.CONNECTED, 28, "2s", "10.0.0.1:19100"),
            PeerInfo("nmd-peer-02", "London-Validator", NodeRole.VALIDATOR, PeerConnectionState.CONNECTED, 35, "4s", "10.0.0.2:19100"),
            PeerInfo("nmd-peer-03", "Tokyo-Full", NodeRole.FULL_NODE, PeerConnectionState.SYNCING, 90, "1s", "Tokyo Relay"),
            PeerInfo("nmd-peer-04", "Frankfurt-Relay", NodeRole.RELAY_NODE, PeerConnectionState.IDLE, 42, "8s", "EU Central")
        )
        isolatedManager.updatePeers(sampleLive)
        val peers = isolatedManager.peers.value
        assertEquals(4, peers.size)
        assertTrue(peers.none { it.isDemo })
    }

    @Test
    fun testPeerFilteringByRole() {
        val isolatedManager = NodeManager(nodePrefs)
        isolatedManager.updatePeers(
            listOf(
                PeerInfo("p1", "V1", NodeRole.VALIDATOR, PeerConnectionState.CONNECTED, 20, "1s", "ZRH"),
                PeerInfo("p2", "V2", NodeRole.VALIDATOR, PeerConnectionState.CONNECTED, 25, "1s", "LON"),
                PeerInfo("p3", "F1", NodeRole.FULL_NODE, PeerConnectionState.SYNCING, 40, "2s", "NYC"),
                PeerInfo("p4", "F2", NodeRole.FULL_NODE, PeerConnectionState.CONNECTED, 45, "2s", "SGP"),
                PeerInfo("p5", "R1", NodeRole.RELAY_NODE, PeerConnectionState.IDLE, 50, "5s", "FRA"),
                PeerInfo("p6", "R2", NodeRole.RELAY_NODE, PeerConnectionState.IDLE, 55, "5s", "BER")
            )
        )
        val allPeers = isolatedManager.peers.value
        val validators = allPeers.filter { it.role == NodeRole.VALIDATOR }
        val fullNodes = allPeers.filter { it.role == NodeRole.FULL_NODE }
        val relays = allPeers.filter { it.role == NodeRole.RELAY_NODE }

        assertEquals(2, validators.size)
        assertEquals(2, fullNodes.size)
        assertEquals(2, relays.size)
    }

    @Test
    fun testPeerSearchFiltering() {
        val isolatedManager = NodeManager(nodePrefs)
        isolatedManager.updatePeers(
            listOf(
                PeerInfo("nmd-peer-nrt-04", "Tokyo-Full", NodeRole.FULL_NODE, PeerConnectionState.CONNECTED, 80, "1s", "Tokyo, JP"),
                PeerInfo("nmd-peer-lon-01", "London-Validator", NodeRole.VALIDATOR, PeerConnectionState.CONNECTED, 30, "1s", "London, UK")
            )
        )
        val allPeers = isolatedManager.peers.value

        val tokyoPeers = allPeers.filter { it.location.contains("Tokyo", ignoreCase = true) }
        assertEquals(1, tokyoPeers.size)
        assertEquals("nmd-peer-nrt-04", tokyoPeers.first().id)

        val londonPeers = allPeers.filter { it.name.contains("London", ignoreCase = true) }
        assertEquals(1, londonPeers.size)
        assertEquals(NodeRole.VALIDATOR, londonPeers.first().role)

        val none = allPeers.filter { it.name.contains("Mars", ignoreCase = true) }
        assertTrue(none.isEmpty())
    }

    // =========================================================================
    // 6. Strict Separation of Real Device Telemetry vs Live Chain Telemetry
    // =========================================================================

    @Test
    fun testStrictTelemetrySeparation() {
        val monitor = DeviceResourceMonitor(context)
        val deviceTelemetry = monitor.sampleDeviceTelemetry()
        val networkTelemetry = NetworkTelemetry()

        // Real device telemetry must be from Android system
        assertTrue("Available RAM string must not be empty", deviceTelemetry.availableRamFormatted.isNotBlank())
        assertTrue("Total RAM string must not be empty", deviceTelemetry.totalRamFormatted.isNotBlank())
        assertTrue("Battery status string must not be empty", deviceTelemetry.batteryStatusFormatted.isNotBlank())
        assertTrue("Network type string must not be empty", deviceTelemetry.networkType.isNotBlank())

        // Zero-initialized honest live telemetry (no hardcoded fake height 1,849,208)
        assertEquals(0L, networkTelemetry.blockHeight)
        assertEquals(0f, networkTelemetry.syncPercentage, 0.01f)
        assertEquals(0, networkTelemetry.connectedPeersCount)
        assertFalse(networkTelemetry.isDemo)
        assertEquals("Local Dev Chain (nmd-local-dev-1)", networkTelemetry.networkMode)

        assertEquals("#0", networkTelemetry.blockHeightFormatted)
        assertEquals("0.0%", networkTelemetry.syncPercentageFormatted)
    }

    @Test
    fun testDeviceTelemetryParameterizedFormatting() {
        val emptyTelemetry = DeviceTelemetry()

        assertEquals("Unavailable", emptyTelemetry.getAvailableRamFormatted("Unavailable"))
        assertEquals("غير متوفر", emptyTelemetry.getAvailableRamFormatted("غير متوفر"))
        assertEquals("Indisponible", emptyTelemetry.getAvailableRamFormatted("Indisponible"))

        assertEquals("Charging", DeviceTelemetry(isCharging = true).getBatteryStatusFormatted("Charging", "Discharging", "Unavailable"))
        assertEquals("قيد الشحن", DeviceTelemetry(isCharging = true).getBatteryStatusFormatted("قيد الشحن", "قيد الاستهلاك", "غير متوفر"))
        assertEquals("Décharge", DeviceTelemetry(isCharging = false).getBatteryStatusFormatted("En charge", "Décharge", "Indisponible"))
    }

    // =========================================================================
    // 7. Stage 3 Localization Audit Across English, French, and Arabic
    // =========================================================================

    private fun getLocalizedContext(locale: Locale): Context {
        val config = Configuration(context.resources.configuration).apply {
            setLocale(locale)
        }
        return context.createConfigurationContext(config)
    }

    @Test
    fun testStage3KeysExistInAllThreeLanguages() {
        val stage3Keys = listOf(
            R.string.tab_network_dashboard,
            R.string.tab_network_roles,
            R.string.tab_network_peers,
            R.string.tab_network_activity,
            R.string.tab_network_device,
            R.string.node_dashboard_title,
            R.string.node_dashboard_subtitle,
            R.string.node_mode_demo_tag,
            R.string.node_status_demo_label,
            R.string.node_status_inactive_label,
            R.string.node_btn_configure,
            R.string.node_config_dialog_title,
            R.string.node_display_name_title,
            R.string.node_display_name_hint,
            R.string.node_demo_mode_switch,
            R.string.node_demo_mode_desc,
            R.string.node_validator_warning_title,
            R.string.node_validator_warning_desc,
            R.string.node_save_config_btn,
            R.string.telemetry_device_title,
            R.string.telemetry_network_title,
            R.string.telemetry_demo_badge,
            R.string.telemetry_real_badge,
            R.string.telemetry_block_height,
            R.string.telemetry_sync_percent,
            R.string.telemetry_peers_count,
            R.string.telemetry_uptime,
            R.string.telemetry_last_sync,
            R.string.telemetry_refresh_action,
            R.string.telemetry_device_ram_avail,
            R.string.telemetry_device_ram_total,
            R.string.telemetry_device_app_ram,
            R.string.telemetry_device_battery_lvl,
            R.string.telemetry_device_battery_status,
            R.string.battery_charging,
            R.string.battery_discharging,
            R.string.telemetry_device_network_type,
            R.string.telemetry_unavailable,
            R.string.peers_search_hint,
            R.string.peers_all_roles,
            R.string.peers_empty_title,
            R.string.peers_demo_disclaimer,
            R.string.activity_demo_disclaimer,
            R.string.act_block_received,
            R.string.act_sync_updated,
            R.string.act_peer_connected,
            R.string.act_config_changed,
            R.string.role_validator_title,
            R.string.role_validator_desc,
            R.string.role_validator_resp,
            R.string.role_full_title,
            R.string.role_full_desc,
            R.string.role_full_resp,
            R.string.role_light_title,
            R.string.role_light_desc,
            R.string.role_light_resp,
            R.string.role_relay_title,
            R.string.role_relay_desc,
            R.string.role_relay_resp,
            R.string.role_storage_title,
            R.string.role_storage_desc,
            R.string.role_storage_resp
        )

        val targetLocales = listOf(
            Locale.ENGLISH to "English",
            Locale.FRENCH to "French",
            Locale.forLanguageTag("ar") to "Arabic"
        )

        for ((loc, langName) in targetLocales) {
            val locContext = getLocalizedContext(loc)
            for (resId in stage3Keys) {
                val value = locContext.getString(resId)
                assertNotNull("Resource key $resId must not be null in $langName", value)
                assertTrue("Resource key $resId must not be blank in $langName", value.isNotBlank())
            }
        }
    }

    @Test
    fun testStage3LanguageSpecificStrings() {
        val enCtx = getLocalizedContext(Locale.ENGLISH)
        val frCtx = getLocalizedContext(Locale.FRENCH)
        val arCtx = getLocalizedContext(Locale.forLanguageTag("ar"))

        assertEquals("SIMULATED TELEMETRY", enCtx.getString(R.string.telemetry_demo_badge))
        assertEquals("TÉLÉMÉTRIE SIMULÉE", frCtx.getString(R.string.telemetry_demo_badge))
        assertEquals("محاكاة تجريبية", arCtx.getString(R.string.telemetry_demo_badge))

        assertEquals("REAL DEVICE METRIC", enCtx.getString(R.string.telemetry_real_badge))
        assertEquals("MÉTRIQUE APPAREIL RÉEL", frCtx.getString(R.string.telemetry_real_badge))
        assertEquals("بيانات فعلية للجهاز", arCtx.getString(R.string.telemetry_real_badge))

        assertEquals("Local Demo / Test Environment", enCtx.getString(R.string.node_mode_demo_tag))
        assertEquals("Environnement Démo Local / Test", frCtx.getString(R.string.node_mode_demo_tag))
        assertEquals("بيئة تجريبية محلية / معاينة", arCtx.getString(R.string.node_mode_demo_tag))

        assertEquals("Charging", enCtx.getString(R.string.battery_charging))
        assertEquals("En charge", frCtx.getString(R.string.battery_charging))
        assertEquals("قيد الشحن", arCtx.getString(R.string.battery_charging))

        assertEquals("Discharging", enCtx.getString(R.string.battery_discharging))
        assertEquals("Décharge", frCtx.getString(R.string.battery_discharging))
        assertEquals("قيد الاستهلاك", arCtx.getString(R.string.battery_discharging))
    }
}
