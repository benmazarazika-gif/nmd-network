package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.config.BlockchainParameters
import com.example.blockchain.config.NmdGenesisConfigs
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.blockchain.validation.BlockValidator
import com.example.consensus.NmdConsensusCoordinatorRegistry
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.crypto.ConsensusCryptoSigner
import com.example.consensus.engine.ConsensusEngine
import com.example.consensus.engine.ConsensusEvent
import com.example.consensus.engine.LocalSignVoteResult
import com.example.consensus.engine.ProposalSubmissionResult
import com.example.consensus.engine.VoteSubmissionResult
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ValidatorAvailability
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorStatus
import com.example.consensus.model.VotePhase
import com.example.consensus.storage.RoomConsensusStorage
import com.example.consensus.validation.ConsensusValidators
import com.example.consensus.validator.ValidatorEligibilityRegistry
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.Ed25519KeyPairResult
import com.example.data.DeviceTelemetry
import com.example.production.NmdBlockProductionRegistry
import com.example.production.builder.BlockConstructor
import com.example.production.builder.CandidateBuildOutcome
import com.example.production.config.BlockProductionConfig
import com.example.production.engine.BlockProductionEngine
import com.example.production.model.BlockProductionAttemptResult
import com.example.production.model.ProductionErrorCode
import com.example.production.model.ProductionPhase
import com.example.production.model.ProposalSubmissionStatus
import com.example.production.scheduler.ValidatorSchedulingEngine
import com.example.production.selection.DeterministicTransactionSelector
import com.example.production.storage.RoomBlockProductionStorage
import com.example.transaction.NmdTransactionEngineRegistry
import com.example.transaction.blockchain.TransactionBlockBridge
import com.example.transaction.crypto.NmdAddressCodec
import com.example.transaction.crypto.TransactionSigner
import com.example.transaction.mempool.MempoolSubmissionResult
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionPropagationStatus
import com.example.transaction.model.TransactionType
import com.example.transaction.storage.RoomTransactionStorage
import com.example.transaction.validation.TransactionPolicyConfig
import com.example.transaction.validation.TransactionValidator
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Comprehensive Automated & Adversarial Verification Suite for Stage 11:
 * Block Production & Validator Scheduling.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdBlockProductionStage11Test {

    private lateinit var context: Context
    private val crypto = BouncyCastleEd25519Provider()
    private val signer = ConsensusCryptoSigner(crypto)
    private val txSigner = TransactionSigner(crypto)
    private val blockHasher = BlockHasher(crypto)
    private val blockchainConfig = BlockchainConfig()
    private val consensusConfig = ConsensusConfig()

    private val testDbs = listOf(
        "s11_restart_chain.db",
        "s11_restart_tx.db",
        "s11_restart_consensus.db",
        "s11_restart_production.db"
    )

    private data class TestValidatorNode(
        val name: String,
        val keyPair: Ed25519KeyPairResult,
        val validatorId: String,
        val publicKeyHex: String,
        val info: ValidatorInfo
    )

    private class ValidatorStack(
        val node: TestValidatorNode,
        val blockchainManager: BlockchainManager,
        val txMempool: TransactionMempool,
        val txBlockBridge: TransactionBlockBridge,
        val consensusEngine: ConsensusEngine,
        val productionEngine: BlockProductionEngine
    ) : java.io.Closeable {
        override fun close() {
            productionEngine.close()
            consensusEngine.close()
            txMempool.close()
            blockchainManager.close()
        }
    }

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        NmdBlockProductionRegistry.resetForTests()
        NmdConsensusCoordinatorRegistry.resetForTests()
        NmdTransactionEngineRegistry.resetForTests()
        cleanupArtifacts()
    }

    @After
    fun tearDown() {
        NmdBlockProductionRegistry.resetForTests()
        NmdConsensusCoordinatorRegistry.resetForTests()
        NmdTransactionEngineRegistry.resetForTests()
        cleanupArtifacts()
    }

    private fun cleanupArtifacts() {
        testDbs.forEach { context.deleteDatabase(it) }
    }

    private fun baseTimeNow(): Long = maxOf(System.currentTimeMillis(), NmdGenesisConfigs.LOCAL_DEV_TIMESTAMP_MS + 120_000L)

    private fun healthyTelemetry() = DeviceTelemetry(
        availableRamMb = 2048L,
        totalRamMb = 4096L,
        appRamMb = 96L,
        batteryPercent = 85,
        isCharging = true,
        networkType = "Wi-Fi",
        isLowRam = false
    )

    private fun createValidators(count: Int, registeredAtMs: Long = baseTimeNow()): List<TestValidatorNode> {
        return (0 until count).map { idx ->
            val kp = crypto.generateEd25519KeyPair()
            val pubHex = crypto.toHex(kp.publicKeyBytes).lowercase()
            val valId = signer.deriveValidatorId(kp.publicKeyBytes)
            TestValidatorNode(
                name = "Validator-${idx + 1}",
                keyPair = kp,
                validatorId = valId,
                publicKeyHex = pubHex,
                info = ValidatorInfo(
                    validatorId = valId,
                    nodeId = crypto.deriveNodeId(kp.publicKeyBytes),
                    publicKeyHex = pubHex,
                    displayName = "Validator-${idx + 1}",
                    votingPower = 1L,
                    status = ValidatorStatus.ACTIVE,
                    registeredAtMs = registeredAtMs
                )
            )
        }.sortedBy { it.validatorId }
    }

    private suspend fun buildStack(
        node: TestValidatorNode,
        allValidators: List<ValidatorInfo>,
        prodConfig: BlockProductionConfig = BlockProductionConfig(minBlockIntervalMs = 0L),
        chainConfig: BlockchainConfig = blockchainConfig,
        inMemory: Boolean = true,
        prefix: String = "mem",
        nowMs: Long = baseTimeNow()
    ): ValidatorStack {
        val bc = BlockchainManager(
            context = context,
            config = chainConfig.copy(databaseName = "${prefix}_chain.db"),
            inMemoryStorage = inMemory
        )
        bc.initialize()

        val txStorage = RoomTransactionStorage(
            context = context,
            dbName = "${prefix}_tx.db",
            inMemory = inMemory
        )
        val txValidator = TransactionValidator(chainConfig)
        val mempool = TransactionMempool(txStorage, txValidator)
        mempool.initialize(nowMs)
        val bridge = TransactionBlockBridge(mempool, bc)

        val consStorage = RoomConsensusStorage(
            context = context,
            dbName = "${prefix}_consensus.db",
            inMemory = inMemory
        )
        val consRegistry = ValidatorEligibilityRegistry(consensusConfig)
        val consValidators = ConsensusValidators(consensusConfig, signer, BlockValidator(chainConfig, bc.blockHasher))
        val consEngine = ConsensusEngine(
            config = consensusConfig,
            storage = consStorage,
            registry = consRegistry,
            signer = signer,
            validators = consValidators,
            blockchainManager = bc,
            txBlockBridge = bridge
        )
        consEngine.initialize(
            initialValidators = allValidators,
            localDevicePublicKeyHex = node.publicKeyHex,
            nowMs = nowMs
        )

        val prodStorage = RoomBlockProductionStorage(
            context = context,
            dbName = "${prefix}_production.db",
            inMemory = inMemory
        )
        val prodEngine = BlockProductionEngine(
            config = prodConfig,
            storage = prodStorage,
            blockchainManager = bc,
            txMempool = mempool,
            txBlockBridge = bridge,
            consensusEngine = consEngine
        )
        prodEngine.initialize(
            localPublicKeyHex = node.publicKeyHex,
            telemetry = healthyTelemetry(),
            thermalSevere = false,
            nowMs = nowMs
        )

        return ValidatorStack(node, bc, mempool, bridge, consEngine, prodEngine)
    }

    private fun buildSignedTransferTx(
        senderKp: Ed25519KeyPairResult,
        recipientPub: ByteArray = crypto.generateEd25519KeyPair().publicKeyBytes,
        amountUnits: Long = 500_000L,
        feeUnits: Long = 20_000L,
        nonce: Long = 0L,
        timestampMs: Long = baseTimeNow(),
        memo: String = "tx-n$nonce"
    ): NmdTransaction {
        val recipientAddr = NmdAddressCodec.deriveAddressFromPublicKey(recipientPub, crypto)
        val unsigned = NmdTransaction(
            chainId = blockchainConfig.chainId,
            protocolVersion = blockchainConfig.parameters.protocolVersion,
            senderAddress = "",
            recipientAddress = recipientAddr,
            amountUnits = amountUnits,
            feeUnits = feeUnits,
            nonce = nonce,
            timestamp = timestampMs,
            txType = TransactionType.TRANSFER,
            senderPublicKeyHex = "",
            payload = memo.toByteArray(Charsets.UTF_8)
        )
        return txSigner.signWithKeyPair(unsigned, senderKp.privateKeyBytes)
    }

    @Test
    fun deterministicScheduling_rotatesHeightsAndRounds_andIgnoresLocalMobilePause() = runBlocking {
        val now = baseTimeNow()
        val validators = createValidators(4, now)
        val registry = ValidatorEligibilityRegistry(consensusConfig).apply {
            loadRestoredValidators(validators.map { it.info })
        }
        val scheduler = ValidatorSchedulingEngine(registry)

        // Pause local availability on validator[1] -> MUST NOT alter deterministic schedule across nodes!
        registry.updateAvailability(validators[1].validatorId, ValidatorAvailability.LOW_BATTERY_PAUSED, now)
        val snapshot = registry.buildSnapshot(1L)

        val h1r0 = scheduler.computeSchedule(1L, 0, validators[1].validatorId, snapshot)
        val h1r1 = scheduler.computeSchedule(1L, 1, validators[1].validatorId, snapshot)
        val h2r0 = scheduler.computeSchedule(2L, 0, validators[1].validatorId, snapshot)

        assertEquals(validators[1].validatorId, h1r0.scheduledProposerId)
        assertTrue(h1r0.isLocalValidatorScheduled)
        assertEquals(validators[2].validatorId, h1r0.nextRoundProposerId)
        assertEquals(validators[2].validatorId, h1r0.nextHeightProposerId)
        assertEquals(validators[2].validatorId, h1r1.scheduledProposerId)
        assertEquals(validators[2].validatorId, h2r0.scheduledProposerId)
        assertTrue(scheduler.isScheduledProposerUnavailable(1L, 0, snapshot))
        assertFalse(scheduler.isScheduledProposerUnavailable(1L, 1, snapshot))
    }

    @Test
    fun unauthorizedOrWrongSlotProposer_isRejectedOrSkipped() = runBlocking {
        val now = baseTimeNow()
        val validators = createValidators(4, now)
        val allInfos = validators.map { it.info }
        // Height 1 round 0 proposer is validators[1]
        val wrongNode = validators[0]
        val outsiderKp = crypto.generateEd25519KeyPair()

        val stack = buildStack(wrongNode, allInfos, nowMs = now)
        try {
            // Wrong scheduled slot attempt
            val wrongSlotRes = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = wrongNode.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now
            )
            assertTrue(wrongSlotRes is BlockProductionAttemptResult.Skipped)
            assertEquals(
                ProductionErrorCode.NOT_SCHEDULED_PROPOSER,
                (wrongSlotRes as BlockProductionAttemptResult.Skipped).code
            )

            // Unregistered outsider validator attempt
            val unauthorizedRes = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = outsiderKp.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now
            )
            assertTrue(unauthorizedRes is BlockProductionAttemptResult.Rejected)
            assertEquals(
                ProductionErrorCode.UNAUTHORIZED_VALIDATOR,
                (unauthorizedRes as BlockProductionAttemptResult.Rejected).code
            )

            // Chain MUST remain at height 0 (genesis)
            assertEquals(0L, stack.blockchainManager.getCurrentHeight())
        } finally {
            stack.close()
        }
    }

    @Test
    fun deterministicTransactionSelection_ordersFeesTimestampsNoncesAndDeduplicatesConflicts() {
        val now = baseTimeNow()
        val senderA = crypto.generateEd25519KeyPair()
        val senderB = crypto.generateEd25519KeyPair()
        val recipient = crypto.generateEd25519KeyPair().publicKeyBytes

        val aNonce0Low = buildSignedTransferTx(senderA, recipient, feeUnits = 15_000L, nonce = 0L, timestampMs = now - 5_000L, memo = "a0-low")
        val aNonce0High = buildSignedTransferTx(senderA, recipient, feeUnits = 50_000L, nonce = 0L, timestampMs = now - 4_000L, memo = "a0-high")
        val aNonce1 = buildSignedTransferTx(senderA, recipient, feeUnits = 80_000L, nonce = 1L, timestampMs = now - 3_000L, memo = "a1")
        // Gap tx nonce 3 (nonce 2 missing) MUST NOT be included!
        val aNonce3Gap = buildSignedTransferTx(senderA, recipient, feeUnits = 99_000L, nonce = 3L, timestampMs = now - 2_000L, memo = "a3-gap")
        val bNonce0 = buildSignedTransferTx(senderB, recipient, feeUnits = 60_000L, nonce = 0L, timestampMs = now - 4_500L, memo = "b0")
        // Expired tx MUST be filtered out at assembly time
        val senderExpired = crypto.generateEd25519KeyPair()
        val expiredTx = buildSignedTransferTx(
            senderExpired,
            recipient,
            feeUnits = 90_000L,
            nonce = 0L,
            timestampMs = now - 48L * 60L * 60L * 1000L,
            memo = "expired"
        )

        fun toRec(tx: NmdTransaction) = MempoolTransactionRecord(
            transaction = tx,
            status = MempoolTxStatus.VALIDATED,
            propagationStatus = TransactionPropagationStatus.LOCAL_ONLY,
            createdAtMs = now,
            updatedAtMs = now,
            expiresAtMs = tx.timestamp + TransactionPolicyConfig().maxTransactionAgeMs
        )

        val recordsOrder1 = listOf(aNonce0Low, aNonce0High, aNonce0High, aNonce1, aNonce3Gap, bNonce0, expiredTx).map(::toRec)
        val recordsOrder2 = recordsOrder1.reversed()

        val selector = DeterministicTransactionSelector(
            config = BlockProductionConfig(maxTransactionsPerBlock = 20, maxBlockSizeBytes = 64_000),
            validator = TransactionValidator(blockchainConfig),
            blockHasher = blockHasher
        )

        val res1 = selector.selectFromRecords(recordsOrder1, emptyMap(), 1L, "a".repeat(64), "val_1", now)
        val res2 = selector.selectFromRecords(recordsOrder2, emptyMap(), 1L, "a".repeat(64), "val_1", now)

        assertEquals(res1.selectedTransactions.map { it.txId }, res2.selectedTransactions.map { it.txId })

        // Expected deterministic order:
        // Frontier starts with {aNonce0High (fee 50k), bNonce0 (fee 60k)} -> b0 first, then a0High pops -> exposes aNonce1 (fee 80k)
        assertEquals(listOf(bNonce0.txId, aNonce0High.txId, aNonce1.txId), res1.selectedTransactions.map { it.txId })
        assertTrue(res1.rejectedTxIds.contains(aNonce0Low.txId.lowercase()))
        assertTrue(res1.rejectedTxIds.contains(expiredTx.txId.lowercase()))
        assertTrue(res1.skippedDueToNonceGapTxIds.contains(aNonce3Gap.txId.lowercase()))
    }

    @Test
    fun deterministicTransactionSelection_enforcesBlockSizeAndTxCountLimits() {
        val now = baseTimeNow()
        val recipient = crypto.generateEd25519KeyPair().publicKeyBytes
        val sender = crypto.generateEd25519KeyPair()

        val txs = (0 until 5).map { idx ->
            buildSignedTransferTx(
                sender,
                recipient,
                feeUnits = 20_000L,
                nonce = idx.toLong(),
                timestampMs = now + idx,
                memo = "tx-$idx"
            )
        }
        val records = txs.map {
            MempoolTransactionRecord(
                transaction = it,
                status = MempoolTxStatus.VALIDATED,
                propagationStatus = TransactionPropagationStatus.LOCAL_ONLY,
                createdAtMs = now,
                updatedAtMs = now,
                expiresAtMs = now + 3_600_000L
            )
        }

        // 1. Limit by maxTransactionsPerBlock = 2
        val countLimited = DeterministicTransactionSelector(
            config = BlockProductionConfig(maxTransactionsPerBlock = 2, maxBlockSizeBytes = 100_000),
            validator = TransactionValidator(blockchainConfig),
            blockHasher = blockHasher
        ).selectFromRecords(records, emptyMap(), 1L, "a".repeat(64), "val_1", now)
        assertEquals(2, countLimited.selectedTransactions.size)
        assertEquals(listOf(0L, 1L), countLimited.selectedTransactions.map { it.nonce })

        // 2. Limit by maxBlockSizeBytes tight cap -> rejects oversized candidate addition
        val sizeLimited = DeterministicTransactionSelector(
            config = BlockProductionConfig(maxTransactionsPerBlock = 10, maxBlockSizeBytes = 550),
            validator = TransactionValidator(blockchainConfig),
            blockHasher = blockHasher
        ).selectFromRecords(records, emptyMap(), 1L, "a".repeat(64), "val_1", now)
        assertTrue(sizeLimited.selectedTransactions.size < 5)
        assertTrue(sizeLimited.estimatedBlockSizeBytes <= 550)
    }

    @Test
    fun candidateBlockConstruction_rejectsInvalidOrOversizedAndPreservesStage8Hashes() = runBlocking {
        val now = baseTimeNow()
        val bc = BlockchainManager(context, blockchainConfig, inMemoryStorage = true)
        bc.initialize()
        try {
            val genesis = bc.getGenesisBlock()!!
            val sender = crypto.generateEd25519KeyPair()
            val tx = buildSignedTransferTx(sender, timestampMs = now)

            val tightConfig = BlockProductionConfig(maxBlockSizeBytes = 120)
            val tightConstructor = BlockConstructor(
                config = tightConfig,
                blockHasher = bc.blockHasher,
                blockValidator = BlockValidator(blockchainConfig, bc.blockHasher)
            )
            val oversizedRes = tightConstructor.buildCandidateBlock(
                parentBlock = genesis,
                targetHeight = 1L,
                round = 0,
                proposerId = "nmdval_test",
                selectedTransactions = listOf(tx),
                nowMs = now
            )
            assertTrue(oversizedRes is CandidateBuildOutcome.Rejected)

            // Valid constructor matches deterministic Stage 8 hash identically on independent constructor
            val validConfig = BlockProductionConfig()
            val c1 = BlockConstructor(validConfig, bc.blockHasher, BlockValidator(blockchainConfig, bc.blockHasher))
                .buildCandidateBlock(genesis, 1L, 0, "nmdval_test", listOf(tx), nowMs = now) as CandidateBuildOutcome.Built
            val c2 = BlockConstructor(validConfig, bc.blockHasher, BlockValidator(blockchainConfig, bc.blockHasher))
                .buildCandidateBlock(genesis, 1L, 0, "nmdval_test", listOf(tx), nowMs = now) as CandidateBuildOutcome.Built

            assertEquals(c1.candidate.block.header.merkleRoot, c2.candidate.block.header.merkleRoot)
            assertEquals(c1.candidate.block.hash, c2.candidate.block.hash)
        } finally {
            bc.close()
        }
    }

    @Test
    fun proposalReplayProtection_andConsensusNonBypassEnforcement() = runBlocking {
        val now = baseTimeNow()
        val validators = createValidators(4, now)
        val allInfos = validators.map { it.info }
        // Height 1 round 0 scheduled proposer is validators[1]
        val proposer = validators[1]
        val stack = buildStack(proposer, allInfos, nowMs = now)
        try {
            val sender = crypto.generateEd25519KeyPair()
            val tx = buildSignedTransferTx(sender, timestampMs = now)
            val submitTx = stack.txMempool.submitTransaction(tx, nowMs = now)
            assertTrue(submitTx is MempoolSubmissionResult.Accepted)

            // Produce and submit proposal for (height=1, round=0)
            val res1 = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = proposer.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now
            )
            assertTrue(res1 is BlockProductionAttemptResult.Proposed)
            val proposed = res1 as BlockProductionAttemptResult.Proposed

            // Verify Ed25519 signature & tamper detection
            assertTrue(signer.verifyProposalSignature(proposed.signedProposal))
            val tampered = proposed.signedProposal.copy(proposedBlockHash = "f".repeat(64))
            assertFalse(signer.verifyProposalSignature(tampered))

            // Duplicate proposal replay in SAME (height=1, round=0) MUST be blocked!
            val replayRes = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = proposer.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now + 5000L
            )
            assertTrue(replayRes is BlockProductionAttemptResult.Skipped)
            assertEquals(
                ProductionErrorCode.PROPOSAL_ALREADY_SUBMITTED_FOR_SLOT,
                (replayRes as BlockProductionAttemptResult.Skipped).code
            )

            // CRITICAL NON-BYPASS CHECK:
            // Even after proposal + ONLY 2 PREVOTES (<3 quorum), block MUST NOT be committed in Stage 8
            // and transaction MUST NOT be confirmed in Stage 9!
            val v0Vote = (stack.consensusEngine.signLocalVote(
                VotePhase.PREVOTE,
                proposed.candidateBlock.hash,
                privateKeyBytesForTest = validators[0].keyPair.privateKeyBytes,
                nowMs = now
            ) as LocalSignVoteResult.Signed).vote
            val v1Vote = (stack.consensusEngine.signLocalVote(
                VotePhase.PREVOTE,
                proposed.candidateBlock.hash,
                privateKeyBytesForTest = validators[1].keyPair.privateKeyBytes,
                nowMs = now
            ) as LocalSignVoteResult.Signed).vote
            stack.consensusEngine.submitVote(v0Vote, now)
            stack.consensusEngine.submitVote(v1Vote, now)

            assertEquals(0L, stack.blockchainManager.getCurrentHeight())
            assertNull(stack.blockchainManager.getBlockByHeight(1L))
            val mempoolTx = stack.txMempool.getByTxId(tx.txId)
            assertNotNull(mempoolTx)
            assertEquals(MempoolTxStatus.VALIDATED, mempoolTx!!.status)
            assertEquals(ProductionPhase.PROPOSED_AWAITING_CONSENSUS, stack.productionEngine.state.value.phase)
        } finally {
            stack.close()
        }
    }

    @Test
    fun fullMultiValidatorBftFinalization_commitsStage8ConfirmsStage9AndRotatesHeight() = runBlocking {
        val now = baseTimeNow()
        val validators = createValidators(4, now)
        val allInfos = validators.map { it.info }
        val stacks = validators.map { buildStack(it, allInfos, nowMs = now) }
        try {
            // Prepare & validate the same transaction in all 4 validators' mempools
            val walletSender = crypto.generateEd25519KeyPair()
            val walletAddr = NmdAddressCodec.deriveAddressFromPublicKey(walletSender.publicKeyBytes, crypto)
            val tx1 = buildSignedTransferTx(walletSender, nonce = 0L, feeUnits = 25_000L, timestampMs = now, memo = "block-1-tx")
            stacks.forEach { s ->
                assertTrue(s.txMempool.submitTransaction(tx1, nowMs = now) is MempoolSubmissionResult.Accepted)
            }

            // Height 1, Round 0: deterministic proposer is validators[1]
            val proposer1Stack = stacks[1]
            val attempt1 = proposer1Stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = proposer1Stack.node.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now + 100L
            ) as BlockProductionAttemptResult.Proposed

            // Deliver BlockProposal to all peer consensus engines & emit event tracking
            proposer1Stack.productionEngine.handleConsensusEvent(
                ConsensusEvent.ProposalAccepted(1L, 0, attempt1.candidateBlock.hash, proposer1Stack.node.validatorId),
                now + 100L
            )
            stacks.filter { it !== proposer1Stack }.forEach { peer ->
                val sub = peer.consensusEngine.submitProposal(attempt1.signedProposal, now + 150L)
                assertTrue(sub is ProposalSubmissionResult.Accepted)
                peer.productionEngine.handleConsensusEvent(
                    ConsensusEvent.ProposalAccepted(1L, 0, attempt1.candidateBlock.hash, proposer1Stack.node.validatorId),
                    now + 150L
                )
            }

            // Round of PREVOTEs from all 4 validators delivered to all 4 consensus engines
            val prevotes = stacks.map { s ->
                (s.consensusEngine.signLocalVote(
                    VotePhase.PREVOTE,
                    attempt1.candidateBlock.hash,
                    privateKeyBytesForTest = s.node.keyPair.privateKeyBytes,
                    nowMs = now + 200L
                ) as LocalSignVoteResult.Signed).vote
            }
            for (s in stacks) {
                for (pv in prevotes) {
                    s.consensusEngine.submitVote(pv, now + 250L)
                }
            }

            // Round of PRECOMMITs from all 4 validators -> BFT CommitCertificate finality!
            val precommits = stacks.map { s ->
                (s.consensusEngine.signLocalVote(
                    VotePhase.PRECOMMIT,
                    attempt1.candidateBlock.hash,
                    privateKeyBytesForTest = s.node.keyPair.privateKeyBytes,
                    nowMs = now + 300L
                ) as LocalSignVoteResult.Signed).vote
            }

            var certOnNode0: CommitCertificate? = null
            for (s in stacks) {
                for (pc in precommits) {
                    val vRes = s.consensusEngine.submitVote(pc, now + 350L)
                    if (vRes is VoteSubmissionResult.Accepted && vRes.commitCertificate != null) {
                        val cert = vRes.commitCertificate!!
                        if (s === stacks[0]) certOnNode0 = cert
                        s.productionEngine.handleConsensusEvent(ConsensusEvent.BlockFinalized(cert), now + 400L)
                    }
                }
            }
            assertNotNull(certOnNode0)

            // Assert ALL 4 independent nodes converged on identical Stage 8 Block 1, Stage 9 CONFIRMED tx1,
            // cleared active pending pool, advanced confirmedNextNonce -> 1, and rotated scheduled proposer to validators[2]!
            for (s in stacks) {
                val block1 = s.blockchainManager.getBlockByHeight(1L)
                assertNotNull(block1)
                assertEquals(attempt1.candidateBlock.hash, block1!!.hash)
                assertEquals(1, block1.header.transactionCount)
                assertEquals(tx1.txId, block1.body.transactionRefs.first().txHash)

                val txRecord = s.txMempool.getByTxId(tx1.txId)
                assertNotNull(txRecord)
                assertEquals(MempoolTxStatus.CONFIRMED, txRecord!!.status)
                assertEquals(1L, txRecord.confirmedBlockHeight)
                assertEquals(0, s.txMempool.stats.value.activeValidOrQueuedCount)
                assertEquals(1L, s.txMempool.getConfirmedNextNonce(walletAddr))

                val pState = s.productionEngine.state.value
                assertEquals(ProductionPhase.FINALIZED, pState.phase)
                assertEquals(1L, pState.latestFinalizedBlockHeight)
                assertEquals(2L, pState.currentProductionHeight)
                assertEquals(0, pState.currentRound)
                assertEquals(validators[2].validatorId, pState.scheduledProposerId)
            }

            // Height 2, Round 0: deterministic proposer rotated cleanly to stacks[2]!
            val attempt2 = stacks[2].productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = stacks[2].node.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now + 500L
            )
            assertTrue(attempt2 is BlockProductionAttemptResult.Proposed)
            val proposed2 = attempt2 as BlockProductionAttemptResult.Proposed
            assertEquals(2L, proposed2.height)
            assertEquals(attempt1.candidateBlock.hash, proposed2.candidateBlock.previousHash)
        } finally {
            stacks.forEach { it.close() }
        }
    }

    @Test
    fun timeoutAndMissedProposal_rotatesToNextRoundProposerAndFinalizes() = runBlocking {
        val now = baseTimeNow()
        val validators = createValidators(4, now)
        val allInfos = validators.map { it.info }
        // Height 1 Round 0 proposer is validators[1] (simulating offline), Round 1 proposer is validators[2]
        val round1Node = validators[2]
        val stack = buildStack(round1Node, allInfos, nowMs = now)
        try {
            assertEquals(validators[1].validatorId, stack.productionEngine.state.value.scheduledProposerId)

            // Trigger BFT timeout on ConsensusEngine + notify Stage 11 ProductionEngine
            val newRound = stack.consensusEngine.forceTimeoutAndAdvanceRound("Round 0 proposer offline", now + 10_000L)
            assertEquals(1, newRound)
            val rotState = stack.productionEngine.handleConsensusEvent(
                ConsensusEvent.RoundTimedOut(1L, 0, 1, validators[2].validatorId),
                now + 10_000L
            )
            assertEquals(1L, rotState.missedProposalCount)
            assertEquals(1, rotState.currentRound)
            assertEquals(round1Node.validatorId, rotState.scheduledProposerId)
            assertTrue(rotState.localValidatorEligible)

            // Now validators[2] proposes validly in (height=1, round=1)
            val res = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = round1Node.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now + 10_100L
            )
            assertTrue(res is BlockProductionAttemptResult.Proposed)
            val proposed = res as BlockProductionAttemptResult.Proposed
            assertEquals(1, proposed.round)

            // 3 validators PREVOTE + PRECOMMIT -> finality on round 1
            for (vIdx in listOf(0, 2, 3)) {
                val pv = (stack.consensusEngine.signLocalVote(
                    VotePhase.PREVOTE,
                    proposed.candidateBlock.hash,
                    privateKeyBytesForTest = validators[vIdx].keyPair.privateKeyBytes,
                    round = 1,
                    nowMs = now + 10_200L
                ) as LocalSignVoteResult.Signed).vote
                stack.consensusEngine.submitVote(pv, now + 10_250L)
            }
            var cert: CommitCertificate? = null
            for (vIdx in listOf(0, 2, 3)) {
                val pc = (stack.consensusEngine.signLocalVote(
                    VotePhase.PRECOMMIT,
                    proposed.candidateBlock.hash,
                    privateKeyBytesForTest = validators[vIdx].keyPair.privateKeyBytes,
                    round = 1,
                    nowMs = now + 10_300L
                ) as LocalSignVoteResult.Signed).vote
                val submitRes = stack.consensusEngine.submitVote(pc, now + 10_350L)
                if (submitRes is VoteSubmissionResult.Accepted && submitRes.commitCertificate != null) {
                    cert = submitRes.commitCertificate
                }
            }
            assertNotNull(cert)
            val finState = stack.productionEngine.handleConsensusEvent(ConsensusEvent.BlockFinalized(cert!!), now + 10_400L)
            assertEquals(1L, finState.latestFinalizedBlockHeight)
            assertEquals(1L, stack.blockchainManager.getCurrentHeight())
        } finally {
            stack.close()
        }
    }

    @Test
    fun mobileResourceGuards_andEmptyBlockPolicy_workAndRecoverCleanly() = runBlocking {
        val now = baseTimeNow()
        val validators = createValidators(4, now)
        val proposer = validators[1]
        val stack = buildStack(
            proposer,
            validators.map { it.info },
            prodConfig = BlockProductionConfig(minBlockIntervalMs = 0L, produceEmptyBlocks = false),
            nowMs = now
        )
        try {
            // 1. Thermal severe pauses local production cleanly
            val thermalRes = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = proposer.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                thermalSevere = true,
                nowMs = now
            )
            assertEquals(
                ProductionErrorCode.MOBILE_RESOURCE_PAUSED,
                (thermalRes as BlockProductionAttemptResult.Skipped).code
            )
            assertEquals(ProductionPhase.PAUSED_MOBILE_RESOURCE, stack.productionEngine.state.value.phase)

            // 2. Low uncharging battery pauses cleanly
            val lowBatTelemetry = healthyTelemetry().copy(batteryPercent = 10, isCharging = false)
            val batteryRes = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = proposer.keyPair.privateKeyBytes,
                telemetry = lowBatTelemetry,
                thermalSevere = false,
                nowMs = now
            )
            assertEquals(
                ProductionErrorCode.MOBILE_RESOURCE_PAUSED,
                (batteryRes as BlockProductionAttemptResult.Skipped).code
            )

            // 3. Recovery to healthy telemetry -> empty mempool with produceEmptyBlocks=false returns NO_PENDING_TRANSACTIONS
            val emptyRes = stack.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = proposer.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                thermalSevere = false,
                nowMs = now + 100L
            )
            assertEquals(
                ProductionErrorCode.NO_PENDING_TRANSACTIONS,
                (emptyRes as BlockProductionAttemptResult.Skipped).code
            )

            // 4. Separate engine with produceEmptyBlocks=true produces deterministic valid empty block
            val emptyOkStack = buildStack(
                proposer,
                validators.map { it.info },
                prodConfig = BlockProductionConfig(minBlockIntervalMs = 0L, produceEmptyBlocks = true),
                nowMs = now
            )
            try {
                val emptyBuilt = emptyOkStack.productionEngine.tryProduceAndProposeBlock(
                    privateKeyBytesForTest = proposer.keyPair.privateKeyBytes,
                    telemetry = healthyTelemetry(),
                    nowMs = now + 100L
                )
                assertTrue(emptyBuilt is BlockProductionAttemptResult.Proposed)
                assertEquals(0, (emptyBuilt as BlockProductionAttemptResult.Proposed).includedTxCount)
            } finally {
                emptyOkStack.close()
            }
        } finally {
            stack.close()
        }
    }

    @Test
    fun appRestartRecovery_restoresCheckpointConfirmedNoncesAndPreventsSlotReplay() = runBlocking {
        val now = baseTimeNow()
        val validators = createValidators(4, now)
        val allInfos = validators.map { it.info }
        val height1Proposer = validators[1]
        val height2Proposer = validators[2]
        val walletKp = crypto.generateEd25519KeyPair()
        val walletAddr = NmdAddressCodec.deriveAddressFromPublicKey(walletKp.publicKeyBytes, crypto)
        val tx1 = buildSignedTransferTx(walletKp, nonce = 0L, timestampMs = now)

        // Session 1: persistent Room DBs -> finalize Block 1 and propose Block 2 before simulated process death
        val s1 = buildStack(
            height1Proposer,
            allInfos,
            inMemory = false,
            prefix = "s11_restart",
            nowMs = now
        )
        val block1Hash: String
        try {
            assertTrue(s1.txMempool.submitTransaction(tx1, nowMs = now) is MempoolSubmissionResult.Accepted)
            val p1 = s1.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = height1Proposer.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now + 100L
            ) as BlockProductionAttemptResult.Proposed
            block1Hash = p1.candidateBlock.hash

            for (vIdx in listOf(0, 1, 2)) {
                val pv = (s1.consensusEngine.signLocalVote(
                    VotePhase.PREVOTE,
                    block1Hash,
                    privateKeyBytesForTest = validators[vIdx].keyPair.privateKeyBytes,
                    nowMs = now + 200L
                ) as LocalSignVoteResult.Signed).vote
                s1.consensusEngine.submitVote(pv, now + 210L)
            }
            var cert: CommitCertificate? = null
            for (vIdx in listOf(0, 1, 2)) {
                val pc = (s1.consensusEngine.signLocalVote(
                    VotePhase.PRECOMMIT,
                    block1Hash,
                    privateKeyBytesForTest = validators[vIdx].keyPair.privateKeyBytes,
                    nowMs = now + 300L
                ) as LocalSignVoteResult.Signed).vote
                val r = s1.consensusEngine.submitVote(pc, now + 310L)
                if (r is VoteSubmissionResult.Accepted && r.commitCertificate != null) cert = r.commitCertificate
            }
            s1.productionEngine.handleConsensusEvent(ConsensusEvent.BlockFinalized(cert!!), now + 400L)
        } finally {
            s1.close()
        }

        // Session 2: Reboot persistent DBs cleanly as height2Proposer and verify recovery!
        val s2 = buildStack(
            height2Proposer,
            allInfos,
            inMemory = false,
            prefix = "s11_restart",
            nowMs = now + 1000L
        )
        try {
            val recoveredState = s2.productionEngine.state.value
            assertEquals(1L, recoveredState.latestFinalizedBlockHeight)
            assertEquals(block1Hash, recoveredState.latestFinalizedBlockHash)
            assertEquals(2L, recoveredState.currentProductionHeight)
            assertEquals(1L, recoveredState.blocksFinalizedCount)
            assertEquals(1L, s2.txMempool.getConfirmedNextNonce(walletAddr))
            assertEquals(MempoolTxStatus.CONFIRMED, s2.txMempool.getByTxId(tx1.txId)!!.status)

            // Propose Height 2 Round 0, close, reboot again -> slot replay MUST still be prevented across reboot!
            val p2 = s2.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = height2Proposer.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now + 1200L
            )
            assertTrue(p2 is BlockProductionAttemptResult.Proposed)
        } finally {
            s2.close()
        }

        val s3 = buildStack(
            height2Proposer,
            allInfos,
            inMemory = false,
            prefix = "s11_restart",
            nowMs = now + 2000L
        )
        try {
            assertEquals(ProposalSubmissionStatus.ACCEPTED_BY_CONSENSUS, s3.productionEngine.state.value.proposalSubmissionStatus)
            val replayAfterReboot = s3.productionEngine.tryProduceAndProposeBlock(
                privateKeyBytesForTest = height2Proposer.keyPair.privateKeyBytes,
                telemetry = healthyTelemetry(),
                nowMs = now + 2100L
            )
            assertTrue(replayAfterReboot is BlockProductionAttemptResult.Skipped)
            assertEquals(
                ProductionErrorCode.PROPOSAL_ALREADY_SUBMITTED_FOR_SLOT,
                (replayAfterReboot as BlockProductionAttemptResult.Skipped).code
            )
            assertEquals(1L, s3.blockchainManager.getCurrentHeight())
            assertNotEquals("0".repeat(64), s3.productionEngine.state.value.latestFinalizedBlockHash)
        } finally {
            s3.close()
        }
    }
}
