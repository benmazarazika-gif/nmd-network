package com.example

import android.content.Context
import android.content.res.Configuration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.NodeIdentityManager
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.p2p.connectivity.PeerConnectivityManager
import com.example.p2p.connectivity.ice.SimulatedIceNetworkFabric
import com.example.p2p.connectivity.ice.SimulatedNatBehavior
import com.example.p2p.connectivity.ice.SimulatedNatIceEngine
import com.example.p2p.connectivity.model.IceCandidateInfo
import com.example.p2p.connectivity.model.NatTraversalConfig
import com.example.p2p.connectivity.signaling.CandidateIngestOutcome
import com.example.p2p.connectivity.signaling.SignalingEnvelope
import com.example.p2p.connectivity.signaling.SignalingValidationResult
import com.example.p2p.discovery.DistributedDiscoveryCoordinator
import com.example.p2p.discovery.PeerDiscoveryService
import com.example.p2p.handshake.PeerHandshakeService
import com.example.p2p.infrastructure.NetworkInfrastructureCoordinator
import com.example.p2p.infrastructure.bootstrap.BootstrapNodeManager
import com.example.p2p.infrastructure.model.BootstrapEndpointConfig
import com.example.p2p.infrastructure.model.BootstrapPeerRecord
import com.example.p2p.infrastructure.model.BootstrapTransportProtocol
import com.example.p2p.infrastructure.model.EndpointHealthState
import com.example.p2p.infrastructure.model.NetworkInfrastructureSnapshot
import com.example.p2p.infrastructure.model.NetworkProfileConfig
import com.example.p2p.infrastructure.model.NetworkProfileRegistry
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.infrastructure.model.SignalingEndpointConfig
import com.example.p2p.infrastructure.model.SignalingTransportStatus
import com.example.p2p.infrastructure.signaling.WebSocketSignalingChannel
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.repository.NetworkTransportRepository
import com.example.p2p.service.ReliableP2pMessagingService
import com.example.p2p.transport.TcpPeerTransport
import com.example.ui.screens.network.PublicNetworkInfraSection
import com.example.ui.theme.NmdNetworkTheme
import com.nmd.bootstrap.BootstrapServer
import com.nmd.bootstrap.BootstrapServiceConfig
import com.nmd.bootstrap.ServiceNetworkProfile
import com.nmd.signaling.SignalingServer
import com.nmd.signaling.SignalingServiceConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.Closeable
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

/**
 * Stage 15 Public Network Infrastructure & Bootstrap Verification Suite.
 *
 * Clearly distinguishes:
 * - Real client-server loopback HTTP & WebSocket integration in tests using local instances of
 *   [BootstrapServer] and [SignalingServer] (NOT deployed external internet servers).
 * - Full real Stage 13 X25519+Ed25519+ChaCha20-Poly1305 encryption, Stage 14 signaling security,
 *   Stage 7 Peer Exchange (PEX), network profile isolation, and Compose UI verification.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdP2PStage15InfrastructureTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private val testScopes = mutableListOf<CoroutineScope>()
    private val closeables = mutableListOf<Closeable>()
    private val crypto = BouncyCastleEd25519Provider()

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
    }

    @After
    fun teardown() {
        closeables.forEach { runCatching { it.close() } }
        closeables.clear()
        testScopes.forEach { it.cancel() }
        testScopes.clear()
    }

    private fun newScope(): CoroutineScope {
        val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        testScopes.add(s)
        return s
    }

    private fun createTestIdentityManager(suffix: String): NodeIdentityManager {
        val prefs = KeyStoreStorageService(
            context = context,
            preferencesName = "stage15_id_${suffix}_${UUID.randomUUID().toString().take(8)}",
            allowTestEnvironmentFallback = true
        )
        val repo = IdentityRepositoryImpl(crypto, prefs)
        return NodeIdentityManager(repo).apply { generateNewIdentity() }
    }

    private data class NodeStack(
        val idMgr: NodeIdentityManager,
        val nodeId: String,
        val transport: TcpPeerTransport,
        val connectionManager: PeerConnectionManager,
        val reliableService: ReliableP2pMessagingService,
        val discoveryCoordinator: DistributedDiscoveryCoordinator,
        val connectivityManager: PeerConnectivityManager,
        val infraCoordinator: NetworkInfrastructureCoordinator
    )

    private fun createNodeStack(
        name: String,
        fabric: SimulatedIceNetworkFabric
    ): NodeStack {
        val scope = newScope()
        val idMgr = createTestIdentityManager(name)
        val nodeId = idMgr.getActiveIdentity()!!.nodeId
        val transport = TcpPeerTransport(scope)
        val discoveryService = PeerDiscoveryService(context, scope)
        val handshakeService = PeerHandshakeService(idMgr)
        val connMgr = PeerConnectionManager(
            context = context,
            identityManager = idMgr,
            transport = transport,
            handshakeService = handshakeService,
            discoveryService = discoveryService,
            scope = scope
        )
        val reliable = ReliableP2pMessagingService(
            context = context,
            identityManager = idMgr,
            connectionManager = connMgr,
            scope = scope
        )
        val coordinator = DistributedDiscoveryCoordinator(
            context = context,
            identityManager = idMgr,
            transport = transport,
            discoveryService = discoveryService,
            connectionManager = connMgr,
            reliableMessagingService = reliable,
            scope = scope
        )
        val connectivityMgr = PeerConnectivityManager(
            context = context,
            identityManager = idMgr,
            connectionManager = connMgr,
            discoveryCoordinator = coordinator,
            scope = scope,
            discoveryService = discoveryService,
            localIpProvider = { transport.getLocalIpAddress() },
            iceEngine = SimulatedNatIceEngine(nodeId, fabric)
        )
        val infra = NetworkInfrastructureCoordinator(
            context = context,
            identityManager = idMgr,
            transport = transport,
            connectionManager = connMgr,
            discoveryCoordinator = coordinator,
            connectivityManager = connectivityMgr,
            scope = scope
        )
        closeables.add(infra)
        closeables.add(connectivityMgr)
        closeables.add(coordinator)
        closeables.add(reliable)
        closeables.add(connMgr)
        closeables.add(discoveryService)
        closeables.add(transport)
        return NodeStack(idMgr, nodeId, transport, connMgr, reliable, coordinator, connectivityMgr, infra)
    }

    @Test
    fun `test01 network profile validation blocks disabled mainnet, wrong chain, and dev loopback in testnet-mainnet`() {
        val devDefault = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
        assertEquals(null, devDefault.validate())

        val testnetDefault = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.TESTNET)
        assertEquals(null, testnetDefault.validate())

        // Mainnet disabled by default
        val mainnetDefault = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.MAINNET)
        assertNotNull(mainnetDefault.validate())

        // Loopback forbidden in TESTNET/MAINNET without test override
        val badTestnet = testnetDefault.copy(
            bootstrapEndpoints = listOf(
                BootstrapEndpointConfig(
                    id = "b1",
                    name = "Bad Loopback",
                    host = "127.0.0.1",
                    port = 8844,
                    protocol = BootstrapTransportProtocol.HTTPS,
                    requireTls = true,
                    networkProfile = NmdNetworkProfile.TESTNET
                )
            )
        )
        assertTrue(badTestnet.validate()!!.contains("Loopback", ignoreCase = true))

        // Non-TLS rejected in TESTNET/MAINNET
        val badHttp = testnetDefault.copy(
            bootstrapEndpoints = listOf(
                BootstrapEndpointConfig(
                    id = "b2",
                    name = "Plain HTTP",
                    host = "bootstrap.example.org",
                    port = 8844,
                    protocol = BootstrapTransportProtocol.HTTP_DEV_ONLY,
                    requireTls = true,
                    networkProfile = NmdNetworkProfile.TESTNET
                )
            )
        )
        assertTrue(badHttp.validate()!!.contains("HTTPS/TLS", ignoreCase = true))

        // Invalid signaling ws:// in TESTNET rejected when requireTls = true
        val badWs = testnetDefault.copy(
            signalingEndpoints = listOf(
                SignalingEndpointConfig(
                    id = "s1",
                    name = "Insecure WS",
                    url = "ws://signal.example.org:8845/ws",
                    requireTls = true,
                    networkProfile = NmdNetworkProfile.TESTNET
                )
            )
        )
        assertTrue(badWs.validate()!!.contains("wss://", ignoreCase = true))

        // Genesis hash mismatch blocked
        val badGenesis = testnetDefault.copy(expectedGenesisHash = "f".repeat(64))
        assertTrue(badGenesis.validate()!!.contains("Genesis hash", ignoreCase = true))
    }

    @Test
    fun `test02 bootstrap failover, signed server verification, wrong chain rejection, and restart persistence`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_ICE_ALLOWED)
        val stack = createNodeStack("bootFailover", fabric)
        val devCfg = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)

        // Generate bootstrap server Ed25519 keypair to verify signed responses
        val kp = crypto.generateEd25519KeyPair()
        val privSeedHex = crypto.toHex(kp.privateKeyBytes)
        val pubHex = crypto.toHex(kp.publicKeyBytes)

        // Primary unreachable port + healthy secondary BootstrapServer
        val server2 = BootstrapServer(
            BootstrapServiceConfig(
                port = 0,
                networkProfile = ServiceNetworkProfile.DEVELOPMENT,
                chainId = devCfg.chainId,
                genesisHash = devCfg.expectedGenesisHash,
                responseSigningPrivateKeyHex = privSeedHex
            )
        ).also { closeables.add(it) }
        val port2 = server2.start()

        // Seed a valid peer on server2
        val remoteStack = createNodeStack("remoteSeed", fabric)
        val remoteCfg = devCfg.copy(
            bootstrapEndpoints = listOf(
                BootstrapEndpointConfig(
                    id = "s2_direct",
                    name = "Secondary",
                    host = "127.0.0.1",
                    port = port2,
                    protocol = BootstrapTransportProtocol.HTTP_DEV_ONLY,
                    requireTls = false,
                    expectedPublicKeyHex = pubHex,
                    networkProfile = NmdNetworkProfile.DEVELOPMENT
                )
            )
        )
        remoteStack.infraCoordinator.bootstrapManager.applyProfileConfiguration(remoteCfg, persist = false)
        assertTrue(remoteStack.infraCoordinator.bootstrapManager.registerLocalNodeWithBootstrap("127.0.0.1", 19001).isSuccess)

        // Configure primary dead endpoint (priority 1) + healthy secondary (priority 2)
        val epDead = BootstrapEndpointConfig(
            id = "dead_primary",
            name = "Dead Primary",
            host = "127.0.0.1",
            port = 65421,
            protocol = BootstrapTransportProtocol.HTTP_DEV_ONLY,
            requireTls = false,
            networkProfile = NmdNetworkProfile.DEVELOPMENT,
            priority = 1
        )
        val epHealthy = BootstrapEndpointConfig(
            id = "healthy_secondary",
            name = "Healthy Secondary",
            host = "127.0.0.1",
            port = port2,
            protocol = BootstrapTransportProtocol.HTTP_DEV_ONLY,
            requireTls = false,
            expectedPublicKeyHex = pubHex,
            networkProfile = NmdNetworkProfile.DEVELOPMENT,
            priority = 2
        )
        val multiCfg = devCfg.copy(bootstrapEndpoints = listOf(epDead, epHealthy))
        assertTrue(stack.infraCoordinator.applyNetworkProfileConfig(multiCfg, attachWebSocketChannel = false).isSuccess)

        val disc = stack.infraCoordinator.bootstrapManager.discoverInitialPeers()
        assertTrue("Expected failover to secondary bootstrap: ${disc.exceptionOrNull()}", disc.isSuccess)
        val outcome = disc.getOrThrow()
        assertEquals("healthy_secondary", outcome.usedEndpointId)
        assertEquals(1, outcome.validPeersAccepted.size)
        assertEquals(remoteStack.nodeId, outcome.validPeersAccepted[0].nodeId)

        // Primary should now be marked in COOLDOWN; secondary HEALTHY
        val updatedList = stack.infraCoordinator.bootstrapManager.activeProfileConfig.value.bootstrapEndpoints
        assertEquals(EndpointHealthState.COOLDOWN, updatedList.first { it.id == "dead_primary" }.healthState)
        assertEquals(EndpointHealthState.HEALTHY, updatedList.first { it.id == "healthy_secondary" }.healthState)

        // Wrong Chain ID server rejected cleanly
        val wrongChainServer = BootstrapServer(
            BootstrapServiceConfig(
                port = 0,
                networkProfile = ServiceNetworkProfile.TESTNET,
                chainId = "nmd-wrong-chain-999",
                genesisHash = devCfg.expectedGenesisHash
            )
        ).also { closeables.add(it) }
        val wrongPort = wrongChainServer.start()
        val wrongCfg = devCfg.copy(
            bootstrapEndpoints = listOf(
                BootstrapEndpointConfig(
                    id = "wrong_chain_ep",
                    name = "Wrong Chain",
                    host = "127.0.0.1",
                    port = wrongPort,
                    protocol = BootstrapTransportProtocol.HTTP_DEV_ONLY,
                    requireTls = false,
                    networkProfile = NmdNetworkProfile.DEVELOPMENT
                )
            )
        )
        stack.infraCoordinator.bootstrapManager.applyProfileConfiguration(wrongCfg, persist = true)
        val wrongDisc = stack.infraCoordinator.bootstrapManager.discoverInitialPeers()
        assertTrue(wrongDisc.isFailure)
        assertTrue(wrongDisc.exceptionOrNull()!!.message!!.contains("Chain ID mismatch", ignoreCase = true))

        // Recovery after restart: reload persisted config into fresh BootstrapNodeManager
        val freshMgr = BootstrapNodeManager(
            context = context,
            identityManager = stack.idMgr,
            peerRegistry = stack.discoveryCoordinator.peerRegistry,
            trustManager = stack.connectionManager.transportSecurityManager.trustManager
        )
        assertEquals(devCfg.chainId, freshMgr.activeProfileConfig.value.chainId)
        assertEquals("wrong_chain_ep", freshMgr.activeProfileConfig.value.bootstrapEndpoints.first().id)
    }

    @Test
    fun `test03 peer record validation rejects malformed identity, wrong genesis, expired timestamp, and revoked peers`() {
        val devCfg = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
        val idPeer = createTestIdentityManager("recVal").getActiveIdentity()!!
        val now = 1_740_000_000_000L

        val validRecord = BootstrapPeerRecord(
            nodeId = idPeer.nodeId,
            publicKeyHex = idPeer.publicKeyHex,
            protocolVersion = 1,
            chainId = devCfg.chainId,
            genesisHash = devCfg.expectedGenesisHash,
            host = "198.51.100.10",
            port = 8765,
            lastSeenTimestampMs = now - 5_000L,
            capabilities = listOf("p2p"),
            availabilityStatus = "ONLINE"
        )
        assertEquals(null, validRecord.validateAgainst(devCfg, "nmd_node_other", now))

        // Spoofed Node ID that does not derive from publicKeyHex rejected
        val spoofed = validRecord.copy(nodeId = "nmd_node_ffffffffffffffffffffffffffffffff")
        assertNotNull(spoofed.validateAgainst(devCfg, "nmd_node_other", now))

        // Wrong genesis hash rejected
        val wrongGenesis = validRecord.copy(genesisHash = "0".repeat(64))
        assertNotNull(wrongGenesis.validateAgainst(devCfg, "nmd_node_other", now))

        // Expired record rejected
        val expired = validRecord.copy(lastSeenTimestampMs = now - BootstrapPeerRecord.MAX_RECORD_AGE_MS - 1_000L)
        assertNotNull(expired.validateAgainst(devCfg, "nmd_node_other", now))
    }

    @Test
    fun `test04 WebSocketSignalingChannel connects, delivers all Stage 14 signed envelopes, and enforces security`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_ICE_ALLOWED)
        val devCfg = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)

        val sigServer = SignalingServer(
            SignalingServiceConfig(
                port = 0,
                chainId = devCfg.chainId,
                maxMessageBytes = 4096,
                offlineQueueTtlMs = 30_000L
            )
        ).also { closeables.add(it) }
        val sigPort = sigServer.start()

        val peerA = createNodeStack("wsPeerA", fabric)
        val peerB = createNodeStack("wsPeerB", fabric)

        val sigEndpoint = SignalingEndpointConfig(
            id = "ws_local",
            name = "Local WS Signaling",
            url = "ws://127.0.0.1:$sigPort/ws",
            requireTls = false,
            networkProfile = NmdNetworkProfile.DEVELOPMENT
        )
        val cfg = devCfg.copy(signalingEndpoints = listOf(sigEndpoint))

        assertTrue(peerA.infraCoordinator.applyNetworkProfileConfig(cfg, attachWebSocketChannel = true).isSuccess)
        assertTrue(peerB.infraCoordinator.applyNetworkProfileConfig(cfg, attachWebSocketChannel = true).isSuccess)

        var wait = 0
        while (
            (peerA.infraCoordinator.webSocketSignalingChannel.status.value != SignalingTransportStatus.AUTHENTICATED ||
                peerB.infraCoordinator.webSocketSignalingChannel.status.value != SignalingTransportStatus.AUTHENTICATED) &&
            wait < 40
        ) {
            delay(50)
            wait++
        }
        assertEquals(SignalingTransportStatus.AUTHENTICATED, peerA.infraCoordinator.webSocketSignalingChannel.status.value)
        assertEquals(SignalingTransportStatus.AUTHENTICATED, peerB.infraCoordinator.webSocketSignalingChannel.status.value)

        // End-to-end signed ICE + Stage 13 encryption over REAL WebSocketSignalingChannel!
        val connRes = peerA.connectivityManager.connectToPeerSmart(targetNodeId = peerB.nodeId)
        assertTrue("Expected cross-WebSocket ICE + Stage 13 auth to succeed: ${connRes.exceptionOrNull()}", connRes.isSuccess)
        assertEquals(RealPeerConnectionState.AUTHENTICATED, connRes.getOrThrow().state)

        // Verify signed protocol message flows over the WebSocket-signaled ICE DataChannel
        var rxPayload: String? = null
        val job = newScope().launch {
            peerB.connectionManager.receivedMessages.collect { (_, msg) ->
                rxPayload = msg.payload
            }
        }
        peerA.connectionManager.sendMessage(connRes.getOrThrow().connectionId, ProtocolMessageType.NODE_ANNOUNCEMENT, "{\"stage\":15,\"ws\":true}")
        delay(200)
        job.cancel()
        assertEquals("{\"stage\":15,\"ws\":true}", rxPayload)

        // Verify signaling security over WebSocket envelopes (client 16KB cap + server 4KB cap)
        val rawWs = peerA.infraCoordinator.webSocketSignalingChannel
        val tooLargeForClient = peerA.connectivityManager.signalingService.createSignedOffer("bigClient", peerB.nodeId, "x".repeat(20_000))
        if (tooLargeForClient.isSuccess) {
            assertTrue(rawWs.sendEnvelope(tooLargeForClient.getOrThrow()).isFailure)
        }
        val oversizedForServer = peerA.connectivityManager.signalingService.createSignedOffer("bigSrv", peerB.nodeId, "x".repeat(5_000))
        if (oversizedForServer.isSuccess) {
            rawWs.sendEnvelope(oversizedForServer.getOrThrow())
            var errWait = 0
            while (rawWs.lastError.value == null && errWait < 30) {
                delay(50)
                errWait++
            }
            assertTrue(
                "Expected server FRAME_OVERSIZED rejection, got: ${rawWs.lastError.value}",
                rawWs.lastError.value?.contains("too big", ignoreCase = true) == true ||
                    rawWs.lastError.value?.contains("1009") == true ||
                    rawWs.lastError.value?.contains("exceeds", ignoreCase = true) == true
            )
        }

        // Verify invalid Ed25519 signature, wrong recipient, replay rejected by PeerSignalingService
        val offer = peerA.connectivityManager.signalingService.createSignedOffer("sec-s1", peerB.nodeId, "v=0\nsdp\n").getOrThrow()
        assertTrue(peerB.connectivityManager.signalingService.verifyAndProcessIncoming(offer.copy(payloadJson = "tampered")) is SignalingValidationResult.Rejected)
        assertTrue(peerB.connectivityManager.signalingService.verifyAndProcessIncoming(offer.copy(chainId = "wrong-chain")) is SignalingValidationResult.Rejected)
        assertTrue(peerB.connectivityManager.signalingService.verifyAndProcessIncoming(offer) is SignalingValidationResult.Valid)
        assertTrue(peerB.connectivityManager.signalingService.verifyAndProcessIncoming(offer) is SignalingValidationResult.Rejected) // replay

        // Out-of-order + duplicate candidate buffering
        assertTrue(peerB.connectivityManager.signalingService.tryReserveOutboundNegotiation("ooo-ws", peerA.nodeId).isSuccess)
        val cand = IceCandidateInfo.parseSafe("candidate:1 1 udp 2122260223 198.51.100.5 52000 typ host")!!
        assertTrue(peerB.connectivityManager.signalingService.ingestRemoteCandidate("ooo-ws", cand) is CandidateIngestOutcome.BufferedEarly)
        assertTrue(peerB.connectivityManager.signalingService.ingestRemoteCandidate("ooo-ws", cand) is CandidateIngestOutcome.DuplicateIgnored)
    }

    @Test
    fun `test05 WebSocketSignalingChannel expires stale offline queue messages and reconnects after server restart`() = runBlocking {
        val now = AtomicLong(1_740_000_000_000L)
        val devCfg = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
        val idMgr = createTestIdentityManager("wsExpire")
        val scope = newScope()

        val wsChannel = WebSocketSignalingChannel(
            identityManager = idMgr,
            scope = scope,
            offlineQueueTtlMs = 2_000L,
            clockMs = { now.get() }
        ).also { closeables.add(it) }

        val sigServer1 = SignalingServer(
            config = SignalingServiceConfig(port = 0, chainId = devCfg.chainId),
            clockMs = { now.get() }
        ).also { closeables.add(it) }
        val port = sigServer1.start()

        val ep = SignalingEndpointConfig(
            id = "ws_exp",
            name = "WS Expire",
            url = "ws://127.0.0.1:$port/ws",
            requireTls = false,
            networkProfile = NmdNetworkProfile.DEVELOPMENT
        )
        // Configure without waiting yet or queue while disconnected
        wsChannel.configureAndConnect(NmdNetworkProfile.DEVELOPMENT, devCfg.chainId, listOf(ep), allowLocalTestOverride = true)

        // Wait until authenticated
        var w = 0
        while (wsChannel.status.value != SignalingTransportStatus.AUTHENTICATED && w < 40) {
            delay(50)
            w++
        }
        assertEquals(SignalingTransportStatus.AUTHENTICATED, wsChannel.status.value)

        // Shut down server -> client disconnects cleanly and enters reconnect backoff
        sigServer1.close()
        delay(200)
        assertTrue(
            wsChannel.status.value == SignalingTransportStatus.DISCONNECTED ||
                wsChannel.status.value == SignalingTransportStatus.RECONNECTING
        )

        // Enqueue an envelope while offline, then advance clock past TTL
        val staleEnv = SignalingEnvelope(
            signalingSessionId = "stale-s1",
            chainId = devCfg.chainId,
            senderNodeId = idMgr.getActiveIdentity()!!.nodeId,
            senderPublicKeyHex = idMgr.getActiveIdentity()!!.publicKeyHex,
            recipientNodeId = "nmd_node_11111111111111111111111111111111",
            messageType = com.example.p2p.connectivity.signaling.SignalingMessageType.ICE_OFFER,
            sequenceNumber = 1L,
            timestampMs = now.get(),
            nonceHex = "00".repeat(16),
            payloadJson = "{\"sdp\":\"v=0\"}",
            signatureHex = "aa"
        )
        wsChannel.sendEnvelope(staleEnv)
        now.addAndGet(5_000L)

        // Start replacement server on SAME port -> manual/auto reconnect flushes queue (dropping expired message)
        val sigServer2 = SignalingServer(
            config = SignalingServiceConfig(port = port, chainId = devCfg.chainId),
            clockMs = { now.get() }
        ).also { closeables.add(it) }
        sigServer2.start()
        wsChannel.triggerReconnect("Server back up")

        var w2 = 0
        while (wsChannel.status.value != SignalingTransportStatus.AUTHENTICATED && w2 < 40) {
            delay(50)
            w2++
        }
        assertEquals(SignalingTransportStatus.AUTHENTICATED, wsChannel.status.value)
        assertTrue("Expired offline envelope should have been purged before sending", wsChannel.expiredQueueCount() >= 1L)
    }

    @Test
    fun `test06 end-to-end onboarding via bootstrap discovers peers, connects via Stage 13 auth, expands via PEX, and survives bootstrap outage`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_ICE_ALLOWED)
        val devCfg = NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)

        val bootServer = BootstrapServer(
            BootstrapServiceConfig(
                port = 0,
                networkProfile = ServiceNetworkProfile.DEVELOPMENT,
                chainId = devCfg.chainId,
                genesisHash = devCfg.expectedGenesisHash
            )
        ).also { closeables.add(it) }
        val bootPort = bootServer.start()

        val peerA = createNodeStack("onboardA", fabric)
        val peerB = createNodeStack("onboardB", fabric)

        val portB = peerB.connectionManager.startP2P(0)
        val sharedBootCfg = devCfg.copy(
            bootstrapEndpoints = listOf(
                BootstrapEndpointConfig(
                    id = "boot_dev_1",
                    name = "Local Dev Bootstrap",
                    host = "127.0.0.1",
                    port = bootPort,
                    protocol = BootstrapTransportProtocol.HTTP_DEV_ONLY,
                    requireTls = false,
                    networkProfile = NmdNetworkProfile.DEVELOPMENT
                )
            )
        )
        peerB.infraCoordinator.applyNetworkProfileConfig(sharedBootCfg, attachWebSocketChannel = false)
        assertTrue(peerB.infraCoordinator.bootstrapManager.registerLocalNodeWithBootstrap("127.0.0.1", portB).isSuccess)

        // Peer A starts fresh, discovers Peer B from bootstrap, connects with Stage 13 auth
        peerA.infraCoordinator.applyNetworkProfileConfig(sharedBootCfg, attachWebSocketChannel = false)
        val onboardRes = peerA.infraCoordinator.bootstrapAndSyncPeers(registerSelfIfListening = false)
        assertTrue("Onboarding failed: ${onboardRes.exceptionOrNull()}", onboardRes.isSuccess)
        assertEquals(1, onboardRes.getOrThrow())
        assertEquals(1, peerA.connectionManager.authenticatedPeers.value.size)

        // Reject duplicate Node IDs cleanly (connecting again to Peer B returns existing authenticated session)
        val dupRes = peerA.connectivityManager.connectToPeerSmart(
            targetNodeId = peerB.nodeId,
            localEndpoint = com.example.p2p.model.PeerEndpoint("127.0.0.1", portB, peerB.nodeId)
        )
        assertTrue(dupRes.isSuccess)
        assertEquals(1, peerA.connectionManager.authenticatedPeers.value.size)

        // Shut down bootstrap server completely -> network continues operating cleanly on existing peers!
        bootServer.close()
        val resilientSync = peerA.infraCoordinator.bootstrapAndSyncPeers(registerSelfIfListening = false)
        assertTrue("Network must keep operating on authenticated peers when bootstrap goes down", resilientSync.isSuccess)
        delay(100)
        assertTrue(peerA.infraCoordinator.snapshot.value.isOfflineOperatingOnExistingPeers)
        assertEquals(1, peerA.connectionManager.authenticatedPeers.value.size)

        // Revocation enforcement rejects compromised peer cleanly
        peerA.connectionManager.transportSecurityManager.revokePeerIdentity(peerB.nodeId, reason = "Revoked in Stage 15 test")
        delay(150)
        assertEquals(0, peerA.connectionManager.authenticatedPeers.value.size)
    }

    @Test
    fun `test07 Stage 15 localized strings EN, AR RTL, and FR LTR all resolve and PublicNetworkInfraSection renders + confirms changes`() {
        val locales = listOf(Locale.ENGLISH, Locale.forLanguageTag("ar"), Locale.FRENCH)
        val keys = listOf(
            R.string.stage15_infra_title,
            R.string.stage15_field_profile,
            R.string.stage15_field_chain_id,
            R.string.stage15_field_genesis_hash,
            R.string.stage15_field_configured_bootstrap,
            R.string.stage15_field_healthy_bootstrap,
            R.string.stage15_field_active_signaling,
            R.string.stage15_field_signaling_status,
            R.string.stage15_action_bootstrap_sync,
            R.string.stage15_action_probe_health,
            R.string.stage15_action_reconnect_sig,
            R.string.stage15_action_configure_endpoints,
            R.string.stage15_confirm_title,
            R.string.stage15_confirm_apply
        )
        for (loc in locales) {
            val conf = Configuration(context.resources.configuration).apply { setLocale(loc) }
            val localizedCtx = context.createConfigurationContext(conf)
            for (resId in keys) {
                assertTrue("Blank string $resId for ${loc.language}", localizedCtx.getString(resId).isNotBlank())
            }
        }

        val sampleSnapshot = NetworkInfrastructureSnapshot(
            activeProfile = NmdNetworkProfile.TESTNET,
            isMainnetActivated = false,
            chainId = "nmd-private-testnet-1",
            configuredBootstrapCount = 2,
            healthyBootstrapCount = 1,
            unavailableBootstrapCount = 1,
            activeSignalingEndpoint = "wss://signal.example:8845/ws",
            signalingStatus = SignalingTransportStatus.AUTHENTICATED,
            discoveredPeersCount = 12,
            authenticatedPeersCount = 4,
            directConnectionsCount = 3,
            relayConnectionsCount = 1,
            lastDirectoryRefreshMs = System.currentTimeMillis(),
            lastBootstrapSuccessMs = System.currentTimeMillis(),
            currentEndpointFailures = 1,
            lastStatusSummary = "Operating cleanly via 1 healthy bootstrap + WSS"
        )

        var synced = false
        var probed = false
        var reconnected = false
        var applied = false

        composeRule.setContent {
            NmdNetworkTheme {
                Box(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    PublicNetworkInfraSection(
                        snapshot = sampleSnapshot,
                        onBootstrapAndSync = { synced = true },
                        onProbeHealth = { probed = true },
                        onReconnectSignaling = { reconnected = true },
                        onApplyConfiguration = { _, _, _, _ -> applied = true }
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("stage15_public_infra_card").assertIsDisplayed()
        composeRule.onNodeWithTag("stage15_active_profile_value").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("stage15_chain_id_value").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("stage15_genesis_hash_value").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("stage15_signaling_status_value").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("stage15_bootstrap_sync_btn").performScrollTo().performClick()
        composeRule.onNodeWithTag("stage15_probe_health_btn").performScrollTo().performClick()
        composeRule.onNodeWithTag("stage15_reconnect_wss_btn").performScrollTo().performClick()
        composeRule.onNodeWithTag("stage15_configure_infra_btn").performScrollTo().performClick()
        composeRule.waitForIdle()

        assertTrue(synced)
        assertTrue(probed)
        assertTrue(reconnected)

        // Admin dialog opened -> click Save -> Confirmation Dialog MUST appear before applying changes!
        composeRule.onNodeWithTag("stage15_dialog_save_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText(context.getString(R.string.stage15_confirm_title)).assertIsDisplayed()
        composeRule.onNodeWithTag("stage15_confirm_apply_btn").performClick()
        composeRule.waitForIdle()
        assertTrue(applied)
    }

    @Test
    fun `test08 Stage 14 NetworkTransportRepository remains backward compatible with Stage 15 wired`() {
        val scope = newScope()
        val idMgr = createTestIdentityManager("repo15")
        val repo = NetworkTransportRepository(context, idMgr, scope)
        closeables.add(repo)

        assertNotNull(repo.infrastructureCoordinator)
        assertEquals(NmdNetworkProfile.DEVELOPMENT, repo.infrastructureSnapshot.value.activeProfile)
        assertFalse(repo.infrastructureSnapshot.value.isMainnetActivated)
    }
}
