package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.config.NmdGenesisConfigs
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.blockchain.model.TransactionReference
import com.example.blockchain.storage.RoomBlockchainStorage
import com.example.consensus.ConsensusCoordinator
import com.example.consensus.NmdConsensusCoordinatorRegistry
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.crypto.ConsensusCryptoSigner
import com.example.consensus.engine.LocalSignVoteResult
import com.example.consensus.engine.ProposalSubmissionResult
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorStatus
import com.example.consensus.model.VotePhase
import com.example.consensus.storage.RoomConsensusStorage
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.Ed25519KeyPairResult
import com.example.data.DeviceTelemetry
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.session.P2pSessionState
import com.example.p2p.session.PeerSession
import com.example.production.NmdBlockProductionRegistry
import com.example.sync.NmdBlockchainSyncRegistry
import com.example.sync.config.SyncConfig
import com.example.sync.engine.BlockchainSyncManager
import com.example.sync.engine.SyncCycleOutcome
import com.example.sync.model.BlockHeadersRequest
import com.example.sync.model.BlockHeadersResponse
import com.example.sync.model.BlocksRequest
import com.example.sync.model.BlocksResponse
import com.example.sync.model.ChainStatusExchangeMessage
import com.example.sync.model.ChainStatusRequest
import com.example.sync.model.SyncBlockBundle
import com.example.sync.model.SyncBlockHeaderEntry
import com.example.sync.model.SyncErrorCode
import com.example.sync.model.SyncStatusState
import com.example.sync.p2p.SyncPeerTransport
import com.example.sync.p2p.SyncTransportCallResult
import com.example.sync.storage.RoomSyncStorage
import com.example.transaction.NmdTransactionEngineRegistry
import com.example.transaction.crypto.NmdAddressCodec
import com.example.transaction.crypto.TransactionSigner
import com.example.transaction.mempool.MempoolSubmissionResult
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionType
import com.example.transaction.storage.RoomTransactionStorage
import com.example.transaction.validation.TransactionValidator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdBlockchainSyncStage12Test {

    private lateinit var context: Context
    private val crypto = BouncyCastleEd25519Provider()
    private val consensusSigner = ConsensusCryptoSigner(crypto)
    private val txSigner = TransactionSigner(crypto)
    private val blockHasher = BlockHasher(crypto)
    private val blockchainConfig = BlockchainConfig()
    private val consensusConfig = ConsensusConfig()

    private val persistentDbs = listOf(
        "s12_resume_chain_nodeB.db",
        "s12_resume_tx_nodeB.db",
        "s12_resume_cons_nodeB.db",
        "s12_resume_sync_nodeB.db"
    )

    private data class TestValidator(
        val name: String,
        val keyPair: Ed25519KeyPairResult,
        val validatorId: String,
        val publicKeyHex: String,
        val info: ValidatorInfo
    )

    private data class NodeBundle(
        val nodeId: String,
        val blockchainManager: BlockchainManager,
        val txMempool: TransactionMempool,
        val consensusCoordinator: ConsensusCoordinator,
        val syncManager: BlockchainSyncManager,
        val peerRegistry: DistributedPeerRegistry,
        val registryScope: CoroutineScope
    ) : java.io.Closeable {
        override fun close() {
            syncManager.close()
            consensusCoordinator.close()
            txMempool.close()
            blockchainManager.close()
            registryScope.cancel()
        }
    }

    /**
     * Multi-node router implementing [SyncPeerTransport] cleanly over real serialized protocol messages.
     */
    private class MultiNodeRouterTransport(
        private val connectedPeers: MutableMap<String, PeerSession> = LinkedHashMap(),
        private val handlers: MutableMap<String, BlockchainSyncManager> = LinkedHashMap(),
        var customStatusOverride: (suspend (peerId: String, ChainStatusRequest) -> SyncTransportCallResult<ChainStatusExchangeMessage>?)? = null,
        var customHeadersOverride: (suspend (peerId: String, BlockHeadersRequest) -> SyncTransportCallResult<BlockHeadersResponse>?)? = null,
        var customBlocksOverride: (suspend (peerId: String, BlocksRequest) -> SyncTransportCallResult<BlocksResponse>?)? = null
    ) : SyncPeerTransport {

        val requestedHeaderFromHeights = mutableListOf<Pair<String, Long>>()
        val requestedBlockFromHeights = mutableListOf<Pair<String, Long>>()
        var maxPayloadLimitBytes: Int = 512 * 1024

        fun connectPeer(peerId: String, handler: BlockchainSyncManager, latencyMs: Long = 10L) {
            connectedPeers[peerId] = PeerSession(
                sessionId = "sess_$peerId",
                peerId = peerId,
                remotePublicKeyHex = "ab".repeat(32),
                endpoint = PeerEndpoint("192.168.1.${connectedPeers.size + 10}", 9000, peerId),
                state = P2pSessionState.ACTIVE,
                lastRoundTripLatencyMs = latencyMs
            )
            handlers[peerId] = handler
        }

        fun disconnectPeer(peerId: String) {
            connectedPeers.remove(peerId)
        }

        override fun getAuthenticatedSessions(): List<PeerSession> = connectedPeers.values.toList()

        override suspend fun requestChainStatus(
            session: PeerSession,
            request: ChainStatusRequest,
            timeoutMs: Long
        ): SyncTransportCallResult<ChainStatusExchangeMessage> {
            customStatusOverride?.invoke(session.peerId, request)?.let { return it }
            val peer = handlers[session.peerId]
                ?: return SyncTransportCallResult.Failure("Peer disconnected", isDisconnected = true)
            val wireJson = peer.handleChainStatusRequest(request).toJson()
            val decoded = ChainStatusExchangeMessage.fromJson(wireJson, maxBytes = maxPayloadLimitBytes)
                ?: return SyncTransportCallResult.Failure("Oversized or malformed status", isMalformedOrOversized = true)
            return SyncTransportCallResult.Success(decoded, session.lastRoundTripLatencyMs.coerceAtLeast(1L))
        }

        override suspend fun requestBlockHeaders(
            session: PeerSession,
            request: BlockHeadersRequest,
            timeoutMs: Long
        ): SyncTransportCallResult<BlockHeadersResponse> {
            requestedHeaderFromHeights.add(session.peerId to request.fromHeight)
            customHeadersOverride?.invoke(session.peerId, request)?.let { return it }
            val peer = handlers[session.peerId]
                ?: return SyncTransportCallResult.Failure("Peer disconnected", isDisconnected = true)
            val wireJson = peer.handleBlockHeadersRequest(request).toJson()
            val decoded = BlockHeadersResponse.fromJson(wireJson, maxBytes = maxPayloadLimitBytes)
                ?: return SyncTransportCallResult.Failure("Oversized or malformed headers", isMalformedOrOversized = true)
            return SyncTransportCallResult.Success(decoded, session.lastRoundTripLatencyMs.coerceAtLeast(1L))
        }

        override suspend fun requestBlocks(
            session: PeerSession,
            request: BlocksRequest,
            timeoutMs: Long
        ): SyncTransportCallResult<BlocksResponse> {
            requestedBlockFromHeights.add(session.peerId to request.fromHeight)
            customBlocksOverride?.invoke(session.peerId, request)?.let { return it }
            val peer = handlers[session.peerId]
                ?: return SyncTransportCallResult.Failure("Peer disconnected", isDisconnected = true)
            val wireJson = peer.handleBlocksRequest(request).toJson()
            if (wireJson.toByteArray(Charsets.UTF_8).size > maxPayloadLimitBytes) {
                return SyncTransportCallResult.Failure("Response exceeds maxResponsePayloadBytes", isMalformedOrOversized = true)
            }
            val decoded = BlocksResponse.fromJson(wireJson, maxBytes = maxPayloadLimitBytes)
                ?: return SyncTransportCallResult.Failure("Oversized or malformed blocks", isMalformedOrOversized = true)
            return SyncTransportCallResult.Success(decoded, session.lastRoundTripLatencyMs.coerceAtLeast(1L))
        }
    }

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        NmdBlockchainSyncRegistry.resetForTests()
        NmdBlockProductionRegistry.resetForTests()
        NmdConsensusCoordinatorRegistry.resetForTests()
        NmdTransactionEngineRegistry.resetForTests()
        cleanupDbs()
    }

    @After
    fun tearDown() {
        NmdBlockchainSyncRegistry.resetForTests()
        NmdBlockProductionRegistry.resetForTests()
        NmdConsensusCoordinatorRegistry.resetForTests()
        NmdTransactionEngineRegistry.resetForTests()
        cleanupDbs()
    }

    private fun cleanupDbs() {
        persistentDbs.forEach { dbName ->
            context.deleteDatabase(dbName)
        }
    }

    private fun createValidators(count: Int = 4): List<TestValidator> {
        return (1..count).map { idx ->
            val kp = crypto.generateEd25519KeyPair()
            val pubHex = crypto.toHex(kp.publicKeyBytes)
            val valId = consensusSigner.deriveValidatorIdFromHex(pubHex)!!
            TestValidator(
                name = "Validator-$idx",
                keyPair = kp,
                validatorId = valId,
                publicKeyHex = pubHex,
                info = ValidatorInfo(
                    validatorId = valId,
                    nodeId = "node_$valId",
                    publicKeyHex = pubHex,
                    displayName = "Validator-$idx",
                    votingPower = 1L,
                    status = ValidatorStatus.ACTIVE
                )
            )
        }
    }

    private suspend fun createNode(
        nodeId: String,
        validators: List<TestValidator>,
        transport: SyncPeerTransport,
        syncConfig: SyncConfig = SyncConfig(),
        chainCfg: BlockchainConfig = blockchainConfig,
        inMemory: Boolean = true,
        dbPrefix: String = nodeId
    ): NodeBundle {
        val storage = RoomBlockchainStorage(
            context = context,
            dbName = "${dbPrefix}_chain_${nodeId}.db",
            inMemory = inMemory
        )
        val bm = BlockchainManager(config = chainCfg, storage = storage, blockHasher = blockHasher)
        bm.initialize()

        val txStorage = RoomTransactionStorage(
            context = context,
            dbName = "${dbPrefix}_tx_${nodeId}.db",
            inMemory = inMemory
        )
        val mempool = TransactionMempool(txStorage, TransactionValidator(chainCfg))
        mempool.initialize()

        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val peerReg = DistributedPeerRegistry(context = null, scope = scope)

        val consStorage = RoomConsensusStorage(
            context = context,
            dbName = "${dbPrefix}_cons_${nodeId}.db",
            inMemory = inMemory
        )
        val consCoord = ConsensusCoordinator(
            config = ConsensusConfig(chainId = chainCfg.chainId, protocolVersion = chainCfg.parameters.protocolVersion),
            storage = consStorage,
            blockchainManager = bm,
            peerRegistry = peerReg
        )
        consCoord.initialize(bootstrapValidators = validators.map { it.info })

        val syncStorage = RoomSyncStorage(
            context = context,
            dbName = "${dbPrefix}_sync_${nodeId}.db",
            inMemory = inMemory
        )
        val syncMgr = BlockchainSyncManager(
            config = syncConfig.copy(chainId = chainCfg.chainId, protocolVersion = chainCfg.parameters.protocolVersion),
            syncStorage = syncStorage,
            blockchainManager = bm,
            consensusCoordinator = consCoord,
            txMempool = mempool,
            transport = transport,
            peerRegistry = peerReg
        )
        syncMgr.initialize()
        return NodeBundle(nodeId, bm, mempool, consCoord, syncMgr, peerReg, scope)
    }

    private fun createSignedTx(
        senderKp: Ed25519KeyPairResult,
        recipientAddress: String,
        nonce: Long,
        amountNmd: String = "5.00",
        timestampMs: Long = System.currentTimeMillis()
    ): NmdTransaction {
        val pubHex = crypto.toHex(senderKp.publicKeyBytes)
        val senderAddr = NmdAddressCodec.deriveAddressFromPublicKey(senderKp.publicKeyBytes, crypto)
        val unsigned = NmdTransaction(
            chainId = blockchainConfig.chainId,
            protocolVersion = blockchainConfig.parameters.protocolVersion,
            senderAddress = senderAddr,
            recipientAddress = recipientAddress,
            amountUnits = NmdAmountCodec.parseNmdToUnits(amountNmd)!!,
            feeUnits = 15_000L,
            nonce = nonce,
            timestamp = timestampMs,
            txType = TransactionType.TRANSFER,
            senderPublicKeyHex = pubHex,
            payload = "sync_tx_$nonce".toByteArray(Charsets.UTF_8)
        )
        return txSigner.signWithKeyPair(unsigned, senderKp.privateKeyBytes)
    }

    /**
     * Produces and finalizes a real Stage 8 block + Stage 10 BFT CommitCertificate on [producerNode]
     * using real Ed25519 signatures from [validators]. Optionally commits transactions included.
     */
    private suspend fun produceAndFinalizeBftBlock(
        producerNode: NodeBundle,
        validators: List<TestValidator>,
        includedTxs: List<NmdTransaction> = emptyList(),
        extraData: String = "stage12_test_block",
        nowMs: Long = System.currentTimeMillis()
    ): Pair<Block, CommitCertificate> {
        val tip = producerNode.blockchainManager.getLatestBlock()!!
        val nextHeight = tip.height + 1L
        val snapshot = producerNode.consensusCoordinator.engine.getCurrentValidatorSetSnapshot()
        val scheduled = producerNode.consensusCoordinator.registry.selectDeterministicProposer(snapshot, nextHeight, 0)!!
        val proposer = validators.first { it.validatorId == scheduled.validatorId }

        for (tx in includedTxs) {
            if (producerNode.txMempool.getByTxId(tx.txId) == null) {
                val res = producerNode.txMempool.submitTransaction(tx, nowMs = nowMs)
                assertTrue("Expected tx ${tx.shortTxId} accepted, was $res", res is MempoolSubmissionResult.Accepted)
            }
        }

        val txRefs = includedTxs.mapIndexed { idx, tx ->
            TransactionReference(txHash = tx.txId, txIndex = idx, txType = tx.txType.name)
        }
        val body = com.example.blockchain.model.BlockBody(transactionRefs = txRefs, extraData = extraData)
        val merkleRoot = blockHasher.computeBodyMerkleRoot(body)
        val blockTimestamp = maxOf(tip.timestamp + 1L, nowMs)
        val header = com.example.blockchain.model.BlockHeader(
            height = nextHeight,
            previousHash = tip.hash,
            timestamp = blockTimestamp,
            chainId = blockchainConfig.chainId,
            protocolVersion = blockchainConfig.parameters.protocolVersion,
            merkleRoot = merkleRoot,
            transactionCount = includedTxs.size,
            producerId = proposer.validatorId
        )
        val blockHash = blockHasher.computeHeaderHash(header)
        val block = Block(header = header, body = body, hash = blockHash)

        val unsignedProposal = BlockProposal(
            chainId = blockchainConfig.chainId,
            protocolVersion = blockchainConfig.parameters.protocolVersion,
            blockHeight = nextHeight,
            round = 0,
            proposerId = proposer.validatorId,
            proposerPublicKeyHex = proposer.publicKeyHex,
            previousBlockHash = tip.hash,
            proposedBlockHash = block.hash,
            timestamp = blockTimestamp,
            attachedBlock = block
        )
        val signedProposal = consensusSigner.signProposalWithKeyPair(unsignedProposal, proposer.keyPair.privateKeyBytes)
        val propRes = producerNode.consensusCoordinator.engine.submitProposal(signedProposal, blockTimestamp)
        assertTrue("Proposal failed: $propRes", propRes is ProposalSubmissionResult.Accepted)

        var cert: CommitCertificate? = null
        // All validators sign PREVOTE then PRECOMMIT directly against consensusEngine
        for (v in validators) {
            val voteUnsigned = com.example.consensus.model.ConsensusVote(
                chainId = blockchainConfig.chainId,
                protocolVersion = consensusConfig.protocolVersion,
                blockHeight = nextHeight,
                round = 0,
                votePhase = VotePhase.PREVOTE,
                validatorId = v.validatorId,
                validatorPublicKeyHex = v.publicKeyHex,
                proposedBlockHash = block.hash,
                timestamp = blockTimestamp
            )
            val signedVote = consensusSigner.signVoteWithKeyPair(voteUnsigned, v.keyPair.privateKeyBytes)
            producerNode.consensusCoordinator.engine.submitVote(signedVote, blockTimestamp)
        }
        for (v in validators) {
            val precommitUnsigned = com.example.consensus.model.ConsensusVote(
                chainId = blockchainConfig.chainId,
                protocolVersion = consensusConfig.protocolVersion,
                blockHeight = nextHeight,
                round = 0,
                votePhase = VotePhase.PRECOMMIT,
                validatorId = v.validatorId,
                validatorPublicKeyHex = v.publicKeyHex,
                proposedBlockHash = block.hash,
                timestamp = blockTimestamp
            )
            val signedVote = consensusSigner.signVoteWithKeyPair(precommitUnsigned, v.keyPair.privateKeyBytes)
            val vRes = producerNode.consensusCoordinator.engine.submitVote(signedVote, blockTimestamp)
            if (vRes is com.example.consensus.engine.VoteSubmissionResult.Accepted && vRes.commitCertificate != null) {
                cert = vRes.commitCertificate
            }
        }
        assertNotNull("Expected CommitCertificate for height $nextHeight", cert)
        if (includedTxs.isNotEmpty()) {
            producerNode.txMempool.onBlockCommitted(
                txIds = includedTxs.map { it.txId },
                blockHeight = block.height,
                blockHash = block.hash,
                updatedAtMs = blockTimestamp
            )
        }
        return block to cert!!
    }

    @Test
    fun testStatusExchangeCompatibilityAndNeverTrustingUnverifiedReportedHeight() = runBlocking {
        val validators = createValidators()
        val router = MultiNodeRouterTransport()
        val nodeA = createNode("peerA", validators, MultiNodeRouterTransport())
        val nodeB = createNode("nodeB", validators, router)

        try {
            // Incompatible peer: different chainId claiming absurdly high height 9999
            router.connectPeer("wrong_chain_peer", nodeA.syncManager)
            router.customStatusOverride = { peerId, req ->
                if (peerId == "wrong_chain_peer") {
                    SyncTransportCallResult.Success(
                        ChainStatusExchangeMessage(
                            requestId = req.requestId,
                            chainId = "different-network-99",
                            genesisHash = nodeB.blockchainManager.getGenesisBlock()!!.hash,
                            currentHeight = 9999L,
                            latestBlockHash = "aa".repeat(32),
                            finalizedHeight = 9999L,
                            finalizedBlockHash = "aa".repeat(32),
                            protocolVersion = 1
                        ),
                        12L
                    )
                } else null
            }

            val outcome = nodeB.syncManager.synchronize()
            assertTrue(outcome is SyncCycleOutcome.Failed)
            assertEquals(SyncErrorCode.INCOMPATIBLE_CHAIN_ID, (outcome as SyncCycleOutcome.Failed).errorCode)
            // Crucially: reported high height MUST NOT elevate highestVerifiedPeerHeight or localHeight
            assertEquals(0L, nodeB.syncManager.uiState.value.localHeight)
            assertEquals(0L, nodeB.syncManager.uiState.value.highestVerifiedPeerHeight)
        } finally {
            nodeA.close()
            nodeB.close()
        }
    }

    @Test
    fun testEndToEndMultiNodeSyncWithTransactionsAndBftCertificates() = runBlocking {
        val validators = createValidators()
        val senderKp = crypto.generateEd25519KeyPair()
        val receiverKp = crypto.generateEd25519KeyPair()
        val receiverAddr = NmdAddressCodec.deriveAddressFromPublicKey(receiverKp.publicKeyBytes, crypto)

        val routerA = MultiNodeRouterTransport()
        val nodeA = createNode("nodeA", validators, routerA)

        val t0 = System.currentTimeMillis()
        // Produce 5 real blocks with real signed transactions & >2/3 BFT CommitCertificates on Node A
        for (i in 0 until 5) {
            val tx = createSignedTx(senderKp, receiverAddr, nonce = i.toLong(), amountNmd = "${i + 1}.50", timestampMs = t0 + i * 100L)
            produceAndFinalizeBftBlock(nodeA, validators, includedTxs = listOf(tx), nowMs = t0 + i * 100L)
        }
        assertEquals(5L, nodeA.blockchainManager.getCurrentHeight())

        // Node B starts at genesis (height 0), with bounded batch size = 2 to prove multi-batch loop!
        val routerB = MultiNodeRouterTransport()
        routerB.connectPeer("nodeA", nodeA.syncManager, latencyMs = 15L)
        val nodeB = createNode(
            "nodeB",
            validators,
            routerB,
            syncConfig = SyncConfig(maxHeaderBatchSize = 3, maxBlockBatchSize = 2)
        )

        try {
            val syncOutcome = nodeB.syncManager.synchronize()
            assertTrue("Expected Synced outcome, got $syncOutcome", syncOutcome is SyncCycleOutcome.Synced)
            val synced = syncOutcome as SyncCycleOutcome.Synced
            assertEquals(5L, synced.localHeight)
            assertEquals(5L, synced.syncedBlocksCount)

            val ui = nodeB.syncManager.uiState.value
            assertEquals(SyncStatusState.SYNCED, ui.syncStatus)
            assertEquals(5L, ui.localHeight)
            assertEquals(5L, ui.highestReportedPeerHeight)
            assertEquals(5L, ui.highestVerifiedPeerHeight)
            assertEquals(1f, ui.progressFraction, 0.001f)
            assertNotNull(ui.lastSyncTimestampMs)

            // Every block 0..5 hash on Node B must identically match Node A
            for (h in 0L..5L) {
                assertEquals(
                    nodeA.blockchainManager.getBlockByHeight(h)!!.hash,
                    nodeB.blockchainManager.getBlockByHeight(h)!!.hash
                )
            }
            // Sender nonce must have advanced to 5 on Node B via Stage 12 mempool reconciliation!
            val senderAddr = NmdAddressCodec.deriveAddressFromPublicKey(senderKp.publicKeyBytes, crypto)
            assertEquals(5L, nodeB.txMempool.getConfirmedNextNonce(senderAddr))
        } finally {
            nodeA.close()
            nodeB.close()
        }
    }

    @Test
    fun testAdversarialCorruptedBlocksTransactionsAndCommitCertificatesRejected() = runBlocking {
        val validators = createValidators()
        val senderKp = crypto.generateEd25519KeyPair()
        val receiverKp = crypto.generateEd25519KeyPair()
        val receiverAddr = NmdAddressCodec.deriveAddressFromPublicKey(receiverKp.publicKeyBytes, crypto)

        val nodeA = createNode("honestA", validators, MultiNodeRouterTransport())
        val tx0 = createSignedTx(senderKp, receiverAddr, nonce = 0L)
        val (validBlock, validCert) = produceAndFinalizeBftBlock(nodeA, validators, includedTxs = listOf(tx0))

        val cases = listOf(
            "corrupted_block_hash",
            "bad_previous_hash",
            "bad_merkle_root",
            "bad_tx_signature",
            "insufficient_bft_quorum"
        )

        try {
            for (attack in cases) {
                val router = MultiNodeRouterTransport()
                router.connectPeer("byzantine_peer", nodeA.syncManager)
                val victim = createNode("victim_$attack", validators, router)
                victim.peerRegistry.registerOrUpdatePeer(
                    peerId = "byzantine_peer",
                    endpoint = PeerEndpoint("10.0.0.2", 9000, "byzantine_peer"),
                    source = DiscoverySource.MANUAL
                )

                val tamperedBundle = when (attack) {
                    "corrupted_block_hash" -> SyncBlockBundle(
                        block = validBlock.copy(hash = "ff".repeat(32)),
                        commitCertificate = validCert,
                        transactions = listOf(tx0)
                    )
                    "bad_previous_hash" -> {
                        val h = validBlock.header.copy(previousHash = "cc".repeat(32))
                        SyncBlockBundle(
                            block = validBlock.copy(header = h, hash = blockHasher.computeHeaderHash(h)),
                            commitCertificate = validCert,
                            transactions = listOf(tx0)
                        )
                    }
                    "bad_merkle_root" -> {
                        val h = validBlock.header.copy(merkleRoot = "dd".repeat(32))
                        SyncBlockBundle(
                            block = validBlock.copy(header = h, hash = blockHasher.computeHeaderHash(h)),
                            commitCertificate = validCert,
                            transactions = listOf(tx0)
                        )
                    }
                    "bad_tx_signature" -> SyncBlockBundle(
                        block = validBlock,
                        commitCertificate = validCert,
                        transactions = listOf(tx0.copy(signatureHex = "00".repeat(64)))
                    )
                    else -> SyncBlockBundle(
                        block = validBlock,
                        commitCertificate = validCert.copy(precommitVotes = validCert.precommitVotes.take(1)),
                        transactions = listOf(tx0)
                    )
                }

                // Make header match tamperedBundle so the check specifically exercises full block/tx/cert verifier!
                val tamperedHeader = SyncBlockHeaderEntry(
                    height = tamperedBundle.block.header.height,
                    blockHash = tamperedBundle.block.hash,
                    previousHash = tamperedBundle.block.header.previousHash,
                    timestamp = tamperedBundle.block.header.timestamp,
                    chainId = tamperedBundle.block.header.chainId,
                    protocolVersion = tamperedBundle.block.header.protocolVersion,
                    merkleRoot = tamperedBundle.block.header.merkleRoot,
                    transactionCount = tamperedBundle.block.header.transactionCount,
                    producerId = tamperedBundle.block.header.producerId
                )

                router.customHeadersOverride = { _, req ->
                    SyncTransportCallResult.Success(BlockHeadersResponse(req.requestId, blockchainConfig.chainId, listOf(tamperedHeader)), 5L)
                }
                router.customBlocksOverride = { _, req ->
                    SyncTransportCallResult.Success(BlocksResponse(req.requestId, blockchainConfig.chainId, listOf(tamperedBundle)), 5L)
                }

                val outcome = victim.syncManager.synchronize()
                assertTrue("Attack '$attack' must fail, got $outcome", outcome is SyncCycleOutcome.Failed)
                assertEquals("Victim height must remain 0 after $attack", 0L, victim.blockchainManager.getCurrentHeight())
                assertTrue(victim.peerRegistry.getPeer("byzantine_peer")!!.reputationScore < 50)
                victim.close()
            }
        } finally {
            nodeA.close()
        }
    }

    @Test
    fun testOversizedAndOutOfOrderResponsesRejected() = runBlocking {
        val validators = createValidators()
        val nodeA = createNode("nodeA", validators, MultiNodeRouterTransport())
        produceAndFinalizeBftBlock(nodeA, validators)
        produceAndFinalizeBftBlock(nodeA, validators)

        val router = MultiNodeRouterTransport()
        router.connectPeer("peerA", nodeA.syncManager)
        val nodeB = createNode("nodeB", validators, router, syncConfig = SyncConfig(maxHeaderBatchSize = 1, maxBlockBatchSize = 1, maxResponsePayloadBytes = 64))

        try {
            // Test 1: Oversized status response rejected by wire limit
            router.maxPayloadLimitBytes = 64
            val failOversized = nodeB.syncManager.synchronize()
            assertTrue(failOversized is SyncCycleOutcome.Failed)
            assertEquals(0L, nodeB.blockchainManager.getCurrentHeight())

            // Test 2: Out-of-order header height returned (h=5 when expecting h=1)
            router.maxPayloadLimitBytes = 512 * 1024
            nodeB.syncManager.peerSelector.clearCooldowns()
            val h2 = nodeA.blockchainManager.getBlockByHeight(2L)!!
            router.customHeadersOverride = { _, req ->
                SyncTransportCallResult.Success(
                    BlockHeadersResponse(
                        req.requestId,
                        blockchainConfig.chainId,
                        listOf(
                            SyncBlockHeaderEntry(
                                height = 5L,
                                blockHash = h2.hash,
                                previousHash = h2.previousHash,
                                timestamp = h2.timestamp,
                                chainId = h2.chainId,
                                protocolVersion = h2.header.protocolVersion,
                                merkleRoot = h2.header.merkleRoot,
                                transactionCount = 0,
                                producerId = h2.header.producerId
                            )
                        )
                    ),
                    5L
                )
            }
            val failOrder = nodeB.syncManager.synchronize()
            assertTrue(failOrder is SyncCycleOutcome.Failed)
            assertEquals(SyncErrorCode.INVALID_RESPONSE_ORDER, (failOrder as SyncCycleOutcome.Failed).errorCode)
        } finally {
            nodeA.close()
            nodeB.close()
        }
    }

    @Test
    fun testConflictingFinalizedHistoryHaltsSafelyWithConflictDetected() = runBlocking {
        val validators = createValidators()
        val forkA = createNode("forkA", validators, MultiNodeRouterTransport())
        val forkB = createNode("forkB", validators, MultiNodeRouterTransport())

        val t = System.currentTimeMillis()
        // Both start with identical genesis + height 1
        produceAndFinalizeBftBlock(forkA, validators, extraData = "common_1", nowMs = t)
        val forkBBlock1 = produceAndFinalizeBftBlock(forkB, validators, extraData = "forked_chain_1", nowMs = t + 500L)

        // Fork A builds height 2 on top of forkA's block 1 -> different finalized history!
        produceAndFinalizeBftBlock(forkA, validators, extraData = "common_2", nowMs = t + 1000L)

        // Wire forkB to sync from forkA
        val routerB = MultiNodeRouterTransport()
        routerB.connectPeer("forkA", forkA.syncManager)
        val verifierNodeB = createNode("nodeB_conflict", validators, routerB)
        // Install forkB's finalized block 1 into verifierNodeB
        val (b1, b1Cert) = forkBBlock1
        verifierNodeB.consensusCoordinator.engine.applyVerifiedCommitCertificate(b1Cert, b1, t + 500L)
        verifierNodeB.syncManager.initialize()

        try {
            val outcome = verifierNodeB.syncManager.synchronize()
            assertTrue("Expected ConflictDetected, got $outcome", outcome is SyncCycleOutcome.ConflictDetected)
            val ui = verifierNodeB.syncManager.uiState.value
            assertEquals(SyncStatusState.CONFLICT_DETECTED, ui.syncStatus)
            assertTrue(ui.conflictRecords.isNotEmpty())
            // Must NOT delete or overwrite local finalized block 1!
            assertEquals(b1.hash, verifierNodeB.blockchainManager.getBlockByHeight(1L)!!.hash)
            assertEquals(1L, verifierNodeB.blockchainManager.getCurrentHeight())
        } finally {
            forkA.close()
            forkB.close()
            verifierNodeB.close()
        }
    }

    @Test
    fun testInterruptedSyncAndAppRestartResumesFromVerifiedCheckpoint() = runBlocking {
        val validators = createValidators()
        val routerA = MultiNodeRouterTransport()
        val nodeA = createNode("nodeA", validators, routerA)
        val t0 = System.currentTimeMillis()
        repeat(4) { i ->
            produceAndFinalizeBftBlock(nodeA, validators, extraData = "blk_$i", nowMs = t0 + i * 100L)
        }

        // Start Node B with persistent Room DBs; disconnect peer after height 2!
        val router1 = MultiNodeRouterTransport()
        router1.connectPeer("peerA", nodeA.syncManager)
        router1.customBlocksOverride = { _, req ->
            if (req.fromHeight >= 3L) {
                SyncTransportCallResult.Failure("Simulated mid-sync socket drop", isDisconnected = true)
            } else null
        }

        val nodeB1 = createNode(
            "nodeB",
            validators,
            router1,
            syncConfig = SyncConfig(maxHeaderBatchSize = 4, maxBlockBatchSize = 2),
            inMemory = false,
            dbPrefix = "s12_resume"
        )
        // Rename helper note: createNode uses ${dbPrefix}_chain_${nodeId}.db; track cleanup cleanly:
        val firstRun = nodeB1.syncManager.synchronize()
        assertTrue(firstRun is SyncCycleOutcome.Failed)
        // Heights 1 and 2 must be committed & checkpointed!
        assertEquals(2L, nodeB1.blockchainManager.getCurrentHeight())
        nodeB1.close()

        // Simulate app restart with fresh persistent Node B instance & restored network
        val router2 = MultiNodeRouterTransport()
        router2.connectPeer("peerA", nodeA.syncManager)
        val nodeB2 = createNode(
            "nodeB",
            validators,
            router2,
            syncConfig = SyncConfig(maxHeaderBatchSize = 4, maxBlockBatchSize = 2),
            inMemory = false,
            dbPrefix = "s12_resume"
        )
        try {
            assertEquals(2L, nodeB2.syncManager.uiState.value.localHeight)
            val resumeOutcome = nodeB2.syncManager.synchronize()
            assertTrue("Expected resumed sync to succeed, got $resumeOutcome", resumeOutcome is SyncCycleOutcome.Synced)
            assertEquals(4L, nodeB2.blockchainManager.getCurrentHeight())
            assertEquals(SyncStatusState.SYNCED, nodeB2.syncManager.uiState.value.syncStatus)
            // Crucially: verify nodeB2 started header & block requests from height 3 (did NOT re-download 1..2!)
            assertTrue(router2.requestedHeaderFromHeights.all { it.second >= 3L })
            assertTrue(router2.requestedBlockFromHeights.all { it.second >= 3L })
        } finally {
            nodeB2.close()
            nodeA.close()
            listOf("chain", "tx", "cons", "sync").forEach { kind ->
                context.deleteDatabase("s12_resume_${kind}_nodeB.db")
            }
        }
    }

    @Test
    fun testPeerTimeoutAndDisconnectionSwitchesAutomaticallyToHealthyFallbackPeer() = runBlocking {
        val validators = createValidators()
        val healthyPeer = createNode("healthyPeer", validators, MultiNodeRouterTransport())
        val flakeyPeer = createNode("flakeyPeer", validators, MultiNodeRouterTransport())

        val t0 = System.currentTimeMillis()
        repeat(3) { i ->
            val (b, c) = produceAndFinalizeBftBlock(healthyPeer, validators, extraData = "block_$i", nowMs = t0 + i * 100L)
            flakeyPeer.consensusCoordinator.engine.applyVerifiedCommitCertificate(c, b, t0 + i * 100L)
        }

        val router = MultiNodeRouterTransport()
        // flakeyPeer has lower latency initially so it is picked first, but its block request times out!
        router.connectPeer("flakeyPeer", flakeyPeer.syncManager, latencyMs = 5L)
        router.connectPeer("healthyPeer", healthyPeer.syncManager, latencyMs = 25L)
        router.customBlocksOverride = { peerId, _ ->
            if (peerId == "flakeyPeer") {
                SyncTransportCallResult.Failure("Timed out waiting for block response", isTimeout = true)
            } else null
        }

        val nodeB = createNode("nodeB", validators, router)
        try {
            val outcome = nodeB.syncManager.synchronize()
            assertTrue("Expected automatic peer switch to complete sync, got $outcome", outcome is SyncCycleOutcome.Synced)
            assertEquals(3L, nodeB.blockchainManager.getCurrentHeight())
            val flakeyState = nodeB.syncManager.peerSelector.getAllPeerStates().first { it.peerId == "flakeyPeer" }
            assertTrue(flakeyState.consecutiveFailures >= 1)
            assertEquals(3L, nodeB.syncManager.uiState.value.highestVerifiedPeerHeight)
        } finally {
            healthyPeer.close()
            flakeyPeer.close()
            nodeB.close()
        }
    }

    @Test
    fun testDuplicateSyncExecutionPreventedAndMempoolReconciliationWorks() = runBlocking {
        val validators = createValidators()
        val aliceKp = crypto.generateEd25519KeyPair()
        val aliceAddr = NmdAddressCodec.deriveAddressFromPublicKey(aliceKp.publicKeyBytes, crypto)
        val bobKp = crypto.generateEd25519KeyPair()
        val bobAddr = NmdAddressCodec.deriveAddressFromPublicKey(bobKp.publicKeyBytes, crypto)

        val now = System.currentTimeMillis()
        // Synced tx at nonce 0 on Alice -> Bob
        val syncedTx0 = createSignedTx(aliceKp, bobAddr, nonce = 0L, amountNmd = "3.00", timestampMs = now)
        // Competing local stale tx at nonce 0 on Alice (different recipient) & valid future pending tx at nonce 1!
        val competingLocalTx0 = createSignedTx(aliceKp, aliceAddr, nonce = 0L, amountNmd = "1.00", timestampMs = now + 10L)
        val validPendingTx1 = createSignedTx(aliceKp, bobAddr, nonce = 1L, amountNmd = "2.00", timestampMs = now + 20L)

        val nodeA = createNode("nodeA", validators, MultiNodeRouterTransport())
        produceAndFinalizeBftBlock(nodeA, validators, includedTxs = listOf(syncedTx0), nowMs = now)

        val slowRouter = MultiNodeRouterTransport()
        slowRouter.connectPeer("nodeA", nodeA.syncManager)
        var delayedOnce = false
        slowRouter.customHeadersOverride = { _, _ ->
            if (!delayedOnce) {
                delayedOnce = true
                delay(200L)
            }
            null
        }

        val nodeB = createNode("nodeB", validators, slowRouter)
        try {
            // Submit competing local nonce=0 and queued nonce=1 on Node B before syncing
            assertTrue(nodeB.txMempool.submitTransaction(competingLocalTx0, nowMs = now + 25L) is MempoolSubmissionResult.Accepted)
            assertTrue(nodeB.txMempool.submitTransaction(validPendingTx1, nowMs = now + 30L) is MempoolSubmissionResult.Accepted)

            // Launch concurrent sync attempts -> second must return AlreadyRunning cleanly
            val job1 = async { nodeB.syncManager.synchronize() }
            delay(30L)
            val job2 = async { nodeB.syncManager.synchronize() }

            val out2 = job2.await()
            val out1 = job1.await()
            assertTrue(out2 is SyncCycleOutcome.AlreadyRunning)
            assertTrue(out1 is SyncCycleOutcome.Synced)

            // Mempool reconciliation checks:
            val confirmedRec = nodeB.txMempool.getByTxId(syncedTx0.txId)
            val staleCompetingRec = nodeB.txMempool.getByTxId(competingLocalTx0.txId)
            val pendingNextRec = nodeB.txMempool.getByTxId(validPendingTx1.txId)

            assertEquals(1L, nodeB.txMempool.getConfirmedNextNonce(aliceAddr))
            assertEquals(MempoolTxStatus.CONFIRMED, confirmedRec?.status)
            assertEquals(MempoolTxStatus.REJECTED, staleCompetingRec?.status)
            assertEquals(MempoolTxStatus.VALIDATED, pendingNextRec?.status)
        } finally {
            nodeA.close()
            nodeB.close()
        }
    }

    @Test
    fun testMobileBatteryRamNetworkThermalGuardsAndUserPauseResumeControls() = runBlocking {
        val validators = createValidators()
        val nodeA = createNode("nodeA", validators, MultiNodeRouterTransport())
        produceAndFinalizeBftBlock(nodeA, validators)

        val router = MultiNodeRouterTransport()
        router.connectPeer("nodeA", nodeA.syncManager)
        val nodeB = createNode("nodeB", validators, router)

        try {
            // 1. Low battery (not charging) pauses sync cleanly
            val lowBattery = DeviceTelemetry(batteryPercent = 10, isCharging = false, networkType = "Wi-Fi", availableRamMb = 1024)
            val lowBatRes = nodeB.syncManager.synchronize(telemetry = lowBattery)
            assertTrue(lowBatRes is SyncCycleOutcome.Paused)
            assertEquals(SyncErrorCode.MOBILE_RESOURCE_PAUSED, (lowBatRes as SyncCycleOutcome.Paused).errorCode)

            // 2. Offline network pauses sync cleanly
            val offline = DeviceTelemetry(batteryPercent = 80, isCharging = false, networkType = "Offline", availableRamMb = 1024)
            val offlineRes = nodeB.syncManager.synchronize(telemetry = offline)
            assertTrue(offlineRes is SyncCycleOutcome.Paused)
            assertEquals(SyncErrorCode.MOBILE_RESOURCE_PAUSED, (offlineRes as SyncCycleOutcome.Paused).errorCode)

            // 3. Low RAM pauses sync cleanly
            val lowRam = DeviceTelemetry(batteryPercent = 80, isCharging = false, networkType = "Wi-Fi", availableRamMb = 64, isLowRam = true)
            val lowRamRes = nodeB.syncManager.synchronize(telemetry = lowRam)
            assertTrue(lowRamRes is SyncCycleOutcome.Paused)

            // 4. Severe thermal throttling pauses sync cleanly
            val okTelemetry = DeviceTelemetry(batteryPercent = 85, isCharging = true, networkType = "Wi-Fi", availableRamMb = 2048)
            val thermalRes = nodeB.syncManager.synchronize(telemetry = okTelemetry, thermalSevere = true)
            assertTrue(thermalRes is SyncCycleOutcome.Paused)

            // 5. User pause / resume controls
            nodeB.syncManager.pauseSync()
            val userPausedRes = nodeB.syncManager.synchronize(telemetry = okTelemetry, thermalSevere = false)
            assertTrue(userPausedRes is SyncCycleOutcome.Paused)
            assertEquals(SyncErrorCode.PAUSED_BY_USER, (userPausedRes as SyncCycleOutcome.Paused).errorCode)
            assertEquals(0L, nodeB.blockchainManager.getCurrentHeight())

            nodeB.syncManager.resumeSync()
            val resumedRes = nodeB.syncManager.synchronize(telemetry = okTelemetry, thermalSevere = false)
            assertTrue(resumedRes is SyncCycleOutcome.Synced)
            assertEquals(1L, nodeB.blockchainManager.getCurrentHeight())
        } finally {
            nodeA.close()
            nodeB.close()
        }
    }
}
