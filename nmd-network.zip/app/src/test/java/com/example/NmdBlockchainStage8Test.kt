package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.config.BlockchainParameters
import com.example.blockchain.config.NmdGenesisConfigs
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.crypto.CanonicalBlockSerializer
import com.example.blockchain.crypto.MerkleTree
import com.example.blockchain.genesis.GenesisBlockFactory
import com.example.blockchain.manager.BlockIngestionResult
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.blockchain.model.BlockchainDbStatus
import com.example.blockchain.model.StructuralValidationStatus
import com.example.blockchain.model.TransactionReference
import com.example.blockchain.p2p.DefaultBlockchainPeerSyncGateway
import com.example.blockchain.storage.BlockchainDatabase
import com.example.blockchain.storage.RoomBlockchainStorage
import com.example.blockchain.validation.BlockValidationResult
import com.example.blockchain.validation.BlockValidator
import com.example.blockchain.validation.ConsensusValidationHook
import com.example.blockchain.validation.ValidationErrorCode
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerCapability
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.model.PeerEndpoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Automated verification suite for Stage 8: NMD Blockchain Core Foundation.
 *
 * Covers:
 * 1. Deterministic Genesis Block creation across independent nodes & environments.
 * 2. Canonical binary block serialization & SHA-256 hashing verification.
 * 3. Domain-separated Merkle tree root calculation & SPV proof generation/verification.
 * 4. Structural & cryptographic BlockValidator positive and negative test cases
 *    (plus clean separation of ConsensusValidationHook).
 * 5. Duplicate block rejection and broken previousHash chain rejection.
 * 6. Persistent Room SQLite database persistence, indexed single-block queries,
 *    restart recovery, and database corruption detection.
 * 7. Stage 7 P2P integration bridge zero-trust validation and peer reputation penalties.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdBlockchainStage8Test {

    private lateinit var context: Context
    private lateinit var testScope: CoroutineScope
    private val cryptoProvider = BouncyCastleEd25519Provider()
    private val blockHasher = BlockHasher(cryptoProvider)
    private val genesisFactory = GenesisBlockFactory(blockHasher)

    private val persistentDbNames = listOf(
        "test_stage8_persistent_a.db",
        "test_stage8_persistent_b.db",
        "test_stage8_tamper.db"
    )

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testScope = CoroutineScope(Dispatchers.IO + Job())
        cleanupTestArtifacts()
    }

    @After
    fun tearDown() {
        testScope.cancel()
        cleanupTestArtifacts()
    }

    private fun cleanupTestArtifacts() {
        persistentDbNames.forEach { dbName ->
            context.deleteDatabase(dbName)
        }
        context.getSharedPreferences("nmd_p2p_registry", Context.MODE_PRIVATE).edit().clear().commit()
    }

    private fun buildValidChildBlock(
        parent: Block,
        txRefs: List<TransactionReference> = emptyList(),
        extraData: String = "block-${parent.height + 1}",
        timestamp: Long = parent.timestamp + 5_000L,
        producerId: String = "nmd_test_producer_1",
        protocolVersion: Int = parent.header.protocolVersion,
        chainId: String = parent.chainId,
        consensusMetadata: String = ""
    ): Block {
        val body = BlockBody(transactionRefs = txRefs, extraData = extraData)
        val merkleRoot = blockHasher.computeBodyMerkleRoot(body)
        val header = BlockHeader(
            height = parent.height + 1L,
            previousHash = parent.hash,
            timestamp = timestamp,
            chainId = chainId,
            protocolVersion = protocolVersion,
            merkleRoot = merkleRoot,
            transactionCount = txRefs.size,
            producerId = producerId,
            consensusMetadata = consensusMetadata
        )
        val hash = blockHasher.computeHeaderHash(header)
        return Block(header = header, body = body, hash = hash)
    }

    private fun makeTxHash(seed: String): String {
        return cryptoProvider.toHex(cryptoProvider.sha256(seed.toByteArray(Charsets.UTF_8)))
    }

    // 1. Genesis determinism & multi-environment separation
    @Test
    fun genesisBlock_isDeterministicAcrossNodesAndDistinctPerEnvironment() = runBlocking {
        val configA = BlockchainConfig(genesisConfig = NmdGenesisConfigs.LOCAL_DEV)
        val configB = BlockchainConfig(genesisConfig = NmdGenesisConfigs.LOCAL_DEV)
        val configTestnet = BlockchainConfig(genesisConfig = NmdGenesisConfigs.PRIVATE_TESTNET)

        val managerA = BlockchainManager(context, configA, inMemoryStorage = true)
        val managerB = BlockchainManager(context, configB, inMemoryStorage = true)
        val managerTestnet = BlockchainManager(context, configTestnet, inMemoryStorage = true)

        try {
            val stateA = managerA.initialize().getOrThrow()
            val stateB = managerB.initialize().getOrThrow()
            val stateTestnet = managerTestnet.initialize().getOrThrow()

            val genesisA = managerA.getGenesisBlock()!!
            val genesisB = managerB.getGenesisBlock()!!
            val genesisTestnet = managerTestnet.getGenesisBlock()!!

            assertTrue(stateA.isInitialized)
            assertTrue(stateA.isLocalDevelopmentChain)
            assertEquals(0L, stateA.currentHeight)
            assertEquals(1L, stateA.storedBlockCount)
            assertEquals(BlockchainDbStatus.READY, stateA.dbStatus)
            assertEquals(StructuralValidationStatus.VALID, stateA.structuralValidationStatus)

            // Same genesis config on independent nodes produces identical genesis hash & state
            assertEquals(genesisA.hash, genesisB.hash)
            assertEquals(stateA.genesisHash, stateB.genesisHash)
            assertEquals(BlockHeader.GENESIS_PREVIOUS_HASH, genesisA.previousHash)
            assertEquals(0L, genesisA.height)
            assertTrue(blockHasher.verifyBlockHash(genesisA))
            assertTrue(blockHasher.verifyMerkleRoot(genesisA))
            assertTrue(genesisFactory.validateGenesisBlock(genesisA, NmdGenesisConfigs.LOCAL_DEV).isValid)

            // Different environment preset produces a distinct genesis hash & chainId
            assertNotEquals(genesisA.hash, genesisTestnet.hash)
            assertEquals(NmdGenesisConfigs.PRIVATE_TESTNET.chainId, genesisTestnet.chainId)
            assertFalse(stateTestnet.isLocalDevelopmentChain)
            assertFalse(genesisFactory.validateGenesisBlock(genesisA, NmdGenesisConfigs.PRIVATE_TESTNET).isValid)
        } finally {
            managerA.close()
            managerB.close()
            managerTestnet.close()
        }
    }

    // 2. Canonical binary serialization & SHA-256 hashing verification
    @Test
    fun canonicalSerializationAndBlockHashing_areDeterministicAndTamperEvident() {
        val genesis = genesisFactory.createGenesisBlock(NmdGenesisConfigs.LOCAL_DEV)
        val child1 = buildValidChildBlock(
            parent = genesis,
            txRefs = listOf(
                TransactionReference(makeTxHash("tx-1"), 0, "TRANSFER_REF"),
                TransactionReference(makeTxHash("tx-2"), 1, "TRANSFER_REF")
            )
        )
        val child2 = buildValidChildBlock(
            parent = genesis,
            txRefs = listOf(
                TransactionReference(makeTxHash("tx-1"), 0, "TRANSFER_REF"),
                TransactionReference(makeTxHash("tx-2"), 1, "TRANSFER_REF")
            )
        )

        val bytes1 = CanonicalBlockSerializer.serializeHeader(child1.header)
        val bytes2 = CanonicalBlockSerializer.serializeHeader(child2.header)
        assertArrayEquals(bytes1, bytes2)
        assertEquals(child1.hash, child2.hash)
        assertTrue(BlockHasher.isValidSha256Hex(child1.hash))
        assertTrue(blockHasher.verifyBlockHash(child1))

        // Mutating any header field changes canonical serialization & invalidates hash
        val tamperedHeader = child1.header.copy(timestamp = child1.header.timestamp + 1L)
        assertFalse(bytes1.contentEquals(CanonicalBlockSerializer.serializeHeader(tamperedHeader)))
        val tamperedBlock = child1.copy(header = tamperedHeader)
        assertFalse(blockHasher.verifyBlockHash(tamperedBlock))
    }

    // 3. Domain-separated Merkle tree root & SPV proof verification
    @Test
    fun merkleTree_computesRootsAndVerifiesSpvProofsCorrectly() {
        // Empty root is deterministic
        val emptyRootA = MerkleTree.computeRoot(emptyList(), cryptoProvider)
        val emptyRootB = MerkleTree.computeRoot(emptyList(), cryptoProvider)
        assertEquals(emptyRootA, emptyRootB)
        assertTrue(BlockHasher.isValidSha256Hex(emptyRootA))

        // Odd number of leaves (3) exercises odd-leaf duplication
        val leaves = listOf(
            makeTxHash("alpha"),
            makeTxHash("beta"),
            makeTxHash("gamma")
        )
        val root = MerkleTree.computeRoot(leaves, cryptoProvider)
        assertNotEquals(emptyRootA, root)

        for (i in leaves.indices) {
            val proof = MerkleTree.generateProof(leaves, i, cryptoProvider)
            assertNotNull(proof)
            assertTrue(MerkleTree.verifyProof(proof!!, cryptoProvider))

            // Tampering leaf hash or root hash fails SPV proof verification
            assertFalse(MerkleTree.verifyProof(proof.copy(leafHashHex = makeTxHash("forged")), cryptoProvider))
            assertFalse(MerkleTree.verifyProof(proof.copy(rootHashHex = makeTxHash("wrong-root")), cryptoProvider))
        }

        assertNull(MerkleTree.generateProof(leaves, -1, cryptoProvider))
        assertNull(MerkleTree.generateProof(leaves, 3, cryptoProvider))
    }

    // 4. Structural BlockValidator negative/positive checks + Consensus hook separation
    @Test
    fun blockValidator_enforcesAllStructuralRulesAndSeparatesConsensusHook() {
        val config = BlockchainConfig(
            genesisConfig = NmdGenesisConfigs.LOCAL_DEV.copy(
                parameters = BlockchainParameters(
                    protocolVersion = 1,
                    maxBlockSizeBytes = 2048,
                    maxTransactionsPerBlock = 20,
                    maxFutureTimestampDriftMs = 60_000L
                )
            )
        )
        val validator = BlockValidator(config, blockHasher)
        val genesis = genesisFactory.createGenesisBlock(config.genesisConfig)
        val baseNow = genesis.timestamp + 10_000L

        val validBlock = buildValidChildBlock(
            parent = genesis,
            txRefs = listOf(TransactionReference(makeTxHash("tx-ok"), 0)),
            timestamp = genesis.timestamp + 5_000L
        )

        // Valid structural-only result
        val validResult = validator.validateBlock(validBlock, genesis, nowMs = baseNow)
        assertTrue(validResult is BlockValidationResult.Valid)
        validResult as BlockValidationResult.Valid
        assertTrue(validResult.structuralValidated)
        assertFalse(validResult.consensusValidated)

        // Invalid hash
        val badHash = validBlock.copy(hash = "f".repeat(64))
        assertEquals(
            ValidationErrorCode.INVALID_HASH,
            (validator.validateBlock(badHash, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Invalid Merkle root
        val badMerkleHeader = validBlock.header.copy(merkleRoot = "a".repeat(64))
        val badMerkle = Block(badMerkleHeader, validBlock.body, blockHasher.computeHeaderHash(badMerkleHeader))
        assertEquals(
            ValidationErrorCode.INVALID_MERKLE_ROOT,
            (validator.validateBlock(badMerkle, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Invalid previousHash
        val badPrevHeader = validBlock.header.copy(previousHash = "b".repeat(64))
        val badPrev = Block(badPrevHeader, validBlock.body, blockHasher.computeHeaderHash(badPrevHeader))
        assertEquals(
            ValidationErrorCode.INVALID_PREVIOUS_HASH,
            (validator.validateBlock(badPrev, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Non-sequential height
        val badHeightHeader = validBlock.header.copy(height = 5L)
        val badHeight = Block(badHeightHeader, validBlock.body, blockHasher.computeHeaderHash(badHeightHeader))
        assertEquals(
            ValidationErrorCode.INVALID_HEIGHT,
            (validator.validateBlock(badHeight, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Wrong chainId
        val badChainHeader = validBlock.header.copy(chainId = "other-chain")
        val badChain = Block(badChainHeader, validBlock.body, blockHasher.computeHeaderHash(badChainHeader))
        assertEquals(
            ValidationErrorCode.INVALID_CHAIN_ID,
            (validator.validateBlock(badChain, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Unsupported protocol version
        val badProtoHeader = validBlock.header.copy(protocolVersion = 99)
        val badProto = Block(badProtoHeader, validBlock.body, blockHasher.computeHeaderHash(badProtoHeader))
        assertEquals(
            ValidationErrorCode.UNSUPPORTED_PROTOCOL_VERSION,
            (validator.validateBlock(badProto, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Invalid timestamp (precedes parent and excessive future drift)
        val pastTsBlock = buildValidChildBlock(parent = genesis, timestamp = genesis.timestamp - 1L)
        assertEquals(
            ValidationErrorCode.INVALID_TIMESTAMP,
            (validator.validateBlock(pastTsBlock, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )
        val futureTsBlock = buildValidChildBlock(parent = genesis, timestamp = baseNow + 120_000L)
        assertEquals(
            ValidationErrorCode.INVALID_TIMESTAMP,
            (validator.validateBlock(futureTsBlock, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Transaction count mismatch
        val txMismatchHeader = validBlock.header.copy(transactionCount = 99)
        val txMismatch = Block(txMismatchHeader, validBlock.body, blockHasher.computeHeaderHash(txMismatchHeader))
        assertEquals(
            ValidationErrorCode.TX_COUNT_MISMATCH,
            (validator.validateBlock(txMismatch, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Oversized block (> 2048 bytes limit set above)
        val oversizedBlock = buildValidChildBlock(
            parent = genesis,
            extraData = "X".repeat(3000),
            timestamp = genesis.timestamp + 5_000L
        )
        assertEquals(
            ValidationErrorCode.BLOCK_TOO_LARGE,
            (validator.validateBlock(oversizedBlock, genesis, nowMs = baseNow) as BlockValidationResult.Invalid).code
        )

        // Clean separation check: custom ConsensusValidationHook evaluates consensus metadata independently
        val rejectingConsensusHook = object : ConsensusValidationHook {
            override fun validateConsensusMetadata(block: Block, parentBlock: Block?): BlockValidationResult {
                return if (block.header.consensusMetadata == "VALID_QUORUM") {
                    BlockValidationResult.Valid(structuralValidated = true, consensusValidated = true)
                } else {
                    BlockValidationResult.Invalid(
                        ValidationErrorCode.CONSENSUS_REJECTED,
                        "Missing quorum proof"
                    )
                }
            }
        }
        val noConsensusRes = validator.validateBlock(validBlock, genesis, nowMs = baseNow, consensusHook = rejectingConsensusHook)
        assertEquals(
            ValidationErrorCode.CONSENSUS_REJECTED,
            (noConsensusRes as BlockValidationResult.Invalid).code
        )

        val withConsensusBlock = buildValidChildBlock(
            parent = genesis,
            timestamp = genesis.timestamp + 5_000L,
            consensusMetadata = "VALID_QUORUM"
        )
        val acceptedConsensusRes = validator.validateBlock(
            withConsensusBlock,
            genesis,
            nowMs = baseNow,
            consensusHook = rejectingConsensusHook
        ) as BlockValidationResult.Valid
        assertTrue(acceptedConsensusRes.structuralValidated)
        assertTrue(acceptedConsensusRes.consensusValidated)
    }

    // 5. Duplicate block & broken chain rejection via BlockchainManager
    @Test
    fun blockchainManager_rejectsDuplicatesAndBrokenChainLinks() = runBlocking {
        val manager = BlockchainManager(
            context = context,
            config = BlockchainConfig(genesisConfig = NmdGenesisConfigs.LOCAL_DEV),
            inMemoryStorage = true
        )
        try {
            manager.initialize().getOrThrow()
            val genesis = manager.getGenesisBlock()!!
            val nowMs = genesis.timestamp + 20_000L

            val block1 = buildValidChildBlock(parent = genesis, timestamp = genesis.timestamp + 5_000L)
            val res1 = manager.submitIncomingBlock(block1, nowMs = nowMs)
            assertTrue(res1 is BlockIngestionResult.Accepted)
            assertEquals(1L, manager.getCurrentHeight())

            // Duplicate identical block -> rejected as Duplicate
            val dupRes = manager.submitIncomingBlock(block1, nowMs = nowMs)
            assertTrue(dupRes is BlockIngestionResult.Duplicate)

            // Different block at already occupied height 1 -> Duplicate
            val forkHeight1 = buildValidChildBlock(
                parent = genesis,
                extraData = "fork-block-1",
                timestamp = genesis.timestamp + 6_000L
            )
            assertTrue(manager.submitIncomingBlock(forkHeight1, nowMs = nowMs) is BlockIngestionResult.Duplicate)

            // Block 2 with broken previousHash (pointing to genesis instead of block1) -> Rejected
            val badLinkHeader = BlockHeader(
                height = 2L,
                previousHash = genesis.hash,
                timestamp = block1.timestamp + 5_000L,
                chainId = genesis.chainId,
                protocolVersion = genesis.header.protocolVersion,
                merkleRoot = blockHasher.computeBodyMerkleRoot(BlockBody()),
                transactionCount = 0,
                producerId = "producer_x"
            )
            val badLinkBlock = Block(badLinkHeader, BlockBody(), blockHasher.computeHeaderHash(badLinkHeader))
            val badLinkRes = manager.submitIncomingBlock(badLinkBlock, nowMs = nowMs)
            assertTrue(badLinkRes is BlockIngestionResult.Rejected)
            assertEquals(ValidationErrorCode.INVALID_PREVIOUS_HASH, (badLinkRes as BlockIngestionResult.Rejected).code)

            // Skipped height (height 3 when tip is 1) -> Rejected
            val skippedBlock = buildValidChildBlock(parent = block1, timestamp = block1.timestamp + 5_000L).let { b ->
                val h = b.header.copy(height = 3L)
                b.copy(header = h, hash = blockHasher.computeHeaderHash(h))
            }
            val skippedRes = manager.submitIncomingBlock(skippedBlock, nowMs = nowMs)
            assertTrue(skippedRes is BlockIngestionResult.Rejected)
            assertEquals(ValidationErrorCode.INVALID_HEIGHT, (skippedRes as BlockIngestionResult.Rejected).code)
        } finally {
            manager.close()
        }
    }

    // 6. Real persistent Room SQLite persistence, restart recovery, and corruption detection
    @Test
    fun roomPersistentStorage_persistsBlocksAcrossRestartsAndDetectsCorruption() = runBlocking {
        val dbName = "test_stage8_persistent_a.db"
        val config = BlockchainConfig(
            genesisConfig = NmdGenesisConfigs.LOCAL_DEV,
            databaseName = dbName
        )

        // Session 1: Create fresh chain, append 2 sequential blocks, close manager
        val session1 = BlockchainManager(context, config, inMemoryStorage = false)
        val genesisHash: String
        val block1Hash: String
        val block2Hash: String

        try {
            val initState = session1.initialize().getOrThrow()
            assertEquals(1L, initState.storedBlockCount)

            val genesis = session1.getGenesisBlock()!!
            genesisHash = genesis.hash

            val block1 = buildValidChildBlock(
                parent = genesis,
                txRefs = listOf(TransactionReference(makeTxHash("persistent-tx-1"), 0)),
                timestamp = genesis.timestamp + 4_000L
            )
            val block2 = buildValidChildBlock(
                parent = block1,
                txRefs = listOf(
                    TransactionReference(makeTxHash("persistent-tx-2"), 0),
                    TransactionReference(makeTxHash("persistent-tx-3"), 1)
                ),
                timestamp = block1.timestamp + 4_000L
            )

            val nowMs = genesis.timestamp + 30_000L
            assertTrue(session1.submitIncomingBlock(block1, nowMs = nowMs) is BlockIngestionResult.Accepted)
            assertTrue(session1.submitIncomingBlock(block2, nowMs = nowMs) is BlockIngestionResult.Accepted)

            block1Hash = block1.hash
            block2Hash = block2.hash

            // Single-block indexed lookup queries
            assertEquals(block1Hash, session1.getBlockByHeight(1L)?.hash)
            assertEquals(2L, session1.getBlockByHash(block2Hash)?.height)
            assertEquals(2L, session1.getTipContext()?.nextHeight?.minus(1L))
        } finally {
            session1.close()
        }

        // Session 2: Restart recovery against the same persistent SQLite file
        val session2 = BlockchainManager(context, config, inMemoryStorage = false)
        try {
            val recoveredState = session2.initialize().getOrThrow()
            assertTrue(recoveredState.isInitialized)
            assertEquals(genesisHash, recoveredState.genesisHash)
            assertEquals(2L, recoveredState.currentHeight)
            assertEquals(block2Hash, recoveredState.latestBlockHash)
            assertEquals(3L, recoveredState.storedBlockCount)
            assertEquals(BlockchainDbStatus.READY, recoveredState.dbStatus)
            assertEquals(StructuralValidationStatus.VALID, recoveredState.structuralValidationStatus)

            val integrity = session2.verifyIntegrity()
            assertTrue(integrity.isHealthy)
            assertEquals(3L, integrity.verifiedBlocksCount)
            assertTrue(integrity.genesisHashMatches)
        } finally {
            session2.close()
        }

        // Session 3: Direct SQLite row corruption detection
        val tamperDb = BlockchainDatabase.buildPersistent(context, dbName)
        try {
            val corrupted = tamperDb.blockchainDao().getBlockByHeight(1L)!!
            // Overwrite stored block row at height 1 with mismatched merkleRoot without updating hash
            tamperDb.openHelper.writableDatabase.execSQL(
                "UPDATE blockchain_blocks SET merkleRoot = ? WHERE height = 1",
                arrayOf("c".repeat(64))
            )
            assertNotNull(corrupted)
        } finally {
            tamperDb.close()
        }

        val session3 = BlockchainManager(context, config, inMemoryStorage = false)
        try {
            val initCorruptedResult = session3.initialize()
            assertTrue(initCorruptedResult.isFailure)
            assertFalse(session3.chainState.value.isInitialized)
            assertEquals(BlockchainDbStatus.CORRUPTED, session3.chainState.value.dbStatus)
            assertEquals(StructuralValidationStatus.INVALID, session3.chainState.value.structuralValidationStatus)

            val report = session3.verifyIntegrity()
            assertFalse(report.isHealthy)
            assertTrue(report.issues.isNotEmpty())
        } finally {
            session3.close()
        }
    }

    // 7. Stage 7 P2P integration interface & zero-trust behavior
    @Test
    fun p2pSyncGateway_enforcesZeroTrustValidationAndPenalizesBadPeers() = runBlocking {
        val manager = BlockchainManager(
            context = context,
            config = BlockchainConfig(genesisConfig = NmdGenesisConfigs.LOCAL_DEV),
            inMemoryStorage = true
        )
        val registry = DistributedPeerRegistry(
            context = null,
            scope = testScope,
            ioDispatcher = Dispatchers.IO
        )

        try {
            manager.initialize().getOrThrow()
            val genesis = manager.getGenesisBlock()!!
            val gateway = DefaultBlockchainPeerSyncGateway(manager, registry)

            val authPeerId = "node_auth_peer_1"
            val unauthPeerId = "node_unauth_peer_2"

            registry.registerOrUpdatePeer(
                peerId = authPeerId,
                endpoint = PeerEndpoint("192.168.1.25", 9876, authPeerId),
                source = DiscoverySource.PEER_EXCHANGE,
                publicKeyHex = "ab".repeat(32),
                reachability = ReachabilityStatus.CONNECTED,
                capabilities = listOf(PeerCapability.STAGE7_DISCOVERY, PeerCapability.BLOCK_SYNC)
            )
            registry.recordSuccessfulAuth(authPeerId, "ab".repeat(32))

            registry.registerOrUpdatePeer(
                peerId = unauthPeerId,
                endpoint = PeerEndpoint("192.168.1.26", 9876, unauthPeerId),
                source = DiscoverySource.PEER_EXCHANGE,
                reachability = ReachabilityStatus.CONNECTED
            )

            // Only authenticated & connected sync peers appear
            val syncPeers = gateway.identifySyncCapablePeers()
            assertEquals(1, syncPeers.size)
            assertEquals(authPeerId, syncPeers.first().peerId)

            // Status summary and missing block request metadata work cleanly
            val status = gateway.getLocalChainStatus()
            assertNotNull(status)
            assertEquals(0L, status!!.height)
            assertEquals(genesis.hash, status.genesisHash)

            val req = gateway.createMissingBlocksRequest(fromHeight = 1L, maxBlocks = 100)
            assertEquals(1L, req.fromHeight)
            assertEquals(32, req.maxBlocks) // bounded

            // Create block timestamped cleanly within default System.currentTimeMillis() drift or test genesis?
            // Note: genesis timestamp is 2025-01-01, so a block with System.currentTimeMillis() timestamp
            // satisfies both >= genesis.timestamp and <= nowMs + maxFutureTimestampDriftMs!
            val liveNowMs = System.currentTimeMillis()
            val validBlock1 = buildValidChildBlock(
                parent = genesis,
                txRefs = listOf(TransactionReference(makeTxHash("p2p-tx-1"), 0)),
                timestamp = liveNowMs
            )

            // Reject block from unauthenticated peer even if block itself is cryptographically valid
            val unauthResult = gateway.handleIncomingBlockPayload(
                fromPeerId = unauthPeerId,
                rawBlockJson = validBlock1.toStorageJson()
            )
            assertTrue(unauthResult is BlockIngestionResult.Rejected)
            assertEquals(0L, manager.getCurrentHeight())

            // Accept valid block from authenticated peer after passing full structural validation
            val authAcceptResult = gateway.handleIncomingBlockPayload(
                fromPeerId = authPeerId,
                rawBlockJson = validBlock1.toStorageJson()
            )
            assertTrue(authAcceptResult is BlockIngestionResult.Accepted)
            assertEquals(1L, manager.getCurrentHeight())

            // Invalid block from authenticated peer is rejected AND penalizes reputation score
            val scoreBefore = registry.getPeer(authPeerId)!!.reputationScore
            val forgedBlock = validBlock1.copy(
                header = validBlock1.header.copy(height = 2L, previousHash = validBlock1.hash),
                hash = "e".repeat(64)
            )
            val invalidRes = gateway.handleIncomingBlockPayload(
                fromPeerId = authPeerId,
                rawBlockJson = forgedBlock.toStorageJson()
            )
            assertTrue(invalidRes is BlockIngestionResult.Rejected)
            val scoreAfter = registry.getPeer(authPeerId)!!.reputationScore
            assertTrue(scoreAfter < scoreBefore)
        } finally {
            registry.close()
            manager.close()
        }
    }
}
