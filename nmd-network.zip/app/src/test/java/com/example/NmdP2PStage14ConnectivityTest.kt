package com.example

import android.content.Context
import android.content.res.Configuration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.blockchain.config.NmdGenesisConfigs
import com.example.crypto.NodeIdentityManager
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.p2p.connectivity.PeerConnectivityManager
import com.example.p2p.connectivity.ice.SimulatedIceNetworkFabric
import com.example.p2p.connectivity.ice.SimulatedNatBehavior
import com.example.p2p.connectivity.ice.SimulatedNatIceEngine
import com.example.p2p.connectivity.model.ConnectivityDiagnosticsSnapshot
import com.example.p2p.connectivity.model.ConnectivityState
import com.example.p2p.connectivity.model.IceCandidateInfo
import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.IceConnectionStatus
import com.example.p2p.connectivity.model.IceGatheringProgress
import com.example.p2p.connectivity.model.IpVersion
import com.example.p2p.connectivity.model.NatTraversalConfig
import com.example.p2p.connectivity.model.NetworkInterfaceType
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.StunServerProbeResult
import com.example.p2p.connectivity.model.StunServerStatus
import com.example.p2p.connectivity.model.TransportPathType
import com.example.p2p.connectivity.model.TurnRelayStatus
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.connectivity.model.TurnTransportProtocol
import com.example.p2p.connectivity.relay.RelayConnectionManager
import com.example.p2p.connectivity.selector.NetworkPathSelector
import com.example.p2p.connectivity.signaling.CandidateIngestOutcome
import com.example.p2p.connectivity.signaling.InMemorySignalingBroker
import com.example.p2p.connectivity.signaling.PeerSignalingService
import com.example.p2p.connectivity.signaling.SignalingValidationResult
import com.example.p2p.connectivity.stun.Rfc5389StunUdpProber
import com.example.p2p.connectivity.stun.StunDiscoveryService
import com.example.p2p.discovery.DistributedDiscoveryCoordinator
import com.example.p2p.discovery.PeerDiscoveryService
import com.example.p2p.handshake.PeerHandshakeService
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.FrameType
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.repository.NetworkTransportRepository
import com.example.p2p.security.model.TransportSecurityConfig
import com.example.p2p.service.ReliableP2pMessagingService
import com.example.p2p.transport.BufferedStreamTransportChannel
import com.example.p2p.transport.InMemoryTransportChannelPair
import com.example.p2p.transport.MessageFramer
import com.example.p2p.transport.TcpPeerTransport
import com.example.ui.screens.network.ConnectivityDiagnosticsSection
import com.example.ui.theme.NmdNetworkTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Stage 14 NAT Traversal & Direct Internet Connectivity Verification Suite.
 *
 * Clearly distinguishes:
 * - Real local code execution: RFC 5389 UDP STUN binding client/parser, Ed25519 signed signaling,
 *   Stage 13 X25519+Ed25519+ChaCha20-Poly1305 encryption over TransportChannel, TCP local transport,
 *   NetworkPathSelector, AndroidNetworkMonitor transitions, Compose UI diagnostics, EN/AR/FR localization.
 * - Simulated infrastructure in JVM/Robolectric tests (where external public STUN/TURN servers and
 *   native Android WebRTC JNI binaries are unavailable): embedded local UDP STUN responder socket,
 *   InMemorySignalingBroker, and SimulatedNatIceEngine modeling cone NAT / symmetric NAT / blocked paths.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdP2PStage14ConnectivityTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private val testScopes = mutableListOf<CoroutineScope>()
    private val closeables = mutableListOf<java.io.Closeable>()

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
    }

    @After
    fun teardown() {
        closeables.forEach { runCatching { it.close() } }
        closeables.clear()
        testScopes.forEach { it.cancel() }
        testScopes.clear()
    }

    private fun newScope(): CoroutineScope {
        val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        testScopes.add(s)
        return s
    }

    private fun createTestIdentityManager(suffix: String): NodeIdentityManager {
        val prefs = KeyStoreStorageService(
            context = context,
            preferencesName = "stage14_id_${suffix}_${UUID.randomUUID().toString().take(8)}",
            allowTestEnvironmentFallback = true
        )
        val repo = IdentityRepositoryImpl(BouncyCastleEd25519Provider(), prefs)
        return NodeIdentityManager(repo).apply { generateNewIdentity() }
    }

    private data class PeerHarness(
        val name: String,
        val identityManager: NodeIdentityManager,
        val nodeId: String,
        val transport: TcpPeerTransport,
        val connectionManager: PeerConnectionManager,
        val reliableService: ReliableP2pMessagingService,
        val discoveryCoordinator: DistributedDiscoveryCoordinator,
        val connectivityManager: PeerConnectivityManager
    )

    private fun createPeerHarness(
        name: String,
        fabric: SimulatedIceNetworkFabric,
        broker: InMemorySignalingBroker,
        config: NatTraversalConfig = NatTraversalConfig()
    ): PeerHarness {
        val scope = newScope()
        val idMgr = createTestIdentityManager(name)
        val nodeId = idMgr.getActiveIdentity()!!.nodeId
        val transport = TcpPeerTransport(scope)
        val discoveryService = PeerDiscoveryService(context, scope)
        val handshakeService = PeerHandshakeService(idMgr)
        val connMgr = PeerConnectionManager(
            context = context,
            identityManager = idMgr,
            transport = transport,
            handshakeService = handshakeService,
            discoveryService = discoveryService,
            scope = scope
        )
        val reliable = ReliableP2pMessagingService(
            context = context,
            identityManager = idMgr,
            connectionManager = connMgr,
            scope = scope
        )
        val coordinator = DistributedDiscoveryCoordinator(
            context = context,
            identityManager = idMgr,
            transport = transport,
            discoveryService = discoveryService,
            connectionManager = connMgr,
            reliableMessagingService = reliable,
            scope = scope
        )
        val iceEngine = SimulatedNatIceEngine(nodeId, fabric)
        val connectivityMgr = PeerConnectivityManager(
            context = context,
            identityManager = idMgr,
            connectionManager = connMgr,
            discoveryCoordinator = coordinator,
            scope = scope,
            discoveryService = discoveryService,
            localIpProvider = { transport.getLocalIpAddress() },
            initialConfig = config,
            iceEngine = iceEngine
        )
        val signalingChannel = broker.registerPeer(nodeId)
        connectivityMgr.attachSignalingChannel(signalingChannel)

        closeables.add(connectivityMgr)
        closeables.add(coordinator)
        closeables.add(reliable)
        closeables.add(connMgr)
        closeables.add(discoveryService)
        closeables.add(transport)

        return PeerHarness(
            name = name,
            identityManager = idMgr,
            nodeId = nodeId,
            transport = transport,
            connectionManager = connMgr,
            reliableService = reliable,
            discoveryCoordinator = coordinator,
            connectivityManager = connectivityMgr
        )
    }

    @Test
    fun `test01 local direct LAN TCP connection prioritized and encrypted`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_ICE_ALLOWED)
        val broker = InMemorySignalingBroker()
        val peerA = createPeerHarness("lanA", fabric, broker)
        val peerB = createPeerHarness("lanB", fabric, broker)

        val portB = peerB.connectionManager.startP2P(0)
        assertTrue(portB > 0)

        val result = peerA.connectivityManager.connectToPeerSmart(
            targetNodeId = peerB.nodeId,
            localEndpoint = PeerEndpoint("127.0.0.1", portB, peerB.nodeId)
        )
        assertTrue("Expected LAN TCP connection to succeed: ${result.exceptionOrNull()}", result.isSuccess)
        val info = result.getOrThrow()
        assertEquals(RealPeerConnectionState.AUTHENTICATED, info.state)
        assertEquals(TransportPathType.LOCAL_DIRECT_TCP, info.transportPathType)

        delay(200)
        val diagA = peerA.connectivityManager.diagnostics.value
        assertEquals(ConnectivityState.CONNECTED_DIRECTLY, diagA.status)
        assertEquals(TransportPathType.LOCAL_DIRECT_TCP, diagA.activeTransportPath)
        assertEquals(1, diagA.authenticatedConnectedPeers)
        assertEquals(1, diagA.directConnectionsCount)
        assertEquals(0, diagA.relayedConnectionsCount)
    }

    @Test
    fun `test02 cross-network ICE direct negotiation succeeds and runs full Stage 13 encryption`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_ICE_ALLOWED)
        val broker = InMemorySignalingBroker()
        val stunCfg = listOf(StunServerConfig("stun:198.51.100.10:3478"))
        val cfg = NatTraversalConfig(stunServers = stunCfg)

        val peerA = createPeerHarness("iceA", fabric, broker, cfg)
        val peerB = createPeerHarness("iceB", fabric, broker, cfg)

        // Connect over ICE without local LAN endpoint -> triggers ICE Direct negotiation
        val connectRes = peerA.connectivityManager.connectToPeerSmart(
            targetNodeId = peerB.nodeId,
            localEndpoint = null
        )
        assertTrue("Expected ICE Direct + Stage 13 auth to succeed: ${connectRes.exceptionOrNull()}", connectRes.isSuccess)
        val peerInfo = connectRes.getOrThrow()
        assertEquals(TransportPathType.ICE_DIRECT, peerInfo.transportPathType)
        assertEquals(RealPeerConnectionState.AUTHENTICATED, peerInfo.state)

        // Wait for inbound peer B Stage 13 handshake completion
        var waited = 0
        while (peerB.connectionManager.authenticatedPeers.value.isEmpty() && waited < 40) {
            delay(50)
            waited++
        }
        assertEquals(1, peerB.connectionManager.authenticatedPeers.value.size)

        // Verify signed Stage 5/13 encrypted protocol message traverses the ICE DataChannel cleanly
        var receivedPayload: String? = null
        val collectJob = newScope().launch {
            peerB.connectionManager.receivedMessages.collect { (_, msg) ->
                receivedPayload = msg.payload
            }
        }
        val sendRes = peerA.connectionManager.sendMessage(
            targetConnectionId = peerInfo.connectionId,
            messageType = ProtocolMessageType.NODE_ANNOUNCEMENT,
            payload = "{\"stage\":14,\"path\":\"ICE_DIRECT\"}"
        )
        assertTrue(sendRes.isSuccess)
        delay(200)
        collectJob.cancel()

        assertEquals("{\"stage\":14,\"path\":\"ICE_DIRECT\"}", receivedPayload)

        val diagA = peerA.connectivityManager.diagnostics.value
        assertEquals(ConnectivityState.CONNECTED_DIRECTLY, diagA.status)
        assertEquals(TransportPathType.ICE_DIRECT, diagA.activeTransportPath)
        assertEquals(1, diagA.directConnectionsCount)
        assertEquals(0, diagA.relayedConnectionsCount)
        assertNotNull(diagA.observedPublicEndpoint)
    }

    @Test
    fun `test03 real RFC 5389 UDP STUN binding discovery, timeout handling, and public IP shift detection`() = runBlocking {
        // Spin up a real local UDP socket implementing RFC 5389 Binding Response with XOR-MAPPED-ADDRESS
        val serverSocket = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        val running = AtomicBoolean(true)
        var spoofedExternalIp = "203.0.113.45"
        var spoofedExternalPort = 54321

        val serverThread = Thread {
            val buf = ByteArray(512)
            while (running.get() && !serverSocket.isClosed) {
                try {
                    val pkt = DatagramPacket(buf, buf.size)
                    serverSocket.receive(pkt)
                    if (pkt.length >= 20) {
                        val rxTxId = buf.copyOfRange(8, 20)
                        val respBytes = Rfc5389StunUdpProber.buildBindingSuccessResponse(
                            transactionId = rxTxId,
                            clientAddress = InetAddress.getByName(spoofedExternalIp),
                            clientPort = spoofedExternalPort
                        )
                        val respPkt = DatagramPacket(respBytes, respBytes.size, pkt.address, pkt.port)
                        serverSocket.send(respPkt)
                    }
                } catch (_: Exception) {
                    if (!running.get()) break
                }
            }
        }.apply { isDaemon = true; start() }

        try {
            val stunService = StunDiscoveryService()
            val unreachablePort = 65430
            stunService.configureServers(
                listOf(
                    StunServerConfig("stun:127.0.0.1:$unreachablePort", timeoutMs = 400L),
                    StunServerConfig("stun:127.0.0.1:${serverSocket.localPort}", timeoutMs = 1_500L)
                )
            )

            val firstSummary = stunService.discoverReflexiveEndpoints()
            assertEquals(StunServerStatus.AVAILABLE, firstSummary.overallStatus)
            assertEquals(2, firstSummary.configuredServersCount)
            assertEquals(1, firstSummary.reachableServersCount)
            assertEquals("203.0.113.45:54321", firstSummary.formattedPublicEndpoint)
            assertEquals(IpVersion.IPV4, firstSummary.ipVersion)
            assertTrue(firstSummary.natLimitationNote.contains("symmetric NAT", ignoreCase = true))

            // Simulate public IP change across NAT rebinding
            spoofedExternalIp = "198.51.100.88"
            spoofedExternalPort = 61002
            val secondSummary = stunService.discoverReflexiveEndpoints()
            assertEquals("198.51.100.88:61002", secondSummary.formattedPublicEndpoint)
            assertEquals(1, secondSummary.publicIpChangedCount)
        } finally {
            running.set(false)
            serverSocket.close()
            serverThread.join(1000)
        }
    }

    @Test
    fun `test04 symmetric NAT direct failure falls back to configured TURN relay and maintains encryption`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_BLOCKED_RELAY_REQUIRED)
        val broker = InMemorySignalingBroker()
        val validTurn = TurnServerConfig(
            uri = "turn:203.0.113.77:3478",
            transport = TurnTransportProtocol.TLS,
            username = "ephemeral_u1",
            credential = "ephemeral_secret_test_only",
            expiresAtEpochMs = System.currentTimeMillis() + 300_000L
        )
        val cfg = NatTraversalConfig(
            stunServers = listOf(StunServerConfig("stun:198.51.100.10:3478")),
            turnServers = listOf(validTurn),
            iceConnectivityTimeoutMs = 3_000L
        )

        val peerA = createPeerHarness("turnA", fabric, broker, cfg)
        val peerB = createPeerHarness("turnB", fabric, broker, cfg)

        // Check redacted summary never prints TURN secret credential
        assertFalse(validTurn.redactedSummary().contains("ephemeral_secret_test_only"))

        val res = peerA.connectivityManager.connectToPeerSmart(targetNodeId = peerB.nodeId)
        assertTrue("Expected TURN relay fallback to succeed: ${res.exceptionOrNull()}", res.isSuccess)
        val info = res.getOrThrow()
        assertEquals(TransportPathType.TURN_RELAY, info.transportPathType)
        assertEquals(IceCandidateType.RELAY, info.selectedCandidateType)
        assertEquals(RealPeerConnectionState.AUTHENTICATED, info.state)

        delay(200)
        val diagA = peerA.connectivityManager.diagnostics.value
        assertEquals(ConnectivityState.CONNECTED_THROUGH_RELAY, diagA.status)
        assertEquals(TransportPathType.TURN_RELAY, diagA.activeTransportPath)
        assertEquals(0, diagA.directConnectionsCount)
        assertEquals(1, diagA.relayedConnectionsCount)
        assertEquals(TurnRelayStatus.RELAYING, diagA.turnStatus)
    }

    @Test
    fun `test05 direct blocked without TURN or with expired TURN credentials reports unavailable cleanly`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_BLOCKED_RELAY_REQUIRED)
        val broker = InMemorySignalingBroker()

        // Case 1: No TURN configured
        val peerA = createPeerHarness("noTurnA", fabric, broker, NatTraversalConfig(iceConnectivityTimeoutMs = 700L))
        val peerB = createPeerHarness("noTurnB", fabric, broker, NatTraversalConfig(iceConnectivityTimeoutMs = 700L))

        val diagUnconfigured = peerA.connectivityManager.diagnostics.value
        assertEquals(TurnRelayStatus.UNCONFIGURED, diagUnconfigured.turnStatus)
        assertTrue(diagUnconfigured.turnAvailabilityMessage.contains("unavailable", ignoreCase = true))

        val failRes = peerA.connectivityManager.connectToPeerSmart(targetNodeId = peerB.nodeId)
        assertTrue(failRes.isFailure)
        val afterFailDiag = peerA.connectivityManager.diagnostics.value
        assertEquals(ConnectivityState.NO_CONNECTIVITY, afterFailDiag.status)
        assertTrue(afterFailDiag.failedAttemptsCount >= 1L)

        // Case 2: Expired TURN credential rejected cleanly
        val relayMgr = RelayConnectionManager()
        val expiredTurn = TurnServerConfig(
            uri = "turn:203.0.113.77:3478",
            transport = TurnTransportProtocol.TCP,
            username = "u_exp",
            credential = "expired_token",
            expiresAtEpochMs = System.currentTimeMillis() - 10_000L
        )
        relayMgr.configureTurnServers(listOf(expiredTurn))
        assertFalse(relayMgr.isRelayAvailable())
        assertEquals(TurnRelayStatus.UNAVAILABLE_EXPIRED, relayMgr.state.value.status)
        assertTrue(relayMgr.beginRelayFallbackAllocation(peerB.nodeId).isFailure)
    }

    @Test
    fun `test06 candidate prioritization, IPv6 support, and safe remote candidate parsing`() {
        val selector = NetworkPathSelector(NatTraversalConfig(enableIpv6Candidates = true))

        // Valid IPv4 + IPv6 candidates
        val hostV4 = IceCandidateInfo.parseSafe("candidate:1 1 udp 2122260223 192.168.1.10 50000 typ host")!!
        val srflxV4 = IceCandidateInfo.parseSafe("candidate:2 1 udp 1686052607 198.51.100.5 60000 typ srflx")!!
        val hostV6 = IceCandidateInfo.parseSafe("candidate:3 1 udp 2122262783 2001:db8::1 50001 typ host")!!
        val relayV4 = IceCandidateInfo.parseSafe("candidate:4 1 udp 41885439 203.0.113.99 3478 typ relay")!!

        assertEquals(IpVersion.IPV6, hostV6.ipVersion)
        assertEquals(IpVersion.IPV4, hostV4.ipVersion)

        val ranked = selector.rankCandidates(listOf(relayV4, srflxV4, hostV4, hostV6))
        assertEquals(IceCandidateType.HOST, ranked[0].type)
        assertEquals(IpVersion.IPV6, ranked[0].ipVersion) // higher priority host candidate
        assertEquals(IceCandidateType.HOST, ranked[1].type)
        assertEquals(IceCandidateType.SRFLX, ranked[2].type)
        assertEquals(IceCandidateType.RELAY, ranked[3].type)

        // Malformed / malicious candidates rejected safely
        assertNull(IceCandidateInfo.parseSafe(""))
        assertNull(IceCandidateInfo.parseSafe("candidate:1 1 udp 100 192.168.1.1 99999 typ host")) // invalid port
        assertNull(IceCandidateInfo.parseSafe("candidate:1 1 udp 100 192.168.1.1 5000 typ host\r\na=injected")) // CRLF injection
        assertNull(IceCandidateInfo.parseSafe("candidate:1 1 icmp 100 192.168.1.1 5000 typ host")) // unsupported proto
        assertNull(IceCandidateInfo.parseSafe("candidate:1 1 udp 100 192.168.1.1 5000 typ bogus")) // invalid candidate type
    }

    @Test
    fun `test07 out-of-order and duplicate ICE candidates buffered and deduplicated cleanly`() {
        val idA = createTestIdentityManager("sigA")
        val idB = createTestIdentityManager("sigB")
        val repoTrust = com.example.p2p.security.trust.PeerTrustManager(context)
        val sigA = PeerSignalingService(idA, repoTrust, NatTraversalConfig())
        val sigB = PeerSignalingService(idB, repoTrust, NatTraversalConfig())

        val nodeA = idA.getActiveIdentity()!!.nodeId
        val nodeB = idB.getActiveIdentity()!!.nodeId
        val sessId = "sess-ooo-1"

        // Pre-reserve session on B or arrive via valid candidate first? In ICE signaling, offer starts session or candidate buffers after session created
        assertTrue(sigB.tryReserveOutboundNegotiation(sessId, nodeA).isSuccess)

        val c1 = IceCandidateInfo.parseSafe("candidate:10 1 udp 2122260223 192.0.2.5 51000 typ host")!!
        val envCand = sigA.createSignedCandidate(sessId, nodeB, c1).getOrThrow()

        // B verifies signature and buffers c1 early before SDP arrives
        val verified = sigB.verifyAndProcessIncoming(envCand)
        assertTrue(verified is SignalingValidationResult.Valid)

        val ingest1 = sigB.ingestRemoteCandidate(sessId, c1)
        assertTrue(ingest1 is CandidateIngestOutcome.BufferedEarly)

        // Duplicate ignored
        val ingestDup = sigB.ingestRemoteCandidate(sessId, c1)
        assertTrue(ingestDup is CandidateIngestOutcome.DuplicateIgnored)

        // Offer arrives -> drains buffered candidates
        val offerEnv = sigA.createSignedOffer(sessId, nodeB, "v=0\no=- 1 1 IN IP4 127.0.0.1\n").getOrThrow()
        assertTrue(sigB.verifyAndProcessIncoming(offerEnv) is SignalingValidationResult.Valid)
        val drained = sigB.markRemoteSdpAppliedAndDrainCandidates(sessId)
        assertEquals(1, drained.size)
        assertEquals(51000, drained[0].port)
    }

    @Test
    fun `test08 security unauthenticated, tampered, wrong-chain, wrong-recipient, replayed, and revoked signaling rejected`() {
        val idA = createTestIdentityManager("secA")
        val idB = createTestIdentityManager("secB")
        val idC = createTestIdentityManager("secC")
        val trustB = com.example.p2p.security.trust.PeerTrustManager(context, "stage14_trust_sec_${UUID.randomUUID()}")
        val sigA = PeerSignalingService(idA, trustB, NatTraversalConfig())
        val sigB = PeerSignalingService(idB, trustB, NatTraversalConfig())
        val sigWrongChain = PeerSignalingService(idC, trustB, NatTraversalConfig(chainId = "evil-fork-chain"))

        val nodeA = idA.getActiveIdentity()!!.nodeId
        val nodeB = idB.getActiveIdentity()!!.nodeId

        val validOffer = sigA.createSignedOffer("s1", nodeB, "v=0\nsdp-ok\n").getOrThrow()

        // 1. Tampered signature / payload
        val tampered = validOffer.copy(payloadJson = "{\"sdp\":\"tampered\"}")
        assertTrue(sigB.verifyAndProcessIncoming(tampered) is SignalingValidationResult.Rejected)

        // 2. Wrong recipient
        val wrongTarget = sigA.createSignedOffer("s2", idC.getActiveIdentity()!!.nodeId, "v=0").getOrThrow()
        assertTrue(sigB.verifyAndProcessIncoming(wrongTarget) is SignalingValidationResult.Rejected)

        // 3. Wrong Chain ID
        val wrongChainOffer = sigWrongChain.createSignedOffer("s3", nodeB, "v=0").getOrThrow()
        val wrongChainRes = sigB.verifyAndProcessIncoming(wrongChainOffer)
        assertTrue(wrongChainRes is SignalingValidationResult.Rejected)
        assertTrue((wrongChainRes as SignalingValidationResult.Rejected).reason.contains("Chain ID", ignoreCase = true))

        // 4. Valid succeeds once, Replay with same nonce fails
        assertTrue(sigB.verifyAndProcessIncoming(validOffer) is SignalingValidationResult.Valid)
        val replayRes = sigB.verifyAndProcessIncoming(validOffer)
        assertTrue(replayRes is SignalingValidationResult.Rejected)

        // 5. Revoked peer rejected
        trustB.revokePeerIdentity(nodeA, reason = "Compromised test key")
        val postRevoke = sigA.createSignedOffer("s4", nodeB, "v=0").getOrThrow()
        val revokedRes = sigB.verifyAndProcessIncoming(postRevoke)
        assertTrue(revokedRes is SignalingValidationResult.Rejected)
        assertTrue((revokedRes as SignalingValidationResult.Rejected).reason.contains("revoked", ignoreCase = true))
    }

    @Test
    fun `test09 encryption and Stage 13 handshake are mandatory over ICE channels - raw plaintext rejected`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_ICE_ALLOWED)
        val broker = InMemorySignalingBroker()
        val peerB = createPeerHarness("encB", fabric, broker)

        // Simulate raw unencrypted rogue peer sending raw bytes directly on an inbound TransportChannel
        val (rogueEnd, victimEnd) = InMemoryTransportChannelPair.create(
            pathType = TransportPathType.ICE_DIRECT,
            candidateType = IceCandidateType.SRFLX
        )
        var authFailedCalled = false
        peerB.connectionManager.handleIncomingChannel(
            endpoint = PeerEndpoint("198.51.100.99", 55000),
            channel = victimEnd,
            onAuthFailed = { authFailedCalled = true }
        )

        // Rogue writes fake unencrypted frame instead of Stage 13 SECURE_HANDSHAKE_INIT
        MessageFramer.writeFrame(rogueEnd.outputStream, FrameType.PROTOCOL_MESSAGE, "{\"fake\":true}".toByteArray())
        delay(300)

        assertTrue("Unauthenticated ICE channel MUST fail Stage 13 handshake", authFailedCalled)
        assertEquals(0, peerB.connectionManager.authenticatedPeers.value.size)
        assertTrue(victimEnd.isClosed)
    }

    @Test
    fun `test10 abuse protection enforces payload caps, queue limits, per-peer rate limit, and abandoned session cleanup`() {
        val idA = createTestIdentityManager("abA")
        val idB = createTestIdentityManager("abB")
        val trust = com.example.p2p.security.trust.PeerTrustManager(context, "stage14_trust_ab_${UUID.randomUUID()}")
        val limitedConfig = NatTraversalConfig(
            maxSignalingPayloadBytes = 512,
            maxCandidateQueueSize = 3,
            maxConcurrentNegotiations = 3,
            maxNegotiationStartsPerPeerPerWindow = 2,
            abandonedSessionTtlMs = 1_000L
        )
        val sigA = PeerSignalingService(idA, trust, NatTraversalConfig())
        val sigB = PeerSignalingService(idB, trust, limitedConfig)
        val nodeB = idB.getActiveIdentity()!!.nodeId

        // 1. Oversized payload rejected
        val hugeSdp = "a=".repeat(400)
        val hugeOffer = sigA.createSignedOffer("huge1", nodeB, hugeSdp).getOrThrow()
        assertTrue(sigB.verifyAndProcessIncoming(hugeOffer) is SignalingValidationResult.Rejected)

        // 2. Per-peer negotiation rate limit (max 2 in window)
        val t0 = System.currentTimeMillis()
        assertTrue(sigB.tryReserveOutboundNegotiation("r1", "peer-x", t0).isSuccess)
        assertTrue(sigB.tryReserveOutboundNegotiation("r2", "peer-x", t0 + 10).isSuccess)
        assertTrue(sigB.tryReserveOutboundNegotiation("r3", "peer-x", t0 + 20).isFailure)

        // 3. Bounded candidate queue (max 3)
        repeat(3) { i ->
            val c = IceCandidateInfo.parseSafe("candidate:$i 1 udp 2122260223 192.0.2.1 ${5000 + i} typ host")!!
            assertTrue(sigB.ingestRemoteCandidate("r1", c) is CandidateIngestOutcome.BufferedEarly)
        }
        val extra = IceCandidateInfo.parseSafe("candidate:9 1 udp 2122260223 192.0.2.1 5999 typ host")!!
        assertTrue(sigB.ingestRemoteCandidate("r1", extra) is CandidateIngestOutcome.QueueLimitExceeded)

        // 4. Abandoned session expiry sweep
        val swept = sigB.sweepExpiredSessions(t0 + 2_500L)
        assertEquals(2, swept)
        assertEquals(0, sigB.activeNegotiationCount())
    }

    @Test
    fun `test11 Android network switch triggers clean reconnect without duplicate sessions and handles connectivity loss`() = runBlocking {
        val fabric = SimulatedIceNetworkFabric(SimulatedNatBehavior.DIRECT_ICE_ALLOWED)
        val broker = InMemorySignalingBroker()
        val peerA = createPeerHarness("netA", fabric, broker)
        val peerB = createPeerHarness("netB", fabric, broker)

        // Ensure monitor starts on Wi-Fi regardless of Robolectric ShadowConnectivityManager defaults
        if (peerA.connectivityManager.networkMonitor.currentNetworkType.value == NetworkInterfaceType.NONE) {
            peerA.connectivityManager.networkMonitor.notifyObservedNetworkTransition(
                newType = NetworkInterfaceType.WIFI,
                newAddresses = listOf("192.168.1.40"),
                reason = "Initial Wi-Fi ready"
            )
            delay(150)
        }

        // Initial direct ICE connection
        val conn1 = peerA.connectivityManager.connectToPeerSmart(targetNodeId = peerB.nodeId)
        assertTrue(conn1.isSuccess)
        assertEquals(1, peerA.connectionManager.authenticatedPeers.value.size)

        // Simulate cellular/airplane connectivity loss -> must transition to NO_CONNECTIVITY and close sessions
        peerA.connectivityManager.networkMonitor.notifyObservedNetworkTransition(
            newType = NetworkInterfaceType.NONE,
            newAddresses = emptyList(),
            reason = "Airplane mode enabled"
        )
        delay(250)
        assertEquals(ConnectivityState.NO_CONNECTIVITY, peerA.connectivityManager.diagnostics.value.status)
        assertEquals(0, peerA.connectionManager.authenticatedPeers.value.size)

        // Restore Wi-Fi network -> must reconnect eligible peer B cleanly with ZERO duplicate sessions
        peerA.connectivityManager.networkMonitor.notifyObservedNetworkTransition(
            newType = NetworkInterfaceType.WIFI,
            newAddresses = listOf("192.168.1.44"),
            reason = "Wi-Fi restored"
        )
        var reconnectWait = 0
        while (
            (peerA.connectivityManager.diagnostics.value.status != ConnectivityState.CONNECTED_DIRECTLY ||
                peerA.connectionManager.authenticatedPeers.value.size != 1) &&
            reconnectWait < 50
        ) {
            delay(50)
            reconnectWait++
        }
        assertEquals(NetworkInterfaceType.WIFI, peerA.connectivityManager.diagnostics.value.currentNetworkType)
        assertEquals(ConnectivityState.CONNECTED_DIRECTLY, peerA.connectivityManager.diagnostics.value.status)
        assertEquals(1, peerA.connectionManager.authenticatedPeers.value.size)

        // Switch Wi-Fi -> Cellular with IP change -> verify deduplicated session & preserved identity
        peerA.connectivityManager.networkMonitor.notifyObservedNetworkTransition(
            newType = NetworkInterfaceType.CELLULAR,
            newAddresses = listOf("100.64.22.19"),
            reason = "Handed over to 5G cellular"
        )
        var cellularWait = 0
        while (
            peerA.connectivityManager.diagnostics.value.currentNetworkType != NetworkInterfaceType.CELLULAR &&
            cellularWait < 40
        ) {
            delay(50)
            cellularWait++
        }
        delay(250)
        val diagAfterSwitch = peerA.connectivityManager.diagnostics.value
        assertEquals(NetworkInterfaceType.CELLULAR, diagAfterSwitch.currentNetworkType)
        assertTrue(diagAfterSwitch.authenticatedConnectedPeers <= 1)
        assertNotNull(diagAfterSwitch.lastNetworkChangeAtMs)
    }

    @Test
    fun `test12 localized strings EN, AR RTL, and FR LTR all resolve cleanly for Stage 14`() {
        val locales = listOf(Locale("en"), Locale("ar"), Locale("fr"))
        val keys = listOf(
            R.string.stage14_connectivity_title,
            R.string.stage14_status_discovering,
            R.string.stage14_status_gathering,
            R.string.stage14_status_connecting_direct,
            R.string.stage14_status_connected_direct,
            R.string.stage14_status_connecting_relay,
            R.string.stage14_status_connected_relay,
            R.string.stage14_status_reconnecting,
            R.string.stage14_status_no_connectivity,
            R.string.stage14_status_auth_failed,
            R.string.stage14_turn_unconfigured,
            R.string.stage14_nat_limitation_note,
            R.string.stage14_action_refresh_probes,
            R.string.stage14_action_ice_restart,
            R.string.stage14_action_configure_ice
        )

        for (loc in locales) {
            val conf = Configuration(context.resources.configuration).apply { setLocale(loc) }
            val localizedCtx = context.createConfigurationContext(conf)
            for (resId in keys) {
                val text = localizedCtx.getString(resId)
                assertTrue("Empty string for $resId in ${loc.language}", text.isNotBlank())
            }
        }
    }

    @Test
    fun `test13 ConnectivityDiagnosticsSection Compose UI renders all diagnostics and opens STUN-TURN dialog`() {
        val sampleDiag = ConnectivityDiagnosticsSnapshot(
            status = ConnectivityState.CONNECTED_THROUGH_RELAY,
            totalDiscoveredPeers = 4,
            authenticatedConnectedPeers = 1,
            directConnectionsCount = 0,
            relayedConnectionsCount = 1,
            iceGatheringState = IceGatheringProgress.COMPLETE,
            iceConnectionState = IceConnectionStatus.CONNECTED,
            selectedCandidateType = IceCandidateType.RELAY,
            selectedCandidatePairSummary = "relay(turn) <-> relay(turn)",
            stunStatus = StunServerStatus.AVAILABLE,
            stunServerCount = 2,
            observedPublicEndpoint = "198.51.100.12:62001",
            turnStatus = TurnRelayStatus.RELAYING,
            turnServerCount = 1,
            lastConnectionEstablishmentMs = 142L,
            currentNetworkType = NetworkInterfaceType.CELLULAR,
            lastNetworkChangeAtMs = System.currentTimeMillis(),
            lastNetworkChangeReason = "Cellular handover",
            failedAttemptsCount = 1L,
            activeTransportPath = TransportPathType.TURN_RELAY,
            lastEventSummary = "Relayed encrypted session ready"
        )

        var refreshed = false
        var restarted = false

        composeRule.setContent {
            NmdNetworkTheme {
                Box(modifier = androidx.compose.ui.Modifier.verticalScroll(rememberScrollState())) {
                    ConnectivityDiagnosticsSection(
                        diagnostics = sampleDiag,
                        onRefreshProbes = { refreshed = true },
                        onTriggerIceRestart = { restarted = true },
                        onConfigureServers = { _, _ -> }
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("nat_connectivity_diagnostics_card").assertIsDisplayed()
        composeRule.onNodeWithTag("stage14_status_value").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("stage14_active_path_value").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("stage14_refresh_probes_btn").performScrollTo().performClick()
        composeRule.onNodeWithTag("stage14_ice_restart_btn").performScrollTo().performClick()
        composeRule.onNodeWithTag("stage14_configure_servers_btn").performScrollTo().performClick()
        composeRule.waitForIdle()

        assertTrue(refreshed)
        assertTrue(restarted)
        composeRule.onNodeWithText(context.getString(R.string.stage14_dialog_title)).assertIsDisplayed()
    }

    @Test
    fun `test14 Stage 13 NMD repository instantiation remains healthy with Stage 14 wired`() {
        val scope = newScope()
        val idMgr = createTestIdentityManager("repoCompat")
        val repo = NetworkTransportRepository(context, idMgr, scope)
        closeables.add(repo)

        assertNotNull(repo.connectivityManager)
        assertEquals(ConnectivityState.DISCOVERING, repo.connectivityDiagnostics.value.status)
        assertEquals(TurnRelayStatus.UNCONFIGURED, repo.connectivityDiagnostics.value.turnStatus)
        assertEquals(StunServerStatus.UNCONFIGURED, repo.connectivityDiagnostics.value.stunStatus)
    }
}
