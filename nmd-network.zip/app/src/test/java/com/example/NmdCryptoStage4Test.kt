package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.NodeIdentityManager
import com.example.crypto.SelfVerificationStatus
import com.example.crypto.model.KeyStorageSecurityStatus
import com.example.crypto.model.MessageVerificationResult
import com.example.crypto.model.NodeIdentity
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.crypto.model.VerificationFailureReason
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.crypto.repository.IdentityRepository
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.service.MessageVerifier
import com.example.crypto.service.SignatureService
import com.example.crypto.storage.KeyStoreStorageService
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.nio.charset.StandardCharsets

/**
 * Stage 4 Cryptographic Identity & Protocol Foundation Test Suite
 * Verifies Ed25519 key generation, deterministic node ID derivation, signing,
 * strict multi-stage verification (tampering, expiry, future drift, replay protection),
 * public JSON safety, and localization parity.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdCryptoStage4Test {

    private lateinit var context: Context
    private lateinit var cryptoProvider: CryptographicProvider
    private lateinit var signatureService: SignatureService
    private lateinit var messageVerifier: MessageVerifier

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        cryptoProvider = BouncyCastleEd25519Provider()
        signatureService = SignatureService(cryptoProvider)
        messageVerifier = MessageVerifier(cryptoProvider)
    }

    @Test
    fun testEd25519KeyGenerationProperties() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()

        // RFC 8032: Ed25519 private seed is exactly 32 bytes
        assertEquals(32, keyPair.privateKeyBytes.size)
        // Ed25519 public key is exactly 32 bytes
        assertEquals(32, keyPair.publicKeyBytes.size)

        // Deriving from private seed must match generated public key
        val derivedPubKey = cryptoProvider.derivePublicKeyFromPrivate(keyPair.privateKeyBytes)
        assertArrayEquals(keyPair.publicKeyBytes, derivedPubKey)
    }

    @Test
    fun testDeterministicNodeIdDerivation() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId1 = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val nodeId2 = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)

        // Derivation must be deterministic
        assertEquals(nodeId1, nodeId2)

        // Node ID specification: "nmd_node_" + 32 lowercase hex characters
        assertTrue(nodeId1.startsWith(NodeIdentity.NODE_ID_PREFIX))
        assertEquals(NodeIdentity.NODE_ID_PREFIX.length + 32, nodeId1.length)
        assertEquals(nodeId1, nodeId1.lowercase())
    }

    @Test
    fun testPublicKeyFingerprintFormat() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val fingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes)

        // SHA-256 fingerprint formatted as XX:XX:...:XX (16 hex pairs separated by colons)
        val parts = fingerprint.split(":")
        assertEquals(16, parts.size)
        parts.forEach { part ->
            assertEquals(2, part.length)
            assertTrue(part.all { it in '0'..'9' || it in 'A'..'F' })
        }
    }

    @Test
    fun testEd25519SigningAndVerification() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val data = "NMD Network Layer-1 Protocol Payload".toByteArray(StandardCharsets.UTF_8)

        // Sign data
        val signature = cryptoProvider.sign(keyPair.privateKeyBytes, data)
        // RFC 8032: Ed25519 signature is exactly 64 bytes
        assertEquals(64, signature.size)

        // Verification with authentic public key must succeed
        val isValid = cryptoProvider.verify(keyPair.publicKeyBytes, data, signature)
        assertTrue("Signature verification should succeed for authentic data", isValid)
    }

    @Test
    fun testSignatureVerificationRejectsTamperedData() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val originalData = "Block #1849208 State Transition".toByteArray(StandardCharsets.UTF_8)
        val signature = cryptoProvider.sign(keyPair.privateKeyBytes, originalData)

        // Tamper with data (change 1 byte)
        val tamperedData = "Block #1849209 State Transition".toByteArray(StandardCharsets.UTF_8)
        val isValid = cryptoProvider.verify(keyPair.publicKeyBytes, tamperedData, signature)
        assertFalse("Verification must fail when payload is tampered", isValid)
    }

    @Test
    fun testSignatureVerificationRejectsTamperedSignature() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val data = "Valid Transaction Bundle".toByteArray(StandardCharsets.UTF_8)
        val signature = cryptoProvider.sign(keyPair.privateKeyBytes, data)

        // Corrupt signature
        val corruptedSig = signature.copyOf()
        corruptedSig[0] = (corruptedSig[0].toInt() xor 0xFF).toByte()

        val isValid = cryptoProvider.verify(keyPair.publicKeyBytes, data, corruptedSig)
        assertFalse("Verification must fail when signature is tampered", isValid)
    }

    @Test
    fun testSignatureVerificationRejectsForeignPublicKey() {
        val keyPairA = cryptoProvider.generateEd25519KeyPair()
        val keyPairB = cryptoProvider.generateEd25519KeyPair()

        val data = "Node Announcement Broadcast".toByteArray(StandardCharsets.UTF_8)
        val signatureA = cryptoProvider.sign(keyPairA.privateKeyBytes, data)

        // Verify with Key B
        val isValid = cryptoProvider.verify(keyPairB.publicKeyBytes, data, signatureA)
        assertFalse("Verification must fail when checked against a foreign public key", isValid)
    }

    @Test
    fun testSignedProtocolMessageCreationAndVerification() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val pubKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes)

        val identity = NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = pubKeyHex,
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.NODE_ANNOUNCEMENT,
            payload = "{\"role\":\"VALIDATOR\",\"version\":\"1.0.0\"}"
        )

        assertNotNull(signedMessage)
        assertEquals(nodeId, signedMessage.senderNodeId)
        assertEquals(pubKeyHex, signedMessage.senderPublicKey)
        assertEquals(ProtocolMessageType.NODE_ANNOUNCEMENT, signedMessage.messageType)
        assertTrue(signedMessage.isLocalDemoMessage)
        assertEquals(128, signedMessage.signatureHex.length) // 64 bytes in hex = 128 characters

        // Verification via MessageVerifier
        val result = messageVerifier.verifyMessage(signedMessage)
        assertTrue("Authentic signed protocol message must verify as Valid", result is MessageVerificationResult.Valid)
    }

    @Test
    fun testMessageVerifierRejectsSenderNodeIdMismatch() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val pubKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes)

        val identity = NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = pubKeyHex,
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.HEARTBEAT,
            payload = "{\"uptime\":120}"
        )

        // Spoof sender node ID
        val spoofedMessage = signedMessage.copy(senderNodeId = "nmd_node_00000000000000000000000000000000")
        val result = messageVerifier.verifyMessage(spoofedMessage)

        assertTrue(result is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.SENDER_NODE_ID_MISMATCH,
            (result as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testMessageVerifierRejectsExpiredTimestamp() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val pubKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes)

        val identity = NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = pubKeyHex,
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val pastTimestamp = System.currentTimeMillis() - (10 * 60 * 1000L) // 10 minutes ago (> 5m window)
        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.PEER_PING,
            payload = "{\"ping\":1}",
            timestamp = pastTimestamp
        )

        val result = messageVerifier.verifyMessage(signedMessage)
        assertTrue(result is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.EXPIRED_TIMESTAMP,
            (result as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testMessageVerifierRejectsFutureTimestamp() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val pubKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes)

        val identity = NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = pubKeyHex,
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val futureTimestamp = System.currentTimeMillis() + (10 * 60 * 1000L) // 10 minutes in future (> 5m window)
        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.PEER_PING,
            payload = "{\"ping\":1}",
            timestamp = futureTimestamp
        )

        val result = messageVerifier.verifyMessage(signedMessage)
        assertTrue(result is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.FUTURE_TIMESTAMP,
            (result as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testMessageVerifierReplayAttackProtection() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val pubKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes)

        val identity = NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = pubKeyHex,
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.STATE_SYNC_REQUEST,
            payload = "{\"block_start\":100}"
        )

        // First verification should pass and record message ID
        val firstResult = messageVerifier.verifyMessage(signedMessage)
        assertTrue(firstResult is MessageVerificationResult.Valid)

        // Second verification with identical message ID must be rejected as replay attack
        val secondResult = messageVerifier.verifyMessage(signedMessage)
        assertTrue(secondResult is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.DUPLICATE_MESSAGE_ID,
            (secondResult as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testPublicIdentityJsonNeverExposesPrivateKey() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val pubKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes)

        val identity = NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = pubKeyHex,
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val publicJson = identity.toPublicJson()

        // Must contain safe public fields
        assertTrue(publicJson.contains("node_id"))
        assertTrue(publicJson.contains(identity.nodeId))
        assertTrue(publicJson.contains("public_key_hex"))
        assertTrue(publicJson.contains(identity.publicKeyHex))
        assertTrue(publicJson.contains("fingerprint"))
        assertTrue(publicJson.contains("Ed25519"))

        // CRITICAL: Must NEVER contain private key seed or private key material
        assertFalse("Public JSON must never contain 'private_key'", publicJson.contains("private_key", ignoreCase = true))
        assertFalse("Public JSON must never contain 'seed'", publicJson.contains("seed", ignoreCase = true))
        assertFalse("Public JSON must never contain 'secret'", publicJson.contains("secret", ignoreCase = true))
    }

    @Test
    fun testStage4LocalizationResourceParity() {
        // List of all Stage 4 string resources
        val stage4Keys = listOf(
            "tab_network_identity",
            "crypto_identity_title",
            "crypto_identity_subtitle",
            "crypto_status_active",
            "crypto_status_empty",
            "crypto_no_identity_title",
            "crypto_no_identity_desc",
            "crypto_node_id_title",
            "crypto_public_key_title",
            "crypto_fingerprint_title",
            "crypto_algorithm_title",
            "crypto_creation_date_title",
            "crypto_storage_security_title",
            "crypto_btn_generate",
            "crypto_btn_view_public",
            "crypto_btn_verify_self",
            "crypto_btn_delete",
            "crypto_btn_sign_test_msg",
            "crypto_btn_verify_msg",
            "crypto_delete_dialog_title",
            "crypto_delete_dialog_desc",
            "crypto_delete_confirm_btn",
            "crypto_public_dialog_title",
            "crypto_public_dialog_desc",
            "crypto_copy_btn",
            "crypto_copied_toast",
            "crypto_sign_dialog_title",
            "crypto_sign_dialog_desc",
            "crypto_test_msg_badge",
            "crypto_verify_success",
            "crypto_verify_failed",
            "crypto_self_verify_success",
            "crypto_self_verify_failed",
            "crypto_storage_hardware_title",
            "crypto_storage_hardware_desc",
            "crypto_storage_software_title",
            "crypto_storage_software_desc",
            "crypto_storage_enclave_title",
            "crypto_storage_enclave_desc",
            "msg_type_announcement",
            "msg_type_heartbeat",
            "msg_type_ping",
            "msg_type_sync_req",
            "msg_type_gossip",
            "verify_err_invalid_signature",
            "verify_err_sender_mismatch",
            "verify_err_expired_timestamp",
            "verify_err_future_timestamp",
            "verify_err_duplicate_message_id",
            "verify_err_malformed"
        )

        val res = context.resources
        val packageName = context.packageName

        stage4Keys.forEach { key ->
            val resId = res.getIdentifier(key, "string", packageName)
            assertTrue("String resource key '$key' must exist in resources", resId != 0)
            val text = res.getString(resId)
            assertTrue("String for key '$key' must not be blank", text.isNotBlank())
        }
    }

    @Test
    fun testHexEncodingLengths() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val pubHex = cryptoProvider.toHex(keyPair.publicKeyBytes)
        // Public key is 32 bytes -> exactly 64 hex characters
        assertEquals(64, pubHex.length)
        assertTrue(pubHex.all { it in '0'..'9' || it in 'a'..'f' })

        val signature = cryptoProvider.sign(keyPair.privateKeyBytes, "test data".toByteArray())
        val sigHex = cryptoProvider.toHex(signature)
        // Signature is 64 bytes -> exactly 128 hex characters
        assertEquals(128, sigHex.length)
        assertTrue(sigHex.all { it in '0'..'9' || it in 'a'..'f' })
    }

    @Test
    fun testMessageVerifierRejectsAlteredPayload() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.NODE_ANNOUNCEMENT,
            payload = "{\"role\":\"VALIDATOR\"}"
        )

        // Alter payload
        val alteredMessage = signedMessage.copy(payload = "{\"role\":\"VALIDATOR\",\"extra\":1}")
        val result = messageVerifier.verifyMessage(alteredMessage)

        assertTrue(result is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.INVALID_SIGNATURE,
            (result as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testMessageVerifierRejectsAlteredMessageId() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.HEARTBEAT,
            payload = "{\"uptime\":3600}"
        )

        // Alter messageId (which is part of canonical signed bytes)
        val alteredMessage = signedMessage.copy(messageId = "altered_id_${System.currentTimeMillis()}")
        val result = messageVerifier.verifyMessage(alteredMessage)

        assertTrue(result is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.INVALID_SIGNATURE,
            (result as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testMessageVerifierRejectsAlteredTimestampWithinWindow() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val now = System.currentTimeMillis()
        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.PEER_PING,
            payload = "{\"ping\":42}",
            timestamp = now
        )

        // Shift timestamp by 10 seconds (still within ±5m window, but canonical bytes change)
        val alteredMessage = signedMessage.copy(timestamp = now + 10_000L)
        val result = messageVerifier.verifyMessage(alteredMessage)

        assertTrue(result is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.INVALID_SIGNATURE,
            (result as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testMessageVerifierRejectsInvalidSignatureLength() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.HEARTBEAT,
            payload = "{}"
        )

        // Truncate signature to 63 bytes (126 hex chars)
        val shortSigMessage = signedMessage.copy(signatureHex = signedMessage.signatureHex.substring(0, 126))
        val resultShort = messageVerifier.verifyMessage(shortSigMessage)
        assertTrue(resultShort is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.MALFORMED_FORMAT,
            (resultShort as MessageVerificationResult.Invalid).reason
        )

        // Extend signature to 65 bytes (130 hex chars)
        val longSigMessage = signedMessage.copy(signatureHex = signedMessage.signatureHex + "00")
        val resultLong = messageVerifier.verifyMessage(longSigMessage)
        assertTrue(resultLong is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.MALFORMED_FORMAT,
            (resultLong as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testMessageVerifierRejectsInvalidPublicKeyLength() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.HEARTBEAT,
            payload = "{}"
        )

        // Truncate public key to 31 bytes (62 hex chars)
        val shortKeyMessage = signedMessage.copy(senderPublicKey = signedMessage.senderPublicKey.substring(0, 62))
        val result = messageVerifier.verifyMessage(shortKeyMessage)
        assertTrue(result is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.MALFORMED_FORMAT,
            (result as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testCanonicalBytesIncludesAllProtocolFields() {
        val baseMessage = SignedProtocolMessage(
            protocolVersion = 1,
            messageType = ProtocolMessageType.NODE_ANNOUNCEMENT,
            senderNodeId = "nmd_node_11112222333344445555666677778888",
            senderPublicKey = "aabbccdd".repeat(8),
            timestamp = 1700000000000L,
            messageId = "msg_uuid_001",
            payload = "{\"role\":\"FULL_NODE\"}",
            signatureHex = "00".repeat(64)
        )

        val baseCanonical = baseMessage.getCanonicalBytes()

        // 1. Mutate protocolVersion
        assertFalse(baseCanonical.contentEquals(baseMessage.copy(protocolVersion = 2).getCanonicalBytes()))

        // 2. Mutate messageType
        assertFalse(baseCanonical.contentEquals(baseMessage.copy(messageType = ProtocolMessageType.HEARTBEAT).getCanonicalBytes()))

        // 3. Mutate senderNodeId
        assertFalse(baseCanonical.contentEquals(baseMessage.copy(senderNodeId = "nmd_node_9999").getCanonicalBytes()))

        // 4. Mutate senderPublicKey
        assertFalse(baseCanonical.contentEquals(baseMessage.copy(senderPublicKey = "ff".repeat(32)).getCanonicalBytes()))

        // 5. Mutate timestamp
        assertFalse(baseCanonical.contentEquals(baseMessage.copy(timestamp = 1700000000001L).getCanonicalBytes()))

        // 6. Mutate messageId
        assertFalse(baseCanonical.contentEquals(baseMessage.copy(messageId = "msg_uuid_002").getCanonicalBytes()))

        // 7. Mutate payload
        assertFalse(baseCanonical.contentEquals(baseMessage.copy(payload = "{\"role\":\"LIGHT_NODE\"}").getCanonicalBytes()))
    }

    @Test
    fun testKeyStoreStorageServiceLifecycleAndDeletion() {
        val storage = KeyStoreStorageService(context, "test_audit_storage_prefs", allowTestEnvironmentFallback = true)
        storage.deleteIdentity() // Clean slate

        assertFalse(storage.hasStoredIdentity())
        assertNull(storage.loadPublicIdentity())
        assertNull(storage.loadPrivateKeyBytes())

        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        // Store identity (encrypts with AES-256-GCM via AndroidKeyStore)
        storage.storeIdentity(identity, keyPair.privateKeyBytes)

        assertTrue(storage.hasStoredIdentity())
        val loadedIdentity = storage.loadPublicIdentity()
        assertNotNull(loadedIdentity)
        assertEquals(identity.nodeId, loadedIdentity?.nodeId)
        assertEquals(identity.publicKeyHex, loadedIdentity?.publicKeyHex)

        // Decrypt private key bytes
        val decryptedSeed = storage.loadPrivateKeyBytes()
        assertNotNull(decryptedSeed)
        assertArrayEquals(keyPair.privateKeyBytes, decryptedSeed)
        decryptedSeed?.fill(0)

        // Delete identity permanently
        val deleteResult = storage.deleteIdentity()
        assertTrue(deleteResult)

        // Must be unrecoverable
        assertFalse(storage.hasStoredIdentity())
        assertNull(storage.loadPublicIdentity())
        assertNull(storage.loadPrivateKeyBytes())
    }

    @Test
    fun testProductionKeystoreFailureFailsSecurelyWithoutFallback() {
        val prodStorage = KeyStoreStorageService(
            context = context,
            preferencesName = "test_prod_fail_closed_prefs",
            allowTestEnvironmentFallback = false // Strict production mode
        )

        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.HARDWARE_BACKED_KEYSTORE
        )

        try {
            prodStorage.storeIdentity(identity, keyPair.privateKeyBytes)
            // On a physical Android device with AndroidKeyStore, this succeeds via Keystore.
            // On JVM/Robolectric test environment without AndroidKeyStore, it must throw SecurityException!
        } catch (e: SecurityException) {
            assertTrue("SecurityException must explain that AndroidKeyStore is required", e.message?.contains("AndroidKeyStore") == true)
            assertFalse("Must never silently store identity with a fallback key in production mode", prodStorage.hasStoredIdentity())
        }
    }

    @Test
    fun testDuplicateMessageRejectionAfterApplicationRestart() {
        val cacheName = "test_restart_cache_${System.currentTimeMillis()}"
        val verifier1 = MessageVerifier(
            cryptoProvider = cryptoProvider,
            context = context,
            replayCachePreferencesName = cacheName
        )

        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )
        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.HEARTBEAT,
            payload = "{\"uptime\":100}"
        )

        // First verification on original verifier instance
        val result1 = verifier1.verifyMessage(signedMessage)
        assertTrue("First verification must succeed", result1 is MessageVerificationResult.Valid)

        // Simulate complete application termination and process restart:
        // A brand new MessageVerifier instance initialized from persistent storage
        val verifierAfterRestart = MessageVerifier(
            cryptoProvider = cryptoProvider,
            context = context,
            replayCachePreferencesName = cacheName
        )
        val resultAfterRestart = verifierAfterRestart.verifyMessage(signedMessage)

        assertTrue("Duplicate message must be rejected even after process restart", resultAfterRestart is MessageVerificationResult.Invalid)
        assertEquals(
            VerificationFailureReason.DUPLICATE_MESSAGE_ID,
            (resultAfterRestart as MessageVerificationResult.Invalid).reason
        )
    }

    @Test
    fun testConcurrentDuplicateMessageVerification() {
        val verifier = MessageVerifier(cryptoProvider, context = context)
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )
        val signedMessage = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.PEER_PING,
            payload = "{\"nonce\":\"concurrent_test\"}"
        )

        val threadCount = 10
        val results = java.util.Collections.synchronizedList(mutableListOf<MessageVerificationResult>())
        val latch = java.util.concurrent.CountDownLatch(threadCount)
        val executor = java.util.concurrent.Executors.newFixedThreadPool(threadCount)

        for (i in 0 until threadCount) {
            executor.submit {
                try {
                    val res = verifier.verifyMessage(signedMessage)
                    results.add(res)
                } finally {
                    latch.countDown()
                }
            }
        }

        latch.await(5, java.util.concurrent.TimeUnit.SECONDS)
        executor.shutdown()

        val validCount = results.count { it is MessageVerificationResult.Valid }
        val duplicateCount = results.count {
            it is MessageVerificationResult.Invalid && it.reason == VerificationFailureReason.DUPLICATE_MESSAGE_ID
        }

        assertEquals("Atomic concurrency: exactly one thread must succeed", 1, validCount)
        assertEquals("Atomic concurrency: all 9 other threads must receive DUPLICATE_MESSAGE_ID", threadCount - 1, duplicateCount)
    }

    @Test
    fun testReplayCacheExpirationAndCleanup() {
        var mockCurrentTime = 10_000_000L
        val cacheName = "test_cleanup_cache_${System.currentTimeMillis()}"
        val verifier = MessageVerifier(
            cryptoProvider = cryptoProvider,
            maxAllowedDriftMs = 5 * 60 * 1000L,
            currentTimeProvider = { mockCurrentTime },
            context = context,
            replayCachePreferencesName = cacheName
        )

        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = mockCurrentTime,
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )
        val msg1 = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.HEARTBEAT,
            payload = "{\"seq\":1}",
            timestamp = mockCurrentTime
        )

        val res1 = verifier.verifyMessage(msg1)
        assertTrue(res1 is MessageVerificationResult.Valid)

        val prefs = context.getSharedPreferences(cacheName, Context.MODE_PRIVATE)
        assertTrue("Message 1 must be recorded in persistent storage", prefs.contains(msg1.messageId))

        // Advance simulated time by 12 minutes (cutoff is 10 minutes)
        mockCurrentTime += 12 * 60 * 1000L

        val msg2 = signatureService.signMessage(
            identity = identity,
            privateKeyBytes = keyPair.privateKeyBytes,
            messageType = ProtocolMessageType.HEARTBEAT,
            payload = "{\"seq\":2}",
            timestamp = mockCurrentTime
        )
        val res2 = verifier.verifyMessage(msg2)
        assertTrue(res2 is MessageVerificationResult.Valid)

        // Expired message 1 must have been purged from persistent storage to prevent indefinite growth
        assertFalse("Expired message 1 must be evicted from persistent cache", prefs.contains(msg1.messageId))
        assertTrue("New message 2 must be present in persistent cache", prefs.contains(msg2.messageId))
    }

    @Test
    fun testUnusualAndSeparatedPayloadsSucceed() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val identity = NodeIdentity(
            nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes),
            publicKeyHex = cryptoProvider.toHex(keyPair.publicKeyBytes),
            publicKeyFingerprint = cryptoProvider.computeFingerprint(keyPair.publicKeyBytes),
            creationTimestamp = System.currentTimeMillis(),
            securityStatus = KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        val complexPayloads = listOf(
            "", // empty string
            "|||||||", // only delimiters
            "field1|field2||field3|",
            "{\"arabic\":\"شبكة NMD اللامركزية\", \"emoji\":\"🚀⚡🔒\"}",
            "Line1\nLine2\r\nLine3\tTabbed",
            "Special \u0000 \uFFFF \u0022 null and quotes",
            "{\"nested\":{\"pipe\":\"|\",\"colon\":\":\",\"braces\":\"{}\"}}"
        )

        complexPayloads.forEach { payload ->
            val signed = signatureService.signMessage(
                identity = identity,
                privateKeyBytes = keyPair.privateKeyBytes,
                messageType = ProtocolMessageType.GOSSIP_DATA,
                payload = payload
            )
            val result = messageVerifier.verifyMessage(signed)
            assertTrue("Payload '$payload' must verify as Valid", result is MessageVerificationResult.Valid)
        }
    }

    @Test
    fun testLengthPrefixedCanonicalBytesPreventsDelimiterAmbiguityCollision() {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        val nodeId = cryptoProvider.deriveNodeId(keyPair.publicKeyBytes)
        val pubHex = cryptoProvider.toHex(keyPair.publicKeyBytes)
        val now = System.currentTimeMillis()

        // Message A: messageId contains delimiter and extra characters
        val msgA = SignedProtocolMessage(
            protocolVersion = 2,
            messageType = ProtocolMessageType.NODE_ANNOUNCEMENT,
            senderNodeId = nodeId,
            senderPublicKey = pubHex,
            timestamp = now,
            messageId = "test_id|extra",
            payload = "payload_data",
            signatureHex = ""
        )

        // Message B: messageId is short, payload has the delimiter and extra characters
        val msgB = SignedProtocolMessage(
            protocolVersion = 2,
            messageType = ProtocolMessageType.NODE_ANNOUNCEMENT,
            senderNodeId = nodeId,
            senderPublicKey = pubHex,
            timestamp = now,
            messageId = "test_id",
            payload = "extra|payload_data",
            signatureHex = ""
        )

        val canonicalA = msgA.getCanonicalBytes()
        val canonicalB = msgB.getCanonicalBytes()

        // With length-prefixing, messageId length (13 vs 7) and payload length (12 vs 18) prevent collision:
        assertFalse("Canonical byte sequences must be distinct despite delimiter overlap", canonicalA.contentEquals(canonicalB))

        // Sign message A
        val sigA = cryptoProvider.sign(keyPair.privateKeyBytes, canonicalA)
        val signedMsgA = msgA.copy(signatureHex = cryptoProvider.toHex(sigA))

        // Forging signature from Message A onto Message B must fail
        val forgedMsgB = msgB.copy(signatureHex = signedMsgA.signatureHex)
        val verifyResultB = messageVerifier.verifyMessage(forgedMsgB)
        assertTrue("Signature from Message A must fail when applied to Message B", verifyResultB is MessageVerificationResult.Invalid)
    }
}
