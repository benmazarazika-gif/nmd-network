package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.manager.BlockIngestionResult
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.Ed25519KeyPairResult
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerCapability
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.session.P2pSessionState
import com.example.p2p.session.PeerSession
import com.example.transaction.NmdTransactionEngineRegistry
import com.example.transaction.TransactionEngineManager
import com.example.transaction.crypto.CanonicalTransactionSerializer
import com.example.transaction.crypto.NmdAddressCodec
import com.example.transaction.crypto.TransactionSigner
import com.example.transaction.fee.TransactionFeeCalculator
import com.example.transaction.mempool.MempoolSubmissionResult
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionPropagationStatus
import com.example.transaction.model.TransactionType
import com.example.transaction.p2p.TxInboundResult
import com.example.transaction.validation.TransactionPolicyConfig
import com.example.transaction.validation.TransactionValidator
import com.example.transaction.validation.TxValidationErrorCode
import com.example.transaction.validation.TxValidationResult
import com.example.ui.screens.WalletViewModel
import com.example.ui.screens.wallet.TxSigningUiStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Comprehensive Automated Verification Suite for Stage 9:
 * Transaction Engine & Transaction Validation.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdTransactionStage9Test {

    private lateinit var context: Context
    private lateinit var testScope: CoroutineScope
    private val crypto = BouncyCastleEd25519Provider()
    private val signer = TransactionSigner(crypto)
    private val feeCalculator = TransactionFeeCalculator()
    private val config = BlockchainConfig()

    private val testDbFiles = listOf(
        "test_stage9_mempool_persist.db",
        "test_stage9_node_a.db",
        "test_stage9_node_b.db",
        "test_stage9_chain_bridge.db",
        "test_stage9_wallet.db"
    )

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testScope = CoroutineScope(Dispatchers.IO + Job())
        NmdTransactionEngineRegistry.resetForTests()
        cleanupArtifacts()
    }

    @After
    fun tearDown() {
        testScope.cancel()
        NmdTransactionEngineRegistry.resetForTests()
        cleanupArtifacts()
    }

    private fun cleanupArtifacts() {
        testDbFiles.forEach { context.deleteDatabase(it) }
        context.getSharedPreferences("nmd_p2p_registry", Context.MODE_PRIVATE).edit().clear().commit()
        context.deleteSharedPreferences("nmd_identity_prefs")
        context.getSharedPreferences("nmd_crypto_identity_prefs", Context.MODE_PRIVATE).edit().clear().commit()
    }

    private fun buildSignedTx(
        keyPair: Ed25519KeyPairResult = crypto.generateEd25519KeyPair(),
        recipient: String? = null,
        amountUnits: Long = 10L * NmdAmountCodec.UNITS_PER_NMD,
        feeUnits: Long? = null,
        nonce: Long = 0L,
        timestamp: Long = System.currentTimeMillis(),
        txType: TransactionType = TransactionType.TRANSFER,
        payload: ByteArray = "stage9-memo".toByteArray(Charsets.UTF_8),
        chainId: String = config.chainId,
        protocolVersion: Int = config.parameters.protocolVersion
    ): NmdTransaction {
        val targetRecipient = recipient ?: NmdAddressCodec.deriveAddressFromPublicKey(
            crypto.generateEd25519KeyPair().publicKeyBytes,
            crypto
        )
        val senderAddr = NmdAddressCodec.deriveAddressFromPublicKey(keyPair.publicKeyBytes, crypto)
        val senderPubHex = crypto.toHex(keyPair.publicKeyBytes)
        val draftEstimate = feeCalculator.estimateFeeForDraft(txType, payload.size, chainId)
        val unsigned = NmdTransaction(
            chainId = chainId,
            protocolVersion = protocolVersion,
            senderAddress = senderAddr,
            recipientAddress = targetRecipient,
            amountUnits = amountUnits,
            feeUnits = feeUnits ?: draftEstimate.minimumRequiredFeeUnits,
            nonce = nonce,
            timestamp = timestamp,
            txType = txType,
            rawTxTypeName = txType.name,
            senderPublicKeyHex = senderPubHex,
            payload = payload
        )
        return signer.signWithKeyPair(unsigned, keyPair.privateKeyBytes)
    }

    // 1. Deterministic Transaction ID & Canonical Encoding
    @Test
    fun testCanonicalSerializationAndDeterministicTxId() {
        val kp = crypto.generateEd25519KeyPair()
        val recipient = NmdAddressCodec.deriveAddressFromPublicKey(crypto.generateEd25519KeyPair().publicKeyBytes, crypto)
        val fixedTs = 1_750_000_000_000L

        val tx1 = buildSignedTx(
            keyPair = kp,
            recipient = recipient,
            amountUnits = 42_500_000L, // 42.5 NMD
            nonce = 0L,
            timestamp = fixedTs,
            payload = "deterministic".toByteArray()
        )
        val tx2 = buildSignedTx(
            keyPair = kp,
            recipient = recipient,
            amountUnits = 42_500_000L,
            nonce = 0L,
            timestamp = fixedTs,
            payload = "deterministic".toByteArray()
        )

        assertArrayEquals(
            CanonicalTransactionSerializer.serializeForTxId(tx1),
            CanonicalTransactionSerializer.serializeForTxId(tx2)
        )
        assertEquals(tx1.txId, tx2.txId)
        assertEquals(64, tx1.txId.length)
        assertTrue(signer.verifyTransactionId(tx1))
        assertTrue(NmdAddressCodec.isValidAddressFormat(tx1.senderAddress))
        assertTrue(NmdAddressCodec.verifySenderAddressMatchesPublicKey(tx1.senderAddress, kp.publicKeyBytes, crypto))

        // Fixed-point precision tests
        assertEquals(12_345_678L, NmdAmountCodec.parseNmdToUnits("12.345678"))
        assertNull(NmdAmountCodec.parseNmdToUnits("1.0000001")) // finer than 1 micro-NMD rejected
        assertEquals("42.50", NmdAmountCodec.formatUnitsToNmd(42_500_000L))
    }

    // 2. Ed25519 Signing, Tamper Detection, and Sender Spoofing Defense
    @Test
    fun testSigningVerificationAndTamperRejection() {
        val validator = TransactionValidator(config, feeCalculator, signer)
        val tx = buildSignedTx()
        val now = tx.timestamp + 100L

        assertTrue(validator.validateStateless(tx, now).isValid)

        // Tamper amount without updating txId or signature
        val tamperedAmount = tx.copy(amountUnits = tx.amountUnits + 1_000_000L)
        val resAmount = validator.validateStateless(tamperedAmount, now)
        assertTrue(resAmount is TxValidationResult.Invalid)
        assertEquals(TxValidationErrorCode.INVALID_TX_ID, (resAmount as TxValidationResult.Invalid).code)

        // Tamper amount AND recompute txId, keeping original signature -> INVALID_SIGNATURE
        val forgedId = signer.computeTransactionId(tamperedAmount)
        val tamperedWithForgedId = tamperedAmount.copy(txId = forgedId)
        val resSig = validator.validateStateless(tamperedWithForgedId, now)
        assertTrue(resSig is TxValidationResult.Invalid)
        assertEquals(TxValidationErrorCode.INVALID_SIGNATURE, (resSig as TxValidationResult.Invalid).code)

        // Spoof sender address to another peer's valid address -> SENDER_PUBKEY_MISMATCH
        val attackerKp = crypto.generateEd25519KeyPair()
        val victimKp = crypto.generateEd25519KeyPair()
        val victimAddress = NmdAddressCodec.deriveAddressFromPublicKey(victimKp.publicKeyBytes, crypto)
        val spoofed = tx.copy(
            senderAddress = victimAddress,
            senderPublicKeyHex = crypto.toHex(attackerKp.publicKeyBytes)
        )
        val craftedMismatch = spoofed.copy(
            txId = signer.computeTransactionId(spoofed),
            signatureHex = crypto.toHex(
                crypto.sign(attackerKp.privateKeyBytes, CanonicalTransactionSerializer.serializeForSigning(spoofed))
            )
        )
        val resSpoof = validator.validateStateless(craftedMismatch, now)
        assertTrue(resSpoof is TxValidationResult.Invalid)
        assertEquals(TxValidationErrorCode.SENDER_PUBKEY_MISMATCH, (resSpoof as TxValidationResult.Invalid).code)
    }

    // 3. Transaction Types & Unsupported/Disabled Type Rejection
    @Test
    fun testTransactionTypesValidation() {
        val validator = TransactionValidator(config, feeCalculator, signer)
        val kp = crypto.generateEd25519KeyPair()
        val recipient = NmdAddressCodec.deriveAddressFromPublicKey(crypto.generateEd25519KeyPair().publicKeyBytes, crypto)

        val transfer = buildSignedTx(keyPair = kp, recipient = recipient, txType = TransactionType.TRANSFER)
        assertTrue(validator.validateStateless(transfer, transfer.timestamp + 100L).isValid)

        val accountInit = buildSignedTx(
            keyPair = kp,
            recipient = recipient,
            amountUnits = 0L,
            txType = TransactionType.ACCOUNT_INITIALIZATION
        )
        assertTrue(validator.validateStateless(accountInit, accountInit.timestamp + 100L).isValid)

        val futureTx = buildSignedTx(
            keyPair = kp,
            recipient = recipient,
            txType = TransactionType.FUTURE_SYSTEM_TRANSACTION
        )
        val futureRes = validator.validateStateless(futureTx, futureTx.timestamp + 100L)
        assertTrue(futureRes is TxValidationResult.Invalid)
        assertEquals(TxValidationErrorCode.TRANSACTION_TYPE_DISABLED_IN_STAGE, (futureRes as TxValidationResult.Invalid).code)

        // Unknown wire type parsed safely into UNKNOWN and rejected
        val unknownJson = transfer.toJson().replace("\"TRANSFER\"", "\"DEPLOY_SMART_CONTRACT\"")
        val parsedUnknown = NmdTransaction.fromJson(unknownJson)
        assertNotNull(parsedUnknown)
        assertEquals(TransactionType.UNKNOWN, parsedUnknown!!.txType)
        val unknownRes = validator.validateStateless(parsedUnknown, parsedUnknown.timestamp + 100L)
        assertTrue(unknownRes is TxValidationResult.Invalid)
        assertEquals(TxValidationErrorCode.UNSUPPORTED_TRANSACTION_TYPE, (unknownRes as TxValidationResult.Invalid).code)
    }

    // 4. Fee Calculation & Underpaid Fee Rejection
    @Test
    fun testFeeRulesAndUnderpaidRejection() {
        val validator = TransactionValidator(config, feeCalculator, signer)
        val kp = crypto.generateEd25519KeyPair()
        val smallTx = buildSignedTx(keyPair = kp, payload = ByteArray(0), txType = TransactionType.TRANSFER)
        val largeTx = buildSignedTx(keyPair = kp, payload = ByteArray(1024) { 0x41 }, txType = TransactionType.TRANSFER)
        val initTx = buildSignedTx(keyPair = kp, amountUnits = 0L, payload = ByteArray(0), txType = TransactionType.ACCOUNT_INITIALIZATION)

        val smallFee = feeCalculator.estimateFee(smallTx)
        val largeFee = feeCalculator.estimateFee(largeTx)
        val initFee = feeCalculator.estimateFee(initTx)

        assertTrue("Larger payload must cost more fee", largeFee.minimumRequiredFeeUnits > smallFee.minimumRequiredFeeUnits)
        assertTrue("ACCOUNT_INITIALIZATION has 1.5x fee factor", initFee.minimumRequiredFeeUnits > smallFee.minimumRequiredFeeUnits)
        assertTrue("Minimum floor 0.01 NMD respected", smallFee.minimumRequiredFeeUnits >= 10_000L)

        // Underpaid transaction rejected
        val underpaid = buildSignedTx(
            keyPair = kp,
            feeUnits = smallFee.minimumRequiredFeeUnits - 1L
        )
        val res = validator.validateStateless(underpaid, underpaid.timestamp + 50L)
        assertTrue(res is TxValidationResult.Invalid)
        assertEquals(TxValidationErrorCode.INVALID_FEE, (res as TxValidationResult.Invalid).code)
    }

    // 5. Negative Validation Cases (Amount, Chain ID, Protocol Version, Payload Size, Expiry, Address)
    @Test
    fun testValidationNegativeEdgeCases() {
        val validator = TransactionValidator(config, feeCalculator, signer)
        val kp = crypto.generateEd25519KeyPair()

        // Zero amount TRANSFER -> INVALID_AMOUNT
        val zeroTransfer = buildSignedTx(keyPair = kp, amountUnits = 0L, txType = TransactionType.TRANSFER)
        assertEquals(
            TxValidationErrorCode.INVALID_AMOUNT,
            (validator.validateStateless(zeroTransfer, zeroTransfer.timestamp + 10L) as TxValidationResult.Invalid).code
        )

        // Wrong chain ID -> INVALID_CHAIN_ID
        val wrongChain = buildSignedTx(keyPair = kp, chainId = "ethereum-mainnet")
        assertEquals(
            TxValidationErrorCode.INVALID_CHAIN_ID,
            (validator.validateStateless(wrongChain, wrongChain.timestamp + 10L) as TxValidationResult.Invalid).code
        )

        // Unsupported protocol version -> UNSUPPORTED_PROTOCOL_VERSION
        val badVersion = buildSignedTx(keyPair = kp, protocolVersion = 999)
        assertEquals(
            TxValidationErrorCode.UNSUPPORTED_PROTOCOL_VERSION,
            (validator.validateStateless(badVersion, badVersion.timestamp + 10L) as TxValidationResult.Invalid).code
        )

        // Oversized payload -> PAYLOAD_TOO_LARGE
        val hugePayload = ByteArray(validator.policy.maxPayloadBytes + 64) { 0x42 }
        val oversized = buildSignedTx(keyPair = kp, payload = hugePayload)
        assertEquals(
            TxValidationErrorCode.PAYLOAD_TOO_LARGE,
            (validator.validateStateless(oversized, oversized.timestamp + 10L) as TxValidationResult.Invalid).code
        )

        // Expired timestamp -> EXPIRED_TIMESTAMP
        val oldTs = 1_700_000_000_000L
        val expiredTx = buildSignedTx(keyPair = kp, timestamp = oldTs)
        val farFutureNow = oldTs + validator.policy.maxTransactionAgeMs + 5_000L
        assertEquals(
            TxValidationErrorCode.EXPIRED_TIMESTAMP,
            (validator.validateStateless(expiredTx, farFutureNow) as TxValidationResult.Invalid).code
        )

        // Malformed recipient address (non-NMD) -> INVALID_RECIPIENT_ADDRESS
        val badAddrTx = buildSignedTx(keyPair = kp, recipient = "0x1234567890abcdef")
        assertEquals(
            TxValidationErrorCode.INVALID_RECIPIENT_ADDRESS,
            (validator.validateStateless(badAddrTx, badAddrTx.timestamp + 10L) as TxValidationResult.Invalid).code
        )
    }

    // 6. Nonce Sequencing, Concurrent Double-Submission Guard & Out-of-Order Auto-Promotion
    @Test
    fun testNonceSequencingConcurrencyAndQueuedPromotion() = runBlocking {
        val engine = TransactionEngineManager(
            context = context,
            inMemoryStorage = true
        )
        engine.initialize()

        val kp = crypto.generateEd25519KeyPair()
        val senderAddr = NmdAddressCodec.deriveAddressFromPublicKey(kp.publicKeyBytes, crypto)

        // Concurrent nonce reservations must produce strictly unique sequential nonces [0, 1, 2, 3, 4]
        val reservedNonces = (1..5).map {
            async { engine.nonceManager.reserveNextNonce(senderAddr) }
        }.awaitAll()
        assertEquals(listOf(0L, 1L, 2L, 3L, 4L), reservedNonces.sorted())
        reservedNonces.forEach { engine.nonceManager.releaseReservation(senderAddr, it) }

        val now = System.currentTimeMillis()
        // Submit out-of-order nonce 1 before nonce 0 -> admitted as QUEUED
        val tx1 = buildSignedTx(keyPair = kp, nonce = 1L, timestamp = now)
        val res1 = engine.mempool.submitTransaction(tx1, nowMs = now)
        assertTrue(res1 is MempoolSubmissionResult.Accepted)
        assertEquals(MempoolTxStatus.QUEUED, (res1 as MempoolSubmissionResult.Accepted).record.status)

        // Duplicate nonce 1 rejected with DUPLICATE_NONCE
        val dupNonce1 = buildSignedTx(keyPair = kp, nonce = 1L, timestamp = now + 1L)
        val resDupNonce = engine.mempool.submitTransaction(dupNonce1, nowMs = now + 1L, recordRejection = false)
        assertTrue(resDupNonce is MempoolSubmissionResult.Rejected)
        assertEquals(TxValidationErrorCode.DUPLICATE_NONCE, (resDupNonce as MempoolSubmissionResult.Rejected).code)

        // Huge nonce gap -> NONCE_GAP_TOO_LARGE
        val gapTx = buildSignedTx(keyPair = kp, nonce = 99L, timestamp = now)
        val resGap = engine.mempool.submitTransaction(gapTx, nowMs = now, recordRejection = false)
        assertTrue(resGap is MempoolSubmissionResult.Rejected)
        assertEquals(TxValidationErrorCode.NONCE_GAP_TOO_LARGE, (resGap as MempoolSubmissionResult.Rejected).code)

        // Now submit missing nonce 0 -> admitted as VALIDATED AND auto-promotes nonce 1 to VALIDATED
        val tx0 = buildSignedTx(keyPair = kp, nonce = 0L, timestamp = now + 2L)
        val res0 = engine.mempool.submitTransaction(tx0, nowMs = now + 2L)
        assertTrue(res0 is MempoolSubmissionResult.Accepted)
        assertEquals(MempoolTxStatus.VALIDATED, (res0 as MempoolSubmissionResult.Accepted).record.status)

        val promotedTx1 = engine.mempool.getByTxId(tx1.txId)
        assertNotNull(promotedTx1)
        assertEquals(MempoolTxStatus.VALIDATED, promotedTx1!!.status)

        engine.close()
    }

    // 7. Persistent Room Mempool: Priority Ordering, Duplicates, Expiry & Restart Recovery
    @Test
    fun testPersistentMempoolOrderingExpiryAndRestartRecovery() = runBlocking {
        val dbName = "test_stage9_mempool_persist.db"
        val kpA = crypto.generateEd25519KeyPair()
        val kpB = crypto.generateEd25519KeyPair()
        val now = System.currentTimeMillis()

        val lowFeeTx = buildSignedTx(keyPair = kpA, nonce = 0L, feeUnits = 15_000L, timestamp = now)
        val highFeeTx = buildSignedTx(keyPair = kpB, nonce = 0L, feeUnits = 95_000L, timestamp = now)
        val expiredTx = buildSignedTx(
            keyPair = kpB,
            nonce = 1L,
            feeUnits = 25_000L,
            timestamp = now - 30_000L
        )

        val engine1 = TransactionEngineManager(
            context = context,
            dbName = dbName,
            inMemoryStorage = false
        )
        engine1.mempool.initialize(nowMs = now)

        assertTrue(engine1.mempool.submitTransaction(lowFeeTx, nowMs = now) is MempoolSubmissionResult.Accepted)
        assertTrue(engine1.mempool.submitTransaction(highFeeTx, nowMs = now) is MempoolSubmissionResult.Accepted)
        assertTrue(engine1.mempool.submitTransaction(expiredTx, nowMs = now) is MempoolSubmissionResult.Accepted)

        // Duplicate txId suppression
        val dupRes = engine1.mempool.submitTransaction(highFeeTx, nowMs = now)
        assertTrue(dupRes is MempoolSubmissionResult.Duplicate)
        assertEquals(1, engine1.mempoolStats.value.duplicateSuppressedCount)

        // Deterministic ordering: highFeeTx (95k) > expiredTx (25k) > lowFeeTx (15k)
        val candidates = engine1.mempool.getBlockCandidateTransactions(10)
        assertEquals(3, candidates.size)
        assertEquals(highFeeTx.txId, candidates[0].transaction.txId)
        assertEquals(expiredTx.txId, candidates[1].transaction.txId)
        assertEquals(lowFeeTx.txId, candidates[2].transaction.txId)

        // Simulate app restart (close engine1, reopen engine2 on same Room SQLite DB)
        engine1.close()

        val engine2 = TransactionEngineManager(
            context = context,
            dbName = dbName,
            inMemoryStorage = false
        )
        val restored = engine2.mempool.initialize(nowMs = now)
        assertEquals(3, restored.size)
        assertNotNull(engine2.mempool.getByTxId(highFeeTx.txId))
        assertEquals(1L, engine2.nonceManager.getAccountNonceState(lowFeeTx.senderAddress).nextAvailableNonce)

        // Advance time past expiredTx TTL -> pruned cleanly
        val afterExpiry = expiredTx.timestamp + TransactionPolicyConfig().maxTransactionAgeMs + 10_000L
        val pruned = engine2.mempool.pruneExpired(afterExpiry)
        assertEquals(1, pruned)
        assertEquals(MempoolTxStatus.EXPIRED, engine2.mempool.getByTxId(expiredTx.txId)?.status)

        engine2.close()
    }

    // 8. Wallet Integration: Local Signing, Dynamic Fee, Mempool Submission, Live Ledger Tracking
    @Test
    fun testWalletViewModelSignedTransactionFlowPreservesDemoBalances() = runBlocking {
        val storage = KeyStoreStorageService(
            context = context,
            preferencesName = "test_stage9_wallet_identity_prefs",
            allowTestEnvironmentFallback = true
        )
        val repo = IdentityRepositoryImpl(
            cryptoProvider = crypto,
            storageService = storage
        )
        val identityMgr = NodeIdentityManager(repo)
        val createdIdentity = identityMgr.generateNewIdentity()
        val expectedSenderAddr = NmdAddressCodec.deriveAddressFromPublicKeyHex(createdIdentity.publicKeyHex, crypto)
            ?: error("Invalid derived address")

        val engine = TransactionEngineManager(
            context = context,
            dbName = "test_stage9_wallet.db",
            inMemoryStorage = true
        )
        engine.initialize()
        engine.ledgerState.initialize()
        engine.ledgerState.creditDevOrTestAccount(
            address = expectedSenderAddr,
            amountUnits = 100L * NmdAmountCodec.UNITS_PER_NMD
        )

        val walletVm = WalletViewModel(
            injectedEngine = engine,
            injectedIdentityManager = identityMgr
        )

        repeat(40) {
            if (walletVm.isSigningIdentityReady.value && walletVm.walletState.value.totalUnits == 100_000_000L) {
                return@repeat
            }
            delay(25)
        }
        assertTrue(walletVm.isSigningIdentityReady.value)
        assertEquals(expectedSenderAddr, walletVm.signedSenderAddress.value)
        assertFalse(walletVm.walletState.value.isDemo)
        assertEquals(100.0, walletVm.walletState.value.totalBalance, 0.001)

        // Memo change dynamically updates serialized size & fee estimate once above the 0.01 NMD floor
        val emptyEstimate = walletVm.dynamicFeeEstimate.value
        val largeMemo = "Invoice #1042 - Stage 9 Signed P2P Settlement Test | ".repeat(8) // ~416 bytes
        walletVm.onTxMemoChange(largeMemo)
        val memoEstimate = walletVm.dynamicFeeEstimate.value
        assertTrue(memoEstimate.estimatedSizeBytes > emptyEstimate.estimatedSizeBytes)
        assertTrue(memoEstimate.minimumRequiredFeeUnits > emptyEstimate.minimumRequiredFeeUnits)

        // Set recipient & amount and sign/submit real transaction
        val recipientAddr = NmdAddressCodec.deriveAddressFromPublicKey(crypto.generateEd25519KeyPair().publicKeyBytes, crypto)
        walletVm.onRecipientChange(recipientAddr)
        walletVm.onAmountChange("15.25")
        walletVm.signAndSubmitRealTransaction()

        repeat(40) {
            if (walletVm.txSigningStatus.value == TxSigningUiStatus.SIGNED) return@repeat
            delay(25)
        }
        assertEquals(TxSigningUiStatus.SIGNED, walletVm.txSigningStatus.value)
        val submittedTxId = walletVm.lastSubmittedTxId.value
        assertNotNull(submittedTxId)

        val stored = engine.mempool.getByTxId(submittedTxId!!)
        assertNotNull(stored)
        assertEquals(MempoolTxStatus.VALIDATED, stored!!.status)
        assertEquals(15_250_000L, stored.transaction.amountUnits)
        assertEquals(expectedSenderAddr, stored.transaction.senderAddress)
        assertEquals(0L, stored.transaction.nonce)

        // Wait for WalletViewModel collector to reflect mempool reservation
        val expectedReservedUnits = 15_250_000L + stored.transaction.feeUnits
        repeat(40) {
            if (walletVm.walletState.value.reservedUnits == expectedReservedUnits) return@repeat
            delay(25)
        }
        assertEquals(100.0, walletVm.walletState.value.totalBalance, 0.001)
        assertEquals(expectedReservedUnits, walletVm.walletState.value.reservedUnits)
        assertEquals(100_000_000L - expectedReservedUnits, walletVm.walletState.value.availableUnits)

        engine.close()
    }

    // 9. P2P Gateway Zero-Trust Validation & Stage 8 Blockchain Integration Bridge
    @Test
    fun testP2pGatewayZeroTrustAndStage8BlockBridge() = runBlocking {
        val peerRegistry = DistributedPeerRegistry(
            context = null,
            scope = testScope,
            ioDispatcher = Dispatchers.IO
        )
        val blockchainManager = BlockchainManager(
            context = context,
            config = config,
            inMemoryStorage = true
        )
        val engine = TransactionEngineManager(
            context = context,
            blockchainManager = blockchainManager,
            peerRegistry = peerRegistry,
            dbName = "test_stage9_chain_bridge.db",
            inMemoryStorage = true
        )

        try {
            blockchainManager.initialize().getOrThrow()
            engine.initialize()

            val peerKp = crypto.generateEd25519KeyPair()
            val peerPubHex = crypto.toHex(peerKp.publicKeyBytes)
            val peerId = "nmd_peer_${peerPubHex.take(16)}"
            peerRegistry.registerOrUpdatePeer(
                peerId = peerId,
                endpoint = PeerEndpoint("192.168.1.42", 19100, peerId),
                source = DiscoverySource.MANUAL,
                publicKeyHex = peerPubHex,
                reachability = ReachabilityStatus.CONNECTED,
                capabilities = listOf(PeerCapability.STAGE7_DISCOVERY, PeerCapability.BLOCK_SYNC)
            )
            peerRegistry.recordSuccessfulAuth(peerId, peerPubHex)
            val initialRep = peerRegistry.getPeer(peerId)!!.reputationScore

            val untrustedSession = PeerSession(
                sessionId = "sess_untrusted",
                peerId = peerId,
                remotePublicKeyHex = peerPubHex,
                endpoint = PeerEndpoint("192.168.1.42", 19100),
                state = P2pSessionState.CONNECTED
            )
            val trustedSession = untrustedSession.copy(
                sessionId = "sess_trusted",
                state = P2pSessionState.ACTIVE
            )

            val tx1 = buildSignedTx(nonce = 0L)
            val validMsg = P2pMessage(
                senderPeerId = peerId,
                recipientPeerId = "*",
                messageType = P2pMessageType.TX_PAYLOAD,
                payload = tx1.toJson()
            )

            // Untrusted session must be rejected
            val untrustedRes = engine.p2pGateway.handleIncomingP2pTransaction(untrustedSession, validMsg, tx1.timestamp + 50L)
            assertTrue(untrustedRes is TxInboundResult.Rejected)

            // Trusted session admits valid transaction & suppresses duplicate replay
            val acceptedRes = engine.p2pGateway.handleIncomingP2pTransaction(trustedSession, validMsg, tx1.timestamp + 50L)
            assertTrue(acceptedRes is TxInboundResult.Accepted)
            assertEquals(MempoolTxStatus.VALIDATED, (acceptedRes as TxInboundResult.Accepted).mempoolStatus)

            val dupMsgRes = engine.p2pGateway.handleIncomingP2pTransaction(trustedSession, validMsg, tx1.timestamp + 60L)
            assertTrue(dupMsgRes is TxInboundResult.Duplicate)

            // Malicious tampered tx must be rejected & penalize peer reputation
            val tamperedMsg = validMsg.copy(
                payload = tx1.copy(amountUnits = tx1.amountUnits + 500_000L).toJson()
            )
            val badRes = engine.p2pGateway.handleIncomingP2pTransaction(trustedSession, tamperedMsg, tx1.timestamp + 70L)
            assertTrue(badRes is TxInboundResult.Rejected)
            assertTrue((badRes as TxInboundResult.Rejected).penalizedPeer)
            val penalizedRep = peerRegistry.getPeer(peerId)!!.reputationScore
            assertTrue("Peer reputation must decrease after invalid tx", penalizedRep < initialRep)

            // Broadcast from gateway to mocked session sender
            val outboundSent = mutableListOf<Pair<String, String>>()
            engine.p2pGateway.authenticatedSessionsProvider = { listOf(trustedSession) }
            engine.p2pGateway.sendTxPayloadToSession = { sessionId, _, payload ->
                outboundSent.add(sessionId to payload)
                Result.success(Unit)
            }
            val tx2 = buildSignedTx(nonce = 0L)
            engine.mempool.submitTransaction(tx2, nowMs = tx2.timestamp + 10L)
            val broadcastOutcome = engine.p2pGateway.broadcastTransaction(tx2)
            assertEquals(TransactionPropagationStatus.BROADCAST_COMPLETE, broadcastOutcome.propagationStatus)
            assertEquals(1, broadcastOutcome.deliveredPeers)
            assertEquals(1, outboundSent.size)

            // Stage 8 BlockBridge integration: references, Merkle root/proof, block commit & lookup
            val bridge = engine.blockBridge!!
            val candidates = engine.mempool.getBlockCandidateTransactions(10).map { it.transaction }
            val txRefs = bridge.toTransactionReferences(candidates)
            val body = BlockBody(transactionRefs = txRefs, extraData = "stage9-bridge-test")
            val parent = blockchainManager.getLatestBlock()!!
            val hasher: BlockHasher = blockchainManager.blockHasher
            val header = BlockHeader(
                height = parent.height + 1L,
                previousHash = parent.hash,
                timestamp = System.currentTimeMillis(),
                chainId = parent.chainId,
                protocolVersion = parent.header.protocolVersion,
                merkleRoot = bridge.computeMerkleRootForTransactions(candidates),
                transactionCount = txRefs.size,
                producerId = "test_stage9_bridge",
                consensusMetadata = ""
            )
            val block = Block(
                header = header,
                body = body,
                hash = hasher.computeHeaderHash(header)
            )
            val ingestRes = blockchainManager.submitIncomingBlock(block)
            assertTrue(ingestRes is BlockIngestionResult.Accepted)
            assertTrue(blockchainManager.verifyIntegrity().isHealthy)

            val proof = bridge.generateInclusionProof(tx1.txId, block)
            assertNotNull(proof)
            assertTrue(bridge.verifyInclusionProof(proof!!))

            val confirmedCount = bridge.onBlockCommitted(block)
            assertEquals(2, confirmedCount)
            assertEquals(1L, engine.nonceManager.getAccountNonceState(tx1.senderAddress).confirmedNextNonce)

            val lookup = bridge.lookupTransactionById(tx1.txId)
            assertNotNull(lookup)
            assertTrue(lookup!!.isConfirmedInBlock)
            assertEquals(block.height, lookup.includedInBlockHeight)
            assertTrue(bridge.verifyInclusionProof(lookup.merkleProof!!))
        } finally {
            engine.close()
            blockchainManager.close()
            peerRegistry.close()
        }
    }

    // 10. Multi-Device Independent Validation Over Serialized Wire Format
    @Test
    fun testIndependentCrossNodeValidation() = runBlocking {
        val nodeA = TransactionEngineManager(
            context = context,
            dbName = "test_stage9_node_a.db",
            inMemoryStorage = true
        )
        val nodeB = TransactionEngineManager(
            context = context,
            dbName = "test_stage9_node_b.db",
            inMemoryStorage = true
        )
        nodeA.initialize()
        nodeB.initialize()

        val aliceKp = crypto.generateEd25519KeyPair()
        val bobAddr = NmdAddressCodec.deriveAddressFromPublicKey(crypto.generateEd25519KeyPair().publicKeyBytes, crypto)
        val txFromA = buildSignedTx(
            keyPair = aliceKp,
            recipient = bobAddr,
            amountUnits = 75_000_000L, // 75 NMD
            nonce = 0L,
            payload = "cross-device-p2p".toByteArray()
        )
        val admA = nodeA.mempool.submitTransaction(txFromA, nowMs = txFromA.timestamp + 25L)
        assertTrue(admA is MempoolSubmissionResult.Accepted)

        // Transmit wire JSON to independent Node B
        val wireJson = txFromA.toJson()
        val decodedOnB = NmdTransaction.fromJson(wireJson)
        assertNotNull(decodedOnB)

        val admB = nodeB.mempool.submitTransaction(
            tx = decodedOnB!!,
            receivedFromPeerId = "peer_node_a",
            nowMs = txFromA.timestamp + 150L
        )
        assertTrue(admB is MempoolSubmissionResult.Accepted)
        val recordOnB = (admB as MempoolSubmissionResult.Accepted).record
        assertEquals(txFromA.txId, recordOnB.transaction.txId)
        assertEquals(MempoolTxStatus.VALIDATED, recordOnB.status)
        assertEquals(TransactionPropagationStatus.RECEIVED_FROM_PEER, recordOnB.propagationStatus)

        nodeA.close()
        nodeB.close()
    }
}
