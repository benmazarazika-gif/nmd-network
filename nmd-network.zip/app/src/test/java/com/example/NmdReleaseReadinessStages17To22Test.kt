package com.example

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.config.BlockchainParameters
import com.example.blockchain.config.NmdGenesisConfigs
import com.example.blockchain.economics.TokenomicsEngine
import com.example.blockchain.state.LedgerStateEngine
import com.example.crypto.NodeIdentityManager
import com.example.crypto.backup.IdentityBackupManager
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.p2p.security.trust.IdentityTrustCheckResult
import com.example.p2p.security.trust.PeerTrustManager
import com.example.service.NmdNodeForegroundService
import com.example.transaction.crypto.NmdAddressCodec
import com.example.transaction.crypto.TransactionSigner
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionType
import com.example.transaction.storage.ConfirmedTransactionEntry
import com.example.transaction.storage.RoomTransactionStorage
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.atomic.AtomicLong

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdReleaseReadinessStages17To22Test {

    private lateinit var context: Context
    private val crypto = BouncyCastleEd25519Provider()
    private val signer = TransactionSigner(crypto)
    private val storages = mutableListOf<RoomTransactionStorage>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    @After
    fun tearDown() {
        storages.forEach { it.close() }
        storages.clear()
        context.getSharedPreferences("test_stage19_backup_prefs_a", Context.MODE_PRIVATE).edit().clear().commit()
        context.getSharedPreferences("test_stage19_backup_prefs_b", Context.MODE_PRIVATE).edit().clear().commit()
        context.getSharedPreferences("test_stage20_trust_prefs", Context.MODE_PRIVATE).edit().clear().commit()
    }

    private fun newInMemoryStorage(): RoomTransactionStorage {
        return RoomTransactionStorage(context = context, inMemory = true).also { storages.add(it) }
    }

    private fun buildAndSignTx(
        keyPair: com.example.crypto.provider.Ed25519KeyPairResult,
        recipientAddress: String,
        amountUnits: Long,
        feeUnits: Long,
        nonce: Long,
        txType: TransactionType = TransactionType.TRANSFER,
        chainId: String = NmdGenesisConfigs.LOCAL_DEV.chainId
    ): NmdTransaction {
        val pubHex = crypto.toHex(keyPair.publicKeyBytes)
        val senderAddr = NmdAddressCodec.deriveAddressFromPublicKey(keyPair.publicKeyBytes, crypto)
        val unsigned = NmdTransaction(
            chainId = chainId,
            protocolVersion = 1,
            senderAddress = senderAddr,
            recipientAddress = recipientAddress,
            amountUnits = amountUnits,
            feeUnits = feeUnits,
            nonce = nonce,
            timestamp = 1_700_000_000_000L + nonce,
            txType = txType,
            senderPublicKeyHex = pubHex
        )
        return signer.signWithKeyPair(unsigned, keyPair.privateKeyBytes)
    }

    // 1. Stage 17: Deterministic Account State Machine & Canonical stateRoot
    @Test
    fun testLedgerStateEngineDeterministicExecutionAndStrictBalances() = runBlocking {
        val storageA = newInMemoryStorage()
        val storageB = newInMemoryStorage()
        val ledgerA = LedgerStateEngine(storageA, crypto, enforceStrictBalances = true)
        val ledgerB = LedgerStateEngine(storageB, crypto, enforceStrictBalances = true)
        ledgerA.initialize()
        ledgerB.initialize()

        val aliceKp = crypto.generateEd25519KeyPair()
        val bobKp = crypto.generateEd25519KeyPair()
        val aliceAddr = NmdAddressCodec.deriveAddressFromPublicKey(aliceKp.publicKeyBytes, crypto)
        val bobAddr = NmdAddressCodec.deriveAddressFromPublicKey(bobKp.publicKeyBytes, crypto)

        ledgerA.creditDevOrTestAccount(aliceAddr, 500_000_000L)
        ledgerB.creditDevOrTestAccount(aliceAddr, 500_000_000L)

        val validTx = buildAndSignTx(
            keyPair = aliceKp,
            recipientAddress = bobAddr,
            amountUnits = 120_000_000L, // 120 NMD
            feeUnits = 10_000L,         // 0.01 NMD
            nonce = 0L,
            chainId = NmdGenesisConfigs.LOCAL_DEV.chainId
        )
        val overdraftTx = buildAndSignTx(
            keyPair = aliceKp,
            recipientAddress = bobAddr,
            amountUnits = 1_000_000_000L, // Exceeds remaining 379.99 NMD
            feeUnits = 10_000L,
            nonce = 1L,
            chainId = NmdGenesisConfigs.LOCAL_DEV.chainId
        )

        val resA = ledgerA.applyFinalizedBlock(
            transactions = listOf(validTx, overdraftTx),
            blockHeight = 1L,
            nowMs = 1_700_000_000_000L
        )
        val resB = ledgerB.applyFinalizedBlock(
            transactions = listOf(validTx, overdraftTx),
            blockHeight = 1L,
            nowMs = 1_700_000_000_000L
        )

        assertEquals(resA.newStateRoot, resB.newStateRoot)
        assertEquals(listOf(validTx.txId), resA.appliedTxIds)
        assertTrue(resA.rejectedTxReasons.containsKey(overdraftTx.txId))

        assertEquals(379_990_000L, ledgerA.getBalanceUnits(aliceAddr))
        assertEquals(120_000_000L, ledgerA.getBalanceUnits(bobAddr))
        assertEquals(10_000L, ledgerA.getBalanceUnits(LedgerStateEngine.BURN_SINK_ADDRESS))
        assertEquals(1L, ledgerA.getAccountState(aliceAddr).confirmedNonce)

        // Duplicate block height replay must be a safe no-op
        val replayRes = ledgerA.applyFinalizedBlock(listOf(validTx), blockHeight = 1L)
        assertTrue(replayRes.appliedTxIds.isEmpty())
        assertEquals(resA.newStateRoot, replayRes.newStateRoot)
    }

    // 2. Stage 17/18: Permanent Room Confirmed Transaction Archival
    @Test
    fun testRoomConfirmedArchiveSurvivesMempoolCleanup() = runBlocking {
        val storage = newInMemoryStorage()
        val aliceKp = crypto.generateEd25519KeyPair()
        val bobAddr = NmdAddressCodec.deriveAddressFromPublicKey(crypto.generateEd25519KeyPair().publicKeyBytes, crypto)
        val aliceAddr = NmdAddressCodec.deriveAddressFromPublicKey(aliceKp.publicKeyBytes, crypto)

        val tx = buildAndSignTx(
            keyPair = aliceKp,
            recipientAddress = bobAddr,
            amountUnits = 42L * NmdAmountCodec.UNITS_PER_NMD,
            feeUnits = 10_000L,
            nonce = 0L,
            txType = TransactionType.TRANSFER
        )

        storage.saveConfirmedArchive(
            listOf(
                ConfirmedTransactionEntry(
                    transaction = tx,
                    blockHeight = 7L,
                    blockHash = "0xblock0007",
                    txIndex = 0,
                    confirmedAtMs = 1_736_000_000_000L
                )
            )
        )

        val byBlock = storage.getConfirmedArchiveForBlock(7L)
        assertEquals(1, byBlock.size)
        assertEquals(tx.txId, byBlock.first().transaction.txId)

        val bySender = storage.getConfirmedArchiveForAddress(aliceAddr)
        assertEquals(1, bySender.size)
        val byRecipient = storage.getConfirmedArchiveForAddress(bobAddr)
        assertEquals(1, byRecipient.size)
    }

    // 3. Stage 22: Dormant Tokenomics Economics & Mainnet Guard
    @Test
    fun testTokenomicsCapsSplitAndDormantActivationGuard() {
        val dormantParams = BlockchainParameters()
        assertFalse(TokenomicsEngine.isTokenIssuanceActive(dormantParams))
        assertEquals(
            0L,
            TokenomicsEngine.computeCumulativeMintedUnits(
                parameters = dormantParams,
                mainnetGenesisTimestampMs = 1_000L,
                timestampMs = 1_000L + TokenomicsEngine.CLIFF_DURATION_MS + TokenomicsEngine.RELEASE_DURATION_MS
            )
        )
        assertTrue(
            TokenomicsEngine.validateActivationPrerequisites(
                parameters = dormantParams,
                independentAuditApproved = true,
                minimumBftValidatorsOnline = 4
            ).isFailure
        )

        val mainnetParams = BlockchainParameters(tokenIssuanceEnabled = true, isPublicMainnetActive = true)
        assertTrue(TokenomicsEngine.validateActivationPrerequisites(mainnetParams, true, 4).isSuccess)
        assertTrue(TokenomicsEngine.validateActivationPrerequisites(mainnetParams, false, 4).isFailure)
        assertTrue(TokenomicsEngine.validateActivationPrerequisites(mainnetParams, true, 3).isFailure)

        // 1-year cliff returns 0 before 1y, and 100% of 99B NMD at 25y
        val genesis = 1_750_000_000_000L
        assertEquals(0L, TokenomicsEngine.computeCumulativeMintedUnits(mainnetParams, genesis, genesis + TokenomicsEngine.CLIFF_DURATION_MS - 1L))
        assertEquals(
            TokenomicsEngine.EMISSION_SUPPLY_UNITS,
            TokenomicsEngine.computeCumulativeMintedUnits(
                mainnetParams,
                genesis,
                genesis + TokenomicsEngine.CLIFF_DURATION_MS + TokenomicsEngine.RELEASE_DURATION_MS
            )
        )
        assertEquals(100_000_000_000L * NmdAmountCodec.UNITS_PER_NMD, TokenomicsEngine.GENESIS_ALLOCATION_UNITS + TokenomicsEngine.EMISSION_SUPPLY_UNITS)

        // Revenue/fee split: 5% founder, 15% treasury, 20% burn, 60% validators
        val split = TokenomicsEngine.distributeUnits(1_000_000L)
        assertEquals(50_000L, split.founderUnits)
        assertEquals(150_000L, split.treasuryUnits)
        assertEquals(200_000L, split.burnedUnits)
        assertEquals(600_000L, split.validatorsPoolUnits)
        assertEquals(1_000_000L, split.totalUnits)
    }

    // 4. Stage 19/20: Keystore JSON & 33-Word Recovery Phrase Lossless Round-Trips
    @Test
    fun testIdentityBackupEncryptedKeystoreAnd33WordRecovery() = runBlocking {
        val storageA = KeyStoreStorageService(context, "test_stage19_backup_prefs_a", allowTestEnvironmentFallback = true)
        val storageB = KeyStoreStorageService(context, "test_stage19_backup_prefs_b", allowTestEnvironmentFallback = true)
        val mgrA = NodeIdentityManager(IdentityRepositoryImpl(crypto, storageA))
        val mgrB = NodeIdentityManager(IdentityRepositoryImpl(crypto, storageB))

        val origId = mgrA.generateNewIdentity()
        val origAddr = NmdAddressCodec.deriveAddressFromPublicKeyHex(origId.publicKeyHex, crypto)

        // Export & restore PBKDF2 + AES-256-GCM JSON keystore
        val keystoreJson = IdentityBackupManager.exportEncryptedKeystoreJson(mgrA, "StrongPassphrase!99").getOrThrow()
        assertTrue(IdentityBackupManager.restoreFromEncryptedKeystoreJson(mgrB, keystoreJson, "WrongPassphrase!").isFailure)

        val restoredJsonOutcome = IdentityBackupManager.restoreFromEncryptedKeystoreJson(mgrB, keystoreJson, "StrongPassphrase!99").getOrThrow()
        assertEquals(origId.nodeId, restoredJsonOutcome.identity.nodeId)
        assertEquals(origAddr, restoredJsonOutcome.nmdAddress)

        // Export 33-word checksummed phrase & detect 1-word tamper
        val words = IdentityBackupManager.exportRecoveryPhraseWords(mgrA).getOrThrow()
        assertEquals(33, words.size)

        val tampered = words.toMutableList().apply { this[0] = if (this[0] == "acorn") "anchor" else "acorn" }
        assertTrue(IdentityBackupManager.restoreFromRecoveryPhrase(mgrB, tampered.joinToString(" ")).isFailure)

        mgrB.deleteIdentity()
        val restoredPhraseOutcome = IdentityBackupManager.restoreFromRecoveryPhrase(mgrB, words.joinToString(" ")).getOrThrow()
        assertEquals(origId.publicKeyHex.lowercase(), restoredPhraseOutcome.identity.publicKeyHex.lowercase())
        assertEquals(origAddr, restoredPhraseOutcome.nmdAddress)
    }

    // 5. Stage 20: PeerTrustManager CGNAT IP Lease Expiry vs Active MITM Blocking
    @Test
    fun testPeerTrustManagerCgnatRoamingVsMitmDetection() {
        val clock = AtomicLong(1_000_000L)
        val trust = PeerTrustManager(
            context = context,
            preferencesName = "test_stage20_trust_prefs",
            cryptoProvider = crypto,
            endpointPinTtlMs = 15 * 60 * 1000L,
            clockMs = { clock.get() }
        )

        val kpA = crypto.generateEd25519KeyPair()
        val pubHexA = crypto.toHex(kpA.publicKeyBytes)
        val idA = "nmd_${pubHexA.take(16)}"

        val kpB = crypto.generateEd25519KeyPair()
        val pubHexB = crypto.toHex(kpB.publicKeyBytes)
        val idB = "nmd_${pubHexB.take(16)}"

        trust.recordAuthenticatedIdentity(idA, pubHexA, "198.51.100.10:19100")

        // Immediate spoof by Peer B at same endpoint within TTL must be rejected
        val mitmRes = trust.checkHandshakeIdentityAllowed(idB, pubHexB, "198.51.100.10:19100")
        assertTrue(mitmRes is IdentityTrustCheckResult.IdentityMismatch)

        // Advance time beyond 15-minute CGNAT TTL -> legitimate carrier IP reassignment allowed
        clock.addAndGet(16 * 60 * 1000L)
        val cgnatRes = trust.checkHandshakeIdentityAllowed(idB, pubHexB, "198.51.100.10:19100")
        assertTrue(cgnatRes is IdentityTrustCheckResult.Allowed)

        // Key mismatch for pinned Node ID is always rejected
        val keyTamper = trust.checkHandshakeIdentityAllowed(idA, pubHexB, "ice://peer-relay")
        assertTrue(keyTamper is IdentityTrustCheckResult.IdentityMismatch)
    }

    // 6. Chain-ID Room DB Isolation
    @Test
    fun testChainIdDatabaseIsolationNames() {
        val localDb = BlockchainConfig.databaseNameFor("nmd_blockchain_core.db", NmdGenesisConfigs.LOCAL_DEV.chainId)
        val testnetDb = BlockchainConfig.databaseNameFor("nmd_blockchain_core.db", NmdGenesisConfigs.PRIVATE_TESTNET.chainId)
        val mainnetDb = BlockchainConfig.databaseNameFor("nmd_blockchain_core.db", NmdGenesisConfigs.MAINNET_FUTURE.chainId)

        assertEquals("nmd_blockchain_core.db", localDb)
        assertEquals("nmd_blockchain_core_nmd-private-testnet-1.db", testnetDb)
        assertEquals("nmd_blockchain_core_nmd-mainnet-reserved.db", mainnetDb)
    }

    // 7. Play-Compliant Node DataSync Foreground Service Lifecycle
    @Test
    fun testForegroundServiceStartStopTransitions() {
        val controller = Robolectric.buildService(NmdNodeForegroundService::class.java).create()
        val service = controller.get()

        val startIntent = Intent(context, NmdNodeForegroundService::class.java).apply {
            action = NmdNodeForegroundService.ACTION_START
            putExtra(NmdNodeForegroundService.EXTRA_STATUS_SUMMARY, "Height #10 • 3 peers")
        }
        service.onStartCommand(startIntent, 0, 1)
        assertTrue(NmdNodeForegroundService.isRunning.value)

        val stopIntent = Intent(context, NmdNodeForegroundService::class.java).apply {
            action = NmdNodeForegroundService.ACTION_STOP
        }
        service.onStartCommand(stopIntent, 0, 2)
        assertFalse(NmdNodeForegroundService.isRunning.value)
        controller.destroy()
    }
}
