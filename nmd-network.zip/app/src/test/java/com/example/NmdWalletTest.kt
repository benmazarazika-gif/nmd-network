package com.example

import android.content.Context
import android.content.res.Configuration
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.data.NmdAddressValidationResult
import com.example.data.NmdAddressValidator
import com.example.data.TransactionStatus
import com.example.transaction.TransactionEngineManager
import com.example.transaction.WalletTxCreationOutcome
import com.example.transaction.crypto.NmdAddressCodec
import com.example.transaction.model.NmdAmountCodec
import com.example.ui.components.qr.QrCodeGenerator
import com.example.ui.screens.WalletViewModel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdWalletTest {

    private lateinit var viewModel: WalletViewModel
    private lateinit var context: Context
    private val crypto = BouncyCastleEd25519Provider()
    private val enginesToClose = mutableListOf<TransactionEngineManager>()

    @Before
    fun setup() {
        viewModel = WalletViewModel()
        context = ApplicationProvider.getApplicationContext()
    }

    @After
    fun tearDown() {
        enginesToClose.forEach { it.close() }
        enginesToClose.clear()
        context.getSharedPreferences("test_wallet_stage19_prefs", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
    }

    private suspend fun createFundedLiveWallet(initialNmdUnits: Long): Pair<WalletViewModel, String> {
        val storage = KeyStoreStorageService(
            context = context,
            preferencesName = "test_wallet_stage19_prefs",
            allowTestEnvironmentFallback = true
        )
        val idMgr = NodeIdentityManager(IdentityRepositoryImpl(crypto, storage))
        val identity = idMgr.generateNewIdentity()
        val address = NmdAddressCodec.deriveAddressFromPublicKeyHex(identity.publicKeyHex, crypto)
            ?: error("Invalid derived address")

        val engine = TransactionEngineManager(
            context = context,
            dbName = "test_wallet_${System.nanoTime()}.db",
            inMemoryStorage = true
        )
        enginesToClose.add(engine)
        engine.initialize()
        engine.ledgerState.initialize()
        if (initialNmdUnits > 0L) {
            engine.ledgerState.creditDevOrTestAccount(address, initialNmdUnits)
        }

        val vm = WalletViewModel(
            injectedEngine = engine,
            injectedIdentityManager = idMgr
        )
        repeat(40) {
            if (vm.isSigningIdentityReady.value && vm.walletState.value.totalUnits == initialNmdUnits) {
                return vm to address
            }
            delay(25)
        }
        return vm to address
    }

    // =========================================================================
    // 1. Initial State & Currency Consistency Regression Test (Zero Fake State)
    // =========================================================================

    @Test
    fun testInitialWalletStateAndCurrencyPreservation() {
        val state = viewModel.walletState.value
        assertFalse("Wallet must never default to fake demo mode", state.isDemo)
        assertEquals(0.0, state.totalBalance, 0.001)
        assertEquals(0.0, state.availableBalance, 0.001)
        assertEquals(0.0, state.reservedBalance, 0.001)
        assertEquals("", state.walletAddress)
        assertEquals("NMD", state.tokenSymbol)
        assertEquals("0.01 NMD", state.estimatedFeeFormatted)
        assertTrue(state.isBalanceVisible)
        assertEquals(state.totalBalance, state.availableBalance + state.reservedBalance, 0.001)
    }

    @Test
    fun testCurrencyRegressionConsistency() = runBlocking {
        // 1. Symbol in data model
        assertEquals("NMD", viewModel.walletState.value.tokenSymbol)

        // 2. Unit label in all locales must strictly remain "NMD"
        val locales = listOf(Locale.ENGLISH, Locale.FRENCH, Locale.forLanguageTag("ar"))
        for (loc in locales) {
            val locCtx = getLocalizedContext(loc)
            val unitStr = locCtx.getString(R.string.wallet_unit)
            assertEquals("Currency unit in locale $loc must be NMD", "NMD", unitStr)
        }

        // 3. Real LedgerState credit + Ed25519 signed transfer updates reserved & available units accurately
        val (liveVm, _) = createFundedLiveWallet(2_500_000_000L) // 2,500 NMD
        val initial = liveVm.walletState.value
        assertFalse(initial.isDemo)
        assertEquals(2500.0, initial.totalBalance, 0.001)
        assertEquals(2500.0, initial.availableBalance, 0.001)

        val tx1Deferred = CompletableDeferred<WalletTxCreationOutcome>()
        liveVm.onRecipientChange("nmd1x884k390z882p004f2vl7m")
        liveVm.onAmountChange("30.0")
        liveVm.confirmAndSignTransfer { tx1Deferred.complete(it) }
        val outcome1 = tx1Deferred.await()
        assertTrue("Signed tx must succeed: $outcome1", outcome1 is WalletTxCreationOutcome.Submitted)
        val record1 = (outcome1 as WalletTxCreationOutcome.Submitted).record

        val expectedReserved1 = record1.transaction.amountUnits + record1.transaction.feeUnits
        repeat(40) {
            if (liveVm.walletState.value.reservedUnits == expectedReserved1) return@repeat
            delay(25)
        }
        val afterTx1 = liveVm.walletState.value
        assertEquals(expectedReserved1, afterTx1.reservedUnits)
        assertEquals(2_500_000_000L - expectedReserved1, afterTx1.availableUnits)
        assertEquals(afterTx1.totalUnits, afterTx1.availableUnits + afterTx1.reservedUnits)
    }

    @Test
    fun testBalanceVisibilityToggle() {
        assertTrue(viewModel.walletState.value.isBalanceVisible)
        viewModel.toggleBalanceVisibility()
        assertFalse(viewModel.walletState.value.isBalanceVisible)
        viewModel.toggleBalanceVisibility()
        assertTrue(viewModel.walletState.value.isBalanceVisible)
    }

    // =========================================================================
    // 2. NMD Address Format & Validation
    // =========================================================================

    @Test
    fun testNmdAddressValidatorRejects0xGenericAddresses() {
        val ethAddress = "0x4b789104fa289c091e893240fb872019b8417c82"
        val result = NmdAddressValidator.validateDemoAddress(ethAddress)
        assertTrue("0x addresses must be invalid", result is NmdAddressValidationResult.Invalid)
        assertEquals(
            R.string.send_error_rejected_0x_address,
            (result as NmdAddressValidationResult.Invalid).errorRes
        )

        // Via ViewModel
        viewModel.onRecipientChange(ethAddress)
        viewModel.onAmountChange("10.0")
        assertFalse(viewModel.validateAndProceedToSendReview())
        assertEquals(R.string.send_error_rejected_0x_address, viewModel.addressError.value)
    }

    @Test
    fun testNmdAddressValidatorRequiresNmd1Prefix() {
        val badPrefix = "cosmos1q9x4p2v7km83z95w4a8lj2"
        val result = NmdAddressValidator.validateDemoAddress(badPrefix)
        assertTrue(result is NmdAddressValidationResult.Invalid)
        assertEquals(
            R.string.send_error_invalid_prefix,
            (result as NmdAddressValidationResult.Invalid).errorRes
        )
    }

    @Test
    fun testNmdAddressValidatorLengthBounds() {
        val tooShort = "nmd1short"
        val resultShort = NmdAddressValidator.validateDemoAddress(tooShort)
        assertTrue(resultShort is NmdAddressValidationResult.Invalid)
        assertEquals(
            R.string.send_error_invalid_length,
            (resultShort as NmdAddressValidationResult.Invalid).errorRes
        )

        val tooLong = "nmd1" + "a".repeat(60)
        val resultLong = NmdAddressValidator.validateDemoAddress(tooLong)
        assertTrue(resultLong is NmdAddressValidationResult.Invalid)
        assertEquals(
            R.string.send_error_invalid_length,
            (resultLong as NmdAddressValidationResult.Invalid).errorRes
        )
    }

    @Test
    fun testNmdAddressValidatorInvalidCharacters() {
        val invalidAddresses = listOf(
            "nmd1q9x4p2v7km83z95w4a8lB2",
            "nmd1q9x4p2v7km83z95w4a8l12",
            "nmd1q9x4p2v7km83z95w4a8lb2",
            "nmd1q9x4p2v7km83z95w4a8li2",
            "nmd1q9x4p2v7km83z95w4a8lo2",
            "nmd1q9x4p2v7km83z95w4a8l#2"
        )

        for (addr in invalidAddresses) {
            val res = NmdAddressValidator.validateDemoAddress(addr)
            assertTrue("Address $addr should fail with invalid characters", res is NmdAddressValidationResult.Invalid)
            assertEquals(R.string.send_error_invalid_characters, (res as NmdAddressValidationResult.Invalid).errorRes)
        }
    }

    @Test
    fun testNmdAddressValidatorEmptyAddress() {
        val emptyResult = NmdAddressValidator.validateDemoAddress("")
        assertTrue(emptyResult is NmdAddressValidationResult.Invalid)
        assertEquals(R.string.send_error_empty_address, (emptyResult as NmdAddressValidationResult.Invalid).errorRes)

        val whitespaceResult = NmdAddressValidator.validateDemoAddress("   ")
        assertTrue(whitespaceResult is NmdAddressValidationResult.Invalid)
        assertEquals(R.string.send_error_empty_address, (whitespaceResult as NmdAddressValidationResult.Invalid).errorRes)
    }

    @Test
    fun testNmdAddressValidatorValidAddresses() {
        val validAddresses = listOf(
            "nmd1q9x4p2v7km83z95w4a8lj2",
            "nmd1x884k390z882p004f2vl7m",
            "nmd1d402z9834nm9820f4ex98k",
            "nmd1q3809zkm480290spl89k34m"
        )
        for (addr in validAddresses) {
            val result = NmdAddressValidator.validateDemoAddress(addr)
            assertTrue("Address $addr should be valid format", result is NmdAddressValidationResult.Valid)
        }
    }

    // =========================================================================
    // 3. Transaction History Audit: Empty Until Real Signed Submission / Confirmation
    // =========================================================================

    @Test
    fun testInitialTransactionsAreEmptyNeverFakeDemo() {
        val initialTxs = viewModel.transactions.value
        assertTrue("Initial wallet history must be empty with no fake DEMO fixtures", initialTxs.isEmpty())
    }

    @Test
    fun testSignedTransferAppearsInTransactionsAsPending() = runBlocking {
        val (liveVm, _) = createFundedLiveWallet(500L * NmdAmountCodec.UNITS_PER_NMD)
        liveVm.onRecipientChange("nmd1x884k390z882p004f2vl7m")
        liveVm.onAmountChange("25.0")

        assertTrue(liveVm.validateAndProceedToSendReview())
        val deferred = CompletableDeferred<WalletTxCreationOutcome>()
        liveVm.confirmAndSignTransfer { deferred.complete(it) }
        val outcome = deferred.await()
        assertTrue(outcome is WalletTxCreationOutcome.Submitted)
        val record = (outcome as WalletTxCreationOutcome.Submitted).record

        repeat(40) {
            if (liveVm.transactions.value.any { it.txHash == record.transaction.txId }) return@repeat
            delay(25)
        }

        val firstInList = liveVm.transactions.value.firstOrNull { it.txHash == record.transaction.txId }
        assertNotNull(firstInList)
        assertEquals(TransactionStatus.PENDING, firstInList!!.status)
    }

    // =========================================================================
    // 4. Balance Calculations & Deficit Guard (Negative Balance Prevention)
    // =========================================================================

    @Test
    fun testAmountValidationAndDeficitGuard() = runBlocking {
        val (liveVm, _) = createFundedLiveWallet(2_430_750_000L) // 2430.75 NMD
        liveVm.onRecipientChange("nmd1q9x4p2v7km83z95w4a8lj2")

        // Zero amount rejected
        liveVm.onAmountChange("0.0")
        assertFalse(liveVm.validateAndProceedToSendReview())
        assertEquals(R.string.send_error_zero_amount, liveVm.amountError.value)

        // Negative amount rejected
        liveVm.onAmountChange("-15.0")
        assertFalse(liveVm.validateAndProceedToSendReview())
        assertEquals(R.string.send_error_zero_amount, liveVm.amountError.value)

        // Excessive amount exceeding available balance (2430.75)
        liveVm.onAmountChange("2500.0")
        assertFalse(liveVm.validateAndProceedToSendReview())
        assertEquals(R.string.send_error_insufficient_balance, liveVm.amountError.value)

        // Valid amount within available balance
        liveVm.onAmountChange("100.0")
        assertTrue(liveVm.validateAndProceedToSendReview())
        assertNull(liveVm.amountError.value)
    }

    @Test
    fun testSignedTransferCannotCreateNegativeBalance() = runBlocking {
        val (liveVm, _) = createFundedLiveWallet(200L * NmdAmountCodec.UNITS_PER_NMD)
        val initialAvailable = liveVm.walletState.value.availableUnits

        liveVm.onRecipientChange("nmd1q9x4p2v7km83z95w4a8lj2")
        liveVm.onAmountChange("50.0")

        val deferred = CompletableDeferred<WalletTxCreationOutcome>()
        liveVm.confirmAndSignTransfer { deferred.complete(it) }
        val outcome = deferred.await()
        assertTrue(outcome is WalletTxCreationOutcome.Submitted)
        val record = (outcome as WalletTxCreationOutcome.Submitted).record

        val expectedDeduction = record.transaction.amountUnits + record.transaction.feeUnits
        repeat(40) {
            if (liveVm.walletState.value.reservedUnits == expectedDeduction) return@repeat
            delay(25)
        }

        val stateAfter = liveVm.walletState.value
        assertEquals(initialAvailable - expectedDeduction, stateAfter.availableUnits)
        assertEquals(expectedDeduction, stateAfter.reservedUnits)
        assertTrue(stateAfter.availableBalance >= 0.0)
        assertTrue(stateAfter.totalBalance >= 0.0)
    }

    @Test
    fun testPercentageShortcuts() = runBlocking {
        val (liveVm, _) = createFundedLiveWallet(1_000_000_000L) // 1000.00 NMD
        val available = liveVm.walletState.value.availableBalance

        liveVm.applyPercentage("25%")
        assertEquals(available * 0.25, liveVm.amount.value.toDouble(), 0.05)

        liveVm.applyPercentage("50%")
        assertEquals(available * 0.50, liveVm.amount.value.toDouble(), 0.05)

        liveVm.applyPercentage("75%")
        assertEquals(available * 0.75, liveVm.amount.value.toDouble(), 0.05)

        liveVm.applyPercentage("MAX")
        assertEquals(available - liveVm.walletState.value.estimatedFee, liveVm.amount.value.toDouble(), 0.05)
    }

    // =========================================================================
    // 5. QR Code Matrix Geometry & Properties
    // =========================================================================

    @Test
    fun testQrCodeGeneratorVisualPrototypeProperties() {
        val testAddr = "nmd1q9x4p2v7km83z95w4a8lj2"
        val matrix = QrCodeGenerator.encode(testAddr)

        assertEquals(29, matrix.size)
        assertEquals(29, matrix[0].size)
        assertEquals(QrCodeGenerator.MATRIX_SIZE, matrix.size)

        assertTrue(matrix[0][0])
        assertTrue(matrix[0][6])
        assertTrue(matrix[6][0])
        assertTrue(matrix[6][6])
        assertTrue(matrix[3][3])

        val enCtx = getLocalizedContext(Locale.ENGLISH)
        val qrLabel = enCtx.getString(R.string.receive_qr_label)
        assertTrue("QR label must remain present", qrLabel.contains("prototype", ignoreCase = true))
    }

    // =========================================================================
    // 6. Localization Audit Across English, Arabic, and French
    // =========================================================================

    private fun getLocalizedContext(locale: Locale): Context {
        val config = Configuration(context.resources.configuration).apply {
            setLocale(locale)
        }
        return context.createConfigurationContext(config)
    }

    @Test
    fun testEnglishLocalizationAudit() {
        val enContext = getLocalizedContext(Locale.ENGLISH)
        assertEquals("NMD Wallet", enContext.getString(R.string.wallet_title))
        assertEquals("Total Balance", enContext.getString(R.string.wallet_total_balance))
        assertEquals("NMD", enContext.getString(R.string.wallet_unit))
        assertEquals("Demo (Simulated)", enContext.getString(R.string.history_status_demo))
        assertEquals("DEMO", enContext.getString(R.string.history_demo_badge))
        assertTrue(enContext.getString(R.string.send_error_rejected_0x_address).contains("0x"))
        assertTrue(enContext.getString(R.string.security_screen_title).contains("Prototype"))
        assertTrue(enContext.getString(R.string.receive_qr_label).contains("prototype", ignoreCase = true))
    }

    @Test
    fun testFrenchLocalizationAudit() {
        val frContext = getLocalizedContext(Locale.FRENCH)
        assertEquals("Portefeuille NMD", frContext.getString(R.string.wallet_title))
        assertEquals("Solde Total", frContext.getString(R.string.wallet_total_balance))
        assertEquals("NMD", frContext.getString(R.string.wallet_unit))
        assertEquals("Démo (Simulée)", frContext.getString(R.string.history_status_demo))
        assertEquals("DÉMO", frContext.getString(R.string.history_demo_badge))
        assertTrue(frContext.getString(R.string.send_error_rejected_0x_address).contains("0x"))
        assertTrue(frContext.getString(R.string.security_screen_title).contains("Prototype"))
        assertTrue(frContext.getString(R.string.receive_qr_label).contains("prototype", ignoreCase = true))
    }

    @Test
    fun testArabicLocalizationAudit() {
        val arContext = getLocalizedContext(Locale.forLanguageTag("ar"))
        assertEquals("محفظة NMD", arContext.getString(R.string.wallet_title))
        assertEquals("رصيدك الكلي", arContext.getString(R.string.wallet_total_balance))
        assertEquals("NMD", arContext.getString(R.string.wallet_unit))
        assertEquals("محاكاة تجريبية", arContext.getString(R.string.history_status_demo))
        assertEquals("تجريبي", arContext.getString(R.string.history_demo_badge))
        assertTrue(arContext.getString(R.string.send_error_rejected_0x_address).contains("0x"))
        assertTrue(arContext.getString(R.string.security_screen_title).contains("النموذج الأولي"))
        assertTrue(arContext.getString(R.string.receive_qr_label).contains("نموذج بصري"))
    }

    @Test
    fun testAllWalletKeysExistInAllThreeLanguages() {
        val walletStringIds = listOf(
            R.string.wallet_title,
            R.string.wallet_total_balance,
            R.string.wallet_unit,
            R.string.wallet_available_balance,
            R.string.wallet_reserved_balance,
            R.string.wallet_recipient_title,
            R.string.wallet_recipient_hint,
            R.string.wallet_amount_title,
            R.string.wallet_fee_label,
            R.string.send_screen_title,
            R.string.send_review_title,
            R.string.send_error_empty_address,
            R.string.send_error_rejected_0x_address,
            R.string.send_error_invalid_prefix,
            R.string.send_error_invalid_length,
            R.string.send_error_invalid_characters,
            R.string.send_error_insufficient_balance,
            R.string.send_error_zero_amount,
            R.string.receive_screen_title,
            R.string.receive_qr_label,
            R.string.receive_testnet_warning,
            R.string.history_screen_title,
            R.string.history_status_demo,
            R.string.history_status_confirmed,
            R.string.history_status_pending,
            R.string.history_status_failed,
            R.string.history_demo_badge,
            R.string.security_screen_title,
            R.string.stage19_security_screen_title,
            R.string.stage19_backup_title,
            R.string.stage19_wallet_live_badge
        )

        val targetLocales = listOf(
            Locale.ENGLISH to "English",
            Locale.FRENCH to "French",
            Locale.forLanguageTag("ar") to "Arabic"
        )

        for ((loc, langName) in targetLocales) {
            val locContext = getLocalizedContext(loc)
            for (resId in walletStringIds) {
                val value = locContext.getString(resId)
                assertNotNull("Resource $resId must not be null in $langName", value)
                assertTrue("Resource $resId must not be empty in $langName", value.isNotBlank())
            }
        }
    }
}
