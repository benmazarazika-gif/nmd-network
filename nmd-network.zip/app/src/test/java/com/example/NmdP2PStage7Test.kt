package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.p2p.discovery.PeerDiscoveryService
import com.example.p2p.discovery.bootstrap.BootstrapPeer
import com.example.p2p.discovery.bootstrap.BootstrapPeerManager
import com.example.p2p.discovery.bootstrap.BootstrapStatus
import com.example.p2p.discovery.pex.PeerExchangeService
import com.example.p2p.discovery.pex.PeerListPayload
import com.example.p2p.discovery.pex.PexRateLimiter
import com.example.p2p.discovery.pex.ProcessPexResult
import com.example.p2p.discovery.pex.SignedPeerAnnouncement
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerAuthStatus
import com.example.p2p.discovery.registry.PeerFilterOption
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.discovery.topology.ConnectionAdmissionResult
import com.example.p2p.discovery.topology.NetworkTopologyManager
import com.example.p2p.model.DiscoveredPeer
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.repository.NetworkTransportRepository
import com.example.p2p.session.P2pSessionState
import com.example.p2p.session.PeerSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

/**
 * NmdP2PStage7Test verifies all Stage 7 Distributed Peer Discovery & Network Expansion components:
 *
 * 1. Local NSD discovery callbacks & address validation (Unit/Local).
 * 2. DistributedPeerRegistry deduplication, reputation, filtering & persistence zero-trust reset (Unit).
 * 3. Peer expiration & stale peer pruning (Unit).
 * 4. SignedPeerAnnouncement Ed25519 signature, nodeId binding, freshness & replay protection (Unit).
 * 5. Invalid peer rejection (tampered signature, mismatched ID, unsafe/broadcast IP, malformed JSON) (Unit).
 * 6. Peer List Exchange (PEX) request/response & bounded peer list sizes (Unit).
 * 7. Bootstrap peer multi-configuration & persistence (Unit).
 * 8. Bootstrap failure handling & exponential backoff retry gating (Unit).
 * 9. PexRateLimiter flood protection & reputation penalty (Unit).
 * 10. NetworkTopologyManager connection limits & loop prevention (Unit).
 * 11. Real 3-node loopback TCP integration test: Peer A -> Peer B -> Peer C peer announcement & discovery exchange (Integration).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdP2PStage7Test {

    private lateinit var context: Context
    private lateinit var testScope: CoroutineScope
    private val cryptoProvider = BouncyCastleEd25519Provider()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        testScope = CoroutineScope(Dispatchers.IO + Job())
        clearStage7Prefs()
    }

    @After
    fun tearDown() {
        testScope.cancel()
        clearStage7Prefs()
    }

    private fun clearStage7Prefs() {
        context.getSharedPreferences("nmd_p2p_handshake_replay_cache", Context.MODE_PRIVATE).edit().clear().commit()
        context.getSharedPreferences("nmd_p2p_registry", Context.MODE_PRIVATE).edit().clear().commit()
        context.getSharedPreferences("nmd_bootstrap_prefs", Context.MODE_PRIVATE).edit().clear().commit()
    }

    private fun createTestIdentity(alias: String): NodeIdentityManager {
        val storage = KeyStoreStorageService(
            context = context,
            preferencesName = "test_nmd_prefs_stage7_$alias",
            allowTestEnvironmentFallback = true
        )
        val repo = IdentityRepositoryImpl(
            cryptoProvider = cryptoProvider,
            storageService = storage
        )
        val mgr = NodeIdentityManager(repo)
        mgr.generateNewIdentity()
        return mgr
    }

    private fun createSessionForPeer(peerId: String, pubKeyHex: String = ""): PeerSession {
        return PeerSession(
            sessionId = "sess-$peerId",
            peerId = peerId,
            remotePublicKeyHex = pubKeyHex,
            endpoint = PeerEndpoint("192.168.1.50", 9876, peerId),
            state = P2pSessionState.ACTIVE,
            isOutbound = true
        )
    }

    // ==========================================
    // 1. Local Discovery & Duplicate Detection
    // ==========================================

    @Test
    fun testLocalDiscoveryCallbacksAndDuplicateDetection() = runBlocking {
        val registry = DistributedPeerRegistry(context = null, scope = testScope)
        val discoveryService = PeerDiscoveryService(context = context, scope = testScope)

        val discoveredEvents = mutableListOf<DiscoveredPeer>()
        discoveryService.onPeerDiscovered = { peer ->
            discoveredEvents.add(peer)
            val id = peer.advertisedNodeId ?: "nsd_${peer.host}_${peer.port}"
            registry.registerOrUpdatePeer(
                peerId = id,
                endpoint = PeerEndpoint(peer.host, peer.port, peer.advertisedNodeId),
                source = DiscoverySource.LOCAL_NSD,
                reachability = ReachabilityStatus.REACHABLE
            )
        }

        // Provisional manual / NSD discovery before NodeID resolved
        discoveryService.addManualPeer("192.168.1.40", 9876, null)
        assertEquals(1, registry.peers.value.size)

        // Later NSD or handshake resolves same host:port with full advertisedNodeId -> should consolidate, not duplicate!
        val remoteId = "nmd_node_resolved_12345"
        registry.registerOrUpdatePeer(
            peerId = remoteId,
            endpoint = PeerEndpoint("192.168.1.40", 9876, remoteId),
            source = DiscoverySource.LOCAL_NSD,
            reachability = ReachabilityStatus.REACHABLE
        )

        assertEquals(1, registry.peers.value.size)
        assertEquals(remoteId, registry.peers.value.first().peerId)

        // Duplicate advertisement for same nodeId should update, not insert duplicate
        registry.registerOrUpdatePeer(
            peerId = remoteId,
            endpoint = PeerEndpoint("192.168.1.40", 9876, remoteId),
            source = DiscoverySource.PEER_EXCHANGE
        )
        assertEquals(1, registry.peers.value.size)

        discoveryService.close()
        registry.close()
    }

    // ==========================================
    // 2. Peer Registry Updates, Zero-Trust Persistence & Filtering
    // ==========================================

    @Test
    fun testPeerRegistryUpdatesFiltersAndZeroTrustJsonRestore() {
        val registry = DistributedPeerRegistry(context = null, scope = testScope)

        val p1 = registry.registerOrUpdatePeer("peer-1", PeerEndpoint("10.0.0.2", 9001), DiscoverySource.LOCAL_NSD)
        val p2 = registry.registerOrUpdatePeer("peer-2", PeerEndpoint("10.0.0.3", 9002), DiscoverySource.PEER_EXCHANGE)
        val p3 = registry.registerOrUpdatePeer("peer-3", PeerEndpoint("10.0.0.4", 9003), DiscoverySource.BOOTSTRAP, isBootstrap = true)

        assertEquals(PeerAuthStatus.UNAUTHENTICATED, p1.authenticationStatus)

        registry.recordSuccessfulAuth(p1.peerId, "aabbcc")
        registry.recordConnectionFailed(p2.peerId)

        assertEquals(1, registry.getFilteredPeers(PeerFilterOption.CONNECTED).size)
        assertEquals(1, registry.getFilteredPeers(PeerFilterOption.AUTHENTICATED).size)
        assertEquals(1, registry.getFilteredPeers(PeerFilterOption.UNREACHABLE).size)
        assertEquals(1, registry.getFilteredPeers(PeerFilterOption.BOOTSTRAP).size)
        assertEquals(3, registry.getFilteredPeers(PeerFilterOption.ALL).size)

        // Zero-Trust rule: serialized JSON never restores as AUTHENTICATED
        val authedRecord = registry.getPeer(p1.peerId)!!
        assertTrue(authedRecord.isAuthenticated)
        val json = authedRecord.toJson()
        val restored = PeerRegistryRecord.fromJson(json)!!
        assertFalse(restored.isAuthenticated)
        assertEquals(PeerAuthStatus.UNAUTHENTICATED, restored.authenticationStatus)
        assertEquals(ReachabilityStatus.UNKNOWN, restored.reachabilityStatus)
        assertEquals(authedRecord.reputationScore, restored.reputationScore)

        registry.close()
    }

    // ==========================================
    // 3. Peer Stale Pruning & Expiration
    // ==========================================

    @Test
    fun testPeerStalePruningAndExpirationRemoval() {
        val registry = DistributedPeerRegistry(context = null, scope = testScope)
        val now = System.currentTimeMillis()

        registry.registerOrUpdatePeer("fresh-peer", PeerEndpoint("10.0.0.10", 9876), DiscoverySource.LOCAL_NSD)
        registry.registerOrUpdatePeer("stale-peer", PeerEndpoint("10.0.0.11", 9876), DiscoverySource.LOCAL_NSD)
        registry.registerOrUpdatePeer("expired-peer", PeerEndpoint("10.0.0.12", 9876), DiscoverySource.PEER_EXCHANGE)
        registry.registerOrUpdatePeer("bootstrap-old", PeerEndpoint("10.0.0.13", 9876), DiscoverySource.BOOTSTRAP, isBootstrap = true)

        // Make stale-peer 15 min old, expired-peer & bootstrap-old 30 hours old
        registry.updateLastSeenForTesting("stale-peer", now - 15 * 60_000L)
        registry.updateLastSeenForTesting("expired-peer", now - 30 * 3600_000L)
        registry.updateLastSeenForTesting("bootstrap-old", now - 30 * 3600_000L)

        val prunedCount = registry.pruneStalePeers(staleThresholdMs = 10 * 60_000L, nowMs = now)
        assertTrue(prunedCount >= 2)
        assertEquals(ReachabilityStatus.STALE, registry.getPeer("stale-peer")?.reachabilityStatus)

        // Remove expired (> 24h) - bootstrap nodes must be preserved
        val removedCount = registry.removeExpiredPeers(expiryThresholdMs = 24 * 3600_000L, nowMs = now)
        assertEquals(1, removedCount)
        assertNull(registry.getPeer("expired-peer"))
        assertNotNull(registry.getPeer("bootstrap-old"))
        assertNotNull(registry.getPeer("fresh-peer"))
        assertNotNull(registry.getPeer("stale-peer"))

        registry.close()
    }

    // ==========================================
    // 4. Signed Peer Announcement Security & Rejection
    // ==========================================

    @Test
    fun testSignedAnnouncementValidationAndInvalidRejection() {
        val aliceMgr = createTestIdentity("alice_sec")
        val bobMgr = createTestIdentity("bob_sec")
        val aliceId = aliceMgr.getActiveIdentity()!!
        val bobId = bobMgr.getActiveIdentity()!!

        val registry = DistributedPeerRegistry(context = null, scope = testScope)
        val pex = PeerExchangeService(aliceMgr, registry)

        // 1. Valid announcement from Bob
        val bobAnnounce = SignedPeerAnnouncement(
            peerId = bobId.nodeId,
            publicKeyHex = bobId.publicKeyHex,
            host = "192.168.1.25",
            port = 9876,
            timestamp = System.currentTimeMillis()
        ).sign(bobMgr)

        assertTrue(bobAnnounce.verify(cryptoProvider))
        assertTrue(bobAnnounce.validateFreshness())
        assertTrue(bobAnnounce.validateAddress())

        val validMsg = P2pMessage(
            senderPeerId = bobId.nodeId,
            recipientPeerId = aliceId.nodeId,
            messageType = P2pMessageType.PEER_ANNOUNCEMENT,
            payload = bobAnnounce.toJson().toString()
        )
        val bobSession = createSessionForPeer(bobId.nodeId, bobId.publicKeyHex)
        val ingestResult = pex.processIncomingPexMessage(validMsg, bobSession, "127.0.0.1", 9870)
        assertTrue(ingestResult is ProcessPexResult.Ingested)
        assertNotNull(registry.getPeer(bobId.nodeId))

        // 2. Replay protection: exact same announcement rejected on second attempt
        val replayResult = pex.processIncomingPexMessage(validMsg, bobSession, "127.0.0.1", 9870)
        assertTrue(replayResult is ProcessPexResult.Rejected)

        // 3. Tampered payload (port altered) rejected
        val tampered = bobAnnounce.copy(port = 9999)
        assertFalse(tampered.verify(cryptoProvider))

        // 4. Identity mismatch (Bob signs with Bob's key, but claims Alice's peerId) rejected
        val spoofedId = SignedPeerAnnouncement(
            peerId = aliceId.nodeId,
            publicKeyHex = bobId.publicKeyHex,
            host = "192.168.1.30",
            port = 9876
        ).sign(bobMgr)
        assertFalse(spoofedId.verify(cryptoProvider))

        // 5. Invalid addresses rejected
        assertFalse(bobAnnounce.copy(host = "0.0.0.0").validateAddress())
        assertFalse(bobAnnounce.copy(host = "255.255.255.255").validateAddress())
        assertFalse(bobAnnounce.copy(host = "224.0.0.1").validateAddress())
        assertFalse(bobAnnounce.copy(port = 0).validateAddress())
        assertFalse(bobAnnounce.copy(port = 70000).validateAddress())

        // 6. Expired timestamp rejected
        val expiredAnnounce = SignedPeerAnnouncement(
            peerId = bobId.nodeId,
            publicKeyHex = bobId.publicKeyHex,
            host = "192.168.1.25",
            port = 9876,
            timestamp = System.currentTimeMillis() - 600_000L
        ).sign(bobMgr)
        assertFalse(expiredAnnounce.validateFreshness())
        val expiredMsg = validMsg.copy(messageId = UUID.randomUUID().toString(), payload = expiredAnnounce.toJson().toString())
        val expiredRes = pex.processIncomingPexMessage(expiredMsg, bobSession, "127.0.0.1", 9870)
        assertTrue(expiredRes is ProcessPexResult.Rejected)

        // 7. Malformed JSON handled safely without crashing
        val malformedMsg = validMsg.copy(messageId = UUID.randomUUID().toString(), payload = "{not_json!!")
        val malformedRes = pex.processIncomingPexMessage(malformedMsg, bobSession, "127.0.0.1", 9870)
        assertTrue(malformedRes is ProcessPexResult.Rejected)

        registry.close()
    }

    // ==========================================
    // 5. Peer List Exchange & Bounded Size Enforcement
    // ==========================================

    @Test
    fun testPeerListExchangeAndBoundedListSize() {
        val aliceMgr = createTestIdentity("alice_pex")
        val bobMgr = createTestIdentity("bob_pex")
        val charlieMgr = createTestIdentity("charlie_pex")
        val aliceId = aliceMgr.getActiveIdentity()!!
        val bobId = bobMgr.getActiveIdentity()!!
        val charlieId = charlieMgr.getActiveIdentity()!!

        val bobRegistry = DistributedPeerRegistry(context = null, scope = testScope)
        val bobPex = PeerExchangeService(bobMgr, bobRegistry)

        // Charlie sends valid announcement to Bob
        val charlieAnnounce = SignedPeerAnnouncement(
            peerId = charlieId.nodeId,
            publicKeyHex = charlieId.publicKeyHex,
            host = "192.168.1.99",
            port = 9888
        ).sign(charlieMgr)
        bobRegistry.registerOrUpdatePeer(
            peerId = charlieId.nodeId,
            endpoint = PeerEndpoint("192.168.1.99", 9888, charlieId.nodeId),
            source = DiscoverySource.PEER_EXCHANGE,
            publicKeyHex = charlieId.publicKeyHex,
            reachability = ReachabilityStatus.REACHABLE,
            signedAnnouncementJson = charlieAnnounce.toJson().toString()
        )

        // Alice asks Bob for peer list
        val aliceRegistry = DistributedPeerRegistry(context = null, scope = testScope)
        val alicePex = PeerExchangeService(aliceMgr, aliceRegistry)
        val requestMsg = alicePex.createPeerListRequest(bobId.nodeId)!!
        val aliceSessionAtBob = createSessionForPeer(aliceId.nodeId, aliceId.publicKeyHex)

        val bobResult = bobPex.processIncomingPexMessage(requestMsg, aliceSessionAtBob, "192.168.1.20", 9876)
        assertTrue(bobResult is ProcessPexResult.ResponseReady)
        val responseMsg = (bobResult as ProcessPexResult.ResponseReady).responseMessage
        assertEquals(P2pMessageType.PEER_LIST_RESPONSE, responseMsg.messageType)

        // Alice ingests Bob's PEER_LIST_RESPONSE -> gets both Bob and Charlie
        val bobSessionAtAlice = createSessionForPeer(bobId.nodeId, bobId.publicKeyHex)
        val aliceIngest = alicePex.processIncomingPexMessage(responseMsg, bobSessionAtAlice, "192.168.1.10", 9876)
        assertTrue(aliceIngest is ProcessPexResult.Ingested)
        val ingested = aliceIngest as ProcessPexResult.Ingested
        assertEquals(2, ingested.newPeersCount)
        assertNotNull(aliceRegistry.getPeer(bobId.nodeId))
        assertNotNull(aliceRegistry.getPeer(charlieId.nodeId))

        // Verify PeerListPayload size bounding (MAX_PEERS_PER_PAYLOAD = 16)
        val oversized = (1..25).map { idx ->
            SignedPeerAnnouncement(
                peerId = charlieId.nodeId,
                publicKeyHex = charlieId.publicKeyHex,
                host = "192.168.1.$idx",
                port = 9800 + idx
            )
        }
        val serializedOversized = PeerListPayload(oversized).toJson()
        val parsedOversized = PeerListPayload.fromJson(serializedOversized)!!
        assertEquals(PeerListPayload.MAX_PEERS_PER_PAYLOAD, parsedOversized.announcements.size)

        bobRegistry.close()
        aliceRegistry.close()
    }

    // ==========================================
    // 6. Rate Limiting & Flood Protection
    // ==========================================

    @Test
    fun testPexRateLimitingAndFloodProtection() {
        val aliceMgr = createTestIdentity("alice_rl")
        val bobMgr = createTestIdentity("bob_rl")
        val bobId = bobMgr.getActiveIdentity()!!

        val registry = DistributedPeerRegistry(context = null, scope = testScope)
        val limiter = PexRateLimiter(maxRequestsPerWindow = 3, windowDurationMs = 10_000L)
        val pex = PeerExchangeService(aliceMgr, registry, rateLimiter = limiter)

        val bobSession = createSessionForPeer(bobId.nodeId, bobId.publicKeyHex)
        registry.registerOrUpdatePeer(bobId.nodeId, bobSession.endpoint, DiscoverySource.MANUAL)
        val initialScore = registry.getPeer(bobId.nodeId)!!.reputationScore

        // First 3 requests allowed
        repeat(3) {
            val req = P2pMessage(
                senderPeerId = bobId.nodeId,
                recipientPeerId = aliceMgr.getActiveIdentity()!!.nodeId,
                messageType = P2pMessageType.PEER_LIST_REQUEST
            )
            val res = pex.processIncomingPexMessage(req, bobSession, "127.0.0.1", 9876)
            assertTrue(res is ProcessPexResult.ResponseReady)
        }

        // 4th request rate-limited and reputation penalized
        val floodReq = P2pMessage(
            senderPeerId = bobId.nodeId,
            recipientPeerId = aliceMgr.getActiveIdentity()!!.nodeId,
            messageType = P2pMessageType.PEER_LIST_REQUEST
        )
        val floodRes = pex.processIncomingPexMessage(floodReq, bobSession, "127.0.0.1", 9876)
        assertTrue(floodRes is ProcessPexResult.RateLimited)
        assertTrue(registry.getPeer(bobId.nodeId)!!.reputationScore < initialScore)

        registry.close()
    }

    // ==========================================
    // 7. Bootstrap Peer Architecture & Backoff Recovery
    // ==========================================

    @Test
    fun testBootstrapConfigurationAndFailureBackoff() = runBlocking {
        val registry = DistributedPeerRegistry(context = context, scope = testScope)
        val bootstrapMgr = BootstrapPeerManager(
            context = context,
            registry = registry,
            connectionManager = null,
            scope = testScope
        )

        // Preconfigured dev nodes are present
        assertTrue(bootstrapMgr.bootstrapPeers.value.any { it.isPreconfiguredDev })

        // Add custom bootstrap peer
        val custom = bootstrapMgr.addCustomBootstrapPeer("Test LAN Seed", "192.168.1.250", 9876)
        assertTrue(bootstrapMgr.bootstrapPeers.value.any { it.id == custom.id })

        // Toggle enabled
        bootstrapMgr.toggleBootstrapPeer(custom.id, false)
        assertFalse(bootstrapMgr.bootstrapPeers.value.find { it.id == custom.id }!!.isEnabled)

        // Remove custom peer
        assertTrue(bootstrapMgr.removeBootstrapPeer(custom.id))
        assertNull(bootstrapMgr.bootstrapPeers.value.find { it.id == custom.id })

        // Exponential backoff progression verification
        assertEquals(2_000L, BootstrapPeer.computeBackoffMs(1))
        assertEquals(4_000L, BootstrapPeer.computeBackoffMs(2))
        assertEquals(8_000L, BootstrapPeer.computeBackoffMs(3))
        assertEquals(60_000L, BootstrapPeer.computeBackoffMs(10))

        // Real failure attempt on unreachable localhost port triggers BACKOFF state via real connectionManager
        val aliceMgr = createTestIdentity("alice_boot")
        val repo = NetworkTransportRepository(context = context, identityManager = aliceMgr, scope = testScope)
        val unreachableSeed = repo.addCustomBootstrapPeer("Closed Port Seed", "127.0.0.1", 59999)
        val failRes = repo.connectBootstrapPeer(unreachableSeed.id)
        assertTrue(failRes.isFailure)

        val updatedSeed = repo.bootstrapPeers.value.find { it.id == unreachableSeed.id }!!
        assertEquals(BootstrapStatus.BACKOFF, updatedSeed.status)
        assertEquals(1, updatedSeed.consecutiveFailures)
        assertTrue(updatedSeed.isInBackoff)

        // Immediate retry should be blocked by exponential backoff policy
        val blockedRetry = repo.connectBootstrapPeer(unreachableSeed.id)
        assertTrue(blockedRetry.isFailure)
        assertTrue(blockedRetry.exceptionOrNull()?.message?.contains("backoff", ignoreCase = true) == true)

        repo.close()
        bootstrapMgr.close()
        registry.close()
    }

    // ==========================================
    // 8. Network Topology Manager Limits & Loop Prevention
    // ==========================================

    @Test
    fun testNetworkTopologyLimitsAndLoopPrevention() {
        val topology = NetworkTopologyManager(maxConnectedPeers = 2, maxOutboundConnections = 2)
        val localNodeId = "nmd_local_self"

        // Self-connection loop by Node ID rejected
        val selfIdLoop = topology.validateOutboundConnection(
            targetEndpoint = PeerEndpoint("192.168.1.10", 9876, localNodeId),
            localNodeId = localNodeId,
            localPort = 9876,
            localIp = "192.168.1.5",
            currentOutboundCount = 0,
            activeEndpoints = emptySet()
        )
        assertTrue(selfIdLoop is ConnectionAdmissionResult.Rejected)

        // Self-connection loop by local IP + port rejected
        val selfPortLoop = topology.validateOutboundConnection(
            targetEndpoint = PeerEndpoint("127.0.0.1", 9876, null),
            localNodeId = localNodeId,
            localPort = 9876,
            localIp = "192.168.1.5",
            currentOutboundCount = 0,
            activeEndpoints = emptySet()
        )
        assertTrue(selfPortLoop is ConnectionAdmissionResult.Rejected)

        // Duplicate endpoint rejected
        val dupEndpoint = topology.validateOutboundConnection(
            targetEndpoint = PeerEndpoint("192.168.1.20", 9876),
            localNodeId = localNodeId,
            localPort = 9876,
            localIp = "192.168.1.5",
            currentOutboundCount = 1,
            activeEndpoints = setOf("192.168.1.20:9876")
        )
        assertTrue(dupEndpoint is ConnectionAdmissionResult.Rejected)

        // Outbound capacity exceeded rejected
        val overOutbound = topology.validateOutboundConnection(
            targetEndpoint = PeerEndpoint("192.168.1.21", 9876),
            localNodeId = localNodeId,
            localPort = 9876,
            localIp = "192.168.1.5",
            currentOutboundCount = 2,
            activeEndpoints = emptySet()
        )
        assertTrue(overOutbound is ConnectionAdmissionResult.Rejected)

        // Valid distinct connection allowed
        val validOutbound = topology.validateOutboundConnection(
            targetEndpoint = PeerEndpoint("192.168.1.21", 9877),
            localNodeId = localNodeId,
            localPort = 9876,
            localIp = "192.168.1.5",
            currentOutboundCount = 1,
            activeEndpoints = setOf("192.168.1.20:9876")
        )
        assertTrue(validOutbound is ConnectionAdmissionResult.Allowed)

        // Inbound limit enforced
        assertTrue(topology.canAcceptInbound(1) is ConnectionAdmissionResult.Allowed)
        assertTrue(topology.canAcceptInbound(2) is ConnectionAdmissionResult.Rejected)
    }

    // ==========================================
    // 9. Multi-Peer Loopback TCP Integration Test (Node A -> Node B <- Node C)
    // ==========================================

    @Test
    fun testMultiPeerLoopbackDiscoveryAndPexExchangeIntegration() = runBlocking {
        val nodeAMgr = createTestIdentity("loop_node_a")
        val nodeBMgr = createTestIdentity("loop_node_b")
        val nodeCMgr = createTestIdentity("loop_node_c")

        val nodeAId = nodeAMgr.getActiveIdentity()!!.nodeId
        val nodeBId = nodeBMgr.getActiveIdentity()!!.nodeId
        val nodeCId = nodeCMgr.getActiveIdentity()!!.nodeId

        val repoA = NetworkTransportRepository(context = context, identityManager = nodeAMgr, scope = testScope)
        val repoB = NetworkTransportRepository(context = context, identityManager = nodeBMgr, scope = testScope)
        val repoC = NetworkTransportRepository(context = context, identityManager = nodeCMgr, scope = testScope)

        try {
            val portA = repoA.startListening(0)
            val portB = repoB.startListening(0)
            val portC = repoC.startListening(0)
            assertTrue(portA > 0 && portB > 0 && portC > 0)

            // 1. Node A connects to Node B over real TCP loopback socket
            val resAB = repoA.connectToPeer(PeerEndpoint("127.0.0.1", portB, nodeBId))
            assertTrue("A -> B connection must succeed: ${resAB.exceptionOrNull()?.message}", resAB.isSuccess)

            // Wait for initial PEX announcement & registry ingestion on B
            var aRegisteredOnB = false
            for (i in 0..30) {
                if (repoB.registeredPeers.value.any { it.peerId == nodeAId && it.signedAnnouncementJson != null }) {
                    aRegisteredOnB = true
                    break
                }
                delay(100L)
            }
            assertTrue("Node B should register Node A's signed announcement", aRegisteredOnB)

            // 2. Node C connects to Node B over real TCP loopback socket
            val resCB = repoC.connectToPeer(PeerEndpoint("127.0.0.1", portB, nodeBId))
            assertTrue("C -> B connection must succeed: ${resCB.exceptionOrNull()?.message}", resCB.isSuccess)

            // Explicitly trigger PEX request from Node C as well
            delay(200L)
            repoC.requestPeerExchangeFromAll()

            // Wait for Node C to discover Node A indirectly via Node B's signed PEER_LIST_RESPONSE!
            var cDiscoveredA = false
            for (i in 0..30) {
                val peerAOnC = repoC.registeredPeers.value.find { it.peerId == nodeAId }
                if (peerAOnC != null && peerAOnC.discoverySource == DiscoverySource.PEER_EXCHANGE) {
                    cDiscoveredA = true
                    // Zero-Trust rule: A was discovered via PEX, must be UNAUTHENTICATED on C before connecting
                    assertEquals(PeerAuthStatus.UNAUTHENTICATED, peerAOnC.authenticationStatus)
                    break
                }
                delay(100L)
            }
            assertTrue("Node C should discover Node A via Node B PEX exchange", cDiscoveredA)
            assertTrue(repoC.topologyMetrics.value.indirectPeersCount >= 1)
        } finally {
            repoA.close()
            repoB.close()
            repoC.close()
        }
    }
}
