package com.example

import androidx.compose.ui.unit.LayoutDirection
import com.example.data.AppLanguage
import com.example.ui.navigation.NavScreen
import com.example.ui.screens.HomeViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NmdArchitectureTest {

    @Test
    fun testLanguageDirections() {
        assertEquals(LayoutDirection.Rtl, AppLanguage.ARABIC.layoutDirection)
        assertEquals(LayoutDirection.Ltr, AppLanguage.ENGLISH.layoutDirection)
        assertEquals(LayoutDirection.Ltr, AppLanguage.FRENCH.layoutDirection)
    }

    @Test
    fun testFiveNavDestinationsExist() {
        assertEquals(5, NavScreen.entries.size)
        assertTrue(NavScreen.entries.contains(NavScreen.Home))
        assertTrue(NavScreen.entries.contains(NavScreen.Wallet))
        assertTrue(NavScreen.entries.contains(NavScreen.Network))
        assertTrue(NavScreen.entries.contains(NavScreen.Discover))
        assertTrue(NavScreen.entries.contains(NavScreen.Profile))
    }

    @Test
    fun testHomeViewModelState() {
        val vm = HomeViewModel()
        val wallet = vm.walletState.value
        assertFalse("Wallet must not default to demo mode", wallet.isDemo)
        assertEquals("0.00", wallet.totalBalanceFormatted)
        assertEquals("NMD", wallet.tokenSymbol)
        assertTrue("Home recent activities must start empty until real ledger/mempool activity exists", vm.recentActivities.value.isEmpty())
    }
}
