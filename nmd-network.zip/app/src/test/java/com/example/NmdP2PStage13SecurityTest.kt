package com.example

import android.content.Context
import android.content.res.Configuration
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.NodeIdentityManager
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import com.example.p2p.discovery.PeerDiscoveryService
import com.example.p2p.handshake.HandshakeChallengeReplayCache
import com.example.p2p.handshake.PeerHandshakeService
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.FrameType
import com.example.p2p.model.HandshakeHello
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.repository.NetworkTransportRepository
import com.example.p2p.security.IncomingSecurityResult
import com.example.p2p.security.TransportSecurityManager
import com.example.p2p.security.crypto.EncryptedTransportSession
import com.example.p2p.security.crypto.FrameDecryptOutcome
import com.example.p2p.security.crypto.NoiseStyleKeySchedule
import com.example.p2p.security.crypto.X25519KeyExchange
import com.example.p2p.security.guard.ConnectionAbuseProtector
import com.example.p2p.security.guard.GuardAdmissionResult
import com.example.p2p.security.handshake.SecureHandshakeInit
import com.example.p2p.security.handshake.SecureHandshakeResp
import com.example.p2p.security.handshake.SecureSessionHandshakeService
import com.example.p2p.security.handshake.SecurityHandshakeException
import com.example.p2p.security.model.PeerTrustState
import com.example.p2p.security.model.SecurityEventType
import com.example.p2p.security.model.SecurityThreatModel
import com.example.p2p.security.model.TransportSecurityConfig
import com.example.p2p.security.model.TransportSecurityStatus
import com.example.p2p.security.trust.IdentityTrustCheckResult
import com.example.p2p.security.trust.PeerTrustManager
import com.example.p2p.transport.MessageFramer
import com.example.p2p.transport.TcpPeerTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Locale
import java.util.UUID

/**
 * Stage 13 P2P Network Security & Encrypted Transport Verification Suite.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NmdP2PStage13SecurityTest {

    private lateinit var context: Context
    private lateinit var testScope: CoroutineScope
    private lateinit var cryptoProvider: CryptographicProvider

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        testScope = CoroutineScope(Dispatchers.IO + Job())
        cryptoProvider = BouncyCastleEd25519Provider()
        HandshakeChallengeReplayCache.clearGlobalCacheForTest()
    }

    @After
    fun tearDown() {
        testScope.cancel()
        HandshakeChallengeReplayCache.clearGlobalCacheForTest()
    }

    private fun createTestIdentityManager(suffix: String): NodeIdentityManager {
        val storage = KeyStoreStorageService(
            context = context,
            preferencesName = "stage13_id_$suffix",
            allowTestEnvironmentFallback = true
        )
        val repo = IdentityRepositoryImpl(cryptoProvider = cryptoProvider, storageService = storage)
        return NodeIdentityManager(repo).apply { generateNewIdentity() }
    }

    private fun openExistingIdentityManager(suffix: String): NodeIdentityManager {
        val storage = KeyStoreStorageService(
            context = context,
            preferencesName = "stage13_id_$suffix",
            allowTestEnvironmentFallback = true
        )
        val repo = IdentityRepositoryImpl(cryptoProvider = cryptoProvider, storageService = storage)
        return NodeIdentityManager(repo)
    }

    private fun createSocketHandshakePair(
        serviceA: SecureSessionHandshakeService,
        serviceB: SecureSessionHandshakeService,
        expectedBId: String? = null
    ): Pair<EncryptedTransportSession, EncryptedTransportSession> {
        val server = ServerSocket(0, 10, InetAddress.getByName("127.0.0.1"))
        var resB: Result<EncryptedTransportSession>? = null
        val t = Thread {
            try {
                server.accept().use { s ->
                    val out = serviceB.performResponderHandshake(s.getInputStream(), s.getOutputStream())
                    resB = Result.success(out.encryptedSession)
                }
            } catch (e: Exception) {
                resB = Result.failure(e)
            }
        }
        t.start()

        val client = Socket("127.0.0.1", server.localPort)
        return try {
            val resA = try {
                Result.success(
                    serviceA.performInitiatorHandshake(
                        inputStream = client.getInputStream(),
                        outputStream = client.getOutputStream(),
                        expectedRemoteNodeId = expectedBId
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
            t.join(5000)
            val errB = resB?.exceptionOrNull()
            val errA = resA.exceptionOrNull()
            if (errB != null && (errB is SecurityHandshakeException && (errA !is SecurityHandshakeException || errA.eventType == SecurityEventType.HANDSHAKE_FAILED))) {
                throw errB
            }
            if (errA != null) throw errA
            if (errB != null) throw errB
            Pair(resA.getOrThrow().encryptedSession, resB!!.getOrThrow())
        } finally {
            try { client.close() } catch (_: Exception) {}
            try { server.close() } catch (_: Exception) {}
        }
    }

    // 1. Authenticated ECDHE handshake, AEAD roundtrip, ephemeral + session key zeroization
    @Test
    fun testAuthenticatedEncryptedHandshakeAndZeroization() = runBlocking {
        val alice = createTestIdentityManager("alice_1")
        val bob = createTestIdentityManager("bob_1")
        val bobId = bob.getActiveIdentity()!!.nodeId

        // Verify ephemeral key zeroization explicitly
        val ephemeral = X25519KeyExchange.generateEphemeralKeyPair()
        val peerEph = X25519KeyExchange.generateEphemeralKeyPair()
        val secret = ephemeral.computeAgreement(peerEph.publicKeyBytes)
        assertEquals(32, secret.size)
        assertFalse(secret.all { it == 0.toByte() })
        ephemeral.close()
        X25519KeyExchange.zeroize(secret)
        assertTrue("Agreed secret must be zeroized", secret.all { it == 0.toByte() })
        try {
            ephemeral.computeAgreement(peerEph.publicKeyBytes)
            fail("Closed ephemeral X25519 keypair must reject reuse")
        } catch (_: IllegalStateException) {
            // Expected
        } finally {
            peerEph.close()
        }

        // Full TCP loopback NetworkTransportRepository end-to-end encrypted communication
        val repoAlice = NetworkTransportRepository(context = context, identityManager = alice, scope = testScope)
        val repoBob = NetworkTransportRepository(context = context, identityManager = bob, scope = testScope)
        try {
            val portBob = repoBob.startListening(0)
            val connRes = repoAlice.connectToPeer(PeerEndpoint("127.0.0.1", portBob, bobId))
            assertTrue("Encrypted connection must succeed: ${connRes.exceptionOrNull()?.message}", connRes.isSuccess)
            val peerInfo = connRes.getOrThrow()
            assertEquals(RealPeerConnectionState.AUTHENTICATED, peerInfo.state)

            delay(250)
            assertEquals(TransportSecurityStatus.SECURE, repoAlice.securityUiState.value.status)
            assertEquals(TransportSecurityStatus.SECURE, repoBob.securityUiState.value.status)
            assertEquals(1, repoAlice.securityUiState.value.encryptedSessionsCount)
            assertEquals(1, repoBob.securityUiState.value.encryptedSessionsCount)

            val payload = "{\"block_height\":1042,\"tx_count\":7}"
            val sendRes = repoAlice.sendSignedMessage(peerInfo.connectionId, ProtocolMessageType.STATE_SYNC_REQUEST, payload)
            assertTrue(sendRes.isSuccess)

            var received = false
            for (i in 1..30) {
                if (repoBob.messageHistory.value.isNotEmpty()) {
                    received = true
                    break
                }
                delay(100)
            }
            assertTrue("Bob must receive decrypted authenticated message", received)
            assertEquals(payload, repoBob.messageHistory.value.first().payload)

            // Verify Session 1 + Session 2 keys match oppositely and zeroize on close
            val sAlice = repoAlice.transportSecurityManager.getActiveSession(peerInfo.connectionId)!!
            assertTrue(sAlice.isActive())
            repoAlice.disconnectPeer(peerInfo.connectionId)
            delay(150)
            assertFalse("Session must close & zeroize on disconnect", sAlice.isActive())
        } finally {
            repoAlice.close()
            repoBob.close()
        }
    }

    // 2. Invalid Ed25519 peer identity / expected NodeID mismatch rejected
    @Test
    fun testInvalidIdentityAndNodeIdMismatchRejected() {
        val alice = createTestIdentityManager("alice_id_mismatch")
        val bob = createTestIdentityManager("bob_id_mismatch")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(context, "t_a_${UUID.randomUUID()}", cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_a", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(context, "t_b_${UUID.randomUUID()}", cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_b", cryptoProvider))

        try {
            createSocketHandshakePair(svcA, svcB, expectedBId = "nmd_wrong_node_id_0000")
            fail("Expected handshake rejection on mismatched expectedRemoteNodeId")
        } catch (e: IOException) {
            assertTrue(e is SecurityHandshakeException || (e.message?.contains("mismatch", ignoreCase = true) == true))
        }
    }

    // 3. Wrong Chain ID rejection
    @Test
    fun testWrongChainIdRejected() {
        val alice = createTestIdentityManager("alice_chain")
        val bob = createTestIdentityManager("bob_chain")
        val cfgMain = TransportSecurityConfig(chainId = "nmd-dev-net-1")
        val cfgWrong = TransportSecurityConfig(chainId = "rogue-fork-99")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), cfgMain, replayCache = HandshakeChallengeReplayCache(null, "rc_c1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), cfgWrong, replayCache = HandshakeChallengeReplayCache(null, "rc_c2", cryptoProvider))

        try {
            createSocketHandshakePair(svcA, svcB)
            fail("Expected handshake rejection on Chain ID mismatch")
        } catch (e: SecurityHandshakeException) {
            assertEquals(SecurityEventType.CHAIN_MISMATCH_REJECTED, e.eventType)
        }
    }

    // 4. Unsupported protocol version & cipher-suite downgrade rejected
    @Test
    fun testUnsupportedProtocolVersionAndCipherSuiteRejected() {
        val alice = createTestIdentityManager("alice_ver")
        val bob = createTestIdentityManager("bob_ver")
        val cfgV3 = TransportSecurityConfig(protocolVersion = 3, minSupportedProtocolVersion = 3)
        val cfgDowngrade = TransportSecurityConfig(protocolVersion = 2, minSupportedProtocolVersion = 2)
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), cfgV3, replayCache = HandshakeChallengeReplayCache(null, "rc_v1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), cfgDowngrade, replayCache = HandshakeChallengeReplayCache(null, "rc_v2", cryptoProvider))

        try {
            createSocketHandshakePair(svcA, svcB)
            fail("Expected downgrade rejection")
        } catch (e: SecurityHandshakeException) {
            assertEquals(SecurityEventType.DOWNGRADE_REJECTED, e.eventType)
        }

        // Cipher suite mismatch also rejected as DOWNGRADE_REJECTED
        val cfgWeakCipher = TransportSecurityConfig(cipherSuiteId = "NULL_PLAINTEXT_CIPHER")
        val svcWeak = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), cfgWeakCipher, replayCache = HandshakeChallengeReplayCache(null, "rc_v3", cryptoProvider))
        try {
            createSocketHandshakePair(svcA, svcWeak)
            fail("Expected weak/unsupported cipher suite rejection")
        } catch (e: SecurityHandshakeException) {
            assertEquals(SecurityEventType.DOWNGRADE_REJECTED, e.eventType)
        }
    }

    // 5. Downgrade attempt with legacy unencrypted HANDSHAKE_HELLO or unencrypted RELIABLE_MSG rejected (no plaintext fallback)
    @Test
    fun testLegacyPlaintextHandshakeAndPostHandshakePlaintextDowngradesBlocked() = runBlocking {
        val bob = createTestIdentityManager("bob_nodowngrade")
        val repoBob = NetworkTransportRepository(context = context, identityManager = bob, scope = testScope)
        try {
            val portBob = repoBob.startListening(0)
            // Rogue client connects and sends legacy v2 plaintext HANDSHAKE_HELLO (0x01)
            Socket("127.0.0.1", portBob).use { rogueSocket ->
                val hello = HandshakeHello(
                    protocolVersion = 2,
                    senderNodeId = "rogue",
                    senderPublicKeyHex = "11".repeat(32),
                    challengeHex = "22".repeat(32),
                    timestamp = System.currentTimeMillis()
                )
                MessageFramer.writeFrame(rogueSocket.getOutputStream(), FrameType.HANDSHAKE_HELLO, hello.toJson().toByteArray())
                val reply = MessageFramer.readFrame(rogueSocket.getInputStream())
                // Responder must close immediately without sending HANDSHAKE_RESPONSE
                assertTrue("Bob must reject legacy HANDSHAKE_HELLO and close stream", reply == null)
            }
            delay(200)
            assertTrue(repoBob.securityUiState.value.failedHandshakesCount >= 1)
            assertEquals(SecurityEventType.DOWNGRADE_REJECTED, repoBob.securityUiState.value.lastSecurityEvent?.type)

            // Post-handshake unencrypted frame injection into decryptAndAuthorizeIncoming must also fail & reject
            val alice = createTestIdentityManager("alice_post_downgrade")
            val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_pd1", cryptoProvider))
            val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_pd2", cryptoProvider))
            val (sA, _) = createSocketHandshakePair(svcA, svcB)
            val secMgr = TransportSecurityManager(context = null, identityManager = alice)
            // Verify unencrypted RELIABLE_MSG passed directly to decryptAndAuthorizeIncoming triggers DOWNGRADE_REJECTED
            val initFrameOutcome = secMgr.decryptAndAuthorizeIncoming("missing", FrameType.RELIABLE_MSG, "plain".toByteArray())
            assertTrue(initFrameOutcome is IncomingSecurityResult.SecurityViolation)
            sA.close()
            secMgr.close()
        } finally {
            repoBob.close()
        }
    }

    // 6. Forged / invalid handshake signature rejected
    @Test
    fun testInvalidHandshakeSignatureRejected() {
        val alice = createTestIdentityManager("alice_forged")
        val bob = createTestIdentityManager("bob_forged")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_sig1", cryptoProvider))

        val server = ServerSocket(0, 5, InetAddress.getByName("127.0.0.1"))
        val t = Thread {
            try {
                server.accept().use { s ->
                    MessageFramer.readFrame(s.getInputStream(), 8192)
                    val ephB = X25519KeyExchange.generateEphemeralKeyPair()
                    val badResp = SecureHandshakeResp(
                        protocolVersion = 3,
                        minSupportedVersion = 3,
                        chainId = TransportSecurityConfig().chainId,
                        cipherSuiteId = TransportSecurityConfig.DEFAULT_CIPHER_SUITE_ID,
                        responderNodeId = bob.getActiveIdentity()!!.nodeId,
                        responderPublicKeyHex = bob.getActiveIdentity()!!.publicKeyHex,
                        ephemeralX25519PubHex = cryptoProvider.toHex(ephB.publicKeyBytes),
                        counterChallengeHex = "ab".repeat(32),
                        sessionId = "forged_session_id_1234567890123456",
                        timestamp = System.currentTimeMillis(),
                        responderSignatureHex = "00".repeat(64) // Invalid Ed25519 signature
                    )
                    ephB.close()
                    MessageFramer.writeFrame(s.getOutputStream(), FrameType.SECURE_HANDSHAKE_RESP, badResp.toJson().toByteArray(), 8192)
                }
            } catch (_: Exception) {
            }
        }
        t.start()
        Socket("127.0.0.1", server.localPort).use { client ->
            try {
                svcA.performInitiatorHandshake(client.getInputStream(), client.getOutputStream())
                fail("Invalid responder signature must fail handshake")
            } catch (e: SecurityHandshakeException) {
                assertTrue(
                    e.eventType == SecurityEventType.SIGNATURE_INVALID ||
                        e.eventType == SecurityEventType.MALFORMED_FRAME_REJECTED
                )
            }
        }
        t.join(2000)
        server.close()
    }

    // 7. Ciphertext modification, Poly1305 tag tampering, and AAD tampering rejected
    @Test
    fun testCiphertextAndAuthTagTamperingRejected() {
        val alice = createTestIdentityManager("alice_aead")
        val bob = createTestIdentityManager("bob_aead")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_aead1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_aead2", cryptoProvider))
        val (sAlice, sBob) = createSocketHandshakePair(svcA, svcB)

        val plaintext = "{\"tx\":\"transfer\",\"amount\":500}".toByteArray()
        val encrypted = sAlice.encryptFrame(FrameType.PROTOCOL_MESSAGE, plaintext)

        // Flip bit in ciphertext/Poly1305 tag (last byte)
        val tamperedTag = encrypted.copyOf()
        tamperedTag[tamperedTag.size - 1] = (tamperedTag[tamperedTag.size - 1].toInt() xor 0xFF).toByte()
        val tagOutcome = sBob.decryptFrame(tamperedTag)
        assertTrue(tagOutcome is FrameDecryptOutcome.Rejected)
        assertTrue((tagOutcome as FrameDecryptOutcome.Rejected).isMalformedOrTampered)

        // Flip bit in ciphertext body
        val tamperedBody = encrypted.copyOf()
        tamperedBody[tamperedBody.size - 20] = (tamperedBody[tamperedBody.size - 20].toInt() xor 0x01).toByte()
        val bodyOutcome = sBob.decryptFrame(tamperedBody)
        assertTrue(bodyOutcome is FrameDecryptOutcome.Rejected)

        // Flip innerFrameType byte inside wire envelope (index 10) -> AAD verification fails!
        val tamperedAad = encrypted.copyOf()
        tamperedAad[10] = FrameType.DISCONNECT
        val aadOutcome = sBob.decryptFrame(tamperedAad)
        assertTrue(aadOutcome is FrameDecryptOutcome.Rejected)

        // Original unmodified encrypted frame still decrypts cleanly (MAC failed before replay window admission!)
        val validOutcome = sBob.decryptFrame(encrypted)
        assertTrue("Authentic packet must still decrypt after tampered attempts", validOutcome is FrameDecryptOutcome.Success)
        assertArrayEquals(plaintext, (validOutcome as FrameDecryptOutcome.Success).result.plaintext)

        sAlice.close()
        sBob.close()
    }

    // 8 & 9. Replay attack & duplicate encrypted frame rejection + handshake challenge replay
    @Test
    fun testReplayAndDuplicateFrameRejection() {
        val alice = createTestIdentityManager("alice_replay")
        val bob = createTestIdentityManager("bob_replay")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_rep1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_rep2", cryptoProvider))
        val (sAlice, sBob) = createSocketHandshakePair(svcA, svcB)

        val frame1 = sAlice.encryptFrame(FrameType.RELIABLE_MSG, "msg-1".toByteArray())
        val frame2 = sAlice.encryptFrame(FrameType.RELIABLE_MSG, "msg-2".toByteArray())

        // First receipt succeeds
        assertTrue(sBob.decryptFrame(frame1) is FrameDecryptOutcome.Success)
        // Duplicate/replayed frame 1 rejected
        val dupOutcome = sBob.decryptFrame(frame1)
        assertTrue(dupOutcome is FrameDecryptOutcome.Rejected)
        assertTrue((dupOutcome as FrameDecryptOutcome.Rejected).isReplay)

        // Higher sequence frame 2 still succeeds
        assertTrue(sBob.decryptFrame(frame2) is FrameDecryptOutcome.Success)
        // Replaying frame 2 again rejected
        val replay2 = sBob.decryptFrame(frame2)
        assertTrue(replay2 is FrameDecryptOutcome.Rejected && replay2.isReplay)

        // Handshake challenge replay across restarts (persisted SharedPreferences cache)
        val challengeHex = "fe".repeat(32)
        val cache1 = HandshakeChallengeReplayCache(context, "stage13_replay_persist", cryptoProvider)
        cache1.checkAndRegisterChallenge(challengeHex)
        val cacheAfterRestart = HandshakeChallengeReplayCache(context, "stage13_replay_persist", cryptoProvider)
        try {
            cacheAfterRestart.checkAndRegisterChallenge(challengeHex)
            fail("Replayed challenge after restart must be rejected")
        } catch (e: IOException) {
            assertTrue(e.message?.contains("replay", ignoreCase = true) == true)
        }

        sAlice.close()
        sBob.close()
    }

    // 10. Stale / cross-session frame rejected in new session
    @Test
    fun testStaleSessionMessageRejectedInNewSession() {
        val alice = createTestIdentityManager("alice_stale")
        val bob = createTestIdentityManager("bob_stale")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_st1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_st2", cryptoProvider))

        val (sessionA1, sessionB1) = createSocketHandshakePair(svcA, svcB)
        val (sessionA2, sessionB2) = createSocketHandshakePair(svcA, svcB)

        assertNotEquals(sessionA1.sessionId, sessionA2.sessionId)
        val oldFrame = sessionA1.encryptFrame(FrameType.PROTOCOL_MESSAGE, "old session payload".toByteArray())

        // Inject old session's encrypted frame into new session B2
        val outcome = sessionB2.decryptFrame(oldFrame)
        assertTrue(outcome is FrameDecryptOutcome.Rejected)
        assertTrue((outcome as FrameDecryptOutcome.Rejected).isReplay)

        sessionA1.close(); sessionB1.close()
        sessionA2.close(); sessionB2.close()
    }

    // 11. Session expiration (TTL and frame cap) + forced rotation requiring re-handshake
    @Test
    fun testSessionExpirationForcesTerminationAndReHandshake() {
        val alice = createTestIdentityManager("alice_exp")
        val bob = createTestIdentityManager("bob_exp")
        val shortCfg = TransportSecurityConfig(sessionTtlMs = 5_000L, maxFramesPerSession = 2L)
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), shortCfg, replayCache = HandshakeChallengeReplayCache(null, "rc_ex1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), shortCfg, replayCache = HandshakeChallengeReplayCache(null, "rc_ex2", cryptoProvider))

        val (sA, sB) = createSocketHandshakePair(svcA, svcB)
        val t0 = sA.createdAtMs

        // Frame 1 & 2 succeed
        val f1 = sA.encryptFrame(FrameType.RELIABLE_MSG, "one".toByteArray(), nowMs = t0 + 100)
        val f2 = sA.encryptFrame(FrameType.RELIABLE_MSG, "two".toByteArray(), nowMs = t0 + 200)
        assertTrue(sB.decryptFrame(f1, nowMs = t0 + 100) is FrameDecryptOutcome.Success)
        assertTrue(sB.decryptFrame(f2, nowMs = t0 + 200) is FrameDecryptOutcome.Success)

        // Frame 3 hits maxFramesPerSession = 2 and forces re-handshake
        try {
            sA.encryptFrame(FrameType.RELIABLE_MSG, "three".toByteArray(), nowMs = t0 + 300)
            fail("Expected frame limit expiration")
        } catch (_: IOException) {
            assertFalse(sA.isActive(t0 + 300))
        }

        // TTL expiration
        val (sA2, sB2) = createSocketHandshakePair(svcA, svcB)
        val ttlOutcome = sB2.decryptFrame(
            sA2.encryptFrame(FrameType.RELIABLE_MSG, "ttl".toByteArray(), nowMs = sA2.createdAtMs + 100),
            nowMs = sB2.createdAtMs + 6_000L
        )
        assertTrue(ttlOutcome is FrameDecryptOutcome.Rejected && ttlOutcome.isExpired)
        sA2.close(); sB2.close()
    }

    // 12. Revoked peer identity: blocks future handshakes, terminates live sessions immediately, persists across restarts
    @Test
    fun testPeerRevocationBlocksAndTerminatesActiveSessionAndPersists() = runBlocking {
        val alice = createTestIdentityManager("alice_rev")
        val bob = createTestIdentityManager("bob_rev")
        val bobId = bob.getActiveIdentity()!!.nodeId
        val aliceId = alice.getActiveIdentity()!!.nodeId

        val repoAlice = NetworkTransportRepository(context = context, identityManager = alice, scope = testScope)
        val repoBob = NetworkTransportRepository(context = context, identityManager = bob, scope = testScope)
        try {
            val portBob = repoBob.startListening(0)
            val connRes = repoAlice.connectToPeer(PeerEndpoint("127.0.0.1", portBob, bobId))
            assertTrue(connRes.isSuccess)
            delay(250)
            assertEquals(1, repoBob.authenticatedPeers.value.size)

            // Revoke Alice on Bob -> immediately terminates active encrypted session & disconnects
            val terminated = repoBob.revokePeerIdentity(aliceId, "Compromised peer key test")
            assertEquals(1, terminated)
            delay(250)
            assertEquals(0, repoBob.securityUiState.value.encryptedSessionsCount)
            assertEquals(1, repoBob.securityUiState.value.revokedPeersCount)
            assertTrue(repoBob.securityUiState.value.revokedPeerIds.contains(aliceId))

            // Alice attempting to reconnect while revoked is rejected
            val reconnectBlocked = repoAlice.connectToPeer(PeerEndpoint("127.0.0.1", portBob, bobId))
            assertTrue("Revoked peer reconnect must fail", reconnectBlocked.isFailure)
            delay(150)
            assertEquals(0, repoBob.securityUiState.value.encryptedSessionsCount)
            assertEquals(SecurityEventType.PEER_REVOKED, repoBob.securityUiState.value.lastSecurityEvent?.type)

            // Restart Bob's NetworkTransportRepository with same identity & verify revocation persisted
            repoBob.close()
            val bobRestarted = openExistingIdentityManager("bob_rev")
            val repoBobRestarted = NetworkTransportRepository(context = context, identityManager = bobRestarted, scope = testScope)
            try {
                assertTrue(repoBobRestarted.transportSecurityManager.trustManager.isPeerRevoked(aliceId))
                val portBob2 = repoBobRestarted.startListening(0)
                val blockedAfterRestart = repoAlice.connectToPeer(PeerEndpoint("127.0.0.1", portBob2, bobId))
                assertTrue("Revocation must persist across app restarts", blockedAfterRestart.isFailure)

                // Unrevoke Alice and verify fresh encrypted session succeeds
                assertTrue(repoBobRestarted.unrevokePeerIdentity(aliceId))
                val unrevokedRes = repoAlice.connectToPeer(PeerEndpoint("127.0.0.1", portBob2, bobId))
                assertTrue("Unrevoked peer must connect cleanly", unrevokedRes.isSuccess)
            } finally {
                repoBobRestarted.close()
            }
        } finally {
            repoAlice.close()
            repoBob.close()
        }
    }

    // 13. Unexpected identity / public-key change detection
    @Test
    fun testUnexpectedIdentityAndKeyChangeDetected() {
        val trustMgr = PeerTrustManager(context = context, preferencesName = "stage13_pin_${UUID.randomUUID()}", cryptoProvider = cryptoProvider)
        val kp1 = cryptoProvider.generateEd25519KeyPair()
        val nodeId1 = cryptoProvider.deriveNodeId(kp1.publicKeyBytes)
        val kp2 = cryptoProvider.generateEd25519KeyPair()
        val nodeId2 = cryptoProvider.deriveNodeId(kp2.publicKeyBytes)

        // Pin nodeId1 at endpoint 10.0.0.5:9876
        trustMgr.recordAuthenticatedIdentity(nodeId1, cryptoProvider.toHex(kp1.publicKeyBytes), "10.0.0.5:9876")

        // Same endpoint now claims different nodeId2 -> IDENTITY_MISMATCH
        val endpointSwap = trustMgr.checkHandshakeIdentityAllowed(nodeId2, cryptoProvider.toHex(kp2.publicKeyBytes), "10.0.0.5:9876", null)
        assertTrue(endpointSwap is IdentityTrustCheckResult.IdentityMismatch)
        assertEquals(PeerTrustState.IDENTITY_MISMATCH, trustMgr.getTrustState(nodeId2))

        // Same nodeId1 presents different public key -> IDENTITY_MISMATCH
        val keySwap = trustMgr.checkHandshakeIdentityAllowed(nodeId1, cryptoProvider.toHex(kp2.publicKeyBytes), null, null)
        assertTrue(keySwap is IdentityTrustCheckResult.IdentityMismatch)
    }

    // 14. Oversized handshake & oversized encrypted frame rejection before memory allocation
    @Test
    fun testOversizedHandshakeAndEncryptedFrameRejectedEarly() {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.write(MessageFramer.MAGIC_HEADER)
        dos.writeByte(FrameType.SECURE_HANDSHAKE_INIT.toInt())
        dos.writeInt(999_999) // Claims ~1 MB
        dos.flush()

        try {
            MessageFramer.readFrame(ByteArrayInputStream(baos.toByteArray()), maxPayloadSize = 8_192)
            fail("Must reject oversized handshake header length before reading payload")
        } catch (e: IOException) {
            assertTrue(e.message?.contains("exceeds") == true || e.message?.contains("length") == true)
        }

        // Oversized encrypted frame check inside session
        val cfg = TransportSecurityConfig(maxEncryptedFrameBytes = 128)
        val alice = createTestIdentityManager("alice_ov")
        val bob = createTestIdentityManager("bob_ov")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), cfg, replayCache = HandshakeChallengeReplayCache(null, "rc_ov1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), cfg, replayCache = HandshakeChallengeReplayCache(null, "rc_ov2", cryptoProvider))
        val (sA, sB) = createSocketHandshakePair(svcA, svcB)
        try {
            sA.encryptFrame(FrameType.PROTOCOL_MESSAGE, ByteArray(512))
            fail("Expected oversized frame rejection")
        } catch (e: IOException) {
            assertTrue(e.message?.contains("exceeds") == true)
        } finally {
            sA.close(); sB.close()
        }
    }

    // 15 & 16. Connection flood, unauthenticated handshake cap, auth-failure cooldown, and per-peer message rate limit
    @Test
    fun testConnectionFloodAndPerPeerMessageRateLimiting() {
        val cfg = TransportSecurityConfig(
            maxConcurrentUnauthenticatedConnections = 2,
            maxPendingHandshakeQueue = 4,
            maxConnectionAttemptsPerWindow = 3,
            connectionRateWindowMs = 10_000L,
            maxMessagesPerPeerPerWindow = 4,
            messageRateWindowMs = 10_000L,
            maxAuthFailuresBeforeCooldown = 2,
            peerCooldownMs = 30_000L
        )
        val guard = ConnectionAbuseProtector(cfg)
        val host = "192.168.1.99"

        // Concurrent unauthenticated slot limit = 2
        assertTrue(guard.tryAcquirePendingHandshakeSlot(host, 1_000L) is GuardAdmissionResult.Allowed)
        assertTrue(guard.tryAcquirePendingHandshakeSlot(host, 1_100L) is GuardAdmissionResult.Allowed)
        val overConcurrent = guard.tryAcquirePendingHandshakeSlot(host, 1_200L)
        assertTrue(overConcurrent is GuardAdmissionResult.Rejected)

        // Release slots; 3rd attempt succeeds, 4th exceeds connection attempt rate window -> triggers cooldown
        guard.releaseUnauthenticatedSlot()
        guard.releaseUnauthenticatedSlot()
        assertTrue(guard.tryAcquirePendingHandshakeSlot(host, 1_300L) is GuardAdmissionResult.Allowed)
        guard.releaseUnauthenticatedSlot()
        val rateLimited = guard.tryAcquirePendingHandshakeSlot(host, 1_400L)
        assertTrue("Exceeding connection rate limit must reject & engage cooldown", rateLimited is GuardAdmissionResult.Rejected)
        assertTrue(guard.isInCooldown(host, 1_500L))

        // Per-peer message rate limiting
        val peerId = "peer_flood_1"
        repeat(4) {
            assertTrue(guard.checkPeerMessageRate(peerId, 2_000L + it) is GuardAdmissionResult.Allowed)
        }
        val msgFlooded = guard.checkPeerMessageRate(peerId, 2_100L)
        assertTrue(msgFlooded is GuardAdmissionResult.Rejected)

        // Auth failure cooldown
        val badHost = "10.9.9.9"
        assertFalse(guard.recordAuthFailure(badHost, 3_000L))
        assertTrue("2nd failure triggers cooldown", guard.recordAuthFailure(badHost, 3_100L))
        assertTrue(guard.checkOutboundAllowed(badHost, 3_200L) is GuardAdmissionResult.Rejected)
    }

    // 17. Malformed cryptographic wire envelopes & all-zero X25519 keys rejected
    @Test
    fun testMalformedMessagesAndWeakX25519Rejected() {
        assertFalse(X25519KeyExchange.isValidPublicKey(ByteArray(32)))
        assertTrue(X25519KeyExchange.isValidPublicKey(ByteArray(32) { 0x09 }))

        val alice = createTestIdentityManager("alice_mal")
        val bob = createTestIdentityManager("bob_mal")
        val svcA = SecureSessionHandshakeService(alice, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_m1", cryptoProvider))
        val svcB = SecureSessionHandshakeService(bob, PeerTrustManager(null, cryptoProvider = cryptoProvider), replayCache = HandshakeChallengeReplayCache(null, "rc_m2", cryptoProvider))
        val (sA, sB) = createSocketHandshakePair(svcA, svcB)

        // Truncated wire bytes
        assertTrue(sB.decryptFrame(ByteArray(24) { 0x03 }) is FrameDecryptOutcome.Rejected)
        // Wrong wire format version
        val valid = sA.encryptFrame(FrameType.PROTOCOL_MESSAGE, "hello".toByteArray())
        val badWireVer = valid.copyOf().apply { this[0] = 0x7F }
        assertTrue(sB.decryptFrame(badWireVer) is FrameDecryptOutcome.Rejected)

        // Reflection / direction spoof: feed Alice's outbound encrypted frame back into Alice's own decryptFrame!
        val reflected = sA.decryptFrame(valid)
        assertTrue("Reflected outbound frame must be rejected by direction check", reflected is FrameDecryptOutcome.Rejected)

        // Verify HKDF key separation produces distinct directional keys
        val sched = NoiseStyleKeySchedule("nmd-dev-net-1", 3, TransportSecurityConfig.DEFAULT_CIPHER_SUITE_ID, 3)
        val keys = sched.mixKeyAndSplit(ByteArray(32) { 0x42 }, "sid_123")
        assertFalse(keys.initiatorToResponderKey.contentEquals(keys.responderToInitiatorKey))
        X25519KeyExchange.zeroize(keys.initiatorToResponderKey, keys.responderToInitiatorKey)

        sA.close(); sB.close()
    }

    // 18. App restart establishes fresh ephemeral sessions & preserves Stage 6 reliable delivery over encrypted channel
    @Test
    fun testRestartFreshEphemeralSessionAndNoKeyPersistenceOnDisk() = runBlocking {
        val alice = createTestIdentityManager("alice_restart")
        val bob = createTestIdentityManager("bob_restart")
        val bobId = bob.getActiveIdentity()!!.nodeId

        val repoA1 = NetworkTransportRepository(context = context, identityManager = alice, scope = testScope)
        val repoB = NetworkTransportRepository(context = context, identityManager = bob, scope = testScope)
        val firstSessionId: String
        try {
            val portB = repoB.startListening(0)
            val c1 = repoA1.connectToPeer(PeerEndpoint("127.0.0.1", portB, bobId)).getOrThrow()
            firstSessionId = repoA1.transportSecurityManager.getActiveSession(c1.connectionId)!!.sessionId

            // Verify Stage 6 reliable ACK-backed messaging operates seamlessly over ChaCha20-Poly1305
            delay(250)
            val sessA = repoA1.activeSessions.value.first()
            val relRes = repoA1.sendReliableP2pMessage(sessA.sessionId, P2pMessageType.DATA, "{\"encrypted\":true}")
            assertTrue("Stage 6 reliable message must succeed over Stage 13 encryption", relRes.isSuccess)
        } finally {
            repoA1.close()
        }

        // Verify SharedPreferences trust store contains NO ephemeral session keys or private keys
        val trustPrefs = context.getSharedPreferences(
            "nmd_p2p_trust_${alice.getActiveIdentity()!!.nodeId.take(16)}",
            Context.MODE_PRIVATE
        )
        val rawPrefsText = trustPrefs.all.entries.joinToString("\n") { "${it.key}=${it.value}" }
        assertFalse(rawPrefsText.contains("sendKey", ignoreCase = true))
        assertFalse(rawPrefsText.contains("privateKey", ignoreCase = true))

        // Simulated restart of Alice with existing persistent Ed25519 identity connects again with new ephemeral X25519 session
        val aliceRestarted = openExistingIdentityManager("alice_restart")
        val repoA2 = NetworkTransportRepository(context = context, identityManager = aliceRestarted, scope = testScope)
        try {
            val portB = repoB.boundPort.value!!
            val c2 = repoA2.connectToPeer(PeerEndpoint("127.0.0.1", portB, bobId)).getOrThrow()
            val secondSessionId = repoA2.transportSecurityManager.getActiveSession(c2.connectionId)!!.sessionId
            assertNotEquals("Restarted app must negotiate a fresh ephemeral session ID", firstSessionId, secondSessionId)
            assertEquals(TransportSecurityStatus.SECURE, repoA2.securityUiState.value.status)

            // Also verify manual Rotate Session Keys terminates active sessions & zeroes RAM keys
            val rotated = repoA2.rotateEncryptedSessions()
            assertEquals(1, rotated)
            delay(150)
            assertEquals(0, repoA2.securityUiState.value.encryptedSessionsCount)
        } finally {
            repoA2.close()
            repoB.close()
        }
    }

    // 19. Threat model documentation + Localization parity (EN, AR RTL, FR)
    @Test
    fun testThreatModelAndStage13MultilingualResources() {
        assertTrue(SecurityThreatModel.MITIGATED_THREATS.size >= 10)
        assertTrue(SecurityThreatModel.UNPREVENTABLE_BY_TRANSPORT_ALONE.size >= 3)

        val keys = listOf(
            R.string.stage13_security_title,
            R.string.stage13_badge_encrypted,
            R.string.stage13_security_notice,
            R.string.stage13_field_status,
            R.string.stage13_status_secure,
            R.string.stage13_status_connecting,
            R.string.stage13_status_authenticating,
            R.string.stage13_status_encrypted,
            R.string.stage13_status_auth_failed,
            R.string.stage13_status_disconnected,
            R.string.stage13_status_peer_revoked,
            R.string.stage13_field_protocol,
            R.string.stage13_field_auth_peers,
            R.string.stage13_field_encrypted_sessions,
            R.string.stage13_field_pending_handshakes,
            R.string.stage13_field_failed_handshakes,
            R.string.stage13_field_rejected_replays,
            R.string.stage13_field_rate_limited,
            R.string.stage13_field_revoked_peers,
            R.string.stage13_field_last_event,
            R.string.stage13_action_rotate_sessions,
            R.string.stage13_action_revoke,
            R.string.stage13_action_unrevoke
        )

        val enValues = mutableMapOf<Int, String>()
        val arValues = mutableMapOf<Int, String>()
        val frValues = mutableMapOf<Int, String>()

        listOf(Locale.ENGLISH, Locale.forLanguageTag("ar"), Locale.FRENCH).forEach { locale ->
            val conf = Configuration(context.resources.configuration).apply { setLocale(locale) }
            val localizedCtx = context.createConfigurationContext(conf)
            keys.forEach { resId ->
                val text = localizedCtx.getString(resId)
                assertTrue("Missing localized string for ${locale.language}", text.isNotBlank())
                when (locale.language) {
                    "en" -> enValues[resId] = text
                    "ar" -> arValues[resId] = text
                    "fr" -> frValues[resId] = text
                }
            }
        }
        assertNotEquals(enValues[R.string.stage13_security_title], arValues[R.string.stage13_security_title])
        assertNotEquals(enValues[R.string.stage13_security_title], frValues[R.string.stage13_security_title])
    }
}
