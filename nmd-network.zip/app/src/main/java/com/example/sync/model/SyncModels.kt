package com.example.sync.model

import com.example.blockchain.model.Block
import com.example.consensus.model.CommitCertificate
import com.example.transaction.model.NmdTransaction
import org.json.JSONArray
import org.json.JSONObject

object SyncProtocolConstants {
    const val SYNC_PROTOCOL_VERSION = 1
    const val ZERO_HASH = "0000000000000000000000000000000000000000000000000000000000000000"
}

enum class SyncStatusState {
    IDLE,
    DISCOVERING_PEERS,
    SYNCHRONIZING,
    VERIFYING_BLOCKS,
    PAUSED,
    SYNCED,
    FAILED,
    CONFLICT_DETECTED
}

enum class SyncErrorCode {
    NONE,
    NOT_INITIALIZED,
    NO_ELIGIBLE_PEERS,
    INCOMPATIBLE_CHAIN_ID,
    INCOMPATIBLE_GENESIS_HASH,
    INCOMPATIBLE_PROTOCOL_VERSION,
    PEER_DISCONNECTED,
    REQUEST_TIMEOUT,
    INVALID_RESPONSE_ORDER,
    MALFORMED_PAYLOAD,
    PAYLOAD_TOO_LARGE,
    DUPLICATE_OR_UNREQUESTED_DATA,
    INVALID_BLOCK_HASH,
    INVALID_PREVIOUS_HASH,
    INVALID_MERKLE_ROOT,
    INVALID_BLOCK_HEIGHT,
    INVALID_TRANSACTION,
    INVALID_COMMIT_CERTIFICATE,
    CONFLICTING_FINALIZED_HISTORY,
    STORAGE_ERROR,
    PAUSED_BY_USER,
    MOBILE_RESOURCE_PAUSED
}

/**
 * Blockchain Status Protocol payload exchanged over authenticated P2P sessions.
 */
data class ChainStatusExchangeMessage(
    val requestId: String = "",
    val chainId: String,
    val genesisHash: String,
    val currentHeight: Long,
    val latestBlockHash: String,
    val finalizedHeight: Long,
    val finalizedBlockHash: String,
    val protocolVersion: Int = SyncProtocolConstants.SYNC_PROTOCOL_VERSION,
    val syncState: SyncStatusState = SyncStatusState.IDLE,
    val timestampMs: Long = System.currentTimeMillis()
) {
    fun toJson(): String = JSONObject().apply {
        put("request_id", requestId)
        put("chain_id", chainId)
        put("genesis_hash", genesisHash.lowercase())
        put("current_height", currentHeight)
        put("latest_block_hash", latestBlockHash.lowercase())
        put("finalized_height", finalizedHeight)
        put("finalized_block_hash", finalizedBlockHash.lowercase())
        put("protocol_version", protocolVersion)
        put("sync_state", syncState.name)
        put("timestamp_ms", timestampMs)
    }.toString()

    companion object {
        fun fromJson(raw: String, maxBytes: Int = 32 * 1024): ChainStatusExchangeMessage? {
            if (raw.isBlank() || raw.toByteArray(Charsets.UTF_8).size > maxBytes) return null
            return try {
                val j = JSONObject(raw)
                val stateStr = j.optString("sync_state", SyncStatusState.IDLE.name)
                val state = try { SyncStatusState.valueOf(stateStr) } catch (_: Exception) { SyncStatusState.IDLE }
                ChainStatusExchangeMessage(
                    requestId = j.optString("request_id", ""),
                    chainId = j.getString("chain_id").trim(),
                    genesisHash = j.getString("genesis_hash").trim().lowercase(),
                    currentHeight = j.getLong("current_height"),
                    latestBlockHash = j.getString("latest_block_hash").trim().lowercase(),
                    finalizedHeight = j.getLong("finalized_height"),
                    finalizedBlockHash = j.getString("finalized_block_hash").trim().lowercase(),
                    protocolVersion = j.getInt("protocol_version"),
                    syncState = state,
                    timestampMs = j.optLong("timestamp_ms", 0L)
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class ChainStatusRequest(
    val requestId: String,
    val chainId: String,
    val genesisHash: String,
    val protocolVersion: Int = SyncProtocolConstants.SYNC_PROTOCOL_VERSION
) {
    fun toJson(): String = JSONObject().apply {
        put("request_id", requestId)
        put("chain_id", chainId)
        put("genesis_hash", genesisHash.lowercase())
        put("protocol_version", protocolVersion)
    }.toString()

    companion object {
        fun fromJson(raw: String, maxBytes: Int = 8 * 1024): ChainStatusRequest? {
            if (raw.isBlank() || raw.toByteArray(Charsets.UTF_8).size > maxBytes) return null
            return try {
                val j = JSONObject(raw)
                ChainStatusRequest(
                    requestId = j.getString("request_id").trim(),
                    chainId = j.getString("chain_id").trim(),
                    genesisHash = j.optString("genesis_hash", "").trim().lowercase(),
                    protocolVersion = j.optInt("protocol_version", SyncProtocolConstants.SYNC_PROTOCOL_VERSION)
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class BlockHeadersRequest(
    val requestId: String,
    val chainId: String,
    val fromHeight: Long,
    val maxHeaders: Int
) {
    fun toJson(): String = JSONObject().apply {
        put("request_id", requestId)
        put("chain_id", chainId)
        put("from_height", fromHeight)
        put("max_headers", maxHeaders)
    }.toString()

    companion object {
        fun fromJson(raw: String, maxBytes: Int = 8 * 1024): BlockHeadersRequest? {
            if (raw.isBlank() || raw.toByteArray(Charsets.UTF_8).size > maxBytes) return null
            return try {
                val j = JSONObject(raw)
                BlockHeadersRequest(
                    requestId = j.getString("request_id").trim(),
                    chainId = j.getString("chain_id").trim(),
                    fromHeight = j.getLong("from_height"),
                    maxHeaders = j.getInt("max_headers")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class SyncBlockHeaderEntry(
    val height: Long,
    val blockHash: String,
    val previousHash: String,
    val timestamp: Long,
    val chainId: String,
    val protocolVersion: Int,
    val merkleRoot: String,
    val transactionCount: Int,
    val producerId: String
) {
    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("height", height)
        put("block_hash", blockHash.lowercase())
        put("previous_hash", previousHash.lowercase())
        put("timestamp", timestamp)
        put("chain_id", chainId)
        put("protocol_version", protocolVersion)
        put("merkle_root", merkleRoot.lowercase())
        put("transaction_count", transactionCount)
        put("producer_id", producerId)
    }

    companion object {
        fun fromJsonObject(j: JSONObject): SyncBlockHeaderEntry? = try {
            SyncBlockHeaderEntry(
                height = j.getLong("height"),
                blockHash = j.getString("block_hash").trim().lowercase(),
                previousHash = j.getString("previous_hash").trim().lowercase(),
                timestamp = j.getLong("timestamp"),
                chainId = j.getString("chain_id").trim(),
                protocolVersion = j.getInt("protocol_version"),
                merkleRoot = j.getString("merkle_root").trim().lowercase(),
                transactionCount = j.getInt("transaction_count"),
                producerId = j.getString("producer_id").trim()
            )
        } catch (_: Exception) {
            null
        }
    }
}

data class BlockHeadersResponse(
    val requestId: String,
    val chainId: String,
    val headers: List<SyncBlockHeaderEntry>
) {
    fun toJson(): String = JSONObject().apply {
        put("request_id", requestId)
        put("chain_id", chainId)
        val arr = JSONArray()
        headers.forEach { arr.put(it.toJsonObject()) }
        put("headers", arr)
    }.toString()

    companion object {
        fun fromJson(raw: String, maxBytes: Int = 512 * 1024): BlockHeadersResponse? {
            if (raw.isBlank() || raw.toByteArray(Charsets.UTF_8).size > maxBytes) return null
            return try {
                val j = JSONObject(raw)
                val arr = j.getJSONArray("headers")
                val entries = ArrayList<SyncBlockHeaderEntry>(arr.length())
                for (i in 0 until arr.length()) {
                    val item = SyncBlockHeaderEntry.fromJsonObject(arr.getJSONObject(i)) ?: return null
                    entries.add(item)
                }
                BlockHeadersResponse(
                    requestId = j.getString("request_id").trim(),
                    chainId = j.getString("chain_id").trim(),
                    headers = entries
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class BlocksRequest(
    val requestId: String,
    val chainId: String,
    val fromHeight: Long,
    val maxBlocks: Int
) {
    fun toJson(): String = JSONObject().apply {
        put("request_id", requestId)
        put("chain_id", chainId)
        put("from_height", fromHeight)
        put("max_blocks", maxBlocks)
    }.toString()

    companion object {
        fun fromJson(raw: String, maxBytes: Int = 8 * 1024): BlocksRequest? {
            if (raw.isBlank() || raw.toByteArray(Charsets.UTF_8).size > maxBytes) return null
            return try {
                val j = JSONObject(raw)
                BlocksRequest(
                    requestId = j.getString("request_id").trim(),
                    chainId = j.getString("chain_id").trim(),
                    fromHeight = j.getLong("from_height"),
                    maxBlocks = j.getInt("max_blocks")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

/**
 * Self-contained verifiable block bundle carrying:
 * - Stage 8 [Block]
 * - Stage 10 [CommitCertificate] (>2/3 BFT proof)
 * - Stage 9 full [NmdTransaction] list matching `block.body.transactionRefs` for zero-trust Ed25519 verification
 */
data class SyncBlockBundle(
    val block: Block,
    val commitCertificate: CommitCertificate,
    val transactions: List<NmdTransaction> = emptyList()
) {
    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("block", JSONObject(block.toStorageJson()))
        put("commit_certificate", JSONObject(commitCertificate.toJson()))
        val txArr = JSONArray()
        transactions.forEach { txArr.put(JSONObject(it.toJson())) }
        put("transactions", txArr)
    }

    companion object {
        fun fromJsonObject(j: JSONObject): SyncBlockBundle? = try {
            val blockObj = j.getJSONObject("block")
            val block = Block.fromStorageJson(blockObj.toString()) ?: return null
            val certObj = j.getJSONObject("commit_certificate")
            val cert = CommitCertificate.fromJson(certObj.toString()) ?: return null
            val txArr = j.optJSONArray("transactions") ?: JSONArray()
            val txs = ArrayList<NmdTransaction>(txArr.length())
            for (i in 0 until txArr.length()) {
                val tx = NmdTransaction.fromJson(txArr.getJSONObject(i).toString()) ?: return null
                txs.add(tx)
            }
            SyncBlockBundle(block = block, commitCertificate = cert, transactions = txs)
        } catch (_: Exception) {
            null
        }
    }
}

data class BlocksResponse(
    val requestId: String,
    val chainId: String,
    val bundles: List<SyncBlockBundle>
) {
    fun toJson(): String = JSONObject().apply {
        put("request_id", requestId)
        put("chain_id", chainId)
        val arr = JSONArray()
        bundles.forEach { arr.put(it.toJsonObject()) }
        put("bundles", arr)
    }.toString()

    companion object {
        fun fromJson(raw: String, maxBytes: Int = 512 * 1024): BlocksResponse? {
            if (raw.isBlank() || raw.toByteArray(Charsets.UTF_8).size > maxBytes) return null
            return try {
                val j = JSONObject(raw)
                val arr = j.getJSONArray("bundles")
                val list = ArrayList<SyncBlockBundle>(arr.length())
                for (i in 0 until arr.length()) {
                    val b = SyncBlockBundle.fromJsonObject(arr.getJSONObject(i)) ?: return null
                    list.add(b)
                }
                BlocksResponse(
                    requestId = j.getString("request_id").trim(),
                    chainId = j.getString("chain_id").trim(),
                    bundles = list
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class SyncPeerState(
    val peerId: String,
    val sessionId: String,
    val isCompatible: Boolean,
    val incompatibilityReason: String? = null,
    val reportedStatus: ChainStatusExchangeMessage? = null,
    val reportedHeight: Long = -1L,
    val reportedFinalizedHeight: Long = -1L,
    val highestVerifiedHeightFromPeer: Long = -1L,
    val reliabilityScore: Int = 50,
    val latencyMs: Long = 0L,
    val consecutiveFailures: Int = 0,
    val cooldownUntilMs: Long = 0L,
    val lastUpdatedMs: Long = System.currentTimeMillis()
) {
    fun isInCooldown(nowMs: Long = System.currentTimeMillis()): Boolean = cooldownUntilMs > nowMs
}

data class SyncConflictRecord(
    val conflictId: String,
    val chainId: String,
    val conflictHeight: Long,
    val localBlockHash: String,
    val conflictingBlockHash: String,
    val reportingPeerId: String,
    val reason: String,
    val detectedAtMs: Long = System.currentTimeMillis(),
    val hasValidConflictingCertificate: Boolean = false
)

data class SyncProgressCheckpoint(
    val chainId: String,
    val lastVerifiedHeight: Long = 0L,
    val lastVerifiedBlockHash: String = SyncProtocolConstants.ZERO_HASH,
    val targetReportedHeight: Long = 0L,
    val downloadedBlocksCount: Long = 0L,
    val verifiedBlocksCount: Long = 0L,
    val activePeerId: String? = null,
    val statusState: SyncStatusState = SyncStatusState.IDLE,
    val lastSyncTimestampMs: Long? = null,
    val lastErrorCode: SyncErrorCode = SyncErrorCode.NONE,
    val lastErrorMessage: String? = null
)

data class SyncUiState(
    val isInitialized: Boolean = false,
    val isDevelopmentMode: Boolean = true,
    val chainId: String = "nmd-local-dev-1",
    val syncStatus: SyncStatusState = SyncStatusState.IDLE,
    val localHeight: Long = 0L,
    val latestFinalizedHeight: Long = 0L,
    val latestFinalizedBlockHash: String = SyncProtocolConstants.ZERO_HASH,
    val highestReportedPeerHeight: Long = 0L,
    val highestVerifiedPeerHeight: Long = 0L,
    val currentSyncPeerId: String? = null,
    val downloadedBlocksCount: Long = 0L,
    val verifiedBlocksCount: Long = 0L,
    val remainingBlocksCount: Long = 0L,
    val progressFraction: Float = 0f,
    val compatiblePeersCount: Int = 0,
    val connectedPeersCount: Int = 0,
    val lastSyncTimestampMs: Long? = null,
    val isUserPaused: Boolean = false,
    val mobileResourcePaused: Boolean = false,
    val mobilePauseReason: String? = null,
    val errorCode: SyncErrorCode = SyncErrorCode.NONE,
    val errorMessage: String? = null,
    val conflictRecords: List<SyncConflictRecord> = emptyList(),
    val peerStates: List<SyncPeerState> = emptyList()
) {
    val progressPercent: Int
        get() = (progressFraction.coerceIn(0f, 1f) * 100f).toInt()
}
