package com.example.sync.storage

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.sync.model.SyncConflictRecord
import com.example.sync.model.SyncErrorCode
import com.example.sync.model.SyncProgressCheckpoint
import com.example.sync.model.SyncStatusState
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable

@Entity(tableName = "sync_checkpoints")
data class SyncCheckpointEntity(
    @PrimaryKey val chainId: String,
    val lastVerifiedHeight: Long,
    val lastVerifiedBlockHash: String,
    val targetReportedHeight: Long,
    val downloadedBlocksCount: Long,
    val verifiedBlocksCount: Long,
    val activePeerId: String?,
    val statusState: String,
    val lastSyncTimestampMs: Long?,
    val lastErrorCode: String,
    val lastErrorMessage: String?
) {
    fun toDomain() = SyncProgressCheckpoint(
        chainId = chainId,
        lastVerifiedHeight = lastVerifiedHeight,
        lastVerifiedBlockHash = lastVerifiedBlockHash,
        targetReportedHeight = targetReportedHeight,
        downloadedBlocksCount = downloadedBlocksCount,
        verifiedBlocksCount = verifiedBlocksCount,
        activePeerId = activePeerId,
        statusState = try { SyncStatusState.valueOf(statusState) } catch (_: Exception) { SyncStatusState.IDLE },
        lastSyncTimestampMs = lastSyncTimestampMs,
        lastErrorCode = try { SyncErrorCode.valueOf(lastErrorCode) } catch (_: Exception) { SyncErrorCode.NONE },
        lastErrorMessage = lastErrorMessage
    )

    companion object {
        fun fromDomain(checkpoint: SyncProgressCheckpoint) = SyncCheckpointEntity(
            chainId = checkpoint.chainId,
            lastVerifiedHeight = checkpoint.lastVerifiedHeight,
            lastVerifiedBlockHash = checkpoint.lastVerifiedBlockHash,
            targetReportedHeight = checkpoint.targetReportedHeight,
            downloadedBlocksCount = checkpoint.downloadedBlocksCount,
            verifiedBlocksCount = checkpoint.verifiedBlocksCount,
            activePeerId = checkpoint.activePeerId,
            statusState = checkpoint.statusState.name,
            lastSyncTimestampMs = checkpoint.lastSyncTimestampMs,
            lastErrorCode = checkpoint.lastErrorCode.name,
            lastErrorMessage = checkpoint.lastErrorMessage
        )
    }
}

@Entity(
    tableName = "sync_conflicts",
    indices = [Index(value = ["chainId", "conflictHeight"])]
)
data class SyncConflictEntity(
    @PrimaryKey val conflictId: String,
    val chainId: String,
    val conflictHeight: Long,
    val localBlockHash: String,
    val conflictingBlockHash: String,
    val reportingPeerId: String,
    val reason: String,
    val detectedAtMs: Long,
    val hasValidConflictingCertificate: Boolean
) {
    fun toDomain() = SyncConflictRecord(
        conflictId = conflictId,
        chainId = chainId,
        conflictHeight = conflictHeight,
        localBlockHash = localBlockHash,
        conflictingBlockHash = conflictingBlockHash,
        reportingPeerId = reportingPeerId,
        reason = reason,
        detectedAtMs = detectedAtMs,
        hasValidConflictingCertificate = hasValidConflictingCertificate
    )

    companion object {
        fun fromDomain(record: SyncConflictRecord) = SyncConflictEntity(
            conflictId = record.conflictId,
            chainId = record.chainId,
            conflictHeight = record.conflictHeight,
            localBlockHash = record.localBlockHash,
            conflictingBlockHash = record.conflictingBlockHash,
            reportingPeerId = record.reportingPeerId,
            reason = record.reason,
            detectedAtMs = record.detectedAtMs,
            hasValidConflictingCertificate = record.hasValidConflictingCertificate
        )
    }
}

@Dao
interface SyncDao {
    @Query("SELECT * FROM sync_checkpoints WHERE chainId = :chainId LIMIT 1")
    suspend fun getCheckpoint(chainId: String): SyncCheckpointEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCheckpoint(entity: SyncCheckpointEntity)

    @Query("SELECT * FROM sync_conflicts WHERE chainId = :chainId ORDER BY detectedAtMs DESC")
    suspend fun getConflicts(chainId: String): List<SyncConflictEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConflict(entity: SyncConflictEntity)

    @Query("DELETE FROM sync_conflicts WHERE chainId = :chainId")
    suspend fun clearConflicts(chainId: String)
}

@Database(
    entities = [SyncCheckpointEntity::class, SyncConflictEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SyncDatabase : RoomDatabase() {
    abstract fun syncDao(): SyncDao

    companion object {
        fun build(
            context: Context,
            dbName: String = "nmd_blockchain_sync.db",
            inMemory: Boolean = false
        ): SyncDatabase {
            val builder = if (inMemory) {
                Room.inMemoryDatabaseBuilder(context.applicationContext, SyncDatabase::class.java)
            } else {
                Room.databaseBuilder(context.applicationContext, SyncDatabase::class.java, dbName)
            }
            return builder.build()
        }
    }
}

interface SyncStorage : Closeable {
    suspend fun getCheckpoint(chainId: String): SyncProgressCheckpoint?
    suspend fun saveCheckpoint(checkpoint: SyncProgressCheckpoint)
    suspend fun getConflicts(chainId: String): List<SyncConflictRecord>
    suspend fun saveConflict(record: SyncConflictRecord)
    suspend fun clearConflicts(chainId: String)
}

class RoomSyncStorage(
    context: Context,
    dbName: String = "nmd_blockchain_sync.db",
    inMemory: Boolean = false,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : SyncStorage {

    private val db: SyncDatabase = SyncDatabase.build(context, dbName, inMemory)
    private val dao = db.syncDao()

    override suspend fun getCheckpoint(chainId: String): SyncProgressCheckpoint? = withContext(ioDispatcher) {
        dao.getCheckpoint(chainId)?.toDomain()
    }

    override suspend fun saveCheckpoint(checkpoint: SyncProgressCheckpoint) = withContext(ioDispatcher) {
        dao.upsertCheckpoint(SyncCheckpointEntity.fromDomain(checkpoint))
    }

    override suspend fun getConflicts(chainId: String): List<SyncConflictRecord> = withContext(ioDispatcher) {
        dao.getConflicts(chainId).map { it.toDomain() }
    }

    override suspend fun saveConflict(record: SyncConflictRecord) = withContext(ioDispatcher) {
        dao.upsertConflict(SyncConflictEntity.fromDomain(record))
    }

    override suspend fun clearConflicts(chainId: String) = withContext(ioDispatcher) {
        dao.clearConflicts(chainId)
    }

    override fun close() {
        db.close()
    }
}
