package com.example.sync.p2p

import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.reliable.DeliveryResult
import com.example.p2p.session.PeerSession
import com.example.sync.config.SyncConfig
import com.example.sync.model.BlockHeadersRequest
import com.example.sync.model.BlockHeadersResponse
import com.example.sync.model.BlocksRequest
import com.example.sync.model.BlocksResponse
import com.example.sync.model.ChainStatusExchangeMessage
import com.example.sync.model.ChainStatusRequest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap

sealed class SyncTransportCallResult<out T> {
    data class Success<T>(val value: T, val latencyMs: Long) : SyncTransportCallResult<T>()
    data class Failure(
        val reason: String,
        val isTimeout: Boolean = false,
        val isMalformedOrOversized: Boolean = false,
        val isDisconnected: Boolean = false
    ) : SyncTransportCallResult<Nothing>()
}

/**
 * Clean transport abstraction over Stage 5/6/7 authenticated P2P sessions for Stage 12 synchronization.
 * Production uses [P2pSyncTransportBridge]; multi-node Robolectric tests can wire nodes directly through
 * real serialization + peer routing without mocking validation logic.
 */
interface SyncPeerTransport {
    fun getAuthenticatedSessions(): List<PeerSession>

    suspend fun requestChainStatus(
        session: PeerSession,
        request: ChainStatusRequest,
        timeoutMs: Long
    ): SyncTransportCallResult<ChainStatusExchangeMessage>

    suspend fun requestBlockHeaders(
        session: PeerSession,
        request: BlockHeadersRequest,
        timeoutMs: Long
    ): SyncTransportCallResult<BlockHeadersResponse>

    suspend fun requestBlocks(
        session: PeerSession,
        request: BlocksRequest,
        timeoutMs: Long
    ): SyncTransportCallResult<BlocksResponse>
}

interface SyncIncomingRequestHandler {
    suspend fun handleChainStatusRequest(request: ChainStatusRequest): ChainStatusExchangeMessage
    suspend fun handleBlockHeadersRequest(request: BlockHeadersRequest): BlockHeadersResponse
    suspend fun handleBlocksRequest(request: BlocksRequest): BlocksResponse
}

/**
 * Production P2P Transport Bridge routing Stage 12 sync messages through
 * [com.example.p2p.repository.NetworkTransportRepository] / [com.example.p2p.service.ReliableP2pMessagingService].
 */
class P2pSyncTransportBridge(
    private val config: SyncConfig,
    @Volatile var authenticatedSessionsProvider: () -> List<PeerSession>,
    @Volatile var sendSyncMessageToSession: suspend (sessionId: String, type: P2pMessageType, payloadJson: String) -> Result<DeliveryResult>,
    private val peerRegistry: DistributedPeerRegistry? = null
) : SyncPeerTransport {

    @Volatile
    var requestHandler: SyncIncomingRequestHandler? = null

    private val pendingStatusResponses = ConcurrentHashMap<String, CompletableDeferred<Pair<String, String>>>()
    private val pendingHeaderResponses = ConcurrentHashMap<String, CompletableDeferred<Pair<String, String>>>()
    private val pendingBlockResponses = ConcurrentHashMap<String, CompletableDeferred<Pair<String, String>>>()

    override fun getAuthenticatedSessions(): List<PeerSession> {
        return authenticatedSessionsProvider().filter { it.isTrusted }
    }

    override suspend fun requestChainStatus(
        session: PeerSession,
        request: ChainStatusRequest,
        timeoutMs: Long
    ): SyncTransportCallResult<ChainStatusExchangeMessage> {
        if (!session.isTrusted) {
            return SyncTransportCallResult.Failure("Peer session is not authenticated", isDisconnected = true)
        }
        val deferred = CompletableDeferred<Pair<String, String>>()
        pendingStatusResponses[request.requestId] = deferred
        val started = System.currentTimeMillis()
        try {
            val sendRes = sendSyncMessageToSession(session.sessionId, P2pMessageType.CHAIN_STATUS_REQUEST, request.toJson())
            if (sendRes.isFailure) {
                return SyncTransportCallResult.Failure(
                    sendRes.exceptionOrNull()?.message ?: "Failed sending CHAIN_STATUS_REQUEST",
                    isDisconnected = true
                )
            }
            val rawPair = withTimeoutOrNull(timeoutMs) { deferred.await() }
                ?: return SyncTransportCallResult.Failure("Chain status request timed out", isTimeout = true)
            val latency = (System.currentTimeMillis() - started).coerceAtLeast(1L)
            if (rawPair.first != session.peerId) {
                return SyncTransportCallResult.Failure("Response sender ${rawPair.first} mismatched requested peer ${session.peerId}", isMalformedOrOversized = true)
            }
            val parsed = ChainStatusExchangeMessage.fromJson(rawPair.second, maxBytes = config.maxResponsePayloadBytes)
                ?: return SyncTransportCallResult.Failure("Malformed or oversized CHAIN_STATUS_RESPONSE", isMalformedOrOversized = true)
            return SyncTransportCallResult.Success(parsed, latency)
        } finally {
            pendingStatusResponses.remove(request.requestId)
        }
    }

    override suspend fun requestBlockHeaders(
        session: PeerSession,
        request: BlockHeadersRequest,
        timeoutMs: Long
    ): SyncTransportCallResult<BlockHeadersResponse> {
        if (!session.isTrusted) {
            return SyncTransportCallResult.Failure("Peer session is not authenticated", isDisconnected = true)
        }
        val deferred = CompletableDeferred<Pair<String, String>>()
        pendingHeaderResponses[request.requestId] = deferred
        val started = System.currentTimeMillis()
        try {
            val sendRes = sendSyncMessageToSession(session.sessionId, P2pMessageType.BLOCK_HEADERS_REQUEST, request.toJson())
            if (sendRes.isFailure) {
                return SyncTransportCallResult.Failure(
                    sendRes.exceptionOrNull()?.message ?: "Failed sending BLOCK_HEADERS_REQUEST",
                    isDisconnected = true
                )
            }
            val rawPair = withTimeoutOrNull(timeoutMs) { deferred.await() }
                ?: return SyncTransportCallResult.Failure("Block headers request timed out", isTimeout = true)
            val latency = (System.currentTimeMillis() - started).coerceAtLeast(1L)
            if (rawPair.first != session.peerId) {
                return SyncTransportCallResult.Failure("Response sender mismatch", isMalformedOrOversized = true)
            }
            val parsed = BlockHeadersResponse.fromJson(rawPair.second, maxBytes = config.maxResponsePayloadBytes)
                ?: return SyncTransportCallResult.Failure("Malformed or oversized BLOCK_HEADERS_RESPONSE", isMalformedOrOversized = true)
            return SyncTransportCallResult.Success(parsed, latency)
        } finally {
            pendingHeaderResponses.remove(request.requestId)
        }
    }

    override suspend fun requestBlocks(
        session: PeerSession,
        request: BlocksRequest,
        timeoutMs: Long
    ): SyncTransportCallResult<BlocksResponse> {
        if (!session.isTrusted) {
            return SyncTransportCallResult.Failure("Peer session is not authenticated", isDisconnected = true)
        }
        val deferred = CompletableDeferred<Pair<String, String>>()
        pendingBlockResponses[request.requestId] = deferred
        val started = System.currentTimeMillis()
        try {
            val sendRes = sendSyncMessageToSession(session.sessionId, P2pMessageType.BLOCKS_REQUEST, request.toJson())
            if (sendRes.isFailure) {
                return SyncTransportCallResult.Failure(
                    sendRes.exceptionOrNull()?.message ?: "Failed sending BLOCKS_REQUEST",
                    isDisconnected = true
                )
            }
            val rawPair = withTimeoutOrNull(timeoutMs) { deferred.await() }
                ?: return SyncTransportCallResult.Failure("Blocks download request timed out", isTimeout = true)
            val latency = (System.currentTimeMillis() - started).coerceAtLeast(1L)
            if (rawPair.first != session.peerId) {
                return SyncTransportCallResult.Failure("Response sender mismatch", isMalformedOrOversized = true)
            }
            val parsed = BlocksResponse.fromJson(rawPair.second, maxBytes = config.maxResponsePayloadBytes)
                ?: return SyncTransportCallResult.Failure("Malformed or oversized BLOCKS_RESPONSE", isMalformedOrOversized = true)
            return SyncTransportCallResult.Success(parsed, latency)
        } finally {
            pendingBlockResponses.remove(request.requestId)
        }
    }

    suspend fun handleIncomingP2pSyncMessage(session: PeerSession, message: P2pMessage) {
        if (!session.isTrusted) {
            peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 20)
            return
        }
        val payloadSize = message.payload.toByteArray(Charsets.UTF_8).size
        if (payloadSize > config.maxResponsePayloadBytes) {
            peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 25)
            return
        }

        val handler = requestHandler
        when (message.messageType) {
            P2pMessageType.CHAIN_STATUS_REQUEST -> {
                val req = ChainStatusRequest.fromJson(message.payload)
                if (req == null) {
                    peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 15)
                    return
                }
                if (handler != null) {
                    val resp = handler.handleChainStatusRequest(req)
                    sendSyncMessageToSession(session.sessionId, P2pMessageType.CHAIN_STATUS_RESPONSE, resp.toJson())
                }
            }
            P2pMessageType.CHAIN_STATUS_RESPONSE -> {
                val reqId = extractRequestId(message.payload) ?: return
                pendingStatusResponses[reqId]?.complete(session.peerId to message.payload)
            }
            P2pMessageType.BLOCK_HEADERS_REQUEST -> {
                val req = BlockHeadersRequest.fromJson(message.payload)
                if (req == null) {
                    peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 15)
                    return
                }
                if (handler != null) {
                    val resp = handler.handleBlockHeadersRequest(req)
                    sendSyncMessageToSession(session.sessionId, P2pMessageType.BLOCK_HEADERS_RESPONSE, resp.toJson())
                }
            }
            P2pMessageType.BLOCK_HEADERS_RESPONSE -> {
                val reqId = extractRequestId(message.payload) ?: return
                pendingHeaderResponses[reqId]?.complete(session.peerId to message.payload)
            }
            P2pMessageType.BLOCKS_REQUEST -> {
                val req = BlocksRequest.fromJson(message.payload)
                if (req == null) {
                    peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 15)
                    return
                }
                if (handler != null) {
                    val resp = handler.handleBlocksRequest(req)
                    sendSyncMessageToSession(session.sessionId, P2pMessageType.BLOCKS_RESPONSE, resp.toJson())
                }
            }
            P2pMessageType.BLOCKS_RESPONSE -> {
                val reqId = extractRequestId(message.payload) ?: return
                pendingBlockResponses[reqId]?.complete(session.peerId to message.payload)
            }
            else -> Unit
        }
    }

    private fun extractRequestId(raw: String): String? {
        return try {
            val j = org.json.JSONObject(raw)
            j.optString("request_id", "").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }
}
