package com.example.sync

import android.content.Context
import com.example.blockchain.manager.BlockchainManager
import com.example.consensus.ConsensusCoordinator
import com.example.data.DeviceTelemetry
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.reliable.DeliveryResult
import com.example.p2p.session.PeerSession
import com.example.sync.config.SyncConfig
import com.example.sync.engine.BlockchainSyncManager
import com.example.sync.engine.SyncCycleOutcome
import com.example.sync.model.SyncUiState
import com.example.sync.p2p.P2pSyncTransportBridge
import com.example.sync.policy.MobileSyncPolicy
import com.example.sync.storage.RoomSyncStorage
import com.example.sync.storage.SyncStorage
import com.example.transaction.TransactionEngineManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import java.io.Closeable

/**
 * Central Stage 12 Blockchain Synchronization Coordinator.
 *
 * Bridges Stage 5/6/7 authenticated P2P transport, Stage 8 Blockchain Core,
 * Stage 9 Transaction Mempool, Stage 10 BFT Consensus, and mobile resource policies.
 */
class BlockchainSyncCoordinator(
    val config: SyncConfig,
    val storage: SyncStorage,
    val blockchainManager: BlockchainManager,
    val txEngineManager: TransactionEngineManager,
    val consensusCoordinator: ConsensusCoordinator,
    val peerRegistry: DistributedPeerRegistry? = consensusCoordinator.peerRegistry,
    val p2pBridge: P2pSyncTransportBridge,
    ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    constructor(
        context: Context,
        blockchainManager: BlockchainManager,
        txEngineManager: TransactionEngineManager,
        consensusCoordinator: ConsensusCoordinator,
        peerRegistry: DistributedPeerRegistry? = consensusCoordinator.peerRegistry,
        config: SyncConfig = SyncConfig.fromBlockchainConfig(blockchainManager.config),
        inMemoryStorage: Boolean = false
    ) : this(
        config = config,
        storage = RoomSyncStorage(
            context = context,
            dbName = config.databaseName,
            inMemory = inMemoryStorage
        ),
        blockchainManager = blockchainManager,
        txEngineManager = txEngineManager,
        consensusCoordinator = consensusCoordinator,
        peerRegistry = peerRegistry,
        p2pBridge = P2pSyncTransportBridge(
            config = config,
            authenticatedSessionsProvider = { emptyList() },
            sendSyncMessageToSession = { _, _, _ -> Result.failure(IllegalStateException("P2P transport not yet bound")) },
            peerRegistry = peerRegistry
        )
    )

    val manager = BlockchainSyncManager(
        config = config,
        syncStorage = storage,
        blockchainManager = blockchainManager,
        consensusCoordinator = consensusCoordinator,
        txMempool = txEngineManager.mempool,
        transport = p2pBridge,
        peerRegistry = peerRegistry,
        ioDispatcher = ioDispatcher
    )

    val state: StateFlow<SyncUiState> = manager.uiState

    init {
        p2pBridge.requestHandler = manager
    }

    /**
     * Binds live authenticated P2P session access and reliable frame sending.
     */
    fun bindP2pTransport(
        authenticatedSessionsProvider: () -> List<PeerSession>,
        sendSyncMessageToSession: suspend (sessionId: String, type: P2pMessageType, payloadJson: String) -> Result<DeliveryResult>
    ) {
        p2pBridge.authenticatedSessionsProvider = authenticatedSessionsProvider
        p2pBridge.sendSyncMessageToSession = sendSyncMessageToSession
    }

    suspend fun handleIncomingSyncMessage(session: PeerSession, message: P2pMessage) {
        p2pBridge.handleIncomingP2pSyncMessage(session, message)
    }
    suspend fun initialize(
        context: Context? = null,
        telemetry: DeviceTelemetry = DeviceTelemetry()
    ): SyncUiState {
        val thermalSevere = context?.let { MobileSyncPolicy.isDeviceThermallyThrottled(it) } ?: false
        return manager.initialize(telemetry = telemetry, thermalSevere = thermalSevere)
    }

    suspend fun synchronizeNow(
        context: Context? = null,
        telemetry: DeviceTelemetry = DeviceTelemetry()
    ): SyncCycleOutcome {
        val thermalSevere = context?.let { MobileSyncPolicy.isDeviceThermallyThrottled(it) } ?: false
        return manager.synchronize(telemetry = telemetry, thermalSevere = thermalSevere)
    }

    fun pauseSync() = manager.pauseSync()

    fun resumeSync() = manager.resumeSync()

    suspend fun clearConflictsAndResetState() = manager.clearConflictsAndResetState()

    fun refreshMobilePolicy(
        context: Context? = null,
        telemetry: DeviceTelemetry = DeviceTelemetry()
    ): Boolean {
        val thermalSevere = context?.let { MobileSyncPolicy.isDeviceThermallyThrottled(it) } ?: false
        return manager.evaluateMobilePolicy(telemetry, thermalSevere)
    }

    override fun close() {
        manager.close()
    }
}

object NmdBlockchainSyncRegistry {
    @Volatile
    private var sharedInstance: BlockchainSyncCoordinator? = null

    fun getOrCreate(
        context: Context,
        blockchainManager: BlockchainManager,
        txEngineManager: TransactionEngineManager,
        consensusCoordinator: ConsensusCoordinator,
        peerRegistry: DistributedPeerRegistry? = consensusCoordinator.peerRegistry
    ): BlockchainSyncCoordinator {
        val existing = sharedInstance
        if (existing != null) return existing
        return synchronized(this) {
            sharedInstance ?: BlockchainSyncCoordinator(
                context = context.applicationContext,
                blockchainManager = blockchainManager,
                txEngineManager = txEngineManager,
                consensusCoordinator = consensusCoordinator,
                peerRegistry = peerRegistry
            ).also {
                sharedInstance = it
            }
        }
    }

    fun resetForTests() {
        synchronized(this) {
            sharedInstance?.close()
            sharedInstance = null
        }
    }
}
