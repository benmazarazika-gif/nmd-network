package com.example.sync.validation

import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.model.Block
import com.example.blockchain.validation.BlockValidationResult
import com.example.blockchain.validation.BlockValidator
import com.example.blockchain.validation.ValidationErrorCode
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ValidatorSetSnapshot
import com.example.consensus.validation.ConsensusValidationOutcome
import com.example.consensus.validation.ConsensusValidators
import com.example.sync.model.SyncBlockBundle
import com.example.sync.model.SyncBlockHeaderEntry
import com.example.sync.model.SyncConflictRecord
import com.example.sync.model.SyncErrorCode
import com.example.transaction.model.NmdTransaction
import com.example.transaction.validation.TransactionValidator
import com.example.transaction.validation.TxValidationErrorCode
import com.example.transaction.validation.TxValidationResult
import java.util.UUID

sealed class HeaderBatchValidationResult {
    data object Valid : HeaderBatchValidationResult()
    data class Invalid(
        val errorCode: SyncErrorCode,
        val reason: String,
        val conflictRecord: SyncConflictRecord? = null
    ) : HeaderBatchValidationResult()
}

sealed class SyncBundleVerificationResult {
    data object Verified : SyncBundleVerificationResult()
    data class Rejected(
        val errorCode: SyncErrorCode,
        val reason: String,
        val penalizePeer: Boolean = true,
        val conflictRecord: SyncConflictRecord? = null
    ) : SyncBundleVerificationResult()
}

/**
 * Independent Zero-Trust Validator for Stage 12 Blockchain Synchronization.
 *
 * Verifies every received header batch and full [SyncBlockBundle]:
 * 1. Deterministic JSON roundtrip consistency
 * 2. Local finalized block/certificate conflict detection (no silent chain reorg)
 * 3. Stage 8 [BlockValidator] (hash, previousHash, height, timestamp, Merkle root, limits)
 * 4. Stage 9 [TransactionValidator] + Ed25519 signature & reference consistency for all transactions
 * 5. Stage 10 [ConsensusValidators.validateCommitCertificate] (>2/3 BFT quorum + Ed25519 signatures)
 */
class SyncBlockVerifier(
    private val blockchainConfig: BlockchainConfig,
    private val blockHasher: BlockHasher = BlockHasher(),
    private val blockValidator: BlockValidator = BlockValidator(blockchainConfig, blockHasher),
    private val transactionValidator: TransactionValidator = TransactionValidator(blockchainConfig),
    private val consensusValidators: ConsensusValidators
) {

    fun validateHeadersBatch(
        headers: List<SyncBlockHeaderEntry>,
        expectedStartHeight: Long,
        expectedPreviousHash: String,
        maxBatchSize: Int,
        reportingPeerId: String
    ): HeaderBatchValidationResult {
        if (headers.isEmpty()) {
            return HeaderBatchValidationResult.Invalid(
                SyncErrorCode.INVALID_RESPONSE_ORDER,
                "Peer returned empty header batch"
            )
        }
        if (headers.size > maxBatchSize) {
            return HeaderBatchValidationResult.Invalid(
                SyncErrorCode.PAYLOAD_TOO_LARGE,
                "Header count ${headers.size} exceeds maxHeaderBatchSize=$maxBatchSize"
            )
        }

        var nextHeight = expectedStartHeight
        var prevHash = expectedPreviousHash.lowercase()

        for ((index, h) in headers.withIndex()) {
            if (h.chainId != blockchainConfig.chainId) {
                return HeaderBatchValidationResult.Invalid(
                    SyncErrorCode.INCOMPATIBLE_CHAIN_ID,
                    "Header at h=${h.height} has wrong chainId=${h.chainId}"
                )
            }
            if (h.protocolVersion != blockchainConfig.parameters.protocolVersion) {
                return HeaderBatchValidationResult.Invalid(
                    SyncErrorCode.INCOMPATIBLE_PROTOCOL_VERSION,
                    "Header at h=${h.height} has unsupported protocolVersion=${h.protocolVersion}"
                )
            }
            if (h.height != nextHeight) {
                return HeaderBatchValidationResult.Invalid(
                    SyncErrorCode.INVALID_RESPONSE_ORDER,
                    "Out-of-order header at idx=$index: expected h=$nextHeight, got ${h.height}"
                )
            }
            if (!BlockHasher.isValidSha256Hex(h.blockHash) || !BlockHasher.isValidSha256Hex(h.previousHash)) {
                return HeaderBatchValidationResult.Invalid(
                    SyncErrorCode.INVALID_BLOCK_HASH,
                    "Malformed SHA-256 hex in header h=${h.height}"
                )
            }
            if (!h.previousHash.equals(prevHash, ignoreCase = true)) {
                val conflict = if (index == 0 && expectedStartHeight > 1L) {
                    SyncConflictRecord(
                        conflictId = "conflict_${UUID.randomUUID()}",
                        chainId = blockchainConfig.chainId,
                        conflictHeight = expectedStartHeight - 1L,
                        localBlockHash = prevHash,
                        conflictingBlockHash = h.previousHash.lowercase(),
                        reportingPeerId = reportingPeerId,
                        reason = "Header at h=${h.height} parent hash ${h.previousHash.take(12)}... does not link to finalized local block ${prevHash.take(12)}..."
                    )
                } else null
                return HeaderBatchValidationResult.Invalid(
                    errorCode = if (conflict != null) SyncErrorCode.CONFLICTING_FINALIZED_HISTORY else SyncErrorCode.INVALID_PREVIOUS_HASH,
                    reason = "Header previousHash mismatch at h=${h.height}",
                    conflictRecord = conflict
                )
            }
            nextHeight++
            prevHash = h.blockHash.lowercase()
        }

        return HeaderBatchValidationResult.Valid
    }

    fun verifyBlockBundle(
        bundle: SyncBlockBundle,
        parentBlock: Block,
        validatorSnapshot: ValidatorSetSnapshot,
        existingFinalizedBlockAtHeight: Block? = null,
        existingCommitCertAtHeight: CommitCertificate? = null,
        reportingPeerId: String,
        nowMs: Long = System.currentTimeMillis()
    ): SyncBundleVerificationResult {
        val block = bundle.block
        val cert = bundle.commitCertificate

        // 1. Deterministic serialization roundtrip check
        val reDecoded = Block.fromStorageJson(block.toStorageJson())
        if (reDecoded == null || reDecoded != block) {
            return SyncBundleVerificationResult.Rejected(
                errorCode = SyncErrorCode.MALFORMED_PAYLOAD,
                reason = "Block at h=${block.height} failed deterministic serialization roundtrip"
            )
        }

        // 2. BFT Finality Conflict Check: finalized local blocks are NEVER reorganized
        if (existingFinalizedBlockAtHeight != null) {
            if (!existingFinalizedBlockAtHeight.hash.equals(block.hash, ignoreCase = true)) {
                val certCheck = consensusValidators.validateCommitCertificate(
                    certificate = cert,
                    snapshot = validatorSnapshot,
                    expectedPreviousHash = parentBlock.hash
                )
                val conflict = SyncConflictRecord(
                    conflictId = "conflict_${UUID.randomUUID()}",
                    chainId = blockchainConfig.chainId,
                    conflictHeight = block.height,
                    localBlockHash = existingFinalizedBlockAtHeight.hash.lowercase(),
                    conflictingBlockHash = block.hash.lowercase(),
                    reportingPeerId = reportingPeerId,
                    reason = "Conflicting block at finalized height ${block.height}: local=${existingFinalizedBlockAtHeight.displayHash}, remote=${block.displayHash}",
                    detectedAtMs = nowMs,
                    hasValidConflictingCertificate = certCheck is ConsensusValidationOutcome.Valid
                )
                return SyncBundleVerificationResult.Rejected(
                    errorCode = SyncErrorCode.CONFLICTING_FINALIZED_HISTORY,
                    reason = conflict.reason,
                    penalizePeer = certCheck !is ConsensusValidationOutcome.Valid,
                    conflictRecord = conflict
                )
            }
            return SyncBundleVerificationResult.Rejected(
                errorCode = SyncErrorCode.DUPLICATE_OR_UNREQUESTED_DATA,
                reason = "Block at height ${block.height} already finalized locally",
                penalizePeer = false
            )
        }

        if (existingCommitCertAtHeight != null &&
            !existingCommitCertAtHeight.blockHash.equals(block.hash, ignoreCase = true)
        ) {
            val certCheck = consensusValidators.validateCommitCertificate(
                certificate = cert,
                snapshot = validatorSnapshot,
                expectedPreviousHash = parentBlock.hash
            )
            val conflict = SyncConflictRecord(
                conflictId = "conflict_${UUID.randomUUID()}",
                chainId = blockchainConfig.chainId,
                conflictHeight = block.height,
                localBlockHash = existingCommitCertAtHeight.blockHash.lowercase(),
                conflictingBlockHash = block.hash.lowercase(),
                reportingPeerId = reportingPeerId,
                reason = "Conflicting CommitCertificate at height ${block.height}",
                detectedAtMs = nowMs,
                hasValidConflictingCertificate = certCheck is ConsensusValidationOutcome.Valid
            )
            return SyncBundleVerificationResult.Rejected(
                errorCode = SyncErrorCode.CONFLICTING_FINALIZED_HISTORY,
                reason = conflict.reason,
                penalizePeer = certCheck !is ConsensusValidationOutcome.Valid,
                conflictRecord = conflict
            )
        }

        // 3. Stage 8 Structural & Cryptographic Block Validation (height, previousHash, hash, merkleRoot, sizes)
        val structural = blockValidator.validateBlock(block, parentBlock, nowMs)
        if (structural is BlockValidationResult.Invalid) {
            val syncCode = when (structural.code) {
                ValidationErrorCode.INVALID_HASH -> SyncErrorCode.INVALID_BLOCK_HASH
                ValidationErrorCode.INVALID_PREVIOUS_HASH -> SyncErrorCode.INVALID_PREVIOUS_HASH
                ValidationErrorCode.INVALID_MERKLE_ROOT -> SyncErrorCode.INVALID_MERKLE_ROOT
                ValidationErrorCode.INVALID_HEIGHT -> SyncErrorCode.INVALID_BLOCK_HEIGHT
                ValidationErrorCode.INVALID_CHAIN_ID -> SyncErrorCode.INCOMPATIBLE_CHAIN_ID
                ValidationErrorCode.UNSUPPORTED_PROTOCOL_VERSION -> SyncErrorCode.INCOMPATIBLE_PROTOCOL_VERSION
                ValidationErrorCode.BLOCK_TOO_LARGE -> SyncErrorCode.PAYLOAD_TOO_LARGE
                else -> SyncErrorCode.MALFORMED_PAYLOAD
            }
            return SyncBundleVerificationResult.Rejected(syncCode, structural.reason)
        }

        // 4. Full Transaction Inclusion & Signature Verification (Zero-Trust: verify all transactions referenced in body)
        val refs = block.body.transactionRefs
        val txs = bundle.transactions
        if (txs.size != refs.size) {
            return SyncBundleVerificationResult.Rejected(
                errorCode = SyncErrorCode.INVALID_TRANSACTION,
                reason = "Transaction payload count (${txs.size}) does not match block body refs (${refs.size}) at h=${block.height}"
            )
        }
        val seenTxIds = HashSet<String>(txs.size)
        for (i in refs.indices) {
            val ref = refs[i]
            val tx = txs[i]
            val normTxId = tx.txId.lowercase()
            if (!seenTxIds.add(normTxId)) {
                return SyncBundleVerificationResult.Rejected(
                    errorCode = SyncErrorCode.INVALID_TRANSACTION,
                    reason = "Duplicate transaction $normTxId inside block h=${block.height}"
                )
            }
            if (!ref.txHash.equals(normTxId, ignoreCase = true)) {
                return SyncBundleVerificationResult.Rejected(
                    errorCode = SyncErrorCode.INVALID_MERKLE_ROOT,
                    reason = "Transaction at index $i txId=$normTxId does not match block ref ${ref.txHash}"
                )
            }
            if (tx.timestamp > block.timestamp + transactionValidator.policy.maxFutureDriftMs) {
                return SyncBundleVerificationResult.Rejected(
                    errorCode = SyncErrorCode.INVALID_TRANSACTION,
                    reason = "Transaction $normTxId timestamp exceeds block timestamp"
                )
            }
            // Validate stateless structure, chain binding, address<->pubkey binding, canonical txId hash, fee, and Ed25519 signature.
            // Evaluate age relative to block timestamp (historical finalized blocks synced later remain valid),
            // while still checking against future drift using real current clock.
            val evalClockMs = maxOf(block.timestamp, tx.timestamp)
            val txValidation = transactionValidator.validateStateless(tx, nowMs = evalClockMs)
            if (txValidation is TxValidationResult.Invalid) {
                return SyncBundleVerificationResult.Rejected(
                    errorCode = SyncErrorCode.INVALID_TRANSACTION,
                    reason = "Transaction $normTxId invalid (${txValidation.code.name}): ${txValidation.reason}"
                )
            }
            if (tx.timestamp > nowMs + transactionValidator.policy.maxFutureDriftMs) {
                return SyncBundleVerificationResult.Rejected(
                    errorCode = SyncErrorCode.INVALID_TRANSACTION,
                    reason = "Transaction $normTxId timestamp in the future"
                )
            }
        }

        // 5. Stage 10 BFT CommitCertificate Verification (Quorum >= 2/3, active validators, Ed25519 signatures)
        if (cert.blockHeight != block.height) {
            return SyncBundleVerificationResult.Rejected(
                errorCode = SyncErrorCode.INVALID_COMMIT_CERTIFICATE,
                reason = "CommitCertificate height ${cert.blockHeight} != block height ${block.height}"
            )
        }
        val unsignedHeaderHash = blockHasher.computeHeaderHash(block.header.copy(consensusMetadata = ""))
        val hashMatches = cert.blockHash.equals(block.hash, ignoreCase = true) ||
            cert.blockHash.equals(unsignedHeaderHash, ignoreCase = true)
        if (!hashMatches) {
            return SyncBundleVerificationResult.Rejected(
                errorCode = SyncErrorCode.INVALID_COMMIT_CERTIFICATE,
                reason = "CommitCertificate blockHash does not bind to block ${block.displayHash}"
            )
        }

        val certOutcome = consensusValidators.validateCommitCertificate(
            certificate = cert,
            snapshot = validatorSnapshot,
            expectedPreviousHash = parentBlock.hash
        )
        if (certOutcome is ConsensusValidationOutcome.Invalid) {
            return SyncBundleVerificationResult.Rejected(
                errorCode = SyncErrorCode.INVALID_COMMIT_CERTIFICATE,
                reason = "CommitCertificate failed Stage 10 verification (${certOutcome.code.name}): ${certOutcome.reason}"
            )
        }

        return SyncBundleVerificationResult.Verified
    }
}
