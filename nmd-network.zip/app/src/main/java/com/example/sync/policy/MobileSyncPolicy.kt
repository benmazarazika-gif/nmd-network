package com.example.sync.policy

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.example.data.DeviceTelemetry
import com.example.sync.config.SyncConfig

data class MobileSyncDecision(
    val allowSync: Boolean,
    val reason: String? = null
)

/**
 * Stage 12 Mobile-Friendly Sync Safeguard.
 *
 * Evaluates Android battery, connectivity, memory, and thermal throttling so synchronization
 * behaves politely on smartphones without ever altering Stage 10/11 BFT finality or validation rules.
 */
object MobileSyncPolicy {

    fun isDeviceThermallyThrottled(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
            pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
        } catch (_: Throwable) {
            false
        }
    }

    fun evaluate(
        telemetry: DeviceTelemetry,
        config: SyncConfig,
        thermalSevere: Boolean = false
    ): MobileSyncDecision {
        if (config.respectThermalGuard && thermalSevere) {
            return MobileSyncDecision(
                allowSync = false,
                reason = "Thermal throttling active (SEVERE+) — sync paused"
            )
        }

        if (config.respectNetworkGuard &&
            (telemetry.networkType.equals("Offline", ignoreCase = true) ||
                telemetry.networkType.equals("None", ignoreCase = true))
        ) {
            return MobileSyncDecision(
                allowSync = false,
                reason = "Device network offline — waiting for connectivity"
            )
        }

        if (config.respectBatteryGuard &&
            telemetry.batteryPercent != null &&
            telemetry.isCharging != true &&
            telemetry.batteryPercent <= config.batteryLowPauseThresholdPercent
        ) {
            return MobileSyncDecision(
                allowSync = false,
                reason = "Low battery (${telemetry.batteryPercent}% <= ${config.batteryLowPauseThresholdPercent}%, not charging) — sync paused"
            )
        }

        val availRam = telemetry.availableRamMb
        if (telemetry.isLowRam || (availRam != null && availRam < config.minAvailableRamMb)) {
            return MobileSyncDecision(
                allowSync = false,
                reason = "Low available RAM (${availRam ?: 0}MB < ${config.minAvailableRamMb}MB) — sync paused"
            )
        }

        return MobileSyncDecision(allowSync = true, reason = null)
    }
}
