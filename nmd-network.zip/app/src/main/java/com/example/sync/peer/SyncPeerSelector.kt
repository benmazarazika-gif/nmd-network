package com.example.sync.peer

import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.session.PeerSession
import com.example.sync.config.SyncConfig
import com.example.sync.model.ChainStatusExchangeMessage
import com.example.sync.model.SyncErrorCode
import com.example.sync.model.SyncPeerState
import java.util.concurrent.ConcurrentHashMap

data class PeerCompatibilityCheck(
    val isCompatible: Boolean,
    val errorCode: SyncErrorCode = SyncErrorCode.NONE,
    val reason: String? = null
)

/**
 * Manages authenticated peer compatibility validation, reliability scoring, cooldown backoff,
 * and automatic peer switching for Stage 12 synchronization.
 */
class SyncPeerSelector(
    private val config: SyncConfig,
    private val peerRegistry: DistributedPeerRegistry? = null
) {
    private val peerStates = ConcurrentHashMap<String, SyncPeerState>()

    fun evaluateCompatibility(
        localChainId: String,
        localGenesisHash: String,
        localProtocolVersion: Int,
        peerStatus: ChainStatusExchangeMessage
    ): PeerCompatibilityCheck {
        if (peerStatus.chainId != localChainId) {
            return PeerCompatibilityCheck(
                isCompatible = false,
                errorCode = SyncErrorCode.INCOMPATIBLE_CHAIN_ID,
                reason = "Chain ID mismatch: peer=${peerStatus.chainId}, local=$localChainId"
            )
        }
        if (localGenesisHash.isNotBlank() &&
            !peerStatus.genesisHash.equals(localGenesisHash, ignoreCase = true)
        ) {
            return PeerCompatibilityCheck(
                isCompatible = false,
                errorCode = SyncErrorCode.INCOMPATIBLE_GENESIS_HASH,
                reason = "Genesis hash mismatch: peer=${peerStatus.genesisHash.take(12)}..."
            )
        }
        if (peerStatus.protocolVersion != localProtocolVersion) {
            return PeerCompatibilityCheck(
                isCompatible = false,
                errorCode = SyncErrorCode.INCOMPATIBLE_PROTOCOL_VERSION,
                reason = "Protocol version mismatch: peer=${peerStatus.protocolVersion}, local=$localProtocolVersion"
            )
        }
        if (peerStatus.currentHeight < 0L || peerStatus.finalizedHeight < 0L ||
            peerStatus.finalizedHeight > peerStatus.currentHeight
        ) {
            return PeerCompatibilityCheck(
                isCompatible = false,
                errorCode = SyncErrorCode.MALFORMED_PAYLOAD,
                reason = "Malformed peer heights: height=${peerStatus.currentHeight}, finalized=${peerStatus.finalizedHeight}"
            )
        }
        return PeerCompatibilityCheck(isCompatible = true)
    }

    fun recordStatusExchange(
        session: PeerSession,
        localChainId: String,
        localGenesisHash: String,
        localProtocolVersion: Int,
        status: ChainStatusExchangeMessage,
        observedLatencyMs: Long,
        nowMs: Long = System.currentTimeMillis()
    ): SyncPeerState {
        val compat = evaluateCompatibility(localChainId, localGenesisHash, localProtocolVersion, status)
        val existing = peerStates[session.peerId]
        val registryRep = peerRegistry?.getPeer(session.peerId)?.reputationScore
        val baseReliability = existing?.reliabilityScore ?: registryRep ?: 60

        val updated = SyncPeerState(
            peerId = session.peerId,
            sessionId = session.sessionId,
            isCompatible = compat.isCompatible,
            incompatibilityReason = compat.reason,
            reportedStatus = status,
            reportedHeight = status.currentHeight,
            reportedFinalizedHeight = status.finalizedHeight,
            highestVerifiedHeightFromPeer = existing?.highestVerifiedHeightFromPeer ?: -1L,
            reliabilityScore = if (compat.isCompatible) baseReliability else (baseReliability - 25).coerceAtLeast(0),
            latencyMs = if (observedLatencyMs > 0) observedLatencyMs else session.lastRoundTripLatencyMs,
            consecutiveFailures = if (compat.isCompatible) existing?.consecutiveFailures ?: 0 else (existing?.consecutiveFailures ?: 0) + 1,
            cooldownUntilMs = existing?.cooldownUntilMs ?: 0L,
            lastUpdatedMs = nowMs
        )
        peerStates[session.peerId] = updated
        if (!compat.isCompatible) {
            peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 15)
        }
        return updated
    }

    fun recordVerifiedProgressFromPeer(
        peerId: String,
        verifiedHeight: Long,
        latencyMs: Long = 0L,
        nowMs: Long = System.currentTimeMillis()
    ) {
        val current = peerStates[peerId] ?: return
        peerStates[peerId] = current.copy(
            highestVerifiedHeightFromPeer = maxOf(current.highestVerifiedHeightFromPeer, verifiedHeight),
            reliabilityScore = (current.reliabilityScore + 5).coerceAtMost(100),
            latencyMs = if (latencyMs > 0L) latencyMs else current.latencyMs,
            consecutiveFailures = 0,
            cooldownUntilMs = 0L,
            lastUpdatedMs = nowMs
        )
    }

    fun recordPeerFailure(
        peerId: String,
        penalizeInvalidBehavior: Boolean,
        nowMs: Long = System.currentTimeMillis()
    ) {
        val current = peerStates[peerId]
        val newFailures = (current?.consecutiveFailures ?: 0) + 1
        val penalty = if (penalizeInvalidBehavior) config.invalidBehaviorPenalty else 10
        val newScore = ((current?.reliabilityScore ?: 60) - penalty).coerceAtLeast(0)
        val cooldownUntil = if (penalizeInvalidBehavior || newFailures >= config.maxPeerFailuresBeforeCooldown) {
            nowMs + config.peerCooldownMs
        } else {
            current?.cooldownUntilMs ?: 0L
        }
        if (current != null) {
            peerStates[peerId] = current.copy(
                reliabilityScore = newScore,
                consecutiveFailures = newFailures,
                cooldownUntilMs = cooldownUntil,
                lastUpdatedMs = nowMs
            )
        }
        if (penalizeInvalidBehavior) {
            peerRegistry?.recordInvalidBehavior(peerId, penalty = config.invalidBehaviorPenalty)
        }
    }

    /**
     * Selects the best authenticated, compatible, non-cooldown peer that claims blocks strictly ahead of [localHeight].
     */
    fun selectBestPeer(
        activeSessions: List<PeerSession>,
        localHeight: Long,
        excludedPeerIds: Set<String> = emptySet(),
        nowMs: Long = System.currentTimeMillis()
    ): SyncPeerState? {
        val activeSessionByPeer = activeSessions
            .filter { it.isTrusted }
            .associateBy { it.peerId }

        return peerStates.values
            .asSequence()
            .mapNotNull { state ->
                val liveSession = activeSessionByPeer[state.peerId] ?: return@mapNotNull null
                state.copy(sessionId = liveSession.sessionId)
            }
            .filter { state ->
                state.isCompatible &&
                    state.peerId !in excludedPeerIds &&
                    !state.isInCooldown(nowMs) &&
                    state.reportedHeight > localHeight &&
                    state.reportedFinalizedHeight > localHeight
            }
            .sortedWith(
                compareByDescending<SyncPeerState> { it.reliabilityScore }
                    .thenBy { if (it.latencyMs <= 0L) Long.MAX_VALUE else it.latencyMs }
                    .thenByDescending { it.reportedFinalizedHeight }
                    .thenBy { it.peerId }
            )
            .firstOrNull()
    }

    fun pruneDisconnectedPeers(connectedPeerIds: Set<String>) {
        peerStates.keys.removeIf { !connectedPeerIds.contains(it) }
    }

    fun getAllPeerStates(): List<SyncPeerState> {
        return peerStates.values.sortedBy { it.peerId }
    }

    fun clearCooldowns() {
        val keys = peerStates.keys.toList()
        for (k in keys) {
            peerStates[k]?.let { peerStates[k] = it.copy(cooldownUntilMs = 0L, consecutiveFailures = 0) }
        }
    }
}
