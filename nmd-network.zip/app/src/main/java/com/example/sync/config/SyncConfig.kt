package com.example.sync.config

import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.config.NetworkEnvironment

/**
 * Configuration and safety limits for Stage 12 Blockchain Synchronization.
 */
data class SyncConfig(
    val chainId: String = "nmd-local-dev-1",
    val protocolVersion: Int = 1,
    val genesisHash: String = "",
    val networkEnvironment: NetworkEnvironment = NetworkEnvironment.LOCAL_DEV,
    val isDevelopmentMode: Boolean = true,
    val maxHeaderBatchSize: Int = 32,
    val maxBlockBatchSize: Int = 8,
    val maxResponsePayloadBytes: Int = 512 * 1024, // 512 KiB hard wire bound per response
    val requestTimeoutMs: Long = 8_000L,
    val peerCooldownMs: Long = 30_000L,
    val maxPeerFailuresBeforeCooldown: Int = 2,
    val invalidBehaviorPenalty: Int = 35,
    val maxConcurrentDownloads: Int = 1,
    val minAvailableRamMb: Long = 128L,
    val batteryLowPauseThresholdPercent: Int = 15,
    val respectBatteryGuard: Boolean = true,
    val respectNetworkGuard: Boolean = true,
    val respectThermalGuard: Boolean = true,
    val databaseName: String = "nmd_blockchain_sync.db"
) {
    companion object {
        fun fromBlockchainConfig(
            config: BlockchainConfig,
            genesisHash: String = ""
        ): SyncConfig {
            return SyncConfig(
                chainId = config.chainId,
                protocolVersion = config.parameters.protocolVersion,
                genesisHash = genesisHash.lowercase(),
                networkEnvironment = config.networkEnvironment,
                isDevelopmentMode = config.isLocalDevelopmentChain,
                databaseName = BlockchainConfig.databaseNameFor("nmd_blockchain_sync.db", config.chainId)
            )
        }
    }
}
