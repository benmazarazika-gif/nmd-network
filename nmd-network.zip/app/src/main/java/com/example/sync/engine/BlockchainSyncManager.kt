package com.example.sync.engine

import com.example.blockchain.manager.BlockchainManager
import com.example.consensus.ConsensusCoordinator
import com.example.consensus.validation.ConsensusValidationOutcome
import com.example.data.DeviceTelemetry
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.session.PeerSession
import com.example.sync.config.SyncConfig
import com.example.sync.model.BlockHeadersRequest
import com.example.sync.model.BlockHeadersResponse
import com.example.sync.model.BlocksRequest
import com.example.sync.model.BlocksResponse
import com.example.sync.model.ChainStatusExchangeMessage
import com.example.sync.model.ChainStatusRequest
import com.example.sync.model.SyncBlockBundle
import com.example.sync.model.SyncBlockHeaderEntry
import com.example.sync.model.SyncConflictRecord
import com.example.sync.model.SyncErrorCode
import com.example.sync.model.SyncProgressCheckpoint
import com.example.sync.model.SyncProtocolConstants
import com.example.sync.model.SyncStatusState
import com.example.sync.model.SyncUiState
import com.example.sync.p2p.SyncIncomingRequestHandler
import com.example.sync.p2p.SyncPeerTransport
import com.example.sync.p2p.SyncTransportCallResult
import com.example.sync.peer.SyncPeerSelector
import com.example.sync.policy.MobileSyncPolicy
import com.example.sync.storage.SyncStorage
import com.example.sync.validation.HeaderBatchValidationResult
import com.example.sync.validation.SyncBlockVerifier
import com.example.sync.validation.SyncBundleVerificationResult
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.NmdTransaction
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

sealed class SyncCycleOutcome {
    data class Synced(val localHeight: Long, val syncedBlocksCount: Long) : SyncCycleOutcome()
    data class UpToDate(val localHeight: Long) : SyncCycleOutcome()
    data class Paused(val reason: String, val errorCode: SyncErrorCode) : SyncCycleOutcome()
    data class ConflictDetected(val conflict: SyncConflictRecord) : SyncConflictOutcomeResult()
    data class Failed(val errorCode: SyncErrorCode, val reason: String) : SyncCycleOutcome()
    data object AlreadyRunning : SyncCycleOutcome()

    sealed class SyncConflictOutcomeResult : SyncCycleOutcome()
}

/**
 * Modular, Zero-Trust Stage 12 Blockchain Synchronization Engine.
 *
 * Guarantees:
 * - Never blindly trusts peer-reported heights; only advances verified height after cryptographic,
 *   structural, transaction, and >2/3 BFT CommitCertificate validation.
 * - Never reorganizes finalized BFT blocks or deletes local blockchain history on failure.
 * - Detects conflicting finalized histories / conflicting certificates and halts safely as [SyncStatusState.CONFLICT_DETECTED].
 * - Resumes cleanly across app restarts from persistent Room [SyncProgressCheckpoint].
 * - Reconciles verified transactions cleanly into Stage 9 [TransactionMempool].
 */
class BlockchainSyncManager(
    val config: SyncConfig,
    private val syncStorage: SyncStorage,
    private val blockchainManager: BlockchainManager,
    private val consensusCoordinator: ConsensusCoordinator,
    private val txMempool: TransactionMempool,
    private val transport: SyncPeerTransport,
    peerRegistry: DistributedPeerRegistry? = consensusCoordinator.peerRegistry,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : SyncIncomingRequestHandler, Closeable {

    val peerSelector = SyncPeerSelector(config, peerRegistry)

    private val verifier = SyncBlockVerifier(
        blockchainConfig = blockchainManager.config,
        blockHasher = blockchainManager.blockHasher,
        transactionValidator = txMempool.validator,
        consensusValidators = consensusCoordinator.validators
    )

    private val syncExecutionMutex = Mutex()
    private val pauseRequested = AtomicBoolean(false)
    private val syncActiveFlag = AtomicBoolean(false)

    private val _uiState = MutableStateFlow(
        SyncUiState(
            isInitialized = false,
            isDevelopmentMode = config.isDevelopmentMode,
            chainId = config.chainId
        )
    )
    val uiState: StateFlow<SyncUiState> = _uiState.asStateFlow()

    @Volatile
    private var localGenesisHash: String = config.genesisHash.lowercase()

    @Volatile
    private var lastDownloadedCount: Long = 0L

    @Volatile
    private var lastVerifiedCount: Long = 0L

    @Volatile
    private var lastSyncTimestampMs: Long? = null

    @Volatile
    private var mobileResourcePaused: Boolean = false

    @Volatile
    private var mobilePauseReason: String? = null

    /**
     * Restores local chain tip, persisted checkpoint, and any unresolved conflict records cleanly.
     */
    suspend fun initialize(
        telemetry: DeviceTelemetry = DeviceTelemetry(),
        thermalSevere: Boolean = false
    ): SyncUiState = withContext(ioDispatcher) {
        val genesis = blockchainManager.getGenesisBlock()
        if (genesis != null) {
            localGenesisHash = genesis.hash.lowercase()
        }
        val latest = blockchainManager.getLatestBlock()
        val localHeight = latest?.height ?: 0L
        val localHash = latest?.hash?.lowercase() ?: SyncProtocolConstants.ZERO_HASH

        val savedCheckpoint = syncStorage.getCheckpoint(config.chainId)
        val savedConflicts = syncStorage.getConflicts(config.chainId)

        if (savedCheckpoint != null) {
            lastDownloadedCount = savedCheckpoint.downloadedBlocksCount
            lastVerifiedCount = savedCheckpoint.verifiedBlocksCount
            lastSyncTimestampMs = savedCheckpoint.lastSyncTimestampMs
        }

        // Never trust a saved checkpoint claiming higher height than the verified DB tip
        val alignedHeight = minOf(savedCheckpoint?.lastVerifiedHeight ?: localHeight, localHeight)
        if (savedCheckpoint == null || alignedHeight != savedCheckpoint.lastVerifiedHeight) {
            syncStorage.saveCheckpoint(
                SyncProgressCheckpoint(
                    chainId = config.chainId,
                    lastVerifiedHeight = localHeight,
                    lastVerifiedBlockHash = localHash,
                    targetReportedHeight = savedCheckpoint?.targetReportedHeight ?: localHeight,
                    downloadedBlocksCount = lastDownloadedCount,
                    verifiedBlocksCount = lastVerifiedCount,
                    statusState = if (savedConflicts.isNotEmpty()) SyncStatusState.CONFLICT_DETECTED else SyncStatusState.IDLE,
                    lastSyncTimestampMs = lastSyncTimestampMs
                )
            )
        }

        val mobileEval = MobileSyncPolicy.evaluate(telemetry, config, thermalSevere)
        mobileResourcePaused = !mobileEval.allowSync
        mobilePauseReason = mobileEval.reason

        val initialStatus = when {
            savedConflicts.isNotEmpty() -> SyncStatusState.CONFLICT_DETECTED
            pauseRequested.get() || mobileResourcePaused -> SyncStatusState.PAUSED
            else -> SyncStatusState.IDLE
        }

        val state = SyncUiState(
            isInitialized = true,
            isDevelopmentMode = config.isDevelopmentMode,
            chainId = config.chainId,
            syncStatus = initialStatus,
            localHeight = localHeight,
            latestFinalizedHeight = localHeight,
            latestFinalizedBlockHash = localHash,
            highestReportedPeerHeight = maxOf(localHeight, savedCheckpoint?.targetReportedHeight ?: 0L),
            highestVerifiedPeerHeight = maxOf(
                localHeight,
                peerSelector.getAllPeerStates().maxOfOrNull { it.highestVerifiedHeightFromPeer } ?: 0L
            ),
            downloadedBlocksCount = lastDownloadedCount,
            verifiedBlocksCount = lastVerifiedCount,
            remainingBlocksCount = 0L,
            progressFraction = if (initialStatus == SyncStatusState.SYNCED) 1f else 0f,
            compatiblePeersCount = peerSelector.getAllPeerStates().count { it.isCompatible },
            connectedPeersCount = transport.getAuthenticatedSessions().size,
            lastSyncTimestampMs = lastSyncTimestampMs,
            isUserPaused = pauseRequested.get(),
            mobileResourcePaused = mobileResourcePaused,
            mobilePauseReason = mobilePauseReason,
            errorCode = if (savedConflicts.isNotEmpty()) SyncErrorCode.CONFLICTING_FINALIZED_HISTORY else SyncErrorCode.NONE,
            errorMessage = savedConflicts.firstOrNull()?.reason,
            conflictRecords = savedConflicts,
            peerStates = peerSelector.getAllPeerStates()
        )
        _uiState.value = state
        state
    }

    fun pauseSync() {
        pauseRequested.set(true)
        if (_uiState.value.syncStatus != SyncStatusState.CONFLICT_DETECTED) {
            _uiState.value = _uiState.value.copy(
                syncStatus = SyncStatusState.PAUSED,
                isUserPaused = true,
                errorCode = SyncErrorCode.PAUSED_BY_USER,
                errorMessage = "Synchronization paused by user"
            )
        } else {
            _uiState.value = _uiState.value.copy(isUserPaused = true)
        }
    }

    fun resumeSync() {
        pauseRequested.set(false)
        peerSelector.clearCooldowns()
        if (_uiState.value.syncStatus == SyncStatusState.PAUSED) {
            _uiState.value = _uiState.value.copy(
                syncStatus = SyncStatusState.IDLE,
                isUserPaused = false,
                errorCode = SyncErrorCode.NONE,
                errorMessage = null
            )
        } else {
            _uiState.value = _uiState.value.copy(isUserPaused = false)
        }
    }

    suspend fun clearConflictsAndResetState() = withContext(ioDispatcher) {
        syncStorage.clearConflicts(config.chainId)
        val latest = blockchainManager.getLatestBlock()
        _uiState.value = _uiState.value.copy(
            syncStatus = SyncStatusState.IDLE,
            errorCode = SyncErrorCode.NONE,
            errorMessage = null,
            conflictRecords = emptyList(),
            localHeight = latest?.height ?: 0L,
            latestFinalizedHeight = latest?.height ?: 0L,
            latestFinalizedBlockHash = latest?.hash?.lowercase() ?: SyncProtocolConstants.ZERO_HASH
        )
    }

    fun evaluateMobilePolicy(telemetry: DeviceTelemetry, thermalSevere: Boolean = false): Boolean {
        val eval = MobileSyncPolicy.evaluate(telemetry, config, thermalSevere)
        mobileResourcePaused = !eval.allowSync
        mobilePauseReason = eval.reason
        _uiState.value = _uiState.value.copy(
            mobileResourcePaused = mobileResourcePaused,
            mobilePauseReason = mobilePauseReason
        )
        return eval.allowSync
    }

    /**
     * Executes a full bounded, zero-trust synchronization cycle against authenticated peers.
     * Prevents duplicate concurrent executions cleanly.
     */
    suspend fun synchronize(
        telemetry: DeviceTelemetry = DeviceTelemetry(),
        thermalSevere: Boolean = false,
        nowMs: Long = System.currentTimeMillis()
    ): SyncCycleOutcome = withContext(ioDispatcher) {
        if (!syncActiveFlag.compareAndSet(false, true)) {
            return@withContext SyncCycleOutcome.AlreadyRunning
        }

        try {
            return@withContext syncExecutionMutex.withLock {
                if (!_uiState.value.isInitialized) {
                    initialize(telemetry, thermalSevere)
                }

                // 0. Do not auto-sync past unresolved finalized conflicts
                val unresolvedConflicts = syncStorage.getConflicts(config.chainId)
                if (unresolvedConflicts.isNotEmpty()) {
                    val first = unresolvedConflicts.first()
                    publishState(
                        status = SyncStatusState.CONFLICT_DETECTED,
                        errorCode = SyncErrorCode.CONFLICTING_FINALIZED_HISTORY,
                        errorMsg = first.reason,
                        conflicts = unresolvedConflicts
                    )
                    return@withLock SyncCycleOutcome.ConflictDetected(first)
                }

                // 1. Respect pause & mobile resource safeguards
                if (pauseRequested.get()) {
                    publishState(
                        status = SyncStatusState.PAUSED,
                        errorCode = SyncErrorCode.PAUSED_BY_USER,
                        errorMsg = "Synchronization paused by user"
                    )
                    return@withLock SyncCycleOutcome.Paused("Paused by user", SyncErrorCode.PAUSED_BY_USER)
                }

                val mobileEval = MobileSyncPolicy.evaluate(telemetry, config, thermalSevere)
                mobileResourcePaused = !mobileEval.allowSync
                mobilePauseReason = mobileEval.reason
                if (!mobileEval.allowSync) {
                    publishState(
                        status = SyncStatusState.PAUSED,
                        errorCode = SyncErrorCode.MOBILE_RESOURCE_PAUSED,
                        errorMsg = mobileEval.reason
                    )
                    return@withLock SyncCycleOutcome.Paused(mobileEval.reason ?: "Mobile guard active", SyncErrorCode.MOBILE_RESOURCE_PAUSED)
                }

                // 2. Discover & exchange chain status with authenticated peers
                publishState(status = SyncStatusState.DISCOVERING_PEERS, errorCode = SyncErrorCode.NONE, errorMsg = null)
                val sessions = transport.getAuthenticatedSessions()
                peerSelector.pruneDisconnectedPeers(sessions.map { it.peerId }.toSet())

                if (sessions.isEmpty()) {
                    val tip = blockchainManager.getLatestBlock()
                    val h = tip?.height ?: 0L
                    publishState(
                        status = SyncStatusState.IDLE,
                        localHeight = h,
                        latestFinalizedHash = tip?.hash?.lowercase() ?: SyncProtocolConstants.ZERO_HASH,
                        remaining = 0L,
                        progress = 0f,
                        errorCode = SyncErrorCode.NO_ELIGIBLE_PEERS,
                        errorMsg = "No authenticated P2P peers connected"
                    )
                    return@withLock SyncCycleOutcome.Failed(SyncErrorCode.NO_ELIGIBLE_PEERS, "No authenticated peers connected")
                }

                val genesis = blockchainManager.getGenesisBlock()
                if (genesis != null) {
                    localGenesisHash = genesis.hash.lowercase()
                }
                var localTip = blockchainManager.getLatestBlock()
                    ?: run {
                        publishState(status = SyncStatusState.FAILED, errorCode = SyncErrorCode.NOT_INITIALIZED, errorMsg = "Local genesis missing")
                        return@withLock SyncCycleOutcome.Failed(SyncErrorCode.NOT_INITIALIZED, "Local genesis missing")
                    }

                var lastCompatibilityFailure: SyncErrorCode = SyncErrorCode.NONE
                var lastCompatibilityMessage: String? = null

                for (session in sessions) {
                    val req = ChainStatusRequest(
                        requestId = "st_${UUID.randomUUID()}",
                        chainId = config.chainId,
                        genesisHash = localGenesisHash,
                        protocolVersion = config.protocolVersion
                    )
                    when (val callRes = transport.requestChainStatus(session, req, config.requestTimeoutMs)) {
                        is SyncTransportCallResult.Success -> {
                            val state = peerSelector.recordStatusExchange(
                                session = session,
                                localChainId = config.chainId,
                                localGenesisHash = localGenesisHash,
                                localProtocolVersion = config.protocolVersion,
                                status = callRes.value,
                                observedLatencyMs = callRes.latencyMs,
                                nowMs = nowMs
                            )
                            if (!state.isCompatible) {
                                val compat = peerSelector.evaluateCompatibility(config.chainId, localGenesisHash, config.protocolVersion, callRes.value)
                                lastCompatibilityFailure = compat.errorCode
                                lastCompatibilityMessage = compat.reason
                            } else if (state.reportedFinalizedHeight == localTip.height &&
                                localTip.height > 0L &&
                                !callRes.value.finalizedBlockHash.equals(localTip.hash, ignoreCase = true)
                            ) {
                                // Immediate conflict detection at finalized tip height
                                val conflict = SyncConflictRecord(
                                    conflictId = "conflict_${UUID.randomUUID()}",
                                    chainId = config.chainId,
                                    conflictHeight = localTip.height,
                                    localBlockHash = localTip.hash.lowercase(),
                                    conflictingBlockHash = callRes.value.finalizedBlockHash.lowercase(),
                                    reportingPeerId = session.peerId,
                                    reason = "Peer ${session.peerId} reports conflicting finalized block at height ${localTip.height}",
                                    detectedAtMs = nowMs,
                                    hasValidConflictingCertificate = false
                                )
                                recordConflictAndPersistLocked(conflict, localTip)
                                return@withLock SyncCycleOutcome.ConflictDetected(conflict)
                            }
                        }
                        is SyncTransportCallResult.Failure -> {
                            peerSelector.recordPeerFailure(
                                peerId = session.peerId,
                                penalizeInvalidBehavior = callRes.isMalformedOrOversized,
                                nowMs = nowMs
                            )
                        }
                    }
                }

                val peerStatesSnapshot = peerSelector.getAllPeerStates()
                val compatiblePeers = peerStatesSnapshot.filter { it.isCompatible }
                if (compatiblePeers.isEmpty()) {
                    val code = if (lastCompatibilityFailure != SyncErrorCode.NONE) lastCompatibilityFailure else SyncErrorCode.NO_ELIGIBLE_PEERS
                    val msg = lastCompatibilityMessage ?: "No compatible NMD blockchain peers available"
                    publishState(
                        status = SyncStatusState.FAILED,
                        localHeight = localTip.height,
                        latestFinalizedHash = localTip.hash.lowercase(),
                        errorCode = code,
                        errorMsg = msg
                    )
                    return@withLock SyncCycleOutcome.Failed(code, msg)
                }

                val maxReportedPeerHeight = compatiblePeers.maxOf { it.reportedFinalizedHeight }
                if (maxReportedPeerHeight <= localTip.height) {
                    val syncedAt = System.currentTimeMillis()
                    lastSyncTimestampMs = syncedAt
                    saveCheckpointLocked(
                        height = localTip.height,
                        hash = localTip.hash,
                        targetReported = maxReportedPeerHeight,
                        peerId = null,
                        status = SyncStatusState.SYNCED,
                        syncedAtMs = syncedAt
                    )
                    publishState(
                        status = SyncStatusState.SYNCED,
                        localHeight = localTip.height,
                        latestFinalizedHash = localTip.hash.lowercase(),
                        highestReported = maxReportedPeerHeight,
                        remaining = 0L,
                        progress = 1f
                    )
                    return@withLock SyncCycleOutcome.UpToDate(localTip.height)
                }

                // 3. Incremental Sync Loop (bounded headers -> bounded blocks -> zero-trust verify -> atomic persist)
                val initialStartHeight = localTip.height + 1L
                val totalTargetDelta = (maxReportedPeerHeight - localTip.height).coerceAtLeast(1L)
                var syncedThisRun = 0L
                val excludedPeersThisRun = HashSet<String>()
                var lastFailureCode = SyncErrorCode.NO_ELIGIBLE_PEERS
                var lastFailureMessage = "No eligible peer completed sync"

                while (localTip.height < maxReportedPeerHeight) {
                    if (pauseRequested.get()) {
                        saveCheckpointLocked(localTip.height, localTip.hash, maxReportedPeerHeight, null, SyncStatusState.PAUSED)
                        publishState(
                            status = SyncStatusState.PAUSED,
                            localHeight = localTip.height,
                            latestFinalizedHash = localTip.hash.lowercase(),
                            highestReported = maxReportedPeerHeight,
                            remaining = (maxReportedPeerHeight - localTip.height).coerceAtLeast(0L),
                            progress = computeProgress(localTip.height, initialStartHeight - 1L, maxReportedPeerHeight),
                            errorCode = SyncErrorCode.PAUSED_BY_USER,
                            errorMsg = "Synchronization paused by user"
                        )
                        return@withLock SyncCycleOutcome.Paused("Paused by user", SyncErrorCode.PAUSED_BY_USER)
                    }

                    val liveSessions = transport.getAuthenticatedSessions()
                    val selectedPeer = peerSelector.selectBestPeer(
                        activeSessions = liveSessions,
                        localHeight = localTip.height,
                        excludedPeerIds = excludedPeersThisRun,
                        nowMs = System.currentTimeMillis()
                    )

                    if (selectedPeer == null) {
                        val remaining = (maxReportedPeerHeight - localTip.height).coerceAtLeast(0L)
                        publishState(
                            status = SyncStatusState.FAILED,
                            localHeight = localTip.height,
                            latestFinalizedHash = localTip.hash.lowercase(),
                            highestReported = maxReportedPeerHeight,
                            remaining = remaining,
                            progress = computeProgress(localTip.height, initialStartHeight - 1L, maxReportedPeerHeight),
                            errorCode = lastFailureCode,
                            errorMsg = lastFailureMessage
                        )
                        saveCheckpointLocked(
                            localTip.height,
                            localTip.hash,
                            maxReportedPeerHeight,
                            null,
                            SyncStatusState.FAILED,
                            errorCode = lastFailureCode,
                            errorMessage = lastFailureMessage
                        )
                        return@withLock SyncCycleOutcome.Failed(lastFailureCode, lastFailureMessage)
                    }

                    val peerSession = liveSessions.firstOrNull { it.peerId == selectedPeer.peerId }
                    if (peerSession == null || !peerSession.isTrusted) {
                        peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = false)
                        excludedPeersThisRun.add(selectedPeer.peerId)
                        lastFailureCode = SyncErrorCode.PEER_DISCONNECTED
                        lastFailureMessage = "Peer ${selectedPeer.peerId} disconnected"
                        continue
                    }

                    val peerTarget = minOf(selectedPeer.reportedFinalizedHeight, maxReportedPeerHeight)
                    val remainingFromPeer = (peerTarget - localTip.height).coerceAtLeast(0L)
                    if (remainingFromPeer == 0L) {
                        excludedPeersThisRun.add(selectedPeer.peerId)
                        continue
                    }

                    // Step A: Download bounded header batch & validate parent continuity BEFORE fetching bodies
                    val nextNeededHeight = localTip.height + 1L
                    val headerBatchCount = minOf(config.maxHeaderBatchSize.toLong(), remainingFromPeer).toInt()
                    publishState(
                        status = SyncStatusState.SYNCHRONIZING,
                        localHeight = localTip.height,
                        latestFinalizedHash = localTip.hash.lowercase(),
                        highestReported = maxReportedPeerHeight,
                        currentPeerId = selectedPeer.peerId,
                        remaining = (maxReportedPeerHeight - localTip.height).coerceAtLeast(0L),
                        progress = computeProgress(localTip.height, initialStartHeight - 1L, maxReportedPeerHeight)
                    )

                    val headersReq = BlockHeadersRequest(
                        requestId = "hdr_${UUID.randomUUID()}",
                        chainId = config.chainId,
                        fromHeight = nextNeededHeight,
                        maxHeaders = headerBatchCount
                    )
                    val headersCall = transport.requestBlockHeaders(peerSession, headersReq, config.requestTimeoutMs)
                    if (headersCall is SyncTransportCallResult.Failure) {
                        peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = headersCall.isMalformedOrOversized)
                        excludedPeersThisRun.add(selectedPeer.peerId)
                        lastFailureCode = when {
                            headersCall.isTimeout -> SyncErrorCode.REQUEST_TIMEOUT
                            headersCall.isDisconnected -> SyncErrorCode.PEER_DISCONNECTED
                            else -> SyncErrorCode.MALFORMED_PAYLOAD
                        }
                        lastFailureMessage = headersCall.reason
                        continue
                    }

                    val headersResp = (headersCall as SyncTransportCallResult.Success).value
                    val headerCheck = verifier.validateHeadersBatch(
                        headers = headersResp.headers,
                        expectedStartHeight = nextNeededHeight,
                        expectedPreviousHash = localTip.hash,
                        maxBatchSize = headerBatchCount,
                        reportingPeerId = selectedPeer.peerId
                    )
                    if (headerCheck is HeaderBatchValidationResult.Invalid) {
                        if (headerCheck.conflictRecord != null) {
                            recordConflictAndPersistLocked(headerCheck.conflictRecord, localTip)
                            return@withLock SyncCycleOutcome.ConflictDetected(headerCheck.conflictRecord)
                        }
                        peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = true)
                        excludedPeersThisRun.add(selectedPeer.peerId)
                        lastFailureCode = headerCheck.errorCode
                        lastFailureMessage = headerCheck.reason
                        continue
                    }

                    // Step B: Fetch bounded full block bundles across the verified header slice
                    val verifiedHeaders = headersResp.headers
                    var headerCursor = 0
                    var peerErrored = false

                    while (headerCursor < verifiedHeaders.size) {
                        if (pauseRequested.get()) {
                            saveCheckpointLocked(localTip.height, localTip.hash, maxReportedPeerHeight, null, SyncStatusState.PAUSED)
                            return@withLock SyncCycleOutcome.Paused("Paused by user", SyncErrorCode.PAUSED_BY_USER)
                        }

                        val sliceEnd = minOf(headerCursor + config.maxBlockBatchSize, verifiedHeaders.size)
                        val expectedSlice = verifiedHeaders.subList(headerCursor, sliceEnd)
                        val batchFromHeight = expectedSlice.first().height
                        val batchMaxBlocks = expectedSlice.size

                        val liveForBatch = transport.getAuthenticatedSessions().firstOrNull { it.peerId == selectedPeer.peerId && it.isTrusted }
                        if (liveForBatch == null) {
                            peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = false)
                            excludedPeersThisRun.add(selectedPeer.peerId)
                            lastFailureCode = SyncErrorCode.PEER_DISCONNECTED
                            lastFailureMessage = "Peer ${selectedPeer.peerId} disconnected mid-sync"
                            peerErrored = true
                            break
                        }

                        val blocksReq = BlocksRequest(
                            requestId = "blk_${UUID.randomUUID()}",
                            chainId = config.chainId,
                            fromHeight = batchFromHeight,
                            maxBlocks = batchMaxBlocks
                        )
                        val blocksCall = transport.requestBlocks(liveForBatch, blocksReq, config.requestTimeoutMs)
                        if (blocksCall is SyncTransportCallResult.Failure) {
                            peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = blocksCall.isMalformedOrOversized)
                            excludedPeersThisRun.add(selectedPeer.peerId)
                            lastFailureCode = when {
                                blocksCall.isTimeout -> SyncErrorCode.REQUEST_TIMEOUT
                                blocksCall.isDisconnected -> SyncErrorCode.PEER_DISCONNECTED
                                else -> SyncErrorCode.MALFORMED_PAYLOAD
                            }
                            lastFailureMessage = blocksCall.reason
                            peerErrored = true
                            break
                        }

                        val blocksSuccess = blocksCall as SyncTransportCallResult.Success
                        val bundles = blocksSuccess.value.bundles
                        if (bundles.isEmpty() || bundles.size > batchMaxBlocks) {
                            peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = true)
                            excludedPeersThisRun.add(selectedPeer.peerId)
                            lastFailureCode = if (bundles.isEmpty()) SyncErrorCode.MALFORMED_PAYLOAD else SyncErrorCode.PAYLOAD_TOO_LARGE
                            lastFailureMessage = "Unexpected bundle count ${bundles.size} (expected 1..$batchMaxBlocks)"
                            peerErrored = true
                            break
                        }

                        lastDownloadedCount += bundles.size.toLong()
                        publishState(
                            status = SyncStatusState.VERIFYING_BLOCKS,
                            localHeight = localTip.height,
                            latestFinalizedHash = localTip.hash.lowercase(),
                            highestReported = maxReportedPeerHeight,
                            currentPeerId = selectedPeer.peerId,
                            remaining = (maxReportedPeerHeight - localTip.height).coerceAtLeast(0L),
                            progress = computeProgress(localTip.height, initialStartHeight - 1L, maxReportedPeerHeight)
                        )

                        val validatorSnapshot = consensusCoordinator.engine.getCurrentValidatorSetSnapshot()
                        var verifiedInBatch = 0

                        for (idx in bundles.indices) {
                            val bundle = bundles[idx]
                            val expectedHdr = expectedSlice[idx]

                            if (bundle.block.height != expectedHdr.height ||
                                !bundle.block.hash.equals(expectedHdr.blockHash, ignoreCase = true)
                            ) {
                                peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = true)
                                excludedPeersThisRun.add(selectedPeer.peerId)
                                lastFailureCode = SyncErrorCode.INVALID_RESPONSE_ORDER
                                lastFailureMessage = "Downloaded block h=${bundle.block.height} mismatched verified header h=${expectedHdr.height}"
                                peerErrored = true
                                break
                            }

                            val existingFinalized = blockchainManager.getBlockByHeight(bundle.block.height)
                            val existingCert = consensusCoordinator.storage.getCommitCertificate(bundle.block.height)

                            when (
                                val verifyRes = verifier.verifyBlockBundle(
                                    bundle = bundle,
                                    parentBlock = localTip,
                                    validatorSnapshot = validatorSnapshot,
                                    existingFinalizedBlockAtHeight = existingFinalized,
                                    existingCommitCertAtHeight = existingCert,
                                    reportingPeerId = selectedPeer.peerId,
                                    nowMs = System.currentTimeMillis()
                                )
                            ) {
                                is SyncBundleVerificationResult.Verified -> {
                                    // Commit atomically via Stage 10 ConsensusEngine (persists block + CommitCert + advances height)
                                    val commitOutcome = consensusCoordinator.engine.applyVerifiedCommitCertificate(
                                        certificate = bundle.commitCertificate,
                                        attachedBlock = bundle.block,
                                        nowMs = System.currentTimeMillis()
                                    )
                                    if (commitOutcome is ConsensusValidationOutcome.Invalid) {
                                        peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = true)
                                        excludedPeersThisRun.add(selectedPeer.peerId)
                                        lastFailureCode = SyncErrorCode.INVALID_COMMIT_CERTIFICATE
                                        lastFailureMessage = commitOutcome.reason
                                        peerErrored = true
                                        break
                                    }

                                    // Verify Stage 8 block was atomically committed before advancing sync checkpoint
                                    val persistedTip = blockchainManager.getBlockByHeight(bundle.block.height)
                                    if (persistedTip == null || !persistedTip.hash.equals(bundle.block.hash, ignoreCase = true)) {
                                        lastFailureCode = SyncErrorCode.STORAGE_ERROR
                                        lastFailureMessage = "Block h=${bundle.block.height} failed atomic storage persistence"
                                        publishState(
                                            status = SyncStatusState.FAILED,
                                            localHeight = localTip.height,
                                            latestFinalizedHash = localTip.hash.lowercase(),
                                            errorCode = lastFailureCode,
                                            errorMsg = lastFailureMessage
                                        )
                                        return@withLock SyncCycleOutcome.Failed(lastFailureCode, lastFailureMessage)
                                    }

                                    // Stage 12 Mempool & Stage 17 LedgerState Reconciliation for verified transactions inside the synced block
                                    if (bundle.transactions.isNotEmpty()) {
                                        txMempool.reconcileSyncedConfirmedTransactions(
                                            transactions = bundle.transactions,
                                            blockHeight = persistedTip.height,
                                            blockHash = persistedTip.hash,
                                            receivedFromPeerId = selectedPeer.peerId,
                                            updatedAtMs = System.currentTimeMillis()
                                        )
                                        val transition = txMempool.ledgerStateEngine?.applyFinalizedBlock(
                                            transactions = bundle.transactions,
                                            blockHeight = persistedTip.height,
                                            parameters = blockchainManager.config.parameters,
                                            nowMs = persistedTip.timestamp
                                        )
                                        if (transition != null) {
                                            for (reg in transition.validatorRegistrations) {
                                                consensusCoordinator.engine.registerAuthorizedValidator(
                                                    publicKeyHex = reg.publicKeyHex,
                                                    displayName = reg.displayName,
                                                    votingPower = reg.votingPower
                                                )
                                            }
                                            for (exit in transition.validatorExits) {
                                                consensusCoordinator.engine.signer.deriveValidatorIdFromHex(exit.publicKeyHex)?.let { id ->
                                                    consensusCoordinator.engine.retireValidator(id)
                                                }
                                            }
                                        }
                                    }

                                    localTip = persistedTip
                                    lastVerifiedCount += 1L
                                    syncedThisRun += 1L
                                    verifiedInBatch += 1

                                    peerSelector.recordVerifiedProgressFromPeer(
                                        peerId = selectedPeer.peerId,
                                        verifiedHeight = persistedTip.height,
                                        latencyMs = blocksSuccess.latencyMs
                                    )

                                    saveCheckpointLocked(
                                        height = persistedTip.height,
                                        hash = persistedTip.hash,
                                        targetReported = maxReportedPeerHeight,
                                        peerId = selectedPeer.peerId,
                                        status = SyncStatusState.SYNCHRONIZING
                                    )

                                    publishState(
                                        status = SyncStatusState.VERIFYING_BLOCKS,
                                        localHeight = persistedTip.height,
                                        latestFinalizedHash = persistedTip.hash.lowercase(),
                                        highestReported = maxReportedPeerHeight,
                                        currentPeerId = selectedPeer.peerId,
                                        remaining = (maxReportedPeerHeight - persistedTip.height).coerceAtLeast(0L),
                                        progress = computeProgress(persistedTip.height, initialStartHeight - 1L, maxReportedPeerHeight)
                                    )
                                }
                                is SyncBundleVerificationResult.Rejected -> {
                                    if (verifyRes.conflictRecord != null) {
                                        recordConflictAndPersistLocked(verifyRes.conflictRecord, localTip)
                                        return@withLock SyncCycleOutcome.ConflictDetected(verifyRes.conflictRecord)
                                    }
                                    peerSelector.recordPeerFailure(selectedPeer.peerId, penalizeInvalidBehavior = verifyRes.penalizePeer)
                                    excludedPeersThisRun.add(selectedPeer.peerId)
                                    lastFailureCode = verifyRes.errorCode
                                    lastFailureMessage = verifyRes.reason
                                    peerErrored = true
                                    break
                                }
                            }
                        }

                        if (peerErrored || verifiedInBatch == 0) {
                            break
                        }
                        headerCursor += verifiedInBatch
                    }
                }

                val finishedAt = System.currentTimeMillis()
                lastSyncTimestampMs = finishedAt
                saveCheckpointLocked(
                    height = localTip.height,
                    hash = localTip.hash,
                    targetReported = maxReportedPeerHeight,
                    peerId = null,
                    status = SyncStatusState.SYNCED,
                    syncedAtMs = finishedAt
                )
                publishState(
                    status = SyncStatusState.SYNCED,
                    localHeight = localTip.height,
                    latestFinalizedHash = localTip.hash.lowercase(),
                    highestReported = maxReportedPeerHeight,
                    currentPeerId = null,
                    remaining = 0L,
                    progress = 1f,
                    errorCode = SyncErrorCode.NONE,
                    errorMsg = null
                )
                SyncCycleOutcome.Synced(localHeight = localTip.height, syncedBlocksCount = syncedThisRun)
            }
        } finally {
            syncActiveFlag.set(false)
        }
    }

    // ==================== Peer-Serving Handlers (Authenticated Peers Requesting Our Chain) ====================

    override suspend fun handleChainStatusRequest(request: ChainStatusRequest): ChainStatusExchangeMessage {
        val genesis = blockchainManager.getGenesisBlock()
        val latest = blockchainManager.getLatestBlock()
        val consensusState = consensusCoordinator.state.value
        val genesisHash = genesis?.hash?.lowercase() ?: localGenesisHash.ifBlank { SyncProtocolConstants.ZERO_HASH }
        val finalizedHeight = maxOf(0L, latest?.height ?: 0L)
        val finalizedHash = latest?.hash?.lowercase()
            ?: consensusState.latestFinalizedHash.lowercase()

        return ChainStatusExchangeMessage(
            requestId = request.requestId,
            chainId = blockchainManager.config.chainId,
            genesisHash = genesisHash,
            currentHeight = latest?.height ?: 0L,
            latestBlockHash = latest?.hash?.lowercase() ?: genesisHash,
            finalizedHeight = finalizedHeight,
            finalizedBlockHash = finalizedHash,
            protocolVersion = blockchainManager.config.parameters.protocolVersion,
            syncState = _uiState.value.syncStatus,
            timestampMs = System.currentTimeMillis()
        )
    }

    override suspend fun handleBlockHeadersRequest(request: BlockHeadersRequest): BlockHeadersResponse {
        if (request.chainId != config.chainId || request.fromHeight < 0L) {
            return BlockHeadersResponse(requestId = request.requestId, chainId = config.chainId, headers = emptyList())
        }
        val bounded = request.maxHeaders.coerceIn(1, config.maxHeaderBatchSize)
        val blocks = blockchainManager.getBlocksRange(request.fromHeight, bounded)
        val headers = blocks.map { b ->
            SyncBlockHeaderEntry(
                height = b.header.height,
                blockHash = b.hash.lowercase(),
                previousHash = b.header.previousHash.lowercase(),
                timestamp = b.header.timestamp,
                chainId = b.header.chainId,
                protocolVersion = b.header.protocolVersion,
                merkleRoot = b.header.merkleRoot.lowercase(),
                transactionCount = b.header.transactionCount,
                producerId = b.header.producerId
            )
        }
        return BlockHeadersResponse(
            requestId = request.requestId,
            chainId = config.chainId,
            headers = headers
        )
    }

    override suspend fun handleBlocksRequest(request: BlocksRequest): BlocksResponse {
        if (request.chainId != config.chainId || request.fromHeight < 1L) {
            return BlocksResponse(requestId = request.requestId, chainId = config.chainId, bundles = emptyList())
        }
        val bounded = request.maxBlocks.coerceIn(1, config.maxBlockBatchSize)
        val blocks = blockchainManager.getBlocksRange(request.fromHeight, bounded)
        val bundles = ArrayList<SyncBlockBundle>(blocks.size)
        var runningBytes = 256

        for (block in blocks) {
            val cert = consensusCoordinator.storage.getCommitCertificate(block.height) ?: break
            val txs = ArrayList<NmdTransaction>(block.body.transactionRefs.size)
            var missingTx = false
            for (ref in block.body.transactionRefs) {
                val tx = txMempool.getConfirmedOrActiveTransaction(ref.txHash)
                if (tx == null) {
                    missingTx = true
                    break
                }
                txs.add(tx)
            }
            if (missingTx) break

            val bundle = SyncBlockBundle(
                block = block,
                commitCertificate = cert,
                transactions = txs
            )
            val bundleBytes = bundle.toJsonObject().toString().toByteArray(Charsets.UTF_8).size
            if (runningBytes + bundleBytes > config.maxResponsePayloadBytes && bundles.isNotEmpty()) {
                break
            }
            runningBytes += bundleBytes
            bundles.add(bundle)
        }

        return BlocksResponse(
            requestId = request.requestId,
            chainId = config.chainId,
            bundles = bundles
        )
    }

    private suspend fun recordConflictAndPersistLocked(conflict: SyncConflictRecord, localTip: com.example.blockchain.model.Block) {
        syncStorage.saveConflict(conflict)
        val allConflicts = syncStorage.getConflicts(config.chainId)
        saveCheckpointLocked(
            height = localTip.height,
            hash = localTip.hash,
            targetReported = _uiState.value.highestReportedPeerHeight,
            peerId = conflict.reportingPeerId,
            status = SyncStatusState.CONFLICT_DETECTED,
            errorCode = SyncErrorCode.CONFLICTING_FINALIZED_HISTORY,
            errorMessage = conflict.reason
        )
        publishState(
            status = SyncStatusState.CONFLICT_DETECTED,
            localHeight = localTip.height,
            latestFinalizedHash = localTip.hash.lowercase(),
            errorCode = SyncErrorCode.CONFLICTING_FINALIZED_HISTORY,
            errorMsg = conflict.reason,
            conflicts = allConflicts
        )
    }

    private suspend fun saveCheckpointLocked(
        height: Long,
        hash: String,
        targetReported: Long,
        peerId: String?,
        status: SyncStatusState,
        syncedAtMs: Long? = lastSyncTimestampMs,
        errorCode: SyncErrorCode = SyncErrorCode.NONE,
        errorMessage: String? = null
    ) {
        syncStorage.saveCheckpoint(
            SyncProgressCheckpoint(
                chainId = config.chainId,
                lastVerifiedHeight = height,
                lastVerifiedBlockHash = hash.lowercase(),
                targetReportedHeight = targetReported,
                downloadedBlocksCount = lastDownloadedCount,
                verifiedBlocksCount = lastVerifiedCount,
                activePeerId = peerId,
                statusState = status,
                lastSyncTimestampMs = syncedAtMs,
                lastErrorCode = errorCode,
                lastErrorMessage = errorMessage
            )
        )
    }

    private fun computeProgress(currentHeight: Long, startHeight: Long, targetHeight: Long): Float {
        if (targetHeight <= startHeight) return 1f
        val total = (targetHeight - startHeight).toFloat()
        val done = (currentHeight - startHeight).coerceAtLeast(0L).toFloat()
        return (done / total).coerceIn(0f, 1f)
    }

    private suspend fun publishState(
        status: SyncStatusState,
        localHeight: Long = _uiState.value.localHeight,
        latestFinalizedHash: String = _uiState.value.latestFinalizedBlockHash,
        highestReported: Long = _uiState.value.highestReportedPeerHeight,
        currentPeerId: String? = null,
        remaining: Long = _uiState.value.remainingBlocksCount,
        progress: Float = _uiState.value.progressFraction,
        errorCode: SyncErrorCode = SyncErrorCode.NONE,
        errorMsg: String? = null,
        conflicts: List<SyncConflictRecord>? = null
    ) {
        val peerStates = peerSelector.getAllPeerStates()
        val highestVerified = maxOf(
            localHeight,
            peerStates.maxOfOrNull { it.highestVerifiedHeightFromPeer } ?: 0L
        )
        val conflictList = conflicts ?: syncStorage.getConflicts(config.chainId)
        _uiState.value = SyncUiState(
            isInitialized = true,
            isDevelopmentMode = config.isDevelopmentMode,
            chainId = config.chainId,
            syncStatus = status,
            localHeight = localHeight,
            latestFinalizedHeight = localHeight,
            latestFinalizedBlockHash = latestFinalizedHash,
            highestReportedPeerHeight = highestReported,
            highestVerifiedPeerHeight = highestVerified,
            currentSyncPeerId = currentPeerId,
            downloadedBlocksCount = lastDownloadedCount,
            verifiedBlocksCount = lastVerifiedCount,
            remainingBlocksCount = remaining,
            progressFraction = progress,
            compatiblePeersCount = peerStates.count { it.isCompatible },
            connectedPeersCount = transport.getAuthenticatedSessions().size,
            lastSyncTimestampMs = lastSyncTimestampMs,
            isUserPaused = pauseRequested.get(),
            mobileResourcePaused = mobileResourcePaused,
            mobilePauseReason = mobilePauseReason,
            errorCode = errorCode,
            errorMessage = errorMsg,
            conflictRecords = conflictList,
            peerStates = peerStates
        )
    }

    override fun close() {
        syncStorage.close()
    }
}
