package com.example.transaction

import android.content.Context
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.manager.BlockchainManager
import com.example.crypto.NodeIdentityManager
import com.example.crypto.model.NodeIdentity
import com.example.crypto.repository.IdentityRepository
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.transaction.blockchain.TransactionBlockBridge
import com.example.transaction.blockchain.TransactionLookupResult
import com.example.transaction.crypto.NmdAddressCodec
import com.example.transaction.crypto.TransactionSigner
import com.example.transaction.fee.FeeConfig
import com.example.transaction.fee.FeeEstimate
import com.example.transaction.fee.TransactionFeeCalculator
import com.example.transaction.mempool.MempoolSubmissionResult
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.AccountNonceState
import com.example.transaction.model.MempoolStatsSnapshot
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionPropagationStatus
import com.example.transaction.model.TransactionType
import com.example.transaction.nonce.NonceManager
import com.example.transaction.p2p.P2pTransactionPropagationGateway
import com.example.transaction.p2p.TxBroadcastOutcome
import com.example.transaction.storage.RoomTransactionStorage
import com.example.transaction.storage.TransactionStorage
import com.example.transaction.validation.TransactionPolicyConfig
import com.example.transaction.validation.TransactionValidator
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import java.io.Closeable

sealed class WalletTxCreationOutcome {
    data class Submitted(
        val record: MempoolTransactionRecord,
        val broadcastOutcome: TxBroadcastOutcome?
    ) : WalletTxCreationOutcome()

    data class Failed(
        val reason: String,
        val isIdentityMissing: Boolean = false
    ) : WalletTxCreationOutcome()
}

/**
 * Central Stage 9 Transaction Engine coordinator.
 *
 * Unifies:
 * - Ed25519 local signing & sender address derivation
 * - Fee calculation & rules
 * - Account nonce tracking & concurrency-safe reservation
 * - Structural/cryptographic validation
 * - Persistent Room mempool
 * - Stage 8 Blockchain Core integration bridge
 * - Stage 6/7 P2P transaction propagation gateway
 */
class TransactionEngineManager(
    val blockchainConfig: BlockchainConfig = BlockchainConfig(),
    val storage: TransactionStorage,
    val feeCalculator: TransactionFeeCalculator = TransactionFeeCalculator(FeeConfig()),
    val signer: TransactionSigner = TransactionSigner(),
    val policy: TransactionPolicyConfig = TransactionPolicyConfig(),
    val blockchainManager: BlockchainManager? = null,
    val peerRegistry: DistributedPeerRegistry? = null,
    ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    enforceStrictBalances: Boolean = false
) : Closeable {

    constructor(
        context: Context,
        blockchainConfig: BlockchainConfig = BlockchainConfig(),
        dbName: String = BlockchainConfig.databaseNameFor("nmd_tx_mempool.db", blockchainConfig.chainId),
        inMemoryStorage: Boolean = false,
        blockchainManager: BlockchainManager? = null,
        peerRegistry: DistributedPeerRegistry? = null,
        enforceStrictBalances: Boolean = false
    ) : this(
        blockchainConfig = blockchainConfig,
        storage = RoomTransactionStorage(
            context = context,
            dbName = dbName,
            inMemory = inMemoryStorage
        ),
        blockchainManager = blockchainManager,
        peerRegistry = peerRegistry,
        enforceStrictBalances = enforceStrictBalances
    )

    val ledgerState = com.example.blockchain.state.LedgerStateEngine(
        storage = storage,
        cryptoProvider = signer.cryptoProvider,
        ioDispatcher = ioDispatcher,
        enforceStrictBalances = enforceStrictBalances
    )

    val validator = TransactionValidator(
        blockchainConfig = blockchainConfig,
        feeCalculator = feeCalculator,
        signer = signer,
        policy = policy
    )

    val mempool = TransactionMempool(
        storage = storage,
        validator = validator,
        ioDispatcher = ioDispatcher,
        ledgerStateEngine = ledgerState
    )

    val nonceManager = NonceManager(storage)

    val blockBridge: TransactionBlockBridge? = blockchainManager?.let {
        TransactionBlockBridge(mempool, it)
    }

    val p2pGateway = P2pTransactionPropagationGateway(
        mempool = mempool,
        peerRegistry = peerRegistry
    )

    val mempoolTransactions: StateFlow<List<MempoolTransactionRecord>> = mempool.transactions
    val mempoolStats: StateFlow<MempoolStatsSnapshot> = mempool.stats

    suspend fun initialize(): List<MempoolTransactionRecord> = mempool.initialize()

    fun deriveSenderAddress(identity: NodeIdentity?): String? {
        identity ?: return null
        return NmdAddressCodec.deriveAddressFromPublicKeyHex(identity.publicKeyHex, signer.cryptoProvider)
    }

    fun estimateFeeForDraft(
        txType: TransactionType = TransactionType.TRANSFER,
        memoOrPayload: String = ""
    ): FeeEstimate {
        val payloadBytes = memoOrPayload.toByteArray(Charsets.UTF_8)
        return feeCalculator.estimateFeeForDraft(txType, payloadBytes.size, blockchainConfig.chainId)
    }

    suspend fun getAccountNonceState(address: String): AccountNonceState {
        return nonceManager.getAccountNonceState(address)
    }

    /**
     * Builds, safely assigns sequential nonce, signs locally via Ed25519 [identityManager],
     * validates, stores in persistent mempool, and propagates to connected authenticated peers if any.
     */
    suspend fun createSignAndSubmitFromWallet(
        identityManager: NodeIdentityManager,
        recipientAddress: String,
        amountUnits: Long,
        txType: TransactionType = TransactionType.TRANSFER,
        memoOrPayload: String = "",
        customFeeUnits: Long? = null,
        attemptBroadcast: Boolean = true
    ): WalletTxCreationOutcome {
        val identity = identityManager.getActiveIdentity()
            ?: return WalletTxCreationOutcome.Failed(
                reason = "No Ed25519 node identity initialized on this device",
                isIdentityMissing = true
            )

        return createSignAndSubmit(
            identityRepository = identityManager.repository,
            recipientAddress = recipientAddress.trim(),
            amountUnits = amountUnits,
            txType = txType,
            payloadBytes = memoOrPayload.toByteArray(Charsets.UTF_8),
            customFeeUnits = customFeeUnits,
            attemptBroadcast = attemptBroadcast
        )
    }

    suspend fun createSignAndSubmit(
        identityRepository: IdentityRepository,
        recipientAddress: String,
        amountUnits: Long,
        txType: TransactionType = TransactionType.TRANSFER,
        payloadBytes: ByteArray = ByteArray(0),
        customFeeUnits: Long? = null,
        attemptBroadcast: Boolean = true,
        nowMs: Long = System.currentTimeMillis()
    ): WalletTxCreationOutcome {
        val identity = identityRepository.getPublicIdentity()
            ?: return WalletTxCreationOutcome.Failed("No Ed25519 identity available", isIdentityMissing = true)

        val senderAddress = deriveSenderAddress(identity)
            ?: return WalletTxCreationOutcome.Failed("Invalid local public key")

        return nonceManager.withReservedNonce(senderAddress) { assignedNonce ->
            val preliminaryTx = NmdTransaction(
                chainId = blockchainConfig.chainId,
                protocolVersion = blockchainConfig.parameters.protocolVersion,
                senderAddress = senderAddress,
                recipientAddress = recipientAddress.trim(),
                amountUnits = amountUnits,
                feeUnits = customFeeUnits ?: 0L,
                nonce = assignedNonce,
                timestamp = nowMs,
                txType = txType,
                rawTxTypeName = txType.name,
                senderPublicKeyHex = identity.publicKeyHex.lowercase(),
                payload = payloadBytes
            )
            val resolvedFeeUnits = customFeeUnits ?: feeCalculator.estimateFee(preliminaryTx).minimumRequiredFeeUnits
            val unsignedTx = preliminaryTx.copy(feeUnits = resolvedFeeUnits)

            val signedTx = try {
                signer.signWithDeviceIdentity(unsignedTx, identityRepository)
            } catch (e: Exception) {
                return@withReservedNonce WalletTxCreationOutcome.Failed(
                    reason = e.message ?: "Local Ed25519 signing failed"
                )
            }

            when (val submission = mempool.submitTransaction(signedTx, nowMs = nowMs)) {
                is MempoolSubmissionResult.Accepted -> {
                    val broadcastOutcome = if (attemptBroadcast) {
                        p2pGateway.broadcastTransaction(submission.record.transaction)
                    } else {
                        null
                    }
                    val latestRecord = mempool.getByTxId(submission.record.transaction.txId) ?: submission.record
                    WalletTxCreationOutcome.Submitted(latestRecord, broadcastOutcome)
                }
                is MempoolSubmissionResult.Duplicate -> {
                    WalletTxCreationOutcome.Failed(submission.reason)
                }
                is MempoolSubmissionResult.Rejected -> {
                    WalletTxCreationOutcome.Failed(submission.reason)
                }
            }
        }
    }

    suspend fun broadcastAllValidated(): Int {
        val candidates = mempool.getBlockCandidateTransactions(50)
        var broadcasted = 0
        for (rec in candidates) {
            if (rec.propagationStatus == TransactionPropagationStatus.LOCAL_ONLY ||
                rec.propagationStatus == TransactionPropagationStatus.PROPAGATION_FAILED
            ) {
                val out = p2pGateway.broadcastTransaction(rec.transaction)
                if (out.deliveredPeers > 0) broadcasted++
            }
        }
        return broadcasted
    }

    suspend fun pruneExpiredTransactions(): Int = mempool.pruneExpired()

    suspend fun lookupTransaction(txId: String): TransactionLookupResult? {
        val bridge = blockBridge
        if (bridge != null) return bridge.lookupTransactionById(txId)
        val rec = mempool.getByTxId(txId) ?: return null
        return TransactionLookupResult(
            txId = rec.transaction.txId,
            foundInMempool = true,
            mempoolRecord = rec
        )
    }

    override fun close() {
        mempool.close()
    }
}

/**
 * Application-scoped shared registry so Wallet and Network screens interact with
 * the exact same Stage 9 [TransactionEngineManager] instance at runtime without breaking
 * Compose default ViewModel factories or isolated unit tests.
 */
object NmdTransactionEngineRegistry {
    @Volatile
    private var sharedInstance: TransactionEngineManager? = null

    fun getOrCreate(
        context: Context,
        blockchainManager: BlockchainManager? = null,
        peerRegistry: DistributedPeerRegistry? = null
    ): TransactionEngineManager {
        val existing = sharedInstance
        if (existing != null) return existing
        return synchronized(this) {
            sharedInstance ?: TransactionEngineManager(
                context = context.applicationContext,
                blockchainConfig = blockchainManager?.config ?: BlockchainConfig(),
                blockchainManager = blockchainManager,
                peerRegistry = peerRegistry
            ).also {
                sharedInstance = it
            }
        }
    }

    fun resetForTests() {
        synchronized(this) {
            sharedInstance?.close()
            sharedInstance = null
        }
    }
}
