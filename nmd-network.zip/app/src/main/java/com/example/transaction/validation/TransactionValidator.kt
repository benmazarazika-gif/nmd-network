package com.example.transaction.validation

import com.example.blockchain.config.BlockchainConfig
import com.example.transaction.crypto.NmdAddressCodec
import com.example.transaction.crypto.TransactionSigner
import com.example.transaction.fee.FeeEstimate
import com.example.transaction.fee.FeeValidationResult
import com.example.transaction.fee.TransactionFeeCalculator
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionType

enum class TxValidationErrorCode {
    MALFORMED_STRUCTURE,
    INVALID_TX_ID,
    INVALID_CHAIN_ID,
    UNSUPPORTED_PROTOCOL_VERSION,
    UNSUPPORTED_TRANSACTION_TYPE,
    TRANSACTION_TYPE_DISABLED_IN_STAGE,
    INVALID_SENDER_ADDRESS,
    INVALID_RECIPIENT_ADDRESS,
    INVALID_PUBLIC_KEY,
    SENDER_PUBKEY_MISMATCH,
    INVALID_SIGNATURE,
    INVALID_AMOUNT,
    INVALID_FEE,
    INVALID_TIMESTAMP,
    EXPIRED_TIMESTAMP,
    PAYLOAD_TOO_LARGE,
    TX_TOO_LARGE,
    STALE_NONCE,
    DUPLICATE_NONCE,
    NONCE_GAP_TOO_LARGE,
    DUPLICATE_TX_ID,
    MEMPOOL_FULL,
    SENDER_MEMPOOL_QUOTA_EXCEEDED,
    INSUFFICIENT_BALANCE,
    INVALID_VALIDATOR_PAYLOAD
}

sealed class TxValidationResult {
    data class Valid(
        val targetStatus: MempoolTxStatus,
        val feeEstimate: FeeEstimate
    ) : TxValidationResult()

    data class Invalid(
        val code: TxValidationErrorCode,
        val reason: String
    ) : TxValidationResult()

    val isValid: Boolean
        get() = this is Valid
}

data class TransactionPolicyConfig(
    val maxPayloadBytes: Int = 4_096,
    val maxSerializedTxBytes: Int = 8_192,
    val maxTransactionAgeMs: Long = 24L * 60L * 60L * 1000L, // 24 hours
    val maxFutureDriftMs: Long = 120_000L,                   // 2 minutes
    val maxNonceGap: Long = 16L,
    val maxActiveMempoolSize: Int = 500,
    val maxRejectedHistorySize: Int = 100,
    val maxPendingPerSender: Int = 32
)

/**
 * Modular, consensus-neutral Stage 9 Transaction Validation Engine.
 *
 * Independently verifies structural integrity, chain binding, address/key derivation,
 * Ed25519 signature validity, fee rules, payload limits, timestamps, and nonce ordering.
 */
class TransactionValidator(
    private val blockchainConfig: BlockchainConfig = BlockchainConfig(),
    private val feeCalculator: TransactionFeeCalculator = TransactionFeeCalculator(),
    val signer: TransactionSigner = TransactionSigner(),
    val policy: TransactionPolicyConfig = TransactionPolicyConfig()
) {
    /**
     * Stateless validation checks independent of local mempool or account nonce state.
     */
    fun validateStateless(
        tx: NmdTransaction,
        nowMs: Long = System.currentTimeMillis()
    ): TxValidationResult {
        // 1. Structural & non-blank checks
        if (tx.txId.isBlank() || tx.chainId.isBlank() || tx.senderAddress.isBlank() ||
            tx.recipientAddress.isBlank() || tx.senderPublicKeyHex.isBlank() || tx.signatureHex.isBlank()
        ) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.MALFORMED_STRUCTURE,
                "Missing required transaction fields"
            )
        }

        // 2. Supported transaction type check
        if (tx.txType == TransactionType.UNKNOWN) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.UNSUPPORTED_TRANSACTION_TYPE,
                "Unsupported transaction type: ${tx.rawTxTypeName}"
            )
        }
        if (!tx.txType.isActiveInCurrentStage) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.TRANSACTION_TYPE_DISABLED_IN_STAGE,
                "Transaction type ${tx.txType.name} is reserved and disabled in Stage 9"
            )
        }

        // 3. Chain ID & protocol version
        if (tx.chainId != blockchainConfig.chainId) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_CHAIN_ID,
                "Chain ID mismatch: expected ${blockchainConfig.chainId}, got ${tx.chainId}"
            )
        }
        if (tx.protocolVersion != blockchainConfig.parameters.protocolVersion) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.UNSUPPORTED_PROTOCOL_VERSION,
                "Unsupported protocol version: ${tx.protocolVersion}"
            )
        }

        // 4. Payload & serialized size limits
        if (tx.payload.size > policy.maxPayloadBytes) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.PAYLOAD_TOO_LARGE,
                "Payload size (${tx.payload.size}B) exceeds max (${policy.maxPayloadBytes}B)"
            )
        }

        // 5. Timestamp checks
        if (tx.timestamp <= 0L) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_TIMESTAMP,
                "Transaction timestamp must be positive"
            )
        }
        if (tx.timestamp > nowMs + policy.maxFutureDriftMs) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_TIMESTAMP,
                "Transaction timestamp exceeds allowed future drift"
            )
        }
        if (nowMs - tx.timestamp > policy.maxTransactionAgeMs) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.EXPIRED_TIMESTAMP,
                "Transaction timestamp expired (age=${nowMs - tx.timestamp}ms > ${policy.maxTransactionAgeMs}ms)"
            )
        }

        // 6. Address formatting & public key checks
        if (!NmdAddressCodec.isValidAddressFormat(tx.senderAddress)) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_SENDER_ADDRESS,
                "Invalid NMD sender address format"
            )
        }
        if (!NmdAddressCodec.isValidAddressFormat(tx.recipientAddress)) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_RECIPIENT_ADDRESS,
                "Invalid NMD recipient address format"
            )
        }
        if (!TransactionSigner.isValidEd25519PublicKeyHex(tx.senderPublicKeyHex)) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_PUBLIC_KEY,
                "Invalid Ed25519 public key encoding"
            )
        }
        val pubKeyBytes = try {
            signer.cryptoProvider.fromHex(tx.senderPublicKeyHex)
        } catch (_: Exception) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_PUBLIC_KEY,
                "Malformed public key hex"
            )
        }
        if (pubKeyBytes.size != 32 || pubKeyBytes.all { it == 0.toByte() }) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_PUBLIC_KEY,
                "Invalid or zero Ed25519 public key"
            )
        }

        // 7. Sender identity consistency check (prevents sender spoofing with someone else's address)
        if (!NmdAddressCodec.verifySenderAddressMatchesPublicKey(tx.senderAddress, pubKeyBytes, signer.cryptoProvider)) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.SENDER_PUBKEY_MISMATCH,
                "Sender address does not match derived Ed25519 public key"
            )
        }

        // 8. Amount & nonce basic bounds + validator payload verification
        if (tx.nonce < 0L) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.STALE_NONCE,
                "Transaction nonce cannot be negative"
            )
        }
        when (tx.txType) {
            TransactionType.TRANSFER -> {
                if (tx.amountUnits <= 0L || tx.amountUnits > NmdAmountCodec.MAX_AMOUNT_UNITS) {
                    return TxValidationResult.Invalid(
                        TxValidationErrorCode.INVALID_AMOUNT,
                        "TRANSFER amount must be strictly positive and within bounds"
                    )
                }
            }
            TransactionType.ACCOUNT_INITIALIZATION -> {
                if (tx.amountUnits < 0L || tx.amountUnits > NmdAmountCodec.MAX_AMOUNT_UNITS) {
                    return TxValidationResult.Invalid(
                        TxValidationErrorCode.INVALID_AMOUNT,
                        "Invalid ACCOUNT_INITIALIZATION amount"
                    )
                }
            }
            TransactionType.VALIDATOR_REGISTER, TransactionType.VALIDATOR_EXIT -> {
                if (tx.amountUnits < 0L || tx.amountUnits > NmdAmountCodec.MAX_AMOUNT_UNITS) {
                    return TxValidationResult.Invalid(
                        TxValidationErrorCode.INVALID_AMOUNT,
                        "Invalid validator transaction amount"
                    )
                }
                val parsed = com.example.transaction.model.ValidatorTransactionPayload.fromBytes(tx.payload)
                    ?: return TxValidationResult.Invalid(
                        TxValidationErrorCode.INVALID_VALIDATOR_PAYLOAD,
                        "Malformed validator registration/exit JSON payload"
                    )
                if (!parsed.publicKeyHex.equals(tx.senderPublicKeyHex, ignoreCase = true)) {
                    return TxValidationResult.Invalid(
                        TxValidationErrorCode.SENDER_PUBKEY_MISMATCH,
                        "Validator registration public key must match sender signing key"
                    )
                }
            }
            else -> Unit
        }

        // 9. Fee validation & serialized byte limit
        val feeRes = feeCalculator.validateFee(tx)
        val feeEstimate = when (feeRes) {
            is FeeValidationResult.Valid -> feeRes.estimate
            is FeeValidationResult.Invalid -> {
                return TxValidationResult.Invalid(TxValidationErrorCode.INVALID_FEE, feeRes.reason)
            }
        }
        if (feeEstimate.estimatedSizeBytes > policy.maxSerializedTxBytes) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.TX_TOO_LARGE,
                "Serialized transaction size (${feeEstimate.estimatedSizeBytes}B) exceeds limit (${policy.maxSerializedTxBytes}B)"
            )
        }

        // 10. Deterministic Transaction ID verification
        if (!signer.verifyTransactionId(tx)) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_TX_ID,
                "Transaction ID does not match canonical hash"
            )
        }

        // 11. Ed25519 Digital Signature verification
        if (!signer.verifySignature(tx)) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.INVALID_SIGNATURE,
                "Ed25519 digital signature verification failed"
            )
        }

        return TxValidationResult.Valid(
            targetStatus = MempoolTxStatus.PENDING,
            feeEstimate = feeEstimate
        )
    }

    /**
     * Stateful validation against confirmed account nonce and active sender mempool nonces.
     */
    fun validateWithAccountState(
        tx: NmdTransaction,
        confirmedNextNonce: Long,
        activeSenderNonces: Set<Long>,
        nowMs: Long = System.currentTimeMillis()
    ): TxValidationResult {
        val stateless = validateStateless(tx, nowMs)
        if (stateless is TxValidationResult.Invalid) return stateless
        val feeEstimate = (stateless as TxValidationResult.Valid).feeEstimate

        if (tx.nonce < confirmedNextNonce) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.STALE_NONCE,
                "Nonce ${tx.nonce} is below confirmed account nonce $confirmedNextNonce"
            )
        }
        if (activeSenderNonces.contains(tx.nonce)) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.DUPLICATE_NONCE,
                "Nonce ${tx.nonce} already exists in active mempool for sender ${tx.senderAddress}"
            )
        }

        // Compute expected sequential frontier starting at confirmedNextNonce across active nonces
        var sequentialTip = confirmedNextNonce
        while (activeSenderNonces.contains(sequentialTip)) {
            sequentialTip++
        }

        val gap = tx.nonce - sequentialTip
        if (gap > policy.maxNonceGap) {
            return TxValidationResult.Invalid(
                TxValidationErrorCode.NONCE_GAP_TOO_LARGE,
                "Nonce ${tx.nonce} exceeds maximum allowed forward gap from expected $sequentialTip"
            )
        }

        val targetStatus = if (tx.nonce == sequentialTip) {
            MempoolTxStatus.VALIDATED
        } else {
            MempoolTxStatus.QUEUED
        }

        return TxValidationResult.Valid(
            targetStatus = targetStatus,
            feeEstimate = feeEstimate
        )
    }
}
