package com.example.transaction.blockchain

import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.crypto.MerkleProof
import com.example.blockchain.crypto.MerkleTree
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.TransactionReference
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdTransaction

data class TransactionLookupResult(
    val txId: String,
    val foundInMempool: Boolean,
    val mempoolRecord: MempoolTransactionRecord? = null,
    val includedInBlockHeight: Long? = null,
    val includedInBlockHash: String? = null,
    val txIndexInBlock: Int? = null,
    val merkleProof: MerkleProof? = null
) {
    val isConfirmedInBlock: Boolean
        get() = includedInBlockHeight != null && includedInBlockHash != null
}

/**
 * Clean bridge between Stage 9 Transaction Engine and Stage 8 Blockchain Core.
 *
 * Responsibilities:
 * - Converts validated transactions into Stage 8 [TransactionReference]s.
 * - Computes transaction Merkle roots & inclusion proofs via Stage 8 [BlockHasher]/[MerkleTree]
 *   without altering Stage 8 block hashing.
 * - Looks up transactions across mempool and persisted Stage 8 blocks.
 * - Updates mempool confirmation metadata when a future Stage 10+ block is committed.
 */
class TransactionBlockBridge(
    private val mempool: TransactionMempool,
    private val blockchainManager: BlockchainManager
) {
    private val blockHasher: BlockHasher = blockchainManager.blockHasher

    fun toTransactionReferences(transactions: List<NmdTransaction>): List<TransactionReference> {
        return transactions.mapIndexed { index, tx ->
            TransactionReference(
                txHash = tx.txId.lowercase(),
                txIndex = index,
                txType = tx.txType.name
            )
        }
    }

    fun computeMerkleRootForTransactions(transactions: List<NmdTransaction>): String {
        val refs = toTransactionReferences(transactions)
        return blockHasher.computeBodyMerkleRoot(BlockBody(transactionRefs = refs))
    }

    fun generateInclusionProof(txId: String, block: Block): MerkleProof? {
        val refs = block.body.transactionRefs
        val targetIndex = refs.indexOfFirst { it.txHash.equals(txId, ignoreCase = true) }
        if (targetIndex < 0) return null
        val leafHashes = refs.map { blockHasher.computeTransactionRefHash(it) }
        return MerkleTree.generateProof(leafHashes, targetIndex, blockHasher.cryptoProvider)
    }

    fun verifyInclusionProof(proof: MerkleProof): Boolean {
        return MerkleTree.verifyProof(proof, blockHasher.cryptoProvider)
    }

    /**
     * Confirmation tracking hook for Stage 10+ block inclusion without implementing block production.
     */
    suspend fun onBlockCommitted(block: Block): Int {
        val txIds = block.body.transactionRefs.map { it.txHash.lowercase() }
        if (txIds.isEmpty()) return 0
        return mempool.onBlockCommitted(
            txIds = txIds,
            blockHeight = block.height,
            blockHash = block.hash,
            updatedAtMs = block.timestamp
        )
    }

    suspend fun lookupTransactionById(
        txId: String,
        scanMaxRecentBlocks: Long = 200L
    ): TransactionLookupResult? {
        val cleanId = txId.trim().lowercase()
        if (cleanId.isBlank()) return null

        val mempoolRecord = mempool.getByTxId(cleanId)
        if (mempoolRecord != null &&
            mempoolRecord.status == MempoolTxStatus.CONFIRMED &&
            mempoolRecord.confirmedBlockHeight != null
        ) {
            val block = blockchainManager.getBlockByHeight(mempoolRecord.confirmedBlockHeight)
            val idx = block?.body?.transactionRefs?.indexOfFirst { it.txHash.equals(cleanId, ignoreCase = true) }
            val proof = if (block != null && idx != null && idx >= 0) generateInclusionProof(cleanId, block) else null
            return TransactionLookupResult(
                txId = cleanId,
                foundInMempool = true,
                mempoolRecord = mempoolRecord,
                includedInBlockHeight = mempoolRecord.confirmedBlockHeight,
                includedInBlockHash = mempoolRecord.confirmedBlockHash,
                txIndexInBlock = if (idx != null && idx >= 0) idx else null,
                merkleProof = proof
            )
        }

        // Scan recent Stage 8 persisted blocks (bounded downward scan from tip)
        val tipHeight = blockchainManager.getCurrentHeight()
        if (tipHeight >= 0L) {
            val lowestToScan = maxOf(0L, tipHeight - scanMaxRecentBlocks + 1L)
            for (h in tipHeight downTo lowestToScan) {
                val block = blockchainManager.getBlockByHeight(h) ?: continue
                val refIndex = block.body.transactionRefs.indexOfFirst { it.txHash.equals(cleanId, ignoreCase = true) }
                if (refIndex >= 0) {
                    val proof = generateInclusionProof(cleanId, block)
                    return TransactionLookupResult(
                        txId = cleanId,
                        foundInMempool = mempoolRecord != null,
                        mempoolRecord = mempoolRecord,
                        includedInBlockHeight = block.height,
                        includedInBlockHash = block.hash,
                        txIndexInBlock = refIndex,
                        merkleProof = proof
                    )
                }
            }
        }

        if (mempoolRecord != null) {
            return TransactionLookupResult(
                txId = cleanId,
                foundInMempool = true,
                mempoolRecord = mempoolRecord
            )
        }

        return null
    }
}
