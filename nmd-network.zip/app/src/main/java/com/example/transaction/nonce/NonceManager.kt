package com.example.transaction.nonce

import com.example.transaction.model.AccountNonceState
import com.example.transaction.storage.TransactionStorage
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

/**
 * Concurrency-safe account nonce coordinator.
 *
 * Clearly distinguishes:
 * - [confirmedNextNonce]: State confirmed on committed blockchain blocks (persisted in Room).
 * - [pendingNonces]: Transactions present in local mempool ([PENDING]/[VALIDATED]/[QUEUED]).
 * - [reservedNonces]: Transient in-flight UI/service reservations preventing double submission.
 */
class NonceManager(
    private val storage: TransactionStorage
) {
    private val senderMutexes = ConcurrentHashMap<String, Mutex>()
    private val inFlightReservations = ConcurrentHashMap<String, MutableSet<Long>>()

    private fun mutexFor(address: String): Mutex =
        senderMutexes.getOrPut(address) { Mutex() }

    suspend fun getAccountNonceState(address: String): AccountNonceState {
        return mutexFor(address).withLock {
            readStateLocked(address)
        }
    }

    /**
     * Atomically reserves the next sequential nonce for [address] to prevent concurrent
     * double-taps or parallel coroutines from creating conflicting duplicate-nonce transactions.
     */
    suspend fun reserveNextNonce(address: String): Long {
        return mutexFor(address).withLock {
            val state = readStateLocked(address)
            val nextNonce = state.nextAvailableNonce
            val reserved = inFlightReservations.getOrPut(address) { mutableSetOf() }
            reserved.add(nextNonce)
            nextNonce
        }
    }

    suspend fun releaseReservation(address: String, nonce: Long) {
        mutexFor(address).withLock {
            inFlightReservations[address]?.remove(nonce)
        }
    }

    suspend fun <T> withReservedNonce(address: String, block: suspend (Long) -> T): T {
        val reserved = reserveNextNonce(address)
        return try {
            block(reserved)
        } finally {
            releaseReservation(address, reserved)
        }
    }

    private suspend fun readStateLocked(address: String): AccountNonceState {
        val confirmedNext = storage.getConfirmedNextNonce(address)
        val activeNonces = storage.getActiveNoncesForSender(address).toSet()
        val reserved = inFlightReservations[address]?.toSet() ?: emptySet()
        return AccountNonceState(
            address = address,
            confirmedNextNonce = confirmedNext,
            pendingNonces = activeNonces,
            reservedNonces = reserved
        )
    }
}
