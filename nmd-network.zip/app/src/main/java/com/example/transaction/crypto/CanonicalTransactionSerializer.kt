package com.example.transaction.crypto

import com.example.transaction.model.NmdTransaction
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/**
 * Deterministic canonical binary encoder for Stage 9 transactions.
 *
 * Uses domain separation, big-endian fixed-width integers/longs, and explicit 4-byte length prefixes
 * (avoiding DataOutputStream.writeUTF 64KB limitations and ambiguous string concatenation).
 */
object CanonicalTransactionSerializer {

    private val SIGN_DOMAIN = "NMD-TX-SIGN-V1\u0000".toByteArray(Charsets.UTF_8)
    private val ID_DOMAIN = "NMD-TX-ID-V1\u0000".toByteArray(Charsets.UTF_8)

    fun serializeForSigning(tx: NmdTransaction): ByteArray {
        return serializeCoreFields(SIGN_DOMAIN, tx)
    }

    fun serializeForTxId(tx: NmdTransaction): ByteArray {
        return serializeCoreFields(ID_DOMAIN, tx)
    }

    /**
     * Exact canonical wire size accounting for all fields, 64-byte Ed25519 signature, and 32-byte txId.
     */
    fun estimateSignedSerializedSizeBytes(tx: NmdTransaction): Int {
        val signingSize = serializeForSigning(tx).size
        return signingSize + 64 + 32
    }

    private fun serializeCoreFields(domainHeader: ByteArray, tx: NmdTransaction): ByteArray {
        val baos = ByteArrayOutputStream(256 + tx.payload.size)
        val dos = DataOutputStream(baos)

        dos.write(domainHeader)
        dos.writeInt(tx.protocolVersion)
        writeLengthPrefixedUtf8(dos, tx.chainId)
        writeLengthPrefixedUtf8(dos, tx.rawTxTypeName.trim().uppercase())
        writeLengthPrefixedUtf8(dos, tx.senderAddress)
        writeLengthPrefixedUtf8(dos, tx.recipientAddress)
        dos.writeLong(tx.amountUnits)
        dos.writeLong(tx.feeUnits)
        dos.writeLong(tx.nonce)
        dos.writeLong(tx.timestamp)
        writeLengthPrefixedUtf8(dos, tx.senderPublicKeyHex.lowercase())
        dos.writeInt(tx.payload.size)
        if (tx.payload.isNotEmpty()) {
            dos.write(tx.payload)
        }
        dos.flush()
        return baos.toByteArray()
    }

    private fun writeLengthPrefixedUtf8(dos: DataOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        dos.writeInt(bytes.size)
        if (bytes.isNotEmpty()) {
            dos.write(bytes)
        }
    }
}
