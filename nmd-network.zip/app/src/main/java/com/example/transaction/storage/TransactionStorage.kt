package com.example.transaction.storage

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.util.Base64
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionPropagationStatus
import com.example.transaction.model.TransactionType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.Closeable

@Entity(
    tableName = "mempool_transactions",
    indices = [
        Index(value = ["senderAddress", "nonce"]),
        Index(value = ["status"]),
        Index(value = ["feeUnits", "createdAtMs"]),
        Index(value = ["expiresAtMs"])
    ]
)
data class MempoolTransactionEntity(
    @PrimaryKey val txId: String,
    val chainId: String,
    val protocolVersion: Int,
    val senderAddress: String,
    val recipientAddress: String,
    val amountUnits: Long,
    val feeUnits: Long,
    val nonce: Long,
    val timestamp: Long,
    val txType: String,
    val senderPublicKeyHex: String,
    val signatureHex: String,
    val payloadB64: String,
    val status: String,
    val propagationStatus: String,
    val rejectionReason: String?,
    val receivedFromPeerId: String?,
    val confirmedBlockHeight: Long?,
    val confirmedBlockHash: String?,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    val expiresAtMs: Long,
    val feeMetadataJson: String
) {
    fun toDomainRecord(): MempoolTransactionRecord? {
        return try {
            val payloadBytes = if (payloadB64.isEmpty()) ByteArray(0) else Base64.decode(payloadB64, Base64.NO_WRAP)
            val tx = NmdTransaction(
                txId = txId,
                chainId = chainId,
                protocolVersion = protocolVersion,
                senderAddress = senderAddress,
                recipientAddress = recipientAddress,
                amountUnits = amountUnits,
                feeUnits = feeUnits,
                nonce = nonce,
                timestamp = timestamp,
                txType = TransactionType.fromWireName(txType),
                rawTxTypeName = txType,
                senderPublicKeyHex = senderPublicKeyHex,
                signatureHex = signatureHex,
                payload = payloadBytes
            )
            MempoolTransactionRecord(
                transaction = tx,
                status = MempoolTxStatus.valueOf(status),
                propagationStatus = try {
                    TransactionPropagationStatus.valueOf(propagationStatus)
                } catch (_: Exception) {
                    TransactionPropagationStatus.LOCAL_ONLY
                },
                rejectionReason = rejectionReason,
                receivedFromPeerId = receivedFromPeerId,
                confirmedBlockHeight = confirmedBlockHeight,
                confirmedBlockHash = confirmedBlockHash,
                createdAtMs = createdAtMs,
                updatedAtMs = updatedAtMs,
                expiresAtMs = expiresAtMs,
                feeMetadataJson = feeMetadataJson
            )
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        fun fromDomainRecord(record: MempoolTransactionRecord): MempoolTransactionEntity {
            val tx = record.transaction
            return MempoolTransactionEntity(
                txId = tx.txId.lowercase(),
                chainId = tx.chainId,
                protocolVersion = tx.protocolVersion,
                senderAddress = tx.senderAddress,
                recipientAddress = tx.recipientAddress,
                amountUnits = tx.amountUnits,
                feeUnits = tx.feeUnits,
                nonce = tx.nonce,
                timestamp = tx.timestamp,
                txType = tx.rawTxTypeName,
                senderPublicKeyHex = tx.senderPublicKeyHex.lowercase(),
                signatureHex = tx.signatureHex.lowercase(),
                payloadB64 = Base64.encodeToString(tx.payload, Base64.NO_WRAP),
                status = record.status.name,
                propagationStatus = record.propagationStatus.name,
                rejectionReason = record.rejectionReason,
                receivedFromPeerId = record.receivedFromPeerId,
                confirmedBlockHeight = record.confirmedBlockHeight,
                confirmedBlockHash = record.confirmedBlockHash,
                createdAtMs = record.createdAtMs,
                updatedAtMs = record.updatedAtMs,
                expiresAtMs = record.expiresAtMs,
                feeMetadataJson = record.feeMetadataJson
            )
        }
    }
}

@Entity(tableName = "account_nonces")
data class AccountNonceEntity(
    @PrimaryKey val address: String,
    val confirmedNextNonce: Long,
    val updatedAtMs: Long
)

/**
 * Permanent archival store for finalized transactions (Stage 17).
 * Guarantees historical P2P block synchronization works even after mempool pruning.
 */
@Entity(
    tableName = "confirmed_transactions",
    indices = [
        Index(value = ["blockHeight", "txIndex"]),
        Index(value = ["senderAddress", "blockHeight"]),
        Index(value = ["recipientAddress", "blockHeight"])
    ]
)
data class ConfirmedTransactionEntity(
    @PrimaryKey val txId: String,
    val chainId: String,
    val protocolVersion: Int,
    val senderAddress: String,
    val recipientAddress: String,
    val amountUnits: Long,
    val feeUnits: Long,
    val nonce: Long,
    val timestamp: Long,
    val txType: String,
    val senderPublicKeyHex: String,
    val signatureHex: String,
    val payloadB64: String,
    val blockHeight: Long,
    val blockHash: String,
    val txIndex: Int,
    val confirmedAtMs: Long
) {
    fun toConfirmedEntry(): ConfirmedTransactionEntry? {
        return try {
            val payloadBytes = if (payloadB64.isEmpty()) ByteArray(0) else Base64.decode(payloadB64, Base64.NO_WRAP)
            ConfirmedTransactionEntry(
                transaction = NmdTransaction(
                    txId = txId,
                    chainId = chainId,
                    protocolVersion = protocolVersion,
                    senderAddress = senderAddress,
                    recipientAddress = recipientAddress,
                    amountUnits = amountUnits,
                    feeUnits = feeUnits,
                    nonce = nonce,
                    timestamp = timestamp,
                    txType = TransactionType.fromWireName(txType),
                    rawTxTypeName = txType,
                    senderPublicKeyHex = senderPublicKeyHex,
                    signatureHex = signatureHex,
                    payload = payloadBytes
                ),
                blockHeight = blockHeight,
                blockHash = blockHash,
                txIndex = txIndex,
                confirmedAtMs = confirmedAtMs
            )
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        fun fromEntry(entry: ConfirmedTransactionEntry): ConfirmedTransactionEntity {
            val tx = entry.transaction
            return ConfirmedTransactionEntity(
                txId = tx.txId.lowercase(),
                chainId = tx.chainId,
                protocolVersion = tx.protocolVersion,
                senderAddress = tx.senderAddress,
                recipientAddress = tx.recipientAddress,
                amountUnits = tx.amountUnits,
                feeUnits = tx.feeUnits,
                nonce = tx.nonce,
                timestamp = tx.timestamp,
                txType = tx.rawTxTypeName,
                senderPublicKeyHex = tx.senderPublicKeyHex.lowercase(),
                signatureHex = tx.signatureHex.lowercase(),
                payloadB64 = Base64.encodeToString(tx.payload, Base64.NO_WRAP),
                blockHeight = entry.blockHeight,
                blockHash = entry.blockHash.lowercase(),
                txIndex = entry.txIndex,
                confirmedAtMs = entry.confirmedAtMs
            )
        }
    }
}

/**
 * Persistent deterministic Ledger Account State (Stage 17).
 */
@Entity(
    tableName = "account_states",
    indices = [Index(value = ["updatedAtHeight"])]
)
data class AccountStateEntity(
    @PrimaryKey val address: String,
    val balanceUnits: Long,
    val confirmedNonce: Long,
    val isValidator: Boolean,
    val updatedAtHeight: Long,
    val updatedAtMs: Long
) {
    fun toDomain() = AccountStateRecord(
        address = address,
        balanceUnits = balanceUnits,
        confirmedNonce = confirmedNonce,
        isValidator = isValidator,
        updatedAtHeight = updatedAtHeight,
        updatedAtMs = updatedAtMs
    )

    companion object {
        fun fromDomain(record: AccountStateRecord) = AccountStateEntity(
            address = record.address,
            balanceUnits = record.balanceUnits,
            confirmedNonce = record.confirmedNonce,
            isValidator = record.isValidator,
            updatedAtHeight = record.updatedAtHeight,
            updatedAtMs = record.updatedAtMs
        )
    }
}

data class ConfirmedTransactionEntry(
    val transaction: NmdTransaction,
    val blockHeight: Long,
    val blockHash: String,
    val txIndex: Int,
    val confirmedAtMs: Long
)

data class AccountStateRecord(
    val address: String,
    val balanceUnits: Long = 0L,
    val confirmedNonce: Long = 0L,
    val isValidator: Boolean = false,
    val updatedAtHeight: Long = 0L,
    val updatedAtMs: Long = 0L
)

@Dao
interface MempoolDao {

    @Query("SELECT * FROM mempool_transactions WHERE txId = :txId LIMIT 1")
    suspend fun getByTxId(txId: String): MempoolTransactionEntity?

    @Query("SELECT * FROM mempool_transactions ORDER BY updatedAtMs DESC LIMIT :limit")
    fun observeRecentTransactions(limit: Int = 200): Flow<List<MempoolTransactionEntity>>

    @Query("SELECT * FROM mempool_transactions ORDER BY updatedAtMs DESC")
    suspend fun getAllTransactions(): List<MempoolTransactionEntity>

    @Query(
        "SELECT * FROM mempool_transactions WHERE status = 'VALIDATED' " +
            "ORDER BY feeUnits DESC, nonce ASC, createdAtMs ASC, txId ASC LIMIT :limit"
    )
    suspend fun getValidatedCandidates(limit: Int): List<MempoolTransactionEntity>

    @Query(
        "SELECT * FROM mempool_transactions WHERE senderAddress = :sender AND status IN ('PENDING', 'VALIDATED', 'QUEUED') " +
            "ORDER BY nonce ASC"
    )
    suspend fun getActiveBySender(sender: String): List<MempoolTransactionEntity>

    @Query(
        "SELECT EXISTS(SELECT 1 FROM mempool_transactions WHERE senderAddress = :sender AND nonce = :nonce " +
            "AND status IN ('PENDING', 'VALIDATED', 'QUEUED'))"
    )
    suspend fun hasActiveSenderNonce(sender: String, nonce: Long): Boolean

    @Query("SELECT COUNT(*) FROM mempool_transactions WHERE status IN ('PENDING', 'VALIDATED', 'QUEUED')")
    suspend fun getActivePoolCount(): Int

    @Query("SELECT COUNT(*) FROM mempool_transactions WHERE senderAddress = :sender AND status IN ('PENDING', 'VALIDATED', 'QUEUED')")
    suspend fun getActiveSenderCount(sender: String): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAbortOnConflict(entity: MempoolTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: MempoolTransactionEntity)

    @Query("UPDATE mempool_transactions SET status = :newStatus, updatedAtMs = :updatedAtMs WHERE txId = :txId")
    suspend fun updateStatus(txId: String, newStatus: String, updatedAtMs: Long)

    @Query("UPDATE mempool_transactions SET propagationStatus = :propStatus, updatedAtMs = :updatedAtMs WHERE txId = :txId")
    suspend fun updatePropagationStatus(txId: String, propStatus: String, updatedAtMs: Long)

    @Query(
        "UPDATE mempool_transactions SET status = 'CONFIRMED', confirmedBlockHeight = :blockHeight, " +
            "confirmedBlockHash = :blockHash, updatedAtMs = :updatedAtMs WHERE txId = :txId"
    )
    suspend fun markConfirmed(txId: String, blockHeight: Long, blockHash: String, updatedAtMs: Long)

    @Query(
        "UPDATE mempool_transactions SET status = 'EXPIRED', updatedAtMs = :nowMs " +
            "WHERE status IN ('PENDING', 'VALIDATED', 'QUEUED') AND expiresAtMs <= :nowMs"
    )
    suspend fun markExpired(nowMs: Long): Int

    @Query("DELETE FROM mempool_transactions WHERE txId = :txId")
    suspend fun deleteByTxId(txId: String): Int

    @Query(
        "DELETE FROM mempool_transactions WHERE status = 'REJECTED' AND txId NOT IN " +
            "(SELECT txId FROM mempool_transactions WHERE status = 'REJECTED' ORDER BY updatedAtMs DESC LIMIT :keepLimit)"
    )
    suspend fun trimRejectedOverflow(keepLimit: Int): Int

    @Query("SELECT confirmedNextNonce FROM account_nonces WHERE address = :address LIMIT 1")
    suspend fun getConfirmedNextNonce(address: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccountNonce(entity: AccountNonceEntity)

    @Transaction
    suspend fun confirmTransactionAndAdvanceNonce(
        txId: String,
        senderAddress: String,
        txNonce: Long,
        blockHeight: Long,
        blockHash: String,
        updatedAtMs: Long
    ) {
        markConfirmed(txId, blockHeight, blockHash, updatedAtMs)
        val currentConfirmed = getConfirmedNextNonce(senderAddress) ?: 0L
        val nextConfirmed = maxOf(currentConfirmed, txNonce + 1L)
        upsertAccountNonce(AccountNonceEntity(senderAddress, nextConfirmed, updatedAtMs))
    }

    @Transaction
    suspend fun upsertConfirmedFromSyncAndAdvanceNonce(entity: MempoolTransactionEntity) {
        upsert(entity)
        val currentConfirmed = getConfirmedNextNonce(entity.senderAddress) ?: 0L
        val nextConfirmed = maxOf(currentConfirmed, entity.nonce + 1L)
        upsertAccountNonce(AccountNonceEntity(entity.senderAddress, nextConfirmed, entity.updatedAtMs))
    }

    // Confirmed archival transactions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConfirmedArchive(entries: List<ConfirmedTransactionEntity>)

    @Query("SELECT * FROM confirmed_transactions WHERE txId = :txId LIMIT 1")
    suspend fun getConfirmedArchiveById(txId: String): ConfirmedTransactionEntity?

    @Query(
        "SELECT * FROM confirmed_transactions WHERE senderAddress = :address OR recipientAddress = :address " +
            "ORDER BY blockHeight DESC, txIndex DESC LIMIT :limit"
    )
    suspend fun getConfirmedArchiveForAddress(address: String, limit: Int): List<ConfirmedTransactionEntity>

    @Query("SELECT * FROM confirmed_transactions WHERE blockHeight = :height ORDER BY txIndex ASC")
    suspend fun getConfirmedArchiveForBlock(height: Long): List<ConfirmedTransactionEntity>

    // Account Ledger State
    @Query("SELECT * FROM account_states ORDER BY address ASC")
    suspend fun getAllAccountStates(): List<AccountStateEntity>

    @Query("SELECT * FROM account_states ORDER BY address ASC")
    fun observeAllAccountStates(): Flow<List<AccountStateEntity>>

    @Query("SELECT * FROM account_states WHERE address = :address LIMIT 1")
    suspend fun getAccountState(address: String): AccountStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccountStates(states: List<AccountStateEntity>)

    @Query("DELETE FROM account_states")
    suspend fun clearAccountStates()
}

@Database(
    entities = [
        MempoolTransactionEntity::class,
        AccountNonceEntity::class,
        ConfirmedTransactionEntity::class,
        AccountStateEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class TransactionDatabase : RoomDatabase() {
    abstract fun mempoolDao(): MempoolDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `confirmed_transactions` (
                        `txId` TEXT NOT NULL,
                        `chainId` TEXT NOT NULL,
                        `protocolVersion` INTEGER NOT NULL,
                        `senderAddress` TEXT NOT NULL,
                        `recipientAddress` TEXT NOT NULL,
                        `amountUnits` INTEGER NOT NULL,
                        `feeUnits` INTEGER NOT NULL,
                        `nonce` INTEGER NOT NULL,
                        `timestamp` INTEGER NOT NULL,
                        `txType` TEXT NOT NULL,
                        `senderPublicKeyHex` TEXT NOT NULL,
                        `signatureHex` TEXT NOT NULL,
                        `payloadB64` TEXT NOT NULL,
                        `blockHeight` INTEGER NOT NULL,
                        `blockHash` TEXT NOT NULL,
                        `txIndex` INTEGER NOT NULL,
                        `confirmedAtMs` INTEGER NOT NULL,
                        PRIMARY KEY(`txId`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_confirmed_transactions_blockHeight_txIndex` ON `confirmed_transactions` (`blockHeight`, `txIndex`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_confirmed_transactions_senderAddress_blockHeight` ON `confirmed_transactions` (`senderAddress`, `blockHeight`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_confirmed_transactions_recipientAddress_blockHeight` ON `confirmed_transactions` (`recipientAddress`, `blockHeight`)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `account_states` (
                        `address` TEXT NOT NULL,
                        `balanceUnits` INTEGER NOT NULL,
                        `confirmedNonce` INTEGER NOT NULL,
                        `isValidator` INTEGER NOT NULL,
                        `updatedAtHeight` INTEGER NOT NULL,
                        `updatedAtMs` INTEGER NOT NULL,
                        PRIMARY KEY(`address`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_account_states_updatedAtHeight` ON `account_states` (`updatedAtHeight`)")
            }
        }

        fun buildPersistent(context: Context, dbName: String): TransactionDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                TransactionDatabase::class.java,
                dbName
            ).addMigrations(MIGRATION_1_2).build()
        }

        fun buildInMemory(context: Context): TransactionDatabase {
            return Room.inMemoryDatabaseBuilder(
                context.applicationContext,
                TransactionDatabase::class.java
            ).addMigrations(MIGRATION_1_2).build()
        }
    }
}

sealed class MempoolInsertResult {
    data object Inserted : MempoolInsertResult()
    data class Duplicate(val reason: String) : MempoolInsertResult()
    data class Error(val reason: String) : MempoolInsertResult()
}

interface TransactionStorage : Closeable {
    fun observeTransactions(): Flow<List<MempoolTransactionRecord>>
    suspend fun getByTxId(txId: String): MempoolTransactionRecord?
    suspend fun getAllTransactions(): List<MempoolTransactionRecord>
    suspend fun getValidatedCandidates(limit: Int): List<MempoolTransactionRecord>
    suspend fun getActiveBySender(senderAddress: String): List<MempoolTransactionRecord>
    suspend fun getActiveNoncesForSender(senderAddress: String): List<Long>
    suspend fun getConfirmedNextNonce(address: String): Long
    suspend fun getActivePoolCount(): Int
    suspend fun insertAbortDuplicate(record: MempoolTransactionRecord): MempoolInsertResult
    suspend fun upsertRecord(record: MempoolTransactionRecord)
    suspend fun updateStatus(txId: String, status: MempoolTxStatus, updatedAtMs: Long)
    suspend fun updatePropagationStatus(txId: String, propagationStatus: TransactionPropagationStatus, updatedAtMs: Long)
    suspend fun confirmTransactionsInBlock(txIds: List<String>, blockHeight: Long, blockHash: String, updatedAtMs: Long): Int
    suspend fun confirmSyncedTransactionsInBlock(records: List<MempoolTransactionRecord>, updatedAtMs: Long): Int
    suspend fun pruneExpired(nowMs: Long): Int
    suspend fun trimRejectedHistory(keepLimit: Int): Int
    suspend fun removeTransaction(txId: String): Boolean

    // Stage 17 Archival + Account State operations
    suspend fun saveConfirmedArchive(entries: List<ConfirmedTransactionEntry>)
    suspend fun getConfirmedArchiveById(txId: String): ConfirmedTransactionEntry?
    suspend fun getConfirmedArchiveForAddress(address: String, limit: Int = 100): List<ConfirmedTransactionEntry>
    suspend fun getConfirmedArchiveForBlock(height: Long): List<ConfirmedTransactionEntry>
    suspend fun getAllAccountStates(): List<AccountStateRecord>
    fun observeAllAccountStates(): Flow<List<AccountStateRecord>>
    suspend fun getAccountState(address: String): AccountStateRecord?
    suspend fun upsertAccountStates(states: List<AccountStateRecord>)
}

class RoomTransactionStorage(
    private val database: TransactionDatabase,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : TransactionStorage {

    constructor(
        context: Context,
        dbName: String = "nmd_tx_mempool.db",
        inMemory: Boolean = false
    ) : this(
        database = if (inMemory) {
            TransactionDatabase.buildInMemory(context)
        } else {
            TransactionDatabase.buildPersistent(context, dbName)
        }
    )

    private val dao = database.mempoolDao()

    override fun observeTransactions(): Flow<List<MempoolTransactionRecord>> {
        return dao.observeRecentTransactions().map { list ->
            list.mapNotNull { it.toDomainRecord() }
        }
    }

    override suspend fun getByTxId(txId: String): MempoolTransactionRecord? = withContext(ioDispatcher) {
        dao.getByTxId(txId.lowercase())?.toDomainRecord()
    }

    override suspend fun getAllTransactions(): List<MempoolTransactionRecord> = withContext(ioDispatcher) {
        dao.getAllTransactions().mapNotNull { it.toDomainRecord() }
    }

    override suspend fun getValidatedCandidates(limit: Int): List<MempoolTransactionRecord> = withContext(ioDispatcher) {
        dao.getValidatedCandidates(limit).mapNotNull { it.toDomainRecord() }
    }

    override suspend fun getActiveBySender(senderAddress: String): List<MempoolTransactionRecord> = withContext(ioDispatcher) {
        dao.getActiveBySender(senderAddress).mapNotNull { it.toDomainRecord() }
    }

    override suspend fun getActiveNoncesForSender(senderAddress: String): List<Long> = withContext(ioDispatcher) {
        dao.getActiveBySender(senderAddress).map { it.nonce }
    }

    override suspend fun getConfirmedNextNonce(address: String): Long = withContext(ioDispatcher) {
        dao.getConfirmedNextNonce(address) ?: 0L
    }

    override suspend fun getActivePoolCount(): Int = withContext(ioDispatcher) {
        dao.getActivePoolCount()
    }

    override suspend fun insertAbortDuplicate(record: MempoolTransactionRecord): MempoolInsertResult = withContext(ioDispatcher) {
        val existing = dao.getByTxId(record.transaction.txId.lowercase())
        if (existing != null) {
            return@withContext MempoolInsertResult.Duplicate("Transaction ${record.transaction.shortTxId} already exists in storage")
        }
        return@withContext try {
            dao.insertAbortOnConflict(MempoolTransactionEntity.fromDomainRecord(record))
            MempoolInsertResult.Inserted
        } catch (e: SQLiteConstraintException) {
            MempoolInsertResult.Duplicate("Duplicate txId constraint violation: ${e.message}")
        } catch (e: Exception) {
            MempoolInsertResult.Error(e.message ?: "Failed inserting transaction")
        }
    }

    override suspend fun upsertRecord(record: MempoolTransactionRecord) = withContext(ioDispatcher) {
        dao.upsert(MempoolTransactionEntity.fromDomainRecord(record))
    }

    override suspend fun updateStatus(txId: String, status: MempoolTxStatus, updatedAtMs: Long) = withContext(ioDispatcher) {
        dao.updateStatus(txId.lowercase(), status.name, updatedAtMs)
    }

    override suspend fun updatePropagationStatus(
        txId: String,
        propagationStatus: TransactionPropagationStatus,
        updatedAtMs: Long
    ) = withContext(ioDispatcher) {
        dao.updatePropagationStatus(txId.lowercase(), propagationStatus.name, updatedAtMs)
    }

    override suspend fun confirmTransactionsInBlock(
        txIds: List<String>,
        blockHeight: Long,
        blockHash: String,
        updatedAtMs: Long
    ): Int = withContext(ioDispatcher) {
        var confirmedCount = 0
        val archivalEntries = mutableListOf<ConfirmedTransactionEntity>()
        txIds.forEachIndexed { idx, rawId ->
            val entity = dao.getByTxId(rawId.lowercase()) ?: return@forEachIndexed
            dao.confirmTransactionAndAdvanceNonce(
                txId = entity.txId,
                senderAddress = entity.senderAddress,
                txNonce = entity.nonce,
                blockHeight = blockHeight,
                blockHash = blockHash.lowercase(),
                updatedAtMs = updatedAtMs
            )
            val record = entity.toDomainRecord()
            if (record != null) {
                archivalEntries.add(
                    ConfirmedTransactionEntity.fromEntry(
                        ConfirmedTransactionEntry(
                            transaction = record.transaction,
                            blockHeight = blockHeight,
                            blockHash = blockHash.lowercase(),
                            txIndex = idx,
                            confirmedAtMs = updatedAtMs
                        )
                    )
                )
            }
            confirmedCount++
        }
        if (archivalEntries.isNotEmpty()) {
            dao.upsertConfirmedArchive(archivalEntries)
        }
        confirmedCount
    }

    override suspend fun confirmSyncedTransactionsInBlock(
        records: List<MempoolTransactionRecord>,
        updatedAtMs: Long
    ): Int = withContext(ioDispatcher) {
        var confirmedCount = 0
        val archivalEntries = mutableListOf<ConfirmedTransactionEntity>()
        records.forEachIndexed { idx, rec ->
            dao.upsertConfirmedFromSyncAndAdvanceNonce(MempoolTransactionEntity.fromDomainRecord(rec))
            archivalEntries.add(
                ConfirmedTransactionEntity.fromEntry(
                    ConfirmedTransactionEntry(
                        transaction = rec.transaction,
                        blockHeight = rec.confirmedBlockHeight ?: 0L,
                        blockHash = rec.confirmedBlockHash?.lowercase().orEmpty(),
                        txIndex = idx,
                        confirmedAtMs = updatedAtMs
                    )
                )
            )
            confirmedCount++
        }
        if (archivalEntries.isNotEmpty()) {
            dao.upsertConfirmedArchive(archivalEntries)
        }
        confirmedCount
    }

    override suspend fun pruneExpired(nowMs: Long): Int = withContext(ioDispatcher) {
        dao.markExpired(nowMs)
    }

    override suspend fun trimRejectedHistory(keepLimit: Int): Int = withContext(ioDispatcher) {
        dao.trimRejectedOverflow(keepLimit)
    }

    override suspend fun removeTransaction(txId: String): Boolean = withContext(ioDispatcher) {
        dao.deleteByTxId(txId.lowercase()) > 0
    }

    override suspend fun saveConfirmedArchive(entries: List<ConfirmedTransactionEntry>) = withContext(ioDispatcher) {
        if (entries.isNotEmpty()) {
            dao.upsertConfirmedArchive(entries.map { ConfirmedTransactionEntity.fromEntry(it) })
        }
    }

    override suspend fun getConfirmedArchiveById(txId: String): ConfirmedTransactionEntry? = withContext(ioDispatcher) {
        dao.getConfirmedArchiveById(txId.lowercase())?.toConfirmedEntry()
    }

    override suspend fun getConfirmedArchiveForAddress(address: String, limit: Int): List<ConfirmedTransactionEntry> =
        withContext(ioDispatcher) {
            dao.getConfirmedArchiveForAddress(address, limit).mapNotNull { it.toConfirmedEntry() }
        }

    override suspend fun getConfirmedArchiveForBlock(height: Long): List<ConfirmedTransactionEntry> =
        withContext(ioDispatcher) {
            dao.getConfirmedArchiveForBlock(height).mapNotNull { it.toConfirmedEntry() }
        }

    override suspend fun getAllAccountStates(): List<AccountStateRecord> = withContext(ioDispatcher) {
        dao.getAllAccountStates().map { it.toDomain() }
    }

    override fun observeAllAccountStates(): Flow<List<AccountStateRecord>> {
        return dao.observeAllAccountStates().map { list -> list.map { it.toDomain() } }
    }

    override suspend fun getAccountState(address: String): AccountStateRecord? = withContext(ioDispatcher) {
        dao.getAccountState(address)?.toDomain()
    }

    override suspend fun upsertAccountStates(states: List<AccountStateRecord>) = withContext(ioDispatcher) {
        if (states.isNotEmpty()) {
            dao.upsertAccountStates(states.map { AccountStateEntity.fromDomain(it) })
        }
    }

    override fun close() {
        database.close()
    }
}
