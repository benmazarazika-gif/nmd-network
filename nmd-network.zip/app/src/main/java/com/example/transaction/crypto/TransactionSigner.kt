package com.example.transaction.crypto

import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.crypto.repository.IdentityRepository
import com.example.transaction.model.NmdTransaction

/**
 * Local transaction hashing, Ed25519 signing, and signature verification service.
 *
 * Security rules:
 * - Private keys never leave secure storage except transiently inside [IdentityRepository.signRawData].
 * - Private keys are never persisted into [NmdTransaction] or transmitted over P2P.
 */
class TransactionSigner(
    val cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
) {
    companion object {
        private val HEX_64_REGEX = Regex("^[0-9a-f]{64}$")
        private val HEX_128_REGEX = Regex("^[0-9a-f]{128}$")

        fun isValidSha256Hex(hex: String): Boolean = HEX_64_REGEX.matches(hex.lowercase())
        fun isValidEd25519PublicKeyHex(hex: String): Boolean = HEX_64_REGEX.matches(hex.lowercase())
        fun isValidEd25519SignatureHex(hex: String): Boolean = HEX_128_REGEX.matches(hex.lowercase())
    }

    fun computeTransactionId(tx: NmdTransaction): String {
        val idPreimage = CanonicalTransactionSerializer.serializeForTxId(tx)
        return cryptoProvider.toHex(cryptoProvider.sha256(idPreimage))
    }

    /**
     * Signs an unsigned transaction using the device's hardware/software-protected Ed25519 identity.
     */
    fun signWithDeviceIdentity(
        unsignedTx: NmdTransaction,
        identityRepository: IdentityRepository
    ): NmdTransaction {
        val identity = identityRepository.getPublicIdentity()
            ?: throw IllegalStateException("Cannot sign transaction: no local Ed25519 node identity exists")

        val pubKeyBytes = cryptoProvider.fromHex(identity.publicKeyHex)
        val derivedSender = NmdAddressCodec.deriveAddressFromPublicKey(pubKeyBytes, cryptoProvider)

        val prepared = unsignedTx.copy(
            senderAddress = derivedSender,
            senderPublicKeyHex = identity.publicKeyHex.lowercase()
        )
        val computedTxId = computeTransactionId(prepared)
        val signingBytes = CanonicalTransactionSerializer.serializeForSigning(prepared)
        val signatureBytes = identityRepository.signRawData(signingBytes)
        val signatureHex = cryptoProvider.toHex(signatureBytes)

        return prepared.copy(
            txId = computedTxId,
            signatureHex = signatureHex
        )
    }

    /**
     * Signs an unsigned transaction with an explicit Ed25519 key pair (for multi-node automated tests).
     * Never persists or logs private key bytes.
     */
    fun signWithKeyPair(
        unsignedTx: NmdTransaction,
        privateKeyBytes: ByteArray
    ): NmdTransaction {
        val pubKeyBytes = cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytes)
        val pubKeyHex = cryptoProvider.toHex(pubKeyBytes)
        val derivedSender = NmdAddressCodec.deriveAddressFromPublicKey(pubKeyBytes, cryptoProvider)

        val prepared = unsignedTx.copy(
            senderAddress = derivedSender,
            senderPublicKeyHex = pubKeyHex
        )
        val computedTxId = computeTransactionId(prepared)
        val signingBytes = CanonicalTransactionSerializer.serializeForSigning(prepared)
        val signatureBytes = cryptoProvider.sign(privateKeyBytes, signingBytes)

        return prepared.copy(
            txId = computedTxId,
            signatureHex = cryptoProvider.toHex(signatureBytes)
        )
    }

    fun verifyTransactionId(tx: NmdTransaction): Boolean {
        if (!isValidSha256Hex(tx.txId)) return false
        val expectedTxId = computeTransactionId(tx)
        return expectedTxId.equals(tx.txId, ignoreCase = true)
    }

    fun verifySignature(tx: NmdTransaction): Boolean {
        if (!isValidEd25519PublicKeyHex(tx.senderPublicKeyHex)) return false
        if (!isValidEd25519SignatureHex(tx.signatureHex)) return false

        return try {
            val pubKeyBytes = cryptoProvider.fromHex(tx.senderPublicKeyHex)
            if (pubKeyBytes.all { it == 0.toByte() }) return false
            val sigBytes = cryptoProvider.fromHex(tx.signatureHex)
            val signingBytes = CanonicalTransactionSerializer.serializeForSigning(tx)
            cryptoProvider.verify(pubKeyBytes, signingBytes, sigBytes)
        } catch (_: Exception) {
            false
        }
    }
}
