package com.example.transaction.crypto

import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.data.NmdAddressValidationResult
import com.example.data.NmdAddressValidator

/**
 * Deterministic cryptographic derivation & verification of NMD addresses from Ed25519 public keys.
 *
 * Output format: "nmd1" + 39 Bech32-charset characters = 43 characters total.
 * Strictly compatible with [NmdAddressValidator.validateDemoAddress] while adding real
 * SHA-256 public-key binding and an embedded 4-byte checksum.
 */
object NmdAddressCodec {

    private const val ADDRESS_DOMAIN = "NMD-ADDR-V1\u0000"
    private const val CHECKSUM_DOMAIN = "NMD-ADDR-CHK-V1\u0000"
    private const val BECH32_ALPHABET = "023456789acdefghjklmnpqrstuvwxyz"

    fun deriveAddressFromPublicKey(
        publicKeyBytes: ByteArray,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): String {
        require(publicKeyBytes.size == 32) { "Ed25519 public key must be exactly 32 bytes" }

        val domainBytes = ADDRESS_DOMAIN.toByteArray(Charsets.UTF_8)
        val addrInput = ByteArray(domainBytes.size + publicKeyBytes.size)
        System.arraycopy(domainBytes, 0, addrInput, 0, domainBytes.size)
        System.arraycopy(publicKeyBytes, 0, addrInput, domainBytes.size, publicKeyBytes.size)

        val payload20 = cryptoProvider.sha256(addrInput).copyOfRange(0, 20)

        val chkDomainBytes = CHECKSUM_DOMAIN.toByteArray(Charsets.UTF_8)
        val chkInput = ByteArray(chkDomainBytes.size + payload20.size)
        System.arraycopy(chkDomainBytes, 0, chkInput, 0, chkDomainBytes.size)
        System.arraycopy(payload20, 0, chkInput, chkDomainBytes.size, payload20.size)

        val checksum4 = cryptoProvider.sha256(chkInput).copyOfRange(0, 4)

        val raw24 = ByteArray(24)
        System.arraycopy(payload20, 0, raw24, 0, 20)
        System.arraycopy(checksum4, 0, raw24, 20, 4)

        return NmdAddressValidator.DEMO_PREFIX + encodeBase32Bech32(raw24)
    }

    fun deriveAddressFromPublicKeyHex(
        publicKeyHex: String,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): String? {
        return try {
            val bytes = cryptoProvider.fromHex(publicKeyHex)
            if (bytes.size != 32) return null
            deriveAddressFromPublicKey(bytes, cryptoProvider)
        } catch (_: Exception) {
            null
        }
    }

    fun verifySenderAddressMatchesPublicKey(
        senderAddress: String,
        publicKeyBytes: ByteArray,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): Boolean {
        if (publicKeyBytes.size != 32) return false
        val derived = deriveAddressFromPublicKey(publicKeyBytes, cryptoProvider)
        return senderAddress == derived
    }

    fun isValidAddressFormat(address: String): Boolean {
        return NmdAddressValidator.validateDemoAddress(address) is NmdAddressValidationResult.Valid
    }

    private fun encodeBase32Bech32(data: ByteArray): String {
        val out = StringBuilder((data.size * 8 + 4) / 5)
        var buffer = 0
        var bitsLeft = 0
        for (b in data) {
            buffer = (buffer shl 8) or (b.toInt() and 0xFF)
            bitsLeft += 8
            while (bitsLeft >= 5) {
                val index = (buffer ushr (bitsLeft - 5)) and 0x1F
                out.append(BECH32_ALPHABET[index])
                bitsLeft -= 5
            }
        }
        if (bitsLeft > 0) {
            val index = (buffer shl (5 - bitsLeft)) and 0x1F
            out.append(BECH32_ALPHABET[index])
        }
        return out.toString()
    }
}
