package com.example.transaction.fee

import com.example.transaction.crypto.CanonicalTransactionSerializer
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionType
import org.json.JSONObject

data class FeeConfig(
    val feeRuleVersion: Int = 1,
    val minimumFeeUnits: Long = 10_000L, // 0.01 NMD
    val baseFeeUnits: Long = 5_000L,     // 0.005 NMD
    val perByteFeeUnits: Long = 10L,     // 0.00001 NMD per canonical byte
    val transferMultiplierBps: Int = 10_000,    // 1.00x
    val accountInitMultiplierBps: Int = 15_000, // 1.50x
    val maxFeeUnits: Long = 100L * NmdAmountCodec.UNITS_PER_NMD // 100 NMD sanity ceiling
)

data class FeeEstimate(
    val minimumRequiredFeeUnits: Long,
    val estimatedSizeBytes: Int,
    val baseFeeUnits: Long,
    val sizeComponentUnits: Long,
    val typeMultiplierBps: Int,
    val feeRuleVersion: Int,
    val txType: TransactionType
) {
    val formattedMinimumFee: String
        get() = "${NmdAmountCodec.formatUnitsToNmd(minimumRequiredFeeUnits)} NMD"

    fun toMetadataJson(): String {
        return JSONObject().apply {
            put("fee_rule_version", feeRuleVersion)
            put("tx_type", txType.name)
            put("estimated_size_bytes", estimatedSizeBytes)
            put("base_fee_units", baseFeeUnits)
            put("size_component_units", sizeComponentUnits)
            put("type_multiplier_bps", typeMultiplierBps)
            put("minimum_required_fee_units", minimumRequiredFeeUnits)
        }.toString()
    }
}

sealed class FeeValidationResult {
    data class Valid(val estimate: FeeEstimate) : FeeValidationResult()
    data class Invalid(val reason: String) : FeeValidationResult()
}

/**
 * Deterministic Stage 9 Transaction Fee Calculator.
 *
 * Computes configurable minimum fees considering canonical serialized transaction size
 * and transaction type without introducing speculative fee markets or real tokens.
 */
class TransactionFeeCalculator(
    val config: FeeConfig = FeeConfig()
) {
    fun estimateFee(tx: NmdTransaction): FeeEstimate {
        val sizeBytes = CanonicalTransactionSerializer.estimateSignedSerializedSizeBytes(tx)
        return computeFromSizeAndType(sizeBytes, tx.txType)
    }

    fun estimateFeeForDraft(
        txType: TransactionType,
        payloadSizeBytes: Int,
        chainId: String = "nmd-local-dev-1"
    ): FeeEstimate {
        // Exact canonical wire overhead matching CanonicalTransactionSerializer:
        // domain(15) + proto(4) + chain(4+len) + type(4+len) + sender(4+43) + recipient(4+43)
        // + amount/fee/nonce/ts(32) + pubKeyHex(4+64) + payload(4+len) + sig(64) + txId(32)
        val typeNameBytes = txType.name.toByteArray(Charsets.UTF_8).size
        val chainBytes = chainId.toByteArray(Charsets.UTF_8).size
        val estimatedSizeBytes =
            15 + 4 + (4 + chainBytes) + (4 + typeNameBytes) +
            (4 + 43) + (4 + 43) + 32 + (4 + 64) + 4 + payloadSizeBytes.coerceAtLeast(0) + 96
        return computeFromSizeAndType(estimatedSizeBytes, txType)
    }

    fun validateFee(tx: NmdTransaction): FeeValidationResult {
        if (tx.feeUnits <= 0L) {
            return FeeValidationResult.Invalid("Transaction fee must be strictly positive")
        }
        if (tx.feeUnits > config.maxFeeUnits) {
            return FeeValidationResult.Invalid("Transaction fee (${tx.feeUnits}) exceeds configured sanity cap (${config.maxFeeUnits})")
        }
        // Safe Long overflow guard for amount + fee
        if (tx.amountUnits > Long.MAX_VALUE - tx.feeUnits) {
            return FeeValidationResult.Invalid("Amount + fee exceeds 64-bit integer range")
        }
        val estimate = estimateFee(tx)
        if (tx.feeUnits < estimate.minimumRequiredFeeUnits) {
            return FeeValidationResult.Invalid(
                "Fee ${NmdAmountCodec.formatUnitsToNmd(tx.feeUnits)} NMD below required minimum ${estimate.formattedMinimumFee}"
            )
        }
        return FeeValidationResult.Valid(estimate)
    }

    private fun computeFromSizeAndType(sizeBytes: Int, txType: TransactionType): FeeEstimate {
        val multiplierBps = when (txType) {
            TransactionType.TRANSFER -> config.transferMultiplierBps
            TransactionType.ACCOUNT_INITIALIZATION,
            TransactionType.VALIDATOR_REGISTER,
            TransactionType.VALIDATOR_EXIT -> config.accountInitMultiplierBps
            TransactionType.FUTURE_SYSTEM_TRANSACTION, TransactionType.UNKNOWN -> config.transferMultiplierBps
        }
        val sizeComponent = sizeBytes.toLong() * config.perByteFeeUnits
        val rawUnits = config.baseFeeUnits + sizeComponent
        val scaledUnits = (rawUnits * multiplierBps.toLong() + 9_999L) / 10_000L
        val typeFloor = (config.minimumFeeUnits * multiplierBps.toLong()) / 10_000L
        val finalFee = maxOf(typeFloor, scaledUnits)

        return FeeEstimate(
            minimumRequiredFeeUnits = finalFee,
            estimatedSizeBytes = sizeBytes,
            baseFeeUnits = config.baseFeeUnits,
            sizeComponentUnits = sizeComponent,
            typeMultiplierBps = multiplierBps,
            feeRuleVersion = config.feeRuleVersion,
            txType = txType
        )
    }
}
