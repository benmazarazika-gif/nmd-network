package com.example.transaction.model

import android.util.Base64
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Extensible Stage 9 Transaction Types.
 *
 * - TRANSFER: Active in Stage 9 (peer-to-peer value transfer preparation, unconfirmed in mempool).
 * - ACCOUNT_INITIALIZATION: Active in Stage 9 (explicit account/nonce state registration preparation).
 * - FUTURE_SYSTEM_TRANSACTION: Reserved for Stage 10+ consensus/staking/protocol operations;
 *   explicitly disabled in Stage 9 (no token issuance or system rewards activated).
 * - UNKNOWN: Placeholder for unsupported wire values; strictly rejected by validation.
 */
enum class TransactionType(val isActiveInCurrentStage: Boolean) {
    TRANSFER(isActiveInCurrentStage = true),
    ACCOUNT_INITIALIZATION(isActiveInCurrentStage = true),
    VALIDATOR_REGISTER(isActiveInCurrentStage = true),
    VALIDATOR_EXIT(isActiveInCurrentStage = true),
    FUTURE_SYSTEM_TRANSACTION(isActiveInCurrentStage = false),
    UNKNOWN(isActiveInCurrentStage = false);

    companion object {
        fun fromWireName(raw: String?): TransactionType {
            if (raw.isNullOrBlank()) return UNKNOWN
            return when (raw.trim().uppercase()) {
                "TRANSFER" -> TRANSFER
                "ACCOUNT_INITIALIZATION" -> ACCOUNT_INITIALIZATION
                "VALIDATOR_REGISTER" -> VALIDATOR_REGISTER
                "VALIDATOR_EXIT" -> VALIDATOR_EXIT
                "FUTURE_SYSTEM_TRANSACTION" -> FUTURE_SYSTEM_TRANSACTION
                else -> UNKNOWN
            }
        }
    }
}

data class ValidatorTransactionPayload(
    val nodeId: String,
    val publicKeyHex: String,
    val displayName: String,
    val votingPower: Long = 1L
) {
    fun toJsonBytes(): ByteArray = JSONObject().apply {
        put("node_id", nodeId)
        put("public_key_hex", publicKeyHex.lowercase())
        put("display_name", displayName)
        put("voting_power", votingPower)
    }.toString().toByteArray(Charsets.UTF_8)

    companion object {
        fun fromBytes(bytes: ByteArray): ValidatorTransactionPayload? {
            if (bytes.isEmpty()) return null
            return try {
                val obj = JSONObject(String(bytes, Charsets.UTF_8))
                val nodeId = obj.getString("node_id").trim()
                val pubHex = obj.getString("public_key_hex").trim().lowercase()
                val name = obj.optString("display_name", nodeId.take(16)).trim()
                val vp = obj.optLong("voting_power", 1L)
                if (nodeId.isBlank() || pubHex.length != 64 || vp <= 0L) null
                else ValidatorTransactionPayload(nodeId, pubHex, name, vp)
            } catch (_: Exception) {
                null
            }
        }
    }
}

enum class MempoolTxStatus {
    PENDING,
    VALIDATED,
    QUEUED,
    REJECTED,
    CONFIRMED,
    EXPIRED
}

enum class TransactionPropagationStatus {
    LOCAL_ONLY,
    ANNOUNCED,
    BROADCAST_PARTIAL,
    BROADCAST_COMPLETE,
    RECEIVED_FROM_PEER,
    PROPAGATION_FAILED
}

/**
 * Fixed-point NMD amount utility (1 NMD = 1,000,000 atomic micro-NMD units).
 * Eliminates floating-point precision drift during canonical serialization & fee checks.
 */
object NmdAmountCodec {
    const val UNITS_PER_NMD: Long = 1_000_000L
    const val MAX_AMOUNT_UNITS: Long = 1_000_000_000L * UNITS_PER_NMD // 1B NMD cap per tx
    private val DECIMAL_DIVISOR = BigDecimal(UNITS_PER_NMD)

    fun parseNmdToUnits(input: String): Long? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null
        return try {
            val bd = BigDecimal(trimmed)
            if (bd.signum() < 0) return null
            val scaled = bd.multiply(DECIMAL_DIVISOR)
            // Reject sub-unit fractional precision finer than 1e-6 NMD or overflow
            val exactLong = scaled.setScale(0, RoundingMode.UNNECESSARY).longValueExact()
            if (exactLong > MAX_AMOUNT_UNITS) null else exactLong
        } catch (_: Exception) {
            null
        }
    }

    fun formatUnitsToNmd(units: Long, minDecimals: Int = 2, maxDecimals: Int = 6): String {
        val bd = BigDecimal(units).divide(DECIMAL_DIVISOR, maxDecimals, RoundingMode.DOWN)
            .stripTrailingZeros()
        val scale = maxOf(minDecimals, bd.scale().coerceAtLeast(0))
        return bd.setScale(scale, RoundingMode.DOWN).toPlainString()
    }
}

/**
 * Core Stage 9 NMD Transaction Model.
 *
 * Security invariants:
 * - Never stores private keys or recovery phrases.
 * - Uses deterministic fixed-point integer units for amounts and fees.
 * - Preserves [rawTxTypeName] so malformed or unsupported wire types cannot masquerade as valid.
 */
data class NmdTransaction(
    val txId: String = "",
    val chainId: String,
    val protocolVersion: Int,
    val senderAddress: String,
    val recipientAddress: String,
    val amountUnits: Long,
    val feeUnits: Long,
    val nonce: Long,
    val timestamp: Long,
    val txType: TransactionType,
    val rawTxTypeName: String = txType.name,
    val senderPublicKeyHex: String,
    val signatureHex: String = "",
    val payload: ByteArray = ByteArray(0)
) {
    val shortTxId: String
        get() = if (txId.length > 16) "${txId.take(10)}...${txId.takeLast(6)}" else txId

    val payloadUtf8Preview: String
        get() = if (payload.isEmpty()) "" else try {
            String(payload, Charsets.UTF_8)
        } catch (_: Exception) {
            "${payload.size}B binary"
        }

    fun toJson(): String {
        return JSONObject().apply {
            put("tx_id", txId)
            put("chain_id", chainId)
            put("protocol_version", protocolVersion)
            put("sender_address", senderAddress)
            put("recipient_address", recipientAddress)
            put("amount_units", amountUnits)
            put("fee_units", feeUnits)
            put("nonce", nonce)
            put("timestamp", timestamp)
            put("tx_type", rawTxTypeName)
            put("sender_public_key", senderPublicKeyHex.lowercase())
            put("signature", signatureHex.lowercase())
            put("payload_b64", Base64.encodeToString(payload, Base64.NO_WRAP))
        }.toString()
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as NmdTransaction
        return txId == other.txId &&
            chainId == other.chainId &&
            protocolVersion == other.protocolVersion &&
            senderAddress == other.senderAddress &&
            recipientAddress == other.recipientAddress &&
            amountUnits == other.amountUnits &&
            feeUnits == other.feeUnits &&
            nonce == other.nonce &&
            timestamp == other.timestamp &&
            txType == other.txType &&
            rawTxTypeName == other.rawTxTypeName &&
            senderPublicKeyHex == other.senderPublicKeyHex &&
            signatureHex == other.signatureHex &&
            payload.contentEquals(other.payload)
    }

    override fun hashCode(): Int {
        var result = txId.hashCode()
        result = 31 * result + chainId.hashCode()
        result = 31 * result + protocolVersion
        result = 31 * result + senderAddress.hashCode()
        result = 31 * result + recipientAddress.hashCode()
        result = 31 * result + amountUnits.hashCode()
        result = 31 * result + feeUnits.hashCode()
        result = 31 * result + nonce.hashCode()
        result = 31 * result + timestamp.hashCode()
        result = 31 * result + txType.hashCode()
        result = 31 * result + rawTxTypeName.hashCode()
        result = 31 * result + senderPublicKeyHex.hashCode()
        result = 31 * result + signatureHex.hashCode()
        result = 31 * result + payload.contentHashCode()
        return result
    }

    companion object {
        const val MAX_WIRE_JSON_BYTES = 16_384

        fun fromJson(jsonStr: String): NmdTransaction? {
            if (jsonStr.isBlank() || jsonStr.toByteArray(Charsets.UTF_8).size > MAX_WIRE_JSON_BYTES) {
                return null
            }
            return try {
                val j = JSONObject(jsonStr)
                val rawType = j.getString("tx_type")
                val payloadB64 = j.optString("payload_b64", "")
                val payloadBytes = if (payloadB64.isEmpty()) {
                    ByteArray(0)
                } else {
                    Base64.decode(payloadB64, Base64.NO_WRAP)
                }

                NmdTransaction(
                    txId = j.getString("tx_id").trim().lowercase(),
                    chainId = j.getString("chain_id").trim(),
                    protocolVersion = j.getInt("protocol_version"),
                    senderAddress = j.getString("sender_address").trim(),
                    recipientAddress = j.getString("recipient_address").trim(),
                    amountUnits = j.getLong("amount_units"),
                    feeUnits = j.getLong("fee_units"),
                    nonce = j.getLong("nonce"),
                    timestamp = j.getLong("timestamp"),
                    txType = TransactionType.fromWireName(rawType),
                    rawTxTypeName = rawType,
                    senderPublicKeyHex = j.getString("sender_public_key").trim().lowercase(),
                    signatureHex = j.getString("signature").trim().lowercase(),
                    payload = payloadBytes
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class MempoolTransactionRecord(
    val transaction: NmdTransaction,
    val status: MempoolTxStatus,
    val propagationStatus: TransactionPropagationStatus = TransactionPropagationStatus.LOCAL_ONLY,
    val rejectionReason: String? = null,
    val receivedFromPeerId: String? = null,
    val confirmedBlockHeight: Long? = null,
    val confirmedBlockHash: String? = null,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = createdAtMs,
    val expiresAtMs: Long = createdAtMs + DEFAULT_TX_TTL_MS,
    val feeMetadataJson: String = ""
) {
    companion object {
        const val DEFAULT_TX_TTL_MS = 24L * 60L * 60L * 1000L // 24 hours
    }
}

data class AccountNonceState(
    val address: String,
    val confirmedNextNonce: Long = 0L,
    val pendingNonces: Set<Long> = emptySet(),
    val reservedNonces: Set<Long> = emptySet()
) {
    val nextAvailableNonce: Long
        get() {
            var candidate = confirmedNextNonce
            while (pendingNonces.contains(candidate) || reservedNonces.contains(candidate)) {
                candidate++
            }
            return candidate
        }
}

data class MempoolStatsSnapshot(
    val totalStored: Int = 0,
    val maxCapacity: Int = 500,
    val pendingCount: Int = 0,
    val validatedCount: Int = 0,
    val queuedCount: Int = 0,
    val rejectedCount: Int = 0,
    val confirmedCount: Int = 0,
    val expiredCount: Int = 0,
    val receivedFromPeersCount: Int = 0,
    val duplicateSuppressedCount: Int = 0,
    val broadcastCount: Int = 0,
    val authenticatedPeersCount: Int = 0,
    val propagationSummary: String = "LOCAL_ONLY",
    val lastValidationError: String? = null
) {
    val activeValidOrQueuedCount: Int
        get() = pendingCount + validatedCount + queuedCount
}
