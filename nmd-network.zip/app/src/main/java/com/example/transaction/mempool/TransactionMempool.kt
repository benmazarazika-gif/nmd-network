package com.example.transaction.mempool

import com.example.transaction.model.MempoolStatsSnapshot
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionPropagationStatus
import com.example.transaction.storage.MempoolInsertResult
import com.example.transaction.storage.TransactionStorage
import com.example.transaction.validation.TransactionPolicyConfig
import com.example.transaction.validation.TransactionValidator
import com.example.transaction.validation.TxValidationErrorCode
import com.example.transaction.validation.TxValidationResult
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.util.concurrent.atomic.AtomicInteger

sealed class MempoolSubmissionResult {
    data class Accepted(
        val record: MempoolTransactionRecord
    ) : MempoolSubmissionResult()

    data class Duplicate(
        val txId: String,
        val reason: String
    ) : MempoolSubmissionResult()

    data class Rejected(
        val code: TxValidationErrorCode,
        val reason: String,
        val rejectedRecord: MempoolTransactionRecord? = null
    ) : MempoolSubmissionResult()
}

/**
 * Persistent, bounded, deterministic Stage 9 Transaction Mempool.
 *
 * Guarantees:
 * - Invalid transactions NEVER enter the pending/validated candidate pool.
 * - Duplicate txIds and duplicate active (sender, nonce) submissions are rejected.
 * - Out-of-order transactions within [TransactionPolicyConfig.maxNonceGap] wait cleanly in QUEUED
 *   and automatically promote to VALIDATED once earlier sequential nonces arrive.
 * - Survives app restarts cleanly via Room SQLite [TransactionStorage].
 */
class TransactionMempool(
    private val storage: TransactionStorage,
    val validator: TransactionValidator = TransactionValidator(),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    val ledgerStateEngine: com.example.blockchain.state.LedgerStateEngine? = null
) : Closeable {

    private val mutex = Mutex()
    private val duplicateSuppressedCounter = AtomicInteger(0)
    private val broadcastCounter = AtomicInteger(0)

    private val _transactions = MutableStateFlow<List<MempoolTransactionRecord>>(emptyList())
    val transactions: StateFlow<List<MempoolTransactionRecord>> = _transactions.asStateFlow()

    private val _stats = MutableStateFlow(MempoolStatsSnapshot(maxCapacity = validator.policy.maxActiveMempoolSize))
    val stats: StateFlow<MempoolStatsSnapshot> = _stats.asStateFlow()

    @Volatile
    private var lastErrorMessage: String? = null

    @Volatile
    private var lastAuthenticatedPeersCount: Int = 0

    @Volatile
    private var lastPropagationSummary: String = TransactionPropagationStatus.LOCAL_ONLY.name

    suspend fun initialize(nowMs: Long = System.currentTimeMillis()): List<MempoolTransactionRecord> = withContext(ioDispatcher) {
        ledgerStateEngine?.initialize()
        mutex.withLock {
            storage.pruneExpired(nowMs)
            refreshSnapshotLocked()
            _transactions.value
        }
    }

    suspend fun submitTransaction(
        tx: NmdTransaction,
        receivedFromPeerId: String? = null,
        nowMs: Long = System.currentTimeMillis(),
        recordRejection: Boolean = true
    ): MempoolSubmissionResult = withContext(ioDispatcher) {
        mutex.withLock {
            val normalizedId = tx.txId.lowercase()

            // 1. Verify canonical txId consistency before duplicate suppression so tampered payloads
            // reusing an existing txId are rejected and penalized rather than treated as duplicates.
            if (normalizedId.isNotBlank() && !validator.signer.verifyTransactionId(tx)) {
                return@withLock handleRejectionLocked(
                    tx = tx,
                    code = TxValidationErrorCode.INVALID_TX_ID,
                    reason = "Transaction ID does not match canonical hash",
                    receivedFromPeerId = receivedFromPeerId,
                    nowMs = nowMs,
                    recordRejection = recordRejection
                )
            }

            // 2. Check duplicate txId
            if (normalizedId.isNotBlank()) {
                val existing = storage.getByTxId(normalizedId)
                if (existing != null) {
                    duplicateSuppressedCounter.incrementAndGet()
                    refreshSnapshotLocked()
                    return@withLock MempoolSubmissionResult.Duplicate(
                        txId = normalizedId,
                        reason = "Duplicate transaction ID already tracked (status=${existing.status})"
                    )
                }
            }

            // 2. Evict expired active txs before evaluating quotas and nonces
            storage.pruneExpired(nowMs)

            // 3. Enforce bounded capacity for active pool
            val activeCount = storage.getActivePoolCount()
            if (activeCount >= validator.policy.maxActiveMempoolSize) {
                val reason = "Active mempool capacity limit reached (${validator.policy.maxActiveMempoolSize})"
                return@withLock handleRejectionLocked(
                    tx = tx,
                    code = TxValidationErrorCode.MEMPOOL_FULL,
                    reason = reason,
                    receivedFromPeerId = receivedFromPeerId,
                    nowMs = nowMs,
                    recordRejection = recordRejection
                )
            }

            val senderActiveRecords = storage.getActiveBySender(tx.senderAddress)
            if (senderActiveRecords.size >= validator.policy.maxPendingPerSender) {
                val reason = "Sender active pending quota reached (${validator.policy.maxPendingPerSender})"
                return@withLock handleRejectionLocked(
                    tx = tx,
                    code = TxValidationErrorCode.SENDER_MEMPOOL_QUOTA_EXCEEDED,
                    reason = reason,
                    receivedFromPeerId = receivedFromPeerId,
                    nowMs = nowMs,
                    recordRejection = recordRejection
                )
            }

            // 4. Full stateful validation (structure + chain + crypto + sig + fee + nonce)
            val confirmedNext = storage.getConfirmedNextNonce(tx.senderAddress)
            val activeNonces = senderActiveRecords.map { it.transaction.nonce }.toSet()
            val validation = validator.validateWithAccountState(
                tx = tx,
                confirmedNextNonce = confirmedNext,
                activeSenderNonces = activeNonces,
                nowMs = nowMs
            )

            if (validation is TxValidationResult.Invalid) {
                return@withLock handleRejectionLocked(
                    tx = tx,
                    code = validation.code,
                    reason = validation.reason,
                    receivedFromPeerId = receivedFromPeerId,
                    nowMs = nowMs,
                    recordRejection = recordRejection
                )
            }

            // 4b. Strict ledger balance check when enforceStrictBalances is enabled
            if (ledgerStateEngine != null && ledgerStateEngine.enforceStrictBalances) {
                val pendingOutflow = senderActiveRecords.sumOf { it.transaction.amountUnits + it.transaction.feeUnits }
                if (!ledgerStateEngine.hasSufficientBalanceForTx(tx, pendingOutflow)) {
                    return@withLock handleRejectionLocked(
                        tx = tx,
                        code = TxValidationErrorCode.INSUFFICIENT_BALANCE,
                        reason = "Insufficient available ledger balance for transfer + fee",
                        receivedFromPeerId = receivedFromPeerId,
                        nowMs = nowMs,
                        recordRejection = recordRejection
                    )
                }
            }

            val validRes = validation as TxValidationResult.Valid
            val initialProp = if (receivedFromPeerId != null) {
                TransactionPropagationStatus.RECEIVED_FROM_PEER
            } else {
                TransactionPropagationStatus.LOCAL_ONLY
            }

            val record = MempoolTransactionRecord(
                transaction = tx.copy(
                    txId = normalizedId,
                    senderPublicKeyHex = tx.senderPublicKeyHex.lowercase(),
                    signatureHex = tx.signatureHex.lowercase()
                ),
                status = validRes.targetStatus,
                propagationStatus = initialProp,
                receivedFromPeerId = receivedFromPeerId,
                createdAtMs = nowMs,
                updatedAtMs = nowMs,
                expiresAtMs = tx.timestamp + validator.policy.maxTransactionAgeMs,
                feeMetadataJson = validRes.feeEstimate.toMetadataJson()
            )

            when (val insertRes = storage.insertAbortDuplicate(record)) {
                is MempoolInsertResult.Inserted -> {
                    promoteQueuedTransactionsForSenderLocked(tx.senderAddress, nowMs)
                    lastErrorMessage = null
                    refreshSnapshotLocked()
                    val latest = storage.getByTxId(normalizedId) ?: record
                    MempoolSubmissionResult.Accepted(latest)
                }
                is MempoolInsertResult.Duplicate -> {
                    duplicateSuppressedCounter.incrementAndGet()
                    refreshSnapshotLocked()
                    MempoolSubmissionResult.Duplicate(normalizedId, insertRes.reason)
                }
                is MempoolInsertResult.Error -> {
                    MempoolSubmissionResult.Rejected(TxValidationErrorCode.MALFORMED_STRUCTURE, insertRes.reason)
                }
            }
        }
    }

    suspend fun getByTxId(txId: String): MempoolTransactionRecord? = withContext(ioDispatcher) {
        storage.getByTxId(txId.lowercase())
    }

    /**
     * Resolves a full [NmdTransaction] from either active/mempool storage OR the permanent
     * Stage 17 `confirmed_transactions` archive (survives mempool eviction).
     */
    suspend fun getConfirmedOrActiveTransaction(txId: String): NmdTransaction? = withContext(ioDispatcher) {
        val clean = txId.lowercase()
        storage.getConfirmedArchiveById(clean)?.transaction ?: storage.getByTxId(clean)?.transaction
    }

    /**
     * Returns validated transactions ready for future block inclusion in deterministic order:
     * highest fee first, then lower nonce, older timestamp, and lexicographical txId tie-breaker.
     */
    suspend fun getBlockCandidateTransactions(limit: Int = 200): List<MempoolTransactionRecord> = withContext(ioDispatcher) {
        mutex.withLock {
            storage.getValidatedCandidates(limit)
        }
    }

    suspend fun getConfirmedNextNonce(address: String): Long = withContext(ioDispatcher) {
        mutex.withLock {
            storage.getConfirmedNextNonce(address)
        }
    }

    suspend fun removeTransaction(txId: String): Boolean = withContext(ioDispatcher) {
        mutex.withLock {
            val removed = storage.removeTransaction(txId.lowercase())
            if (removed) refreshSnapshotLocked()
            removed
        }
    }

    suspend fun pruneExpired(nowMs: Long = System.currentTimeMillis()): Int = withContext(ioDispatcher) {
        mutex.withLock {
            val count = storage.pruneExpired(nowMs)
            refreshSnapshotLocked()
            count
        }
    }

    suspend fun onBlockCommitted(
        txIds: List<String>,
        blockHeight: Long,
        blockHash: String,
        updatedAtMs: Long = System.currentTimeMillis()
    ): Int = withContext(ioDispatcher) {
        mutex.withLock {
            val affectedSenders = txIds.mapNotNull { storage.getByTxId(it.lowercase())?.transaction?.senderAddress }.distinct()
            val confirmed = storage.confirmTransactionsInBlock(txIds, blockHeight, blockHash, updatedAtMs)
            affectedSenders.forEach { sender ->
                promoteQueuedTransactionsForSenderLocked(sender, updatedAtMs)
            }
            refreshSnapshotLocked()
            confirmed
        }
    }

    /**
     * Stage 12 Mempool Reconciliation:
     * Records verified confirmed transactions from a synced block, advances confirmed nonces,
     * rejects stale active transactions from affected senders below [confirmedNextNonce], and
     * promotes valid sequential queued transactions without discarding valid pending work.
     */
    suspend fun reconcileSyncedConfirmedTransactions(
        transactions: List<NmdTransaction>,
        blockHeight: Long,
        blockHash: String,
        receivedFromPeerId: String? = null,
        updatedAtMs: Long = System.currentTimeMillis()
    ): Int = withContext(ioDispatcher) {
        mutex.withLock {
            if (transactions.isEmpty()) {
                return@withLock 0
            }
            val normalizedHash = blockHash.lowercase()
            val records = mutableListOf<MempoolTransactionRecord>()
            val affectedSenders = LinkedHashSet<String>()

            for (tx in transactions) {
                val normId = tx.txId.lowercase()
                val existing = storage.getByTxId(normId)
                val normalizedTx = tx.copy(
                    txId = normId,
                    senderPublicKeyHex = tx.senderPublicKeyHex.lowercase(),
                    signatureHex = tx.signatureHex.lowercase()
                )
                affectedSenders.add(normalizedTx.senderAddress)
                records.add(
                    MempoolTransactionRecord(
                        transaction = normalizedTx,
                        status = MempoolTxStatus.CONFIRMED,
                        propagationStatus = existing?.propagationStatus ?: TransactionPropagationStatus.RECEIVED_FROM_PEER,
                        rejectionReason = null,
                        receivedFromPeerId = existing?.receivedFromPeerId ?: receivedFromPeerId,
                        confirmedBlockHeight = blockHeight,
                        confirmedBlockHash = normalizedHash,
                        createdAtMs = existing?.createdAtMs ?: updatedAtMs,
                        updatedAtMs = updatedAtMs,
                        expiresAtMs = existing?.expiresAtMs ?: (tx.timestamp + validator.policy.maxTransactionAgeMs),
                        feeMetadataJson = existing?.feeMetadataJson ?: ""
                    )
                )
            }

            val confirmedCount = storage.confirmSyncedTransactionsInBlock(records, updatedAtMs)

            for (sender in affectedSenders) {
                val confirmedNext = storage.getConfirmedNextNonce(sender)
                val activeForSender = storage.getActiveBySender(sender)
                for (activeRec in activeForSender) {
                    if (activeRec.transaction.nonce < confirmedNext) {
                        storage.upsertRecord(
                            activeRec.copy(
                                status = MempoolTxStatus.REJECTED,
                                rejectionReason = "STALE_NONCE: Superseded by synced block #$blockHeight",
                                updatedAtMs = updatedAtMs
                            )
                        )
                    }
                }
                promoteQueuedTransactionsForSenderLocked(sender, updatedAtMs)
            }

            refreshSnapshotLocked()
            confirmedCount
        }
    }

    suspend fun updatePropagationStatus(
        txId: String,
        propagationStatus: TransactionPropagationStatus,
        authenticatedPeersCount: Int = lastAuthenticatedPeersCount,
        summary: String = propagationStatus.name
    ) = withContext(ioDispatcher) {
        mutex.withLock {
            storage.updatePropagationStatus(txId.lowercase(), propagationStatus, System.currentTimeMillis())
            if (propagationStatus == TransactionPropagationStatus.BROADCAST_COMPLETE ||
                propagationStatus == TransactionPropagationStatus.BROADCAST_PARTIAL ||
                propagationStatus == TransactionPropagationStatus.ANNOUNCED
            ) {
                broadcastCounter.incrementAndGet()
            }
            lastAuthenticatedPeersCount = authenticatedPeersCount
            lastPropagationSummary = summary
            refreshSnapshotLocked()
        }
    }

    suspend fun refreshPeerContext(authenticatedPeersCount: Int) = withContext(ioDispatcher) {
        mutex.withLock {
            lastAuthenticatedPeersCount = authenticatedPeersCount
            lastPropagationSummary = if (authenticatedPeersCount > 0) {
                "READY ($authenticatedPeersCount PEERS)"
            } else {
                TransactionPropagationStatus.LOCAL_ONLY.name
            }
            refreshSnapshotLocked()
        }
    }

    fun recordDuplicateSuppressedExternal() {
        duplicateSuppressedCounter.incrementAndGet()
        _stats.value = _stats.value.copy(duplicateSuppressedCount = duplicateSuppressedCounter.get())
    }

    private suspend fun promoteQueuedTransactionsForSenderLocked(senderAddress: String, nowMs: Long) {
        val confirmedNext = storage.getConfirmedNextNonce(senderAddress)
        val senderActive = storage.getActiveBySender(senderAddress).sortedBy { it.transaction.nonce }
        var expectedNext = confirmedNext
        for (rec in senderActive) {
            if (rec.transaction.nonce == expectedNext) {
                if (rec.status == MempoolTxStatus.QUEUED || rec.status == MempoolTxStatus.PENDING) {
                    storage.updateStatus(rec.transaction.txId, MempoolTxStatus.VALIDATED, nowMs)
                }
                expectedNext++
            } else if (rec.transaction.nonce > expectedNext) {
                break
            }
        }
    }

    private suspend fun handleRejectionLocked(
        tx: NmdTransaction,
        code: TxValidationErrorCode,
        reason: String,
        receivedFromPeerId: String?,
        nowMs: Long,
        recordRejection: Boolean
    ): MempoolSubmissionResult.Rejected {
        lastErrorMessage = reason
        var rejectedRecord: MempoolTransactionRecord? = null
        if (recordRejection && tx.txId.isNotBlank() && storage.getByTxId(tx.txId.lowercase()) == null) {
            rejectedRecord = MempoolTransactionRecord(
                transaction = tx.copy(txId = tx.txId.lowercase()),
                status = MempoolTxStatus.REJECTED,
                propagationStatus = if (receivedFromPeerId != null) {
                    TransactionPropagationStatus.RECEIVED_FROM_PEER
                } else {
                    TransactionPropagationStatus.LOCAL_ONLY
                },
                rejectionReason = "${code.name}: $reason",
                receivedFromPeerId = receivedFromPeerId,
                createdAtMs = nowMs,
                updatedAtMs = nowMs,
                expiresAtMs = nowMs
            )
            storage.upsertRecord(rejectedRecord)
            storage.trimRejectedHistory(validator.policy.maxRejectedHistorySize)
        }
        refreshSnapshotLocked()
        return MempoolSubmissionResult.Rejected(code, reason, rejectedRecord)
    }

    private suspend fun refreshSnapshotLocked() {
        val all = storage.getAllTransactions()
        _transactions.value = all

        var pending = 0
        var validated = 0
        var queued = 0
        var rejected = 0
        var confirmed = 0
        var expired = 0
        var fromPeers = 0

        for (rec in all) {
            when (rec.status) {
                MempoolTxStatus.PENDING -> pending++
                MempoolTxStatus.VALIDATED -> validated++
                MempoolTxStatus.QUEUED -> queued++
                MempoolTxStatus.REJECTED -> rejected++
                MempoolTxStatus.CONFIRMED -> confirmed++
                MempoolTxStatus.EXPIRED -> expired++
            }
            if (rec.receivedFromPeerId != null) {
                fromPeers++
            }
        }

        _stats.value = MempoolStatsSnapshot(
            totalStored = all.size,
            maxCapacity = validator.policy.maxActiveMempoolSize,
            pendingCount = pending,
            validatedCount = validated,
            queuedCount = queued,
            rejectedCount = rejected,
            confirmedCount = confirmed,
            expiredCount = expired,
            receivedFromPeersCount = fromPeers,
            duplicateSuppressedCount = duplicateSuppressedCounter.get(),
            broadcastCount = broadcastCounter.get(),
            authenticatedPeersCount = lastAuthenticatedPeersCount,
            propagationSummary = lastPropagationSummary,
            lastValidationError = lastErrorMessage
        )
    }

    override fun close() {
        storage.close()
    }
}
