package com.example.transaction.p2p

import android.util.Log
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.session.PeerSession
import com.example.transaction.mempool.MempoolSubmissionResult
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionPropagationStatus
import com.example.transaction.validation.TxValidationErrorCode
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

sealed class TxInboundResult {
    data class Accepted(val txId: String, val mempoolStatus: MempoolTxStatus) : TxInboundResult()
    data class Duplicate(val txId: String, val reason: String) : TxInboundResult()
    data class Rejected(val code: TxValidationErrorCode?, val reason: String, val penalizedPeer: Boolean) : TxInboundResult()
}

data class TxBroadcastOutcome(
    val txId: String,
    val attemptedPeers: Int,
    val deliveredPeers: Int,
    val propagationStatus: TransactionPropagationStatus
)

/**
 * Per-peer sliding-window rate limiter preventing transaction flooding from remote peers.
 */
class TxPeerRateLimiter(
    private val maxMessagesPerWindow: Int = 20,
    private val windowMs: Long = 60_000L
) {
    private val peerTimestamps = ConcurrentHashMap<String, ArrayDeque<Long>>()

    fun allow(peerId: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        val queue = peerTimestamps.getOrPut(peerId) { ArrayDeque() }
        synchronized(queue) {
            while (queue.isNotEmpty() && nowMs - queue.first() > windowMs) {
                queue.removeFirst()
            }
            if (queue.size >= maxMessagesPerWindow) {
                return false
            }
            queue.addLast(nowMs)
            return true
        }
    }
}

/**
 * Stage 9 P2P Transaction Propagation Gateway integrated with Stage 6/7 networking.
 *
 * Security invariants:
 * - Zero-Trust: never trusts transactions just because they come from an authenticated peer.
 * - Enforces wire payload limits, per-peer rate limiting, duplicate suppression, and full
 *   cryptographic + structural + nonce validation before entering the mempool.
 * - Penalizes peers that send malformed or invalid transactions via [DistributedPeerRegistry].
 * - Never transmits private keys over the wire.
 */
class P2pTransactionPropagationGateway(
    private val mempool: TransactionMempool,
    private val peerRegistry: DistributedPeerRegistry? = null,
    private val rateLimiter: TxPeerRateLimiter = TxPeerRateLimiter()
) {
    companion object {
        private const val TAG = "P2pTxGateway"
        const val MAX_TX_WIRE_PAYLOAD_BYTES = 12_288
    }

    @Volatile
    var authenticatedSessionsProvider: (() -> List<PeerSession>)? = null

    @Volatile
    var sendTxPayloadToSession: (suspend (sessionId: String, messageType: P2pMessageType, payload: String) -> Result<Unit>)? = null

    suspend fun handleIncomingP2pTransaction(
        fromSession: PeerSession,
        message: P2pMessage,
        nowMs: Long = System.currentTimeMillis()
    ): TxInboundResult {
        // 1. Verify live authenticated session
        if (!fromSession.isTrusted) {
            return TxInboundResult.Rejected(
                code = null,
                reason = "Rejected transaction from unauthenticated session ${fromSession.peerId}",
                penalizedPeer = false
            )
        }

        // 2. Enforce wire payload size limit
        val rawPayload = message.payload
        val payloadBytes = rawPayload.toByteArray(Charsets.UTF_8)
        if (payloadBytes.size > MAX_TX_WIRE_PAYLOAD_BYTES) {
            peerRegistry?.recordInvalidBehavior(fromSession.peerId, penalty = 15)
            return TxInboundResult.Rejected(
                code = TxValidationErrorCode.TX_TOO_LARGE,
                reason = "Incoming P2P transaction payload exceeds $MAX_TX_WIRE_PAYLOAD_BYTES bytes",
                penalizedPeer = true
            )
        }

        // 3. Enforce per-peer rate limiting
        if (!rateLimiter.allow(fromSession.peerId, nowMs)) {
            peerRegistry?.recordInvalidBehavior(fromSession.peerId, penalty = 10)
            return TxInboundResult.Rejected(
                code = null,
                reason = "Peer ${fromSession.peerId} exceeded transaction rate limit",
                penalizedPeer = true
            )
        }

        // 4. Parse wire transaction payload (supports raw tx JSON or announcement envelope)
        val txJson = unwrapTransactionJson(rawPayload)
        val tx = NmdTransaction.fromJson(txJson)
        if (tx == null) {
            Log.w(TAG, "Malformed transaction JSON from ${fromSession.peerId}")
            peerRegistry?.recordInvalidBehavior(fromSession.peerId, penalty = 20)
            return TxInboundResult.Rejected(
                code = TxValidationErrorCode.MALFORMED_STRUCTURE,
                reason = "Malformed incoming transaction JSON",
                penalizedPeer = true
            )
        }

        // 5. Independent validation + mempool admission
        return when (val res = mempool.submitTransaction(tx, receivedFromPeerId = fromSession.peerId, nowMs = nowMs)) {
            is MempoolSubmissionResult.Accepted -> {
                TxInboundResult.Accepted(res.record.transaction.txId, res.record.status)
            }
            is MempoolSubmissionResult.Duplicate -> {
                TxInboundResult.Duplicate(res.txId, res.reason)
            }
            is MempoolSubmissionResult.Rejected -> {
                Log.w(TAG, "Rejected P2P transaction from ${fromSession.peerId}: [${res.code}] ${res.reason}")
                peerRegistry?.recordInvalidBehavior(fromSession.peerId, penalty = 20)
                TxInboundResult.Rejected(res.code, res.reason, penalizedPeer = true)
            }
        }
    }

    suspend fun broadcastTransaction(tx: NmdTransaction): TxBroadcastOutcome {
        val stored = mempool.getByTxId(tx.txId)
        if (stored == null || (stored.status != MempoolTxStatus.VALIDATED && stored.status != MempoolTxStatus.QUEUED)) {
            return TxBroadcastOutcome(
                txId = tx.txId,
                attemptedPeers = 0,
                deliveredPeers = 0,
                propagationStatus = TransactionPropagationStatus.PROPAGATION_FAILED
            )
        }

        val sessions = authenticatedSessionsProvider?.invoke()
            ?.filter { it.isTrusted }
            .orEmpty()

        mempool.refreshPeerContext(sessions.size)

        if (sessions.isEmpty()) {
            mempool.updatePropagationStatus(
                txId = tx.txId,
                propagationStatus = TransactionPropagationStatus.LOCAL_ONLY,
                authenticatedPeersCount = 0,
                summary = "LOCAL_ONLY (0 connected peers)"
            )
            return TxBroadcastOutcome(
                txId = tx.txId,
                attemptedPeers = 0,
                deliveredPeers = 0,
                propagationStatus = TransactionPropagationStatus.LOCAL_ONLY
            )
        }

        val sender = sendTxPayloadToSession
        if (sender == null) {
            return TxBroadcastOutcome(
                txId = tx.txId,
                attemptedPeers = sessions.size,
                deliveredPeers = 0,
                propagationStatus = TransactionPropagationStatus.LOCAL_ONLY
            )
        }

        val wirePayload = tx.toJson()
        var delivered = 0
        for (session in sessions) {
            // Avoid bouncing right back to the originating peer
            if (stored.receivedFromPeerId != null && stored.receivedFromPeerId == session.peerId) {
                continue
            }
            val result = try {
                sender(session.sessionId, P2pMessageType.TX_PAYLOAD, wirePayload)
            } catch (e: Exception) {
                Result.failure(e)
            }
            if (result.isSuccess) {
                delivered++
            }
        }

        val status = when {
            delivered == 0 -> TransactionPropagationStatus.PROPAGATION_FAILED
            delivered < sessions.size -> TransactionPropagationStatus.BROADCAST_PARTIAL
            else -> TransactionPropagationStatus.BROADCAST_COMPLETE
        }

        mempool.updatePropagationStatus(
            txId = tx.txId,
            propagationStatus = status,
            authenticatedPeersCount = sessions.size,
            summary = "${status.name} ($delivered/${sessions.size})"
        )

        return TxBroadcastOutcome(
            txId = tx.txId,
            attemptedPeers = sessions.size,
            deliveredPeers = delivered,
            propagationStatus = status
        )
    }

    private fun unwrapTransactionJson(raw: String): String {
        return try {
            val obj = JSONObject(raw)
            if (obj.has("transaction") && obj.get("transaction") is JSONObject) {
                obj.getJSONObject("transaction").toString()
            } else {
                raw
            }
        } catch (_: Exception) {
            raw
        }
    }
}
