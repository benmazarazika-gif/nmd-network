package com.example.crypto.repository

import com.example.crypto.model.MessageVerificationResult
import com.example.crypto.model.NodeIdentity
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.crypto.provider.CryptographicProvider
import com.example.crypto.service.MessageVerifier
import com.example.crypto.service.SignatureService
import com.example.crypto.storage.KeyStoreStorageService

interface IdentityRepository {
    val cryptoProvider: CryptographicProvider
    val messageVerifier: MessageVerifier
    fun hasIdentity(): Boolean
    fun getPublicIdentity(): NodeIdentity?
    fun generateIdentity(): NodeIdentity
    fun importIdentitySeed(privateKeyBytes: ByteArray): NodeIdentity
    fun exportPrivateSeedBytesCopy(): ByteArray?
    fun exportPublicIdentityJson(): String
    fun deleteIdentity(): Boolean
    fun signProtocolMessage(messageType: ProtocolMessageType, payload: String): SignedProtocolMessage
    fun signRawData(data: ByteArray): ByteArray
    fun verifyProtocolMessage(message: SignedProtocolMessage): MessageVerificationResult
    fun verifySelfIdentity(): Boolean
}

class IdentityRepositoryImpl(
    override val cryptoProvider: CryptographicProvider,
    private val storageService: KeyStoreStorageService,
    private val signatureService: SignatureService = SignatureService(cryptoProvider),
    override val messageVerifier: MessageVerifier = MessageVerifier(
        cryptoProvider = cryptoProvider,
        context = storageService.context
    )
) : IdentityRepository {

    override fun signRawData(data: ByteArray): ByteArray {
        val privateKeyBytes = storageService.loadPrivateKeyBytes()
            ?: throw IllegalStateException("Private key seed is unavailable in secure storage")
        try {
            return signatureService.signData(privateKeyBytes, data)
        } finally {
            privateKeyBytes.fill(0)
        }
    }

    override fun hasIdentity(): Boolean = storageService.hasStoredIdentity()

    override fun getPublicIdentity(): NodeIdentity? = storageService.loadPublicIdentity()

    override fun generateIdentity(): NodeIdentity {
        val keyPair = cryptoProvider.generateEd25519KeyPair()
        try {
            return storePrivateKeySeedInternal(keyPair.privateKeyBytes, keyPair.publicKeyBytes)
        } finally {
            keyPair.privateKeyBytes.fill(0)
        }
    }

    override fun importIdentitySeed(privateKeyBytes: ByteArray): NodeIdentity {
        require(privateKeyBytes.size == 32) { "Ed25519 private key seed must be exactly 32 bytes" }
        val publicKeyBytes = cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytes)
        return storePrivateKeySeedInternal(privateKeyBytes, publicKeyBytes)
    }

    private fun storePrivateKeySeedInternal(
        privateKeyBytes: ByteArray,
        publicKeyBytes: ByteArray
    ): NodeIdentity {
        val publicKeyHex = cryptoProvider.toHex(publicKeyBytes)
        val nodeId = cryptoProvider.deriveNodeId(publicKeyBytes)
        val fingerprint = cryptoProvider.computeFingerprint(publicKeyBytes)

        val preliminary = NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = publicKeyHex,
            publicKeyFingerprint = fingerprint,
            algorithm = NodeIdentity.ALGORITHM_ED25519,
            creationTimestamp = System.currentTimeMillis(),
            version = NodeIdentity.IDENTITY_VERSION,
            securityStatus = com.example.crypto.model.KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        )

        storageService.storeIdentity(preliminary, privateKeyBytes)
        messageVerifier.clearReplayCache()
        return storageService.loadPublicIdentity() ?: preliminary
    }

    override fun exportPrivateSeedBytesCopy(): ByteArray? {
        return storageService.loadPrivateKeyBytes()
    }

    override fun exportPublicIdentityJson(): String {
        val identity = getPublicIdentity()
            ?: throw IllegalStateException("No node identity exists to export")
        return identity.toPublicJson()
    }

    override fun deleteIdentity(): Boolean {
        messageVerifier.clearReplayCache()
        return storageService.deleteIdentity()
    }

    override fun signProtocolMessage(
        messageType: ProtocolMessageType,
        payload: String
    ): SignedProtocolMessage {
        val identity = getPublicIdentity()
            ?: throw IllegalStateException("Cannot sign protocol message: no node identity exists")
        val privateKeyBytes = storageService.loadPrivateKeyBytes()
            ?: throw IllegalStateException("Private key seed is unavailable in secure storage")

        try {
            return signatureService.signMessage(
                identity = identity,
                privateKeyBytes = privateKeyBytes,
                messageType = messageType,
                payload = payload
            )
        } finally {
            // Security best practice: wipe in-memory decrypted private key bytes
            privateKeyBytes.fill(0)
        }
    }

    override fun verifyProtocolMessage(message: SignedProtocolMessage): MessageVerificationResult {
        return messageVerifier.verifyMessage(message)
    }

    override fun verifySelfIdentity(): Boolean {
        val identity = getPublicIdentity() ?: return false
        val privateKeyBytes = storageService.loadPrivateKeyBytes() ?: return false
        return try {
            val challenge = "NMD-CHALLENGE-${System.currentTimeMillis()}".toByteArray(Charsets.UTF_8)
            val signature = signatureService.signData(privateKeyBytes, challenge)
            val pubBytes = cryptoProvider.fromHex(identity.publicKeyHex)
            signatureService.verifySignature(pubBytes, challenge, signature)
        } catch (_: Exception) {
            false
        } finally {
            privateKeyBytes.fill(0)
        }
    }
}
