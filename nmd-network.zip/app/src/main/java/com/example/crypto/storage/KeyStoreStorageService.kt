package com.example.crypto.storage

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyInfo
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.crypto.model.KeyStorageSecurityStatus
import com.example.crypto.model.NodeIdentity
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec

/**
 * Manages secure storage of Node Identity cryptographic material.
 *
 * Security Architecture (Strict Stage 4 Compliance):
 * - Private keys are NEVER stored in plaintext.
 * - Private key seeds are encrypted with an AES-256-GCM master key protected by the Android KeyStore.
 * - Hardware security is explicitly checked via KeyInfo.isInsideSecureHardware().
 *   We NEVER claim hardware-backed protection unless strictly verified.
 * - Software-backed storage is clearly reported when hardware-backed security is absent.
 * - Secure deletion explicitly purges the ciphertext and wipes the master key entry from KeyStore.
 */
class KeyStoreStorageService(
    val context: Context,
    private val preferencesName: String = PREFS_NODE_IDENTITY,
    val allowTestEnvironmentFallback: Boolean = false
) {
    private val prefs: SharedPreferences = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)

    fun hasStoredIdentity(): Boolean {
        return prefs.contains(KEY_CIPHERTEXT) &&
               prefs.contains(KEY_IV) &&
               prefs.contains(KEY_NODE_ID) &&
               prefs.contains(KEY_PUBLIC_KEY)
    }

    /**
     * Stores the Ed25519 private key seed securely by encrypting it with the KeyStore master key.
     */
    fun storeIdentity(
        identity: NodeIdentity,
        privateKeyBytes: ByteArray
    ) {
        require(privateKeyBytes.size == 32) { "Private key seed must be exactly 32 bytes" }

        val (masterKey, isHardware) = getOrCreateMasterKey()
        val securityStatus = if (isHardware) {
            KeyStorageSecurityStatus.HARDWARE_BACKED_KEYSTORE
        } else {
            KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        }

        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, masterKey)
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(privateKeyBytes)

        prefs.edit()
            .putString(KEY_NODE_ID, identity.nodeId)
            .putString(KEY_PUBLIC_KEY, identity.publicKeyHex)
            .putString(KEY_FINGERPRINT, identity.publicKeyFingerprint)
            .putString(KEY_ALGORITHM, identity.algorithm)
            .putLong(KEY_TIMESTAMP, identity.creationTimestamp)
            .putInt(KEY_VERSION, identity.version)
            .putString(KEY_SECURITY_STATUS, securityStatus.name)
            .putString(KEY_CIPHERTEXT, Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .putString(KEY_IV, Base64.encodeToString(iv, Base64.NO_WRAP))
            .commit()
    }

    /**
     * Loads the public NodeIdentity record.
     * Contains ONLY public metadata; NEVER exposes the private key.
     */
    fun loadPublicIdentity(): NodeIdentity? {
        if (!hasStoredIdentity()) return null

        val nodeId = prefs.getString(KEY_NODE_ID, null) ?: return null
        val publicKeyHex = prefs.getString(KEY_PUBLIC_KEY, null) ?: return null
        val fingerprint = prefs.getString(KEY_FINGERPRINT, "") ?: ""
        val algorithm = prefs.getString(KEY_ALGORITHM, NodeIdentity.ALGORITHM_ED25519) ?: NodeIdentity.ALGORITHM_ED25519
        val timestamp = prefs.getLong(KEY_TIMESTAMP, 0L)
        val version = prefs.getInt(KEY_VERSION, NodeIdentity.IDENTITY_VERSION)
        val statusName = prefs.getString(KEY_SECURITY_STATUS, KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE.name)
        val securityStatus = try {
            KeyStorageSecurityStatus.valueOf(statusName!!)
        } catch (_: Exception) {
            KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE
        }

        return NodeIdentity(
            nodeId = nodeId,
            publicKeyHex = publicKeyHex,
            publicKeyFingerprint = fingerprint,
            algorithm = algorithm,
            creationTimestamp = timestamp,
            version = version,
            securityStatus = securityStatus
        )
    }

    /**
     * Decrypts and retrieves the private key seed in memory for signing operations.
     * The decrypted bytes must NEVER be logged or leaked into the UI.
     */
    fun loadPrivateKeyBytes(): ByteArray? {
        if (!hasStoredIdentity()) return null

        val ciphertextB64 = prefs.getString(KEY_CIPHERTEXT, null) ?: return null
        val ivB64 = prefs.getString(KEY_IV, null) ?: return null

        val ciphertext = Base64.decode(ciphertextB64, Base64.NO_WRAP)
        val iv = Base64.decode(ivB64, Base64.NO_WRAP)

        val (masterKey, _) = getOrCreateMasterKey()
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, masterKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))

        return cipher.doFinal(ciphertext)
    }

    /**
     * Irreversibly deletes the Node Identity and securely destroys the KeyStore master key.
     */
    fun deleteIdentity(): Boolean {
        prefs.edit().clear().commit()
        fallbackKey = null
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
            keyStore.load(null)
            if (keyStore.containsAlias(MASTER_KEY_ALIAS)) {
                keyStore.deleteEntry(MASTER_KEY_ALIAS)
            }
        } catch (_: Exception) {
            // KeyStore entry cleanup
        }
        return true
    }

    private var fallbackKey: SecretKey? = null

    private fun getOrCreateMasterKey(): Pair<SecretKey, Boolean> {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
            keyStore.load(null)

            if (keyStore.containsAlias(MASTER_KEY_ALIAS)) {
                val existing = keyStore.getKey(MASTER_KEY_ALIAS, null) as? SecretKey
                if (existing != null) {
                    val isHardware = checkIsHardwareBacked(existing)
                    return Pair(existing, isHardware)
                }
            }

            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val keyGenSpec = KeyGenParameterSpec.Builder(
                MASTER_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()

            keyGenerator.init(keyGenSpec)
            val newKey = keyGenerator.generateKey()
            val isHardware = checkIsHardwareBacked(newKey)
            Pair(newKey, isHardware)
        } catch (e: Exception) {
            if (allowTestEnvironmentFallback) {
                // Isolated strictly to test environments without AndroidKeyStore SPI
                getOrCreateSoftwareFallbackKey()
            } else {
                // Fail securely in production: never silently degrade encryption to a software key
                throw SecurityException(
                    "AndroidKeyStore hardware security failure: unable to access or initialize master key. " +
                    "Production builds strictly require AndroidKeyStore and will not silently downgrade key protection.",
                    e
                )
            }
        }
    }

    private fun getOrCreateSoftwareFallbackKey(): Pair<SecretKey, Boolean> {
        val existing = fallbackKey
        if (existing != null) {
            return Pair(existing, false)
        }
        val encodedB64 = prefs.getString(KEY_FALLBACK_KEY, null)
        if (encodedB64 != null) {
            val keyBytes = Base64.decode(encodedB64, Base64.NO_WRAP)
            val restored = javax.crypto.spec.SecretKeySpec(keyBytes, "AES")
            fallbackKey = restored
            return Pair(restored, false)
        }
        val keyGen = KeyGenerator.getInstance("AES")
        keyGen.init(256)
        val generated = keyGen.generateKey()
        fallbackKey = generated
        prefs.edit().putString(KEY_FALLBACK_KEY, Base64.encodeToString(generated.encoded, Base64.NO_WRAP)).commit()
        return Pair(generated, false)
    }

    private fun checkIsHardwareBacked(secretKey: SecretKey): Boolean {
        return try {
            val factory = SecretKeyFactory.getInstance(secretKey.algorithm, ANDROID_KEYSTORE)
            val keyInfo = factory.getKeySpec(secretKey, KeyInfo::class.java) as KeyInfo
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                keyInfo.securityLevel == KeyProperties.SECURITY_LEVEL_TRUSTED_ENVIRONMENT ||
                keyInfo.securityLevel == KeyProperties.SECURITY_LEVEL_STRONGBOX
            } else {
                @Suppress("DEPRECATION")
                keyInfo.isInsideSecureHardware
            }
        } catch (_: Exception) {
            // Emulators or software key stores will throw or return false
            false
        }
    }

    companion object {
        const val PREFS_NODE_IDENTITY = "nmd_node_cryptographic_identity"
        private const val MASTER_KEY_ALIAS = "nmd_node_identity_master_key_v1"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_LENGTH_BITS = 128

        const val KEY_NODE_ID = "identity_node_id"
        const val KEY_PUBLIC_KEY = "identity_public_key"
        const val KEY_FINGERPRINT = "identity_fingerprint"
        const val KEY_ALGORITHM = "identity_algorithm"
        const val KEY_TIMESTAMP = "identity_timestamp"
        const val KEY_VERSION = "identity_version"
        const val KEY_SECURITY_STATUS = "identity_security_status"
        const val KEY_CIPHERTEXT = "identity_private_ciphertext"
        const val KEY_IV = "identity_private_iv"
        private const val KEY_FALLBACK_KEY = "identity_software_fallback_key"
    }
}
