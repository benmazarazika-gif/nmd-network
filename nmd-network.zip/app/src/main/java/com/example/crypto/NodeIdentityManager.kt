package com.example.crypto

import android.content.Context
import com.example.crypto.model.MessageVerificationResult
import com.example.crypto.model.NodeIdentity
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.crypto.repository.IdentityRepository
import com.example.crypto.repository.IdentityRepositoryImpl
import com.example.crypto.storage.KeyStoreStorageService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SelfVerificationStatus {
    IDLE,
    VERIFYING,
    VERIFIED_SUCCESS,
    VERIFIED_FAILED
}

/**
 * High-level manager coordinating cryptographic identity operations, signature generation,
 * and verification state flows for the UI.
 */
class NodeIdentityManager(
    val repository: IdentityRepository
) {
    constructor(context: Context) : this(
        repository = IdentityRepositoryImpl(
            cryptoProvider = BouncyCastleEd25519Provider(),
            storageService = KeyStoreStorageService(context.applicationContext)
        )
    )

    private val _identity = MutableStateFlow<NodeIdentity?>(repository.getPublicIdentity())
    val identity: StateFlow<NodeIdentity?> = _identity.asStateFlow()

    private val _selfVerificationStatus = MutableStateFlow(SelfVerificationStatus.IDLE)
    val selfVerificationStatus: StateFlow<SelfVerificationStatus> = _selfVerificationStatus.asStateFlow()

    private val _lastSignedMessage = MutableStateFlow<SignedProtocolMessage?>(null)
    val lastSignedMessage: StateFlow<SignedProtocolMessage?> = _lastSignedMessage.asStateFlow()

    private val _lastVerificationResult = MutableStateFlow<MessageVerificationResult?>(null)
    val lastVerificationResult: StateFlow<MessageVerificationResult?> = _lastVerificationResult.asStateFlow()

    fun generateNewIdentity(): NodeIdentity {
        val newIdentity = repository.generateIdentity()
        _identity.value = newIdentity
        _selfVerificationStatus.value = SelfVerificationStatus.IDLE
        return newIdentity
    }

    fun importIdentitySeed(privateKeyBytes: ByteArray): NodeIdentity {
        val imported = repository.importIdentitySeed(privateKeyBytes)
        _identity.value = imported
        _selfVerificationStatus.value = SelfVerificationStatus.IDLE
        return imported
    }

    fun deleteIdentity(): Boolean {
        val result = repository.deleteIdentity()
        _identity.value = null
        _selfVerificationStatus.value = SelfVerificationStatus.IDLE
        _lastSignedMessage.value = null
        _lastVerificationResult.value = null
        return result
    }

    fun verifySelfIdentity(): Boolean {
        _selfVerificationStatus.value = SelfVerificationStatus.VERIFYING
        val isOk = repository.verifySelfIdentity()
        _selfVerificationStatus.value = if (isOk) {
            SelfVerificationStatus.VERIFIED_SUCCESS
        } else {
            SelfVerificationStatus.VERIFIED_FAILED
        }
        return isOk
    }

    fun signTestMessage(
        messageType: ProtocolMessageType = ProtocolMessageType.NODE_ANNOUNCEMENT,
        payload: String = "{\"status\":\"ACTIVE_DEMO\",\"node_version\":\"1.0.0\"}"
    ): SignedProtocolMessage {
        val signed = repository.signProtocolMessage(messageType, payload)
        _lastSignedMessage.value = signed
        return signed
    }

    fun verifyMessage(message: SignedProtocolMessage): MessageVerificationResult {
        val result = repository.verifyProtocolMessage(message)
        _lastVerificationResult.value = result
        return result
    }

    fun getActiveIdentity(): NodeIdentity? = _identity.value

    fun signRawData(data: ByteArray): ByteArray {
        return repository.signRawData(data)
    }

    fun signProtocolMessage(
        messageType: ProtocolMessageType,
        payload: String
    ): SignedProtocolMessage {
        val signed = repository.signProtocolMessage(messageType, payload)
        _lastSignedMessage.value = signed
        return signed
    }

    fun exportPublicIdentityJson(): String {
        return repository.exportPublicIdentityJson()
    }
}
