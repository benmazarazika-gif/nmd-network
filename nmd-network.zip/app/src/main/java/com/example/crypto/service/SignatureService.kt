package com.example.crypto.service

import com.example.crypto.model.NodeIdentity
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.crypto.provider.CryptographicProvider
import java.util.UUID

/**
 * Service providing digital signing and signature generation for node protocol messages.
 */
class SignatureService(
    private val cryptoProvider: CryptographicProvider
) {
    /**
     * Creates and signs an authentic protocol message using the node's Ed25519 private key seed.
     */
    fun signMessage(
        identity: NodeIdentity,
        privateKeyBytes: ByteArray,
        messageType: ProtocolMessageType,
        payload: String,
        timestamp: Long = System.currentTimeMillis(),
        messageId: String = UUID.randomUUID().toString()
    ): SignedProtocolMessage {
        val unsignedMessage = SignedProtocolMessage(
            protocolVersion = SignedProtocolMessage.CURRENT_PROTOCOL_VERSION,
            messageType = messageType,
            senderNodeId = identity.nodeId,
            senderPublicKey = identity.publicKeyHex,
            timestamp = timestamp,
            messageId = messageId,
            payload = payload,
            signatureHex = "", // Will be populated with signature
            isLocalDemoMessage = true
        )

        val canonicalBytes = unsignedMessage.getCanonicalBytes()
        val signatureBytes = cryptoProvider.sign(privateKeyBytes, canonicalBytes)
        val signatureHex = cryptoProvider.toHex(signatureBytes)

        return unsignedMessage.copy(signatureHex = signatureHex)
    }

    fun signData(privateKeyBytes: ByteArray, data: ByteArray): ByteArray {
        return cryptoProvider.sign(privateKeyBytes, data)
    }

    fun verifySignature(publicKeyBytes: ByteArray, data: ByteArray, signatureBytes: ByteArray): Boolean {
        return cryptoProvider.verify(publicKeyBytes, data, signatureBytes)
    }
}
