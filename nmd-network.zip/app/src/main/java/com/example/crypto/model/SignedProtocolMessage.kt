package com.example.crypto.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Represents a cryptographically signed protocol message between NMD nodes.
 *
 * NOTE: As required by Stage 4:
 * - These messages are local cryptographic test objects only.
 * - They are never claimed to have been broadcast or transmitted through a live P2P network.
 * - Signatures are authentic Ed25519 digital signatures calculated over canonical message bytes.
 */
data class SignedProtocolMessage(
    val protocolVersion: Int = CURRENT_PROTOCOL_VERSION,
    val messageType: ProtocolMessageType,
    val senderNodeId: String,
    val senderPublicKey: String,
    val timestamp: Long,
    val messageId: String,
    val payload: String,
    val signatureHex: String,
    val isLocalDemoMessage: Boolean = true
) {
    /**
     * Produces the deterministic, length-prefixed canonical byte sequence for signing and verification.
     *
     * Format (Deterministic Length-Prefixed Binary Canonicalization - NMD-SIG-V2):
     * - Header: ASCII "NMD-SIG-V2\u0000" (11 bytes)
     * - Protocol Version: 4 bytes Int (Big-Endian)
     * - Message Type: 4 bytes Int (length) + UTF-8 bytes
     * - Sender Node ID: 4 bytes Int (length) + UTF-8 bytes
     * - Sender Public Key: 4 bytes Int (length) + UTF-8 bytes
     * - Timestamp: 8 bytes Long (Big-Endian)
     * - Message ID: 4 bytes Int (length) + UTF-8 bytes
     * - Payload: 4 bytes Int (length) + UTF-8 bytes
     *
     * Mathematical Guarantee:
     * Length prefixing completely eliminates delimiter collision, delimiter injection,
     * truncation attacks, and accidental cross-field collision across arbitrary payloads.
     */
    fun getCanonicalBytes(): ByteArray {
        val baos = java.io.ByteArrayOutputStream()
        val dos = java.io.DataOutputStream(baos)
        dos.write("NMD-SIG-V2\u0000".toByteArray(Charsets.UTF_8))
        dos.writeInt(protocolVersion)
        writeLengthPrefixedString(dos, messageType.name)
        writeLengthPrefixedString(dos, senderNodeId)
        writeLengthPrefixedString(dos, senderPublicKey)
        dos.writeLong(timestamp)
        writeLengthPrefixedString(dos, messageId)
        writeLengthPrefixedString(dos, payload)
        dos.flush()
        return baos.toByteArray()
    }

    private fun writeLengthPrefixedString(dos: java.io.DataOutputStream, str: String) {
        val bytes = str.toByteArray(Charsets.UTF_8)
        dos.writeInt(bytes.size)
        dos.write(bytes)
    }

    val canonicalRepresentation: String
        get() = "[NMD-SIG-V2:v$protocolVersion:${messageType.name}:${senderNodeId.length}:$senderNodeId:${senderPublicKey.length}:$senderPublicKey:ts$timestamp:${messageId.length}:$messageId:${payload.length}:$payload]"

    val formattedTimestamp: String
        get() {
            val sdf = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            return sdf.format(Date(timestamp))
        }

    val timestampFormatted: String
        get() = formattedTimestamp

    val truncatedSignature: String
        get() = if (signatureHex.length > 20) {
            "${signatureHex.substring(0, 10)}...${signatureHex.substring(signatureHex.length - 8)}"
        } else {
            signatureHex
        }

    fun toJson(): String {
        val json = org.json.JSONObject()
        json.put("protocol_version", protocolVersion)
        json.put("message_type", messageType.name)
        json.put("sender_node_id", senderNodeId)
        json.put("sender_public_key", senderPublicKey)
        json.put("timestamp", timestamp)
        json.put("timestamp_utc", formattedTimestamp)
        json.put("message_id", messageId)
        json.put("payload", payload)
        json.put("signature", signatureHex)
        json.put("is_local_demo_message", isLocalDemoMessage)
        return json.toString()
    }

    companion object {
        const val CURRENT_PROTOCOL_VERSION = 2

        fun fromJson(jsonStr: String): SignedProtocolMessage {
            val json = org.json.JSONObject(jsonStr)
            val version = json.optInt("protocol_version", CURRENT_PROTOCOL_VERSION)
            val typeStr = json.getString("message_type")
            val messageType = ProtocolMessageType.valueOf(typeStr)
            val senderId = json.getString("sender_node_id")
            val senderPub = json.getString("sender_public_key")
            val timestamp = json.getLong("timestamp")
            val messageId = json.getString("message_id")
            val payload = json.getString("payload")
            val sig = json.getString("signature")
            val isDemo = json.optBoolean("is_local_demo_message", true)

            return SignedProtocolMessage(
                protocolVersion = version,
                messageType = messageType,
                senderNodeId = senderId,
                senderPublicKey = senderPub,
                timestamp = timestamp,
                messageId = messageId,
                payload = payload,
                signatureHex = sig,
                isLocalDemoMessage = isDemo
            )
        }
    }
}
