package com.example.crypto.model

import com.example.R

enum class VerificationFailureReason(val messageRes: Int) {
    INVALID_SIGNATURE(R.string.verify_err_invalid_signature),
    SENDER_NODE_ID_MISMATCH(R.string.verify_err_sender_mismatch),
    EXPIRED_TIMESTAMP(R.string.verify_err_expired_timestamp),
    FUTURE_TIMESTAMP(R.string.verify_err_future_timestamp),
    DUPLICATE_MESSAGE_ID(R.string.verify_err_duplicate_message_id),
    MALFORMED_FORMAT(R.string.verify_err_malformed)
}

sealed class MessageVerificationResult {
    data class Valid(
        val message: SignedProtocolMessage,
        val verificationTimestamp: Long = System.currentTimeMillis()
    ) : MessageVerificationResult()

    data class Invalid(
        val reason: VerificationFailureReason,
        val detail: String,
        val message: SignedProtocolMessage? = null
    ) : MessageVerificationResult()

    val isValid: Boolean
        get() = this is Valid
}
