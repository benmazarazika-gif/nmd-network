package com.example.crypto.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Public Node Identity record representing a cryptographic identity for an NMD Network node.
 *
 * Requirements strictly enforced:
 * - Deterministic node identifier derived from public key.
 * - Private key material is NEVER stored or exposed in this data structure.
 * - Algorithm is Ed25519 (RFC 8032).
 */
data class NodeIdentity(
    val nodeId: String,
    val publicKeyHex: String,
    val publicKeyFingerprint: String,
    val algorithm: String = ALGORITHM_ED25519,
    val creationTimestamp: Long,
    val version: Int = IDENTITY_VERSION,
    val securityStatus: KeyStorageSecurityStatus
) {
    val formattedCreationDate: String
        get() {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            return sdf.format(Date(creationTimestamp))
        }

    val creationDateFormatted: String
        get() = formattedCreationDate

    val truncatedNodeId: String
        get() = if (nodeId.length > 24) {
            "${nodeId.substring(0, 14)}...${nodeId.substring(nodeId.length - 8)}"
        } else {
            nodeId
        }

    val truncatedPublicKey: String
        get() = if (publicKeyHex.length > 20) {
            "${publicKeyHex.substring(0, 10)}...${publicKeyHex.substring(publicKeyHex.length - 8)}"
        } else {
            publicKeyHex
        }

    /**
     * Serializes this public identity into a safe, exportable JSON string.
     * Contains ONLY public metadata and keys; NEVER contains private key data.
     */
    fun toPublicJson(): String {
        return """
        {
          "version": $version,
          "algorithm": "$algorithm",
          "node_id": "$nodeId",
          "public_key_hex": "$publicKeyHex",
          "fingerprint": "$publicKeyFingerprint",
          "created_at_epoch_ms": $creationTimestamp,
          "created_at_utc": "$formattedCreationDate",
          "security_status": "${securityStatus.name}",
          "hardware_backed": ${securityStatus.isHardwareBacked}
        }
        """.trimIndent()
    }

    companion object {
        const val ALGORITHM_ED25519 = "Ed25519"
        const val IDENTITY_VERSION = 1
        const val NODE_ID_PREFIX = "nmd_node_"
    }
}
