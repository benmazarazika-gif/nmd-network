package com.example.crypto.model

import com.example.R

/**
 * Enumeration of protocol message types supported by the NMD node identity layer.
 */
enum class ProtocolMessageType(val titleRes: Int) {
    NODE_ANNOUNCEMENT(R.string.msg_type_announcement),
    HEARTBEAT(R.string.msg_type_heartbeat),
    PEER_PING(R.string.msg_type_ping),
    STATE_SYNC_REQUEST(R.string.msg_type_sync_req),
    GOSSIP_DATA(R.string.msg_type_gossip)
}
