package com.example.crypto.provider

data class Ed25519KeyPairResult(
    val privateKeyBytes: ByteArray,
    val publicKeyBytes: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as Ed25519KeyPairResult
        if (!privateKeyBytes.contentEquals(other.privateKeyBytes)) return false
        if (!publicKeyBytes.contentEquals(other.publicKeyBytes)) return false
        return true
    }

    override fun hashCode(): Int {
        var result = privateKeyBytes.contentHashCode()
        result = 31 * result + publicKeyBytes.contentHashCode()
        return result
    }
}

/**
 * Interface defining standard cryptographic operations required for NMD blockchain nodes.
 */
interface CryptographicProvider {
    fun generateEd25519KeyPair(): Ed25519KeyPairResult
    fun derivePublicKeyFromPrivate(privateKeyBytes: ByteArray): ByteArray
    fun deriveNodeId(publicKeyBytes: ByteArray): String
    fun computeFingerprint(publicKeyBytes: ByteArray): String
    fun sign(privateKeyBytes: ByteArray, data: ByteArray): ByteArray
    fun verify(publicKeyBytes: ByteArray, data: ByteArray, signature: ByteArray): Boolean
    fun sha256(data: ByteArray): ByteArray
    fun toHex(data: ByteArray): String
    fun fromHex(hex: String): ByteArray
}
