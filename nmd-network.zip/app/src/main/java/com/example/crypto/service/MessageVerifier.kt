package com.example.crypto.service

import android.content.Context
import android.content.SharedPreferences
import com.example.crypto.model.MessageVerificationResult
import com.example.crypto.model.NodeIdentity
import com.example.crypto.model.SignedProtocolMessage
import com.example.crypto.model.VerificationFailureReason
import com.example.crypto.provider.CryptographicProvider
import kotlin.math.abs

/**
 * Validates protocol messages against cryptographic signatures, sender ownership,
 * timestamp boundaries, and replay/duplicate message attacks.
 *
 * Implements persistent, atomic local replay protection that survives application restarts.
 */
class MessageVerifier(
    private val cryptoProvider: CryptographicProvider,
    private val maxAllowedDriftMs: Long = DEFAULT_MAX_DRIFT_MS,
    private val currentTimeProvider: () -> Long = { System.currentTimeMillis() },
    context: Context? = null,
    replayCachePreferencesName: String = DEFAULT_REPLAY_CACHE_NAME
) {
    private val prefs: SharedPreferences? = context?.getSharedPreferences(
        replayCachePreferencesName,
        Context.MODE_PRIVATE
    )

    // Thread-safe fast in-memory replay protection cache
    private val seenMessageIds = mutableMapOf<String, Long>()

    init {
        // Load persistent seen messages across application restarts
        prefs?.all?.forEach { (key, value) ->
            if (value is Long) {
                seenMessageIds[key] = value
            }
        }
        cleanExpiredSeenMessages(currentTimeProvider())
    }

    @Synchronized
    fun verifyMessage(message: SignedProtocolMessage): MessageVerificationResult {
        val now = currentTimeProvider()

        // 1. Structural / format check
        if (message.messageId.isBlank() ||
            message.senderNodeId.isBlank() ||
            message.senderPublicKey.isBlank() ||
            message.signatureHex.isBlank()
        ) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.MALFORMED_FORMAT,
                detail = "Message contains blank required protocol fields",
                message = message
            )
        }

        if (!message.senderNodeId.startsWith(NodeIdentity.NODE_ID_PREFIX)) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.MALFORMED_FORMAT,
                detail = "Sender node ID does not follow the required prefix convention",
                message = message
            )
        }

        val publicKeyBytes = try {
            cryptoProvider.fromHex(message.senderPublicKey)
        } catch (_: Exception) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.MALFORMED_FORMAT,
                detail = "Sender public key is not valid hex",
                message = message
            )
        }

        if (publicKeyBytes.size != 32) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.MALFORMED_FORMAT,
                detail = "Sender public key must be exactly 32 bytes (64 hex characters)",
                message = message
            )
        }

        val signatureBytes = try {
            cryptoProvider.fromHex(message.signatureHex)
        } catch (_: Exception) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.MALFORMED_FORMAT,
                detail = "Signature is not valid hex",
                message = message
            )
        }

        if (signatureBytes.size != 64) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.MALFORMED_FORMAT,
                detail = "Ed25519 signature must be exactly 64 bytes (128 hex characters)",
                message = message
            )
        }

        // 2. Sender Identity verification: derived node ID must match claimed senderNodeId
        val derivedNodeId = cryptoProvider.deriveNodeId(publicKeyBytes)
        if (derivedNodeId != message.senderNodeId) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.SENDER_NODE_ID_MISMATCH,
                detail = "Claimed sender Node ID (${message.senderNodeId}) does not match public key hash ($derivedNodeId)",
                message = message
            )
        }

        // 3. Timestamp verification (drift window check)
        if (message.timestamp < now - maxAllowedDriftMs) {
            val expiredAgoSec = (now - message.timestamp) / 1000
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.EXPIRED_TIMESTAMP,
                detail = "Message expired: timestamp is older than allowed window by $expiredAgoSec seconds",
                message = message
            )
        }

        if (message.timestamp > now + maxAllowedDriftMs) {
            val futureSec = (message.timestamp - now) / 1000
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.FUTURE_TIMESTAMP,
                detail = "Message rejected: timestamp is in the future by $futureSec seconds",
                message = message
            )
        }

        // 4. Replay protection (Duplicate message ID check)
        cleanExpiredSeenMessages(now)
        if (seenMessageIds.containsKey(message.messageId)) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.DUPLICATE_MESSAGE_ID,
                detail = "Duplicate message detected: ID ${message.messageId} was already processed",
                message = message
            )
        }

        // 5. Cryptographic signature verification over canonical bytes
        val canonicalBytes = message.getCanonicalBytes()
        val isSignatureValid = cryptoProvider.verify(
            publicKeyBytes = publicKeyBytes,
            data = canonicalBytes,
            signature = signatureBytes
        )

        if (!isSignatureValid) {
            return MessageVerificationResult.Invalid(
                reason = VerificationFailureReason.INVALID_SIGNATURE,
                detail = "Ed25519 signature verification failed over canonical message bytes",
                message = message
            )
        }

        // Success: register in seen cache and return Valid result
        seenMessageIds[message.messageId] = now
        prefs?.edit()?.putLong(message.messageId, now)?.apply()

        return MessageVerificationResult.Valid(
            message = message,
            verificationTimestamp = now
        )
    }

    @Synchronized
    fun clearReplayCache() {
        seenMessageIds.clear()
        prefs?.edit()?.clear()?.apply()
    }

    private fun cleanExpiredSeenMessages(now: Long) {
        val cutoff = now - (maxAllowedDriftMs * 2)
        val expired = mutableListOf<String>()
        val iter = seenMessageIds.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next()
            if (entry.value < cutoff) {
                expired.add(entry.key)
                iter.remove()
            }
        }
        if (expired.isNotEmpty() && prefs != null) {
            val editor = prefs.edit()
            expired.forEach { editor.remove(it) }
            editor.apply()
        }
    }

    companion object {
        const val DEFAULT_MAX_DRIFT_MS: Long = 5 * 60 * 1000L // 5 minutes
        const val DEFAULT_REPLAY_CACHE_NAME = "nmd_protocol_replay_cache"
    }
}
