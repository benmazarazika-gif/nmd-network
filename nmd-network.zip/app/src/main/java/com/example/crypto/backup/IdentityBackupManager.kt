package com.example.crypto.backup

import android.util.Base64
import com.example.crypto.NodeIdentityManager
import com.example.crypto.model.NodeIdentity
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.transaction.crypto.NmdAddressCodec
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class RestoredBackupOutcome(
    val identity: NodeIdentity,
    val nmdAddress: String
)

/**
 * Portable Non-Custodial Wallet & Identity Backup Manager (Stage 19/20).
 *
 * Provides two lossless, checksummed backup mechanisms for user-owned Ed25519 seeds:
 * 1. **Encrypted Portable Keystore JSON** (`NMD_KEYSTORE_V1`):
 *    PBKDF2WithHmacSHA256 (120,000 iterations, random 16B salt) + AES-256-GCM (12B random IV)
 *    with AAD binding header metadata (`format|nmd_address`).
 * 2. **Checksummed 33-Word Recovery Phrase**:
 *    Encodes 32-byte Ed25519 seed (256 bits) + 1-byte SHA-256 checksum (264 bits) using a
 *    verified 256-unique-word dictionary so any missing/typoed word is immediately rejected.
 *
 * Security: Zero plaintext key material is stored on disk; temporary seed arrays are zero-wiped in `finally`.
 */
object IdentityBackupManager {

    private const val FORMAT_KEYSTORE_V1 = "NMD_KEYSTORE_V1"
    private const val KDF_ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val KDF_ITERATIONS = 120_000
    private const val SALT_BYTES = 16
    private const val IV_BYTES = 12
    private const val TAG_BITS = 128
    private const val KEY_BITS = 256
    private const val MIN_PASSPHRASE_LEN = 8

    // 256 guaranteed-unique common words (8 bits per word => 32 bytes + 1 checksum byte = 33 words)
    internal val WORD_LIST: List<String> = listOf(
        "acorn", "anchor", "apple", "apron", "arch", "arrow", "aspen", "atlas",
        "autumn", "badge", "baker", "bamboo", "banjo", "banner", "barrel", "basin",
        "basket", "beacon", "beaver", "bellow", "bench", "berry", "bicycle", "birch",
        "bison", "blade", "blanket", "blaze", "blossom", "boulder", "branch", "brass",
        "breeze", "brick", "bridge", "bronze", "brook", "brush", "bucket", "buffalo",
        "bugle", "cabin", "cactus", "camel", "camera", "candle", "cannon", "canoe",
        "canyon", "carbon", "cargo", "carpet", "carrot", "castle", "cedar", "cellar",
        "ceramic", "chalice", "chapel", "cherry", "chisel", "cinder", "circle", "citadel",
        "cliff", "cloak", "clock", "cloud", "clover", "cobble", "copper", "coral",
        "corner", "cotton", "cradle", "craft", "crater", "creek", "crest", "cricket",
        "crown", "crystal", "cupola", "current", "cypress", "dagger", "daisy", "dawn",
        "delta", "desert", "diamond", "dolphin", "dome", "donkey", "dragon", "drift",
        "drum", "dune", "eagle", "earth", "echo", "ember", "emerald", "engine",
        "epoch", "falcon", "feather", "fence", "fern", "fiddle", "field", "fig",
        "fjord", "flame", "flint", "flora", "flute", "forest", "forge", "fossil",
        "fountain", "fox", "frame", "frost", "garden", "garnet", "gate", "gazelle",
        "geyser", "glacier", "glass", "globe", "granite", "grape", "gravel", "grove",
        "hammer", "harbor", "harp", "harvest", "haven", "hawk", "hazel", "hearth",
        "helmet", "heron", "hickory", "hill", "hollow", "horizon", "horn", "horse",
        "hunter", "iceberg", "indigo", "ink", "iron", "island", "ivory", "jacket",
        "jade", "jaguar", "jasmine", "jester", "jewel", "juniper", "kayak", "kettle",
        "key", "kestrel", "kite", "knoll", "ladder", "lagoon", "lamp", "lance",
        "lantern", "larch", "lark", "lattice", "laurel", "lava", "leaf", "ledge",
        "lemon", "leopard", "level", "lichen", "lilac", "lily", "linen", "lion",
        "lizard", "locket", "lodge", "lotus", "lumber", "lunar", "lute", "lynx",
        "magnet", "magpie", "maple", "marble", "market", "marsh", "meadow", "melon",
        "mesa", "metal", "meteor", "mill", "mirror", "mist", "mitten", "monarch",
        "moon", "moor", "morning", "mortar", "moss", "moth", "mountain", "mulberry",
        "mural", "museum", "musket", "myrtle", "nebula", "nectar", "needle", "nest",
        "nettle", "nickel", "nimbus", "nomad", "north", "nutmeg", "oak", "oasis",
        "oat", "ocean", "ochre", "olive", "onion", "onyx", "opal", "oracle",
        "orange", "orbit", "orchard", "orchid", "oregano", "oriole", "osprey", "otter"
    )

    private val WORD_TO_INDEX: Map<String, Int> by lazy {
        require(WORD_LIST.size == 256 && WORD_LIST.distinct().size == 256) {
            "NMD recovery dictionary must contain 256 distinct words"
        }
        WORD_LIST.mapIndexed { idx, w -> w to idx }.toMap()
    }

    fun exportEncryptedKeystoreJson(
        identityManager: NodeIdentityManager,
        passphrase: String,
        cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider
    ): Result<String> {
        if (passphrase.length < MIN_PASSPHRASE_LEN) {
            return Result.failure(IllegalArgumentException("Passphrase must be at least $MIN_PASSPHRASE_LEN characters"))
        }
        val active = identityManager.getActiveIdentity()
            ?: return Result.failure(IllegalStateException("No active Ed25519 node identity"))
        val seed = identityManager.repository.exportPrivateSeedBytesCopy()
            ?: return Result.failure(IllegalStateException("Private key unavailable in KeyStore"))
        return try {
            val nmdAddress = NmdAddressCodec.deriveAddressFromPublicKeyHex(active.publicKeyHex, cryptoProvider)
                ?: return Result.failure(IllegalStateException("Unable to derive NMD address from public key"))
            val json = encryptSeedToKeystoreJson(seed, nmdAddress, active.nodeId, active.publicKeyHex, passphrase)
            Result.success(json)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            seed.fill(0)
        }
    }

    internal fun encryptSeedToKeystoreJson(
        seed: ByteArray,
        nmdAddress: String,
        nodeId: String,
        publicKeyHex: String,
        passphrase: String
    ): String {
        require(seed.size == 32) { "Seed must be 32 bytes" }
        val rng = SecureRandom()
        val salt = ByteArray(SALT_BYTES).also { rng.nextBytes(it) }
        val iv = ByteArray(IV_BYTES).also { rng.nextBytes(it) }

        val kdfKey = deriveAesKey(passphrase, salt, KDF_ITERATIONS)
        val aad = "$FORMAT_KEYSTORE_V1|$nmdAddress".toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, kdfKey, GCMParameterSpec(TAG_BITS, iv))
        cipher.updateAAD(aad)
        val ciphertext = cipher.doFinal(seed)

        return JSONObject().apply {
            put("format", FORMAT_KEYSTORE_V1)
            put("kdf", KDF_ALGORITHM)
            put("iterations", KDF_ITERATIONS)
            put("cipher", "AES-256-GCM")
            put("node_id", nodeId)
            put("nmd_address", nmdAddress)
            put("public_key_hex", publicKeyHex.lowercase())
            put("salt_b64", Base64.encodeToString(salt, Base64.NO_WRAP))
            put("iv_b64", Base64.encodeToString(iv, Base64.NO_WRAP))
            put("ciphertext_b64", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            put("exported_at_ms", System.currentTimeMillis())
        }.toString(2)
    }

    fun restoreFromEncryptedKeystoreJson(
        identityManager: NodeIdentityManager,
        keystoreJson: String,
        passphrase: String
    ): Result<RestoredBackupOutcome> {
        var seed: ByteArray? = null
        return try {
            val obj = JSONObject(keystoreJson.trim())
            val format = obj.getString("format")
            if (format != FORMAT_KEYSTORE_V1) {
                return Result.failure(IllegalArgumentException("Unsupported keystore format: $format"))
            }
            val nmdAddress = obj.getString("nmd_address")
            val iterations = obj.getInt("iterations").coerceAtLeast(10_000)
            val salt = Base64.decode(obj.getString("salt_b64"), Base64.NO_WRAP)
            val iv = Base64.decode(obj.getString("iv_b64"), Base64.NO_WRAP)
            val ciphertext = Base64.decode(obj.getString("ciphertext_b64"), Base64.NO_WRAP)

            val kdfKey = deriveAesKey(passphrase, salt, iterations)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, kdfKey, GCMParameterSpec(TAG_BITS, iv))
            cipher.updateAAD("$format|$nmdAddress".toByteArray(Charsets.UTF_8))
            seed = cipher.doFinal(ciphertext)
            if (seed.size != 32) {
                return Result.failure(IllegalStateException("Decrypted key length invalid"))
            }

            val restored = identityManager.importIdentitySeed(seed)
            val derivedAddr = NmdAddressCodec.deriveAddressFromPublicKeyHex(
                restored.publicKeyHex,
                identityManager.repository.cryptoProvider
            )
            if (derivedAddr != nmdAddress) {
                return Result.failure(IllegalStateException("Address mismatch after decryption"))
            }
            Result.success(RestoredBackupOutcome(restored, derivedAddr))
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            seed?.fill(0)
        }
    }

    fun exportRecoveryPhraseWords(
        identityManager: NodeIdentityManager,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): Result<List<String>> {
        val seed = identityManager.repository.exportPrivateSeedBytesCopy()
            ?: return Result.failure(IllegalStateException("No identity seed available"))
        return try {
            val words = seedToChecksummedWords(seed, cryptoProvider)
            Result.success(words)
        } finally {
            seed.fill(0)
        }
    }

    fun seedToChecksummedWords(
        seed: ByteArray,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): List<String> {
        require(seed.size == 32) { "Ed25519 seed must be exactly 32 bytes" }
        val checksumByte = cryptoProvider.sha256(seed)[0]
        val words = ArrayList<String>(33)
        seed.forEach { b -> words.add(WORD_LIST[b.toInt() and 0xFF]) }
        words.add(WORD_LIST[checksumByte.toInt() and 0xFF])
        return words
    }

    fun restoreFromRecoveryPhrase(
        identityManager: NodeIdentityManager,
        phraseText: String,
        cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider
    ): Result<RestoredBackupOutcome> {
        val tokens = phraseText.trim().lowercase()
            .split(Regex("[\\s,;]+"))
            .filter { it.isNotEmpty() }
        if (tokens.size != 33) {
            return Result.failure(IllegalArgumentException("Recovery phrase must contain 33 words (got ${tokens.size})"))
        }
        val seed = ByteArray(32)
        return try {
            for (i in 0 until 32) {
                val idx = WORD_TO_INDEX[tokens[i]]
                    ?: return Result.failure(IllegalArgumentException("Unrecognized recovery word '${tokens[i]}' at position ${i + 1}"))
                seed[i] = idx.toByte()
            }
            val expectedChecksumIdx = WORD_TO_INDEX[tokens[32]]
                ?: return Result.failure(IllegalArgumentException("Unrecognized checksum word '${tokens[32]}'"))
            val actualChecksumByte = cryptoProvider.sha256(seed)[0].toInt() and 0xFF
            if (actualChecksumByte != expectedChecksumIdx) {
                return Result.failure(IllegalArgumentException("Recovery phrase checksum mismatch — verify word order and spelling"))
            }
            val restored = identityManager.importIdentitySeed(seed)
            val addr = NmdAddressCodec.deriveAddressFromPublicKeyHex(restored.publicKeyHex, cryptoProvider)
                ?: return Result.failure(IllegalStateException("Unable to derive NMD address from restored key"))
            Result.success(RestoredBackupOutcome(restored, addr))
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            seed.fill(0)
        }
    }

    private fun deriveAesKey(passphrase: String, salt: ByteArray, iterations: Int): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance(KDF_ALGORITHM)
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, iterations, KEY_BITS)
        val raw = factory.generateSecret(spec).encoded
        return try {
            SecretKeySpec(raw, "AES")
        } finally {
            raw.fill(0)
            spec.clearPassword()
        }
    }
}
