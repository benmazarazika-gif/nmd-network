package com.example.crypto.provider

import com.example.crypto.model.NodeIdentity
import org.bouncycastle.crypto.generators.Ed25519KeyPairGenerator
import org.bouncycastle.crypto.params.Ed25519KeyGenerationParameters
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Standard, production-grade Ed25519 cryptographic provider implemented via Bouncy Castle.
 *
 * Compliance:
 * - RFC 8032 (Ed25519 signature scheme)
 * - Deterministic SHA-256 node ID derivation
 * - Constant-time verification implementation
 */
class BouncyCastleEd25519Provider(
    private val secureRandom: SecureRandom = SecureRandom()
) : CryptographicProvider {

    override fun generateEd25519KeyPair(): Ed25519KeyPairResult {
        val generator = Ed25519KeyPairGenerator()
        generator.init(Ed25519KeyGenerationParameters(secureRandom))
        val keyPair = generator.generateKeyPair()

        val privParam = keyPair.private as Ed25519PrivateKeyParameters
        val pubParam = keyPair.public as Ed25519PublicKeyParameters

        return Ed25519KeyPairResult(
            privateKeyBytes = privParam.encoded,
            publicKeyBytes = pubParam.encoded
        )
    }

    override fun derivePublicKeyFromPrivate(privateKeyBytes: ByteArray): ByteArray {
        require(privateKeyBytes.size == 32) { "Ed25519 private key seed must be exactly 32 bytes" }
        val privParam = Ed25519PrivateKeyParameters(privateKeyBytes, 0)
        return privParam.generatePublicKey().encoded
    }

    override fun deriveNodeId(publicKeyBytes: ByteArray): String {
        require(publicKeyBytes.size == 32) { "Ed25519 public key must be exactly 32 bytes" }
        val hash = sha256(publicKeyBytes)
        val hashHex = toHex(hash)
        // Deterministic Node ID: "nmd_node_" + first 32 hex characters of SHA-256(PubKey)
        return NodeIdentity.NODE_ID_PREFIX + hashHex.substring(0, 32)
    }

    override fun computeFingerprint(publicKeyBytes: ByteArray): String {
        val hash = sha256(publicKeyBytes)
        // 16 hex pairs separated by colons (OpenSSH / PGP standard representation)
        return hash.take(16).joinToString(":") { "%02X".format(it) }
    }

    override fun sign(privateKeyBytes: ByteArray, data: ByteArray): ByteArray {
        require(privateKeyBytes.size == 32) { "Ed25519 private key seed must be exactly 32 bytes" }
        val signer = Ed25519Signer()
        signer.init(true, Ed25519PrivateKeyParameters(privateKeyBytes, 0))
        signer.update(data, 0, data.size)
        return signer.generateSignature()
    }

    override fun verify(publicKeyBytes: ByteArray, data: ByteArray, signature: ByteArray): Boolean {
        if (publicKeyBytes.size != 32 || signature.size != 64) {
            return false
        }
        return try {
            val verifier = Ed25519Signer()
            verifier.init(false, Ed25519PublicKeyParameters(publicKeyBytes, 0))
            verifier.update(data, 0, data.size)
            verifier.verifySignature(signature)
        } catch (_: Exception) {
            false
        }
    }

    override fun sha256(data: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(data)
    }

    override fun toHex(data: ByteArray): String {
        return data.joinToString("") { "%02x".format(it) }
    }

    override fun fromHex(hex: String): ByteArray {
        val clean = hex.trim().lowercase()
        require(clean.length % 2 == 0) { "Hex string length must be even" }
        val len = clean.length
        val result = ByteArray(len / 2)
        for (i in 0 until len step 2) {
            val byteVal = clean.substring(i, i + 2).toInt(16)
            result[i / 2] = byteVal.toByte()
        }
        return result
    }
}
