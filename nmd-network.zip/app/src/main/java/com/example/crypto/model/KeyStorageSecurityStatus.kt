package com.example.crypto.model

import com.example.R

/**
 * Indicates the security level of the storage backing the node identity private key.
 *
 * NOTE: As required by Stage 4:
 * - We never claim hardware-backed protection unless verified through Android KeyStore KeyInfo.
 * - Software-backed Keystore or encrypted enclave storage is clearly identified.
 * - Private keys are never stored as plaintext.
 */
enum class KeyStorageSecurityStatus(
    val titleRes: Int,
    val descriptionRes: Int,
    val isHardwareBacked: Boolean
) {
    HARDWARE_BACKED_KEYSTORE(
        titleRes = R.string.crypto_storage_hardware_title,
        descriptionRes = R.string.crypto_storage_hardware_desc,
        isHardwareBacked = true
    ),
    SOFTWARE_BACKED_KEYSTORE(
        titleRes = R.string.crypto_storage_software_title,
        descriptionRes = R.string.crypto_storage_software_desc,
        isHardwareBacked = false
    ),
    ENCRYPTED_STORAGE(
        titleRes = R.string.crypto_storage_enclave_title,
        descriptionRes = R.string.crypto_storage_enclave_desc,
        isHardwareBacked = false
    )
}
