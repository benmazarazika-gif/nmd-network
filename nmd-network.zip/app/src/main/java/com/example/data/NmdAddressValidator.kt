package com.example.data

import com.example.R

sealed class NmdAddressValidationResult {
    data object Valid : NmdAddressValidationResult()
    data class Invalid(val errorRes: Int) : NmdAddressValidationResult()
}

/**
 * DEMO-FORMAT VALIDATION ONLY.
 *
 * Validates structural format compliance for NMD Layer 1 demo addresses in the Stage 2 prototype UI.
 *
 * Rules enforced:
 * 1. Must start strictly with lowercase "nmd1" prefix.
 * 2. Generic "0x" (Ethereum/EVM) addresses are strictly rejected.
 * 3. Total character length must be between 24 and 62 characters.
 * 4. Payload characters after prefix must belong to the standard Bech32 character set
 *    [0-9, a-z] excluding ambiguous characters '1', 'b', 'i', and 'o'.
 *
 * CRITICAL BOUNDARY CLARIFICATIONS:
 * - This validator is exclusively for demo-format syntax checking in Stage 2.
 * - It does NOT compute or verify real Bech32 BCH polynomial checksums (BIP-173/BIP-350).
 * - It does NOT verify cryptographic key derivation, signature validity, or on-chain address ownership.
 */
object NmdAddressValidator {
    const val DEMO_PREFIX = "nmd1"
    const val MIN_LENGTH = 24
    const val MAX_LENGTH = 62

    // Bech32 allowed payload characters: [02-9ac-hj-np-z]
    private val BECH32_CHARSET = "023456789acdefghjklmnpqrstuvwxyz".toSet()

    /**
     * Checks demo-format validity for an input address string.
     */
    fun validateDemoAddress(address: String): NmdAddressValidationResult {
        val trimmed = address.trim()

        if (trimmed.isEmpty()) {
            return NmdAddressValidationResult.Invalid(R.string.send_error_empty_address)
        }

        // Generic 0x EVM addresses are strictly rejected
        if (trimmed.startsWith("0x", ignoreCase = true)) {
            return NmdAddressValidationResult.Invalid(R.string.send_error_rejected_0x_address)
        }

        // Must begin with lowercase 'nmd1'
        if (!trimmed.startsWith(DEMO_PREFIX)) {
            return NmdAddressValidationResult.Invalid(R.string.send_error_invalid_prefix)
        }

        // Length validation
        if (trimmed.length < MIN_LENGTH || trimmed.length > MAX_LENGTH) {
            return NmdAddressValidationResult.Invalid(R.string.send_error_invalid_length)
        }

        // Character validation on payload after prefix
        val payload = trimmed.substring(DEMO_PREFIX.length)
        for (ch in payload) {
            if (ch !in BECH32_CHARSET) {
                return NmdAddressValidationResult.Invalid(R.string.send_error_invalid_characters)
            }
        }

        return NmdAddressValidationResult.Valid
    }
}
