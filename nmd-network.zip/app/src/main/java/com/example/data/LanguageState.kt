package com.example.data

import android.content.Context
import android.content.ContextWrapper
import android.content.res.AssetManager
import android.content.res.Configuration
import android.content.res.Resources
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val layoutDirection: LayoutDirection
) {
    ARABIC("ar", "Arabic", "العربية", LayoutDirection.Rtl),
    ENGLISH("en", "English", "English", LayoutDirection.Ltr),
    FRENCH("fr", "French", "Français", LayoutDirection.Ltr);

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.find { it.code.equals(code, ignoreCase = true) } ?: ARABIC
        }
    }
}

val LocalAppLanguage = compositionLocalOf { AppLanguage.ARABIC }

/**
 * Creates a localized Context for the chosen AppLanguage so resources
 * can be resolved accurately regardless of Android system language.
 *
 * Wraps the receiver Context in a ContextWrapper so that Activity references,
 * WindowManager tokens, and system services remain intact for Dialogs and SurfaceSyncGroup.
 */
fun Context.createLocalizedContext(language: AppLanguage): Context {
    val locale = Locale.forLanguageTag(language.code)
    Locale.setDefault(locale)
    val config = Configuration(resources.configuration).apply {
        setLocale(locale)
        setLayoutDirection(locale)
    }
    val configContext = createConfigurationContext(config)
    return object : ContextWrapper(this) {
        override fun getResources(): Resources = configContext.resources
        override fun getAssets(): AssetManager = configContext.assets
    }
}
