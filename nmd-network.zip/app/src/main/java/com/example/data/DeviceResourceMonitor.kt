package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build

/**
 * Real Android device telemetry reader.
 *
 * Adheres strictly to the Stage 3 rule:
 * - Uses real Android device information only when reliably obtainable.
 * - If a value is unavailable or permissions are absent, reports null / "Unavailable" instead of inventing it.
 * - Never mixes real device telemetry with simulated network data.
 */
class DeviceResourceMonitor(private val context: Context) {

    fun sampleDeviceTelemetry(): DeviceTelemetry {
        val memoryInfo = getRealMemoryInfo()
        val appRamMb = getRealAppMemoryMb()
        val batteryInfo = getRealBatteryInfo()
        val networkType = getRealNetworkType()

        return DeviceTelemetry(
            availableRamMb = memoryInfo?.first,
            totalRamMb = memoryInfo?.second,
            appRamMb = appRamMb,
            batteryPercent = batteryInfo?.first,
            isCharging = batteryInfo?.second,
            networkType = networkType,
            isLowRam = memoryInfo?.third ?: false
        )
    }

    private fun getRealMemoryInfo(): Triple<Long, Long, Boolean>? {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val availMb = memInfo.availMem / (1024L * 1024L)
                val totalMb = memInfo.totalMem / (1024L * 1024L)
                Triple(availMb, totalMb, memInfo.lowMemory)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun getRealAppMemoryMb(): Long? {
        return try {
            val runtime = Runtime.getRuntime()
            val usedBytes = runtime.totalMemory() - runtime.freeMemory()
            usedBytes / (1024L * 1024L)
        } catch (_: Exception) {
            null
        }
    }

    private fun getRealBatteryInfo(): Pair<Int, Boolean>? {
        return try {
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val appContext = context.applicationContext ?: context
            val batteryStatus: Intent? = appContext.registerReceiver(null, ifilter)
            if (batteryStatus != null) {
                val level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val percent = if (level >= 0 && scale > 0) {
                    ((level.toFloat() / scale.toFloat()) * 100).toInt()
                } else null

                val status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL

                if (percent != null) Pair(percent, isCharging) else null
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun getRealNetworkType(): String {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            if (cm != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val activeNetwork = cm.activeNetwork
                    val caps = cm.getNetworkCapabilities(activeNetwork)
                    when {
                        caps == null -> "Unavailable"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "Bluetooth"
                        else -> "Connected (Other)"
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val netInfo = cm.activeNetworkInfo
                    if (netInfo != null && netInfo.isConnected) {
                        netInfo.typeName ?: "Connected"
                    } else {
                        "Unavailable"
                    }
                }
            } else {
                "Unavailable"
            }
        } catch (_: SecurityException) {
            "Unavailable"
        } catch (_: Exception) {
            "Unavailable"
        }
    }
}
