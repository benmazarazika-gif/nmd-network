package com.example.data

import com.example.R

enum class NodeRole(
    val titleRes: Int,
    val descRes: Int,
    val responsibilitiesRes: Int,
    val estimatedRam: String,
    val estimatedStorage: String,
    val estimatedBattery: String
) {
    VALIDATOR(
        titleRes = R.string.role_validator_title,
        descRes = R.string.role_validator_desc,
        responsibilitiesRes = R.string.role_validator_resp,
        estimatedRam = "4 GB - 8 GB",
        estimatedStorage = "100 GB+ SSD",
        estimatedBattery = "High (Requires AC power)"
    ),
    FULL_NODE(
        titleRes = R.string.role_full_title,
        descRes = R.string.role_full_desc,
        responsibilitiesRes = R.string.role_full_resp,
        estimatedRam = "2 GB - 4 GB",
        estimatedStorage = "50 GB - 100 GB",
        estimatedBattery = "Moderate"
    ),
    LIGHT_NODE(
        titleRes = R.string.role_light_title,
        descRes = R.string.role_light_desc,
        responsibilitiesRes = R.string.role_light_resp,
        estimatedRam = "256 MB - 512 MB",
        estimatedStorage = "50 MB - 200 MB",
        estimatedBattery = "Minimal (Mobile Optimized)"
    ),
    RELAY_NODE(
        titleRes = R.string.role_relay_title,
        descRes = R.string.role_relay_desc,
        responsibilitiesRes = R.string.role_relay_resp,
        estimatedRam = "1 GB - 2 GB",
        estimatedStorage = "1 GB - 5 GB",
        estimatedBattery = "Moderate"
    ),
    STORAGE_NODE(
        titleRes = R.string.role_storage_title,
        descRes = R.string.role_storage_desc,
        responsibilitiesRes = R.string.role_storage_resp,
        estimatedRam = "1 GB - 3 GB",
        estimatedStorage = "200 GB+ Distributed",
        estimatedBattery = "Moderate"
    )
}

enum class NodeStatus {
    INACTIVE,
    SYNCING,
    ACTIVE_DEMO
}

data class NodeConfiguration(
    val selectedRole: NodeRole = NodeRole.LIGHT_NODE,
    val displayName: String = "NMD-Node-Mobile-01",
    val isDemoActive: Boolean = false,
    val autoSyncEnabled: Boolean = true
)

enum class PeerConnectionState {
    CONNECTED,
    SYNCING,
    IDLE
}

data class PeerInfo(
    val id: String,
    val name: String,
    val role: NodeRole,
    val connectionState: PeerConnectionState,
    val latencyMs: Int,
    val lastSeenText: String,
    val location: String,
    val isDemo: Boolean = false
)

enum class NetworkActivityType {
    CONFIG_CHANGED,
    PEER_CONNECTED,
    SYNC_UPDATED,
    BLOCK_RECEIVED
}

data class NetworkActivityEvent(
    val id: String,
    val type: NetworkActivityType,
    val titleRes: Int,
    val description: String,
    val timestamp: String,
    val isDemo: Boolean = false
)

data class DeviceTelemetry(
    val availableRamMb: Long? = null,
    val totalRamMb: Long? = null,
    val appRamMb: Long? = null,
    val batteryPercent: Int? = null,
    val isCharging: Boolean? = null,
    val networkType: String = "Unavailable",
    val isLowRam: Boolean = false
) {
    fun getAvailableRamFormatted(unavailableText: String = "Unavailable"): String =
        if (availableRamMb != null) "$availableRamMb MB" else unavailableText

    fun getTotalRamFormatted(unavailableText: String = "Unavailable"): String =
        if (totalRamMb != null) "$totalRamMb MB" else unavailableText

    fun getAppRamFormatted(unavailableText: String = "Unavailable"): String =
        if (appRamMb != null) "$appRamMb MB" else unavailableText

    fun getBatteryPercentFormatted(unavailableText: String = "Unavailable"): String =
        if (batteryPercent != null) "$batteryPercent%" else unavailableText

    fun getBatteryStatusFormatted(
        chargingText: String = "Charging",
        dischargingText: String = "Discharging",
        unavailableText: String = "Unavailable"
    ): String = when (isCharging) {
        true -> chargingText
        false -> dischargingText
        null -> unavailableText
    }

    val availableRamFormatted: String
        get() = getAvailableRamFormatted()

    val totalRamFormatted: String
        get() = getTotalRamFormatted()

    val appRamFormatted: String
        get() = getAppRamFormatted()

    val batteryPercentFormatted: String
        get() = getBatteryPercentFormatted()

    val batteryStatusFormatted: String
        get() = getBatteryStatusFormatted()
}

data class NetworkTelemetry(
    val blockHeight: Long = 0L,
    val syncPercentage: Float = 0f,
    val connectedPeersCount: Int = 0,
    val simulatedUptime: String = "0m",
    val lastSyncTimestamp: String = "Not synced",
    val networkMode: String = "Local Dev Chain (nmd-local-dev-1)",
    val isDemo: Boolean = false
) {
    val syncPercentageFormatted: String
        get() = String.format(java.util.Locale.US, "%.1f%%", syncPercentage)

    val blockHeightFormatted: String
        get() = String.format(java.util.Locale.US, "#%,d", blockHeight)
}

enum class NetworkTab {
    DASHBOARD,
    IDENTITY,
    ROLES,
    PEERS,
    REAL_P2P,
    ACTIVITY,
    DEVICE
}
