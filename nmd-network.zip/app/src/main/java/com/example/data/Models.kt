package com.example.data

import com.example.R

enum class ActivityType {
    RECEIVE,
    SEND,
    REWARD
}

enum class TransactionStatus {
    DEMO,       // Local memory simulation (Stage 2)
    PENDING,    // Unconfirmed on-chain (Future network sync)
    CONFIRMED,  // Verified via real blockchain consensus only
    FAILED      // Failed or rejected
}

data class RecentActivityItem(
    val id: String,
    val titleRes: Int,
    val amountFormatted: String,
    val isCredit: Boolean,
    val timeRes: Int,
    val type: ActivityType
)

data class WalletTransaction(
    val id: String,
    val txHash: String,
    val type: ActivityType,
    val titleRes: Int,
    val amountFormatted: String,
    val amountValue: Double,
    val isCredit: Boolean,
    val timeRes: Int,
    val timestampFormatted: String,
    val status: TransactionStatus,
    val feeFormatted: String = "0.01 NMD",
    val counterpartyAddress: String,
    val blockNumber: Long = 0L
)



enum class DiscoverCategoryType {
    GAMING,
    DEFI,
    SOCIAL,
    MARKETPLACE,
    STORAGE,
    DEVELOPERS
}

data class DiscoverCategory(
    val id: String,
    val titleRes: Int,
    val subRes: Int,
    val type: DiscoverCategoryType,
    val colorStart: Long,
    val colorEnd: Long
)

data class WalletState(
    val totalBalance: Double = 0.0,
    val availableBalance: Double = 0.0,
    val reservedBalance: Double = 0.0,
    val tokenSymbol: String = "NMD",
    val changePercent: String = "",
    val isDemo: Boolean = false,
    val walletAddress: String = "",
    val estimatedFee: Double = 0.01,
    val isBalanceVisible: Boolean = true,
    val totalUnits: Long = 0L,
    val availableUnits: Long = 0L,
    val reservedUnits: Long = 0L
) {
    val totalBalanceFormatted: String
        get() = String.format(java.util.Locale.US, "%,.2f", totalBalance)

    val availableBalanceFormatted: String
        get() = String.format(java.util.Locale.US, "%,.2f", availableBalance)

    val reservedBalanceFormatted: String
        get() = String.format(java.util.Locale.US, "%,.2f", reservedBalance)

    val estimatedFeeFormatted: String
        get() = String.format(java.util.Locale.US, "%,.2f NMD", estimatedFee)
}

enum class WalletViewMode {
    OVERVIEW,
    SEND,
    SEND_REVIEW,
    RECEIVE,
    HISTORY,
    SECURITY
}

enum class TransactionFilterType {
    ALL,
    SENT,
    RECEIVED,
    REWARDS
}

enum class TransactionStatusFilter {
    ALL,
    DEMO,
    PENDING,
    CONFIRMED
}

data class NetworkMetrics(
    val isConnected: Boolean = false,
    val isSimulatedDemo: Boolean = false,
    val syncPercentage: Float = 0f,
    val uptimeText: String = "0m",
    val dataTrafficText: String = "0 KB",
    val batteryImpactText: String = "--"
)
