package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages local node configuration, lifecycle simulation, and peer test fixtures.
 *
 * Adheres strictly to Stage 3 Architecture Rules:
 * - Local simulation only: Never presents node activation as a real blockchain consensus node.
 * - Persistence: Persists node display name, selected role, and demo mode flag across application restarts.
 * - Non-persistence of simulated network connections: Fake peer connections are never serialized or restored as live connections.
 */
class NodeManager(
    private val nodePreferences: NodePreferences
) {
    constructor(context: Context) : this(NodePreferences(context.applicationContext))

    private val _nodeConfig = MutableStateFlow(nodePreferences.loadConfiguration())
    val nodeConfig: StateFlow<NodeConfiguration> = _nodeConfig.asStateFlow()

    private val _nodeStatus = MutableStateFlow(
        if (_nodeConfig.value.isDemoActive) NodeStatus.ACTIVE_DEMO else NodeStatus.INACTIVE
    )
    val nodeStatus: StateFlow<NodeStatus> = _nodeStatus.asStateFlow()

    // Demo peer fixtures (In-memory only; never restored as live connections)
    private val _peers = MutableStateFlow(createInitialDemoPeers())
    val peers: StateFlow<List<PeerInfo>> = _peers.asStateFlow()

    fun updateConfiguration(
        role: NodeRole,
        displayName: String,
        isDemoActive: Boolean,
        autoSyncEnabled: Boolean = true
    ): NodeConfiguration {
        val sanitizedName = if (displayName.isBlank()) {
            NodePreferences.DEFAULT_DISPLAY_NAME
        } else {
            displayName.trim()
        }

        val updated = NodeConfiguration(
            selectedRole = role,
            displayName = sanitizedName,
            isDemoActive = isDemoActive,
            autoSyncEnabled = autoSyncEnabled
        )

        _nodeConfig.value = updated
        _nodeStatus.value = if (isDemoActive) NodeStatus.ACTIVE_DEMO else NodeStatus.INACTIVE
        nodePreferences.saveConfiguration(updated)
        return updated
    }

    fun setDemoActive(active: Boolean): NodeConfiguration {
        val current = _nodeConfig.value
        return updateConfiguration(
            role = current.selectedRole,
            displayName = current.displayName,
            isDemoActive = active,
            autoSyncEnabled = current.autoSyncEnabled
        )
    }

    fun selectRole(role: NodeRole): NodeConfiguration {
        val current = _nodeConfig.value
        return updateConfiguration(
            role = role,
            displayName = current.displayName,
            isDemoActive = current.isDemoActive,
            autoSyncEnabled = current.autoSyncEnabled
        )
    }

    fun isValidatorRoleSelected(): Boolean {
        return _nodeConfig.value.selectedRole == NodeRole.VALIDATOR
    }

    fun updatePeers(livePeers: List<PeerInfo>) {
        _peers.value = livePeers
    }

    companion object {
        fun createInitialDemoPeers(): List<PeerInfo> = emptyList()
    }
}
