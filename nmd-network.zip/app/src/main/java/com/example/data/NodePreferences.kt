package com.example.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Persists local node configuration settings across application restarts.
 *
 * NOTE: As required by Stage 3:
 * - Persists local node configuration (role, display name, demo mode flag).
 * - Does NOT persist fake peer connections or simulated transient telemetry.
 */
class NodePreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadConfiguration(): NodeConfiguration {
        val roleName = prefs.getString(KEY_NODE_ROLE, NodeRole.LIGHT_NODE.name) ?: NodeRole.LIGHT_NODE.name
        val role = try {
            NodeRole.valueOf(roleName)
        } catch (_: IllegalArgumentException) {
            NodeRole.LIGHT_NODE
        }

        val displayName = prefs.getString(KEY_DISPLAY_NAME, DEFAULT_DISPLAY_NAME) ?: DEFAULT_DISPLAY_NAME
        val isDemoActive = prefs.getBoolean(KEY_IS_DEMO_ACTIVE, false)
        val autoSync = prefs.getBoolean(KEY_AUTO_SYNC, true)

        return NodeConfiguration(
            selectedRole = role,
            displayName = displayName,
            isDemoActive = isDemoActive,
            autoSyncEnabled = autoSync
        )
    }

    fun saveConfiguration(config: NodeConfiguration) {
        prefs.edit()
            .putString(KEY_NODE_ROLE, config.selectedRole.name)
            .putString(KEY_DISPLAY_NAME, config.displayName)
            .putBoolean(KEY_IS_DEMO_ACTIVE, config.isDemoActive)
            .putBoolean(KEY_AUTO_SYNC, config.autoSyncEnabled)
            .apply()
    }

    companion object {
        const val PREFS_NAME = "nmd_node_preferences"
        private const val KEY_NODE_ROLE = "key_node_role"
        private const val KEY_DISPLAY_NAME = "key_node_display_name"
        private const val KEY_IS_DEMO_ACTIVE = "key_is_demo_active"
        private const val KEY_AUTO_SYNC = "key_auto_sync"

        const val DEFAULT_DISPLAY_NAME = "NMD-Node-Mobile-01"
    }
}
