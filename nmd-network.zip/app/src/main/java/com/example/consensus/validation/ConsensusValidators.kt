package com.example.consensus.validation

import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.model.Block
import com.example.blockchain.validation.BlockValidationResult
import com.example.blockchain.validation.BlockValidator
import com.example.blockchain.validation.ConsensusValidationHook
import com.example.blockchain.validation.ValidationErrorCode
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.crypto.ConsensusCryptoSigner
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ConsensusErrorCode
import com.example.consensus.model.ConsensusVote
import com.example.consensus.model.EquivocationEvidence
import com.example.consensus.model.EquivocationType
import com.example.consensus.model.ValidatorSetSnapshot
import com.example.consensus.model.VotePhase
import com.example.consensus.quorum.QuorumCalculator
import com.example.consensus.validator.ValidatorEligibilityRegistry
import java.util.UUID

sealed class ConsensusValidationOutcome {
    data object Valid : ConsensusValidationOutcome()
    data class Invalid(
        val code: ConsensusErrorCode,
        val reason: String
    ) : ConsensusValidationOutcome()

    val isValid: Boolean
        get() = this is Valid
}

/**
 * Independent cryptographic and protocol validation for Stage 10 proposals, votes,
 * commit certificates, and equivocation evidence.
 */
class ConsensusValidators(
    private val config: ConsensusConfig,
    private val signer: ConsensusCryptoSigner = ConsensusCryptoSigner(),
    private val blockValidator: BlockValidator = BlockValidator(
        BlockchainConfig(genesisConfig = com.example.blockchain.config.NmdGenesisConfigs.LOCAL_DEV.copy(
            chainId = config.chainId,
            networkEnvironment = config.networkEnvironment
        ))
    )
) {

    fun validateProposal(
        proposal: BlockProposal,
        expectedHeight: Long,
        expectedPreviousHash: String,
        parentBlock: Block?,
        snapshot: ValidatorSetSnapshot,
        registry: ValidatorEligibilityRegistry,
        nowMs: Long = System.currentTimeMillis()
    ): ConsensusValidationOutcome {
        if (proposal.chainId != config.chainId) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_CHAIN_ID,
                "Proposal chainId mismatch: expected ${config.chainId}, got ${proposal.chainId}"
            )
        }
        if (proposal.protocolVersion != config.protocolVersion) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.UNSUPPORTED_PROTOCOL_VERSION,
                "Unsupported consensus protocol version ${proposal.protocolVersion}"
            )
        }
        if (proposal.blockHeight != expectedHeight || proposal.blockHeight <= 0L) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_HEIGHT,
                "Proposal height ${proposal.blockHeight} does not match expected height $expectedHeight"
            )
        }
        if (proposal.round < 0) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_ROUND,
                "Negative consensus round ${proposal.round}"
            )
        }
        if (!ConsensusCryptoSigner.isValidSha256Hex(proposal.proposedBlockHash) ||
            proposal.proposedBlockHash.equals(ConsensusConstants.NIL_BLOCK_HASH, ignoreCase = true)
        ) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_BLOCK_HASH,
                "Invalid or nil proposedBlockHash in proposal"
            )
        }
        if (!proposal.previousBlockHash.equals(expectedPreviousHash, ignoreCase = true)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_PREVIOUS_HASH,
                "Proposal previousBlockHash does not match finalized parent"
            )
        }
        if (proposal.timestamp <= 0L || proposal.timestamp > nowMs + config.maxFutureDriftMs) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_TIMESTAMP,
                "Proposal timestamp out of bounds"
            )
        }

        // Verify proposer authorization & deterministic schedule match
        val proposer = snapshot.findActiveValidator(proposal.proposerId)
            ?: return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.UNAUTHORIZED_PROPOSER,
                "Proposer ${proposal.proposerId} is not an active authorized validator"
            )

        if (!proposer.publicKeyHex.equals(proposal.proposerPublicKeyHex, ignoreCase = true)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.VALIDATOR_KEY_MISMATCH,
                "Proposer public key does not match registered validator key"
            )
        }

        val scheduledProposer = registry.selectDeterministicProposer(snapshot, proposal.blockHeight, proposal.round)
        if (scheduledProposer == null || scheduledProposer.validatorId != proposal.proposerId) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_PROPOSER,
                "Proposer ${proposal.proposerId} is not scheduled proposer (${scheduledProposer?.validatorId}) for h=${proposal.blockHeight}, r=${proposal.round}"
            )
        }

        if (!signer.verifyProposalSignature(proposal)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_PROPOSAL_SIGNATURE,
                "Proposal Ed25519 signature verification failed"
            )
        }

        // If the Stage 8 Block payload is attached, validate structural + Merkle integrity and hash binding
        val attached = proposal.attachedBlock
        if (attached != null) {
            if (!attached.hash.equals(proposal.proposedBlockHash, ignoreCase = true)) {
                return ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.INVALID_BLOCK_HASH,
                    "Attached block hash mismatches proposedBlockHash"
                )
            }
            if (attached.height != proposal.blockHeight ||
                !attached.previousHash.equals(proposal.previousBlockHash, ignoreCase = true)
            ) {
                return ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.BLOCK_STRUCTURAL_INVALID,
                    "Attached block header height/previousHash mismatches proposal"
                )
            }
            val structuralRes = blockValidator.validateBlock(attached, parentBlock, nowMs)
            if (structuralRes is BlockValidationResult.Invalid) {
                return ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.BLOCK_STRUCTURAL_INVALID,
                    "Stage 8 block structural validation failed: ${structuralRes.reason}"
                )
            }
        }

        return ConsensusValidationOutcome.Valid
    }

    fun validateVote(
        vote: ConsensusVote,
        snapshot: ValidatorSetSnapshot,
        nowMs: Long = System.currentTimeMillis()
    ): ConsensusValidationOutcome {
        if (vote.chainId != config.chainId) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_CHAIN_ID,
                "Vote chainId mismatch: ${vote.chainId}"
            )
        }
        if (vote.protocolVersion != config.protocolVersion) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.UNSUPPORTED_PROTOCOL_VERSION,
                "Unsupported vote protocol version ${vote.protocolVersion}"
            )
        }
        if (vote.blockHeight <= 0L || vote.round < 0) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_ROUND,
                "Invalid vote height=${vote.blockHeight} or round=${vote.round}"
            )
        }
        if (!ConsensusCryptoSigner.isValidSha256Hex(vote.proposedBlockHash)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_BLOCK_HASH,
                "Malformed block hash hex in vote"
            )
        }
        if (vote.timestamp <= 0L || vote.timestamp > nowMs + config.maxFutureDriftMs) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_TIMESTAMP,
                "Vote timestamp out of allowed drift"
            )
        }

        val validator = snapshot.findActiveValidator(vote.validatorId)
            ?: return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.UNAUTHORIZED_VALIDATOR,
                "Signer ${vote.validatorId} is not an active authorized validator"
            )

        if (!validator.publicKeyHex.equals(vote.validatorPublicKeyHex, ignoreCase = true)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.VALIDATOR_KEY_MISMATCH,
                "Vote public key does not match registered validator key"
            )
        }

        if (!signer.verifyVoteSignature(vote)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_VOTE_SIGNATURE,
                "Vote Ed25519 signature verification failed"
            )
        }

        return ConsensusValidationOutcome.Valid
    }

    fun validateCommitCertificate(
        certificate: CommitCertificate,
        snapshot: ValidatorSetSnapshot,
        expectedPreviousHash: String? = null
    ): ConsensusValidationOutcome {
        if (certificate.chainId != config.chainId) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_CHAIN_ID,
                "CommitCertificate chainId mismatch"
            )
        }
        if (certificate.protocolVersion != config.protocolVersion) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.UNSUPPORTED_PROTOCOL_VERSION,
                "CommitCertificate protocol version mismatch"
            )
        }
        if (certificate.blockHeight <= 0L || certificate.round < 0) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_COMMIT_CERTIFICATE,
                "CommitCertificate has invalid height/round"
            )
        }
        if (!ConsensusCryptoSigner.isValidSha256Hex(certificate.blockHash) ||
            certificate.blockHash.equals(ConsensusConstants.NIL_BLOCK_HASH, ignoreCase = true)
        ) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_COMMIT_CERTIFICATE,
                "CommitCertificate cannot finalize NIL or malformed block hash"
            )
        }
        if (expectedPreviousHash != null &&
            !certificate.previousBlockHash.equals(expectedPreviousHash, ignoreCase = true)
        ) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_PREVIOUS_HASH,
                "CommitCertificate previousBlockHash does not link to parent"
            )
        }
        if (!certificate.validatorSetHash.equals(snapshot.snapshotHash, ignoreCase = true)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_COMMIT_CERTIFICATE,
                "CommitCertificate validatorSetHash mismatch"
            )
        }

        val activeValidators = snapshot.activeValidatorsSorted
        val quorumInfo = QuorumCalculator.calculate(activeValidators.size, config.minValidatorsForBft)
        if (quorumInfo.validatorCount == 0 || certificate.requiredQuorum != quorumInfo.requiredQuorum) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INVALID_COMMIT_CERTIFICATE,
                "CommitCertificate quorum requirement (${certificate.requiredQuorum}) mismatches computed ${quorumInfo.requiredQuorum}"
            )
        }

        val seenValidators = HashSet<String>()
        var validSignersCount = 0

        for (vote in certificate.precommitVotes) {
            if (vote.votePhase != VotePhase.PRECOMMIT ||
                vote.chainId != certificate.chainId ||
                vote.blockHeight != certificate.blockHeight ||
                vote.round != certificate.round ||
                !vote.proposedBlockHash.equals(certificate.blockHash, ignoreCase = true)
            ) {
                return ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.INVALID_COMMIT_CERTIFICATE,
                    "Certificate vote metadata mismatch for validator ${vote.validatorId}"
                )
            }
            if (!seenValidators.add(vote.validatorId)) {
                return ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.DUPLICATE_VOTING_POWER,
                    "Duplicate validator voting power in CommitCertificate: ${vote.validatorId}"
                )
            }
            val regValidator = snapshot.findActiveValidator(vote.validatorId)
                ?: return ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.UNAUTHORIZED_VALIDATOR,
                    "Unauthorized signer in CommitCertificate: ${vote.validatorId}"
                )
            if (!regValidator.publicKeyHex.equals(vote.validatorPublicKeyHex, ignoreCase = true) ||
                !signer.verifyVoteSignature(vote)
            ) {
                return ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.INVALID_VOTE_SIGNATURE,
                    "Invalid Ed25519 signature in CommitCertificate from ${vote.validatorId}"
                )
            }
            validSignersCount++
        }

        if (!quorumInfo.hasQuorum(validSignersCount)) {
            return ConsensusValidationOutcome.Invalid(
                ConsensusErrorCode.INSUFFICIENT_QUORUM,
                "CommitCertificate has $validSignersCount precommits, below required quorum ${quorumInfo.requiredQuorum}"
            )
        }

        return ConsensusValidationOutcome.Valid
    }

    /**
     * Cryptographically verifies an equivocation claim BEFORE returning valid evidence.
     * Prevents malicious false accusations against honest validators.
     */
    fun verifyAndBuildVoteEquivocationEvidence(
        firstVote: ConsensusVote,
        secondVote: ConsensusVote,
        snapshot: ValidatorSetSnapshot,
        detectedAtMs: Long = System.currentTimeMillis()
    ): EquivocationEvidence? {
        if (firstVote.chainId != config.chainId || secondVote.chainId != config.chainId) return null
        if (firstVote.validatorId != secondVote.validatorId) return null
        if (firstVote.blockHeight != secondVote.blockHeight ||
            firstVote.round != secondVote.round ||
            firstVote.votePhase != secondVote.votePhase
        ) return null
        if (firstVote.proposedBlockHash.equals(secondVote.proposedBlockHash, ignoreCase = true)) return null

        val validator = snapshot.findValidator(firstVote.validatorId) ?: return null
        if (!validator.publicKeyHex.equals(firstVote.validatorPublicKeyHex, ignoreCase = true) ||
            !validator.publicKeyHex.equals(secondVote.validatorPublicKeyHex, ignoreCase = true)
        ) return null

        if (!signer.verifyVoteSignature(firstVote) || !signer.verifyVoteSignature(secondVote)) {
            return null
        }

        val type = if (firstVote.votePhase == VotePhase.PREVOTE) {
            EquivocationType.CONFLICTING_PREVOTE
        } else {
            EquivocationType.CONFLICTING_PRECOMMIT
        }

        return EquivocationEvidence(
            evidenceId = "eqv_${UUID.randomUUID()}",
            chainId = firstVote.chainId,
            blockHeight = firstVote.blockHeight,
            round = firstVote.round,
            validatorId = firstVote.validatorId,
            evidenceType = type,
            firstConflictingPayloadJson = firstVote.toJson(),
            secondConflictingPayloadJson = secondVote.toJson(),
            firstHash = firstVote.proposedBlockHash.lowercase(),
            secondHash = secondVote.proposedBlockHash.lowercase(),
            detectedAtMs = detectedAtMs,
            verifiedCryptographically = true
        )
    }

    fun verifyAndBuildProposalEquivocationEvidence(
        firstProposal: BlockProposal,
        secondProposal: BlockProposal,
        snapshot: ValidatorSetSnapshot,
        detectedAtMs: Long = System.currentTimeMillis()
    ): EquivocationEvidence? {
        if (firstProposal.chainId != config.chainId || secondProposal.chainId != config.chainId) return null
        if (firstProposal.proposerId != secondProposal.proposerId) return null
        if (firstProposal.blockHeight != secondProposal.blockHeight ||
            firstProposal.round != secondProposal.round
        ) return null
        if (firstProposal.proposedBlockHash.equals(secondProposal.proposedBlockHash, ignoreCase = true)) return null

        val validator = snapshot.findValidator(firstProposal.proposerId) ?: return null
        if (!validator.publicKeyHex.equals(firstProposal.proposerPublicKeyHex, ignoreCase = true) ||
            !validator.publicKeyHex.equals(secondProposal.proposerPublicKeyHex, ignoreCase = true)
        ) return null

        if (!signer.verifyProposalSignature(firstProposal) || !signer.verifyProposalSignature(secondProposal)) {
            return null
        }

        return EquivocationEvidence(
            evidenceId = "eqv_${UUID.randomUUID()}",
            chainId = firstProposal.chainId,
            blockHeight = firstProposal.blockHeight,
            round = firstProposal.round,
            validatorId = firstProposal.proposerId,
            evidenceType = EquivocationType.CONFLICTING_PROPOSAL,
            firstConflictingPayloadJson = firstProposal.toJson(includeBlockBody = false),
            secondConflictingPayloadJson = secondProposal.toJson(includeBlockBody = false),
            firstHash = firstProposal.proposedBlockHash.lowercase(),
            secondHash = secondProposal.proposedBlockHash.lowercase(),
            detectedAtMs = detectedAtMs,
            verifiedCryptographically = true
        )
    }
}

/**
 * Integrates Stage 10 CommitCertificate finality verification directly into Stage 8 [BlockValidator]
 * via [ConsensusValidationHook] without modifying Stage 8 block hashing.
 */
class ConsensusBlockValidationHook(
    private val validators: ConsensusValidators,
    private val snapshotProvider: (height: Long) -> ValidatorSetSnapshot,
    private val blockHasher: com.example.blockchain.crypto.BlockHasher = com.example.blockchain.crypto.BlockHasher()
) : ConsensusValidationHook {
    override fun validateConsensusMetadata(block: Block, parentBlock: Block?): BlockValidationResult {
        if (block.height == 0L) {
            return BlockValidationResult.Valid(structuralValidated = true, consensusValidated = true)
        }
        val rawCert = block.header.consensusMetadata
        if (rawCert.isBlank()) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.CONSENSUS_REJECTED,
                "Missing CommitCertificate in block consensusMetadata at height ${block.height}"
            )
        }
        val cert = CommitCertificate.fromJson(rawCert)
            ?: return BlockValidationResult.Invalid(
                ValidationErrorCode.CONSENSUS_REJECTED,
                "Malformed CommitCertificate JSON in block consensusMetadata"
            )
        val unsignedHeaderHash = blockHasher.computeHeaderHash(block.header.copy(consensusMetadata = ""))
        val matchesBlockHash = cert.blockHash.equals(block.hash, ignoreCase = true) ||
            cert.blockHash.equals(unsignedHeaderHash, ignoreCase = true)
        if (!matchesBlockHash || cert.blockHeight != block.height) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.CONSENSUS_REJECTED,
                "CommitCertificate height/hash does not match block"
            )
        }
        val snapshot = snapshotProvider(block.height)
        val outcome = validators.validateCommitCertificate(
            certificate = cert,
            snapshot = snapshot,
            expectedPreviousHash = parentBlock?.hash
        )
        return when (outcome) {
            ConsensusValidationOutcome.Valid ->
                BlockValidationResult.Valid(structuralValidated = true, consensusValidated = true)
            is ConsensusValidationOutcome.Invalid ->
                BlockValidationResult.Invalid(ValidationErrorCode.CONSENSUS_REJECTED, outcome.reason)
        }
    }
}
