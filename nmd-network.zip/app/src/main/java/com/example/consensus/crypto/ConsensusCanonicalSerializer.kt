package com.example.consensus.crypto

import com.example.consensus.model.BlockProposal
import com.example.consensus.model.ConsensusVote
import com.example.consensus.model.RoundChangeMessage
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorStatusAnnouncement
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/**
 * Domain-separated canonical binary serializers for Stage 10 BFT consensus messages.
 *
 * Uses explicit domains, big-endian fixed-width primitives, and 4-byte UTF-8 length prefixes
 * so every Android device produces bit-identical canonical bytes for hashing and Ed25519 signing.
 */
object ConsensusCanonicalSerializer {

    private val VALIDATOR_ID_DOMAIN = "NMD-CONSENSUS-VAL-ID-V1\u0000".toByteArray(Charsets.UTF_8)
    private val VALIDATOR_SET_DOMAIN = "NMD-CONSENSUS-VALSET-V1\u0000".toByteArray(Charsets.UTF_8)
    private val PROPOSAL_DOMAIN = "NMD-CONSENSUS-PROPOSAL-V1\u0000".toByteArray(Charsets.UTF_8)
    private val VOTE_DOMAIN = "NMD-CONSENSUS-VOTE-V1\u0000".toByteArray(Charsets.UTF_8)
    private val ROUND_CHANGE_DOMAIN = "NMD-CONSENSUS-RCHANGE-V1\u0000".toByteArray(Charsets.UTF_8)
    private val VALIDATOR_STATUS_DOMAIN = "NMD-CONSENSUS-VALSTATUS-V1\u0000".toByteArray(Charsets.UTF_8)

    fun serializeValidatorIdInput(publicKeyBytes: ByteArray): ByteArray {
        val out = ByteArray(VALIDATOR_ID_DOMAIN.size + publicKeyBytes.size)
        System.arraycopy(VALIDATOR_ID_DOMAIN, 0, out, 0, VALIDATOR_ID_DOMAIN.size)
        System.arraycopy(publicKeyBytes, 0, out, VALIDATOR_ID_DOMAIN.size, publicKeyBytes.size)
        return out
    }

    fun serializeValidatorSet(chainId: String, validators: List<ValidatorInfo>): ByteArray {
        val sortedActive = validators.filter { it.isAuthorizedActive }.sortedBy { it.validatorId }
        val baos = ByteArrayOutputStream(256)
        val dos = DataOutputStream(baos)
        dos.write(VALIDATOR_SET_DOMAIN)
        writeString(dos, chainId)
        dos.writeInt(sortedActive.size)
        for (v in sortedActive) {
            writeString(dos, v.validatorId)
            writeString(dos, v.publicKeyHex.lowercase())
            dos.writeLong(v.votingPower)
        }
        dos.flush()
        return baos.toByteArray()
    }

    fun serializeProposal(proposal: BlockProposal): ByteArray {
        val baos = ByteArrayOutputStream(256)
        val dos = DataOutputStream(baos)
        dos.write(PROPOSAL_DOMAIN)
        dos.writeInt(proposal.protocolVersion)
        writeString(dos, proposal.chainId)
        dos.writeLong(proposal.blockHeight)
        dos.writeInt(proposal.round)
        dos.writeInt(proposal.validRound)
        writeString(dos, proposal.proposerId)
        writeString(dos, proposal.proposerPublicKeyHex.lowercase())
        writeString(dos, proposal.previousBlockHash.lowercase())
        writeString(dos, proposal.proposedBlockHash.lowercase())
        dos.writeLong(proposal.timestamp)
        dos.flush()
        return baos.toByteArray()
    }

    fun serializeVote(vote: ConsensusVote): ByteArray {
        val baos = ByteArrayOutputStream(256)
        val dos = DataOutputStream(baos)
        dos.write(VOTE_DOMAIN)
        dos.writeInt(vote.protocolVersion)
        writeString(dos, vote.chainId)
        dos.writeLong(vote.blockHeight)
        dos.writeInt(vote.round)
        writeString(dos, vote.votePhase.name)
        writeString(dos, vote.validatorId)
        writeString(dos, vote.validatorPublicKeyHex.lowercase())
        writeString(dos, vote.proposedBlockHash.lowercase())
        dos.writeLong(vote.timestamp)
        dos.flush()
        return baos.toByteArray()
    }

    fun serializeRoundChange(msg: RoundChangeMessage): ByteArray {
        val baos = ByteArrayOutputStream(256)
        val dos = DataOutputStream(baos)
        dos.write(ROUND_CHANGE_DOMAIN)
        dos.writeInt(msg.protocolVersion)
        writeString(dos, msg.chainId)
        dos.writeLong(msg.blockHeight)
        dos.writeInt(msg.fromRound)
        dos.writeInt(msg.toRound)
        writeString(dos, msg.validatorId)
        writeString(dos, msg.validatorPublicKeyHex.lowercase())
        writeString(dos, msg.reason)
        dos.writeLong(msg.timestamp)
        dos.flush()
        return baos.toByteArray()
    }

    fun serializeValidatorStatus(msg: ValidatorStatusAnnouncement): ByteArray {
        val baos = ByteArrayOutputStream(256)
        val dos = DataOutputStream(baos)
        dos.write(VALIDATOR_STATUS_DOMAIN)
        dos.writeInt(msg.protocolVersion)
        writeString(dos, msg.chainId)
        writeString(dos, msg.validatorId)
        writeString(dos, msg.publicKeyHex.lowercase())
        writeString(dos, msg.availability.name)
        dos.writeLong(msg.currentHeight)
        dos.writeInt(msg.currentRound)
        dos.writeInt(msg.batteryPercent ?: -1)
        dos.writeLong(msg.timestamp)
        dos.flush()
        return baos.toByteArray()
    }

    private fun writeString(dos: DataOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        dos.writeInt(bytes.size)
        if (bytes.isNotEmpty()) {
            dos.write(bytes)
        }
    }
}
