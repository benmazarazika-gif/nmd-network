package com.example.consensus.config

import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.config.NetworkEnvironment

/**
 * Configurable Stage 10 Consensus parameters designed for a mobile-first Layer-1 BFT foundation.
 *
 * Explicitly separates development consensus ([NetworkEnvironment.LOCAL_DEV] / [NetworkEnvironment.PRIVATE_TESTNET])
 * from unactivated mainnet production networks.
 */
data class ConsensusConfig(
    val chainId: String = BlockchainConfig().chainId,
    val protocolVersion: Int = BlockchainConfig().parameters.protocolVersion,
    val networkEnvironment: NetworkEnvironment = BlockchainConfig().networkEnvironment,
    val databaseName: String = "nmd_consensus_state.db",
    val minValidatorsForBft: Int = 4,
    val maxActiveValidators: Int = 64,
    val baseProposalTimeoutMs: Long = 12_000L,
    val basePrevoteTimeoutMs: Long = 8_000L,
    val basePrecommitTimeoutMs: Long = 8_000L,
    val maxRoundTimeoutBackoffMs: Long = 60_000L,
    val maxFutureDriftMs: Long = 120_000L,
    val maxConsensusMessageBytes: Int = 32_768,
    val maxQueuedInboundMessages: Int = 200,
    val maxPeerMessagesPerMinute: Int = 120,
    val batteryLowPauseThresholdPercent: Int = 15,
    val respectLowBatteryPause: Boolean = true,
    val isProductionMainnetConsensus: Boolean = false
) {
    val isDevelopmentConsensus: Boolean
        get() = !isProductionMainnetConsensus && (
            networkEnvironment == NetworkEnvironment.LOCAL_DEV ||
                networkEnvironment == NetworkEnvironment.PRIVATE_TESTNET
            )

    fun timeoutForRoundMs(baseMs: Long, round: Int): Long {
        val shift = round.coerceIn(0, 4)
        val scaled = baseMs shl shift
        return scaled.coerceAtMost(maxRoundTimeoutBackoffMs)
    }

    companion object {
        fun fromBlockchainConfig(
            blockchainConfig: BlockchainConfig,
            databaseName: String = BlockchainConfig.databaseNameFor(
                "nmd_consensus_state.db",
                blockchainConfig.chainId
            )
        ): ConsensusConfig {
            return ConsensusConfig(
                chainId = blockchainConfig.chainId,
                protocolVersion = blockchainConfig.parameters.protocolVersion,
                networkEnvironment = blockchainConfig.networkEnvironment,
                databaseName = databaseName,
                isProductionMainnetConsensus = blockchainConfig.parameters.isPublicMainnetActive
            )
        }
    }
}
