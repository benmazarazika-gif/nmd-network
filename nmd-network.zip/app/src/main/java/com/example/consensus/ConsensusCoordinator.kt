package com.example.consensus

import android.content.Context
import com.example.blockchain.manager.BlockchainManager
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.crypto.ConsensusCryptoSigner
import com.example.consensus.engine.ConsensusEngine
import com.example.consensus.engine.ConsensusEvent
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusEngineState
import com.example.consensus.model.ConsensusErrorCode
import com.example.consensus.model.EquivocationEvidence
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorStatus
import com.example.consensus.p2p.ConsensusP2pGateway
import com.example.consensus.storage.ConsensusStorage
import com.example.consensus.storage.RoomConsensusStorage
import com.example.consensus.validation.ConsensusBlockValidationHook
import com.example.consensus.validation.ConsensusValidationOutcome
import com.example.consensus.validation.ConsensusValidators
import com.example.consensus.validator.ValidatorEligibilityRegistry
import com.example.crypto.model.NodeIdentity
import com.example.data.DeviceTelemetry
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.transaction.TransactionEngineManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.Closeable

data class ConsensusIntegrityReport(
    val isHealthy: Boolean,
    val checkedAtMs: Long = System.currentTimeMillis(),
    val verifiedCertificatesCount: Int = 0,
    val equivocationsRecorded: Int = 0,
    val message: String = ""
)

/**
 * Central Stage 10 Distributed Consensus coordinator.
 *
 * Unifies:
 * - [ValidatorEligibilityRegistry] & [MobileParticipationPolicy]
 * - [ConsensusCryptoSigner] (Ed25519 reusing Stage 4)
 * - [ConsensusValidators] & [ConsensusBlockValidationHook] (Stage 8 integration)
 * - [ConsensusEngine] (deterministic 3-phase BFT state machine + Room crash recovery)
 * - [ConsensusP2pGateway] (zero-trust Stage 6/7 P2P consensus messaging)
 */
class ConsensusCoordinator(
    val config: ConsensusConfig = ConsensusConfig(),
    val storage: ConsensusStorage,
    val blockchainManager: BlockchainManager? = null,
    val txEngineManager: TransactionEngineManager? = null,
    val peerRegistry: DistributedPeerRegistry? = null,
    ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    constructor(
        context: Context,
        config: ConsensusConfig = ConsensusConfig(),
        inMemoryStorage: Boolean = false,
        blockchainManager: BlockchainManager? = null,
        txEngineManager: TransactionEngineManager? = null,
        peerRegistry: DistributedPeerRegistry? = null
    ) : this(
        config = config,
        storage = RoomConsensusStorage(
            context = context,
            dbName = config.databaseName,
            inMemory = inMemoryStorage
        ),
        blockchainManager = blockchainManager,
        txEngineManager = txEngineManager,
        peerRegistry = peerRegistry
    )

    val registry = ValidatorEligibilityRegistry(config)
    val signer = ConsensusCryptoSigner()
    val validators: ConsensusValidators = ConsensusValidators(
        config = config,
        signer = signer,
        blockValidator = blockchainManager?.let {
            com.example.blockchain.validation.BlockValidator(it.config, it.blockHasher)
        } ?: com.example.blockchain.validation.BlockValidator(
            com.example.blockchain.config.BlockchainConfig(
                genesisConfig = com.example.blockchain.config.NmdGenesisConfigs.LOCAL_DEV.copy(
                    chainId = config.chainId,
                    networkEnvironment = config.networkEnvironment
                )
            )
        )
    )

    val engine = ConsensusEngine(
        config = config,
        storage = storage,
        registry = registry,
        signer = signer,
        validators = validators,
        blockchainManager = blockchainManager,
        txBlockBridge = txEngineManager?.blockBridge,
        ioDispatcher = ioDispatcher
    )

    val p2pGateway = ConsensusP2pGateway(
        consensusEngine = engine,
        peerRegistry = peerRegistry,
        config = config
    )

    val blockValidationHook = ConsensusBlockValidationHook(
        validators = validators,
        snapshotProvider = { engine.getCurrentValidatorSetSnapshot() }
    )

    val state: StateFlow<ConsensusEngineState> = engine.state
    val events: SharedFlow<ConsensusEvent> = engine.events
    val latestCommitCertificate: StateFlow<CommitCertificate?> = engine.latestCommitCertificate
    val equivocationHistory: StateFlow<List<EquivocationEvidence>> = engine.equivocationHistory

    private val _lastIntegrityReport = MutableStateFlow<ConsensusIntegrityReport?>(null)
    val lastIntegrityReport: StateFlow<ConsensusIntegrityReport?> = _lastIntegrityReport.asStateFlow()

    /**
     * Initializes the consensus engine from durable Room storage without inventing fake validators.
     * When [localIdentity] is present and no validators are persisted yet, registers only the real
     * local node identity (marking `bftSafetyMet = false` until at least `minValidatorsForBft` peers join).
     */
    suspend fun initialize(
        localIdentity: NodeIdentity? = null,
        bootstrapValidators: List<ValidatorInfo> = emptyList(),
        localDisplayName: String = "Local NMD Node"
    ): ConsensusEngineState {
        val stateAfterInit = engine.initialize(
            initialValidators = bootstrapValidators,
            localDevicePublicKeyHex = localIdentity?.publicKeyHex
        )
        // If no validators exist yet and a real local Ed25519 identity exists, register it once without fabricating peers
        if (localIdentity != null && stateAfterInit.activeValidatorCount == 0 && bootstrapValidators.isEmpty()) {
            engine.registerAuthorizedValidator(
                publicKeyHex = localIdentity.publicKeyHex,
                displayName = localDisplayName,
                votingPower = 1L,
                status = ValidatorStatus.ACTIVE
            )
        }
        return engine.state.value
    }

    suspend fun onLocalIdentityUpdated(
        localIdentity: NodeIdentity?,
        displayName: String = "Local NMD Node"
    ): ConsensusEngineState {
        if (localIdentity == null) {
            return engine.setLocalValidatorIdentity(null)
        }
        engine.setLocalValidatorIdentity(localIdentity.publicKeyHex)
        val snapshot = engine.getCurrentValidatorSetSnapshot()
        val derivedId = signer.deriveValidatorIdFromHex(localIdentity.publicKeyHex)
        if (derivedId != null && snapshot.findValidator(derivedId) == null && snapshot.validators.isEmpty()) {
            engine.registerAuthorizedValidator(
                publicKeyHex = localIdentity.publicKeyHex,
                displayName = displayName,
                votingPower = 1L,
                status = ValidatorStatus.ACTIVE
            )
        }
        return engine.state.value
    }

    suspend fun updateDeviceTelemetry(telemetry: DeviceTelemetry): ConsensusEngineState {
        return engine.updateLocalDeviceTelemetry(telemetry)
    }

    suspend fun checkRoundTimeout(): Boolean {
        return engine.checkAndAdvanceOnTimeout()
    }

    /**
     * Audits persisted CommitCertificates, safety monotonicity, and equivocation records truthfully.
     */
    suspend fun verifyConsensusIntegrity(): ConsensusIntegrityReport {
        val snapshot = engine.getCurrentValidatorSetSnapshot()
        val latestCert = storage.getLatestCommitCertificate()
        val equivocations = storage.getAllEquivocationEvidence()
        val safety = engine.getSafetySigningState()
        val currentState = engine.state.value

        val issues = mutableListOf<String>()
        var verifiedCertCount = 0

        if (latestCert != null) {
            val outcome = validators.validateCommitCertificate(
                certificate = latestCert,
                snapshot = snapshot,
                expectedPreviousHash = null
            )
            if (outcome is ConsensusValidationOutcome.Invalid) {
                issues.add("Stored CommitCertificate h=${latestCert.blockHeight} failed: ${outcome.reason}")
            } else {
                verifiedCertCount++
            }
        }

        if (safety.lastSignedHeight > currentState.currentHeight) {
            issues.add("Safety height ${safety.lastSignedHeight} ahead of engine height ${currentState.currentHeight}")
        }

        for (ev in equivocations) {
            if (!ev.verifiedCryptographically) {
                issues.add("Unverified equivocation evidence ${ev.evidenceId} present")
            }
        }

        val report = if (issues.isEmpty()) {
            ConsensusIntegrityReport(
                isHealthy = true,
                verifiedCertificatesCount = verifiedCertCount,
                equivocationsRecorded = equivocations.size,
                message = if (verifiedCertCount > 0) {
                    "CommitCertificate & safety state verified"
                } else {
                    "Pre-consensus dev state healthy (${currentState.activeValidatorCount} active / ${config.minValidatorsForBft} BFT min)"
                }
            )
        } else {
            ConsensusIntegrityReport(
                isHealthy = false,
                verifiedCertificatesCount = verifiedCertCount,
                equivocationsRecorded = equivocations.size,
                message = issues.joinToString("; ")
            )
        }
        _lastIntegrityReport.value = report
        return report
    }

    override fun close() {
        engine.close()
    }
}

/**
 * Application-scoped shared registry so screens and background transport share a single
 * Stage 10 [ConsensusCoordinator] instance without breaking default ViewModel factories or unit tests.
 */
object NmdConsensusCoordinatorRegistry {
    @Volatile
    private var sharedInstance: ConsensusCoordinator? = null

    fun getOrCreate(
        context: Context,
        blockchainManager: BlockchainManager? = null,
        txEngineManager: TransactionEngineManager? = null,
        peerRegistry: DistributedPeerRegistry? = null
    ): ConsensusCoordinator {
        val existing = sharedInstance
        if (existing != null) return existing
        return synchronized(this) {
            sharedInstance ?: ConsensusCoordinator(
                context = context.applicationContext,
                blockchainManager = blockchainManager,
                txEngineManager = txEngineManager,
                peerRegistry = peerRegistry
            ).also {
                sharedInstance = it
            }
        }
    }

    fun resetForTests() {
        synchronized(this) {
            sharedInstance?.close()
            sharedInstance = null
        }
    }
}
