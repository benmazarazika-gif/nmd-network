package com.example.consensus.quorum

/**
 * Result of deterministic BFT quorum and fault tolerance calculation.
 *
 * Mathematical guarantees verified for validator set size N:
 * - Tolerated Byzantine faults: F = floor((N - 1) / 3), requiring N >= 3F + 1.
 * - Full BFT fault tolerance (F >= 1) requires N >= 4.
 * - Required Quorum Q = floor((2 * N) / 3) + 1 (strictly > 2N / 3).
 *
 * Safety invariant (Quorum Intersection):
 * Any two quorums Q1, Q2 of size Q overlap in at least:
 *   2*Q - N >= F + 1 validators,
 * guaranteeing at least one honest non-Byzantine validator in every quorum intersection
 * (preventing conflicting commits at the same height/round even when N=5 or N=6 where 2F+1 alone would be unsafe).
 */
data class QuorumInfo(
    val validatorCount: Int,
    val toleratedByzantineFaults: Int,
    val requiredQuorum: Int,
    val isBftSafetyAchieved: Boolean,
    val minIntersectionGuaranteed: Int
) {
    fun hasQuorum(validVotesCount: Int): Boolean {
        return validatorCount > 0 && validVotesCount >= requiredQuorum
    }

    fun isInsufficientQuorumRisk(availableOnlineValidators: Int): Boolean {
        return validatorCount > 0 && availableOnlineValidators < requiredQuorum
    }
}

object QuorumCalculator {

    /**
     * Deterministically computes tolerated Byzantine faults F and required quorum Q
     * for [validatorCount] equally weighted active validators.
     */
    fun calculate(validatorCount: Int, minValidatorsForBft: Int = 4): QuorumInfo {
        if (validatorCount <= 0) {
            return QuorumInfo(
                validatorCount = 0,
                toleratedByzantineFaults = 0,
                requiredQuorum = 0,
                isBftSafetyAchieved = false,
                minIntersectionGuaranteed = 0
            )
        }

        val toleratedFaults = (validatorCount - 1) / 3
        val requiredQuorum = (2 * validatorCount) / 3 + 1
        val intersection = (2 * requiredQuorum) - validatorCount
        val bftAchieved = validatorCount >= minValidatorsForBft &&
            toleratedFaults >= 1 &&
            validatorCount >= (3 * toleratedFaults) + 1 &&
            requiredQuorum >= (2 * toleratedFaults) + 1 &&
            intersection >= toleratedFaults + 1

        return QuorumInfo(
            validatorCount = validatorCount,
            toleratedByzantineFaults = toleratedFaults,
            requiredQuorum = requiredQuorum,
            isBftSafetyAchieved = bftAchieved,
            minIntersectionGuaranteed = intersection
        )
    }
}
