package com.example.consensus.crypto

import com.example.consensus.model.BlockProposal
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ConsensusVote
import com.example.consensus.model.RoundChangeMessage
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorStatusAnnouncement
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.crypto.repository.IdentityRepository

/**
 * Reuses Stage 4 Ed25519 cryptography and [IdentityRepository] to derive deterministic
 * validator identifiers and sign/verify consensus proposals, votes, and status updates.
 */
class ConsensusCryptoSigner(
    val cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
) {
    companion object {
        private val HEX_64 = Regex("^[0-9a-f]{64}$")
        private val HEX_128 = Regex("^[0-9a-f]{128}$")

        fun isValidSha256Hex(hex: String): Boolean = HEX_64.matches(hex.lowercase())
        fun isValidPublicKeyHex(hex: String): Boolean = HEX_64.matches(hex.lowercase())
        fun isValidSignatureHex(hex: String): Boolean = HEX_128.matches(hex.lowercase())
    }

    fun deriveValidatorId(publicKeyBytes: ByteArray): String {
        require(publicKeyBytes.size == 32) { "Ed25519 public key must be 32 bytes" }
        val input = ConsensusCanonicalSerializer.serializeValidatorIdInput(publicKeyBytes)
        val digestHex = cryptoProvider.toHex(cryptoProvider.sha256(input))
        return ConsensusConstants.VALIDATOR_ID_PREFIX + digestHex.take(32)
    }

    fun deriveValidatorIdFromHex(publicKeyHex: String): String? {
        if (!isValidPublicKeyHex(publicKeyHex)) return null
        return try {
            val bytes = cryptoProvider.fromHex(publicKeyHex)
            if (bytes.size != 32 || bytes.all { it == 0.toByte() }) null
            else deriveValidatorId(bytes)
        } catch (_: Exception) {
            null
        }
    }

    fun verifyValidatorIdMatchesPublicKey(validatorId: String, publicKeyHex: String): Boolean {
        val derived = deriveValidatorIdFromHex(publicKeyHex) ?: return false
        return validatorId == derived
    }

    fun computeValidatorSetHash(chainId: String, validators: List<ValidatorInfo>): String {
        val bytes = ConsensusCanonicalSerializer.serializeValidatorSet(chainId, validators)
        return cryptoProvider.toHex(cryptoProvider.sha256(bytes))
    }

    fun signProposalWithDeviceIdentity(
        unsignedProposal: BlockProposal,
        identityRepository: IdentityRepository
    ): BlockProposal {
        val identity = identityRepository.getPublicIdentity()
            ?: throw IllegalStateException("No Ed25519 device identity available to sign proposal")
        val derivedValId = deriveValidatorIdFromHex(identity.publicKeyHex)
            ?: throw IllegalStateException("Invalid device public key")
        val prepared = unsignedProposal.copy(
            proposerId = derivedValId,
            proposerPublicKeyHex = identity.publicKeyHex.lowercase()
        )
        val sigBytes = identityRepository.signRawData(ConsensusCanonicalSerializer.serializeProposal(prepared))
        return prepared.copy(signatureHex = cryptoProvider.toHex(sigBytes))
    }

    fun signProposalWithKeyPair(
        unsignedProposal: BlockProposal,
        privateKeyBytes: ByteArray
    ): BlockProposal {
        val pubBytes = cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytes)
        val valId = deriveValidatorId(pubBytes)
        val prepared = unsignedProposal.copy(
            proposerId = valId,
            proposerPublicKeyHex = cryptoProvider.toHex(pubBytes).lowercase()
        )
        val sigBytes = cryptoProvider.sign(privateKeyBytes, ConsensusCanonicalSerializer.serializeProposal(prepared))
        return prepared.copy(signatureHex = cryptoProvider.toHex(sigBytes))
    }

    fun verifyProposalSignature(proposal: BlockProposal): Boolean {
        if (!verifyValidatorIdMatchesPublicKey(proposal.proposerId, proposal.proposerPublicKeyHex)) return false
        if (!isValidSignatureHex(proposal.signatureHex)) return false
        return try {
            val pub = cryptoProvider.fromHex(proposal.proposerPublicKeyHex)
            val sig = cryptoProvider.fromHex(proposal.signatureHex)
            cryptoProvider.verify(pub, ConsensusCanonicalSerializer.serializeProposal(proposal), sig)
        } catch (_: Exception) {
            false
        }
    }

    fun signVoteWithDeviceIdentity(
        unsignedVote: ConsensusVote,
        identityRepository: IdentityRepository
    ): ConsensusVote {
        val identity = identityRepository.getPublicIdentity()
            ?: throw IllegalStateException("No Ed25519 device identity available to sign vote")
        val derivedValId = deriveValidatorIdFromHex(identity.publicKeyHex)
            ?: throw IllegalStateException("Invalid device public key")
        val prepared = unsignedVote.copy(
            validatorId = derivedValId,
            validatorPublicKeyHex = identity.publicKeyHex.lowercase()
        )
        val sigBytes = identityRepository.signRawData(ConsensusCanonicalSerializer.serializeVote(prepared))
        return prepared.copy(signatureHex = cryptoProvider.toHex(sigBytes))
    }

    fun signVoteWithKeyPair(
        unsignedVote: ConsensusVote,
        privateKeyBytes: ByteArray
    ): ConsensusVote {
        val pubBytes = cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytes)
        val valId = deriveValidatorId(pubBytes)
        val prepared = unsignedVote.copy(
            validatorId = valId,
            validatorPublicKeyHex = cryptoProvider.toHex(pubBytes).lowercase()
        )
        val sigBytes = cryptoProvider.sign(privateKeyBytes, ConsensusCanonicalSerializer.serializeVote(prepared))
        return prepared.copy(signatureHex = cryptoProvider.toHex(sigBytes))
    }

    fun verifyVoteSignature(vote: ConsensusVote): Boolean {
        if (!verifyValidatorIdMatchesPublicKey(vote.validatorId, vote.validatorPublicKeyHex)) return false
        if (!isValidSignatureHex(vote.signatureHex)) return false
        return try {
            val pub = cryptoProvider.fromHex(vote.validatorPublicKeyHex)
            val sig = cryptoProvider.fromHex(vote.signatureHex)
            cryptoProvider.verify(pub, ConsensusCanonicalSerializer.serializeVote(vote), sig)
        } catch (_: Exception) {
            false
        }
    }

    fun signRoundChangeWithKeyPair(
        msg: RoundChangeMessage,
        privateKeyBytes: ByteArray
    ): RoundChangeMessage {
        val pubBytes = cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytes)
        val valId = deriveValidatorId(pubBytes)
        val prepared = msg.copy(
            validatorId = valId,
            validatorPublicKeyHex = cryptoProvider.toHex(pubBytes).lowercase()
        )
        val sigBytes = cryptoProvider.sign(privateKeyBytes, ConsensusCanonicalSerializer.serializeRoundChange(prepared))
        return prepared.copy(signatureHex = cryptoProvider.toHex(sigBytes))
    }

    fun signRoundChangeWithDeviceIdentity(
        msg: RoundChangeMessage,
        identityRepository: IdentityRepository
    ): RoundChangeMessage {
        val identity = identityRepository.getPublicIdentity()
            ?: throw IllegalStateException("No Ed25519 device identity available to sign round change")
        val derivedValId = deriveValidatorIdFromHex(identity.publicKeyHex)
            ?: throw IllegalStateException("Invalid device public key")
        val prepared = msg.copy(
            validatorId = derivedValId,
            validatorPublicKeyHex = identity.publicKeyHex.lowercase()
        )
        val sigBytes = identityRepository.signRawData(ConsensusCanonicalSerializer.serializeRoundChange(prepared))
        return prepared.copy(signatureHex = cryptoProvider.toHex(sigBytes))
    }

    fun verifyRoundChangeSignature(msg: RoundChangeMessage): Boolean {
        if (!verifyValidatorIdMatchesPublicKey(msg.validatorId, msg.validatorPublicKeyHex)) return false
        if (!isValidSignatureHex(msg.signatureHex)) return false
        return try {
            val pub = cryptoProvider.fromHex(msg.validatorPublicKeyHex)
            val sig = cryptoProvider.fromHex(msg.signatureHex)
            cryptoProvider.verify(pub, ConsensusCanonicalSerializer.serializeRoundChange(msg), sig)
        } catch (_: Exception) {
            false
        }
    }

    fun signValidatorStatusWithKeyPair(
        msg: ValidatorStatusAnnouncement,
        privateKeyBytes: ByteArray
    ): ValidatorStatusAnnouncement {
        val pubBytes = cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytes)
        val valId = deriveValidatorId(pubBytes)
        val prepared = msg.copy(
            validatorId = valId,
            publicKeyHex = cryptoProvider.toHex(pubBytes).lowercase()
        )
        val sigBytes = cryptoProvider.sign(privateKeyBytes, ConsensusCanonicalSerializer.serializeValidatorStatus(prepared))
        return prepared.copy(signatureHex = cryptoProvider.toHex(sigBytes))
    }

    fun verifyValidatorStatusSignature(msg: ValidatorStatusAnnouncement): Boolean {
        if (!verifyValidatorIdMatchesPublicKey(msg.validatorId, msg.publicKeyHex)) return false
        if (!isValidSignatureHex(msg.signatureHex)) return false
        return try {
            val pub = cryptoProvider.fromHex(msg.publicKeyHex)
            val sig = cryptoProvider.fromHex(msg.signatureHex)
            cryptoProvider.verify(pub, ConsensusCanonicalSerializer.serializeValidatorStatus(msg), sig)
        } catch (_: Exception) {
            false
        }
    }
}
