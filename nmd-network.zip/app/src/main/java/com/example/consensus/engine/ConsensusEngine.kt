package com.example.consensus.engine

import com.example.blockchain.manager.BlockIngestionResult
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.crypto.ConsensusCryptoSigner
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ConsensusEngineState
import com.example.consensus.model.ConsensusErrorCode
import com.example.consensus.model.ConsensusPhase
import com.example.consensus.model.ConsensusVote
import com.example.consensus.model.EquivocationEvidence
import com.example.consensus.model.RoundChangeMessage
import com.example.consensus.model.SafetySigningState
import com.example.consensus.model.ValidatorAvailability
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorParticipationSummary
import com.example.consensus.model.ValidatorSetSnapshot
import com.example.consensus.model.ValidatorStatus
import com.example.consensus.model.VotePhase
import com.example.consensus.quorum.QuorumCalculator
import com.example.consensus.storage.ConsensusMetaState
import com.example.consensus.storage.ConsensusStorage
import com.example.consensus.validation.ConsensusValidationOutcome
import com.example.consensus.validation.ConsensusValidators
import com.example.consensus.validator.MobileParticipationPolicy
import com.example.consensus.validator.ValidatorEligibilityRegistry
import com.example.crypto.repository.IdentityRepository
import com.example.data.DeviceTelemetry
import com.example.transaction.blockchain.TransactionBlockBridge
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable

sealed class ConsensusEvent {
    data class ProposalAccepted(val height: Long, val round: Int, val blockHash: String, val proposerId: String) : ConsensusEvent()
    data class VoteAccepted(val height: Long, val round: Int, val phase: VotePhase, val validatorId: String, val blockHash: String) : ConsensusEvent()
    data class QuorumReached(val height: Long, val round: Int, val phase: VotePhase, val blockHash: String, val count: Int, val required: Int) : ConsensusEvent()
    data class BlockFinalized(val certificate: CommitCertificate) : ConsensusEvent()
    data class RoundTimedOut(val height: Long, val oldRound: Int, val newRound: Int, val nextProposerId: String?) : ConsensusEvent()
    data class EquivocationDetected(val evidence: EquivocationEvidence) : ConsensusEvent()
    data class ValidationRejected(val code: ConsensusErrorCode, val reason: String) : ConsensusEvent()
    data class BlockSyncRequired(val targetHeight: Long, val targetBlockHash: String) : ConsensusEvent()
}

sealed class ProposalSubmissionResult {
    data class Accepted(val proposal: BlockProposal) : ProposalSubmissionResult()
    data class Duplicate(val reason: String) : ProposalSubmissionResult()
    data class Rejected(
        val code: ConsensusErrorCode,
        val reason: String,
        val equivocationEvidence: EquivocationEvidence? = null
    ) : ProposalSubmissionResult()
}

sealed class VoteSubmissionResult {
    data class Accepted(
        val vote: ConsensusVote,
        val quorumReached: Boolean,
        val commitCertificate: CommitCertificate? = null
    ) : VoteSubmissionResult()

    data class Duplicate(val reason: String) : VoteSubmissionResult()
    data class Rejected(
        val code: ConsensusErrorCode,
        val reason: String,
        val equivocationEvidence: EquivocationEvidence? = null
    ) : VoteSubmissionResult()
}

sealed class LocalSignVoteResult {
    data class Signed(val vote: ConsensusVote) : LocalSignVoteResult()
    data class Refused(val code: ConsensusErrorCode, val reason: String) : LocalSignVoteResult()
}

/**
 * Deterministic Byzantine Fault Tolerant (3-phase) Consensus Engine for NMD Stage 10.
 *
 * Protocol Phases per (height, round):
 * 1. PROPOSE: Scheduled deterministic proposer broadcasts a signed [BlockProposal].
 * 2. PREVOTE: Validators verify proposal & BFT lock rules, persist safety state, and sign [VotePhase.PREVOTE].
 * 3. PRECOMMIT: Upon >2N/3 PREVOTE quorum for a valid proposal (polkadot), validators lock, persist
 *    safety state, and sign [VotePhase.PRECOMMIT].
 * 4. COMMIT / FINALIZE: Upon >2N/3 PRECOMMIT quorum, builds and cryptographically verifies a
 *    [CommitCertificate], atomically persists finality + safety reset in Room, commits any attached
 *    Stage 8 block, and advances cleanly to height + 1, round 0.
 * 5. ROUND_CHANGE / TIMEOUT: Exponential backoff triggers round advancement preserving BFT locks.
 *
 * Safety invariants:
 * - Never marks a block committed without a fully verified >2N/3 [CommitCertificate].
 * - Persists [SafetySigningState] atomically BEFORE returning any locally signed vote.
 * - Never slashes/suspends a validator without cryptographically verified [EquivocationEvidence].
 */
class ConsensusEngine(
    val config: ConsensusConfig = ConsensusConfig(),
    val storage: ConsensusStorage,
    val registry: ValidatorEligibilityRegistry = ValidatorEligibilityRegistry(config),
    val signer: ConsensusCryptoSigner = ConsensusCryptoSigner(),
    val validators: ConsensusValidators = ConsensusValidators(config, signer),
    private val blockchainManager: BlockchainManager? = null,
    private val txBlockBridge: TransactionBlockBridge? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    private val mutex = Mutex()

    private val _state = MutableStateFlow(
        ConsensusEngineState(
            isInitialized = false,
            isDevelopmentConsensus = config.isDevelopmentConsensus,
            chainId = config.chainId
        )
    )
    val state: StateFlow<ConsensusEngineState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<ConsensusEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<ConsensusEvent> = _events.asSharedFlow()

    private val _latestCommitCertificate = MutableStateFlow<CommitCertificate?>(null)
    val latestCommitCertificate: StateFlow<CommitCertificate?> = _latestCommitCertificate.asStateFlow()

    private val _equivocationHistory = MutableStateFlow<List<EquivocationEvidence>>(emptyList())
    val equivocationHistory: StateFlow<List<EquivocationEvidence>> = _equivocationHistory.asStateFlow()

    // In-memory state for active height
    private var currentHeight: Long = 1L
    private var currentRound: Int = 0
    private var currentPhase: ConsensusPhase = ConsensusPhase.PROPOSED
    private var latestFinalizedHeight: Long = 0L
    private var latestFinalizedHash: String = ConsensusConstants.NIL_BLOCK_HASH
    private var latestFinalizedTimestampMs: Long = 0L
    private var safetyState: SafetySigningState = SafetySigningState(chainId = config.chainId)

    private var localValidatorId: String? = null
    private var localMobilePaused: Boolean = false
    private var mobilePauseReason: String? = null
    private var lastError: String? = null
    private var lastErrorCode: ConsensusErrorCode = ConsensusErrorCode.NONE

    // Round tracking for currentHeight:
    // round -> (proposerId -> BlockProposal)
    private val proposalsByRound = HashMap<Int, MutableMap<String, BlockProposal>>()
    // round -> (validatorId -> ConsensusVote)
    private val prevotesByRound = HashMap<Int, MutableMap<String, ConsensusVote>>()
    private val precommitsByRound = HashMap<Int, MutableMap<String, ConsensusVote>>()
    private var currentRoundStartedAtMs: Long = System.currentTimeMillis()
    private var isInitialized: Boolean = false

    suspend fun initialize(
        initialValidators: List<ValidatorInfo> = emptyList(),
        localDevicePublicKeyHex: String? = null,
        nowMs: Long = System.currentTimeMillis()
    ): ConsensusEngineState = withContext(ioDispatcher) {
        mutex.withLock {
            // 1. Restore or seed authorized validator set
            val persistedValidators = storage.getValidators()
            if (persistedValidators.isNotEmpty()) {
                registry.loadRestoredValidators(persistedValidators)
            } else if (initialValidators.isNotEmpty()) {
                registry.loadRestoredValidators(initialValidators)
                storage.saveValidators(registry.getAllValidators())
            }

            if (localDevicePublicKeyHex != null) {
                localValidatorId = signer.deriveValidatorIdFromHex(localDevicePublicKeyHex)
            }

            // 2. Align base finalized tip with Stage 8 BlockchainManager if present
            val chainTip = blockchainManager?.getLatestBlock()

            // 3. Restore consensus metadata & safety state
            val savedMeta = storage.getMeta(config.chainId)
            val savedSafety = storage.getSafetyState(config.chainId)
            val savedCert = storage.getLatestCommitCertificate()

            if (savedMeta != null) {
                currentHeight = savedMeta.currentHeight
                currentRound = savedMeta.currentRound
                currentPhase = savedMeta.phase
                latestFinalizedHeight = savedMeta.latestFinalizedHeight
                latestFinalizedHash = savedMeta.latestFinalizedHash
                latestFinalizedTimestampMs = savedMeta.latestFinalizedTimestampMs
            } else {
                latestFinalizedHeight = chainTip?.height ?: 0L
                latestFinalizedHash = chainTip?.hash ?: ConsensusConstants.NIL_BLOCK_HASH
                latestFinalizedTimestampMs = chainTip?.timestamp ?: 0L
                currentHeight = latestFinalizedHeight + 1L
                currentRound = 0
                currentPhase = ConsensusPhase.PROPOSED
                saveMetaLocked(nowMs)
            }

            // Reconcile strictly with Stage 8 blockchain storage whenever blockchainManager is attached
            if (blockchainManager != null && chainTip != null) {
                if (chainTip.height != latestFinalizedHeight) {
                    latestFinalizedHeight = chainTip.height
                    latestFinalizedHash = chainTip.hash
                    latestFinalizedTimestampMs = chainTip.timestamp
                    currentHeight = chainTip.height + 1L
                    currentRound = 0
                    currentPhase = ConsensusPhase.PROPOSED
                    saveMetaLocked(nowMs)
                }
            } else if (chainTip != null && chainTip.height > latestFinalizedHeight) {
                latestFinalizedHeight = chainTip.height
                latestFinalizedHash = chainTip.hash
                latestFinalizedTimestampMs = chainTip.timestamp
                currentHeight = chainTip.height + 1L
                currentRound = 0
                currentPhase = ConsensusPhase.PROPOSED
                saveMetaLocked(nowMs)
            }

            safetyState = savedSafety ?: SafetySigningState(chainId = config.chainId).also {
                storage.saveSafetyState(it)
            }

            // 4. Reload in-progress proposals & votes for currentHeight across restarts
            proposalsByRound.clear()
            prevotesByRound.clear()
            precommitsByRound.clear()

            storage.getProposalsForHeight(currentHeight).forEach { p ->
                proposalsByRound.getOrPut(p.round) { HashMap() }[p.proposerId] = p
            }
            storage.getVotesForHeight(currentHeight).forEach { v ->
                val map = if (v.votePhase == VotePhase.PREVOTE) prevotesByRound else precommitsByRound
                val roundMap = map.getOrPut(v.round) { HashMap() }
                if (!roundMap.containsKey(v.validatorId)) {
                    roundMap[v.validatorId] = v
                }
            }

            // Recompute round phase truthfully from persisted votes if mid-round restart happened
            reconcilePhaseFromRestoredVotesLocked()

            _latestCommitCertificate.value = savedCert
            _equivocationHistory.value = storage.getAllEquivocationEvidence()
            currentRoundStartedAtMs = nowMs
            isInitialized = true
            publishStateLocked()
        }
    }

    suspend fun registerAuthorizedValidator(
        publicKeyHex: String,
        displayName: String,
        votingPower: Long = 1L,
        status: ValidatorStatus = ValidatorStatus.ACTIVE
    ): ValidatorInfo? = withContext(ioDispatcher) {
        mutex.withLock {
            val info = registry.registerAuthorizedValidator(
                publicKeyHex = publicKeyHex,
                displayName = displayName,
                votingPower = votingPower,
                initialStatus = status
            ) ?: return@withLock null
            storage.saveValidators(registry.getAllValidators())
            publishStateLocked()
            info
        }
    }

    suspend fun retireValidator(validatorId: String, nowMs: Long = System.currentTimeMillis()): Boolean =
        withContext(ioDispatcher) {
            mutex.withLock {
                val updated = registry.updateStatus(validatorId, ValidatorStatus.OFFLINE, nowMs) != null
                if (updated) {
                    storage.saveValidators(registry.getAllValidators())
                    publishStateLocked()
                }
                updated
            }
        }

    suspend fun updateLocalDeviceTelemetry(telemetry: DeviceTelemetry, nowMs: Long = System.currentTimeMillis()): ConsensusEngineState =
        withContext(ioDispatcher) {
            mutex.withLock {
                val eval = MobileParticipationPolicy.evaluateDevice(telemetry, config)
                localMobilePaused = eval.shouldPauseActiveSigning
                mobilePauseReason = eval.reason
                localValidatorId?.let { id ->
                    registry.updateAvailability(id, eval.recommendedAvailability, nowMs)
                    storage.saveValidators(registry.getAllValidators())
                }
                publishStateLocked()
            }
        }

    suspend fun updateValidatorAvailability(
        validatorId: String,
        availability: ValidatorAvailability,
        nowMs: Long = System.currentTimeMillis()
    ): ValidatorInfo? = withContext(ioDispatcher) {
        mutex.withLock {
            val updated = registry.updateAvailability(validatorId, availability, nowMs) ?: return@withLock null
            storage.saveValidators(registry.getAllValidators())
            publishStateLocked()
            updated
        }
    }

    suspend fun setLocalValidatorIdentity(publicKeyHex: String?): ConsensusEngineState = withContext(ioDispatcher) {
        mutex.withLock {
            localValidatorId = publicKeyHex?.let { signer.deriveValidatorIdFromHex(it) }
            publishStateLocked()
        }
    }

    fun getCurrentValidatorSetSnapshot(): ValidatorSetSnapshot {
        return registry.buildSnapshot(currentHeight)
    }

    suspend fun getSafetySigningState(): SafetySigningState = withContext(ioDispatcher) {
        mutex.withLock { safetyState }
    }

    suspend fun getProposalForRound(height: Long, round: Int): BlockProposal? = withContext(ioDispatcher) {
        mutex.withLock {
            if (height == currentHeight) {
                proposalsByRound[round]?.values?.firstOrNull()
            } else {
                storage.getProposalsForHeight(height).firstOrNull { it.round == round }
            }
        }
    }

    /**
     * Evaluates incoming [BlockProposal] strictly.
     * Detects duplicate proposals and cryptographically verifies conflicting proposals -> [EquivocationEvidence].
     */
    suspend fun submitProposal(
        proposal: BlockProposal,
        nowMs: Long = System.currentTimeMillis()
    ): ProposalSubmissionResult = withContext(ioDispatcher) {
        mutex.withLock {
            val snapshot = registry.buildSnapshot(currentHeight)
            val parentBlock = if (latestFinalizedHeight >= 0L) {
                blockchainManager?.getBlockByHeight(latestFinalizedHeight)
            } else null

            val validation = validators.validateProposal(
                proposal = proposal,
                expectedHeight = currentHeight,
                expectedPreviousHash = latestFinalizedHash,
                parentBlock = parentBlock,
                snapshot = snapshot,
                registry = registry,
                nowMs = nowMs
            )

            if (validation is ConsensusValidationOutcome.Invalid) {
                lastError = validation.reason
                lastErrorCode = validation.code
                _events.emit(ConsensusEvent.ValidationRejected(validation.code, validation.reason))
                publishStateLocked()
                return@withLock ProposalSubmissionResult.Rejected(validation.code, validation.reason)
            }

            val roundProposals = proposalsByRound.getOrPut(proposal.round) { HashMap() }
            val existing = roundProposals[proposal.proposerId]
            if (existing != null) {
                if (existing.proposedBlockHash.equals(proposal.proposedBlockHash, ignoreCase = true)) {
                    return@withLock ProposalSubmissionResult.Duplicate(
                        "Duplicate proposal already accepted for h=${proposal.blockHeight}, r=${proposal.round}"
                    )
                } else {
                    val evidence = validators.verifyAndBuildProposalEquivocationEvidence(
                        firstProposal = existing,
                        secondProposal = proposal,
                        snapshot = snapshot,
                        detectedAtMs = nowMs
                    )
                    if (evidence != null) {
                        recordVerifiedEquivocationLocked(evidence)
                    }
                    lastError = "Conflicting proposal detected from ${proposal.proposerId}"
                    lastErrorCode = ConsensusErrorCode.CONFLICTING_PROPOSAL
                    _events.emit(ConsensusEvent.ValidationRejected(ConsensusErrorCode.CONFLICTING_PROPOSAL, lastError!!))
                    publishStateLocked()
                    return@withLock ProposalSubmissionResult.Rejected(
                        ConsensusErrorCode.CONFLICTING_PROPOSAL,
                        lastError!!,
                        equivocationEvidence = evidence
                    )
                }
            }

            roundProposals[proposal.proposerId] = proposal
            storage.saveProposal(proposal)
            registry.recordProposedBlock(proposal.proposerId, nowMs)
            storage.saveValidators(registry.getAllValidators())

            if (proposal.round == currentRound && currentPhase == ConsensusPhase.PROPOSED) {
                currentPhase = ConsensusPhase.PRE_VOTING
                saveMetaLocked(nowMs)
            }
            lastError = null
            lastErrorCode = ConsensusErrorCode.NONE
            _events.emit(ConsensusEvent.ProposalAccepted(proposal.blockHeight, proposal.round, proposal.proposedBlockHash, proposal.proposerId))
            publishStateLocked()
            ProposalSubmissionResult.Accepted(proposal)
        }
    }

    /**
     * Locally signs a [VotePhase.PREVOTE] or [VotePhase.PRECOMMIT] using [IdentityRepository] (or key bytes
     * in isolated multi-validator tests) ONLY after strict BFT safety & Room persistence checks succeed.
     */
    suspend fun signLocalVote(
        votePhase: VotePhase,
        targetBlockHash: String,
        identityRepository: IdentityRepository? = null,
        privateKeyBytesForTest: ByteArray? = null,
        round: Int = currentRound,
        nowMs: Long = System.currentTimeMillis()
    ): LocalSignVoteResult = withContext(ioDispatcher) {
        mutex.withLock {
            if (localMobilePaused) {
                val msg = mobilePauseReason ?: "Consensus signing paused due to mobile battery/network constraints"
                return@withLock LocalSignVoteResult.Refused(ConsensusErrorCode.MOBILE_RESOURCE_PAUSED, msg)
            }

            val signerPubHex = when {
                identityRepository != null -> identityRepository.getPublicIdentity()?.publicKeyHex
                privateKeyBytesForTest != null -> signer.cryptoProvider.toHex(
                    signer.cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytesForTest)
                )
                else -> null
            } ?: return@withLock LocalSignVoteResult.Refused(ConsensusErrorCode.UNAUTHORIZED_VALIDATOR, "No local validator key available")

            val valId = signer.deriveValidatorIdFromHex(signerPubHex)
                ?: return@withLock LocalSignVoteResult.Refused(ConsensusErrorCode.INVALID_PROPOSER, "Invalid public key")

            if (!registry.isRegisteredActiveValidator(valId, currentHeight)) {
                return@withLock LocalSignVoteResult.Refused(
                    ConsensusErrorCode.UNAUTHORIZED_VALIDATOR,
                    "Local identity $valId is not an active authorized validator"
                )
            }

            val cleanHash = targetBlockHash.trim().lowercase()

            // STRICT SAFETY INVARIANTS AGAINST DOUBLE-SIGNING:
            // 1. Never regress below lastSignedHeight
            if (currentHeight < safetyState.lastSignedHeight) {
                return@withLock LocalSignVoteResult.Refused(
                    ConsensusErrorCode.SAFETY_DOUBLE_SIGN_PREVENTED,
                    "Safety violation prevented: height $currentHeight < lastSignedHeight ${safetyState.lastSignedHeight}"
                )
            }

            if (currentHeight == safetyState.lastSignedHeight) {
                if (round < safetyState.lastSignedRound) {
                    return@withLock LocalSignVoteResult.Refused(
                        ConsensusErrorCode.SAFETY_DOUBLE_SIGN_PREVENTED,
                        "Safety violation prevented: round $round < lastSignedRound ${safetyState.lastSignedRound}"
                    )
                }
                if (votePhase == VotePhase.PREVOTE &&
                    round == safetyState.lastPrevoteRound &&
                    safetyState.lastPrevoteHash != null &&
                    !safetyState.lastPrevoteHash.equals(cleanHash, ignoreCase = true)
                ) {
                    return@withLock LocalSignVoteResult.Refused(
                        ConsensusErrorCode.SAFETY_DOUBLE_SIGN_PREVENTED,
                        "Double-sign prevented: already signed PREVOTE at (h=$currentHeight, r=$round)"
                    )
                }
                if (votePhase == VotePhase.PRECOMMIT &&
                    round == safetyState.lastPrecommitRound &&
                    safetyState.lastPrecommitHash != null &&
                    !safetyState.lastPrecommitHash.equals(cleanHash, ignoreCase = true)
                ) {
                    return@withLock LocalSignVoteResult.Refused(
                        ConsensusErrorCode.SAFETY_DOUBLE_SIGN_PREVENTED,
                        "Double-sign prevented: already signed PRECOMMIT at (h=$currentHeight, r=$round)"
                    )
                }
            }

            // 2. BFT Lock Safety: If locked on a block hash at an earlier round, cannot prevote a conflicting hash
            // unless unlocked by a newer polkadot (validRound > lockedRound), nor precommit without prior lock.
            if (votePhase == VotePhase.PREVOTE &&
                safetyState.lockedBlockHash != null &&
                safetyState.lockedRound >= 0 &&
                !cleanHash.equals(ConsensusConstants.NIL_BLOCK_HASH, ignoreCase = true) &&
                !cleanHash.equals(safetyState.lockedBlockHash, ignoreCase = true) &&
                safetyState.validRound <= safetyState.lockedRound
            ) {
                return@withLock LocalSignVoteResult.Refused(
                    ConsensusErrorCode.SAFETY_DOUBLE_SIGN_PREVENTED,
                    "BFT lock active on ${safetyState.lockedBlockHash!!.take(12)} from r=${safetyState.lockedRound}"
                )
            }

            // 3. Commit safety: never precommit a non-nil block hash without PREVOTE quorum reached for that hash!
            if (votePhase == VotePhase.PRECOMMIT && !cleanHash.equals(ConsensusConstants.NIL_BLOCK_HASH, ignoreCase = true)) {
                val quorum = registry.calculateQuorum(currentHeight)
                val prevoteCount = countMatchingVotesLocked(prevotesByRound, round, cleanHash)
                if (!quorum.hasQuorum(prevoteCount)) {
                    return@withLock LocalSignVoteResult.Refused(
                        ConsensusErrorCode.INSUFFICIENT_QUORUM,
                        "Cannot sign PRECOMMIT before PREVOTE quorum ($prevoteCount/${quorum.requiredQuorum})"
                    )
                }
            }

            // 4. Persist safety signing state BEFORE emitting signature!
            val updatedSafety = safetyState.copy(
                lastSignedHeight = currentHeight,
                lastSignedRound = maxOf(safetyState.lastSignedRound, round),
                lastPrevoteRound = if (votePhase == VotePhase.PREVOTE) round else safetyState.lastPrevoteRound,
                lastPrevoteHash = if (votePhase == VotePhase.PREVOTE) cleanHash else safetyState.lastPrevoteHash,
                lastPrecommitRound = if (votePhase == VotePhase.PRECOMMIT) round else safetyState.lastPrecommitRound,
                lastPrecommitHash = if (votePhase == VotePhase.PRECOMMIT) cleanHash else safetyState.lastPrecommitHash,
                lockedRound = if (votePhase == VotePhase.PRECOMMIT && !cleanHash.equals(ConsensusConstants.NIL_BLOCK_HASH, true)) round else safetyState.lockedRound,
                lockedBlockHash = if (votePhase == VotePhase.PRECOMMIT && !cleanHash.equals(ConsensusConstants.NIL_BLOCK_HASH, true)) cleanHash else safetyState.lockedBlockHash,
                updatedAtMs = nowMs
            )
            storage.saveSafetyState(updatedSafety)
            safetyState = updatedSafety

            val unsigned = ConsensusVote(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = currentHeight,
                round = round,
                votePhase = votePhase,
                validatorId = valId,
                validatorPublicKeyHex = signerPubHex.lowercase(),
                proposedBlockHash = cleanHash,
                timestamp = nowMs
            )
            val signedVote = when {
                identityRepository != null -> signer.signVoteWithDeviceIdentity(unsigned, identityRepository)
                privateKeyBytesForTest != null -> signer.signVoteWithKeyPair(unsigned, privateKeyBytesForTest)
                else -> return@withLock LocalSignVoteResult.Refused(ConsensusErrorCode.UNAUTHORIZED_VALIDATOR, "Missing signer")
            }
            LocalSignVoteResult.Signed(signedVote)
        }
    }

    /**
     * Evaluates an incoming signed [ConsensusVote] (local or P2P), detects duplicate & conflicting votes,
     * checks BFT quorum thresholds, and triggers finality ONLY when verified PRECOMMIT quorum succeeds.
     */
    suspend fun submitVote(
        vote: ConsensusVote,
        nowMs: Long = System.currentTimeMillis()
    ): VoteSubmissionResult = withContext(ioDispatcher) {
        mutex.withLock {
            if (vote.blockHeight != currentHeight) {
                return@withLock VoteSubmissionResult.Rejected(
                    ConsensusErrorCode.INVALID_HEIGHT,
                    "Vote height ${vote.blockHeight} does not match active consensus height $currentHeight"
                )
            }

            val snapshot = registry.buildSnapshot(currentHeight)
            val valResult = validators.validateVote(vote, snapshot, nowMs)
            if (valResult is ConsensusValidationOutcome.Invalid) {
                lastError = valResult.reason
                lastErrorCode = valResult.code
                _events.emit(ConsensusEvent.ValidationRejected(valResult.code, valResult.reason))
                publishStateLocked()
                return@withLock VoteSubmissionResult.Rejected(valResult.code, valResult.reason)
            }

            val phaseMap = if (vote.votePhase == VotePhase.PREVOTE) prevotesByRound else precommitsByRound
            val roundMap = phaseMap.getOrPut(vote.round) { HashMap() }
            val existingVote = roundMap[vote.validatorId]

            if (existingVote != null) {
                if (existingVote.proposedBlockHash.equals(vote.proposedBlockHash, ignoreCase = true)) {
                    return@withLock VoteSubmissionResult.Duplicate(
                        "Duplicate ${vote.votePhase.name} ignored from ${vote.validatorId}"
                    )
                } else {
                    val evidence = validators.verifyAndBuildVoteEquivocationEvidence(
                        firstVote = existingVote,
                        secondVote = vote,
                        snapshot = snapshot,
                        detectedAtMs = nowMs
                    )
                    if (evidence != null) {
                        recordVerifiedEquivocationLocked(evidence)
                    }
                    lastError = "Conflicting ${vote.votePhase.name} detected from ${vote.validatorId}"
                    lastErrorCode = ConsensusErrorCode.CONFLICTING_VOTE
                    _events.emit(ConsensusEvent.ValidationRejected(ConsensusErrorCode.CONFLICTING_VOTE, lastError!!))
                    publishStateLocked()
                    return@withLock VoteSubmissionResult.Rejected(
                        ConsensusErrorCode.CONFLICTING_VOTE,
                        lastError!!,
                        equivocationEvidence = evidence
                    )
                }
            }

            // Store verified vote
            roundMap[vote.validatorId] = vote
            storage.saveVote(vote)
            if (vote.votePhase == VotePhase.PREVOTE) {
                registry.recordPrevote(vote.validatorId, nowMs)
            } else {
                registry.recordPrecommit(vote.validatorId, nowMs)
            }
            storage.saveValidators(registry.getAllValidators())

            _events.emit(ConsensusEvent.VoteAccepted(vote.blockHeight, vote.round, vote.votePhase, vote.validatorId, vote.proposedBlockHash))

            // Evaluate quorum ONLY for non-nil real proposed block hashes (nil quorum advances round on timeout)
            val quorum = registry.calculateQuorum(currentHeight)
            val matchingVotes = roundMap.values.filter {
                it.proposedBlockHash.equals(vote.proposedBlockHash, ignoreCase = true)
            }

            if (vote.isNilVote) {
                if (quorum.hasQuorum(matchingVotes.size) && vote.round == currentRound) {
                    advanceRoundLocked(reason = "Quorum of NIL ${vote.votePhase.name} reached", nowMs = nowMs)
                }
                publishStateLocked()
                return@withLock VoteSubmissionResult.Accepted(vote, quorumReached = quorum.hasQuorum(matchingVotes.size))
            }

            if (vote.votePhase == VotePhase.PREVOTE) {
                val reached = quorum.hasQuorum(matchingVotes.size)
                if (reached) {
                    // Valid polkadot reached: record validRound/hash & transition to PRE_COMMITTING
                    if (vote.round >= safetyState.validRound) {
                        safetyState = safetyState.copy(
                            validRound = vote.round,
                            validBlockHash = vote.proposedBlockHash.lowercase(),
                            updatedAtMs = nowMs
                        )
                        storage.saveSafetyState(safetyState)
                    }
                    if (vote.round == currentRound &&
                        (currentPhase == ConsensusPhase.PROPOSED || currentPhase == ConsensusPhase.PRE_VOTING)
                    ) {
                        currentPhase = ConsensusPhase.PRE_COMMITTING
                        saveMetaLocked(nowMs)
                    }
                    _events.emit(
                        ConsensusEvent.QuorumReached(
                            vote.blockHeight, vote.round, VotePhase.PREVOTE, vote.proposedBlockHash,
                            matchingVotes.size, quorum.requiredQuorum
                        )
                    )
                }
                publishStateLocked()
                return@withLock VoteSubmissionResult.Accepted(vote, quorumReached = reached)
            } else {
                // PRECOMMIT evaluation -> require valid PREVOTE quorum OR direct >= 2/3 precommit signatures + valid certificate check
                val reached = quorum.hasQuorum(matchingVotes.size)
                if (reached) {
                    val prevoteQuorumForHash = countMatchingVotesLocked(prevotesByRound, vote.round, vote.proposedBlockHash)
                    if (!quorum.hasQuorum(prevoteQuorumForHash)) {
                        // Safety rule: do not finalize without corresponding prevotes / proposal consistency
                        lastError = "Precommit quorum present without matching PREVOTE quorum"
                        lastErrorCode = ConsensusErrorCode.INSUFFICIENT_QUORUM
                        publishStateLocked()
                        return@withLock VoteSubmissionResult.Accepted(vote, quorumReached = false)
                    }

                    val cert = CommitCertificate(
                        chainId = config.chainId,
                        protocolVersion = config.protocolVersion,
                        blockHeight = currentHeight,
                        round = vote.round,
                        blockHash = vote.proposedBlockHash.lowercase(),
                        previousBlockHash = latestFinalizedHash,
                        validatorSetHash = snapshot.snapshotHash,
                        requiredQuorum = quorum.requiredQuorum,
                        precommitVotes = matchingVotes.sortedBy { it.validatorId },
                        finalizedAtMs = nowMs
                    )

                    val certCheck = validators.validateCommitCertificate(
                        certificate = cert,
                        snapshot = snapshot,
                        expectedPreviousHash = latestFinalizedHash
                    )
                    if (certCheck is ConsensusValidationOutcome.Invalid) {
                        lastError = certCheck.reason
                        lastErrorCode = certCheck.code
                        _events.emit(ConsensusEvent.ValidationRejected(certCheck.code, certCheck.reason))
                        publishStateLocked()
                        return@withLock VoteSubmissionResult.Rejected(certCheck.code, certCheck.reason)
                    }

                    // Finalize atomically in Room storage & optionally attach Stage 8 block
                    val attachedProposal = proposalsByRound[vote.round]?.values?.firstOrNull {
                        it.proposedBlockHash.equals(cert.blockHash, ignoreCase = true)
                    }
                    finalizeWithCertificateLocked(cert, attachedProposal?.attachedBlock, nowMs)
                    publishStateLocked()
                    return@withLock VoteSubmissionResult.Accepted(vote, quorumReached = true, commitCertificate = cert)
                }

                publishStateLocked()
                return@withLock VoteSubmissionResult.Accepted(vote, quorumReached = false)
            }
        }
    }

    /**
     * Verifies and ingests a complete [CommitCertificate] received from a peer during network recovery / partition healing.
     */
    suspend fun applyVerifiedCommitCertificate(
        certificate: CommitCertificate,
        attachedBlock: Block? = null,
        nowMs: Long = System.currentTimeMillis()
    ): ConsensusValidationOutcome = withContext(ioDispatcher) {
        mutex.withLock {
            // If blockchainManager is attached and a sync/recovery block matches chain tip + 1, align currentHeight cleanly
            if (attachedBlock != null && blockchainManager != null) {
                val chainTip = blockchainManager.getLatestBlock()
                if (chainTip != null && certificate.blockHeight == chainTip.height + 1L && currentHeight != certificate.blockHeight) {
                    latestFinalizedHeight = chainTip.height
                    latestFinalizedHash = chainTip.hash.lowercase()
                    latestFinalizedTimestampMs = chainTip.timestamp
                    currentHeight = certificate.blockHeight
                }
            }

            if (certificate.blockHeight != currentHeight) {
                if (blockchainManager != null && certificate.blockHeight > currentHeight) {
                    _events.emit(ConsensusEvent.BlockSyncRequired(certificate.blockHeight, certificate.blockHash))
                }
                return@withLock ConsensusValidationOutcome.Invalid(
                    ConsensusErrorCode.INVALID_HEIGHT,
                    "Certificate height ${certificate.blockHeight} != active height $currentHeight"
                )
            }
            val snapshot = registry.buildSnapshot(currentHeight)
            val check = validators.validateCommitCertificate(
                certificate = certificate,
                snapshot = snapshot,
                expectedPreviousHash = latestFinalizedHash
            )
            if (check is ConsensusValidationOutcome.Invalid) {
                lastError = check.reason
                lastErrorCode = check.code
                _events.emit(ConsensusEvent.ValidationRejected(check.code, check.reason))
                publishStateLocked()
                return@withLock check
            }

            val resolvedBlock = attachedBlock
                ?: proposalsByRound[certificate.round]?.values?.firstOrNull {
                    it.proposedBlockHash.equals(certificate.blockHash, ignoreCase = true)
                }?.attachedBlock
                ?: blockchainManager?.getBlockByHeight(certificate.blockHeight)?.takeIf {
                    it.hash.equals(certificate.blockHash, ignoreCase = true)
                }

            // If a full Stage 8 BlockchainManager is attached, never advance finality ahead of missing block payloads;
            // persist certificate and trigger Stage 12 block sync recovery instead of leaving a gap.
            if (blockchainManager != null && resolvedBlock == null) {
                storage.saveCommitCertificate(certificate)
                _events.emit(ConsensusEvent.BlockSyncRequired(certificate.blockHeight, certificate.blockHash))
                return@withLock ConsensusValidationOutcome.Valid
            }

            finalizeWithCertificateLocked(certificate, resolvedBlock, nowMs)
            publishStateLocked()
            ConsensusValidationOutcome.Valid
        }
    }

    /**
     * Checks timeout expiry for the active round and advances to `round + 1` safely while keeping BFT locks.
     */
    suspend fun checkAndAdvanceOnTimeout(nowMs: Long = System.currentTimeMillis()): Boolean = withContext(ioDispatcher) {
        mutex.withLock {
            val baseTimeout = when (currentPhase) {
                ConsensusPhase.PROPOSED -> config.baseProposalTimeoutMs
                ConsensusPhase.PRE_VOTING -> config.basePrevoteTimeoutMs
                ConsensusPhase.PRE_COMMITTING -> config.basePrecommitTimeoutMs
                ConsensusPhase.COMMITTED, ConsensusPhase.REJECTED, ConsensusPhase.TIMED_OUT -> config.baseProposalTimeoutMs
            }
            val roundTimeout = config.timeoutForRoundMs(baseTimeout, currentRound)
            if (nowMs - currentRoundStartedAtMs < roundTimeout) {
                return@withLock false
            }
            advanceRoundLocked("Timeout elapsed (${nowMs - currentRoundStartedAtMs}ms >= ${roundTimeout}ms)", nowMs)
            publishStateLocked()
            true
        }
    }

    suspend fun forceTimeoutAndAdvanceRound(
        reason: String = "Manual or network round timeout",
        nowMs: Long = System.currentTimeMillis()
    ): Int = withContext(ioDispatcher) {
        mutex.withLock {
            advanceRoundLocked(reason, nowMs)
            publishStateLocked()
            currentRound
        }
    }

    /**
     * Processes a verified [RoundChangeMessage] and records missed-round stats conservatively.
     */
    suspend fun processRoundChangeMessage(
        msg: RoundChangeMessage,
        nowMs: Long = System.currentTimeMillis()
    ): ConsensusValidationOutcome = withContext(ioDispatcher) {
        mutex.withLock {
            if (msg.chainId != config.chainId) {
                return@withLock ConsensusValidationOutcome.Invalid(ConsensusErrorCode.INVALID_CHAIN_ID, "Chain ID mismatch")
            }
            if (msg.blockHeight != currentHeight || msg.toRound <= msg.fromRound) {
                return@withLock ConsensusValidationOutcome.Invalid(ConsensusErrorCode.INVALID_ROUND, "Invalid round change bounds")
            }
            val snapshot = registry.buildSnapshot(currentHeight)
            val reg = snapshot.findActiveValidator(msg.validatorId)
                ?: return@withLock ConsensusValidationOutcome.Invalid(ConsensusErrorCode.UNAUTHORIZED_VALIDATOR, "Unauthorized validator")
            if (!reg.publicKeyHex.equals(msg.validatorPublicKeyHex, ignoreCase = true) ||
                !signer.verifyRoundChangeSignature(msg)
            ) {
                return@withLock ConsensusValidationOutcome.Invalid(ConsensusErrorCode.INVALID_VOTE_SIGNATURE, "Invalid round change signature")
            }
            ConsensusValidationOutcome.Valid
        }
    }

    private suspend fun advanceRoundLocked(reason: String, nowMs: Long) {
        val oldRound = currentRound
        val participantsInOldRound = (prevotesByRound[oldRound]?.keys ?: emptySet()) +
            (precommitsByRound[oldRound]?.keys ?: emptySet())
        registry.recordRoundMissedByOfflineValidators(participantsInOldRound)
        storage.saveValidators(registry.getAllValidators())

        currentRound = oldRound + 1
        currentPhase = ConsensusPhase.TIMED_OUT
        currentRoundStartedAtMs = nowMs
        saveMetaLocked(nowMs)

        val nextProposer = registry.selectDeterministicProposer(registry.buildSnapshot(currentHeight), currentHeight, currentRound)
        _events.emit(ConsensusEvent.RoundTimedOut(currentHeight, oldRound, currentRound, nextProposer?.validatorId))

        // After emitting TIMED_OUT event transition round to PROPOSED so next proposer can act
        currentPhase = ConsensusPhase.PROPOSED
        saveMetaLocked(nowMs)
    }

    private suspend fun finalizeWithCertificateLocked(
        cert: CommitCertificate,
        attachedBlock: Block?,
        nowMs: Long
    ) {
        // Optional Stage 8 + Stage 9 integration when a full Stage 8 block payload accompanies consensus.
        // Preserves Stage 8 block hashing strictly untouched (never mutating header hash after signing).
        if (attachedBlock != null && blockchainManager != null && attachedBlock.height == cert.blockHeight) {
            if (attachedBlock.hash.equals(cert.blockHash, ignoreCase = true)) {
                val res = blockchainManager.submitIncomingBlock(attachedBlock, nowMs = nowMs)
                if (res is BlockIngestionResult.Accepted && txBlockBridge != null) {
                    txBlockBridge.onBlockCommitted(attachedBlock)
                }
            }
        }

        val finalizedHeight = cert.blockHeight
        val finalizedHash = cert.blockHash.lowercase()

        latestFinalizedHeight = finalizedHeight
        latestFinalizedHash = finalizedHash
        latestFinalizedTimestampMs = cert.finalizedAtMs

        val nextHeight = finalizedHeight + 1L
        currentHeight = nextHeight
        currentRound = 0
        currentPhase = ConsensusPhase.COMMITTED

        // Reset round-specific locks while monotonically preserving lastSignedHeight
        val resetSafety = SafetySigningState(
            chainId = config.chainId,
            lastSignedHeight = maxOf(safetyState.lastSignedHeight, finalizedHeight),
            lastSignedRound = -1,
            lastPrevoteRound = -1,
            lastPrevoteHash = null,
            lastPrecommitRound = -1,
            lastPrecommitHash = null,
            lockedRound = -1,
            lockedBlockHash = null,
            validRound = -1,
            validBlockHash = null,
            updatedAtMs = nowMs
        )
        val nextMeta = ConsensusMetaState(
            chainId = config.chainId,
            currentHeight = nextHeight,
            currentRound = 0,
            phase = ConsensusPhase.PROPOSED,
            validatorSetHash = cert.validatorSetHash,
            latestFinalizedHeight = finalizedHeight,
            latestFinalizedHash = finalizedHash,
            latestFinalizedTimestampMs = cert.finalizedAtMs,
            updatedAtMs = nowMs
        )

        storage.finalizeHeightAtomically(cert, nextMeta, resetSafety)
        safetyState = resetSafety

        proposalsByRound.clear()
        prevotesByRound.clear()
        precommitsByRound.clear()
        currentRoundStartedAtMs = nowMs

        _latestCommitCertificate.value = cert
        lastError = null
        lastErrorCode = ConsensusErrorCode.NONE
        _events.emit(ConsensusEvent.BlockFinalized(cert))

        // Ready for next height proposal
        currentPhase = ConsensusPhase.PROPOSED
    }

    private suspend fun recordVerifiedEquivocationLocked(evidence: EquivocationEvidence) {
        if (!evidence.verifiedCryptographically) return
        storage.saveEquivocationEvidence(evidence)
        registry.markSlashedPendingReview(
            validatorId = evidence.validatorId,
            reason = "${evidence.evidenceType.name} at h=${evidence.blockHeight}, r=${evidence.round}"
        )
        storage.saveValidators(registry.getAllValidators())
        _equivocationHistory.value = storage.getAllEquivocationEvidence()
        _events.emit(ConsensusEvent.EquivocationDetected(evidence))
    }

    private suspend fun saveMetaLocked(nowMs: Long) {
        val snapshot = registry.buildSnapshot(currentHeight)
        storage.saveMeta(
            ConsensusMetaState(
                chainId = config.chainId,
                currentHeight = currentHeight,
                currentRound = currentRound,
                phase = currentPhase,
                validatorSetHash = snapshot.snapshotHash,
                latestFinalizedHeight = latestFinalizedHeight,
                latestFinalizedHash = latestFinalizedHash,
                latestFinalizedTimestampMs = latestFinalizedTimestampMs,
                updatedAtMs = nowMs
            )
        )
    }

    private fun reconcilePhaseFromRestoredVotesLocked() {
        val hasPrecommits = !precommitsByRound[currentRound].isNullOrEmpty()
        val hasPrevotes = !prevotesByRound[currentRound].isNullOrEmpty()
        val hasProposal = !proposalsByRound[currentRound].isNullOrEmpty()
        currentPhase = when {
            hasPrecommits -> ConsensusPhase.PRE_COMMITTING
            hasPrevotes || hasProposal -> ConsensusPhase.PRE_VOTING
            else -> ConsensusPhase.PROPOSED
        }
    }

    private fun countMatchingVotesLocked(
        map: Map<Int, Map<String, ConsensusVote>>,
        round: Int,
        hash: String
    ): Int {
        return map[round]?.values?.count { it.proposedBlockHash.equals(hash, ignoreCase = true) } ?: 0
    }

    private fun publishStateLocked(): ConsensusEngineState {
        val snapshot = registry.buildSnapshot(currentHeight)
        val active = snapshot.activeValidatorsSorted
        val quorum = QuorumCalculator.calculate(active.size, config.minValidatorsForBft)
        val proposer = registry.selectDeterministicProposer(snapshot, currentHeight, currentRound)
        val roundPrevotes = prevotesByRound[currentRound] ?: emptyMap()
        val roundPrecommits = precommitsByRound[currentRound] ?: emptyMap()

        val participation = registry.getAllValidators().map { v ->
            ValidatorParticipationSummary(
                validatorId = v.validatorId,
                displayName = v.displayName,
                status = v.status,
                availability = v.availability,
                hasPrevotedCurrentRound = roundPrevotes.containsKey(v.validatorId),
                hasPrecommittedCurrentRound = roundPrecommits.containsKey(v.validatorId),
                validPrevotesTotal = v.history.validPrevotesCount,
                validPrecommitsTotal = v.history.validPrecommitsCount,
                isCurrentProposer = proposer?.validatorId == v.validatorId
            )
        }

        val snapshotState = ConsensusEngineState(
            isInitialized = isInitialized,
            isDevelopmentConsensus = config.isDevelopmentConsensus,
            chainId = config.chainId,
            currentHeight = currentHeight,
            currentRound = currentRound,
            phase = currentPhase,
            activeValidatorCount = active.size,
            availableValidatorCount = active.count { it.isOnlineAndReady },
            requiredQuorum = quorum.requiredQuorum,
            toleratedByzantineFaults = quorum.toleratedByzantineFaults,
            bftSafetyMet = quorum.isBftSafetyAchieved,
            currentProposerId = proposer?.validatorId,
            prevotesReceived = roundPrevotes.size,
            precommitsReceived = roundPrecommits.size,
            latestFinalizedHeight = latestFinalizedHeight,
            latestFinalizedHash = latestFinalizedHash,
            validatorParticipations = participation,
            equivocationCount = _equivocationHistory.value.size,
            localValidatorId = localValidatorId,
            localMobilePaused = localMobilePaused,
            mobilePauseReason = mobilePauseReason,
            lastError = lastError,
            lastErrorCode = lastErrorCode
        )
        _state.value = snapshotState
        return snapshotState
    }

    override fun close() {
        storage.close()
    }
}
