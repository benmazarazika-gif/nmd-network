package com.example.consensus.model

import com.example.blockchain.model.Block
import org.json.JSONArray
import org.json.JSONObject

object ConsensusConstants {
    const val PROTOCOL_VERSION = 1
    const val NIL_BLOCK_HASH = "0000000000000000000000000000000000000000000000000000000000000000"
    const val VALIDATOR_ID_PREFIX = "nmd_val_"
}

enum class ValidatorStatus {
    ACTIVE,
    STANDBY,
    SUSPENDED,
    OFFLINE,
    SLASHED_PENDING_REVIEW
}

enum class ValidatorAvailability {
    ONLINE_AVAILABLE,
    LOW_BATTERY_PAUSED,
    BACKGROUND_THROTTLED,
    TEMPORARILY_UNAVAILABLE,
    DISCONNECTED
}

enum class ConsensusPhase {
    PROPOSED,
    PRE_VOTING,
    PRE_COMMITTING,
    COMMITTED,
    REJECTED,
    TIMED_OUT
}

enum class VotePhase {
    PREVOTE,
    PRECOMMIT
}

enum class EquivocationType {
    CONFLICTING_PROPOSAL,
    CONFLICTING_PREVOTE,
    CONFLICTING_PRECOMMIT
}

enum class ConsensusErrorCode {
    NONE,
    INVALID_CHAIN_ID,
    UNSUPPORTED_PROTOCOL_VERSION,
    INVALID_HEIGHT,
    INVALID_ROUND,
    INVALID_TIMESTAMP,
    INVALID_PREVIOUS_HASH,
    INVALID_BLOCK_HASH,
    INVALID_PROPOSER,
    UNAUTHORIZED_PROPOSER,
    INVALID_PROPOSAL_SIGNATURE,
    DUPLICATE_PROPOSAL,
    CONFLICTING_PROPOSAL,
    BLOCK_STRUCTURAL_INVALID,
    UNAUTHORIZED_VALIDATOR,
    VALIDATOR_KEY_MISMATCH,
    INVALID_VOTE_SIGNATURE,
    DUPLICATE_VOTE,
    CONFLICTING_VOTE,
    INSUFFICIENT_QUORUM,
    DUPLICATE_VOTING_POWER,
    INVALID_COMMIT_CERTIFICATE,
    SAFETY_DOUBLE_SIGN_PREVENTED,
    UNVERIFIED_EVIDENCE_REJECTED,
    RATE_LIMITED,
    PAYLOAD_TOO_LARGE,
    MALFORMED_MESSAGE,
    MOBILE_RESOURCE_PAUSED
}

data class ValidatorHistoryMetadata(
    val proposedBlocksCount: Long = 0L,
    val validPrevotesCount: Long = 0L,
    val validPrecommitsCount: Long = 0L,
    val missedRoundsCount: Long = 0L,
    val committedBlocksSigned: Long = 0L,
    val verifiedEquivocationsCount: Long = 0L
)

data class ValidatorInfo(
    val validatorId: String,
    val nodeId: String,
    val publicKeyHex: String,
    val displayName: String,
    val votingPower: Long = 1L,
    val status: ValidatorStatus = ValidatorStatus.ACTIVE,
    val availability: ValidatorAvailability = ValidatorAvailability.ONLINE_AVAILABLE,
    val registeredAtMs: Long = System.currentTimeMillis(),
    val lastActiveAtMs: Long = registeredAtMs,
    val suspensionReason: String? = null,
    val history: ValidatorHistoryMetadata = ValidatorHistoryMetadata()
) {
    val isAuthorizedActive: Boolean
        get() = status == ValidatorStatus.ACTIVE && votingPower > 0L

    val isOnlineAndReady: Boolean
        get() = isAuthorizedActive && availability == ValidatorAvailability.ONLINE_AVAILABLE

    val shortValidatorId: String
        get() = if (validatorId.length > 18) "${validatorId.take(12)}...${validatorId.takeLast(5)}" else validatorId

    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("validator_id", validatorId)
        put("node_id", nodeId)
        put("public_key", publicKeyHex.lowercase())
        put("display_name", displayName)
        put("voting_power", votingPower)
        put("status", status.name)
        put("availability", availability.name)
        put("registered_at", registeredAtMs)
        put("last_active_at", lastActiveAtMs)
        put("suspension_reason", suspensionReason ?: JSONObject.NULL)
        put("proposed_count", history.proposedBlocksCount)
        put("prevotes_count", history.validPrevotesCount)
        put("precommits_count", history.validPrecommitsCount)
        put("missed_rounds_count", history.missedRoundsCount)
        put("committed_signed_count", history.committedBlocksSigned)
        put("equivocations_count", history.verifiedEquivocationsCount)
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): ValidatorInfo? {
            return try {
                ValidatorInfo(
                    validatorId = obj.getString("validator_id").trim(),
                    nodeId = obj.getString("node_id").trim(),
                    publicKeyHex = obj.getString("public_key").trim().lowercase(),
                    displayName = obj.optString("display_name", "Validator"),
                    votingPower = obj.optLong("voting_power", 1L),
                    status = ValidatorStatus.valueOf(obj.getString("status")),
                    availability = ValidatorAvailability.valueOf(obj.optString("availability", ValidatorAvailability.ONLINE_AVAILABLE.name)),
                    registeredAtMs = obj.optLong("registered_at", 0L),
                    lastActiveAtMs = obj.optLong("last_active_at", 0L),
                    suspensionReason = if (obj.isNull("suspension_reason")) null else obj.optString("suspension_reason"),
                    history = ValidatorHistoryMetadata(
                        proposedBlocksCount = obj.optLong("proposed_count", 0L),
                        validPrevotesCount = obj.optLong("prevotes_count", 0L),
                        validPrecommitsCount = obj.optLong("precommits_count", 0L),
                        missedRoundsCount = obj.optLong("missed_rounds_count", 0L),
                        committedBlocksSigned = obj.optLong("committed_signed_count", 0L),
                        verifiedEquivocationsCount = obj.optLong("equivocations_count", 0L)
                    )
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class ValidatorSetSnapshot(
    val chainId: String,
    val epochOrHeight: Long,
    val validators: List<ValidatorInfo>,
    val snapshotHash: String
) {
    val activeValidatorsSorted: List<ValidatorInfo>
        get() = validators.filter { it.isAuthorizedActive }.sortedBy { it.validatorId }

    fun findValidator(validatorId: String): ValidatorInfo? {
        return validators.firstOrNull { it.validatorId == validatorId }
    }

    fun findActiveValidator(validatorId: String): ValidatorInfo? {
        return activeValidatorsSorted.firstOrNull { it.validatorId == validatorId }
    }
}

data class BlockProposal(
    val chainId: String,
    val protocolVersion: Int = ConsensusConstants.PROTOCOL_VERSION,
    val blockHeight: Long,
    val round: Int,
    val proposerId: String,
    val proposerPublicKeyHex: String,
    val previousBlockHash: String,
    val proposedBlockHash: String,
    val timestamp: Long,
    val signatureHex: String = "",
    val validRound: Int = -1,
    val attachedBlock: Block? = null
) {
    val shortBlockHash: String
        get() = if (proposedBlockHash.length > 16) "${proposedBlockHash.take(10)}...${proposedBlockHash.takeLast(6)}" else proposedBlockHash

    fun toJson(includeBlockBody: Boolean = true): String {
        return JSONObject().apply {
            put("chain_id", chainId)
            put("protocol_version", protocolVersion)
            put("block_height", blockHeight)
            put("round", round)
            put("proposer_id", proposerId)
            put("proposer_public_key", proposerPublicKeyHex.lowercase())
            put("previous_block_hash", previousBlockHash.lowercase())
            put("proposed_block_hash", proposedBlockHash.lowercase())
            put("timestamp", timestamp)
            put("signature", signatureHex.lowercase())
            put("valid_round", validRound)
            if (includeBlockBody && attachedBlock != null) {
                put("attached_block_json", attachedBlock.toStorageJson())
            }
        }.toString()
    }

    companion object {
        fun fromJson(raw: String): BlockProposal? {
            if (raw.isBlank()) return null
            return try {
                val j = JSONObject(raw)
                val attachedJson = if (j.has("attached_block_json") && !j.isNull("attached_block_json")) {
                    j.getString("attached_block_json")
                } else null
                val block = attachedJson?.let { Block.fromStorageJson(it) }
                BlockProposal(
                    chainId = j.getString("chain_id").trim(),
                    protocolVersion = j.getInt("protocol_version"),
                    blockHeight = j.getLong("block_height"),
                    round = j.getInt("round"),
                    proposerId = j.getString("proposer_id").trim(),
                    proposerPublicKeyHex = j.getString("proposer_public_key").trim().lowercase(),
                    previousBlockHash = j.getString("previous_block_hash").trim().lowercase(),
                    proposedBlockHash = j.getString("proposed_block_hash").trim().lowercase(),
                    timestamp = j.getLong("timestamp"),
                    signatureHex = j.getString("signature").trim().lowercase(),
                    validRound = j.optInt("valid_round", -1),
                    attachedBlock = block
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class ConsensusVote(
    val chainId: String,
    val protocolVersion: Int = ConsensusConstants.PROTOCOL_VERSION,
    val blockHeight: Long,
    val round: Int,
    val votePhase: VotePhase,
    val validatorId: String,
    val validatorPublicKeyHex: String,
    val proposedBlockHash: String,
    val timestamp: Long,
    val signatureHex: String = ""
) {
    val isNilVote: Boolean
        get() = proposedBlockHash.equals(ConsensusConstants.NIL_BLOCK_HASH, ignoreCase = true)

    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("chain_id", chainId)
        put("protocol_version", protocolVersion)
        put("block_height", blockHeight)
        put("round", round)
        put("vote_phase", votePhase.name)
        put("validator_id", validatorId)
        put("validator_public_key", validatorPublicKeyHex.lowercase())
        put("proposed_block_hash", proposedBlockHash.lowercase())
        put("timestamp", timestamp)
        put("signature", signatureHex.lowercase())
    }

    fun toJson(): String = toJsonObject().toString()

    companion object {
        fun fromJsonObject(j: JSONObject): ConsensusVote? {
            return try {
                ConsensusVote(
                    chainId = j.getString("chain_id").trim(),
                    protocolVersion = j.getInt("protocol_version"),
                    blockHeight = j.getLong("block_height"),
                    round = j.getInt("round"),
                    votePhase = VotePhase.valueOf(j.getString("vote_phase").trim().uppercase()),
                    validatorId = j.getString("validator_id").trim(),
                    validatorPublicKeyHex = j.getString("validator_public_key").trim().lowercase(),
                    proposedBlockHash = j.getString("proposed_block_hash").trim().lowercase(),
                    timestamp = j.getLong("timestamp"),
                    signatureHex = j.getString("signature").trim().lowercase()
                )
            } catch (_: Exception) {
                null
            }
        }

        fun fromJson(raw: String): ConsensusVote? {
            if (raw.isBlank()) return null
            return try {
                fromJsonObject(JSONObject(raw))
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class CommitCertificate(
    val chainId: String,
    val protocolVersion: Int = ConsensusConstants.PROTOCOL_VERSION,
    val blockHeight: Long,
    val round: Int,
    val blockHash: String,
    val previousBlockHash: String,
    val validatorSetHash: String,
    val requiredQuorum: Int,
    val precommitVotes: List<ConsensusVote>,
    val finalizedAtMs: Long = System.currentTimeMillis()
) {
    val shortBlockHash: String
        get() = if (blockHash.length > 16) "${blockHash.take(10)}...${blockHash.takeLast(6)}" else blockHash

    fun toJson(): String {
        val arr = JSONArray()
        precommitVotes.forEach { arr.put(it.toJsonObject()) }
        return JSONObject().apply {
            put("chain_id", chainId)
            put("protocol_version", protocolVersion)
            put("block_height", blockHeight)
            put("round", round)
            put("block_hash", blockHash.lowercase())
            put("previous_block_hash", previousBlockHash.lowercase())
            put("validator_set_hash", validatorSetHash.lowercase())
            put("required_quorum", requiredQuorum)
            put("precommit_votes", arr)
            put("finalized_at", finalizedAtMs)
        }.toString()
    }

    companion object {
        fun fromJson(raw: String): CommitCertificate? {
            if (raw.isBlank()) return null
            return try {
                val j = JSONObject(raw)
                val arr = j.getJSONArray("precommit_votes")
                val votes = buildList {
                    for (i in 0 until arr.length()) {
                        val vote = ConsensusVote.fromJsonObject(arr.getJSONObject(i)) ?: return null
                        add(vote)
                    }
                }
                CommitCertificate(
                    chainId = j.getString("chain_id").trim(),
                    protocolVersion = j.getInt("protocol_version"),
                    blockHeight = j.getLong("block_height"),
                    round = j.getInt("round"),
                    blockHash = j.getString("block_hash").trim().lowercase(),
                    previousBlockHash = j.getString("previous_block_hash").trim().lowercase(),
                    validatorSetHash = j.getString("validator_set_hash").trim().lowercase(),
                    requiredQuorum = j.getInt("required_quorum"),
                    precommitVotes = votes,
                    finalizedAtMs = j.optLong("finalized_at", 0L)
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class RoundChangeMessage(
    val chainId: String,
    val protocolVersion: Int = ConsensusConstants.PROTOCOL_VERSION,
    val blockHeight: Long,
    val fromRound: Int,
    val toRound: Int,
    val validatorId: String,
    val validatorPublicKeyHex: String,
    val reason: String,
    val timestamp: Long,
    val signatureHex: String = ""
) {
    fun toJson(): String = JSONObject().apply {
        put("chain_id", chainId)
        put("protocol_version", protocolVersion)
        put("block_height", blockHeight)
        put("from_round", fromRound)
        put("to_round", toRound)
        put("validator_id", validatorId)
        put("validator_public_key", validatorPublicKeyHex.lowercase())
        put("reason", reason)
        put("timestamp", timestamp)
        put("signature", signatureHex.lowercase())
    }.toString()

    companion object {
        fun fromJson(raw: String): RoundChangeMessage? {
            if (raw.isBlank()) return null
            return try {
                val j = JSONObject(raw)
                RoundChangeMessage(
                    chainId = j.getString("chain_id").trim(),
                    protocolVersion = j.getInt("protocol_version"),
                    blockHeight = j.getLong("block_height"),
                    fromRound = j.getInt("from_round"),
                    toRound = j.getInt("to_round"),
                    validatorId = j.getString("validator_id").trim(),
                    validatorPublicKeyHex = j.getString("validator_public_key").trim().lowercase(),
                    reason = j.optString("reason", ""),
                    timestamp = j.getLong("timestamp"),
                    signatureHex = j.getString("signature").trim().lowercase()
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class ValidatorStatusAnnouncement(
    val chainId: String,
    val protocolVersion: Int = ConsensusConstants.PROTOCOL_VERSION,
    val validatorId: String,
    val publicKeyHex: String,
    val availability: ValidatorAvailability,
    val currentHeight: Long,
    val currentRound: Int,
    val batteryPercent: Int? = null,
    val timestamp: Long,
    val signatureHex: String = ""
) {
    fun toJson(): String = JSONObject().apply {
        put("chain_id", chainId)
        put("protocol_version", protocolVersion)
        put("validator_id", validatorId)
        put("public_key", publicKeyHex.lowercase())
        put("availability", availability.name)
        put("current_height", currentHeight)
        put("current_round", currentRound)
        put("battery_percent", batteryPercent ?: JSONObject.NULL)
        put("timestamp", timestamp)
        put("signature", signatureHex.lowercase())
    }.toString()

    companion object {
        fun fromJson(raw: String): ValidatorStatusAnnouncement? {
            if (raw.isBlank()) return null
            return try {
                val j = JSONObject(raw)
                ValidatorStatusAnnouncement(
                    chainId = j.getString("chain_id").trim(),
                    protocolVersion = j.getInt("protocol_version"),
                    validatorId = j.getString("validator_id").trim(),
                    publicKeyHex = j.getString("public_key").trim().lowercase(),
                    availability = ValidatorAvailability.valueOf(j.getString("availability")),
                    currentHeight = j.getLong("current_height"),
                    currentRound = j.getInt("current_round"),
                    batteryPercent = if (j.isNull("battery_percent")) null else j.optInt("battery_percent"),
                    timestamp = j.getLong("timestamp"),
                    signatureHex = j.getString("signature").trim().lowercase()
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class EquivocationEvidence(
    val evidenceId: String,
    val chainId: String,
    val blockHeight: Long,
    val round: Int,
    val validatorId: String,
    val evidenceType: EquivocationType,
    val firstConflictingPayloadJson: String,
    val secondConflictingPayloadJson: String,
    val firstHash: String,
    val secondHash: String,
    val detectedAtMs: Long = System.currentTimeMillis(),
    val verifiedCryptographically: Boolean = false
)

/**
 * Safety-critical local signing state persisted atomically in Room BEFORE sending any outbound vote.
 * Guarantees a node never signs conflicting votes across app restarts or crashes.
 */
data class SafetySigningState(
    val chainId: String,
    val lastSignedHeight: Long = -1L,
    val lastSignedRound: Int = -1,
    val lastPrevoteRound: Int = -1,
    val lastPrevoteHash: String? = null,
    val lastPrecommitRound: Int = -1,
    val lastPrecommitHash: String? = null,
    val lockedRound: Int = -1,
    val lockedBlockHash: String? = null,
    val validRound: Int = -1,
    val validBlockHash: String? = null,
    val updatedAtMs: Long = System.currentTimeMillis()
)

data class ValidatorParticipationSummary(
    val validatorId: String,
    val displayName: String,
    val status: ValidatorStatus,
    val availability: ValidatorAvailability,
    val hasPrevotedCurrentRound: Boolean = false,
    val hasPrecommittedCurrentRound: Boolean = false,
    val validPrevotesTotal: Long = 0L,
    val validPrecommitsTotal: Long = 0L,
    val isCurrentProposer: Boolean = false
)

data class ConsensusEngineState(
    val isInitialized: Boolean = false,
    val isDevelopmentConsensus: Boolean = true,
    val chainId: String = "nmd-local-dev-1",
    val currentHeight: Long = 1L,
    val currentRound: Int = 0,
    val phase: ConsensusPhase = ConsensusPhase.PROPOSED,
    val activeValidatorCount: Int = 0,
    val availableValidatorCount: Int = 0,
    val requiredQuorum: Int = 0,
    val toleratedByzantineFaults: Int = 0,
    val bftSafetyMet: Boolean = false,
    val currentProposerId: String? = null,
    val prevotesReceived: Int = 0,
    val precommitsReceived: Int = 0,
    val latestFinalizedHeight: Long = 0L,
    val latestFinalizedHash: String = ConsensusConstants.NIL_BLOCK_HASH,
    val validatorParticipations: List<ValidatorParticipationSummary> = emptyList(),
    val equivocationCount: Int = 0,
    val localValidatorId: String? = null,
    val localMobilePaused: Boolean = false,
    val mobilePauseReason: String? = null,
    val lastError: String? = null,
    val lastErrorCode: ConsensusErrorCode = ConsensusErrorCode.NONE
)
