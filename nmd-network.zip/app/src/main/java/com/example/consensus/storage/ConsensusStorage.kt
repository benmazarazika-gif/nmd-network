package com.example.consensus.storage

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ConsensusPhase
import com.example.consensus.model.ConsensusVote
import com.example.consensus.model.EquivocationEvidence
import com.example.consensus.model.EquivocationType
import com.example.consensus.model.SafetySigningState
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.VotePhase
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.Closeable

data class ConsensusMetaState(
    val chainId: String,
    val currentHeight: Long = 1L,
    val currentRound: Int = 0,
    val phase: ConsensusPhase = ConsensusPhase.PROPOSED,
    val validatorSetHash: String = "",
    val latestFinalizedHeight: Long = 0L,
    val latestFinalizedHash: String = ConsensusConstants.NIL_BLOCK_HASH,
    val latestFinalizedTimestampMs: Long = 0L,
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "consensus_meta")
data class ConsensusMetaEntity(
    @PrimaryKey val chainId: String,
    val currentHeight: Long,
    val currentRound: Int,
    val phase: String,
    val validatorSetHash: String,
    val latestFinalizedHeight: Long,
    val latestFinalizedHash: String,
    val latestFinalizedTimestampMs: Long,
    val updatedAtMs: Long
) {
    fun toDomain() = ConsensusMetaState(
        chainId = chainId,
        currentHeight = currentHeight,
        currentRound = currentRound,
        phase = try { ConsensusPhase.valueOf(phase) } catch (_: Exception) { ConsensusPhase.PROPOSED },
        validatorSetHash = validatorSetHash,
        latestFinalizedHeight = latestFinalizedHeight,
        latestFinalizedHash = latestFinalizedHash,
        latestFinalizedTimestampMs = latestFinalizedTimestampMs,
        updatedAtMs = updatedAtMs
    )
}

@Entity(tableName = "safety_signing_state")
data class SafetySigningStateEntity(
    @PrimaryKey val chainId: String,
    val lastSignedHeight: Long,
    val lastSignedRound: Int,
    val lastPrevoteRound: Int,
    val lastPrevoteHash: String?,
    val lastPrecommitRound: Int,
    val lastPrecommitHash: String?,
    val lockedRound: Int,
    val lockedBlockHash: String?,
    val validRound: Int,
    val validBlockHash: String?,
    val updatedAtMs: Long
) {
    fun toDomain() = SafetySigningState(
        chainId = chainId,
        lastSignedHeight = lastSignedHeight,
        lastSignedRound = lastSignedRound,
        lastPrevoteRound = lastPrevoteRound,
        lastPrevoteHash = lastPrevoteHash,
        lastPrecommitRound = lastPrecommitRound,
        lastPrecommitHash = lastPrecommitHash,
        lockedRound = lockedRound,
        lockedBlockHash = lockedBlockHash,
        validRound = validRound,
        validBlockHash = validBlockHash,
        updatedAtMs = updatedAtMs
    )
}

@Entity(tableName = "validator_set_entries")
data class ValidatorEntryEntity(
    @PrimaryKey val validatorId: String,
    val validatorJson: String,
    val updatedAtMs: Long
)

@Entity(
    tableName = "consensus_proposals",
    indices = [Index(value = ["blockHeight", "round"])]
)
data class ProposalEntity(
    @PrimaryKey val compositeKey: String,
    val blockHeight: Long,
    val round: Int,
    val proposerId: String,
    val proposedBlockHash: String,
    val proposalJson: String,
    val receivedAtMs: Long
)

@Entity(
    tableName = "consensus_votes",
    indices = [Index(value = ["blockHeight", "round", "votePhase"])]
)
data class VoteEntity(
    @PrimaryKey val compositeKey: String,
    val blockHeight: Long,
    val round: Int,
    val votePhase: String,
    val validatorId: String,
    val proposedBlockHash: String,
    val voteJson: String,
    val receivedAtMs: Long
)

@Entity(tableName = "commit_certificates")
data class CommitCertificateEntity(
    @PrimaryKey val blockHeight: Long,
    val round: Int,
    val blockHash: String,
    val certificateJson: String,
    val finalizedAtMs: Long
)

@Entity(
    tableName = "equivocation_evidence",
    indices = [Index(value = ["validatorId", "blockHeight"])]
)
data class EquivocationEvidenceEntity(
    @PrimaryKey val evidenceId: String,
    val chainId: String,
    val blockHeight: Long,
    val round: Int,
    val validatorId: String,
    val evidenceType: String,
    val firstConflictingPayloadJson: String,
    val secondConflictingPayloadJson: String,
    val firstHash: String,
    val secondHash: String,
    val detectedAtMs: Long,
    val verifiedCryptographically: Boolean
) {
    fun toDomain() = EquivocationEvidence(
        evidenceId = evidenceId,
        chainId = chainId,
        blockHeight = blockHeight,
        round = round,
        validatorId = validatorId,
        evidenceType = EquivocationType.valueOf(evidenceType),
        firstConflictingPayloadJson = firstConflictingPayloadJson,
        secondConflictingPayloadJson = secondConflictingPayloadJson,
        firstHash = firstHash,
        secondHash = secondHash,
        detectedAtMs = detectedAtMs,
        verifiedCryptographically = verifiedCryptographically
    )
}

@Dao
interface ConsensusDao {
    @Query("SELECT * FROM consensus_meta WHERE chainId = :chainId LIMIT 1")
    suspend fun getMeta(chainId: String): ConsensusMetaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMeta(entity: ConsensusMetaEntity)

    @Query("SELECT * FROM safety_signing_state WHERE chainId = :chainId LIMIT 1")
    suspend fun getSafetyState(chainId: String): SafetySigningStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSafetyState(entity: SafetySigningStateEntity)

    @Query("SELECT * FROM validator_set_entries ORDER BY validatorId ASC")
    suspend fun getAllValidators(): List<ValidatorEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertValidators(entries: List<ValidatorEntryEntity>)

    @Query("DELETE FROM validator_set_entries")
    suspend fun clearValidators()

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertProposal(entity: ProposalEntity): Long

    @Query("SELECT * FROM consensus_proposals WHERE blockHeight = :height ORDER BY round ASC")
    suspend fun getProposalsForHeight(height: Long): List<ProposalEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertVote(entity: VoteEntity): Long

    @Query("SELECT * FROM consensus_votes WHERE blockHeight = :height ORDER BY round ASC")
    suspend fun getVotesForHeight(height: Long): List<VoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCommitCertificate(entity: CommitCertificateEntity)

    @Query("SELECT * FROM commit_certificates WHERE blockHeight = :height LIMIT 1")
    suspend fun getCommitCertificateByHeight(height: Long): CommitCertificateEntity?

    @Query("SELECT * FROM commit_certificates ORDER BY blockHeight DESC LIMIT 1")
    suspend fun getLatestCommitCertificate(): CommitCertificateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEquivocationEvidence(entity: EquivocationEvidenceEntity)

    @Query("SELECT * FROM equivocation_evidence ORDER BY detectedAtMs DESC")
    suspend fun getAllEquivocationEvidence(): List<EquivocationEvidenceEntity>

    @Transaction
    suspend fun replaceValidatorsAtomically(entries: List<ValidatorEntryEntity>) {
        clearValidators()
        if (entries.isNotEmpty()) {
            upsertValidators(entries)
        }
    }

    @Transaction
    suspend fun finalizeBlockAtomically(
        certificate: CommitCertificateEntity,
        meta: ConsensusMetaEntity,
        safety: SafetySigningStateEntity
    ) {
        upsertCommitCertificate(certificate)
        upsertMeta(meta)
        upsertSafetyState(safety)
    }
}

@Database(
    entities = [
        ConsensusMetaEntity::class,
        SafetySigningStateEntity::class,
        ValidatorEntryEntity::class,
        ProposalEntity::class,
        VoteEntity::class,
        CommitCertificateEntity::class,
        EquivocationEvidenceEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ConsensusDatabase : RoomDatabase() {
    abstract fun consensusDao(): ConsensusDao

    companion object {
        fun build(
            context: Context,
            dbName: String = "nmd_consensus_state.db",
            inMemory: Boolean = false
        ): ConsensusDatabase {
            val builder = if (inMemory) {
                Room.inMemoryDatabaseBuilder(context.applicationContext, ConsensusDatabase::class.java)
            } else {
                Room.databaseBuilder(context.applicationContext, ConsensusDatabase::class.java, dbName)
            }
            return builder.build()
        }
    }
}

interface ConsensusStorage : Closeable {
    suspend fun getMeta(chainId: String): ConsensusMetaState?
    suspend fun saveMeta(meta: ConsensusMetaState)
    suspend fun getSafetyState(chainId: String): SafetySigningState?
    suspend fun saveSafetyState(state: SafetySigningState)
    suspend fun getValidators(): List<ValidatorInfo>
    suspend fun saveValidators(validators: List<ValidatorInfo>)
    suspend fun saveProposal(proposal: BlockProposal)
    suspend fun getProposalsForHeight(height: Long): List<BlockProposal>
    suspend fun saveVote(vote: ConsensusVote)
    suspend fun getVotesForHeight(height: Long): List<ConsensusVote>
    suspend fun saveCommitCertificate(certificate: CommitCertificate)
    suspend fun getCommitCertificate(height: Long): CommitCertificate?
    suspend fun getLatestCommitCertificate(): CommitCertificate?
    suspend fun finalizeHeightAtomically(
        certificate: CommitCertificate,
        nextMeta: ConsensusMetaState,
        resetSafety: SafetySigningState
    )
    suspend fun saveEquivocationEvidence(evidence: EquivocationEvidence)
    suspend fun getAllEquivocationEvidence(): List<EquivocationEvidence>
}

class RoomConsensusStorage(
    context: Context,
    dbName: String = "nmd_consensus_state.db",
    inMemory: Boolean = false,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : ConsensusStorage {

    private val db: ConsensusDatabase = ConsensusDatabase.build(context, dbName, inMemory)
    private val dao = db.consensusDao()

    override suspend fun getMeta(chainId: String): ConsensusMetaState? = withContext(ioDispatcher) {
        dao.getMeta(chainId)?.toDomain()
    }

    override suspend fun saveMeta(meta: ConsensusMetaState) = withContext(ioDispatcher) {
        dao.upsertMeta(
            ConsensusMetaEntity(
                chainId = meta.chainId,
                currentHeight = meta.currentHeight,
                currentRound = meta.currentRound,
                phase = meta.phase.name,
                validatorSetHash = meta.validatorSetHash,
                latestFinalizedHeight = meta.latestFinalizedHeight,
                latestFinalizedHash = meta.latestFinalizedHash,
                latestFinalizedTimestampMs = meta.latestFinalizedTimestampMs,
                updatedAtMs = meta.updatedAtMs
            )
        )
    }

    override suspend fun getSafetyState(chainId: String): SafetySigningState? = withContext(ioDispatcher) {
        dao.getSafetyState(chainId)?.toDomain()
    }

    override suspend fun saveSafetyState(state: SafetySigningState) = withContext(ioDispatcher) {
        dao.upsertSafetyState(state.toEntity())
    }

    override suspend fun getValidators(): List<ValidatorInfo> = withContext(ioDispatcher) {
        dao.getAllValidators().mapNotNull { ValidatorInfo.fromJsonObject(JSONObject(it.validatorJson)) }
    }

    override suspend fun saveValidators(validators: List<ValidatorInfo>) = withContext(ioDispatcher) {
        val now = System.currentTimeMillis()
        val entities = validators.map {
            ValidatorEntryEntity(
                validatorId = it.validatorId,
                validatorJson = it.toJsonObject().toString(),
                updatedAtMs = now
            )
        }
        dao.replaceValidatorsAtomically(entities)
    }

    override suspend fun saveProposal(proposal: BlockProposal) = withContext(ioDispatcher) {
        val key = "${proposal.blockHeight}:${proposal.round}:${proposal.proposerId}:${proposal.proposedBlockHash.lowercase()}"
        dao.insertProposal(
            ProposalEntity(
                compositeKey = key,
                blockHeight = proposal.blockHeight,
                round = proposal.round,
                proposerId = proposal.proposerId,
                proposedBlockHash = proposal.proposedBlockHash.lowercase(),
                proposalJson = proposal.toJson(includeBlockBody = false),
                receivedAtMs = System.currentTimeMillis()
            )
        )
        Unit
    }

    override suspend fun getProposalsForHeight(height: Long): List<BlockProposal> = withContext(ioDispatcher) {
        dao.getProposalsForHeight(height).mapNotNull { BlockProposal.fromJson(it.proposalJson) }
    }

    override suspend fun saveVote(vote: ConsensusVote) = withContext(ioDispatcher) {
        val key = "${vote.blockHeight}:${vote.round}:${vote.votePhase.name}:${vote.validatorId}:${vote.proposedBlockHash.lowercase()}"
        dao.insertVote(
            VoteEntity(
                compositeKey = key,
                blockHeight = vote.blockHeight,
                round = vote.round,
                votePhase = vote.votePhase.name,
                validatorId = vote.validatorId,
                proposedBlockHash = vote.proposedBlockHash.lowercase(),
                voteJson = vote.toJson(),
                receivedAtMs = System.currentTimeMillis()
            )
        )
        Unit
    }

    override suspend fun getVotesForHeight(height: Long): List<ConsensusVote> = withContext(ioDispatcher) {
        dao.getVotesForHeight(height).mapNotNull { ConsensusVote.fromJson(it.voteJson) }
    }

    override suspend fun saveCommitCertificate(certificate: CommitCertificate) = withContext(ioDispatcher) {
        dao.upsertCommitCertificate(certificate.toEntity())
    }

    override suspend fun getCommitCertificate(height: Long): CommitCertificate? = withContext(ioDispatcher) {
        dao.getCommitCertificateByHeight(height)?.let { CommitCertificate.fromJson(it.certificateJson) }
    }

    override suspend fun getLatestCommitCertificate(): CommitCertificate? = withContext(ioDispatcher) {
        dao.getLatestCommitCertificate()?.let { CommitCertificate.fromJson(it.certificateJson) }
    }

    override suspend fun finalizeHeightAtomically(
        certificate: CommitCertificate,
        nextMeta: ConsensusMetaState,
        resetSafety: SafetySigningState
    ) = withContext(ioDispatcher) {
        dao.finalizeBlockAtomically(
            certificate = certificate.toEntity(),
            meta = ConsensusMetaEntity(
                chainId = nextMeta.chainId,
                currentHeight = nextMeta.currentHeight,
                currentRound = nextMeta.currentRound,
                phase = nextMeta.phase.name,
                validatorSetHash = nextMeta.validatorSetHash,
                latestFinalizedHeight = nextMeta.latestFinalizedHeight,
                latestFinalizedHash = nextMeta.latestFinalizedHash,
                latestFinalizedTimestampMs = nextMeta.latestFinalizedTimestampMs,
                updatedAtMs = nextMeta.updatedAtMs
            ),
            safety = resetSafety.toEntity()
        )
    }

    override suspend fun saveEquivocationEvidence(evidence: EquivocationEvidence) = withContext(ioDispatcher) {
        dao.upsertEquivocationEvidence(
            EquivocationEvidenceEntity(
                evidenceId = evidence.evidenceId,
                chainId = evidence.chainId,
                blockHeight = evidence.blockHeight,
                round = evidence.round,
                validatorId = evidence.validatorId,
                evidenceType = evidence.evidenceType.name,
                firstConflictingPayloadJson = evidence.firstConflictingPayloadJson,
                secondConflictingPayloadJson = evidence.secondConflictingPayloadJson,
                firstHash = evidence.firstHash,
                secondHash = evidence.secondHash,
                detectedAtMs = evidence.detectedAtMs,
                verifiedCryptographically = evidence.verifiedCryptographically
            )
        )
    }

    override suspend fun getAllEquivocationEvidence(): List<EquivocationEvidence> = withContext(ioDispatcher) {
        dao.getAllEquivocationEvidence().map { it.toDomain() }
    }

    override fun close() {
        db.close()
    }

    private fun SafetySigningState.toEntity() = SafetySigningStateEntity(
        chainId = chainId,
        lastSignedHeight = lastSignedHeight,
        lastSignedRound = lastSignedRound,
        lastPrevoteRound = lastPrevoteRound,
        lastPrevoteHash = lastPrevoteHash,
        lastPrecommitRound = lastPrecommitRound,
        lastPrecommitHash = lastPrecommitHash,
        lockedRound = lockedRound,
        lockedBlockHash = lockedBlockHash,
        validRound = validRound,
        validBlockHash = validBlockHash,
        updatedAtMs = updatedAtMs
    )

    private fun CommitCertificate.toEntity() = CommitCertificateEntity(
        blockHeight = blockHeight,
        round = round,
        blockHash = blockHash.lowercase(),
        certificateJson = toJson(),
        finalizedAtMs = finalizedAtMs
    )
}
