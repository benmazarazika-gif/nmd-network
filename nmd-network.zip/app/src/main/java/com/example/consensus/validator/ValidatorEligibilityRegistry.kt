package com.example.consensus.validator

import com.example.consensus.config.ConsensusConfig
import com.example.consensus.crypto.ConsensusCryptoSigner
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ValidatorAvailability
import com.example.consensus.model.ValidatorHistoryMetadata
import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorSetSnapshot
import com.example.consensus.model.ValidatorStatus
import com.example.consensus.quorum.QuorumCalculator
import com.example.consensus.quorum.QuorumInfo
import com.example.data.DeviceTelemetry
import java.util.concurrent.ConcurrentHashMap

/**
 * Extensible eligibility check for future Stage 11+ governance/tokenomics rules.
 * In Stage 10, uses configured permissioned validator authorization (no self-appointment).
 */
interface ValidatorEligibilityRule {
    fun checkEligibility(validator: ValidatorInfo, chainId: String, height: Long): EligibilityDecision
}

sealed class EligibilityDecision {
    data object Eligible : EligibilityDecision()
    data class Ineligible(val reason: String) : EligibilityDecision()
}

class DefaultPermissionedEligibilityRule : ValidatorEligibilityRule {
    override fun checkEligibility(
        validator: ValidatorInfo,
        chainId: String,
        height: Long
    ): EligibilityDecision {
        if (!ConsensusCryptoSigner.isValidPublicKeyHex(validator.publicKeyHex)) {
            return EligibilityDecision.Ineligible("Invalid Ed25519 public key format")
        }
        if (validator.votingPower <= 0L) {
            return EligibilityDecision.Ineligible("Validator voting power must be positive")
        }
        return when (validator.status) {
            ValidatorStatus.ACTIVE -> EligibilityDecision.Eligible
            ValidatorStatus.STANDBY -> EligibilityDecision.Ineligible("Validator is STANDBY and not yet activated")
            ValidatorStatus.SUSPENDED -> EligibilityDecision.Ineligible("Validator is suspended: ${validator.suspensionReason ?: "verified fault"}")
            ValidatorStatus.OFFLINE -> EligibilityDecision.Ineligible("Validator is administratively marked OFFLINE")
            ValidatorStatus.SLASHED_PENDING_REVIEW -> EligibilityDecision.Ineligible("Validator flagged for verified equivocation")
        }
    }
}

/**
 * Optional hook for future Stage 11+ stake or decentralized registry weight rules.
 */
interface FutureTokenomicsEligibilityHook {
    fun evaluateFutureEligibility(validatorId: String, height: Long): Boolean = true
}

data class MobileResourceEvaluation(
    val shouldPauseActiveSigning: Boolean,
    val recommendedAvailability: ValidatorAvailability,
    val reason: String? = null
)

/**
 * Evaluates real Android battery/memory/connectivity constraints to prevent excessive
 * battery drain or crash-loops while keeping lightweight verification non-blocking.
 */
object MobileParticipationPolicy {
    fun evaluateDevice(telemetry: DeviceTelemetry, config: ConsensusConfig): MobileResourceEvaluation {
        if (telemetry.networkType == "Unavailable") {
            return MobileResourceEvaluation(
                shouldPauseActiveSigning = true,
                recommendedAvailability = ValidatorAvailability.DISCONNECTED,
                reason = "Network unavailable — offline recovery standby"
            )
        }
        val battery = telemetry.batteryPercent
        val charging = telemetry.isCharging ?: false
        if (config.respectLowBatteryPause && battery != null && battery <= config.batteryLowPauseThresholdPercent && !charging) {
            return MobileResourceEvaluation(
                shouldPauseActiveSigning = true,
                recommendedAvailability = ValidatorAvailability.LOW_BATTERY_PAUSED,
                reason = "Low uncharging battery ($battery% <= ${config.batteryLowPauseThresholdPercent}%)"
            )
        }
        if (telemetry.isLowRam) {
            return MobileResourceEvaluation(
                shouldPauseActiveSigning = false,
                recommendedAvailability = ValidatorAvailability.BACKGROUND_THROTTLED,
                reason = "Low system RAM detected — throttled queue mode"
            )
        }
        return MobileResourceEvaluation(
            shouldPauseActiveSigning = false,
            recommendedAvailability = ValidatorAvailability.ONLINE_AVAILABLE,
            reason = null
        )
    }
}

/**
 * Manages the authorized validator registry separately from ordinary Stage 7 P2P peers.
 *
 * Security invariants:
 * - Unregistered P2P peers advertising themselves cannot become active validators via network messages.
 * - Deterministic proposer selection operates on lexicographically sorted [ValidatorInfo] IDs of ACTIVE
 *   validators so partitioned or temporarily unavailable devices never diverge on who is proposer.
 */
class ValidatorEligibilityRegistry(
    private val config: ConsensusConfig,
    private val signer: ConsensusCryptoSigner = ConsensusCryptoSigner(),
    private val eligibilityRule: ValidatorEligibilityRule = DefaultPermissionedEligibilityRule()
) {
    private val validatorsById = ConcurrentHashMap<String, ValidatorInfo>()

    fun registerAuthorizedValidator(
        publicKeyHex: String,
        displayName: String,
        nodeId: String = "",
        votingPower: Long = 1L,
        initialStatus: ValidatorStatus = ValidatorStatus.ACTIVE,
        initialAvailability: ValidatorAvailability = ValidatorAvailability.ONLINE_AVAILABLE,
        registeredAtMs: Long = System.currentTimeMillis()
    ): ValidatorInfo? {
        if (validatorsById.size >= config.maxActiveValidators) return null
        val derivedValId = signer.deriveValidatorIdFromHex(publicKeyHex) ?: return null
        val cleanPubHex = publicKeyHex.trim().lowercase()
        val resolvedNodeId = nodeId.ifBlank {
            signer.cryptoProvider.deriveNodeId(signer.cryptoProvider.fromHex(cleanPubHex))
        }
        val info = ValidatorInfo(
            validatorId = derivedValId,
            nodeId = resolvedNodeId,
            publicKeyHex = cleanPubHex,
            displayName = displayName.trim().ifBlank { derivedValId.take(16) },
            votingPower = votingPower.coerceAtLeast(1L),
            status = initialStatus,
            availability = initialAvailability,
            registeredAtMs = registeredAtMs,
            lastActiveAtMs = registeredAtMs
        )
        validatorsById[derivedValId] = info
        return info
    }

    fun loadRestoredValidators(list: List<ValidatorInfo>) {
        validatorsById.clear()
        list.forEach { v ->
            if (signer.verifyValidatorIdMatchesPublicKey(v.validatorId, v.publicKeyHex)) {
                validatorsById[v.validatorId] = v
            }
        }
    }

    fun isRegisteredActiveValidator(validatorId: String, height: Long): Boolean {
        val v = validatorsById[validatorId] ?: return false
        return eligibilityRule.checkEligibility(v, config.chainId, height) is EligibilityDecision.Eligible
    }

    fun getValidator(validatorId: String): ValidatorInfo? = validatorsById[validatorId]

    fun getAllValidators(): List<ValidatorInfo> =
        validatorsById.values.sortedBy { it.validatorId }

    fun getActiveValidators(height: Long = 0L): List<ValidatorInfo> =
        validatorsById.values
            .filter { eligibilityRule.checkEligibility(it, config.chainId, height) is EligibilityDecision.Eligible }
            .sortedBy { it.validatorId }

    fun updateAvailability(
        validatorId: String,
        availability: ValidatorAvailability,
        seenAtMs: Long = System.currentTimeMillis()
    ): ValidatorInfo? {
        val current = validatorsById[validatorId] ?: return null
        val updated = current.copy(
            availability = availability,
            lastActiveAtMs = if (availability == ValidatorAvailability.ONLINE_AVAILABLE) seenAtMs else current.lastActiveAtMs
        )
        validatorsById[validatorId] = updated
        return updated
    }

    fun suspendValidator(validatorId: String, reason: String): ValidatorInfo? {
        val current = validatorsById[validatorId] ?: return null
        val updated = current.copy(
            status = ValidatorStatus.SUSPENDED,
            suspensionReason = reason
        )
        validatorsById[validatorId] = updated
        return updated
    }

    fun markSlashedPendingReview(validatorId: String, reason: String): ValidatorInfo? {
        val current = validatorsById[validatorId] ?: return null
        val updated = current.copy(
            status = ValidatorStatus.SLASHED_PENDING_REVIEW,
            suspensionReason = reason,
            history = current.history.copy(
                verifiedEquivocationsCount = current.history.verifiedEquivocationsCount + 1L
            )
        )
        validatorsById[validatorId] = updated
        return updated
    }

    fun reactivateValidator(validatorId: String): ValidatorInfo? {
        val current = validatorsById[validatorId] ?: return null
        val updated = current.copy(
            status = ValidatorStatus.ACTIVE,
            suspensionReason = null,
            lastActiveAtMs = System.currentTimeMillis()
        )
        validatorsById[validatorId] = updated
        return updated
    }

    fun updateStatus(
        validatorId: String,
        status: ValidatorStatus,
        nowMs: Long = System.currentTimeMillis()
    ): ValidatorInfo? {
        val current = validatorsById[validatorId] ?: return null
        val updated = current.copy(
            status = status,
            lastActiveAtMs = if (status == ValidatorStatus.ACTIVE) nowMs else current.lastActiveAtMs
        )
        validatorsById[validatorId] = updated
        return updated
    }

    fun recordProposedBlock(validatorId: String, nowMs: Long = System.currentTimeMillis()) {
        validatorsById.computeIfPresent(validatorId) { _, v ->
            v.copy(
                lastActiveAtMs = nowMs,
                history = v.history.copy(proposedBlocksCount = v.history.proposedBlocksCount + 1L)
            )
        }
    }

    fun recordPrevote(validatorId: String, nowMs: Long = System.currentTimeMillis()) {
        validatorsById.computeIfPresent(validatorId) { _, v ->
            v.copy(
                lastActiveAtMs = nowMs,
                history = v.history.copy(validPrevotesCount = v.history.validPrevotesCount + 1L)
            )
        }
    }

    fun recordPrecommit(validatorId: String, nowMs: Long = System.currentTimeMillis()) {
        validatorsById.computeIfPresent(validatorId) { _, v ->
            v.copy(
                lastActiveAtMs = nowMs,
                history = v.history.copy(validPrecommitsCount = v.history.validPrecommitsCount + 1L)
            )
        }
    }

    fun recordRoundMissedByOfflineValidators(activeParticipants: Set<String>) {
        validatorsById.keys.forEach { id ->
            if (!activeParticipants.contains(id)) {
                validatorsById.computeIfPresent(id) { _, v ->
                    if (v.isAuthorizedActive) {
                        v.copy(history = v.history.copy(missedRoundsCount = v.history.missedRoundsCount + 1L))
                    } else v
                }
            }
        }
    }

    fun buildSnapshot(height: Long): ValidatorSetSnapshot {
        val all = getAllValidators()
        val snapshotHash = signer.computeValidatorSetHash(config.chainId, all)
        return ValidatorSetSnapshot(
            chainId = config.chainId,
            epochOrHeight = height,
            validators = all,
            snapshotHash = snapshotHash
        )
    }

    fun calculateQuorum(height: Long = 0L): QuorumInfo {
        val activeCount = getActiveValidators(height).size
        return QuorumCalculator.calculate(activeCount, config.minValidatorsForBft)
    }

    /**
     * Deterministic round-robin proposer schedule over sorted ACTIVE validators.
     * Ensures independent devices without synchronized connectivity still agree on proposer identity.
     */
    fun selectDeterministicProposer(
        snapshot: ValidatorSetSnapshot,
        height: Long,
        round: Int
    ): ValidatorInfo? {
        val active = snapshot.activeValidatorsSorted
        if (active.isEmpty() || height < 0L || round < 0) return null
        val index = ((height + round.toLong()) % active.size.toLong()).toInt()
        return active[index]
    }
}
