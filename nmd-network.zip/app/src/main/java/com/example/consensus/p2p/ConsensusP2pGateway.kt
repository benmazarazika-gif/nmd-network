package com.example.consensus.p2p

import android.util.Log
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.engine.ConsensusEngine
import com.example.consensus.engine.ProposalSubmissionResult
import com.example.consensus.engine.VoteSubmissionResult
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusErrorCode
import com.example.consensus.model.ConsensusVote
import com.example.consensus.model.RoundChangeMessage
import com.example.consensus.model.ValidatorStatusAnnouncement
import com.example.consensus.validation.ConsensusValidationOutcome
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.session.PeerSession
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

sealed class ConsensusInboundResult {
    data class Accepted(val messageType: P2pMessageType, val details: String) : ConsensusInboundResult()
    data class Duplicate(val reason: String) : ConsensusInboundResult()
    data class Rejected(
        val code: ConsensusErrorCode,
        val reason: String,
        val penalizedPeer: Boolean = false
    ) : ConsensusInboundResult()
}

/**
 * Bounded per-peer sliding-window rate limiter protecting smartphones from consensus message floods.
 */
class ConsensusPeerRateLimiter(
    private val maxMessagesPerWindow: Int = 120,
    private val windowMs: Long = 60_000L
) {
    private val timestamps = ConcurrentHashMap<String, ArrayDeque<Long>>()

    fun allow(peerId: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        val queue = timestamps.getOrPut(peerId) { ArrayDeque() }
        synchronized(queue) {
            while (queue.isNotEmpty() && nowMs - queue.first() > windowMs) {
                queue.removeFirst()
            }
            if (queue.size >= maxMessagesPerWindow) return false
            queue.addLast(nowMs)
            return true
        }
    }
}

/**
 * Stage 10 Consensus P2P Gateway built directly on Stage 6 messaging and Stage 7 peer registry.
 *
 * Security invariants:
 * - Never trusts unauthenticated sessions or unsigned peer messages.
 * - Enforces bounded payload limits ([ConsensusConfig.maxConsensusMessageBytes]) and bounded dedup cache.
 * - Prevents self-appointment: a peer advertising [P2pMessageType.VALIDATOR_STATUS] NEVER gains validator authority.
 * - Penalizes peer reputation ONLY after cryptographically verifiable malformed/forged payloads or verified equivocation.
 */
class ConsensusP2pGateway(
    private val consensusEngine: ConsensusEngine,
    private val peerRegistry: DistributedPeerRegistry? = null,
    private val config: ConsensusConfig = consensusEngine.config,
    private val rateLimiter: ConsensusPeerRateLimiter = ConsensusPeerRateLimiter(config.maxPeerMessagesPerMinute)
) {
    companion object {
        private const val TAG = "ConsensusP2pGateway"
        private const val MAX_DEDUP_CACHE_ENTRIES = 1_000
    }

    @Volatile
    var authenticatedSessionsProvider: (() -> List<PeerSession>)? = null

    @Volatile
    var sendConsensusMessageToSession: (suspend (sessionId: String, messageType: P2pMessageType, payload: String) -> Result<Unit>)? = null

    private val seenMessageDigests = Collections.synchronizedSet(object : LinkedHashSet<String>() {
        override fun add(element: String): Boolean {
            if (size >= MAX_DEDUP_CACHE_ENTRIES) {
                val it = iterator()
                if (it.hasNext()) {
                    it.next()
                    it.remove()
                }
            }
            return super.add(element)
        }
    })

    suspend fun handleIncomingConsensusMessage(
        fromSession: PeerSession,
        message: P2pMessage,
        nowMs: Long = System.currentTimeMillis()
    ): ConsensusInboundResult {
        if (!fromSession.isTrusted) {
            return ConsensusInboundResult.Rejected(
                code = ConsensusErrorCode.UNAUTHORIZED_VALIDATOR,
                reason = "Rejected consensus message from unauthenticated session ${fromSession.peerId}",
                penalizedPeer = false
            )
        }

        val payloadBytes = message.payload.toByteArray(Charsets.UTF_8)
        if (payloadBytes.size > config.maxConsensusMessageBytes) {
            peerRegistry?.recordInvalidBehavior(fromSession.peerId, penalty = 10)
            return ConsensusInboundResult.Rejected(
                code = ConsensusErrorCode.PAYLOAD_TOO_LARGE,
                reason = "Consensus payload exceeds ${config.maxConsensusMessageBytes}B limit",
                penalizedPeer = true
            )
        }

        if (!rateLimiter.allow(fromSession.peerId, nowMs)) {
            peerRegistry?.recordInvalidBehavior(fromSession.peerId, penalty = 10)
            return ConsensusInboundResult.Rejected(
                code = ConsensusErrorCode.RATE_LIMITED,
                reason = "Consensus peer ${fromSession.peerId} exceeded message rate limit",
                penalizedPeer = true
            )
        }

        val dedupKey = "${message.messageType.name}:${message.messageId}:${message.payload.hashCode()}"
        if (!seenMessageDigests.add(dedupKey)) {
            return ConsensusInboundResult.Duplicate("Suppressed duplicate ${message.messageType.name}")
        }

        return when (message.messageType) {
            P2pMessageType.BLOCK_PROPOSAL -> handleProposal(fromSession, message.payload, nowMs)
            P2pMessageType.CONSENSUS_PREVOTE,
            P2pMessageType.CONSENSUS_PRECOMMIT -> handleVote(fromSession, message.messageType, message.payload, nowMs)
            P2pMessageType.CONSENSUS_COMMIT -> handleCommitCertificate(fromSession, message.payload, nowMs)
            P2pMessageType.ROUND_CHANGE -> handleRoundChange(fromSession, message.payload, nowMs)
            P2pMessageType.VALIDATOR_STATUS -> handleValidatorStatus(fromSession, message.payload, nowMs)
            else -> ConsensusInboundResult.Rejected(
                ConsensusErrorCode.MALFORMED_MESSAGE,
                "Unsupported consensus message type: ${message.messageType.name}"
            )
        }
    }

    suspend fun broadcastProposal(proposal: BlockProposal): Int {
        return broadcastRaw(P2pMessageType.BLOCK_PROPOSAL, proposal.toJson())
    }

    suspend fun broadcastVote(vote: ConsensusVote): Int {
        val msgType = if (vote.votePhase == com.example.consensus.model.VotePhase.PREVOTE) {
            P2pMessageType.CONSENSUS_PREVOTE
        } else {
            P2pMessageType.CONSENSUS_PRECOMMIT
        }
        return broadcastRaw(msgType, vote.toJson())
    }

    suspend fun broadcastCommitCertificate(certificate: CommitCertificate): Int {
        return broadcastRaw(P2pMessageType.CONSENSUS_COMMIT, certificate.toJson())
    }

    suspend fun broadcastRoundChange(roundChange: RoundChangeMessage): Int {
        return broadcastRaw(P2pMessageType.ROUND_CHANGE, roundChange.toJson())
    }

    suspend fun broadcastValidatorStatus(status: ValidatorStatusAnnouncement): Int {
        return broadcastRaw(P2pMessageType.VALIDATOR_STATUS, status.toJson())
    }

    private suspend fun broadcastRaw(type: P2pMessageType, payload: String): Int {
        val sessions = authenticatedSessionsProvider?.invoke()?.filter { it.isTrusted }.orEmpty()
        val sender = sendConsensusMessageToSession ?: return 0
        var delivered = 0
        for (s in sessions) {
            val res = try {
                sender(s.sessionId, type, payload)
            } catch (_: Exception) {
                Result.failure(Unit.let { Exception("Send error") })
            }
            if (res.isSuccess) delivered++
        }
        return delivered
    }

    private suspend fun handleProposal(
        session: PeerSession,
        raw: String,
        nowMs: Long
    ): ConsensusInboundResult {
        val proposal = BlockProposal.fromJson(raw)
            ?: return rejectAndPenalizeMalformed(session.peerId, "Malformed BLOCK_PROPOSAL JSON")
        return when (val res = consensusEngine.submitProposal(proposal, nowMs)) {
            is ProposalSubmissionResult.Accepted ->
                ConsensusInboundResult.Accepted(P2pMessageType.BLOCK_PROPOSAL, "Accepted proposal h=${proposal.blockHeight}, r=${proposal.round}")
            is ProposalSubmissionResult.Duplicate ->
                ConsensusInboundResult.Duplicate(res.reason)
            is ProposalSubmissionResult.Rejected -> {
                val shouldPenalize = res.equivocationEvidence?.verifiedCryptographically == true ||
                    res.code == ConsensusErrorCode.INVALID_PROPOSAL_SIGNATURE ||
                    res.code == ConsensusErrorCode.VALIDATOR_KEY_MISMATCH
                if (shouldPenalize) {
                    peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 25)
                }
                ConsensusInboundResult.Rejected(res.code, res.reason, penalizedPeer = shouldPenalize)
            }
        }
    }

    private suspend fun handleVote(
        session: PeerSession,
        type: P2pMessageType,
        raw: String,
        nowMs: Long
    ): ConsensusInboundResult {
        val vote = ConsensusVote.fromJson(raw)
            ?: return rejectAndPenalizeMalformed(session.peerId, "Malformed ${type.name} JSON")
        return when (val res = consensusEngine.submitVote(vote, nowMs)) {
            is VoteSubmissionResult.Accepted ->
                ConsensusInboundResult.Accepted(type, "Accepted ${vote.votePhase.name} h=${vote.blockHeight}, r=${vote.round}")
            is VoteSubmissionResult.Duplicate ->
                ConsensusInboundResult.Duplicate(res.reason)
            is VoteSubmissionResult.Rejected -> {
                val shouldPenalize = res.equivocationEvidence?.verifiedCryptographically == true ||
                    res.code == ConsensusErrorCode.INVALID_VOTE_SIGNATURE ||
                    res.code == ConsensusErrorCode.VALIDATOR_KEY_MISMATCH
                if (shouldPenalize) {
                    peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 25)
                }
                ConsensusInboundResult.Rejected(res.code, res.reason, penalizedPeer = shouldPenalize)
            }
        }
    }

    private suspend fun handleCommitCertificate(
        session: PeerSession,
        raw: String,
        nowMs: Long
    ): ConsensusInboundResult {
        val cert = CommitCertificate.fromJson(raw)
            ?: return rejectAndPenalizeMalformed(session.peerId, "Malformed CONSENSUS_COMMIT JSON")
        return when (val res = consensusEngine.applyVerifiedCommitCertificate(cert, nowMs = nowMs)) {
            ConsensusValidationOutcome.Valid ->
                ConsensusInboundResult.Accepted(P2pMessageType.CONSENSUS_COMMIT, "Finalized h=${cert.blockHeight} via CommitCertificate")
            is ConsensusValidationOutcome.Invalid -> {
                val penalize = res.code == ConsensusErrorCode.INVALID_VOTE_SIGNATURE ||
                    res.code == ConsensusErrorCode.INVALID_COMMIT_CERTIFICATE
                if (penalize) {
                    peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 25)
                }
                ConsensusInboundResult.Rejected(res.code, res.reason, penalizedPeer = penalize)
            }
        }
    }

    private suspend fun handleRoundChange(
        session: PeerSession,
        raw: String,
        nowMs: Long
    ): ConsensusInboundResult {
        val msg = RoundChangeMessage.fromJson(raw)
            ?: return rejectAndPenalizeMalformed(session.peerId, "Malformed ROUND_CHANGE JSON")
        return when (val res = consensusEngine.processRoundChangeMessage(msg, nowMs)) {
            ConsensusValidationOutcome.Valid ->
                ConsensusInboundResult.Accepted(P2pMessageType.ROUND_CHANGE, "Verified ROUND_CHANGE from ${msg.validatorId}")
            is ConsensusValidationOutcome.Invalid -> {
                val penalize = res.code == ConsensusErrorCode.INVALID_VOTE_SIGNATURE
                if (penalize) peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 15)
                ConsensusInboundResult.Rejected(res.code, res.reason, penalizedPeer = penalize)
            }
        }
    }

    private suspend fun handleValidatorStatus(
        session: PeerSession,
        raw: String,
        nowMs: Long
    ): ConsensusInboundResult {
        val statusMsg = ValidatorStatusAnnouncement.fromJson(raw)
            ?: return rejectAndPenalizeMalformed(session.peerId, "Malformed VALIDATOR_STATUS JSON")
        // Verify signature & confirm validator is ALREADY authorized (never self-appoint via P2P!)
        val snapshot = consensusEngine.getCurrentValidatorSetSnapshot()
        val authorized = snapshot.findValidator(statusMsg.validatorId)
            ?: return ConsensusInboundResult.Rejected(
                ConsensusErrorCode.UNAUTHORIZED_VALIDATOR,
                "Rejected self-advertised peer ${statusMsg.validatorId}: not an authorized validator",
                penalizedPeer = false
            )
        if (!authorized.publicKeyHex.equals(statusMsg.publicKeyHex, ignoreCase = true) ||
            !consensusEngine.signer.verifyValidatorStatusSignature(statusMsg)
        ) {
            peerRegistry?.recordInvalidBehavior(session.peerId, penalty = 20)
            return ConsensusInboundResult.Rejected(
                ConsensusErrorCode.INVALID_VOTE_SIGNATURE,
                "Invalid VALIDATOR_STATUS Ed25519 signature",
                penalizedPeer = true
            )
        }
        consensusEngine.updateValidatorAvailability(statusMsg.validatorId, statusMsg.availability, nowMs)
        return ConsensusInboundResult.Accepted(
            P2pMessageType.VALIDATOR_STATUS,
            "Updated availability=${statusMsg.availability.name} for ${statusMsg.validatorId}"
        )
    }

    private fun rejectAndPenalizeMalformed(peerId: String, reason: String): ConsensusInboundResult.Rejected {
        Log.w(TAG, "Peer $peerId sent malformed consensus payload: $reason")
        peerRegistry?.recordInvalidBehavior(peerId, penalty = 15)
        return ConsensusInboundResult.Rejected(
            ConsensusErrorCode.MALFORMED_MESSAGE,
            reason,
            penalizedPeer = true
        )
    }
}
