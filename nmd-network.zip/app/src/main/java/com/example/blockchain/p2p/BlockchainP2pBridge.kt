package com.example.blockchain.p2p

import android.util.Log
import com.example.blockchain.manager.BlockIngestionResult
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerCapability
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.model.PeerEndpoint
import org.json.JSONObject

data class BlockSyncPeer(
    val peerId: String,
    val endpoint: PeerEndpoint,
    val isConnected: Boolean,
    val isAuthenticated: Boolean,
    val reputationScore: Int
)

data class ChainStatusSummary(
    val chainId: String,
    val genesisHash: String,
    val height: Long,
    val latestBlockHash: String,
    val timestamp: Long
) {
    fun toJson(): String = JSONObject().apply {
        put("chain_id", chainId)
        put("genesis_hash", genesisHash)
        put("height", height)
        put("latest_block_hash", latestBlockHash)
        put("timestamp", timestamp)
    }.toString()

    companion object {
        fun fromJson(jsonStr: String): ChainStatusSummary? = try {
            val j = JSONObject(jsonStr)
            ChainStatusSummary(
                chainId = j.getString("chain_id"),
                genesisHash = j.getString("genesis_hash"),
                height = j.getLong("height"),
                latestBlockHash = j.getString("latest_block_hash"),
                timestamp = j.getLong("timestamp")
            )
        } catch (_: Exception) {
            null
        }
    }
}

data class MissingBlockRequest(
    val chainId: String,
    val fromHeight: Long,
    val maxBlocks: Int = 16
) {
    fun toJson(): String = JSONObject().apply {
        put("chain_id", chainId)
        put("from_height", fromHeight)
        put("max_blocks", maxBlocks)
    }.toString()
}

/**
 * Clean Stage 8 P2P integration interface connecting Blockchain Core with Stage 7 Discovery.
 *
 * Strictly enforces Zero-Trust: blocks arriving from authenticated peers are NEVER
 * trusted automatically; every incoming block passes through full cryptographic & structural validation.
 * Full chain synchronization belongs to later stages.
 */
interface BlockchainPeerSyncGateway {
    fun identifySyncCapablePeers(): List<BlockSyncPeer>
    fun getLocalChainStatus(): ChainStatusSummary?
    fun createMissingBlocksRequest(fromHeight: Long, maxBlocks: Int = 16): MissingBlockRequest
    suspend fun handleIncomingBlockPayload(fromPeerId: String, rawBlockJson: String): BlockIngestionResult
}

class DefaultBlockchainPeerSyncGateway(
    private val blockchainManager: BlockchainManager,
    private val peerRegistry: DistributedPeerRegistry
) : BlockchainPeerSyncGateway {

    companion object {
        private const val TAG = "BlockchainP2pGateway"
    }

    override fun identifySyncCapablePeers(): List<BlockSyncPeer> {
        return peerRegistry.peers.value
            .filter { record ->
                record.isAuthenticated &&
                    record.isConnected &&
                    (record.capabilities.contains(PeerCapability.BLOCK_SYNC) ||
                        record.capabilities.contains(PeerCapability.STAGE7_DISCOVERY))
            }
            .map { record: PeerRegistryRecord ->
                BlockSyncPeer(
                    peerId = record.peerId,
                    endpoint = record.endpoint,
                    isConnected = record.isConnected,
                    isAuthenticated = record.isAuthenticated,
                    reputationScore = record.reputationScore
                )
            }
    }

    override fun getLocalChainStatus(): ChainStatusSummary? {
        val state = blockchainManager.chainState.value
        if (!state.isInitialized) return null
        return ChainStatusSummary(
            chainId = state.chainId,
            genesisHash = state.genesisHash,
            height = state.currentHeight,
            latestBlockHash = state.latestBlockHash,
            timestamp = state.latestBlockTimestamp
        )
    }

    override fun createMissingBlocksRequest(fromHeight: Long, maxBlocks: Int): MissingBlockRequest {
        val boundedMax = maxBlocks.coerceIn(1, 32)
        return MissingBlockRequest(
            chainId = blockchainManager.config.chainId,
            fromHeight = fromHeight.coerceAtLeast(0L),
            maxBlocks = boundedMax
        )
    }

    override suspend fun handleIncomingBlockPayload(
        fromPeerId: String,
        rawBlockJson: String
    ): BlockIngestionResult {
        // Zero-Trust: check peer is live-authenticated, and still validate block unconditionally
        val peer = peerRegistry.getPeer(fromPeerId)
        if (peer == null || !peer.isAuthenticated) {
            return BlockIngestionResult.Rejected(
                com.example.blockchain.validation.ValidationErrorCode.MALFORMED_DATA,
                "Rejected block from unauthenticated peer: $fromPeerId"
            )
        }

        val parsedBlock = Block.fromStorageJson(rawBlockJson)
        if (parsedBlock == null) {
            Log.w(TAG, "Malformed incoming block JSON from peer $fromPeerId")
            peerRegistry.recordInvalidBehavior(fromPeerId, penalty = 20)
            return BlockIngestionResult.Rejected(
                com.example.blockchain.validation.ValidationErrorCode.MALFORMED_DATA,
                "Malformed block payload JSON"
            )
        }

        val result = blockchainManager.submitIncomingBlock(parsedBlock)
        if (result is BlockIngestionResult.Rejected) {
            Log.w(TAG, "Rejected invalid block from $fromPeerId: ${result.reason}")
            peerRegistry.recordInvalidBehavior(fromPeerId, penalty = 25)
        }
        return result
    }
}
