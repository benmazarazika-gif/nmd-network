package com.example.blockchain.storage

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockHeader
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Room SQLite-backed implementation of [BlockchainStorage].
 *
 * Uses paged queries during integrity audits so the entire blockchain
 * is never materialized in RAM at once.
 */
class RoomBlockchainStorage(
    private val database: BlockchainDatabase,
    private val blockHasher: BlockHasher = BlockHasher(),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : BlockchainStorage {

    companion object {
        private const val INTEGRITY_BATCH_SIZE = 50
    }

    constructor(
        context: Context,
        dbName: String = "nmd_blockchain_core.db",
        inMemory: Boolean = false
    ) : this(
        database = if (inMemory) {
            BlockchainDatabase.buildInMemory(context)
        } else {
            BlockchainDatabase.buildPersistent(context, dbName)
        }
    )

    private val dao: BlockchainDao = database.blockchainDao()

    override suspend fun getGenesisBlock(): Block? = withContext(ioDispatcher) {
        dao.getGenesisBlock()?.toDomainBlock()
    }

    override suspend fun getBlockByHeight(height: Long): Block? = withContext(ioDispatcher) {
        dao.getBlockByHeight(height)?.toDomainBlock()
    }

    override suspend fun getBlockByHash(hash: String): Block? = withContext(ioDispatcher) {
        dao.getBlockByHash(hash.lowercase())?.toDomainBlock()
    }

    override suspend fun getLatestBlock(): Block? = withContext(ioDispatcher) {
        dao.getLatestBlock()?.toDomainBlock()
    }

    override suspend fun getBlocksRange(fromHeight: Long, limit: Int): List<Block> = withContext(ioDispatcher) {
        dao.getBlocksRange(fromHeight, limit).mapNotNull { it.toDomainBlock() }
    }

    override suspend fun getBlockCount(): Long = withContext(ioDispatcher) {
        dao.getBlockCount()
    }

    override suspend fun existsByHashOrHeight(hash: String, height: Long): Boolean = withContext(ioDispatcher) {
        dao.existsByHashOrHeight(hash.lowercase(), height)
    }

    override suspend fun getChainMetadata(): ChainMetadataEntity? = withContext(ioDispatcher) {
        dao.getMetadata()
    }

    override fun observeChainMetadata(): Flow<ChainMetadataEntity?> = dao.observeMetadata()

    override suspend fun upsertChainMetadata(metadata: ChainMetadataEntity) = withContext(ioDispatcher) {
        dao.upsertMetadata(metadata)
    }

    override suspend fun insertBlockAtomically(
        block: Block,
        metadata: ChainMetadataEntity
    ): StorageInsertResult = withContext(ioDispatcher) {
        if (dao.existsByHashOrHeight(block.hash.lowercase(), block.height)) {
            return@withContext StorageInsertResult.Duplicate(
                "Block already exists (height=${block.height}, hash=${block.displayHash})"
            )
        }
        val sizeBytes = blockHasher.computeBlockSizeBytes(block)
        val entity = BlockEntity.fromDomainBlock(block.copy(hash = block.hash.lowercase()), sizeBytes)
        return@withContext try {
            dao.insertBlockAndMetadataAtomically(entity, metadata)
            StorageInsertResult.Inserted
        } catch (e: SQLiteConstraintException) {
            StorageInsertResult.Duplicate("SQLite unique constraint rejected duplicate block: ${e.message}")
        } catch (e: Exception) {
            StorageInsertResult.Error(e.message ?: "Atomic block insertion failed")
        }
    }

    override suspend fun verifyDatabaseIntegrity(config: BlockchainConfig): IntegrityReport = withContext(ioDispatcher) {
        val issues = mutableListOf<String>()
        val totalCount = dao.getBlockCount()
        val metadata = dao.getMetadata()
        val genesis = dao.getGenesisBlock()?.toDomainBlock()

        if (totalCount == 0L || genesis == null) {
            return@withContext IntegrityReport(
                isHealthy = false,
                verifiedBlocksCount = 0L,
                expectedTipHeight = -1L,
                genesisHashMatches = false,
                issues = listOf("Genesis block missing from database")
            )
        }

        val genesisMatches = genesis.chainId == config.chainId &&
            genesis.previousHash == BlockHeader.GENESIS_PREVIOUS_HASH &&
            blockHasher.verifyBlockHash(genesis) &&
            blockHasher.verifyMerkleRoot(genesis)

        if (!genesisMatches) {
            issues.add("Genesis block integrity or chainId check failed")
        }

        var cursorHeight = 0L
        var previousBlockHash = BlockHeader.GENESIS_PREVIOUS_HASH
        var verifiedCount = 0L
        var lastHeight = -1L

        while (true) {
            val batch = dao.getBlocksRange(cursorHeight, INTEGRITY_BATCH_SIZE)
            if (batch.isEmpty()) break

            for (entity in batch) {
                val block = entity.toDomainBlock()
                if (block == null) {
                    issues.add("Corrupted JSON body at height ${entity.height}")
                    continue
                }
                if (block.height != cursorHeight) {
                    issues.add("Height gap detected: expected $cursorHeight, got ${block.height}")
                }
                if (block.height > 0 && !block.previousHash.equals(previousBlockHash, ignoreCase = true)) {
                    issues.add("Broken previousHash link at height ${block.height}")
                }
                if (!blockHasher.verifyBlockHash(block)) {
                    issues.add("Block hash mismatch at height ${block.height}")
                }
                if (!blockHasher.verifyMerkleRoot(block)) {
                    issues.add("Merkle root mismatch at height ${block.height}")
                }
                previousBlockHash = block.hash
                lastHeight = block.height
                cursorHeight++
                verifiedCount++
            }
        }

        if (metadata == null) {
            issues.add("Chain metadata row missing")
        } else if (metadata.latestHeight != lastHeight || metadata.blockCount != totalCount) {
            issues.add("Metadata out of sync with stored blocks (meta height=${metadata.latestHeight}, tip=$lastHeight)")
        }

        IntegrityReport(
            isHealthy = issues.isEmpty() && verifiedCount == totalCount,
            verifiedBlocksCount = verifiedCount,
            expectedTipHeight = lastHeight,
            genesisHashMatches = genesisMatches,
            issues = issues
        )
    }

    override suspend fun clearAll() = withContext(ioDispatcher) {
        dao.clearAllAtomically()
    }

    override fun close() {
        database.close()
    }
}
