package com.example.blockchain.economics

import com.example.blockchain.config.BlockchainParameters
import java.math.BigInteger

data class FeeAndRewardDistribution(
    val founderUnits: Long,
    val treasuryUnits: Long,
    val burnedUnits: Long,
    val validatorsPoolUnits: Long
) {
    val totalUnits: Long
        get() = founderUnits + treasuryUnits + burnedUnits + validatorsPoolUnits
}

/**
 * Stage 22 Dormant Tokenomics Engine for NMD Network.
 *
 * Economic specification (strictly dormant until `tokenIssuanceEnabled && isPublicMainnetActive`):
 * - Hard Cap Max Supply: 100,000,000,000 NMD (1e17 micro-NMD units)
 * - Genesis Pre-mine Allocation: 1,000,000,000 NMD (1% of max supply = 1e15 micro-NMD units)
 * - Remaining Mintable Supply: 99,000,000,000 NMD released ONLY after 1-year cliff over 24 years
 *   (25-year total schedule, linear block-time emission without arbitrary halving shocks)
 * - Revenue / Fee & Reward Split (sum = 100%):
 *   - 5%  Founder / Core Engineering Vesting
 *   - 15% Ecosystem & Protocol Treasury
 *   - 20% Permanent Burn
 *   - 60% Active Validators & Participatory Staking Pool
 *
 * All calculations use [BigInteger] internally so 100B NMD in 10^-6 micro-units never overflows 64-bit longs.
 */
object TokenomicsEngine {

    const val UNITS_PER_NMD: Long = 1_000_000L
    const val MAX_SUPPLY_NMD: Long = 100_000_000_000L
    const val MAX_SUPPLY_UNITS: Long = MAX_SUPPLY_NMD * UNITS_PER_NMD // 100_000_000_000_000_000L < Long.MAX_VALUE (~9.22e18)

    const val GENESIS_ALLOCATION_NMD: Long = 1_000_000_000L // 1%
    const val GENESIS_ALLOCATION_UNITS: Long = GENESIS_ALLOCATION_NMD * UNITS_PER_NMD

    const val EMISSION_SUPPLY_NMD: Long = 99_000_000_000L
    const val EMISSION_SUPPLY_UNITS: Long = EMISSION_SUPPLY_NMD * UNITS_PER_NMD

    const val CLIFF_DURATION_MS: Long = 365L * 24L * 60L * 60L * 1000L // 1 year
    const val RELEASE_DURATION_MS: Long = 24L * 365L * 24L * 60L * 60L * 1000L // 24 years (25 yrs total)

    const val SHARE_FOUNDER_PCT = 5
    const val SHARE_TREASURY_PCT = 15
    const val SHARE_BURN_PCT = 20
    const val SHARE_VALIDATORS_PCT = 60

    private val BI_100 = BigInteger.valueOf(100L)
    private val BI_FOUNDER = BigInteger.valueOf(SHARE_FOUNDER_PCT.toLong())
    private val BI_TREASURY = BigInteger.valueOf(SHARE_TREASURY_PCT.toLong())
    private val BI_BURN = BigInteger.valueOf(SHARE_BURN_PCT.toLong())

    fun isTokenIssuanceActive(parameters: BlockchainParameters): Boolean {
        return parameters.tokenIssuanceEnabled && parameters.isPublicMainnetActive
    }

    /**
     * Guard enforcing Mainnet + audit prerequisites before any live issuance can be activated.
     */
    fun validateActivationPrerequisites(
        parameters: BlockchainParameters,
        independentAuditApproved: Boolean,
        minimumBftValidatorsOnline: Int
    ): Result<Unit> {
        if (!parameters.isPublicMainnetActive || !parameters.tokenIssuanceEnabled) {
            return Result.failure(IllegalStateException("Token issuance blocked: Mainnet parameters are dormant (tokenIssuanceEnabled=false)"))
        }
        if (!independentAuditApproved) {
            return Result.failure(IllegalStateException("Token issuance blocked: third-party security audit sign-off required"))
        }
        if (minimumBftValidatorsOnline < 4) {
            return Result.failure(IllegalStateException("Token issuance blocked: minimum 4 independent BFT validators required"))
        }
        return Result.success(Unit)
    }

    /**
     * Calculates cumulative newly minted supply (excluding genesis allocation) at [timestampMs]
     * given [mainnetGenesisTimestampMs]. Always returns 0L when issuance is dormant.
     */
    fun computeCumulativeMintedUnits(
        parameters: BlockchainParameters,
        mainnetGenesisTimestampMs: Long,
        timestampMs: Long
    ): Long {
        if (!isTokenIssuanceActive(parameters)) return 0L
        val elapsedSinceGenesis = timestampMs - mainnetGenesisTimestampMs
        if (elapsedSinceGenesis < CLIFF_DURATION_MS) return 0L

        val elapsedPostCliff = (elapsedSinceGenesis - CLIFF_DURATION_MS).coerceAtMost(RELEASE_DURATION_MS)
        if (elapsedPostCliff <= 0L) return 0L

        val numerator = BigInteger.valueOf(EMISSION_SUPPLY_UNITS).multiply(BigInteger.valueOf(elapsedPostCliff))
        return numerator.divide(BigInteger.valueOf(RELEASE_DURATION_MS)).longValueExact()
    }

    /**
     * Calculates newly minted block emission between [parentTimestampMs] and [blockTimestampMs].
     * Enforces monotonic non-negative issuance and hard cap [MAX_SUPPLY_UNITS].
     * Always returns 0L unless [isTokenIssuanceActive] is true.
     */
    fun calculateBlockEmissionUnits(
        parameters: BlockchainParameters,
        mainnetGenesisTimestampMs: Long,
        parentTimestampMs: Long,
        blockTimestampMs: Long,
        alreadyCirculatingMintedUnits: Long = 0L
    ): Long {
        if (!isTokenIssuanceActive(parameters)) return 0L
        if (blockTimestampMs <= parentTimestampMs) return 0L

        val cumPrev = computeCumulativeMintedUnits(parameters, mainnetGenesisTimestampMs, parentTimestampMs)
        val cumNow = computeCumulativeMintedUnits(parameters, mainnetGenesisTimestampMs, blockTimestampMs)
        val delta = (cumNow - cumPrev).coerceAtLeast(0L)
        val remainingCap = (EMISSION_SUPPLY_UNITS - alreadyCirculatingMintedUnits).coerceAtLeast(0L)
        return minOf(delta, remainingCap)
    }

    /**
     * Deterministically splits total fees/rewards using 5% / 15% / 20% / 60% rule without overflow or dust loss.
     */
    fun distributeUnits(totalUnits: Long): FeeAndRewardDistribution {
        if (totalUnits <= 0L) {
            return FeeAndRewardDistribution(0L, 0L, 0L, 0L)
        }
        val totalBi = BigInteger.valueOf(totalUnits)
        val founder = totalBi.multiply(BI_FOUNDER).divide(BI_100).longValueExact()
        val treasury = totalBi.multiply(BI_TREASURY).divide(BI_100).longValueExact()
        val burn = totalBi.multiply(BI_BURN).divide(BI_100).longValueExact()
        // Assign any integer division remainder deterministically to the Validators pool so sum == totalUnits
        val validators = totalUnits - founder - treasury - burn
        return FeeAndRewardDistribution(
            founderUnits = founder,
            treasuryUnits = treasury,
            burnedUnits = burn,
            validatorsPoolUnits = validators
        )
    }
}
