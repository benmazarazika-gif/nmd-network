package com.example.blockchain.validation

import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockHeader

/**
 * Structural Block Validator for Stage 8.
 *
 * Strictly separates structural & cryptographic integrity validation
 * from future consensus rule enforcement via [ConsensusValidationHook].
 */
class BlockValidator(
    private val config: BlockchainConfig,
    private val blockHasher: BlockHasher = BlockHasher()
) {
    fun validateBlock(
        block: Block,
        parentBlock: Block?,
        nowMs: Long = System.currentTimeMillis(),
        consensusHook: ConsensusValidationHook? = null
    ): BlockValidationResult {
        val header = block.header
        val body = block.body
        val params = config.parameters

        // 1. Structural format & hex checks
        if (header.chainId.isBlank() || header.producerId.isBlank()) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.MALFORMED_DATA,
                "Blank chainId or producerId in block header"
            )
        }
        if (!BlockHasher.isValidSha256Hex(block.hash)) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_HASH,
                "Malformed block hash hex: ${block.hash}"
            )
        }
        if (!BlockHasher.isValidSha256Hex(header.previousHash)) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_PREVIOUS_HASH,
                "Malformed previousHash hex: ${header.previousHash}"
            )
        }
        if (!BlockHasher.isValidSha256Hex(header.merkleRoot)) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_MERKLE_ROOT,
                "Malformed merkleRoot hex: ${header.merkleRoot}"
            )
        }

        // 2. Chain ID and protocol version checks
        if (header.chainId != config.chainId) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_CHAIN_ID,
                "Chain ID mismatch: expected ${config.chainId}, got ${header.chainId}"
            )
        }
        if (header.protocolVersion != params.protocolVersion) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.UNSUPPORTED_PROTOCOL_VERSION,
                "Unsupported protocol version: ${header.protocolVersion} (expected ${params.protocolVersion})"
            )
        }

        // 3. Block height & parent linkage checks
        if (header.height < 0L) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_HEIGHT,
                "Block height cannot be negative: ${header.height}"
            )
        }

        if (header.height == 0L) {
            if (!header.previousHash.equals(BlockHeader.GENESIS_PREVIOUS_HASH, ignoreCase = true)) {
                return BlockValidationResult.Invalid(
                    ValidationErrorCode.INVALID_PREVIOUS_HASH,
                    "Genesis block previousHash must be all zeros"
                )
            }
        } else {
            if (parentBlock == null) {
                return BlockValidationResult.Invalid(
                    ValidationErrorCode.INVALID_PREVIOUS_HASH,
                    "Missing parent block for height ${header.height}"
                )
            }
            if (header.height != parentBlock.height + 1L) {
                return BlockValidationResult.Invalid(
                    ValidationErrorCode.INVALID_HEIGHT,
                    "Non-sequential block height: expected ${parentBlock.height + 1L}, got ${header.height}"
                )
            }
            if (!header.previousHash.equals(parentBlock.hash, ignoreCase = true)) {
                return BlockValidationResult.Invalid(
                    ValidationErrorCode.INVALID_PREVIOUS_HASH,
                    "Previous hash mismatch: expected ${parentBlock.hash}, got ${header.previousHash}"
                )
            }
        }

        // 4. Timestamp checks
        if (header.timestamp <= 0L) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_TIMESTAMP,
                "Invalid non-positive block timestamp: ${header.timestamp}"
            )
        }
        if (header.timestamp > nowMs + params.maxFutureTimestampDriftMs) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_TIMESTAMP,
                "Block timestamp exceeds allowed future drift (${header.timestamp} > ${nowMs + params.maxFutureTimestampDriftMs})"
            )
        }
        if (parentBlock != null && header.timestamp < parentBlock.timestamp) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_TIMESTAMP,
                "Block timestamp (${header.timestamp}) precedes parent timestamp (${parentBlock.timestamp})"
            )
        }

        // 5. Transaction count & ordering consistency
        if (header.transactionCount != body.transactionRefs.size || header.transactionCount < 0) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.TX_COUNT_MISMATCH,
                "Header transactionCount (${header.transactionCount}) does not match body size (${body.transactionRefs.size})"
            )
        }
        if (header.transactionCount > params.maxTransactionsPerBlock) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.BLOCK_TOO_LARGE,
                "Transaction count (${header.transactionCount}) exceeds max (${params.maxTransactionsPerBlock})"
            )
        }
        for (i in body.transactionRefs.indices) {
            val ref = body.transactionRefs[i]
            if (ref.txIndex != i || !BlockHasher.isValidSha256Hex(ref.txHash)) {
                return BlockValidationResult.Invalid(
                    ValidationErrorCode.MALFORMED_DATA,
                    "Invalid transaction reference at index $i"
                )
            }
        }

        // 6. Block size limits
        val sizeBytes = blockHasher.computeBlockSizeBytes(block)
        if (sizeBytes > params.maxBlockSizeBytes) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.BLOCK_TOO_LARGE,
                "Serialized block size ($sizeBytes B) exceeds maximum (${params.maxBlockSizeBytes} B)"
            )
        }

        // 7. Merkle root verification
        if (!blockHasher.verifyMerkleRoot(block)) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_MERKLE_ROOT,
                "Merkle root verification failed"
            )
        }

        // 8. Canonical SHA-256 block hash verification
        if (!blockHasher.verifyBlockHash(block)) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.INVALID_HASH,
                "Block hash verification failed"
            )
        }

        // 9. Optional future Consensus hook
        if (consensusHook != null && consensusHook !== StructuralOnlyConsensusHook) {
            val consensusRes = consensusHook.validateConsensusMetadata(block, parentBlock)
            if (consensusRes is BlockValidationResult.Invalid) {
                return consensusRes
            }
            return BlockValidationResult.Valid(structuralValidated = true, consensusValidated = true)
        }

        return BlockValidationResult.Valid(structuralValidated = true, consensusValidated = false)
    }
}
