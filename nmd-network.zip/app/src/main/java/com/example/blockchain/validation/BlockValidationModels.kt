package com.example.blockchain.validation

import com.example.blockchain.model.Block

enum class ValidationErrorCode {
    MALFORMED_DATA,
    INVALID_HASH,
    INVALID_PREVIOUS_HASH,
    INVALID_HEIGHT,
    INVALID_MERKLE_ROOT,
    INVALID_CHAIN_ID,
    UNSUPPORTED_PROTOCOL_VERSION,
    TX_COUNT_MISMATCH,
    BLOCK_TOO_LARGE,
    INVALID_TIMESTAMP,
    DUPLICATE_BLOCK,
    GENESIS_MISMATCH,
    CONSENSUS_REJECTED
}

sealed class BlockValidationResult {
    data class Valid(
        val structuralValidated: Boolean = true,
        val consensusValidated: Boolean = false
    ) : BlockValidationResult()

    data class Invalid(
        val code: ValidationErrorCode,
        val reason: String
    ) : BlockValidationResult()

    val isValid: Boolean
        get() = this is Valid
}

/**
 * Clean hook allowing future consensus stages (Stage 9+) to plug consensus verification
 * into the Stage 8 structural validation pipeline without rewriting core storage/hashing.
 */
interface ConsensusValidationHook {
    fun validateConsensusMetadata(block: Block, parentBlock: Block?): BlockValidationResult
}

/**
 * Default Stage 8 consensus hook: explicitly performs structural-only pass-through
 * without fabricating consensus rules.
 */
object StructuralOnlyConsensusHook : ConsensusValidationHook {
    override fun validateConsensusMetadata(block: Block, parentBlock: Block?): BlockValidationResult {
        return BlockValidationResult.Valid(structuralValidated = true, consensusValidated = false)
    }
}
