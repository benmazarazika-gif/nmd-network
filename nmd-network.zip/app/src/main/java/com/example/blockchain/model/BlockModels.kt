package com.example.blockchain.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Lightweight transaction reference stored in Stage 8 blocks.
 * Transaction execution and account balances belong to later stages.
 */
data class TransactionReference(
    val txHash: String,
    val txIndex: Int,
    val txType: String = "REF"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("tx_hash", txHash)
        put("tx_index", txIndex)
        put("tx_type", txType)
    }

    companion object {
        fun fromJson(json: JSONObject): TransactionReference? {
            return try {
                TransactionReference(
                    txHash = json.getString("tx_hash"),
                    txIndex = json.getInt("tx_index"),
                    txType = json.optString("tx_type", "REF")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

/**
 * Consensus-critical block header structure.
 */
data class BlockHeader(
    val height: Long,
    val previousHash: String,
    val timestamp: Long,
    val chainId: String,
    val protocolVersion: Int,
    val merkleRoot: String,
    val transactionCount: Int,
    val producerId: String,
    val consensusMetadata: String = "",
    val stateRoot: String = "",
    val validatorSetHash: String = ""
) {
    companion object {
        val GENESIS_PREVIOUS_HASH = "0".repeat(64)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("height", height)
        put("previous_hash", previousHash)
        put("timestamp", timestamp)
        put("chain_id", chainId)
        put("protocol_version", protocolVersion)
        put("merkle_root", merkleRoot)
        put("transaction_count", transactionCount)
        put("producer_id", producerId)
        put("consensus_metadata", consensusMetadata)
        if (stateRoot.isNotEmpty()) put("state_root", stateRoot)
        if (validatorSetHash.isNotEmpty()) put("validator_set_hash", validatorSetHash)
    }
}

/**
 * Block body containing transaction references and optional genesis/block metadata.
 */
data class BlockBody(
    val transactionRefs: List<TransactionReference> = emptyList(),
    val extraData: String = ""
) {
    fun toJsonString(): String = JSONObject().apply {
        val arr = JSONArray()
        transactionRefs.forEach { arr.put(it.toJson()) }
        put("transaction_refs", arr)
        put("extra_data", extraData)
    }.toString()

    companion object {
        fun fromJsonString(jsonStr: String): BlockBody? {
            return try {
                val json = JSONObject(jsonStr)
                val arr = json.optJSONArray("transaction_refs") ?: JSONArray()
                val refs = mutableListOf<TransactionReference>()
                for (i in 0 until arr.length()) {
                    val ref = TransactionReference.fromJson(arr.getJSONObject(i)) ?: return null
                    refs.add(ref)
                }
                BlockBody(
                    transactionRefs = refs,
                    extraData = json.optString("extra_data", "")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

/**
 * Complete NMD Blockchain Block combining header, body, and SHA-256 block hash.
 */
data class Block(
    val header: BlockHeader,
    val body: BlockBody,
    val hash: String
) {
    val height: Long
        get() = header.height

    val previousHash: String
        get() = header.previousHash

    val timestamp: Long
        get() = header.timestamp

    val chainId: String
        get() = header.chainId

    val displayHash: String
        get() = if (hash.length > 16) "${hash.take(10)}...${hash.takeLast(6)}" else hash

    fun toStorageJson(): String {
        return JSONObject().apply {
            put("hash", hash)
            put("header", header.toJson())
            put("body", JSONObject(body.toJsonString()))
        }.toString()
    }

    companion object {
        fun fromStorageJson(jsonStr: String): Block? {
            return try {
                val root = JSONObject(jsonStr)
                val hash = root.getString("hash")
                val headerJson = root.getJSONObject("header")
                val bodyJson = root.getJSONObject("body")

                val header = BlockHeader(
                    height = headerJson.getLong("height"),
                    previousHash = headerJson.getString("previous_hash"),
                    timestamp = headerJson.getLong("timestamp"),
                    chainId = headerJson.getString("chain_id"),
                    protocolVersion = headerJson.getInt("protocol_version"),
                    merkleRoot = headerJson.getString("merkle_root"),
                    transactionCount = headerJson.getInt("transaction_count"),
                    producerId = headerJson.getString("producer_id"),
                    consensusMetadata = headerJson.optString("consensus_metadata", ""),
                    stateRoot = headerJson.optString("state_root", ""),
                    validatorSetHash = headerJson.optString("validator_set_hash", "")
                )
                val body = BlockBody.fromJsonString(bodyJson.toString()) ?: return null
                Block(header = header, body = body, hash = hash)
            } catch (_: Exception) {
                null
            }
        }
    }
}
