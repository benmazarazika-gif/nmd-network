package com.example.blockchain.crypto

import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider

data class MerkleProofStep(
    val siblingHashHex: String,
    val isLeftSibling: Boolean
)

data class MerkleProof(
    val leafHashHex: String,
    val rootHashHex: String,
    val steps: List<MerkleProofStep>
)

/**
 * Domain-separated SHA-256 Merkle tree for Stage 8 transaction commitments and future SPV proofs.
 *
 * Domain prefixes prevent second-preimage attacks between leaf and internal tree nodes:
 * - Empty tree root: SHA-256("NMD-MERKLE-EMPTY-V1\0")
 * - Leaf node hash: SHA-256(0x00 || rawLeafHashBytes)
 * - Internal node hash: SHA-256(0x01 || leftNodeBytes || rightNodeBytes)
 */
object MerkleTree {

    private val EMPTY_ROOT_PREIMAGE = "NMD-MERKLE-EMPTY-V1\u0000".toByteArray(Charsets.UTF_8)
    private const val LEAF_DOMAIN_PREFIX: Byte = 0x00
    private const val NODE_DOMAIN_PREFIX: Byte = 0x01

    fun computeRoot(
        leafHashesHex: List<String>,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): String {
        if (leafHashesHex.isEmpty()) {
            return cryptoProvider.toHex(cryptoProvider.sha256(EMPTY_ROOT_PREIMAGE))
        }

        var currentLevel = leafHashesHex.map { hex ->
            hashLeaf(cryptoProvider.fromHex(hex), cryptoProvider)
        }

        while (currentLevel.size > 1) {
            val nextLevel = mutableListOf<ByteArray>()
            var i = 0
            while (i < currentLevel.size) {
                val left = currentLevel[i]
                val right = if (i + 1 < currentLevel.size) currentLevel[i + 1] else currentLevel[i]
                nextLevel.add(hashInternalNode(left, right, cryptoProvider))
                i += 2
            }
            currentLevel = nextLevel
        }

        return cryptoProvider.toHex(currentLevel.first())
    }

    fun generateProof(
        leafHashesHex: List<String>,
        targetIndex: Int,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): MerkleProof? {
        if (leafHashesHex.isEmpty() || targetIndex !in leafHashesHex.indices) {
            return null
        }

        val steps = mutableListOf<MerkleProofStep>()
        var currentIndex = targetIndex
        var currentLevel = leafHashesHex.map { hex ->
            hashLeaf(cryptoProvider.fromHex(hex), cryptoProvider)
        }

        while (currentLevel.size > 1) {
            val isRightNode = (currentIndex % 2 == 1)
            val siblingIndex = if (isRightNode) currentIndex - 1 else currentIndex + 1
            val siblingBytes = if (siblingIndex < currentLevel.size) {
                currentLevel[siblingIndex]
            } else {
                currentLevel[currentIndex]
            }

            steps.add(
                MerkleProofStep(
                    siblingHashHex = cryptoProvider.toHex(siblingBytes),
                    isLeftSibling = isRightNode
                )
            )

            val nextLevel = mutableListOf<ByteArray>()
            var i = 0
            while (i < currentLevel.size) {
                val left = currentLevel[i]
                val right = if (i + 1 < currentLevel.size) currentLevel[i + 1] else currentLevel[i]
                nextLevel.add(hashInternalNode(left, right, cryptoProvider))
                i += 2
            }
            currentLevel = nextLevel
            currentIndex /= 2
        }

        return MerkleProof(
            leafHashHex = leafHashesHex[targetIndex].lowercase(),
            rootHashHex = cryptoProvider.toHex(currentLevel.first()),
            steps = steps
        )
    }

    fun verifyProof(
        proof: MerkleProof,
        cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
    ): Boolean {
        return try {
            var currentBytes = hashLeaf(cryptoProvider.fromHex(proof.leafHashHex), cryptoProvider)
            for (step in proof.steps) {
                val siblingBytes = cryptoProvider.fromHex(step.siblingHashHex)
                currentBytes = if (step.isLeftSibling) {
                    hashInternalNode(siblingBytes, currentBytes, cryptoProvider)
                } else {
                    hashInternalNode(currentBytes, siblingBytes, cryptoProvider)
                }
            }
            cryptoProvider.toHex(currentBytes).equals(proof.rootHashHex, ignoreCase = true)
        } catch (_: Exception) {
            false
        }
    }

    private fun hashLeaf(leafBytes: ByteArray, cryptoProvider: CryptographicProvider): ByteArray {
        val input = ByteArray(1 + leafBytes.size)
        input[0] = LEAF_DOMAIN_PREFIX
        System.arraycopy(leafBytes, 0, input, 1, leafBytes.size)
        return cryptoProvider.sha256(input)
    }

    private fun hashInternalNode(
        left: ByteArray,
        right: ByteArray,
        cryptoProvider: CryptographicProvider
    ): ByteArray {
        val input = ByteArray(1 + left.size + right.size)
        input[0] = NODE_DOMAIN_PREFIX
        System.arraycopy(left, 0, input, 1, left.size)
        System.arraycopy(right, 0, input, 1 + left.size, right.size)
        return cryptoProvider.sha256(input)
    }
}
