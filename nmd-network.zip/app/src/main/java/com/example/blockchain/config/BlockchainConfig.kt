package com.example.blockchain.config

enum class NetworkEnvironment {
    LOCAL_DEV,
    PRIVATE_TESTNET,
    PUBLIC_TESTNET_FUTURE,
    MAINNET_FUTURE
}

/**
 * Consensus-neutral chain parameters for NMD Network Stage 8.
 *
 * Strictly enforces Stage 8 constraints:
 * - No real token issuance is activated.
 * - No public mainnet is activated.
 */
data class BlockchainParameters(
    val protocolVersion: Int = 1,
    val maxBlockSizeBytes: Int = 1_048_576, // 1 MiB
    val maxTransactionsPerBlock: Int = 2_000,
    val maxFutureTimestampDriftMs: Long = 120_000L, // 2 minutes
    val targetBlockIntervalMs: Long = 10_000L,
    val tokenIssuanceEnabled: Boolean = false,
    val isPublicMainnetActive: Boolean = false
)

/**
 * Deterministic Genesis Block configuration.
 * Any two nodes using the same GenesisConfig produce identical genesis block hashes.
 */
data class GenesisConfig(
    val networkEnvironment: NetworkEnvironment,
    val networkName: String,
    val chainId: String,
    val fixedTimestampMs: Long,
    val producerId: String,
    val extraData: String,
    val parameters: BlockchainParameters = BlockchainParameters()
)

object NmdGenesisConfigs {
    // 2025-01-01T00:00:00.000Z UTC (Fixed across all nodes)
    const val LOCAL_DEV_TIMESTAMP_MS = 1735689600000L
    const val PRIVATE_TESTNET_TIMESTAMP_MS = 1735776000000L
    const val PUBLIC_TESTNET_FUTURE_TIMESTAMP_MS = 1735862400000L
    const val MAINNET_FUTURE_TIMESTAMP_MS = 1735948800000L

    val LOCAL_DEV = GenesisConfig(
        networkEnvironment = NetworkEnvironment.LOCAL_DEV,
        networkName = "NMD Local Development Chain",
        chainId = "nmd-local-dev-1",
        fixedTimestampMs = LOCAL_DEV_TIMESTAMP_MS,
        producerId = "nmd_genesis_authority_local_dev",
        extraData = "NMD-Stage8-Genesis-LocalDev-v1"
    )

    val PRIVATE_TESTNET = GenesisConfig(
        networkEnvironment = NetworkEnvironment.PRIVATE_TESTNET,
        networkName = "NMD Private Test Network",
        chainId = "nmd-private-testnet-1",
        fixedTimestampMs = PRIVATE_TESTNET_TIMESTAMP_MS,
        producerId = "nmd_genesis_authority_private_test",
        extraData = "NMD-Stage8-Genesis-PrivateTestnet-v1"
    )

    val PUBLIC_TESTNET_FUTURE = GenesisConfig(
        networkEnvironment = NetworkEnvironment.PUBLIC_TESTNET_FUTURE,
        networkName = "NMD Future Public Testnet (Reserved)",
        chainId = "nmd-public-testnet-reserved",
        fixedTimestampMs = PUBLIC_TESTNET_FUTURE_TIMESTAMP_MS,
        producerId = "nmd_genesis_authority_testnet_reserved",
        extraData = "NMD-Stage8-Genesis-PublicTestnet-Reserved"
    )

    val MAINNET_FUTURE = GenesisConfig(
        networkEnvironment = NetworkEnvironment.MAINNET_FUTURE,
        networkName = "NMD Future Mainnet (Unactivated)",
        chainId = "nmd-mainnet-reserved",
        fixedTimestampMs = MAINNET_FUTURE_TIMESTAMP_MS,
        producerId = "nmd_genesis_authority_mainnet_reserved",
        extraData = "NMD-Stage8-Genesis-Mainnet-Unactivated"
    )

    fun forEnvironment(env: NetworkEnvironment): GenesisConfig = when (env) {
        NetworkEnvironment.LOCAL_DEV -> LOCAL_DEV
        NetworkEnvironment.PRIVATE_TESTNET -> PRIVATE_TESTNET
        NetworkEnvironment.PUBLIC_TESTNET_FUTURE -> PUBLIC_TESTNET_FUTURE
        NetworkEnvironment.MAINNET_FUTURE -> MAINNET_FUTURE
    }
}

data class BlockchainConfig(
    val genesisConfig: GenesisConfig = NmdGenesisConfigs.LOCAL_DEV,
    val databaseName: String = databaseNameFor("nmd_blockchain_core.db", genesisConfig.chainId)
) {
    val parameters: BlockchainParameters
        get() = genesisConfig.parameters

    val chainId: String
        get() = genesisConfig.chainId

    val networkName: String
        get() = genesisConfig.networkName

    val networkEnvironment: NetworkEnvironment
        get() = genesisConfig.networkEnvironment

    val isLocalDevelopmentChain: Boolean
        get() = networkEnvironment == NetworkEnvironment.LOCAL_DEV

    companion object {
        fun databaseNameFor(baseName: String, chainId: String): String {
            if (chainId == NmdGenesisConfigs.LOCAL_DEV.chainId) {
                return baseName
            }
            val safeChain = chainId.lowercase().replace(Regex("[^a-z0-9_-]"), "_")
            val stem = baseName.removeSuffix(".db")
            return "${stem}_${safeChain}.db"
        }

        fun forGenesis(genesis: GenesisConfig): BlockchainConfig = BlockchainConfig(
            genesisConfig = genesis,
            databaseName = databaseNameFor("nmd_blockchain_core.db", genesis.chainId)
        )
    }
}
