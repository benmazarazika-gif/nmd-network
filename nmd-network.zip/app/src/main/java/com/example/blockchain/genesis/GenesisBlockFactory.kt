package com.example.blockchain.genesis

import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.config.GenesisConfig
import com.example.blockchain.config.NmdGenesisConfigs
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.blockchain.validation.BlockValidationResult
import com.example.blockchain.validation.BlockValidator
import com.example.blockchain.validation.ValidationErrorCode

/**
 * Deterministically builds and validates NMD Network Genesis Blocks.
 */
class GenesisBlockFactory(
    private val blockHasher: BlockHasher = BlockHasher()
) {
    fun createGenesisBlock(config: GenesisConfig = NmdGenesisConfigs.LOCAL_DEV): Block {
        val body = BlockBody(
            transactionRefs = emptyList(),
            extraData = config.extraData
        )
        val merkleRoot = blockHasher.computeBodyMerkleRoot(body)
        val consensusMetadata = "env=${config.networkEnvironment.name};token_issuance=${config.parameters.tokenIssuanceEnabled};mainnet=${config.parameters.isPublicMainnetActive}"

        val header = BlockHeader(
            height = 0L,
            previousHash = BlockHeader.GENESIS_PREVIOUS_HASH,
            timestamp = config.fixedTimestampMs,
            chainId = config.chainId,
            protocolVersion = config.parameters.protocolVersion,
            merkleRoot = merkleRoot,
            transactionCount = 0,
            producerId = config.producerId,
            consensusMetadata = consensusMetadata
        )

        val hash = blockHasher.computeHeaderHash(header)
        return Block(header = header, body = body, hash = hash)
    }

    fun validateGenesisBlock(block: Block, expectedConfig: GenesisConfig): BlockValidationResult {
        val validator = BlockValidator(BlockchainConfig(expectedConfig), blockHasher)
        val structural = validator.validateBlock(block, parentBlock = null)
        if (structural is BlockValidationResult.Invalid) {
            return structural
        }

        val canonicalExpected = createGenesisBlock(expectedConfig)
        if (!block.hash.equals(canonicalExpected.hash, ignoreCase = true)) {
            return BlockValidationResult.Invalid(
                ValidationErrorCode.GENESIS_MISMATCH,
                "Genesis hash mismatch: expected ${canonicalExpected.hash}, got ${block.hash}"
            )
        }
        return BlockValidationResult.Valid(structuralValidated = true, consensusValidated = false)
    }
}
