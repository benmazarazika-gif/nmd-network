package com.example.blockchain.model

import com.example.blockchain.config.NetworkEnvironment

enum class BlockchainDbStatus {
    UNINITIALIZED,
    INITIALIZING,
    READY,
    CORRUPTED,
    ERROR
}

enum class StructuralValidationStatus {
    PENDING,
    VALID,
    INVALID
}

data class ChainState(
    val isInitialized: Boolean = false,
    val networkEnvironment: NetworkEnvironment = NetworkEnvironment.LOCAL_DEV,
    val networkName: String = "NMD Local Development Chain",
    val chainId: String = "nmd-local-dev-1",
    val genesisHash: String = "",
    val currentHeight: Long = -1L,
    val latestBlockHash: String = "",
    val latestBlockTimestamp: Long = 0L,
    val storedBlockCount: Long = 0L,
    val dbStatus: BlockchainDbStatus = BlockchainDbStatus.UNINITIALIZED,
    val structuralValidationStatus: StructuralValidationStatus = StructuralValidationStatus.PENDING,
    val lastError: String? = null,
    val isLocalDevelopmentChain: Boolean = true
) {
    val shortGenesisHash: String
        get() = if (genesisHash.length > 16) "${genesisHash.take(10)}...${genesisHash.takeLast(6)}" else genesisHash

    val shortLatestHash: String
        get() = if (latestBlockHash.length > 16) "${latestBlockHash.take(10)}...${latestBlockHash.takeLast(6)}" else latestBlockHash
}
