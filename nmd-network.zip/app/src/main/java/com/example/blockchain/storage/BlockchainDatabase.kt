package com.example.blockchain.storage

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [BlockEntity::class, ChainMetadataEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BlockchainDatabase : RoomDatabase() {
    abstract fun blockchainDao(): BlockchainDao

    companion object {
        fun buildPersistent(context: Context, dbName: String): BlockchainDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                BlockchainDatabase::class.java,
                dbName
            ).build()
        }

        fun buildInMemory(context: Context): BlockchainDatabase {
            return Room.inMemoryDatabaseBuilder(
                context.applicationContext,
                BlockchainDatabase::class.java
            ).build()
        }
    }
}
