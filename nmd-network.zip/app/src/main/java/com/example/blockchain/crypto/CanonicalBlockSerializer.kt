package com.example.blockchain.crypto

import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.blockchain.model.TransactionReference
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/**
 * Provides deterministic, unambiguous big-endian binary serialization for NMD blockchain
 * headers, transaction references, and block bodies.
 *
 * Avoids JSON formatting ambiguities and limits-prone writeUTF; every string/byte slice
 * is length-prefixed with an explicit 32-bit big-endian integer length.
 */
object CanonicalBlockSerializer {

    private val HEADER_DOMAIN_SEPARATOR = "NMD-BLOCK-HEADER-V1\u0000".toByteArray(Charsets.UTF_8)
    private val HEADER_STATE_EXTENSION_TAG = "NMD-HEADER-STATE-V2\u0000".toByteArray(Charsets.UTF_8)
    private val TX_REF_DOMAIN_SEPARATOR = "NMD-TX-REF-V1\u0000".toByteArray(Charsets.UTF_8)
    private val EXTRA_DATA_DOMAIN_SEPARATOR = "NMD-BLOCK-EXTRA-V1\u0000".toByteArray(Charsets.UTF_8)

    fun serializeHeader(header: BlockHeader): ByteArray {
        val baos = ByteArrayOutputStream(320)
        val dos = DataOutputStream(baos)

        dos.write(HEADER_DOMAIN_SEPARATOR)
        dos.writeLong(header.height)
        writeLengthPrefixedString(dos, header.previousHash.lowercase())
        dos.writeLong(header.timestamp)
        writeLengthPrefixedString(dos, header.chainId)
        dos.writeInt(header.protocolVersion)
        writeLengthPrefixedString(dos, header.merkleRoot.lowercase())
        dos.writeInt(header.transactionCount)
        writeLengthPrefixedString(dos, header.producerId)
        writeLengthPrefixedString(dos, header.consensusMetadata)

        // V2 extension: included only when post-Stage-17 blocks commit state roots or validator hashes
        if (header.stateRoot.isNotEmpty() || header.validatorSetHash.isNotEmpty()) {
            dos.write(HEADER_STATE_EXTENSION_TAG)
            writeLengthPrefixedString(dos, header.stateRoot.lowercase())
            writeLengthPrefixedString(dos, header.validatorSetHash.lowercase())
        }

        dos.flush()
        return baos.toByteArray()
    }

    fun serializeTransactionReference(ref: TransactionReference): ByteArray {
        val baos = ByteArrayOutputStream(128)
        val dos = DataOutputStream(baos)

        dos.write(TX_REF_DOMAIN_SEPARATOR)
        dos.writeInt(ref.txIndex)
        writeLengthPrefixedString(dos, ref.txHash.lowercase())
        writeLengthPrefixedString(dos, ref.txType)

        dos.flush()
        return baos.toByteArray()
    }

    fun serializeExtraData(extraData: String): ByteArray {
        val baos = ByteArrayOutputStream(64)
        val dos = DataOutputStream(baos)

        dos.write(EXTRA_DATA_DOMAIN_SEPARATOR)
        writeLengthPrefixedString(dos, extraData)

        dos.flush()
        return baos.toByteArray()
    }

    fun estimateSerializedBodySize(body: BlockBody): Int {
        var total = 4 + body.extraData.toByteArray(Charsets.UTF_8).size
        for (ref in body.transactionRefs) {
            total += serializeTransactionReference(ref).size
        }
        return total
    }

    private fun writeLengthPrefixedString(dos: DataOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        dos.writeInt(bytes.size)
        dos.write(bytes)
    }
}
