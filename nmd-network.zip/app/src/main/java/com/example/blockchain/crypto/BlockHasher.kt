package com.example.blockchain.crypto

import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.blockchain.model.TransactionReference
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider

/**
 * Cryptographic block & body hashing utility reusing Stage 4 CryptographicProvider.
 */
class BlockHasher(
    val cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider()
) {
    companion object {
        private val HEX_64_REGEX = Regex("^[0-9a-f]{64}$")

        fun isValidSha256Hex(value: String): Boolean = HEX_64_REGEX.matches(value.lowercase())
    }

    fun computeHeaderHash(header: BlockHeader): String {
        val canonicalBytes = CanonicalBlockSerializer.serializeHeader(header)
        return cryptoProvider.toHex(cryptoProvider.sha256(canonicalBytes))
    }

    fun computeTransactionRefHash(ref: TransactionReference): String {
        val canonicalBytes = CanonicalBlockSerializer.serializeTransactionReference(ref)
        return cryptoProvider.toHex(cryptoProvider.sha256(canonicalBytes))
    }

    fun computeBodyMerkleRoot(body: BlockBody): String {
        val txLeafHashes = body.transactionRefs.map { computeTransactionRefHash(it) }
        return if (txLeafHashes.isNotEmpty()) {
            MerkleTree.computeRoot(txLeafHashes, cryptoProvider)
        } else if (body.extraData.isNotBlank()) {
            val extraLeaf = cryptoProvider.toHex(
                cryptoProvider.sha256(CanonicalBlockSerializer.serializeExtraData(body.extraData))
            )
            MerkleTree.computeRoot(listOf(extraLeaf), cryptoProvider)
        } else {
            MerkleTree.computeRoot(emptyList(), cryptoProvider)
        }
    }

    fun computeBlockSizeBytes(block: Block): Int {
        val headerSize = CanonicalBlockSerializer.serializeHeader(block.header).size
        val bodySize = CanonicalBlockSerializer.estimateSerializedBodySize(block.body)
        return headerSize + bodySize
    }

    fun verifyBlockHash(block: Block): Boolean {
        if (!isValidSha256Hex(block.hash)) return false
        val expectedHash = computeHeaderHash(block.header)
        return expectedHash.equals(block.hash, ignoreCase = true)
    }

    fun verifyMerkleRoot(block: Block): Boolean {
        if (!isValidSha256Hex(block.header.merkleRoot)) return false
        val expectedRoot = computeBodyMerkleRoot(block.body)
        return expectedRoot.equals(block.header.merkleRoot, ignoreCase = true)
    }
}
