package com.example.blockchain.manager

import android.content.Context
import android.util.Log
import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.genesis.GenesisBlockFactory
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockchainDbStatus
import com.example.blockchain.model.ChainState
import com.example.blockchain.model.StructuralValidationStatus
import com.example.blockchain.storage.BlockchainStorage
import com.example.blockchain.storage.ChainMetadataEntity
import com.example.blockchain.storage.IntegrityReport
import com.example.blockchain.storage.RoomBlockchainStorage
import com.example.blockchain.storage.StorageInsertResult
import com.example.blockchain.validation.BlockValidationResult
import com.example.blockchain.validation.BlockValidator
import com.example.blockchain.validation.ConsensusValidationHook
import com.example.blockchain.validation.StructuralOnlyConsensusHook
import com.example.blockchain.validation.ValidationErrorCode
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable

/**
 * Clean read-only chain tip context for future Stage 9+ block production modules.
 * Stage 8 exposes tip linkage metadata without implementing consensus or block production.
 */
data class ChainTipContext(
    val chainId: String,
    val protocolVersion: Int,
    val nextHeight: Long,
    val previousHash: String,
    val parentTimestampMs: Long
)

sealed class BlockIngestionResult {
    data class Accepted(
        val block: Block,
        val structuralValidated: Boolean,
        val consensusValidated: Boolean
    ) : BlockIngestionResult()

    data class Duplicate(val reason: String) : BlockIngestionResult()
    data class Rejected(val code: ValidationErrorCode, val reason: String) : BlockIngestionResult()
    data class StorageFailure(val reason: String) : BlockIngestionResult()
}

/**
 * Central coordinator for the Stage 8 NMD Blockchain Core.
 *
 * Responsibilities:
 * - Deterministic genesis initialization & restart recovery
 * - Structural & cryptographic block validation
 * - Atomic Room persistence via [BlockchainStorage]
 * - Broken-chain / duplicate rejection
 * - Thread-safe / coroutine-safe chain state tracking
 */
class BlockchainManager(
    val config: BlockchainConfig = BlockchainConfig(),
    private val storage: BlockchainStorage,
    val blockHasher: BlockHasher = BlockHasher(),
    private val genesisFactory: GenesisBlockFactory = GenesisBlockFactory(blockHasher),
    private val validator: BlockValidator = BlockValidator(config, blockHasher),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    constructor(
        context: Context,
        config: BlockchainConfig = BlockchainConfig(),
        inMemoryStorage: Boolean = false
    ) : this(
        config = config,
        storage = RoomBlockchainStorage(
            context = context,
            dbName = config.databaseName,
            inMemory = inMemoryStorage
        )
    )

    companion object {
        private const val TAG = "BlockchainManager"
    }

    private val writeMutex = Mutex()

    private val _chainState = MutableStateFlow(
        ChainState(
            isInitialized = false,
            networkEnvironment = config.networkEnvironment,
            networkName = config.networkName,
            chainId = config.chainId,
            dbStatus = BlockchainDbStatus.UNINITIALIZED,
            structuralValidationStatus = StructuralValidationStatus.PENDING,
            isLocalDevelopmentChain = config.isLocalDevelopmentChain
        )
    )
    val chainState: StateFlow<ChainState> = _chainState.asStateFlow()

    /**
     * Initializes the blockchain core:
     * - First launch: deterministically creates & persists the genesis block.
     * - App restart: reloads persisted genesis & latest tip and verifies DB integrity.
     */
    suspend fun initialize(): Result<ChainState> = withContext(ioDispatcher) {
        writeMutex.withLock {
            try {
                _chainState.value = _chainState.value.copy(
                    dbStatus = BlockchainDbStatus.INITIALIZING,
                    lastError = null
                )

                val canonicalGenesis = genesisFactory.createGenesisBlock(config.genesisConfig)
                val existingCount = storage.getBlockCount()

                if (existingCount == 0L) {
                    val metadata = ChainMetadataEntity(
                        chainId = config.chainId,
                        networkName = config.networkName,
                        networkEnvironment = config.networkEnvironment.name,
                        genesisHash = canonicalGenesis.hash,
                        latestHeight = canonicalGenesis.height,
                        latestHash = canonicalGenesis.hash,
                        latestTimestamp = canonicalGenesis.timestamp,
                        blockCount = 1L,
                        dbStatus = BlockchainDbStatus.READY.name
                    )

                    when (val insertRes = storage.insertBlockAtomically(canonicalGenesis, metadata)) {
                        is StorageInsertResult.Inserted -> {
                            val readyState = ChainState(
                                isInitialized = true,
                                networkEnvironment = config.networkEnvironment,
                                networkName = config.networkName,
                                chainId = config.chainId,
                                genesisHash = canonicalGenesis.hash,
                                currentHeight = 0L,
                                latestBlockHash = canonicalGenesis.hash,
                                latestBlockTimestamp = canonicalGenesis.timestamp,
                                storedBlockCount = 1L,
                                dbStatus = BlockchainDbStatus.READY,
                                structuralValidationStatus = StructuralValidationStatus.VALID,
                                isLocalDevelopmentChain = config.isLocalDevelopmentChain
                            )
                            _chainState.value = readyState
                            Log.i(TAG, "Blockchain initialized fresh with genesis ${canonicalGenesis.displayHash}")
                            return@withLock Result.success(readyState)
                        }
                        is StorageInsertResult.Duplicate, is StorageInsertResult.Error -> {
                            val err = when (insertRes) {
                                is StorageInsertResult.Duplicate -> insertRes.reason
                                is StorageInsertResult.Error -> insertRes.reason
                                else -> "Genesis insertion error"
                            }
                            return@withLock failInitialization(err, BlockchainDbStatus.ERROR)
                        }
                    }
                } else {
                    // Restart recovery path: verify genesis matches & validate DB integrity
                    val storedGenesis = storage.getGenesisBlock()
                        ?: return@withLock failInitialization("Genesis block missing in non-empty database", BlockchainDbStatus.CORRUPTED)

                    val genesisValidation = genesisFactory.validateGenesisBlock(storedGenesis, config.genesisConfig)
                    if (genesisValidation is BlockValidationResult.Invalid) {
                        return@withLock failInitialization(
                            "Stored genesis invalid: ${genesisValidation.reason}",
                            BlockchainDbStatus.CORRUPTED
                        )
                    }

                    val integrity = storage.verifyDatabaseIntegrity(config)
                    val latest = storage.getLatestBlock()
                        ?: return@withLock failInitialization("Latest block tip missing during recovery", BlockchainDbStatus.CORRUPTED)
                    val count = storage.getBlockCount()

                    if (!integrity.isHealthy) {
                        return@withLock failInitialization(
                            "Database integrity check failed: ${integrity.issues.joinToString("; ")}",
                            BlockchainDbStatus.CORRUPTED
                        )
                    }

                    val recoveredState = ChainState(
                        isInitialized = true,
                        networkEnvironment = config.networkEnvironment,
                        networkName = config.networkName,
                        chainId = config.chainId,
                        genesisHash = storedGenesis.hash,
                        currentHeight = latest.height,
                        latestBlockHash = latest.hash,
                        latestBlockTimestamp = latest.timestamp,
                        storedBlockCount = count,
                        dbStatus = BlockchainDbStatus.READY,
                        structuralValidationStatus = StructuralValidationStatus.VALID,
                        isLocalDevelopmentChain = config.isLocalDevelopmentChain
                    )
                    _chainState.value = recoveredState
                    Log.i(TAG, "Blockchain recovered on restart: height=${latest.height}, blocks=$count")
                    return@withLock Result.success(recoveredState)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Blockchain initialization error: ${e.message}")
                return@withLock failInitialization(e.message ?: "Initialization exception", BlockchainDbStatus.ERROR)
            }
        }
    }

    private fun failInitialization(message: String, status: BlockchainDbStatus): Result<ChainState> {
        _chainState.value = _chainState.value.copy(
            isInitialized = false,
            dbStatus = status,
            structuralValidationStatus = StructuralValidationStatus.INVALID,
            lastError = message
        )
        return Result.failure(IllegalStateException(message))
    }

    suspend fun getGenesisBlock(): Block? = storage.getGenesisBlock()

    suspend fun getLatestBlock(): Block? = storage.getLatestBlock()

    suspend fun getBlockByHeight(height: Long): Block? = storage.getBlockByHeight(height)

    suspend fun getBlockByHash(hash: String): Block? = storage.getBlockByHash(hash)

    suspend fun getBlocksRange(fromHeight: Long, limit: Int): List<Block> =
        storage.getBlocksRange(fromHeight, limit)

    suspend fun getCurrentHeight(): Long = storage.getLatestBlock()?.height ?: -1L

    /**
     * Exposes current tip linkage information as a clean hook for future Stage 9+ block producers.
     */
    suspend fun getTipContext(): ChainTipContext? {
        val latest = storage.getLatestBlock() ?: return null
        return ChainTipContext(
            chainId = config.chainId,
            protocolVersion = config.parameters.protocolVersion,
            nextHeight = latest.height + 1L,
            previousHash = latest.hash,
            parentTimestampMs = latest.timestamp
        )
    }

    /**
     * Validates and atomically appends an incoming block (e.g., from storage recovery or future P2P sync).
     *
     * Checks:
     * 1. Initialization state
     * 2. Duplicate hash or existing height
     * 3. Exact parent linkage against latest stored tip
     * 4. Full structural & cryptographic validation (+ optional future ConsensusValidationHook)
     * 5. Atomic Room database insertion & metadata update
     */
    suspend fun submitIncomingBlock(
        block: Block,
        nowMs: Long = System.currentTimeMillis(),
        consensusHook: ConsensusValidationHook = StructuralOnlyConsensusHook
    ): BlockIngestionResult = withContext(ioDispatcher) {
        writeMutex.withLock {
            if (!_chainState.value.isInitialized) {
                return@withLock BlockIngestionResult.StorageFailure("BlockchainManager is not initialized")
            }

            // 1. Check duplicate hash or height
            if (storage.existsByHashOrHeight(block.hash, block.height)) {
                return@withLock BlockIngestionResult.Duplicate(
                    "Duplicate block rejected (height=${block.height}, hash=${block.displayHash})"
                )
            }

            // 2. Locate expected parent (must link directly to current chain tip in Stage 8 linear core)
            val latestTip = storage.getLatestBlock()
                ?: return@withLock BlockIngestionResult.StorageFailure("Chain tip missing in storage")

            if (block.height != latestTip.height + 1L) {
                return@withLock BlockIngestionResult.Rejected(
                    ValidationErrorCode.INVALID_HEIGHT,
                    "Expected height ${latestTip.height + 1L}, got ${block.height}"
                )
            }

            if (!block.previousHash.equals(latestTip.hash, ignoreCase = true)) {
                return@withLock BlockIngestionResult.Rejected(
                    ValidationErrorCode.INVALID_PREVIOUS_HASH,
                    "Broken previousHash: expected ${latestTip.hash}, got ${block.previousHash}"
                )
            }

            // 3. Structural + Cryptographic (+ optional ConsensusHook) validation
            val validation = validator.validateBlock(
                block = block,
                parentBlock = latestTip,
                nowMs = nowMs,
                consensusHook = consensusHook
            )

            if (validation is BlockValidationResult.Invalid) {
                _chainState.value = _chainState.value.copy(
                    structuralValidationStatus = StructuralValidationStatus.INVALID,
                    lastError = validation.reason
                )
                return@withLock BlockIngestionResult.Rejected(validation.code, validation.reason)
            }

            val validMeta = validation as BlockValidationResult.Valid
            val newCount = storage.getBlockCount() + 1L
            val metadata = ChainMetadataEntity(
                chainId = config.chainId,
                networkName = config.networkName,
                networkEnvironment = config.networkEnvironment.name,
                genesisHash = _chainState.value.genesisHash,
                latestHeight = block.height,
                latestHash = block.hash.lowercase(),
                latestTimestamp = block.timestamp,
                blockCount = newCount,
                dbStatus = BlockchainDbStatus.READY.name
            )

            when (val insertRes = storage.insertBlockAtomically(block, metadata)) {
                is StorageInsertResult.Inserted -> {
                    _chainState.value = _chainState.value.copy(
                        currentHeight = block.height,
                        latestBlockHash = block.hash.lowercase(),
                        latestBlockTimestamp = block.timestamp,
                        storedBlockCount = newCount,
                        dbStatus = BlockchainDbStatus.READY,
                        structuralValidationStatus = StructuralValidationStatus.VALID,
                        lastError = null
                    )
                    BlockIngestionResult.Accepted(
                        block = block,
                        structuralValidated = validMeta.structuralValidated,
                        consensusValidated = validMeta.consensusValidated
                    )
                }
                is StorageInsertResult.Duplicate -> {
                    BlockIngestionResult.Duplicate(insertRes.reason)
                }
                is StorageInsertResult.Error -> {
                    BlockIngestionResult.StorageFailure(insertRes.reason)
                }
            }
        }
    }

    /**
     * Audits the persisted blockchain database without loading the entire chain into memory.
     */
    suspend fun verifyIntegrity(): IntegrityReport = withContext(ioDispatcher) {
        writeMutex.withLock {
            val report = storage.verifyDatabaseIntegrity(config)
            _chainState.value = _chainState.value.copy(
                dbStatus = if (report.isHealthy) BlockchainDbStatus.READY else BlockchainDbStatus.CORRUPTED,
                structuralValidationStatus = if (report.isHealthy) StructuralValidationStatus.VALID else StructuralValidationStatus.INVALID,
                lastError = if (report.isHealthy) null else report.issues.firstOrNull()
            )
            report
        }
    }

    override fun close() {
        storage.close()
    }
}
