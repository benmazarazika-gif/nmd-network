package com.example.blockchain.storage

import com.example.blockchain.config.BlockchainConfig
import com.example.blockchain.model.Block
import kotlinx.coroutines.flow.Flow
import java.io.Closeable

data class IntegrityReport(
    val isHealthy: Boolean,
    val verifiedBlocksCount: Long,
    val expectedTipHeight: Long,
    val genesisHashMatches: Boolean,
    val issues: List<String> = emptyList()
)

sealed class StorageInsertResult {
    object Inserted : StorageInsertResult()
    data class Duplicate(val reason: String) : StorageInsertResult()
    data class Error(val reason: String) : StorageInsertResult()
}

/**
 * Abstraction over persistent blockchain storage allowing clean Room implementation
 * and isolated unit/integration testing.
 */
interface BlockchainStorage : Closeable {
    suspend fun getGenesisBlock(): Block?
    suspend fun getBlockByHeight(height: Long): Block?
    suspend fun getBlockByHash(hash: String): Block?
    suspend fun getLatestBlock(): Block?
    suspend fun getBlocksRange(fromHeight: Long, limit: Int): List<Block>
    suspend fun getBlockCount(): Long
    suspend fun existsByHashOrHeight(hash: String, height: Long): Boolean
    suspend fun getChainMetadata(): ChainMetadataEntity?
    fun observeChainMetadata(): Flow<ChainMetadataEntity?>
    suspend fun upsertChainMetadata(metadata: ChainMetadataEntity)
    suspend fun insertBlockAtomically(block: Block, metadata: ChainMetadataEntity): StorageInsertResult
    suspend fun verifyDatabaseIntegrity(config: BlockchainConfig): IntegrityReport
    suspend fun clearAll()
}
