package com.example.blockchain.storage

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader

@Entity(
    tableName = "blockchain_blocks",
    indices = [
        Index(value = ["hash"], unique = true),
        Index(value = ["previousHash"])
    ]
)
data class BlockEntity(
    @PrimaryKey val height: Long,
    val hash: String,
    val previousHash: String,
    val timestamp: Long,
    val chainId: String,
    val protocolVersion: Int,
    val merkleRoot: String,
    val transactionCount: Int,
    val producerId: String,
    val consensusMetadata: String,
    val bodyJson: String,
    val blockSizeBytes: Int
) {
    fun toDomainBlock(): Block? {
        val parsedBody = BlockBody.fromJsonString(bodyJson) ?: return null
        val header = BlockHeader(
            height = height,
            previousHash = previousHash,
            timestamp = timestamp,
            chainId = chainId,
            protocolVersion = protocolVersion,
            merkleRoot = merkleRoot,
            transactionCount = transactionCount,
            producerId = producerId,
            consensusMetadata = consensusMetadata
        )
        return Block(header = header, body = parsedBody, hash = hash)
    }

    companion object {
        fun fromDomainBlock(block: Block, blockSizeBytes: Int): BlockEntity {
            return BlockEntity(
                height = block.header.height,
                hash = block.hash,
                previousHash = block.header.previousHash,
                timestamp = block.header.timestamp,
                chainId = block.header.chainId,
                protocolVersion = block.header.protocolVersion,
                merkleRoot = block.header.merkleRoot,
                transactionCount = block.header.transactionCount,
                producerId = block.header.producerId,
                consensusMetadata = block.header.consensusMetadata,
                bodyJson = block.body.toJsonString(),
                blockSizeBytes = blockSizeBytes
            )
        }
    }
}

@Entity(tableName = "blockchain_metadata")
data class ChainMetadataEntity(
    @PrimaryKey val id: Int = 1,
    val chainId: String,
    val networkName: String,
    val networkEnvironment: String,
    val genesisHash: String,
    val latestHeight: Long,
    val latestHash: String,
    val latestTimestamp: Long,
    val blockCount: Long,
    val dbStatus: String
)
