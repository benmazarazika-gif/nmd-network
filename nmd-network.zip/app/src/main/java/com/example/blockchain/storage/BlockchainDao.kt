package com.example.blockchain.storage

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockchainDao {

    @Query("SELECT * FROM blockchain_blocks WHERE height = :height LIMIT 1")
    suspend fun getBlockByHeight(height: Long): BlockEntity?

    @Query("SELECT * FROM blockchain_blocks WHERE hash = :hash LIMIT 1")
    suspend fun getBlockByHash(hash: String): BlockEntity?

    @Query("SELECT * FROM blockchain_blocks ORDER BY height DESC LIMIT 1")
    suspend fun getLatestBlock(): BlockEntity?

    @Query("SELECT * FROM blockchain_blocks WHERE height = 0 LIMIT 1")
    suspend fun getGenesisBlock(): BlockEntity?

    @Query("SELECT * FROM blockchain_blocks WHERE height >= :fromHeight ORDER BY height ASC LIMIT :limit")
    suspend fun getBlocksRange(fromHeight: Long, limit: Int): List<BlockEntity>

    @Query("SELECT COUNT(*) FROM blockchain_blocks")
    suspend fun getBlockCount(): Long

    @Query("SELECT EXISTS(SELECT 1 FROM blockchain_blocks WHERE hash = :hash OR height = :height)")
    suspend fun existsByHashOrHeight(hash: String, height: Long): Boolean

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBlock(block: BlockEntity)

    @Query("SELECT * FROM blockchain_metadata WHERE id = 1 LIMIT 1")
    suspend fun getMetadata(): ChainMetadataEntity?

    @Query("SELECT * FROM blockchain_metadata WHERE id = 1 LIMIT 1")
    fun observeMetadata(): Flow<ChainMetadataEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMetadata(metadata: ChainMetadataEntity)

    @Query("DELETE FROM blockchain_blocks")
    suspend fun deleteAllBlocks()

    @Query("DELETE FROM blockchain_metadata")
    suspend fun deleteMetadata()

    @Transaction
    suspend fun insertBlockAndMetadataAtomically(
        block: BlockEntity,
        metadata: ChainMetadataEntity
    ) {
        insertBlock(block)
        upsertMetadata(metadata)
    }

    @Transaction
    suspend fun clearAllAtomically() {
        deleteAllBlocks()
        deleteMetadata()
    }
}
