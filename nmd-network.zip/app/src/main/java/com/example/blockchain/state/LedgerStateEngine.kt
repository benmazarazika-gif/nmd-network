package com.example.blockchain.state

import com.example.blockchain.config.BlockchainParameters
import com.example.blockchain.economics.TokenomicsEngine
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.transaction.model.NmdTransaction
import com.example.transaction.model.TransactionType
import com.example.transaction.model.ValidatorTransactionPayload
import com.example.transaction.storage.AccountStateRecord
import com.example.transaction.storage.TransactionStorage
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.math.BigInteger

data class BlockStateTransitionResult(
    val newStateRoot: String,
    val appliedTxIds: List<String>,
    val rejectedTxReasons: Map<String, String>,
    val totalBurnedUnits: Long,
    val totalDistributedFeesUnits: Long,
    val validatorRegistrations: List<ValidatorTransactionPayload>,
    val validatorExits: List<ValidatorTransactionPayload>
)

/**
 * Stage 17 Deterministic Account State Machine & Merkle/Canonical State Root Engine.
 *
 * Guarantees:
 * - Same ordered block transactions executed on any two Android nodes produce the exact same
 *   account balances, nonces, validator statuses, and SHA-256 `stateRoot`.
 * - Overflow-safe fixed-point arithmetic using [BigInteger].
 * - Token issuance remains strictly gated by [TokenomicsEngine.isTokenIssuanceActive].
 */
class LedgerStateEngine(
    private val storage: TransactionStorage,
    private val cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider(),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    val enforceStrictBalances: Boolean = false
) {
    companion object {
        private val STATE_ROOT_DOMAIN = "NMD-STATE-ROOT-V1\u0000".toByteArray(Charsets.UTF_8)
        const val BURN_SINK_ADDRESS = "nmd1burn00000000000000000000000000000000000"
        const val TREASURY_ADDRESS = "nmd1treasury0000000000000000000000000000000"
        const val FOUNDER_VESTING_ADDRESS = "nmd1founder00000000000000000000000000000000"
    }

    private val mutex = Mutex()
    private val stateMap = LinkedHashMap<String, AccountStateRecord>()
    private var lastAppliedHeight: Long = 0L

    private val _accounts = MutableStateFlow<Map<String, AccountStateRecord>>(emptyMap())
    val accounts: StateFlow<Map<String, AccountStateRecord>> = _accounts.asStateFlow()

    private val _stateRoot = MutableStateFlow(computeCanonicalStateRoot(emptyList()))
    val stateRoot: StateFlow<String> = _stateRoot.asStateFlow()

    suspend fun initialize(): String = withContext(ioDispatcher) {
        mutex.withLock {
            stateMap.clear()
            storage.getAllAccountStates().forEach { rec ->
                stateMap[rec.address] = rec
            }
            lastAppliedHeight = stateMap.values.maxOfOrNull { it.updatedAtHeight } ?: 0L
            val root = publishSnapshotLocked()
            root
        }
    }

    suspend fun getAccountState(address: String): AccountStateRecord {
        return withContext(ioDispatcher) {
            mutex.withLock {
                stateMap[address] ?: storage.getAccountState(address) ?: AccountStateRecord(address = address)
            }
        }
    }

    suspend fun getBalanceUnits(address: String): Long = getAccountState(address).balanceUnits

    suspend fun hasSufficientBalanceForTx(
        tx: NmdTransaction,
        pendingOutflowUnits: Long = 0L
    ): Boolean = withContext(ioDispatcher) {
        mutex.withLock {
            val current = stateMap[tx.senderAddress]?.balanceUnits ?: 0L
            val required = BigInteger.valueOf(pendingOutflowUnits)
                .add(BigInteger.valueOf(tx.amountUnits))
                .add(BigInteger.valueOf(tx.feeUnits))
            BigInteger.valueOf(current) >= required
        }
    }

    /**
     * Explicit controlled funding hook strictly for LOCAL_DEV / automated tests.
     */
    suspend fun creditDevOrTestAccount(
        address: String,
        amountUnits: Long,
        atHeight: Long = 0L,
        nowMs: Long = System.currentTimeMillis()
    ): AccountStateRecord = withContext(ioDispatcher) {
        require(amountUnits >= 0L) { "Credit amount cannot be negative" }
        mutex.withLock {
            val existing = stateMap[address] ?: AccountStateRecord(address = address)
            val newBal = BigInteger.valueOf(existing.balanceUnits)
                .add(BigInteger.valueOf(amountUnits))
                .longValueExact()
            val updated = existing.copy(
                balanceUnits = newBal,
                updatedAtHeight = maxOf(existing.updatedAtHeight, atHeight),
                updatedAtMs = nowMs
            )
            stateMap[address] = updated
            storage.upsertAccountStates(listOf(updated))
            publishSnapshotLocked()
            updated
        }
    }

    /**
     * Deterministically previews state root for a candidate block without mutating persisted state.
     */
    suspend fun previewBlockStateRoot(
        transactions: List<NmdTransaction>,
        blockHeight: Long,
        parameters: BlockchainParameters = BlockchainParameters(),
        proposerAddress: String? = null,
        nowMs: Long = System.currentTimeMillis()
    ): String = withContext(ioDispatcher) {
        mutex.withLock {
            val working = HashMap<String, AccountStateRecord>(stateMap)
            val outcome = executeTransactionsInMemory(
                working = working,
                transactions = transactions,
                blockHeight = blockHeight,
                parameters = parameters,
                proposerAddress = proposerAddress,
                nowMs = nowMs,
                enforceBalances = enforceStrictBalances
            )
            outcome.newStateRoot
        }
    }

    /**
     * Atomically executes finalized block transactions into [AccountStateRecord]s and persists them.
     */
    suspend fun applyFinalizedBlock(
        transactions: List<NmdTransaction>,
        blockHeight: Long,
        parameters: BlockchainParameters = BlockchainParameters(),
        proposerAddress: String? = null,
        nowMs: Long = System.currentTimeMillis()
    ): BlockStateTransitionResult = withContext(ioDispatcher) {
        mutex.withLock {
            if (blockHeight > 0L && blockHeight <= lastAppliedHeight) {
                return@withLock BlockStateTransitionResult(
                    newStateRoot = _stateRoot.value,
                    appliedTxIds = emptyList(),
                    rejectedTxReasons = emptyMap(),
                    totalBurnedUnits = 0L,
                    totalDistributedFeesUnits = 0L,
                    validatorRegistrations = emptyList(),
                    validatorExits = emptyList()
                )
            }
            val working = HashMap<String, AccountStateRecord>(stateMap)
            val beforeKeys = working.keys.toSet()
            val beforeSnapshot = HashMap(working)

            val outcome = executeTransactionsInMemory(
                working = working,
                transactions = transactions,
                blockHeight = blockHeight,
                parameters = parameters,
                proposerAddress = proposerAddress,
                nowMs = nowMs,
                enforceBalances = enforceStrictBalances
            )

            val changed = mutableListOf<AccountStateRecord>()
            working.forEach { (addr, rec) ->
                if (!beforeKeys.contains(addr) || beforeSnapshot[addr] != rec) {
                    changed.add(rec)
                }
            }
            if (changed.isNotEmpty()) {
                storage.upsertAccountStates(changed)
            }
            stateMap.clear()
            working.entries.sortedBy { it.key }.forEach { (k, v) -> stateMap[k] = v }
            if (blockHeight > lastAppliedHeight) {
                lastAppliedHeight = blockHeight
            }
            publishSnapshotLocked()
            outcome
        }
    }

    private fun executeTransactionsInMemory(
        working: MutableMap<String, AccountStateRecord>,
        transactions: List<NmdTransaction>,
        blockHeight: Long,
        parameters: BlockchainParameters,
        proposerAddress: String?,
        nowMs: Long,
        enforceBalances: Boolean
    ): BlockStateTransitionResult {
        val appliedIds = mutableListOf<String>()
        val rejected = linkedMapOf<String, String>()
        val validatorRegs = mutableListOf<ValidatorTransactionPayload>()
        val validatorExits = mutableListOf<ValidatorTransactionPayload>()
        var totalFeesCollected = BigInteger.ZERO
        var totalBurned = BigInteger.ZERO

        for (tx in transactions) {
            val senderState = working[tx.senderAddress] ?: AccountStateRecord(address = tx.senderAddress)
            val totalCost = BigInteger.valueOf(tx.amountUnits).add(BigInteger.valueOf(tx.feeUnits))
            val senderBal = BigInteger.valueOf(senderState.balanceUnits)

            if (enforceBalances && senderBal < totalCost) {
                rejected[tx.txId] = "Insufficient balance: has=${senderState.balanceUnits}, needs=$totalCost"
                continue
            }

            // Deduct cost only if strict balances enabled OR sender actually holds sufficient funds
            val deductUnits = if (enforceBalances || senderBal >= totalCost) totalCost else BigInteger.ZERO
            val newSenderBal = senderBal.subtract(deductUnits).coerceAtLeast(BigInteger.ZERO).longValueExact()
            val nextNonce = maxOf(senderState.confirmedNonce, tx.nonce + 1L)

            var senderIsValidator = senderState.isValidator
            when (tx.txType) {
                TransactionType.VALIDATOR_REGISTER -> {
                    ValidatorTransactionPayload.fromBytes(tx.payload)?.let {
                        validatorRegs.add(it)
                        senderIsValidator = true
                    }
                }
                TransactionType.VALIDATOR_EXIT -> {
                    ValidatorTransactionPayload.fromBytes(tx.payload)?.let {
                        validatorExits.add(it)
                        senderIsValidator = false
                    }
                }
                else -> Unit
            }

            working[tx.senderAddress] = senderState.copy(
                balanceUnits = newSenderBal,
                confirmedNonce = nextNonce,
                isValidator = senderIsValidator,
                updatedAtHeight = blockHeight,
                updatedAtMs = nowMs
            )

            // Credit recipient on TRANSFER when balance was transferred
            if (tx.txType == TransactionType.TRANSFER && tx.amountUnits > 0L) {
                val transferAmount = if (deductUnits >= BigInteger.valueOf(tx.amountUnits)) tx.amountUnits else 0L
                if (transferAmount > 0L) {
                    val recState = working[tx.recipientAddress] ?: AccountStateRecord(address = tx.recipientAddress)
                    val recNewBal = BigInteger.valueOf(recState.balanceUnits)
                        .add(BigInteger.valueOf(transferAmount))
                        .longValueExact()
                    working[tx.recipientAddress] = recState.copy(
                        balanceUnits = recNewBal,
                        updatedAtHeight = blockHeight,
                        updatedAtMs = nowMs
                    )
                }
            }

            if (deductUnits > BigInteger.ZERO && tx.feeUnits > 0L) {
                totalFeesCollected = totalFeesCollected.add(BigInteger.valueOf(tx.feeUnits))
            }
            appliedIds.add(tx.txId)
        }

        // Distribute collected transaction fees deterministically if any fees accrued
        val feesLong = totalFeesCollected.longValueExact()
        if (feesLong > 0L) {
            if (TokenomicsEngine.isTokenIssuanceActive(parameters)) {
                val split = TokenomicsEngine.distributeUnits(feesLong)
                creditWorkingAccount(working, FOUNDER_VESTING_ADDRESS, split.founderUnits, blockHeight, nowMs)
                creditWorkingAccount(working, TREASURY_ADDRESS, split.treasuryUnits, blockHeight, nowMs)
                creditWorkingAccount(working, BURN_SINK_ADDRESS, split.burnedUnits, blockHeight, nowMs)
                totalBurned = totalBurned.add(BigInteger.valueOf(split.burnedUnits))
                if (split.validatorsPoolUnits > 0L && !proposerAddress.isNullOrBlank()) {
                    creditWorkingAccount(working, proposerAddress, split.validatorsPoolUnits, blockHeight, nowMs)
                }
            } else {
                // Pre-mainnet: burn/sink collected fee deterministically so total dev supply never expands
                creditWorkingAccount(working, BURN_SINK_ADDRESS, feesLong, blockHeight, nowMs)
                totalBurned = totalBurned.add(BigInteger.valueOf(feesLong))
            }
        }

        val stateRoot = computeCanonicalStateRoot(working.values)
        return BlockStateTransitionResult(
            newStateRoot = stateRoot,
            appliedTxIds = appliedIds,
            rejectedTxReasons = rejected,
            totalBurnedUnits = totalBurned.longValueExact(),
            totalDistributedFeesUnits = feesLong,
            validatorRegistrations = validatorRegs,
            validatorExits = validatorExits
        )
    }

    private fun creditWorkingAccount(
        working: MutableMap<String, AccountStateRecord>,
        address: String,
        units: Long,
        blockHeight: Long,
        nowMs: Long
    ) {
        if (units <= 0L) return
        val cur = working[address] ?: AccountStateRecord(address = address)
        val newBal = BigInteger.valueOf(cur.balanceUnits).add(BigInteger.valueOf(units)).longValueExact()
        working[address] = cur.copy(
            balanceUnits = newBal,
            updatedAtHeight = blockHeight,
            updatedAtMs = nowMs
        )
    }

    private fun publishSnapshotLocked(): String {
        val sorted = stateMap.entries.sortedBy { it.key }.associate { it.toPair() }
        _accounts.value = sorted
        val root = computeCanonicalStateRoot(sorted.values)
        _stateRoot.value = root
        return root
    }

    fun computeCanonicalStateRoot(records: Collection<AccountStateRecord>): String {
        val baos = ByteArrayOutputStream(256)
        val dos = DataOutputStream(baos)
        dos.write(STATE_ROOT_DOMAIN)
        val sorted = records.sortedBy { it.address }
        dos.writeInt(sorted.size)
        for (rec in sorted) {
            val addrBytes = rec.address.toByteArray(Charsets.UTF_8)
            dos.writeInt(addrBytes.size)
            dos.write(addrBytes)
            dos.writeLong(rec.balanceUnits)
            dos.writeLong(rec.confirmedNonce)
            dos.writeBoolean(rec.isValidator)
        }
        dos.flush()
        return cryptoProvider.toHex(cryptoProvider.sha256(baos.toByteArray()))
    }
}
