package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark

@Composable
fun ManualConnectDialog(
    onDismiss: () -> Unit,
    onConnect: (host: String, port: Int, claimedNodeId: String?) -> Unit
) {
    var hostText by remember { mutableStateOf("192.168.1.") }
    var portText by remember { mutableStateOf("9876") }
    var claimedNodeIdText by remember { mutableStateOf("") }
    var isInputValid by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("manual_connect_dialog"),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = stringResource(R.string.p2p_manual_connect_dialog_title),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )

                Text(
                    text = stringResource(R.string.p2p_manual_connect_dialog_desc),
                    fontSize = 12.sp,
                    color = NmdTextSecondaryDark
                )

                OutlinedTextField(
                    value = hostText,
                    onValueChange = {
                        hostText = it
                        isInputValid = true
                    },
                    label = { Text(stringResource(R.string.p2p_field_host_label)) },
                    placeholder = { Text("192.168.1.50") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("p2p_input_host"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    singleLine = true
                )

                OutlinedTextField(
                    value = portText,
                    onValueChange = {
                        portText = it
                        isInputValid = true
                    },
                    label = { Text(stringResource(R.string.p2p_field_port_label)) },
                    placeholder = { Text("9876") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("p2p_input_port"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    singleLine = true
                )

                OutlinedTextField(
                    value = claimedNodeIdText,
                    onValueChange = { claimedNodeIdText = it },
                    label = { Text(stringResource(R.string.p2p_field_node_id_optional_label)) },
                    placeholder = { Text("nmd_node_...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("p2p_input_node_id"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdTextSecondaryDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                    ) {
                        Text(stringResource(R.string.dialog_close))
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val port = portText.toIntOrNull()
                            if (hostText.isNotBlank() && port != null && port in 1..65535) {
                                val optionalId = claimedNodeIdText.trim().ifEmpty { null }
                                onConnect(hostText.trim(), port, optionalId)
                                onDismiss()
                            } else {
                                isInputValid = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("p2p_dialog_connect_submit")
                    ) {
                        Text(
                            text = stringResource(R.string.p2p_action_connect),
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
