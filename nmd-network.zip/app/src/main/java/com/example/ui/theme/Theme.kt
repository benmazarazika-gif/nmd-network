package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val NmdDarkColorScheme = darkColorScheme(
    primary = NmdElectricCyan,
    onPrimary = Color(0xFF040A18),
    primaryContainer = Color(0xFF0D2847),
    onPrimaryContainer = NmdCyanBright,
    secondary = NmdElectricBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF132238),
    onSecondaryContainer = Color(0xFFD4E3FC),
    tertiary = NmdSuccessGreen,
    onTertiary = Color.Black,
    background = NmdDarkBackground,
    onBackground = NmdTextPrimaryDark,
    surface = NmdDarkSurface,
    onSurface = NmdTextPrimaryDark,
    surfaceVariant = NmdDarkCard,
    onSurfaceVariant = NmdTextSecondaryDark,
    outline = NmdDarkCardBorder,
    outlineVariant = Color(0xFF1A2640)
)

private val NmdLightColorScheme = lightColorScheme(
    primary = Color(0xFF0066CC),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7EAFF),
    onPrimaryContainer = Color(0xFF001D3D),
    secondary = Color(0xFF0077FE),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE2EDFC),
    onSecondaryContainer = Color(0xFF001B3F),
    tertiary = Color(0xFF107C41),
    onTertiary = Color.White,
    background = NmdLightBackground,
    onBackground = NmdTextPrimaryLight,
    surface = NmdLightSurface,
    onSurface = NmdTextPrimaryLight,
    surfaceVariant = Color(0xFFEDF2F7),
    onSurfaceVariant = NmdTextSecondaryLight,
    outline = NmdLightCardBorder,
    outlineVariant = Color(0xFFCBD5E1)
)

@Composable
fun NmdNetworkTheme(
    darkTheme: Boolean = true, // Default to dark per project requirements
    dynamicColor: Boolean = false, // Keep consistent cyber/blockchain branding
    content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> NmdDarkColorScheme
    else -> NmdLightColorScheme
  }

  MaterialTheme(
      colorScheme = colorScheme,
      typography = Typography,
      content = content
  )
}
