package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SettingsEthernet
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.p2p.infrastructure.model.BootstrapEndpointConfig
import com.example.p2p.infrastructure.model.BootstrapTransportProtocol
import com.example.p2p.infrastructure.model.NetworkInfrastructureSnapshot
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.infrastructure.model.SignalingEndpointConfig
import com.example.p2p.infrastructure.model.SignalingTransportStatus
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun PublicNetworkInfraSection(
    snapshot: NetworkInfrastructureSnapshot,
    onBootstrapAndSync: () -> Unit,
    onProbeHealth: () -> Unit,
    onReconnectSignaling: () -> Unit,
    onApplyConfiguration: (
        NmdNetworkProfile,
        List<BootstrapEndpointConfig>,
        List<SignalingEndpointConfig>,
        Boolean
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var showConfigDialog by remember { mutableStateOf(false) }

    if (showConfigDialog) {
        InfrastructureAdminDialog(
            currentSnapshot = snapshot,
            onDismiss = { showConfigDialog = false },
            onConfirmedApply = { profile, boot, sig, activateMainnet ->
                onApplyConfiguration(profile, boot, sig, activateMainnet)
                showConfigDialog = false
            }
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stage15_public_infra_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudQueue,
                        contentDescription = stringResource(R.string.stage15_infra_title),
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage15_infra_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Surface(
                    color = NmdElectricCyan.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, NmdElectricCyan.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = stringResource(R.string.stage15_badge_infra),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdElectricCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = stringResource(R.string.stage15_infra_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            val profileLabel = when (snapshot.activeProfile) {
                NmdNetworkProfile.DEVELOPMENT -> stringResource(R.string.stage15_profile_dev)
                NmdNetworkProfile.TESTNET -> stringResource(R.string.stage15_profile_testnet)
                NmdNetworkProfile.MAINNET -> if (snapshot.isMainnetActivated) {
                    stringResource(R.string.stage15_profile_mainnet_active)
                } else {
                    stringResource(R.string.stage15_profile_mainnet_disabled)
                }
            }
            val profileColor = when (snapshot.activeProfile) {
                NmdNetworkProfile.DEVELOPMENT -> NmdWarningOrange
                NmdNetworkProfile.TESTNET -> NmdElectricCyan
                NmdNetworkProfile.MAINNET -> if (snapshot.isMainnetActivated) NmdSuccessGreen else NmdDangerRed
            }

            InfraDiagRow(
                label = stringResource(R.string.stage15_field_profile),
                value = profileLabel,
                valueColor = profileColor,
                isMonospace = true,
                valueTag = "stage15_active_profile_value"
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_chain_id),
                value = snapshot.chainId,
                valueColor = NmdCyanBright,
                isMonospace = true,
                valueTag = "stage15_chain_id_value"
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_genesis_hash),
                value = snapshot.shortenedGenesisHash,
                valueColor = NmdTextPrimaryDark,
                isMonospace = true,
                valueTag = "stage15_genesis_hash_value"
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_configured_bootstrap),
                value = "${snapshot.configuredBootstrapCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_healthy_bootstrap),
                value = "${snapshot.healthyBootstrapCount} / ${snapshot.unavailableBootstrapCount}",
                valueColor = if (snapshot.unavailableBootstrapCount > 0) NmdWarningOrange else NmdSuccessGreen,
                isMonospace = true
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_active_signaling),
                value = snapshot.activeSignalingEndpoint ?: stringResource(R.string.stage15_none_configured),
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            val sigStatusColor = when (snapshot.signalingStatus) {
                SignalingTransportStatus.AUTHENTICATED, SignalingTransportStatus.CONNECTED -> NmdSuccessGreen
                SignalingTransportStatus.CONNECTING, SignalingTransportStatus.RECONNECTING -> NmdWarningOrange
                SignalingTransportStatus.DISCONNECTED -> NmdTextSecondaryDark
                SignalingTransportStatus.TLS_ERROR, SignalingTransportStatus.FAILED -> NmdDangerRed
            }
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_signaling_status),
                value = snapshot.signalingStatus.name,
                valueColor = sigStatusColor,
                isMonospace = true,
                valueTag = "stage15_signaling_status_value"
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_discovered_peers),
                value = "${snapshot.discoveredPeersCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_authenticated_peers),
                value = "${snapshot.authenticatedPeersCount}",
                valueColor = NmdSuccessGreen,
                isMonospace = true
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_direct_relay),
                value = "${snapshot.directConnectionsCount} / ${snapshot.relayConnectionsCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_last_refresh),
                value = formatEpochTime(snapshot.lastDirectoryRefreshMs) ?: stringResource(R.string.stage15_never_recorded),
                valueColor = NmdTextSecondaryDark,
                isMonospace = true
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_last_bootstrap),
                value = formatEpochTime(snapshot.lastBootstrapSuccessMs) ?: stringResource(R.string.stage15_never_recorded),
                valueColor = NmdTextSecondaryDark,
                isMonospace = true
            )
            InfraDiagRow(
                label = stringResource(R.string.stage15_field_endpoint_failures),
                value = "${snapshot.currentEndpointFailures}",
                valueColor = if (snapshot.currentEndpointFailures > 0) NmdDangerRed else NmdTextPrimaryDark,
                isMonospace = true
            )

            Text(
                text = snapshot.lastStatusSummary,
                fontSize = 10.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 14.sp,
                modifier = Modifier.testTag("stage15_last_status_summary")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onBootstrapAndSync,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage15_bootstrap_sync_btn"),
                    border = BorderStroke(1.dp, NmdElectricCyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = stringResource(R.string.stage15_action_bootstrap_sync),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage15_action_bootstrap_sync),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = onProbeHealth,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage15_probe_health_btn"),
                    border = BorderStroke(1.dp, NmdSuccessGreen),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdSuccessGreen),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = stringResource(R.string.stage15_action_probe_health),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage15_action_probe_health),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onReconnectSignaling,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage15_reconnect_wss_btn"),
                    border = BorderStroke(1.dp, NmdWarningOrange),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdWarningOrange),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = stringResource(R.string.stage15_action_reconnect_sig),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage15_action_reconnect_sig),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Button(
                    onClick = { showConfigDialog = true },
                    modifier = Modifier
                        .weight(1.3f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage15_configure_infra_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NmdElectricBlue.copy(alpha = 0.25f),
                        contentColor = NmdCyanBright
                    ),
                    border = BorderStroke(1.dp, NmdElectricBlue),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SettingsEthernet,
                        contentDescription = stringResource(R.string.stage15_action_configure_endpoints),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage15_action_configure_endpoints),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun InfrastructureAdminDialog(
    currentSnapshot: NetworkInfrastructureSnapshot,
    onDismiss: () -> Unit,
    onConfirmedApply: (
        NmdNetworkProfile,
        List<BootstrapEndpointConfig>,
        List<SignalingEndpointConfig>,
        Boolean
    ) -> Unit
) {
    var selectedProfile by remember { mutableStateOf(currentSnapshot.activeProfile) }
    var bootstrapHost by remember { mutableStateOf(currentSnapshot.bootstrapEndpoints.firstOrNull()?.host.orEmpty()) }
    var bootstrapPort by remember { mutableStateOf(currentSnapshot.bootstrapEndpoints.firstOrNull()?.port?.toString() ?: "8844") }
    var signalingUrl by remember { mutableStateOf(currentSnapshot.signalingEndpoints.firstOrNull()?.url.orEmpty()) }
    var tlsPin by remember { mutableStateOf(currentSnapshot.bootstrapEndpoints.firstOrNull()?.pinnedTlsSha256.orEmpty()) }
    var requireTls by remember { mutableStateOf(selectedProfile != NmdNetworkProfile.DEVELOPMENT) }
    var validationError by remember { mutableStateOf<String?>(null) }
    var pendingConfirmation by remember { mutableStateOf(false) }

    if (pendingConfirmation) {
        AlertDialog(
            onDismissRequest = { pendingConfirmation = false },
            containerColor = NmdDarkCard,
            title = {
                Text(
                    text = stringResource(R.string.stage15_confirm_title),
                    color = NmdTextPrimaryDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.stage15_confirm_body),
                    color = NmdTextSecondaryDark,
                    fontSize = 12.sp
                )
            },
            confirmButton = {
                Button(
                    modifier = Modifier.testTag("stage15_confirm_apply_btn"),
                    onClick = {
                        val (boot, sig) = buildValidatedEndpoints(
                            selectedProfile = selectedProfile,
                            host = bootstrapHost,
                            portText = bootstrapPort,
                            signalingUrl = signalingUrl,
                            tlsPin = tlsPin,
                            requireTls = requireTls
                        )
                        onConfirmedApply(
                            selectedProfile,
                            boot,
                            sig,
                            selectedProfile == NmdNetworkProfile.MAINNET
                        )
                    }
                ) {
                    Text(stringResource(R.string.stage15_confirm_apply))
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingConfirmation = false }) {
                    Text(stringResource(R.string.stage14_dialog_cancel), color = NmdTextSecondaryDark)
                }
            }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NmdDarkCard,
        title = {
            Text(
                text = stringResource(R.string.stage15_dialog_title),
                color = NmdTextPrimaryDark,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    NmdNetworkProfile.entries.forEach { profile ->
                        FilterChip(
                            selected = selectedProfile == profile,
                            onClick = {
                                selectedProfile = profile
                                if (profile != NmdNetworkProfile.DEVELOPMENT) requireTls = true
                                validationError = null
                            },
                            label = { Text(profile.name, fontSize = 10.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = bootstrapHost,
                    onValueChange = { bootstrapHost = it; validationError = null },
                    label = { Text(stringResource(R.string.stage15_dialog_bootstrap_host_hint), fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = bootstrapPort,
                    onValueChange = { bootstrapPort = it; validationError = null },
                    label = { Text(stringResource(R.string.stage15_dialog_bootstrap_port_hint), fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = signalingUrl,
                    onValueChange = { signalingUrl = it; validationError = null },
                    label = { Text(stringResource(R.string.stage15_dialog_signaling_url_hint), fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tlsPin,
                    onValueChange = { tlsPin = it; validationError = null },
                    label = { Text(stringResource(R.string.stage15_dialog_tls_pin_hint), fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = requireTls,
                        onCheckedChange = { requireTls = it },
                        enabled = selectedProfile == NmdNetworkProfile.DEVELOPMENT
                    )
                    Text(
                        text = stringResource(R.string.stage15_dialog_require_tls),
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark
                    )
                }
                validationError?.let { err ->
                    Text(text = err, fontSize = 11.sp, color = NmdDangerRed)
                }
            }
        },
        confirmButton = {
            Button(
                modifier = Modifier.testTag("stage15_dialog_save_btn"),
                onClick = {
                    val (boot, sig) = buildValidatedEndpoints(
                        selectedProfile = selectedProfile,
                        host = bootstrapHost,
                        portText = bootstrapPort,
                        signalingUrl = signalingUrl,
                        tlsPin = tlsPin,
                        requireTls = requireTls
                    )
                    val firstBootErr = boot.firstOrNull()?.validateForProfile(selectedProfile)
                    val firstSigErr = sig.firstOrNull()?.validateForProfile(selectedProfile)
                    val err = firstBootErr ?: firstSigErr ?: if (selectedProfile == NmdNetworkProfile.MAINNET && (boot.isEmpty() || sig.isEmpty())) {
                        "Mainnet requires both a valid HTTPS bootstrap endpoint and a wss:// signaling endpoint"
                    } else null
                    if (err != null) {
                        validationError = err
                    } else {
                        pendingConfirmation = true
                    }
                }
            ) {
                Text(stringResource(R.string.stage14_dialog_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.stage14_dialog_cancel), color = NmdTextSecondaryDark)
            }
        }
    )
}

private fun buildValidatedEndpoints(
    selectedProfile: NmdNetworkProfile,
    host: String,
    portText: String,
    signalingUrl: String,
    tlsPin: String,
    requireTls: Boolean
): Pair<List<BootstrapEndpointConfig>, List<SignalingEndpointConfig>> {
    val cleanPin = tlsPin.trim().ifBlank { null }
    val boot = if (host.isNotBlank()) {
        val port = portText.trim().toIntOrNull() ?: 8844
        listOf(
            BootstrapEndpointConfig(
                id = "boot_${UUID.randomUUID().toString().take(8)}",
                name = "${selectedProfile.name} Bootstrap",
                host = host.trim(),
                port = port,
                protocol = if (requireTls) BootstrapTransportProtocol.HTTPS else BootstrapTransportProtocol.HTTP_DEV_ONLY,
                requireTls = requireTls,
                pinnedTlsSha256 = cleanPin,
                networkProfile = selectedProfile,
                priority = 1
            )
        )
    } else emptyList()

    val sig = if (signalingUrl.isNotBlank()) {
        listOf(
            SignalingEndpointConfig(
                id = "sig_${UUID.randomUUID().toString().take(8)}",
                name = "${selectedProfile.name} Signaling",
                url = signalingUrl.trim(),
                requireTls = requireTls,
                pinnedTlsSha256 = cleanPin,
                networkProfile = selectedProfile,
                priority = 1
            )
        )
    } else emptyList()

    return boot to sig
}

private fun formatEpochTime(epochMs: Long?): String? {
    if (epochMs == null || epochMs <= 0L) return null
    return SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(epochMs))
}

@Composable
private fun InfraDiagRow(
    label: String,
    value: String,
    valueColor: Color,
    isMonospace: Boolean,
    valueTag: String? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = if (valueTag != null) Modifier.testTag(valueTag) else Modifier
        )
    }
}
