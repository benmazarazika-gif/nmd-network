package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Headset
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.R
import com.example.blockchain.config.BlockchainConfig
import com.example.crypto.NodeIdentityManager
import com.example.data.AppLanguage
import com.example.service.NmdNodeForegroundService
import com.example.transaction.crypto.NmdAddressCodec
import com.example.ui.components.FeatureNoticeDialog
import com.example.ui.components.LanguageSelectionDialog
import com.example.ui.components.NmdLogoBadge
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark

@Composable
fun ProfileScreen(
    currentLanguage: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit,
    onBack: () -> Unit,
    onNavigateToSecurity: () -> Unit = {},
    onNavigateToNetwork: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val identityManager = remember(context.applicationContext) {
        NodeIdentityManager(context.applicationContext)
    }
    val activeIdentity by identityManager.identity.collectAsState()
    val isServiceRunning by NmdNodeForegroundService.isRunning.collectAsState()

    val derivedAddress = remember(activeIdentity) {
        activeIdentity?.publicKeyHex?.let {
            NmdAddressCodec.deriveAddressFromPublicKeyHex(it)
        }
    }

    var showLanguageDialog by remember { mutableStateOf(false) }
    var showResetIdentityDialog by remember { mutableStateOf(false) }
    var noticeTitle by remember { mutableStateOf<String?>(null) }
    var noticeMessage by remember { mutableStateOf<String?>(null) }

    val notificationsTitle = stringResource(R.string.profile_notifications)
    val notificationsMessage = if (isServiceRunning) {
        stringResource(R.string.stage19_notifications_enabled_desc)
    } else {
        stringResource(R.string.stage19_notifications_stopped_desc)
    }
    val aboutTitle = stringResource(R.string.profile_about)
    val aboutMessage = stringResource(
        R.string.stage19_about_desc,
        BuildConfig.VERSION_NAME,
        BuildConfig.APPLICATION_ID,
        BlockchainConfig().chainId
    )

    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguage = currentLanguage,
            onSelectLanguage = onLanguageChange,
            onDismiss = { showLanguageDialog = false }
        )
    }

    if (noticeTitle != null && noticeMessage != null) {
        FeatureNoticeDialog(
            title = noticeTitle!!,
            message = noticeMessage!!,
            onDismiss = {
                noticeTitle = null
                noticeMessage = null
            }
        )
    }

    if (showResetIdentityDialog) {
        AlertDialog(
            onDismissRequest = { showResetIdentityDialog = false },
            containerColor = NmdDarkCard,
            title = {
                Text(
                    text = stringResource(R.string.stage19_profile_reset_identity),
                    color = NmdTextPrimaryDark,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.stage19_profile_reset_desc),
                    color = NmdTextSecondaryDark,
                    style = MaterialTheme.typography.bodySmall
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        identityManager.deleteIdentity()
                        showResetIdentityDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NmdDangerRed)
                ) {
                    Text(stringResource(R.string.stage19_profile_reset_confirm), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetIdentityDialog = false }) {
                    Text(stringResource(R.string.stage14_dialog_cancel), color = NmdTextSecondaryDark)
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("profile_screen_content")
    ) {
        // Screen Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NmdDarkCard)
                    .testTag("profile_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Text(
                text = stringResource(R.string.nav_profile),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
            )

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NmdDarkCard),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Node Identity Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0x6600D2FF), Color(0x220077FE))
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .testTag("profile_user_card"),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NmdLogoBadge(size = 54.dp, fontSize = 26)

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = activeIdentity?.nodeId?.let { "NMD Node ${it.take(10)}..." }
                                ?: stringResource(R.string.stage19_main_account_title),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                        if (activeIdentity != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified",
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = derivedAddress?.let { "${it.take(14)}...${it.takeLast(8)}" }
                            ?: stringResource(R.string.stage19_no_identity_prompt),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Settings Items List Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
                // Security & Key Backup
                ProfileMenuItem(
                    icon = Icons.Default.Security,
                    title = stringResource(R.string.stage19_profile_backup_action),
                    onClick = onNavigateToSecurity,
                    testTag = "menu_security"
                )

                // Language Selector
                ProfileMenuItem(
                    icon = Icons.Outlined.Language,
                    title = stringResource(R.string.profile_language),
                    trailingText = currentLanguage.nativeName,
                    onClick = { showLanguageDialog = true },
                    testTag = "menu_language"
                )

                // Node Background Sync Notification Status
                ProfileMenuItem(
                    icon = Icons.Default.Notifications,
                    title = stringResource(R.string.profile_notifications),
                    trailingText = if (isServiceRunning) "Active" else "Off",
                    onClick = {
                        noticeTitle = notificationsTitle
                        noticeMessage = notificationsMessage
                    },
                    testTag = "menu_notifications"
                )

                // Node Control Diagnostics
                ProfileMenuItem(
                    icon = Icons.Default.Headset,
                    title = stringResource(R.string.stage19_home_btn_node),
                    onClick = onNavigateToNetwork,
                    testTag = "menu_support"
                )

                // About & Protocol Version
                ProfileMenuItem(
                    icon = Icons.Default.Info,
                    title = stringResource(R.string.profile_about),
                    trailingText = "v${BuildConfig.VERSION_NAME}",
                    onClick = {
                        noticeTitle = aboutTitle
                        noticeMessage = aboutMessage
                    },
                    testTag = "menu_about"
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Local KeyStore Reset Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0x1FFF5252))
                .border(1.dp, Color(0x33FF5252), RoundedCornerShape(16.dp))
                .clickable { showResetIdentityDialog = true }
                .padding(vertical = 14.dp)
                .testTag("btn_logout"),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                contentDescription = null,
                tint = NmdDangerRed,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.stage19_profile_reset_identity),
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NmdDangerRed
                )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "v${BuildConfig.VERSION_NAME} • ${BlockchainConfig().chainId}",
            style = MaterialTheme.typography.bodySmall.copy(
                color = NmdTextMutedDark
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun ProfileMenuItem(
    icon: ImageVector,
    title: String,
    trailingText: String? = null,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NmdElectricCyan,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = NmdTextPrimaryDark
                )
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (trailingText != null) {
                Text(
                    text = trailingText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NmdCyanBright,
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = NmdTextMutedDark,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
