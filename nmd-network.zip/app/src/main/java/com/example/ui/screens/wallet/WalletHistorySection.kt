package com.example.ui.screens.wallet

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.ActivityType
import com.example.data.TransactionFilterType
import com.example.data.TransactionStatus
import com.example.data.TransactionStatusFilter
import com.example.data.WalletTransaction
import com.example.transaction.model.MempoolTransactionRecord
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdSuccessGreenBg
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun WalletHistorySection(
    transactions: List<WalletTransaction>,
    searchQuery: String,
    typeFilter: TransactionFilterType,
    statusFilter: TransactionStatusFilter,
    selectedTransaction: WalletTransaction?,
    onSearchChange: (String) -> Unit,
    onTypeFilterChange: (TransactionFilterType) -> Unit,
    onStatusFilterChange: (TransactionStatusFilter) -> Unit,
    onSelectTransaction: (WalletTransaction?) -> Unit,
    onBackToOverview: () -> Unit,
    modifier: Modifier = Modifier,
    signedMempoolRecords: List<MempoolTransactionRecord> = emptyList()
) {
    val clipboardManager: ClipboardManager = LocalClipboardManager.current

    // Filter transactions
    val filtered = transactions.filter { tx ->
        val matchesSearch = if (searchQuery.isBlank()) true else {
            tx.txHash.contains(searchQuery, ignoreCase = true) ||
            tx.counterpartyAddress.contains(searchQuery, ignoreCase = true)
        }

        val matchesType = when (typeFilter) {
            TransactionFilterType.ALL -> true
            TransactionFilterType.SENT -> tx.type == ActivityType.SEND
            TransactionFilterType.RECEIVED -> tx.type == ActivityType.RECEIVE
            TransactionFilterType.REWARDS -> tx.type == ActivityType.REWARD
        }

        val matchesStatus = when (statusFilter) {
            TransactionStatusFilter.ALL -> true
            TransactionStatusFilter.DEMO -> tx.status == TransactionStatus.DEMO
            TransactionStatusFilter.CONFIRMED -> tx.status == TransactionStatus.CONFIRMED
            TransactionStatusFilter.PENDING -> tx.status == TransactionStatus.PENDING
        }

        matchesSearch && matchesType && matchesStatus
    }

    // Detail Dialog
    if (selectedTransaction != null) {
        TransactionDetailDialog(
            transaction = selectedTransaction,
            onDismiss = { onSelectTransaction(null) },
            onCopyHash = { hash ->
                clipboardManager.setText(AnnotatedString(hash))
            }
        )
    }

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToOverview,
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F1A30))
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                    .testTag("history_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Overview",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = stringResource(R.string.history_screen_title),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )
                Text(
                    text = stringResource(R.string.stage19_history_subtitle),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NmdElectricCyan,
                        fontSize = 11.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = {
                Text(
                    stringResource(R.string.history_search_hint),
                    color = NmdTextMutedDark,
                    fontSize = 12.sp
                )
            },
            trailingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("history_search_input"),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0F1A30),
                unfocusedContainerColor = Color(0xFF0F1A30),
                focusedBorderColor = NmdElectricCyan,
                unfocusedBorderColor = NmdDarkCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Type Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val typeItems = listOf(
                TransactionFilterType.ALL to stringResource(R.string.history_filter_all),
                TransactionFilterType.SENT to stringResource(R.string.history_filter_sent),
                TransactionFilterType.RECEIVED to stringResource(R.string.history_filter_received),
                TransactionFilterType.REWARDS to stringResource(R.string.history_filter_rewards)
            )

            typeItems.forEach { (type, label) ->
                val isSelected = typeFilter == type
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NmdElectricBlue else Color(0xFF10192D))
                        .border(1.dp, if (isSelected) NmdElectricCyan else NmdDarkCardBorder, RoundedCornerShape(10.dp))
                        .clickable { onTypeFilterChange(type) }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .testTag("filter_type_${type.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else NmdTextSecondaryDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Status Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val statusItems = listOf(
                TransactionStatusFilter.ALL to stringResource(R.string.history_status_all),
                TransactionStatusFilter.DEMO to stringResource(R.string.history_status_demo),
                TransactionStatusFilter.PENDING to stringResource(R.string.history_status_pending),
                TransactionStatusFilter.CONFIRMED to stringResource(R.string.history_status_confirmed)
            )

            statusItems.forEach { (status, label) ->
                val isSelected = statusFilter == status
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF162D55) else Color(0xFF0C1424))
                        .border(1.dp, if (isSelected) NmdCyanBright else NmdDarkCardBorder, RoundedCornerShape(8.dp))
                        .clickable { onStatusFilterChange(status) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("filter_status_${status.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) NmdCyanBright else NmdTextMutedDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Transaction List or Empty State
        if (filtered.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp)
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = NmdTextMutedDark,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = stringResource(R.string.history_empty_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.history_empty_subtitle),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    filtered.forEachIndexed { index, tx ->
                        TransactionRowItem(
                            tx = tx,
                            onClick = { onSelectTransaction(tx) }
                        )
                        if (index < filtered.size - 1) {
                            Spacer(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .padding(vertical = 4.dp)
                                    .background(Color(0x1A1E2D4E))
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Stage 9: Persistent Signed Mempool History (Strictly Unconfirmed)
        SignedMempoolHistoryCard(records = signedMempoolRecords)
    }
}

@Composable
fun TransactionRowItem(
    tx: WalletTransaction,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp)
            .testTag("tx_row_${tx.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val badgeBg = when (tx.type) {
            ActivityType.RECEIVE -> NmdSuccessGreenBg
            ActivityType.SEND -> Color(0x220077FE)
            ActivityType.REWARD -> Color(0x22FF9F43)
        }
        val iconTint = when (tx.type) {
            ActivityType.RECEIVE -> NmdSuccessGreen
            ActivityType.SEND -> NmdElectricBlue
            ActivityType.REWARD -> NmdWarningOrange
        }
        val iconVector = when (tx.type) {
            ActivityType.RECEIVE -> Icons.AutoMirrored.Filled.TrendingDown
            ActivityType.SEND -> Icons.AutoMirrored.Filled.TrendingUp
            ActivityType.REWARD -> Icons.Default.CardGiftcard
        }

        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(badgeBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = iconVector,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(tx.titleRes),
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = NmdTextPrimaryDark
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = tx.timestampFormatted,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NmdTextMutedDark,
                        fontSize = 11.sp
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                // Audited Status pill: DEMO, PENDING, CONFIRMED, FAILED
                val (statusText, statusColor, statusBg) = when (tx.status) {
                    TransactionStatus.DEMO -> Triple(
                        stringResource(R.string.history_demo_badge),
                        NmdElectricCyan,
                        Color(0x2200D2FF)
                    )
                    TransactionStatus.PENDING -> Triple(
                        stringResource(R.string.history_status_pending),
                        NmdWarningOrange,
                        Color(0x22FF9F43)
                    )
                    TransactionStatus.CONFIRMED -> Triple(
                        stringResource(R.string.history_status_confirmed),
                        NmdSuccessGreen,
                        Color(0x1F38EF7D)
                    )
                    TransactionStatus.FAILED -> Triple(
                        stringResource(R.string.history_status_failed),
                        Color(0xFFFF6B6B),
                        Color(0x22FF6B6B)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = statusBg
                ) {
                    Text(
                        text = statusText,
                        color = statusColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }
            }
        }

        Text(
            text = tx.amountFormatted,
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (tx.isCredit) NmdSuccessGreen else Color(0xFFFF6B6B)
            )
        )
    }
}

@Composable
fun TransactionDetailDialog(
    transaction: WalletTransaction,
    onDismiss: () -> Unit,
    onCopyHash: (String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NmdDarkCard,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(20.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                Text(
                    text = stringResource(R.string.history_details_title),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Amount
                Text(
                    text = transaction.amountFormatted,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (transaction.isCredit) NmdSuccessGreen else Color(0xFFFF6B6B)
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                DetailItemRow(
                    label = stringResource(R.string.history_timestamp),
                    value = transaction.timestampFormatted
                )

                Spacer(modifier = Modifier.height(10.dp))

                DetailItemRow(
                    label = stringResource(R.string.history_status_all),
                    value = when (transaction.status) {
                        TransactionStatus.DEMO -> stringResource(R.string.history_status_demo)
                        TransactionStatus.CONFIRMED -> stringResource(R.string.history_status_confirmed)
                        TransactionStatus.PENDING -> stringResource(R.string.history_status_pending)
                        TransactionStatus.FAILED -> stringResource(R.string.history_status_failed)
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                DetailItemRow(
                    label = stringResource(R.string.history_block_number),
                    value = if (transaction.blockNumber > 0L) {
                        "#${transaction.blockNumber}"
                    } else {
                        stringResource(R.string.history_status_pending)
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                DetailItemRow(
                    label = stringResource(R.string.history_counterparty),
                    value = if (transaction.counterpartyAddress.length > 20) {
                        transaction.counterpartyAddress.take(12) + "..." + transaction.counterpartyAddress.takeLast(6)
                    } else {
                        transaction.counterpartyAddress.ifBlank { "-" }
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                DetailItemRow(
                    label = stringResource(R.string.wallet_fee_label),
                    value = transaction.feeFormatted
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Hash box with copy button
                Text(
                    text = stringResource(R.string.history_tx_hash),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0C1628))
                        .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(10.dp))
                        .clickable { onCopyHash(transaction.txHash) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = transaction.txHash.take(16) + "...",
                        fontSize = 11.sp,
                        color = NmdCyanBright
                    )
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy hash",
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }

                if (transaction.status == TransactionStatus.DEMO) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "ⓘ " + stringResource(R.string.send_dialog_simulation_warning),
                        fontSize = 10.sp,
                        color = NmdElectricCyan,
                        lineHeight = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                androidx.compose.material3.Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = NmdElectricBlue
                    )
                ) {
                    Text(stringResource(R.string.dialog_close), color = Color.White)
                }
            }
        }
    }
}

@Composable
fun DetailItemRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = NmdTextSecondaryDark)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = NmdTextPrimaryDark)
    }
}
