package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.p2p.connectivity.model.ConnectivityDiagnosticsSnapshot
import com.example.p2p.connectivity.model.ConnectivityState
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.StunServerStatus
import com.example.p2p.connectivity.model.TurnRelayStatus
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.connectivity.model.TurnTransportProtocol
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ConnectivityDiagnosticsSection(
    diagnostics: ConnectivityDiagnosticsSnapshot,
    onRefreshProbes: () -> Unit,
    onTriggerIceRestart: () -> Unit,
    onConfigureServers: (List<StunServerConfig>, List<TurnServerConfig>) -> Unit,
    modifier: Modifier = Modifier
) {
    var showConfigDialog by remember { mutableStateOf(false) }

    if (showConfigDialog) {
        StunTurnConfigDialog(
            onDismiss = { showConfigDialog = false },
            onSave = { stunList, turnList ->
                onConfigureServers(stunList, turnList)
                showConfigDialog = false
            }
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("nat_connectivity_diagnostics_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = stringResource(R.string.stage14_connectivity_title),
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage14_connectivity_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Surface(
                    color = NmdElectricCyan.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, NmdElectricCyan.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = stringResource(R.string.stage14_badge_ice),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdElectricCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = stringResource(R.string.stage14_nat_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            // Explicit NAT Limitation Note (STUN vs Symmetric NAT/CGNAT)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0A1426))
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = NmdWarningOrange,
                    modifier = Modifier
                        .size(15.dp)
                        .padding(top = 1.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.stage14_nat_limitation_note),
                    fontSize = 10.sp,
                    color = NmdTextSecondaryDark,
                    lineHeight = 14.sp
                )
            }

            HorizontalDivider(color = NmdDarkCardBorder)

            val (statusRes, statusColor) = connectivityStatusResAndColor(diagnostics.status)
            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_status),
                value = stringResource(statusRes),
                valueColor = statusColor,
                isMonospace = true,
                valueTag = "stage14_status_value"
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_active_path),
                value = diagnostics.activeTransportPath.name,
                valueColor = NmdCyanBright,
                isMonospace = true,
                valueTag = "stage14_active_path_value"
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_discovered_peers),
                value = "${diagnostics.totalDiscoveredPeers}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_auth_connected),
                value = "${diagnostics.authenticatedConnectedPeers}",
                valueColor = NmdSuccessGreen,
                isMonospace = true
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_direct_relayed),
                value = "${diagnostics.directConnectionsCount} / ${diagnostics.relayedConnectionsCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_ice_gathering),
                value = diagnostics.iceGatheringState.name,
                valueColor = NmdElectricCyan,
                isMonospace = true
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_ice_connection),
                value = diagnostics.iceConnectionState.name,
                valueColor = NmdElectricCyan,
                isMonospace = true
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_selected_candidate),
                value = diagnostics.selectedCandidatePairSummary
                    ?: diagnostics.selectedCandidateType?.sdpToken
                    ?: stringResource(R.string.stage14_none_recorded),
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            val stunText = if (diagnostics.stunStatus == StunServerStatus.UNCONFIGURED) {
                stringResource(R.string.stage14_stun_unconfigured)
            } else {
                "${diagnostics.stunStatus.name} (${diagnostics.stunServerCount})"
            }
            val stunColor = when (diagnostics.stunStatus) {
                StunServerStatus.AVAILABLE -> NmdSuccessGreen
                StunServerStatus.PROBING -> NmdElectricCyan
                StunServerStatus.UNCONFIGURED -> NmdTextSecondaryDark
                StunServerStatus.TIMED_OUT, StunServerStatus.UNREACHABLE -> NmdWarningOrange
            }
            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_stun_availability),
                value = stunText,
                valueColor = stunColor,
                isMonospace = true
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_public_endpoint),
                value = diagnostics.observedPublicEndpoint ?: stringResource(R.string.stage14_none_recorded),
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            val turnText = if (diagnostics.turnStatus == TurnRelayStatus.UNCONFIGURED) {
                stringResource(R.string.stage14_turn_unconfigured)
            } else {
                "${diagnostics.turnStatus.name} (${diagnostics.turnServerCount})"
            }
            val turnColor = when (diagnostics.turnStatus) {
                TurnRelayStatus.AVAILABLE, TurnRelayStatus.RELAYING, TurnRelayStatus.ALLOCATED -> NmdSuccessGreen
                TurnRelayStatus.UNCONFIGURED -> NmdTextSecondaryDark
                TurnRelayStatus.UNAVAILABLE_EXPIRED, TurnRelayStatus.UNREACHABLE, TurnRelayStatus.FAILED -> NmdDangerRed
            }
            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_turn_availability),
                value = turnText,
                valueColor = turnColor,
                isMonospace = false
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_establishment_time),
                value = diagnostics.lastConnectionEstablishmentMs?.let { "${it} ms" }
                    ?: stringResource(R.string.stage14_none_recorded),
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_network_type),
                value = diagnostics.currentNetworkType.name,
                valueColor = NmdElectricCyan,
                isMonospace = true
            )

            val changeSummary = diagnostics.lastNetworkChangeAtMs?.let { ts ->
                val fmt = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(ts))
                "${diagnostics.lastNetworkChangeReason ?: "Changed"} ($fmt)"
            } ?: stringResource(R.string.stage14_none_recorded)

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_last_network_change),
                value = changeSummary,
                valueColor = NmdTextSecondaryDark,
                isMonospace = false
            )

            DiagKeyValueRow(
                label = stringResource(R.string.stage14_field_failed_attempts),
                value = "${diagnostics.failedAttemptsCount}",
                valueColor = if (diagnostics.failedAttemptsCount > 0L) NmdDangerRed else NmdTextPrimaryDark,
                isMonospace = true
            )

            diagnostics.lastEventSummary?.let { summary ->
                Text(
                    text = "${stringResource(R.string.stage14_field_last_event)}: $summary",
                    fontSize = 10.sp,
                    color = NmdTextSecondaryDark,
                    lineHeight = 14.sp,
                    modifier = Modifier.testTag("stage14_last_event_text")
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRefreshProbes,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage14_refresh_probes_btn"),
                    border = BorderStroke(1.dp, NmdElectricCyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = stringResource(R.string.stage14_action_refresh_probes),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage14_action_refresh_probes),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = onTriggerIceRestart,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage14_ice_restart_btn"),
                    border = BorderStroke(1.dp, NmdWarningOrange),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdWarningOrange),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = stringResource(R.string.stage14_action_ice_restart),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage14_action_ice_restart),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Button(
                onClick = { showConfigDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("stage14_configure_servers_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NmdElectricBlue.copy(alpha = 0.25f),
                    contentColor = NmdCyanBright
                ),
                border = BorderStroke(1.dp, NmdElectricBlue)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = stringResource(R.string.stage14_action_configure_ice),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.stage14_action_configure_ice),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun StunTurnConfigDialog(
    onDismiss: () -> Unit,
    onSave: (List<StunServerConfig>, List<TurnServerConfig>) -> Unit
) {
    var stunUri by remember { mutableStateOf("") }
    var turnUri by remember { mutableStateOf("") }
    var turnUsername by remember { mutableStateOf("") }
    var turnCredential by remember { mutableStateOf("") }
    var turnProtocol by remember { mutableStateOf(TurnTransportProtocol.UDP) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NmdDarkCard,
        title = {
            Text(
                text = stringResource(R.string.stage14_dialog_title),
                color = NmdTextPrimaryDark,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = stunUri,
                    onValueChange = { stunUri = it },
                    label = { Text(stringResource(R.string.stage14_dialog_stun_hint), fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = turnUri,
                    onValueChange = { turnUri = it },
                    label = { Text(stringResource(R.string.stage14_dialog_turn_hint), fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = turnUsername,
                    onValueChange = { turnUsername = it },
                    label = { Text(stringResource(R.string.stage14_dialog_turn_user_hint), fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = turnCredential,
                    onValueChange = { turnCredential = it },
                    label = { Text(stringResource(R.string.stage14_dialog_turn_cred_hint), fontSize = 11.sp) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = stringResource(R.string.stage14_dialog_turn_transport),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TurnTransportProtocol.entries.forEach { proto ->
                        FilterChip(
                            selected = turnProtocol == proto,
                            onClick = { turnProtocol = proto },
                            label = { Text(proto.name, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val stunList = stunUri.split(",")
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }
                        .map { StunServerConfig(uri = it) }
                        .filter { it.isValidConfig() }
                    val turnList = if (turnUri.isNotBlank() && turnUsername.isNotBlank() && turnCredential.isNotBlank()) {
                        listOf(
                            TurnServerConfig(
                                uri = turnUri.trim(),
                                transport = turnProtocol,
                                username = turnUsername.trim(),
                                credential = turnCredential
                            )
                        ).filter { it.isValidConfig() }
                    } else emptyList()
                    onSave(stunList, turnList)
                }
            ) {
                Text(stringResource(R.string.stage14_dialog_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.stage14_dialog_cancel), color = NmdTextSecondaryDark)
            }
        }
    )
}

private fun connectivityStatusResAndColor(state: ConnectivityState): Pair<Int, Color> {
    return when (state) {
        ConnectivityState.DISCOVERING -> R.string.stage14_status_discovering to NmdElectricCyan
        ConnectivityState.GATHERING_CANDIDATES -> R.string.stage14_status_gathering to NmdElectricCyan
        ConnectivityState.CONNECTING_DIRECTLY -> R.string.stage14_status_connecting_direct to NmdWarningOrange
        ConnectivityState.CONNECTED_DIRECTLY -> R.string.stage14_status_connected_direct to NmdSuccessGreen
        ConnectivityState.CONNECTING_THROUGH_RELAY -> R.string.stage14_status_connecting_relay to NmdWarningOrange
        ConnectivityState.CONNECTED_THROUGH_RELAY -> R.string.stage14_status_connected_relay to NmdSuccessGreen
        ConnectivityState.RECONNECTING -> R.string.stage14_status_reconnecting to NmdWarningOrange
        ConnectivityState.NO_CONNECTIVITY -> R.string.stage14_status_no_connectivity to NmdDangerRed
        ConnectivityState.AUTHENTICATION_FAILED -> R.string.stage14_status_auth_failed to NmdDangerRed
    }
}

@Composable
private fun DiagKeyValueRow(
    label: String,
    value: String,
    valueColor: Color,
    isMonospace: Boolean,
    valueTag: String? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = if (valueTag != null) Modifier.testTag(valueTag) else Modifier
        )
    }
}
