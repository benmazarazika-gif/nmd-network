package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.DeviceTelemetry
import com.example.data.NetworkTelemetry
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun DeviceTelemetrySection(
    deviceTelemetry: DeviceTelemetry,
    networkTelemetry: NetworkTelemetry,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Strict Separation Disclaimer Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x1F00D2FF))
                .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(14.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = NmdElectricCyan,
                modifier = Modifier
                    .size(20.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Hardware vs Protocol Telemetry",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NmdCyanBright
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Physical device hardware metrics below are read directly from Android system services, separate from Layer-1 blockchain & P2P session state.",
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark,
                    lineHeight = 15.sp
                )
            }
        }

        // Real Device Telemetry Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0x5500D2FF), RoundedCornerShape(18.dp))
                .testTag("card_real_device_telemetry"),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header with badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0D1B36)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Smartphone,
                                contentDescription = null,
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.telemetry_device_title),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0x2200D2FF)
                    ) {
                        Text(
                            text = stringResource(R.string.telemetry_real_badge),
                            color = NmdCyanBright,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                val unavailableText = stringResource(R.string.telemetry_unavailable)
                val chargingText = stringResource(R.string.battery_charging)
                val dischargingText = stringResource(R.string.battery_discharging)

                val availRam = deviceTelemetry.getAvailableRamFormatted(unavailableText)
                val totalRam = deviceTelemetry.getTotalRamFormatted(unavailableText)
                val appRam = deviceTelemetry.getAppRamFormatted(unavailableText)
                val batteryLvl = deviceTelemetry.getBatteryPercentFormatted(unavailableText)
                val batteryState = deviceTelemetry.getBatteryStatusFormatted(chargingText, dischargingText, unavailableText)
                val netType = if (deviceTelemetry.networkType == "Unavailable") unavailableText else deviceTelemetry.networkType

                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_device_ram_avail),
                    value = availRam,
                    icon = Icons.Default.Memory,
                    iconTint = NmdElectricCyan
                )

                Spacer(modifier = Modifier.height(8.dp))

                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_device_ram_total),
                    value = totalRam,
                    icon = Icons.Default.Memory,
                    iconTint = NmdTextSecondaryDark
                )

                Spacer(modifier = Modifier.height(8.dp))

                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_device_app_ram),
                    value = appRam,
                    icon = Icons.Default.Memory,
                    iconTint = NmdElectricBlue
                )

                Spacer(modifier = Modifier.height(8.dp))

                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_device_battery_lvl),
                    value = "$batteryLvl ($batteryState)",
                    icon = Icons.Default.BatteryChargingFull,
                    iconTint = NmdSuccessGreen
                )

                Spacer(modifier = Modifier.height(8.dp))

                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_device_network_type),
                    value = netType,
                    icon = Icons.Default.Wifi,
                    iconTint = NmdCyanBright
                )

                if (deviceTelemetry.isLowRam) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x22FF9F43))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = NmdWarningOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Device is currently in low memory state",
                            fontSize = 11.sp,
                            color = Color(0xFFFFC078)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onRefresh,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("btn_refresh_device_telemetry"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF101E38))
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.telemetry_refresh_action),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdCyanBright
                    )
                }
            }
        }

        // Simulated Blockchain Telemetry Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp))
                .testTag("card_simulated_network_telemetry"),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F1B33)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SignalCellularAlt,
                                contentDescription = null,
                                tint = NmdElectricBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.telemetry_network_title),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (networkTelemetry.isDemo) Color(0x22FF9F43) else Color(0x2238EF7D)
                    ) {
                        Text(
                            text = stringResource(
                                if (networkTelemetry.isDemo) R.string.telemetry_demo_badge
                                else R.string.stage19_live_telemetry_badge
                            ),
                            color = if (networkTelemetry.isDemo) NmdWarningOrange else NmdSuccessGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                val simSuffix = if (networkTelemetry.isDemo) " (Simulated)" else ""
                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_block_height),
                    value = "${networkTelemetry.blockHeightFormatted}$simSuffix"
                )
                Spacer(modifier = Modifier.height(8.dp))
                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_sync_percent),
                    value = "${networkTelemetry.syncPercentageFormatted}$simSuffix"
                )
                Spacer(modifier = Modifier.height(8.dp))
                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_peers_count),
                    value = "${networkTelemetry.connectedPeersCount}$simSuffix"
                )
                Spacer(modifier = Modifier.height(8.dp))
                TelemetryItemRow(
                    label = stringResource(R.string.telemetry_uptime),
                    value = "${networkTelemetry.simulatedUptime}$simSuffix"
                )
                Spacer(modifier = Modifier.height(8.dp))
                TelemetryItemRow(
                    label = stringResource(
                        if (networkTelemetry.isDemo) R.string.node_mode_demo_tag
                        else R.string.status_live_network
                    ),
                    value = networkTelemetry.networkMode
                )
            }
        }
    }
}

@Composable
fun TelemetryItemRow(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    iconTint: Color = NmdElectricCyan
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF091324))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(text = label, fontSize = 11.sp, color = NmdTextSecondaryDark)
        }
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = NmdTextPrimaryDark)
    }
}
