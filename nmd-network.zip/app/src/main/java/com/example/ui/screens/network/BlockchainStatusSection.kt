package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.blockchain.model.BlockchainDbStatus
import com.example.blockchain.model.ChainState
import com.example.blockchain.model.StructuralValidationStatus
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BlockchainStatusSection(
    chainState: ChainState,
    onVerifyIntegrity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formattedTimestamp = remember(chainState.latestBlockTimestamp) {
        if (chainState.latestBlockTimestamp > 0L) {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(Date(chainState.latestBlockTimestamp))
        } else {
            "—"
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("blockchain_status_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage8_blockchain_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                if (chainState.isLocalDevelopmentChain) {
                    Surface(
                        color = NmdWarningOrange.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, NmdWarningOrange.copy(alpha = 0.45f))
                    ) {
                        Text(
                            text = stringResource(R.string.stage8_local_dev_badge),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdWarningOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.stage8_local_dev_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            // Status Rows
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_init_status),
                value = if (chainState.isInitialized) {
                    stringResource(R.string.stage8_status_initialized)
                } else {
                    stringResource(R.string.stage8_status_uninitialized)
                },
                valueColor = if (chainState.isInitialized) NmdSuccessGreen else NmdWarningOrange
            )
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_network_name),
                value = chainState.networkName,
                valueColor = NmdTextPrimaryDark
            )
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_chain_id),
                value = chainState.chainId,
                valueColor = NmdCyanBright,
                isMonospace = true
            )
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_genesis_hash),
                value = chainState.shortGenesisHash.ifBlank { "—" },
                valueColor = NmdElectricCyan,
                isMonospace = true
            )
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_block_height),
                value = if (chainState.currentHeight >= 0L) "#${chainState.currentHeight}" else "—",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_latest_hash),
                value = chainState.shortLatestHash.ifBlank { "—" },
                valueColor = NmdCyanBright,
                isMonospace = true
            )
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_latest_timestamp),
                value = formattedTimestamp,
                valueColor = NmdTextSecondaryDark
            )
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_stored_blocks),
                value = "${chainState.storedBlockCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            val dbStatusColor = when (chainState.dbStatus) {
                BlockchainDbStatus.READY -> NmdSuccessGreen
                BlockchainDbStatus.INITIALIZING, BlockchainDbStatus.UNINITIALIZED -> NmdWarningOrange
                BlockchainDbStatus.CORRUPTED, BlockchainDbStatus.ERROR -> NmdDangerRed
            }
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_db_status),
                value = chainState.dbStatus.name,
                valueColor = dbStatusColor
            )

            val valStatusColor = when (chainState.structuralValidationStatus) {
                StructuralValidationStatus.VALID -> NmdSuccessGreen
                StructuralValidationStatus.PENDING -> NmdWarningOrange
                StructuralValidationStatus.INVALID -> NmdDangerRed
            }
            ChainKeyValueRow(
                label = stringResource(R.string.stage8_field_validation_status),
                value = chainState.structuralValidationStatus.name,
                valueColor = valStatusColor
            )

            chainState.lastError?.let { err ->
                Text(
                    text = err,
                    fontSize = 11.sp,
                    color = NmdDangerRed
                )
            }

            OutlinedButton(
                onClick = onVerifyIntegrity,
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("stage8_verify_integrity_btn"),
                border = BorderStroke(1.dp, NmdElectricCyan),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan)
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.stage8_action_verify_integrity),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun ChainKeyValueRow(
    label: String,
    value: String,
    valueColor: Color,
    isMonospace: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = valueColor
        )
    }
}
