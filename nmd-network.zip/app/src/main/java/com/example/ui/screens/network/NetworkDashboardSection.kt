package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.blockchain.model.ChainState
import com.example.consensus.ConsensusIntegrityReport
import com.example.consensus.model.ConsensusEngineState
import com.example.data.NetworkTelemetry
import com.example.data.NodeConfiguration
import com.example.p2p.connectivity.model.ConnectivityDiagnosticsSnapshot
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.infrastructure.model.BootstrapEndpointConfig
import com.example.p2p.infrastructure.model.NetworkInfrastructureSnapshot
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.infrastructure.model.SignalingEndpointConfig
import com.example.p2p.scalability.model.DeviceResourceMode
import com.example.p2p.scalability.model.NetworkScalabilitySnapshot
import com.example.p2p.security.model.NetworkSecurityUiState
import com.example.production.model.BlockProductionState
import com.example.sync.model.SyncUiState
import com.example.transaction.model.MempoolStatsSnapshot
import com.example.transaction.model.MempoolTransactionRecord
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun NetworkDashboardSection(
    nodeConfig: NodeConfiguration,
    networkTelemetry: NetworkTelemetry,
    onConfigureClick: () -> Unit,
    chainState: ChainState = ChainState(),
    onVerifyChainIntegrity: () -> Unit = {},
    mempoolStats: MempoolStatsSnapshot = MempoolStatsSnapshot(),
    mempoolTransactions: List<MempoolTransactionRecord> = emptyList(),
    onBroadcastValidatedTxs: () -> Unit = {},
    onPruneExpiredTxs: () -> Unit = {},
    consensusState: ConsensusEngineState = ConsensusEngineState(),
    consensusIntegrityReport: ConsensusIntegrityReport? = null,
    onVerifyAndRefreshConsensus: () -> Unit = {},
    productionState: BlockProductionState = BlockProductionState(),
    lastProductionAttemptMessage: String? = null,
    onRefreshProductionSlot: () -> Unit = {},
    onAttemptEligibleProposal: () -> Unit = {},
    syncState: SyncUiState = SyncUiState(),
    onSyncNow: () -> Unit = {},
    onToggleSyncPauseResume: () -> Unit = {},
    securityState: NetworkSecurityUiState = NetworkSecurityUiState(),
    onRevokePeer: (String) -> Unit = {},
    onUnrevokePeer: (String) -> Unit = {},
    onRotateSecuritySessions: () -> Unit = {},
    connectivityDiagnostics: ConnectivityDiagnosticsSnapshot = ConnectivityDiagnosticsSnapshot(),
    onRefreshNatConnectivity: () -> Unit = {},
    onTriggerIceRestart: () -> Unit = {},
    onConfigureStunTurn: (List<StunServerConfig>, List<TurnServerConfig>) -> Unit = { _, _ -> },
    infrastructureSnapshot: NetworkInfrastructureSnapshot = NetworkInfrastructureSnapshot(),
    onBootstrapAndSync: () -> Unit = {},
    onProbeBootstrapHealth: () -> Unit = {},
    onReconnectSignaling: () -> Unit = {},
    onConfigureInfrastructure: (NmdNetworkProfile, List<BootstrapEndpointConfig>, List<SignalingEndpointConfig>, Boolean) -> Unit = { _, _, _, _ -> },
    scalabilitySnapshot: NetworkScalabilitySnapshot = NetworkScalabilitySnapshot(),
    onRunScalabilitySweep: () -> Unit = {},
    onResetCircuitBreakers: () -> Unit = {},
    onSelectResourceMode: (DeviceResourceMode?) -> Unit = {},
    isForegroundServiceRunning: Boolean = false,
    onStartForegroundService: () -> Unit = {},
    onStopForegroundService: () -> Unit = {},
    onRegisterValidator: () -> Unit = {},
    onExitValidator: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Network Identity Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        listOf(Color(0x6600D2FF), Color(0x220077FE), NmdDarkCardBorder)
                    ),
                    shape = RoundedCornerShape(20.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.node_dashboard_title),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                        Text(
                            text = stringResource(R.string.node_dashboard_subtitle),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NmdCyanBright,
                                fontSize = 11.sp
                            )
                        )
                    }

                    // Telemetry Mode Tag
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0x2200D2FF),
                        border = BorderStroke(1.dp, Color(0x4400D2FF))
                    ) {
                        Text(
                            text = stringResource(
                                if (networkTelemetry.isDemo) R.string.telemetry_demo_badge
                                else R.string.stage19_live_telemetry_badge
                            ),
                            color = NmdElectricCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF091426))
                        .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (networkTelemetry.isDemo) {
                            stringResource(R.string.node_mode_demo_tag)
                        } else {
                            networkTelemetry.networkMode
                        },
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (nodeConfig.isDemoActive || isForegroundServiceRunning) NmdSuccessGreen else NmdWarningOrange)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(
                                if (nodeConfig.isDemoActive || isForegroundServiceRunning) R.string.status_node_ok
                                else R.string.node_status_inactive_label
                            ),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (nodeConfig.isDemoActive || isForegroundServiceRunning) NmdSuccessGreen else NmdWarningOrange
                        )
                    }
                }
            }
        }

        // Sync Progress and Live Metrics Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Circular Sync Gauge Card
            Card(
                modifier = Modifier
                    .weight(1.1f)
                    .height(180.dp)
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(18.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { (networkTelemetry.syncPercentage / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.size(120.dp),
                        color = NmdSuccessGreen,
                        trackColor = Color(0x3300D2FF),
                        strokeWidth = 9.dp
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = networkTelemetry.syncPercentageFormatted,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(R.string.telemetry_sync_percent),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NmdTextSecondaryDark,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center
                            )
                        )
                        if (networkTelemetry.isDemo) {
                            Text(
                                text = "(Demo)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NmdCyanBright,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                }
            }

            // Vertical Metrics Column
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DashboardMetricPill(
                    title = stringResource(R.string.telemetry_block_height),
                    value = networkTelemetry.blockHeightFormatted,
                    icon = Icons.Default.Tag,
                    tint = NmdElectricCyan
                )
                DashboardMetricPill(
                    title = stringResource(R.string.telemetry_peers_count),
                    value = if (networkTelemetry.isDemo) {
                        "${networkTelemetry.connectedPeersCount} (Demo)"
                    } else {
                        "${networkTelemetry.connectedPeersCount}"
                    },
                    icon = Icons.Default.Group,
                    tint = NmdSuccessGreen
                )
                DashboardMetricPill(
                    title = stringResource(R.string.telemetry_uptime),
                    value = networkTelemetry.simulatedUptime,
                    icon = Icons.Default.AccessTime,
                    tint = NmdCyanBright
                )
            }
        }

        // Active Local Node Configuration Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F1B33)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Dns,
                                contentDescription = null,
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = nodeConfig.displayName,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NmdTextPrimaryDark
                                )
                            )
                            Text(
                                text = stringResource(nodeConfig.selectedRole.titleRes),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = NmdCyanBright,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    Button(
                        onClick = onConfigureClick,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_dashboard_configure_node")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.node_btn_configure),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.telemetry_last_sync),
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark
                    )
                    Text(
                        text = networkTelemetry.lastSyncTimestamp,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = NmdTextPrimaryDark
                    )
                }
            }
        }

        // Background Node Sync Service Card (Play-compliant DataSync Foreground Service)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp))
                .testTag("card_foreground_service"),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = if (isForegroundServiceRunning) NmdSuccessGreen else NmdElectricCyan,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.stage19_service_title),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                    }
                }

                Text(
                    text = stringResource(
                        if (isForegroundServiceRunning) R.string.stage19_service_running
                        else R.string.stage19_service_stopped
                    ),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isForegroundServiceRunning) NmdSuccessGreen else NmdWarningOrange
                )

                Button(
                    onClick = {
                        if (isForegroundServiceRunning) onStopForegroundService()
                        else onStartForegroundService()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_toggle_foreground_service"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isForegroundServiceRunning) Color(0xFF472518) else NmdElectricBlue
                    )
                ) {
                    Text(
                        text = stringResource(
                            if (isForegroundServiceRunning) R.string.stage19_service_stop
                            else R.string.stage19_service_start
                        ),
                        fontWeight = FontWeight.Bold,
                        color = if (isForegroundServiceRunning) NmdWarningOrange else Color.White
                    )
                }
            }
        }

        // Stage 8: Blockchain Core Status Card
        BlockchainStatusSection(
            chainState = chainState,
            onVerifyIntegrity = onVerifyChainIntegrity
        )

        // Stage 9: Transaction Engine & Mempool Card
        TransactionMempoolSection(
            mempoolStats = mempoolStats,
            mempoolTransactions = mempoolTransactions,
            onBroadcastValidated = onBroadcastValidatedTxs,
            onPruneExpired = onPruneExpiredTxs
        )

        // Stage 10: Distributed BFT Consensus Card
        ConsensusDashboardSection(
            consensusState = consensusState,
            integrityReport = consensusIntegrityReport,
            onVerifyAndRefresh = onVerifyAndRefreshConsensus
        )

        // Stage 11: Block Production & Validator Scheduling Card
        BlockProductionSection(
            productionState = productionState,
            lastAttemptMessage = lastProductionAttemptMessage,
            onRefreshAndCheckSlot = onRefreshProductionSlot,
            onAttemptEligibleProposal = onAttemptEligibleProposal,
            onRegisterValidator = onRegisterValidator,
            onExitValidator = onExitValidator
        )

        // Stage 12: Distributed Blockchain Synchronization Card
        SyncDashboardSection(
            syncState = syncState,
            onSyncNow = onSyncNow,
            onTogglePauseResume = onToggleSyncPauseResume
        )

        // Stage 13: P2P Network Security & Encrypted Transport Card
        NetworkSecurityDashboardSection(
            securityState = securityState,
            onRevokePeer = onRevokePeer,
            onUnrevokePeer = onUnrevokePeer,
            onRotateSessions = onRotateSecuritySessions
        )

        // Stage 14: NAT Traversal & Direct Internet Connectivity Diagnostics Card
        ConnectivityDiagnosticsSection(
            diagnostics = connectivityDiagnostics,
            onRefreshProbes = onRefreshNatConnectivity,
            onTriggerIceRestart = onTriggerIceRestart,
            onConfigureServers = onConfigureStunTurn
        )

        // Stage 15: Public Network Infrastructure, Profiles & Bootstrap Card
        PublicNetworkInfraSection(
            snapshot = infrastructureSnapshot,
            onBootstrapAndSync = onBootstrapAndSync,
            onProbeHealth = onProbeBootstrapHealth,
            onReconnectSignaling = onReconnectSignaling,
            onApplyConfiguration = onConfigureInfrastructure
        )

        // Stage 16: Scalability, Peer Health, Congestion, Circuit Breakers & Quorum Card
        NetworkScalabilitySection(
            snapshot = scalabilitySnapshot,
            onRunHealthSweep = onRunScalabilitySweep,
            onResetCircuitBreakers = onResetCircuitBreakers,
            onSelectResourceMode = onSelectResourceMode
        )
    }
}

@Composable
fun DashboardMetricPill(
    title: String,
    value: String,
    icon: ImageVector,
    tint: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0D172A))
            .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = title,
                fontSize = 10.sp,
                color = NmdTextSecondaryDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NmdTextPrimaryDark
            )
        }
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(18.dp)
        )
    }
}
