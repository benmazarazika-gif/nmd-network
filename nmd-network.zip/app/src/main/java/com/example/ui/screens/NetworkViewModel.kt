package com.example.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.ChainState
import com.example.blockchain.p2p.DefaultBlockchainPeerSyncGateway
import com.example.consensus.ConsensusCoordinator
import com.example.consensus.ConsensusIntegrityReport
import com.example.consensus.NmdConsensusCoordinatorRegistry
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusEngineState
import com.example.consensus.model.EquivocationEvidence
import com.example.crypto.NodeIdentityManager
import com.example.crypto.SelfVerificationStatus
import com.example.crypto.model.MessageVerificationResult
import com.example.crypto.model.NodeIdentity
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.data.DeviceResourceMonitor
import com.example.data.DeviceTelemetry
import com.example.data.NetworkActivityEvent
import com.example.data.NetworkActivityType
import com.example.data.NetworkTab
import com.example.data.NetworkTelemetry
import com.example.data.NodeConfiguration
import com.example.data.NodeManager
import com.example.data.NodeRole
import com.example.data.NodeStatus
import com.example.data.PeerInfo
import com.example.p2p.discovery.DiscoveryMethod
import com.example.p2p.discovery.DiscoveryStatusState
import com.example.p2p.discovery.bootstrap.BootstrapPeer
import com.example.p2p.discovery.registry.PeerFilterOption
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.topology.TopologyMetrics
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.protocol.ReliableMessageRecord
import com.example.p2p.connectivity.model.ConnectivityDiagnosticsSnapshot
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.infrastructure.model.BootstrapEndpointConfig
import com.example.p2p.infrastructure.model.BootstrapTransportProtocol
import com.example.p2p.infrastructure.model.NetworkInfrastructureSnapshot
import com.example.p2p.infrastructure.model.NetworkProfileRegistry
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.infrastructure.model.SignalingEndpointConfig
import com.example.p2p.scalability.model.DeviceResourceMode
import com.example.p2p.scalability.model.NetworkScalabilitySnapshot
import com.example.p2p.security.model.NetworkSecurityUiState
import com.example.p2p.service.P2pTestLabReport
import com.example.p2p.session.PeerSession
import com.example.production.BlockProductionCoordinator
import com.example.production.NmdBlockProductionRegistry
import com.example.production.model.BlockProductionAttemptResult
import com.example.production.model.BlockProductionState
import com.example.sync.BlockchainSyncCoordinator
import com.example.sync.NmdBlockchainSyncRegistry
import com.example.sync.model.SyncUiState
import com.example.service.NmdNodeForegroundService
import com.example.transaction.NmdTransactionEngineRegistry
import com.example.transaction.TransactionEngineManager
import com.example.transaction.WalletTxCreationOutcome
import com.example.transaction.model.MempoolStatsSnapshot
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.TransactionType
import com.example.transaction.model.ValidatorTransactionPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class NetworkViewModel @JvmOverloads constructor(
    application: Application,
    val nodeManager: NodeManager = NodeManager(application.applicationContext),
    val identityManager: NodeIdentityManager = NodeIdentityManager(application.applicationContext),
    val transportRepository: com.example.p2p.repository.NetworkTransportRepository = com.example.p2p.repository.NetworkTransportRepository(
        application.applicationContext,
        identityManager
    ),
    val blockchainManager: BlockchainManager = BlockchainManager(application.applicationContext),
    val transactionEngine: TransactionEngineManager = NmdTransactionEngineRegistry.getOrCreate(
        context = application.applicationContext,
        blockchainManager = blockchainManager,
        peerRegistry = transportRepository.discoveryCoordinator.peerRegistry
    ),
    val consensusCoordinator: ConsensusCoordinator = NmdConsensusCoordinatorRegistry.getOrCreate(
        context = application.applicationContext,
        blockchainManager = blockchainManager,
        txEngineManager = transactionEngine,
        peerRegistry = transportRepository.discoveryCoordinator.peerRegistry
    ),
    val blockProductionCoordinator: BlockProductionCoordinator = NmdBlockProductionRegistry.getOrCreate(
        context = application.applicationContext,
        blockchainManager = blockchainManager,
        txEngineManager = transactionEngine,
        consensusCoordinator = consensusCoordinator
    ),
    val blockchainSyncCoordinator: BlockchainSyncCoordinator = NmdBlockchainSyncRegistry.getOrCreate(
        context = application.applicationContext,
        blockchainManager = blockchainManager,
        txEngineManager = transactionEngine,
        consensusCoordinator = consensusCoordinator,
        peerRegistry = transportRepository.discoveryCoordinator.peerRegistry
    )
) : AndroidViewModel(application) {

    // Stage 8: Blockchain Core Foundation
    val chainState: StateFlow<ChainState> = blockchainManager.chainState
    val blockchainPeerGateway = DefaultBlockchainPeerSyncGateway(
        blockchainManager = blockchainManager,
        peerRegistry = transportRepository.discoveryCoordinator.peerRegistry
    )

    // Stage 9: Transaction Engine & Mempool State
    val mempoolStats: StateFlow<MempoolStatsSnapshot> = transactionEngine.mempoolStats
    val mempoolTransactions: StateFlow<List<MempoolTransactionRecord>> = transactionEngine.mempoolTransactions

    // Stage 10: Distributed Consensus Mechanism State
    val consensusState: StateFlow<ConsensusEngineState> = consensusCoordinator.state
    val latestCommitCertificate: StateFlow<CommitCertificate?> = consensusCoordinator.latestCommitCertificate
    val equivocationHistory: StateFlow<List<EquivocationEvidence>> = consensusCoordinator.equivocationHistory
    val consensusIntegrityReport: StateFlow<ConsensusIntegrityReport?> = consensusCoordinator.lastIntegrityReport

    // Stage 11: Block Production & Validator Scheduling State
    val productionState: StateFlow<BlockProductionState> = blockProductionCoordinator.state
    private val _lastProductionAttemptMessage = MutableStateFlow<String?>(null)
    val lastProductionAttemptMessage: StateFlow<String?> = _lastProductionAttemptMessage.asStateFlow()

    // Stage 12: Blockchain Synchronization State
    val syncState: StateFlow<SyncUiState> = blockchainSyncCoordinator.state

    // Stage 13: P2P Network Security & Encrypted Transport State
    val securityUiState: StateFlow<NetworkSecurityUiState> = transportRepository.securityUiState

    // Stage 14: NAT Traversal & Direct Internet Connectivity Diagnostics State
    val connectivityDiagnostics: StateFlow<ConnectivityDiagnosticsSnapshot> = transportRepository.connectivityDiagnostics

    // Stage 15: Public Network Infrastructure & Bootstrap Diagnostics State
    val infrastructureSnapshot: StateFlow<NetworkInfrastructureSnapshot> = transportRepository.infrastructureSnapshot

    // Stage 16: Network Scalability, Peer Health, Congestion & Fault Tolerance State
    val scalabilitySnapshot: StateFlow<NetworkScalabilitySnapshot> = transportRepository.scalabilitySnapshot

    private val deviceMonitor = DeviceResourceMonitor(application.applicationContext)

    init {
        // Wire Stage 9 P2P transaction gateway into Stage 6/7 transport
        transactionEngine.p2pGateway.authenticatedSessionsProvider = {
            transportRepository.activeSessions.value
        }
        transactionEngine.p2pGateway.sendTxPayloadToSession = { sessionId, msgType, payload ->
            transportRepository.sendReliableP2pMessage(sessionId, msgType, payload).map { Unit }
        }
        transportRepository.reliableMessagingService.onIncomingTransactionMessage = { session, msg ->
            transactionEngine.p2pGateway.handleIncomingP2pTransaction(session, msg)
        }

        // Wire Stage 10 P2P consensus gateway into Stage 6/7 transport
        consensusCoordinator.p2pGateway.authenticatedSessionsProvider = {
            transportRepository.activeSessions.value
        }
        consensusCoordinator.p2pGateway.sendConsensusMessageToSession = { sessionId, msgType, payload ->
            transportRepository.sendReliableP2pMessage(sessionId, msgType, payload).map { Unit }
        }
        transportRepository.reliableMessagingService.onIncomingConsensusMessage = { session, msg ->
            consensusCoordinator.p2pGateway.handleIncomingConsensusMessage(session, msg)
        }

        // Wire Stage 12 P2P blockchain sync transport
        blockchainSyncCoordinator.bindP2pTransport(
            authenticatedSessionsProvider = { transportRepository.activeSessions.value },
            sendSyncMessageToSession = { sessionId, msgType, payload ->
                transportRepository.sendSyncProtocolMessage(sessionId, msgType, payload)
            }
        )
        transportRepository.reliableMessagingService.onIncomingSyncMessage = { session, msg ->
            blockchainSyncCoordinator.handleIncomingSyncMessage(session, msg)
        }

        viewModelScope.launch(Dispatchers.IO) {
            val activeIdentity = identityManager.getActiveIdentity()
            val sampledTelemetry = deviceMonitor.sampleDeviceTelemetry()
            blockchainManager.initialize()
            transactionEngine.initialize()
            consensusCoordinator.initialize(
                localIdentity = activeIdentity,
                localDisplayName = nodeManager.nodeConfig.value.displayName
            )
            consensusCoordinator.updateDeviceTelemetry(sampledTelemetry)
            transportRepository.scalabilityCoordinator.attachValidatorRegistry(
                registry = consensusCoordinator.registry,
                consensusConfig = consensusCoordinator.config,
                localValidatorId = consensusCoordinator.state.value.localValidatorId
            )
            blockProductionCoordinator.initialize(
                context = getApplication(),
                localPublicKeyHex = activeIdentity?.publicKeyHex,
                telemetry = sampledTelemetry
            )
            blockchainSyncCoordinator.initialize(
                context = getApplication(),
                telemetry = sampledTelemetry
            )
        }

        viewModelScope.launch(Dispatchers.IO) {
            transportRepository.activeSessions.collect { sessions ->
                val trustedCount = sessions.count { it.isTrusted }
                transactionEngine.mempool.refreshPeerContext(trustedCount)
            }
        }

        // Stage 19: Live Telemetry & Real Peer List Synchronization (Zero Fake Data)
        viewModelScope.launch(Dispatchers.IO) {
            val utcFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            combine(
                blockchainManager.chainState,
                blockchainSyncCoordinator.state,
                transportRepository.activeSessions,
                transportRepository.registeredPeers,
                NmdNodeForegroundService.isRunning
            ) { chain, sync, sessions, registryPeers, svcRunning ->
                Triple(chain, sync, Triple(sessions, registryPeers, svcRunning))
            }.collect { (chain, sync, peerBundle) ->
                val (sessions, registryPeers, svcRunning) = peerBundle
                val activeTrusted = sessions.filter { it.isTrusted }
                val currentHeight = maxOf(0L, chain.currentHeight)
                val syncPct = when {
                    sync.highestReportedPeerHeight > 0L -> (sync.progressFraction * 100f).coerceIn(0f, 100f)
                    chain.isInitialized -> 100f
                    else -> 0f
                }
                val lastSyncStr = sync.lastSyncTimestampMs?.let { utcFmt.format(Date(it)) }
                    ?: if (chain.isInitialized) "Height #$currentHeight" else "Not synced"
                val infra = transportRepository.infrastructureSnapshot.value
                _networkTelemetry.value = NetworkTelemetry(
                    blockHeight = currentHeight,
                    syncPercentage = syncPct,
                    connectedPeersCount = activeTrusted.size,
                    simulatedUptime = if (svcRunning) "Service Active" else "Foreground",
                    lastSyncTimestamp = lastSyncStr,
                    networkMode = "${chain.chainId} (${infra.activeProfile.name})",
                    isDemo = false
                )

                val validatorIds = consensusCoordinator.state.value.validatorParticipations.map { it.validatorId }.toSet()
                val sessionsByPeer = activeTrusted.associateBy { it.peerId }
                val combinedPeers = mutableListOf<PeerInfo>()
                val seenPeerIds = HashSet<String>()

                for (session in activeTrusted) {
                    if (!seenPeerIds.add(session.peerId)) continue
                    val role = if (session.peerId in validatorIds) NodeRole.VALIDATOR else NodeRole.FULL_NODE
                    combinedPeers.add(
                        PeerInfo(
                            id = session.peerId,
                            name = session.displayPeerId,
                            role = role,
                            connectionState = if (sync.currentSyncPeerId == session.peerId) {
                                com.example.data.PeerConnectionState.SYNCING
                            } else {
                                com.example.data.PeerConnectionState.CONNECTED
                            },
                            latencyMs = session.lastRoundTripLatencyMs.toInt(),
                            lastSeenText = "${session.durationSeconds}s session",
                            location = "${session.endpoint.host}:${session.endpoint.port}",
                            isDemo = false
                        )
                    )
                }

                for (rec in registryPeers) {
                    if (!seenPeerIds.add(rec.peerId)) continue
                    val role = if (rec.peerId in validatorIds) NodeRole.VALIDATOR else NodeRole.FULL_NODE
                    val active = sessionsByPeer[rec.peerId]
                    combinedPeers.add(
                        PeerInfo(
                            id = rec.peerId,
                            name = rec.peerId.take(16),
                            role = role,
                            connectionState = if (active != null) {
                                com.example.data.PeerConnectionState.CONNECTED
                            } else {
                                com.example.data.PeerConnectionState.IDLE
                            },
                            latencyMs = rec.latencyMs.toInt(),
                            lastSeenText = rec.discoverySource.name,
                            location = "${rec.endpoint.host}:${rec.endpoint.port}",
                            isDemo = false
                        )
                    )
                }

                nodeManager.updatePeers(combinedPeers)
            }
        }
    }

    // Stage 5: Real P2P State
    val isP2pListening = transportRepository.isListening
    val p2pBoundPort = transportRepository.boundPort
    val discoveredPeers = transportRepository.discoveredPeers
    val authenticatedRealPeers = transportRepository.authenticatedPeers
    val realP2pEvents = transportRepository.transportEvents
    val p2pMessageHistory = transportRepository.messageHistory

    // Stage 6: Reliable P2P Messaging State
    val activePeerSessions: StateFlow<List<PeerSession>> = transportRepository.activeSessions
    val reliableMessageLog: StateFlow<List<ReliableMessageRecord>> = transportRepository.reliableMessageHistory
    val p2pTestReport: StateFlow<P2pTestLabReport?> = transportRepository.testReport

    // Stage 7: Distributed Peer Discovery & Topology State
    val registeredPeers: StateFlow<List<PeerRegistryRecord>> = transportRepository.registeredPeers
    val bootstrapPeers: StateFlow<List<BootstrapPeer>> = transportRepository.bootstrapPeers
    val topologyMetrics: StateFlow<TopologyMetrics> = transportRepository.topologyMetrics
    val discoveryStatus: StateFlow<DiscoveryStatusState> = transportRepository.discoveryStatus
    val activeDiscoveryMethod: StateFlow<DiscoveryMethod> = transportRepository.activeDiscoveryMethod
    val lastSuccessfulDiscoveryMs: StateFlow<Long?> = transportRepository.lastSuccessfulDiscoveryMs

    private val _registryFilter = MutableStateFlow(PeerFilterOption.ALL)
    val registryFilter: StateFlow<PeerFilterOption> = _registryFilter.asStateFlow()

    private val _selectedSessionForDetail = MutableStateFlow<PeerSession?>(null)
    val selectedSessionForDetail: StateFlow<PeerSession?> = _selectedSessionForDetail.asStateFlow()

    private val _isTestLabRunning = MutableStateFlow(false)
    val isTestLabRunning: StateFlow<Boolean> = _isTestLabRunning.asStateFlow()

    private val _showManualConnectDialog = MutableStateFlow(false)
    val showManualConnectDialog: StateFlow<Boolean> = _showManualConnectDialog.asStateFlow()

    private val _p2pErrorMessage = MutableStateFlow<String?>(null)
    val p2pErrorMessage: StateFlow<String?> = _p2pErrorMessage.asStateFlow()

    // Active Navigation Tab inside Network Control Center
    private val _currentTab = MutableStateFlow(NetworkTab.DASHBOARD)
    val currentTab: StateFlow<NetworkTab> = _currentTab.asStateFlow()

    // Node Configuration & Status State (Persisted via NodeManager & NodePreferences)
    val nodeConfig: StateFlow<NodeConfiguration> = nodeManager.nodeConfig
    val nodeStatus: StateFlow<NodeStatus> = nodeManager.nodeStatus

    // Real Device Telemetry
    private val _deviceTelemetry = MutableStateFlow(deviceMonitor.sampleDeviceTelemetry())
    val deviceTelemetry: StateFlow<DeviceTelemetry> = _deviceTelemetry.asStateFlow()

    // Live Layer-1 Network Telemetry (Backed by real chain, sync & session flows)
    private val _networkTelemetry = MutableStateFlow(NetworkTelemetry())
    val networkTelemetry: StateFlow<NetworkTelemetry> = _networkTelemetry.asStateFlow()

    val isForegroundServiceRunning: StateFlow<Boolean> = NmdNodeForegroundService.isRunning

    // Configuration Modal Visibility
    private val _showConfigDialog = MutableStateFlow(false)
    val showConfigDialog: StateFlow<Boolean> = _showConfigDialog.asStateFlow()

    // Peer Management State
    private val _peerSearchQuery = MutableStateFlow("")
    val peerSearchQuery: StateFlow<String> = _peerSearchQuery.asStateFlow()

    private val _peerRoleFilter = MutableStateFlow<NodeRole?>(null)
    val peerRoleFilter: StateFlow<NodeRole?> = _peerRoleFilter.asStateFlow()

    // Real Peers List (Updated from active P2P sessions & DistributedPeerRegistry)
    val peers: StateFlow<List<PeerInfo>> = nodeManager.peers

    // Live Network Activity Timeline (Zero fake pre-populated entries)
    private val _networkActivities = MutableStateFlow<List<NetworkActivityEvent>>(emptyList())
    val networkActivities: StateFlow<List<NetworkActivityEvent>> = _networkActivities.asStateFlow()

    // Stage 4: Cryptographic Node Identity State
    val nodeIdentity: StateFlow<NodeIdentity?> = identityManager.identity
    val selfVerificationStatus: StateFlow<SelfVerificationStatus> = identityManager.selfVerificationStatus
    val lastSignedMessage: StateFlow<SignedProtocolMessage?> = identityManager.lastSignedMessage
    val lastVerificationResult: StateFlow<MessageVerificationResult?> = identityManager.lastVerificationResult

    // Stage 4 Dialog Controls
    private val _showPublicIdentityDialog = MutableStateFlow(false)
    val showPublicIdentityDialog: StateFlow<Boolean> = _showPublicIdentityDialog.asStateFlow()

    private val _showSignMessageDialog = MutableStateFlow(false)
    val showSignMessageDialog: StateFlow<Boolean> = _showSignMessageDialog.asStateFlow()

    private val _showDeleteIdentityDialog = MutableStateFlow(false)
    val showDeleteIdentityDialog: StateFlow<Boolean> = _showDeleteIdentityDialog.asStateFlow()

    fun setTab(tab: NetworkTab) {
        _currentTab.value = tab
    }

    fun openConfigDialog() {
        _showConfigDialog.value = true
    }

    fun closeConfigDialog() {
        _showConfigDialog.value = false
    }

    fun saveNodeConfiguration(
        newRole: NodeRole,
        newDisplayName: String,
        newDemoActive: Boolean
    ) {
        val updated = nodeManager.updateConfiguration(
            role = newRole,
            displayName = newDisplayName,
            isDemoActive = newDemoActive
        )

        // Append to local activity timeline
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val actionText = if (newDemoActive) "Node runtime active as ${newRole.name}" else "Node runtime standby"
        val newEvent = NetworkActivityEvent(
            id = "act_${System.currentTimeMillis()}",
            type = NetworkActivityType.CONFIG_CHANGED,
            titleRes = R.string.act_config_changed,
            description = "$actionText (${updated.displayName}) at $timeFormat UTC",
            timestamp = "Just now",
            isDemo = false
        )
        _networkActivities.value = (listOf(newEvent) + _networkActivities.value).take(50)
        _showConfigDialog.value = false
    }

    fun toggleDemoNodeActive(active: Boolean) {
        val current = nodeManager.nodeConfig.value
        saveNodeConfiguration(current.selectedRole, current.displayName, active)
    }

    fun selectRoleQuickAction(role: NodeRole) {
        val current = nodeManager.nodeConfig.value
        saveNodeConfiguration(role, current.displayName, true)
    }

    fun setPeerSearchQuery(query: String) {
        _peerSearchQuery.value = query
    }

    fun setPeerRoleFilter(role: NodeRole?) {
        _peerRoleFilter.value = role
    }

    fun refreshDeviceTelemetry() {
        val sampled = deviceMonitor.sampleDeviceTelemetry()
        _deviceTelemetry.value = sampled
        viewModelScope.launch(Dispatchers.IO) {
            consensusCoordinator.updateDeviceTelemetry(sampled)
            blockProductionCoordinator.refreshScheduleAndTelemetry(getApplication(), sampled)
            blockchainSyncCoordinator.refreshMobilePolicy(getApplication(), sampled)
        }
    }

    // Stage 4: Cryptographic Actions
    fun generateNodeIdentity(): NodeIdentity {
        val created = identityManager.generateNewIdentity()
        viewModelScope.launch(Dispatchers.IO) {
            consensusCoordinator.onLocalIdentityUpdated(created, nodeManager.nodeConfig.value.displayName)
            blockProductionCoordinator.onLocalIdentityUpdated(created.publicKeyHex)
        }
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val newEvent = NetworkActivityEvent(
            id = "act_${System.currentTimeMillis()}",
            type = NetworkActivityType.CONFIG_CHANGED,
            titleRes = R.string.crypto_identity_title,
            description = "New Ed25519 node identity generated (${created.nodeId.take(16)}...) at $timeFormat UTC",
            timestamp = "Just now",
            isDemo = false
        )
        _networkActivities.value = (listOf(newEvent) + _networkActivities.value).take(50)
        return created
    }

    fun deleteNodeIdentity(): Boolean {
        val result = identityManager.deleteIdentity()
        viewModelScope.launch(Dispatchers.IO) {
            consensusCoordinator.onLocalIdentityUpdated(null)
            blockProductionCoordinator.onLocalIdentityUpdated(null)
        }
        _showDeleteIdentityDialog.value = false
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val newEvent = NetworkActivityEvent(
            id = "act_${System.currentTimeMillis()}",
            type = NetworkActivityType.CONFIG_CHANGED,
            titleRes = R.string.crypto_identity_title,
            description = "Ed25519 node identity and KeyStore master key purged at $timeFormat UTC",
            timestamp = "Just now",
            isDemo = false
        )
        _networkActivities.value = (listOf(newEvent) + _networkActivities.value).take(50)
        return result
    }

    fun verifySelfIdentity(): Boolean {
        return identityManager.verifySelfIdentity()
    }

    fun signTestProtocolMessage(
        type: ProtocolMessageType,
        payload: String
    ): SignedProtocolMessage {
        val signed = identityManager.signTestMessage(type, payload)
        // Automatically run verification on the freshly signed message
        identityManager.verifyMessage(signed)
        return signed
    }

    fun verifyProtocolMessage(message: SignedProtocolMessage): MessageVerificationResult {
        return identityManager.verifyMessage(message)
    }

    fun exportPublicIdentityJson(): String {
        return identityManager.exportPublicIdentityJson()
    }

    fun openPublicIdentityDialog() {
        _showPublicIdentityDialog.value = true
    }

    fun closePublicIdentityDialog() {
        _showPublicIdentityDialog.value = false
    }

    fun openSignMessageDialog() {
        _showSignMessageDialog.value = true
    }

    fun closeSignMessageDialog() {
        _showSignMessageDialog.value = false
    }

    fun openDeleteIdentityDialog() {
        _showDeleteIdentityDialog.value = true
    }

    fun closeDeleteIdentityDialog() {
        _showDeleteIdentityDialog.value = false
    }

    // Stage 5: Real P2P Actions
    fun getLocalIpAddress(): String = transportRepository.getLocalIpAddress()

    fun toggleP2pListening() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (isP2pListening.value) {
                    transportRepository.stopListening()
                } else {
                    transportRepository.startListening()
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun connectToRealPeer(host: String, port: Int, claimedNodeId: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _p2pErrorMessage.value = null
                val endpoint = com.example.p2p.model.PeerEndpoint(host, port, claimedNodeId)
                val result = transportRepository.connectToPeer(endpoint)
                if (result.isFailure) {
                    _p2pErrorMessage.value = result.exceptionOrNull()?.message ?: "Failed connecting to peer"
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun disconnectRealPeer(connectionId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.disconnectPeer(connectionId)
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun sendSignedProtocolMessageToPeer(
        connectionId: String,
        messageType: ProtocolMessageType,
        payload: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = transportRepository.sendSignedMessage(connectionId, messageType, payload)
                if (result.isFailure) {
                    _p2pErrorMessage.value = result.exceptionOrNull()?.message ?: "Failed sending message"
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun openManualConnectDialog() {
        _showManualConnectDialog.value = true
    }

    fun closeManualConnectDialog() {
        _showManualConnectDialog.value = false
    }

    fun clearP2pErrorMessage() {
        _p2pErrorMessage.value = null
    }

    // Stage 6: Reliable Messaging Actions
    fun selectSessionForDetail(session: PeerSession?) {
        _selectedSessionForDetail.value = session
    }

    fun sendReliableP2pMessage(
        sessionId: String,
        messageType: P2pMessageType,
        payload: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = transportRepository.sendReliableP2pMessage(sessionId, messageType, payload)
                if (result.isFailure) {
                    _p2pErrorMessage.value = result.exceptionOrNull()?.message ?: "Failed sending reliable message"
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun sendPingToSession(sessionId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = transportRepository.sendPingToSession(sessionId)
                if (result.isFailure) {
                    _p2pErrorMessage.value = result.exceptionOrNull()?.message ?: "Ping failed"
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun runP2pTestLabSuite(sessionId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _isTestLabRunning.value = true
                transportRepository.runP2pTestLabSuite(sessionId)
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            } finally {
                _isTestLabRunning.value = false
            }
        }
    }

    fun clearP2pTestReport() {
        transportRepository.clearP2pTestReport()
    }

    // Stage 7: Distributed Discovery Actions
    fun setRegistryFilter(filter: PeerFilterOption) {
        _registryFilter.value = filter
    }

    fun refreshDistributedDiscovery() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _p2pErrorMessage.value = null
                transportRepository.refreshDistributedDiscovery()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun requestPeerExchange() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _p2pErrorMessage.value = null
                transportRepository.requestPeerExchangeFromAll()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun connectToRegistryPeer(peerId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _p2pErrorMessage.value = null
                val res = transportRepository.connectToRegistryPeer(peerId)
                if (res.isFailure) {
                    _p2pErrorMessage.value = res.exceptionOrNull()?.message ?: "Connection failed"
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun removeRegistryPeer(peerId: String) {
        transportRepository.removeRegistryPeer(peerId)
    }

    fun connectBootstrapPeer(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _p2pErrorMessage.value = null
                val res = transportRepository.connectBootstrapPeer(id)
                if (res.isFailure) {
                    _p2pErrorMessage.value = res.exceptionOrNull()?.message ?: "Bootstrap connection failed"
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun toggleBootstrapPeer(id: String, enabled: Boolean) {
        transportRepository.toggleBootstrapPeer(id, enabled)
    }

    fun removeBootstrapPeer(id: String) {
        transportRepository.removeBootstrapPeer(id)
    }

    fun addCustomBootstrapPeer(name: String, host: String, port: Int, expectedNodeId: String? = null) {
        transportRepository.addCustomBootstrapPeer(name, host, port, expectedNodeId)
    }

    // Stage 8: Blockchain Core Integrity Action
    fun verifyBlockchainIntegrity() {
        viewModelScope.launch(Dispatchers.IO) {
            blockchainManager.verifyIntegrity()
        }
    }

    // Stage 9: Mempool Broadcast & Prune Actions
    fun broadcastValidatedTransactions() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transactionEngine.broadcastAllValidated()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun pruneExpiredMempoolTransactions() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transactionEngine.pruneExpiredTransactions()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    // Stage 10: Consensus Verification & Telemetry Refresh Action
    fun verifyAndRefreshConsensus() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val sampled = deviceMonitor.sampleDeviceTelemetry()
                _deviceTelemetry.value = sampled
                consensusCoordinator.updateDeviceTelemetry(sampled)
                consensusCoordinator.checkRoundTimeout()
                consensusCoordinator.verifyConsensusIntegrity()
                blockProductionCoordinator.refreshScheduleAndTelemetry(getApplication(), sampled)
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    // Stage 11: Block Production & Validator Scheduling Actions
    fun refreshAndCheckProductionSlot() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val sampled = deviceMonitor.sampleDeviceTelemetry()
                _deviceTelemetry.value = sampled
                consensusCoordinator.updateDeviceTelemetry(sampled)
                consensusCoordinator.checkRoundTimeout()
                val updated = blockProductionCoordinator.refreshScheduleAndTelemetry(getApplication(), sampled)
                _lastProductionAttemptMessage.value =
                    "H #${updated.currentProductionHeight} R ${updated.currentRound} • " +
                        (if (updated.localValidatorEligible) "Local node scheduled" else "Standby (proposer: ${updated.scheduledProposerId?.take(12) ?: "none"})")
            } catch (e: Exception) {
                _lastProductionAttemptMessage.value = e.message
            }
        }
    }

    fun attemptEligibleBlockProduction() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val sampled = deviceMonitor.sampleDeviceTelemetry()
                _deviceTelemetry.value = sampled
                consensusCoordinator.updateDeviceTelemetry(sampled)
                when (val outcome = blockProductionCoordinator.attemptEligibleProduction(getApplication(), identityManager, sampled)) {
                    is BlockProductionAttemptResult.Proposed -> {
                        _lastProductionAttemptMessage.value =
                            "Proposed H #${outcome.height} R ${outcome.round} (${outcome.includedTxCount} tx) -> BFT Consensus"
                    }
                    is BlockProductionAttemptResult.Skipped -> {
                        _lastProductionAttemptMessage.value = outcome.reason
                    }
                    is BlockProductionAttemptResult.Rejected -> {
                        _lastProductionAttemptMessage.value = "Rejected (${outcome.code.name}): ${outcome.reason}"
                    }
                }
            } catch (e: Exception) {
                _lastProductionAttemptMessage.value = e.message
            }
        }
    }

    // Stage 12: Blockchain Synchronization Actions
    fun triggerBlockchainSync() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val sampled = deviceMonitor.sampleDeviceTelemetry()
                _deviceTelemetry.value = sampled
                blockchainSyncCoordinator.synchronizeNow(getApplication(), sampled)
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun toggleBlockchainSyncPauseResume() {
        if (syncState.value.isUserPaused) {
            blockchainSyncCoordinator.resumeSync()
            triggerBlockchainSync()
        } else {
            blockchainSyncCoordinator.pauseSync()
        }
    }

    // Stage 13: Transport Security & Revocation Actions
    fun revokePeerIdentity(peerId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.revokePeerIdentity(peerId)
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun unrevokePeerIdentity(peerId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.unrevokePeerIdentity(peerId)
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun rotateEncryptedSessions() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.rotateEncryptedSessions()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    // Stage 14: NAT Traversal & Connectivity Actions
    fun refreshNatConnectivity() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.refreshNatConnectivity()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun triggerIceRestart() {
        transportRepository.triggerIceRestart()
    }

    fun configureStunTurnServers(
        stunServers: List<StunServerConfig>,
        turnServers: List<TurnServerConfig>
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.configureStunTurnServers(stunServers, turnServers)
                transportRepository.refreshNatConnectivity()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    // Stage 15: Public Network Infrastructure, Profile & Bootstrap Actions
    fun switchNetworkProfilePreset(profile: NmdNetworkProfile) {
        val res = transportRepository.switchNetworkProfile(profile)
        if (res.isFailure) {
            _p2pErrorMessage.value = res.exceptionOrNull()?.message ?: "Profile change rejected"
        }
    }

    fun configureInfrastructureEndpoints(
        targetProfile: NmdNetworkProfile,
        bootstrapEntries: List<BootstrapEndpointConfig>,
        signalingEntries: List<SignalingEndpointConfig>,
        activateMainnetExplicitly: Boolean = false
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val base = NetworkProfileRegistry.defaultConfigFor(targetProfile)
                val updated = base.copy(
                    isMainnetActivated = targetProfile == NmdNetworkProfile.MAINNET && activateMainnetExplicitly,
                    bootstrapEndpoints = bootstrapEntries,
                    signalingEndpoints = signalingEntries
                )
                val res = transportRepository.applyNetworkInfrastructureConfig(updated)
                if (res.isFailure) {
                    _p2pErrorMessage.value = res.exceptionOrNull()?.message ?: "Invalid endpoint configuration"
                } else {
                    transportRepository.probeBootstrapEndpointsHealth()
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun bootstrapAndSyncPeers() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val res = transportRepository.bootstrapAndSyncPeers()
                if (res.isFailure) {
                    _p2pErrorMessage.value = res.exceptionOrNull()?.message ?: "Bootstrap discovery failed"
                }
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun probeBootstrapEndpointsHealth() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.probeBootstrapEndpointsHealth()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun reconnectSignalingTransport() {
        transportRepository.reconnectSignalingTransport()
    }

    // Stage 16: Scalability, Fault Tolerance & Adaptive Resource Operations
    fun runScalabilitySweep() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                transportRepository.runScalabilitySweep()
            } catch (e: Exception) {
                _p2pErrorMessage.value = e.message
            }
        }
    }

    fun setDeviceResourceModeOverride(mode: DeviceResourceMode?) {
        transportRepository.setDeviceResourceModeOverride(mode)
    }

    fun resetAllCircuitBreakers() {
        transportRepository.resetAllCircuitBreakers()
    }

    // Stage 20/21: Foreground Service & On-Chain Validator Lifecycle Transactions
    fun startNodeForegroundService() {
        val height = maxOf(0L, blockchainManager.chainState.value.currentHeight)
        val trustedPeers = transportRepository.activeSessions.value.count { it.isTrusted }
        NmdNodeForegroundService.start(
            getApplication(),
            "Height #$height • $trustedPeers trusted P2P peers"
        )
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val ev = NetworkActivityEvent(
            id = "act_${System.currentTimeMillis()}",
            type = NetworkActivityType.SYNC_UPDATED,
            titleRes = R.string.stage19_service_title,
            description = "Node foreground DataSync service started at $timeFormat UTC",
            timestamp = "Just now",
            isDemo = false
        )
        _networkActivities.value = (listOf(ev) + _networkActivities.value).take(50)
    }

    fun stopNodeForegroundService() {
        NmdNodeForegroundService.stop(getApplication())
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val ev = NetworkActivityEvent(
            id = "act_${System.currentTimeMillis()}",
            type = NetworkActivityType.SYNC_UPDATED,
            titleRes = R.string.stage19_service_title,
            description = "Node foreground DataSync service stopped at $timeFormat UTC",
            timestamp = "Just now",
            isDemo = false
        )
        _networkActivities.value = (listOf(ev) + _networkActivities.value).take(50)
    }

    fun submitValidatorRegistration(votingPower: Long = 1L) {
        viewModelScope.launch(Dispatchers.IO) {
            val identity = identityManager.getActiveIdentity()
            if (identity == null) {
                _p2pErrorMessage.value = "Generate or restore an Ed25519 node identity before registering as validator"
                return@launch
            }
            val senderAddr = transactionEngine.deriveSenderAddress(identity) ?: return@launch
            val payload = ValidatorTransactionPayload(
                nodeId = identity.nodeId,
                publicKeyHex = identity.publicKeyHex,
                displayName = nodeConfig.value.displayName,
                votingPower = votingPower.coerceAtLeast(1L)
            )
            when (
                val outcome = transactionEngine.createSignAndSubmit(
                    identityRepository = identityManager.repository,
                    recipientAddress = senderAddr,
                    amountUnits = 0L,
                    txType = TransactionType.VALIDATOR_REGISTER,
                    payloadBytes = payload.toJsonBytes(),
                    attemptBroadcast = true
                )
            ) {
                is WalletTxCreationOutcome.Submitted -> {
                    _lastProductionAttemptMessage.value =
                        "Validator registration queued (${outcome.record.transaction.shortTxId})"
                }
                is WalletTxCreationOutcome.Failed -> {
                    _p2pErrorMessage.value = outcome.reason
                }
            }
        }
    }

    fun submitValidatorExit() {
        viewModelScope.launch(Dispatchers.IO) {
            val identity = identityManager.getActiveIdentity()
            if (identity == null) {
                _p2pErrorMessage.value = "No active Ed25519 node identity"
                return@launch
            }
            val senderAddr = transactionEngine.deriveSenderAddress(identity) ?: return@launch
            val payload = ValidatorTransactionPayload(
                nodeId = identity.nodeId,
                publicKeyHex = identity.publicKeyHex,
                displayName = nodeConfig.value.displayName,
                votingPower = 1L
            )
            when (
                val outcome = transactionEngine.createSignAndSubmit(
                    identityRepository = identityManager.repository,
                    recipientAddress = senderAddr,
                    amountUnits = 0L,
                    txType = TransactionType.VALIDATOR_EXIT,
                    payloadBytes = payload.toJsonBytes(),
                    attemptBroadcast = true
                )
            ) {
                is WalletTxCreationOutcome.Submitted -> {
                    _lastProductionAttemptMessage.value =
                        "Validator exit transaction queued (${outcome.record.transaction.shortTxId})"
                }
                is WalletTxCreationOutcome.Failed -> {
                    _p2pErrorMessage.value = outcome.reason
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        blockchainManager.close()
        transportRepository.close()
    }
}
