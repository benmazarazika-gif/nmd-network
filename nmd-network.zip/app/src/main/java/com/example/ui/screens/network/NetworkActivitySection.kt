package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.NetworkActivityEvent
import com.example.data.NetworkActivityType
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun NetworkActivitySection(
    activities: List<NetworkActivityEvent>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (activities.any { it.isDemo }) {
            // Disclaimer Banner only if demo events exist
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x1F00D2FF))
                    .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.activity_demo_disclaimer),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark,
                    lineHeight = 15.sp
                )
            }
        }

        // Timeline List Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp))
                .testTag("card_network_activity_list"),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (activities.isEmpty()) {
                    Text(
                        text = stringResource(R.string.stage19_activity_empty),
                        fontSize = 12.sp,
                        color = NmdTextSecondaryDark,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    activities.forEachIndexed { index, event ->
                        ActivityItemRow(event = event)
                        if (index < activities.size - 1) {
                            Spacer(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .padding(vertical = 4.dp)
                                    .background(Color(0x1A1E2D4E))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActivityItemRow(event: NetworkActivityEvent) {
    val (icon, iconTint, bgTint) = when (event.type) {
        NetworkActivityType.BLOCK_RECEIVED -> Triple(Icons.Default.Tag, NmdSuccessGreen, Color(0x2238EF7D))
        NetworkActivityType.SYNC_UPDATED -> Triple(Icons.Default.Sync, NmdElectricCyan, Color(0x2200D2FF))
        NetworkActivityType.PEER_CONNECTED -> Triple(Icons.Default.Hub, NmdElectricBlue, Color(0x220077FE))
        NetworkActivityType.CONFIG_CHANGED -> Triple(Icons.Default.Settings, NmdWarningOrange, Color(0x22FF9F43))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("activity_row_${event.id}"),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(bgTint),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(event.titleRes),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )

                if (event.isDemo) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0x1A00D2FF)
                    ) {
                        Text(
                            text = "DEMO",
                            color = NmdCyanBright,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = event.description,
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = event.timestamp,
                fontSize = 10.sp,
                color = NmdTextMutedDark
            )
        }
    }
}
