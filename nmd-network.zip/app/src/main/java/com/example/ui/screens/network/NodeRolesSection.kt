package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.NodeConfiguration
import com.example.data.NodeRole
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun NodeRolesSection(
    nodeConfig: NodeConfiguration,
    onConfigureRole: (NodeRole) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        NodeRole.entries.forEach { role ->
            val isCurrentRole = nodeConfig.selectedRole == role
            val isActive = isCurrentRole && nodeConfig.isDemoActive

            val roleIcon: ImageVector = when (role) {
                NodeRole.VALIDATOR -> Icons.Default.Security
                NodeRole.FULL_NODE -> Icons.Default.Dns
                NodeRole.LIGHT_NODE -> Icons.Default.Smartphone
                NodeRole.RELAY_NODE -> Icons.Default.FlashOn
                NodeRole.STORAGE_NODE -> Icons.Default.Storage
            }

            val iconTint: Color = when (role) {
                NodeRole.VALIDATOR -> NmdWarningOrange
                NodeRole.FULL_NODE -> NmdElectricBlue
                NodeRole.LIGHT_NODE -> NmdSuccessGreen
                NodeRole.RELAY_NODE -> NmdElectricCyan
                NodeRole.STORAGE_NODE -> NmdCyanBright
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isActive) NmdSuccessGreen else if (isCurrentRole) NmdElectricCyan else NmdDarkCardBorder,
                        RoundedCornerShape(18.dp)
                    )
                    .testTag("card_node_role_${role.name}"),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0F1A30)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = roleIcon,
                                    contentDescription = null,
                                    tint = iconTint,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = stringResource(role.titleRes),
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NmdTextPrimaryDark
                                    )
                                )
                                Text(
                                    text = stringResource(role.descRes),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = NmdTextSecondaryDark,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }

                        // Status Pill
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isActive) Color(0x2238EF7D) else Color(0x1A00D2FF)
                        ) {
                            Text(
                                text = if (isActive) "ACTIVE (DEMO)" else if (isCurrentRole) "SELECTED" else "READY",
                                color = if (isActive) NmdSuccessGreen else if (isCurrentRole) NmdElectricCyan else NmdCyanBright,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Responsibilities
                    Text(
                        text = stringResource(role.responsibilitiesRes),
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Hardware Specs Pill Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0C1628))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = stringResource(R.string.node_specs_ram), fontSize = 9.sp, color = NmdTextSecondaryDark)
                            Text(text = role.estimatedRam, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NmdTextPrimaryDark)
                        }
                        Column {
                            Text(text = stringResource(R.string.node_specs_storage), fontSize = 9.sp, color = NmdTextSecondaryDark)
                            Text(text = role.estimatedStorage, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NmdTextPrimaryDark)
                        }
                        Column {
                            Text(text = stringResource(R.string.node_specs_battery), fontSize = 9.sp, color = NmdTextSecondaryDark)
                            Text(text = role.estimatedBattery, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NmdTextPrimaryDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action Button
                    if (isCurrentRole) {
                        OutlinedButton(
                            onClick = { onConfigureRole(role) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("btn_configure_role_${role.name}"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NmdElectricCyan)
                        ) {
                            Text(
                                text = stringResource(R.string.node_btn_configure),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NmdElectricCyan
                            )
                        }
                    } else {
                        Button(
                            onClick = { onConfigureRole(role) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("btn_select_role_${role.name}"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                        ) {
                            Text(
                                text = "Select & Configure",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
