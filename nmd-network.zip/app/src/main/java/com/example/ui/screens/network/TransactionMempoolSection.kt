package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.transaction.model.MempoolStatsSnapshot
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun TransactionMempoolSection(
    mempoolStats: MempoolStatsSnapshot,
    mempoolTransactions: List<MempoolTransactionRecord>,
    onBroadcastValidated: () -> Unit,
    onPruneExpired: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stage9_network_mempool_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.DynamicFeed,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage9_network_mempool_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Surface(
                    color = NmdElectricCyan.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, NmdElectricCyan.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = stringResource(R.string.stage9_mempool_badge),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdElectricCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = NmdDarkCardBorder)

            // Stats 2x3 Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MempoolStatTile(
                    label = stringResource(R.string.stage9_stat_mempool_size),
                    value = "${mempoolStats.activeValidOrQueuedCount}/${mempoolStats.maxCapacity}",
                    valueColor = NmdElectricCyan,
                    modifier = Modifier.weight(1f)
                )
                MempoolStatTile(
                    label = stringResource(R.string.stage9_stat_valid_pending),
                    value = "${mempoolStats.validatedCount}",
                    valueColor = NmdSuccessGreen,
                    modifier = Modifier.weight(1f)
                )
                MempoolStatTile(
                    label = stringResource(R.string.stage9_stat_queued),
                    value = "${mempoolStats.queuedCount}",
                    valueColor = NmdWarningOrange,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MempoolStatTile(
                    label = stringResource(R.string.stage9_stat_rejected),
                    value = "${mempoolStats.rejectedCount}",
                    valueColor = if (mempoolStats.rejectedCount > 0) NmdDangerRed else NmdTextSecondaryDark,
                    modifier = Modifier.weight(1f)
                )
                MempoolStatTile(
                    label = stringResource(R.string.stage9_stat_received_p2p),
                    value = "${mempoolStats.receivedFromPeersCount}",
                    valueColor = NmdCyanBright,
                    modifier = Modifier.weight(1f)
                )
                MempoolStatTile(
                    label = stringResource(R.string.stage9_stat_duplicates),
                    value = "${mempoolStats.duplicateSuppressedCount}",
                    valueColor = NmdTextPrimaryDark,
                    modifier = Modifier.weight(1f)
                )
            }

            // Propagation & Validation Summary
            MempoolKeyValueLine(
                label = stringResource(R.string.stage9_field_propagation_status),
                value = mempoolStats.propagationSummary,
                valueColor = if (mempoolStats.authenticatedPeersCount > 0) NmdSuccessGreen else NmdWarningOrange
            )
            MempoolKeyValueLine(
                label = stringResource(R.string.stage9_field_validation_stats),
                value = "OK:${mempoolStats.validatedCount + mempoolStats.queuedCount} | REJ:${mempoolStats.rejectedCount} | EXP:${mempoolStats.expiredCount}",
                valueColor = NmdTextPrimaryDark
            )

            mempoolStats.lastValidationError?.let { err ->
                Text(
                    text = err,
                    fontSize = 10.sp,
                    color = NmdDangerRed
                )
            }

            // Recent mempool items preview (max 4)
            if (mempoolTransactions.isNotEmpty()) {
                HorizontalDivider(color = NmdDarkCardBorder)
                mempoolTransactions.take(4).forEach { rec ->
                    val statusColor = when (rec.status) {
                        MempoolTxStatus.VALIDATED -> NmdSuccessGreen
                        MempoolTxStatus.QUEUED, MempoolTxStatus.PENDING -> NmdWarningOrange
                        MempoolTxStatus.REJECTED, MempoolTxStatus.EXPIRED -> NmdDangerRed
                        MempoolTxStatus.CONFIRMED -> NmdElectricCyan
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0A1426))
                            .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${rec.transaction.shortTxId} • #${rec.transaction.nonce}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = NmdTextPrimaryDark
                            )
                            Text(
                                text = "${rec.transaction.txType.name} • ${NmdAmountCodec.formatUnitsToNmd(rec.transaction.amountUnits)} NMD",
                                fontSize = 10.sp,
                                color = NmdTextSecondaryDark
                            )
                        }
                        Surface(
                            color = statusColor.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = rec.status.name,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onBroadcastValidated,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage9_broadcast_validated_btn"),
                    border = BorderStroke(1.dp, NmdElectricCyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.stage9_action_broadcast_pending),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                OutlinedButton(
                    onClick = onPruneExpired,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage9_prune_expired_btn"),
                    border = BorderStroke(1.dp, NmdDarkCardBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdTextSecondaryDark)
                ) {
                    Icon(
                        imageVector = Icons.Default.CleaningServices,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.stage9_action_prune_expired),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun MempoolStatTile(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF091324))
            .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 8.dp, vertical = 7.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 9.sp,
                color = NmdTextSecondaryDark,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = valueColor
            )
        }
    }
}

@Composable
private fun MempoolKeyValueLine(
    label: String,
    value: String,
    valueColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            color = valueColor
        )
    }
}
