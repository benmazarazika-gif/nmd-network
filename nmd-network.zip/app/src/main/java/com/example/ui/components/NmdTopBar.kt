package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen

@Composable
fun NmdTopBar(
    onLanguageClick: () -> Unit,
    onNotificationClick: () -> Unit,
    isConnected: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Language switcher button (Globe)
        IconButton(
            onClick = onLanguageClick,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(NmdDarkCard)
                .border(1.dp, NmdDarkCardBorder, CircleShape)
                .testTag("top_bar_language_btn")
        ) {
            Icon(
                imageVector = Icons.Outlined.Language,
                contentDescription = "Language Selector",
                tint = NmdElectricCyan,
                modifier = Modifier.size(22.dp)
            )
        }

        // Center Network Status Pill (Distinguishing simulated / demo status)
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF0F1E38),
                            Color(0xFF13274B)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0x3300D2FF),
                            Color(0x5538EF7D),
                            Color(0x3300D2FF)
                        )
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .testTag("network_status_pill")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // Live status indicator
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isConnected) NmdSuccessGreen else Color(0xFFFF9F43))
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = stringResource(
                            if (isConnected) R.string.status_connected else R.string.stage19_service_stopped
                        ),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = stringResource(R.string.status_live_network),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Normal,
                        color = NmdElectricCyan
                    )
                }
            }
        }

        // Notifications button (Bell)
        IconButton(
            onClick = onNotificationClick,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(NmdDarkCard)
                .border(1.dp, NmdDarkCardBorder, CircleShape)
                .testTag("top_bar_notifications_btn")
        ) {
            Box {
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = "Notifications",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
                // Unread dot
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(NmdElectricCyan)
                        .align(Alignment.TopEnd)
                )
            }
        }
    }
}
