package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NMD Brand Palette (Futuristic Layer-1 Blockchain Identity)
val NmdDarkBackground = Color(0xFF070B16)
val NmdDarkSurface = Color(0xFF0E1628)
val NmdDarkCard = Color(0xFF121D36)
val NmdDarkCardBorder = Color(0xFF1E2D4E)
val NmdDarkCardHover = Color(0xFF182645)

val NmdElectricCyan = Color(0xFF00D2FF)
val NmdElectricBlue = Color(0xFF0077FE)
val NmdCyanBright = Color(0xFF54E5FF)
val NmdCyanSoft = Color(0x3300D2FF)
val NmdCyanGlow = Color(0x6600D2FF)

val NmdSuccessGreen = Color(0xFF38EF7D)
val NmdSuccessGreenBg = Color(0x1F38EF7D)
val NmdWarningOrange = Color(0xFFFF9F43)
val NmdWarningOrangeBg = Color(0x1FFFF9F43)
val NmdDangerRed = Color(0xFFFF5252)
val NmdDangerRedBg = Color(0x1FFF5252)

val NmdTextPrimaryDark = Color(0xFFF1F5F9)
val NmdTextSecondaryDark = Color(0xFF94A3B8)
val NmdTextMutedDark = Color(0xFF64748B)

// Light Theme Palette
val NmdLightBackground = Color(0xFFF4F7FC)
val NmdLightSurface = Color(0xFFFFFFFF)
val NmdLightCard = Color(0xFFFFFFFF)
val NmdLightCardBorder = Color(0xFFE2E8F0)
val NmdTextPrimaryLight = Color(0xFF0F172A)
val NmdTextSecondaryLight = Color(0xFF475569)
val NmdTextMutedLight = Color(0xFF94A3B8)
