package com.example.ui.screens.network

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.crypto.model.ProtocolMessageType
import com.example.p2p.discovery.DiscoveryMethod
import com.example.p2p.discovery.DiscoveryStatusState
import com.example.p2p.discovery.bootstrap.BootstrapPeer
import com.example.p2p.discovery.registry.PeerFilterOption
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.topology.TopologyMetrics
import com.example.p2p.model.DiscoveredPeer
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.model.RealPeerInfo
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.protocol.ReliableMessageRecord
import com.example.p2p.reliable.DeliveryStatus
import com.example.p2p.repository.MessageDirection
import com.example.p2p.repository.MessageExchangeRecord
import com.example.p2p.service.P2pTestLabReport
import com.example.p2p.session.ConnectionHealth
import com.example.p2p.session.PeerSession
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun RealP2pSection(
    isListening: Boolean,
    boundPort: Int?,
    localIp: String,
    discoveredPeers: List<DiscoveredPeer>,
    authenticatedPeers: List<RealPeerInfo>,
    messageHistory: List<MessageExchangeRecord>,
    errorMessage: String?,
    onToggleListening: () -> Unit,
    onConnectToPeer: (host: String, port: Int, claimedNodeId: String?) -> Unit,
    onDisconnectPeer: (connectionId: String) -> Unit,
    onSendSignedMessage: (connectionId: String, messageType: ProtocolMessageType, payload: String) -> Unit,
    onOpenManualConnectDialog: () -> Unit,
    onClearErrorMessage: () -> Unit,
    modifier: Modifier = Modifier,
    // Stage 6 Reliable Messaging Parameters
    sessions: List<PeerSession> = emptyList(),
    reliableMessageLog: List<ReliableMessageRecord> = emptyList(),
    testReport: P2pTestLabReport? = null,
    isTestLabRunning: Boolean = false,
    onSelectSessionForDetail: (PeerSession) -> Unit = {},
    onSendReliableMessage: (sessionId: String, type: P2pMessageType, payload: String) -> Unit = { _, _, _ -> },
    onSendPing: (sessionId: String) -> Unit = {},
    onRunTestLabSuite: (sessionId: String) -> Unit = {},
    onClearTestReport: () -> Unit = {},
    // Stage 7 Distributed Peer Discovery Parameters
    topologyMetrics: TopologyMetrics = TopologyMetrics(),
    discoveryStatus: DiscoveryStatusState = DiscoveryStatusState.IDLE,
    discoveryMethod: DiscoveryMethod = DiscoveryMethod.NONE,
    lastSuccessfulDiscoveryMs: Long? = null,
    registeredPeers: List<PeerRegistryRecord> = emptyList(),
    bootstrapPeers: List<BootstrapPeer> = emptyList(),
    selectedRegistryFilter: PeerFilterOption = PeerFilterOption.ALL,
    onSelectRegistryFilter: (PeerFilterOption) -> Unit = {},
    onRefreshDiscovery: () -> Unit = {},
    onRequestPeerExchange: () -> Unit = {},
    onConnectToRegistryPeer: (String) -> Unit = {},
    onRemoveRegistryPeer: (String) -> Unit = {},
    onConnectBootstrapPeer: (String) -> Unit = {},
    onToggleBootstrapPeer: (String, Boolean) -> Unit = { _, _ -> },
    onRemoveBootstrapPeer: (String) -> Unit = {},
    onAddCustomBootstrapPeer: (name: String, host: String, port: Int, expectedNodeId: String?) -> Unit = { _, _, _, _ -> }
) {
    var selectedPeerForSend by remember { mutableStateOf<String?>(null) }
    var activeSessionForDetail by remember { mutableStateOf<PeerSession?>(null) }
    var testPayloadText by remember { mutableStateOf("{\"type\":\"DATA\",\"content\":\"Hello from NMD Stage 6 Peer\"}") }

    // Dialog for inspecting peer session details
    activeSessionForDetail?.let { session ->
        PeerDetailDialog(
            session = session,
            onDismiss = { activeSessionForDetail = null },
            onSendMessage = onSendReliableMessage,
            onSendPing = onSendPing,
            onDisconnect = onDisconnectPeer
        )
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Error banner if any
        AnimatedVisibility(visible = errorMessage != null) {
            errorMessage?.let { error ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1212)),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NmdDangerRed)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = NmdDangerRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = error,
                            color = NmdDangerRed,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onClearErrorMessage, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss",
                                tint = NmdTextSecondaryDark,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Real P2P Security Notice
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E33)),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NmdElectricBlue)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = stringResource(R.string.p2p_security_banner_title),
                        fontWeight = FontWeight.Bold,
                        color = NmdCyanBright,
                        fontSize = 12.sp
                    )
                    Text(
                        text = stringResource(R.string.p2p_security_banner_desc),
                        color = NmdTextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Stage 6: Peer Communication Dashboard Metrics
        val activeCount = sessions.count { it.isTrusted }
        val totalSent = sessions.sumOf { it.messagesSentCount }
        val totalReceived = sessions.sumOf { it.messagesReceivedCount }
        val totalAcked = sessions.sumOf { it.successfulDeliveriesCount }
        val totalFailed = sessions.sumOf { it.failedDeliveriesCount }
        val successRate = if (totalSent > 0) ((totalAcked * 100) / (totalAcked + totalFailed).coerceAtLeast(1L)).toInt() else 100

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.p2p_dashboard_title),
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark,
                        fontSize = 14.sp
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0x2E00E5FF)
                    ) {
                        Text(
                            text = "STAGE 6",
                            color = NmdElectricCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = stringResource(R.string.p2p_active_sessions_stat), fontSize = 11.sp, color = NmdTextSecondaryDark)
                        Text(text = "$activeCount", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NmdCyanBright)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = stringResource(R.string.p2p_total_tx_stat), fontSize = 11.sp, color = NmdTextSecondaryDark)
                        Text(text = "$totalSent", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NmdTextPrimaryDark)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = stringResource(R.string.p2p_total_rx_stat), fontSize = 11.sp, color = NmdTextSecondaryDark)
                        Text(text = "$totalReceived", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NmdTextPrimaryDark)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = stringResource(R.string.p2p_delivery_rate_stat), fontSize = 11.sp, color = NmdTextSecondaryDark)
                        Text(text = "$successRate%", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NmdSuccessGreen)
                    }
                }
            }
        }

        // Local Transport Listener Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Wifi else Icons.Default.WifiOff,
                            contentDescription = null,
                            tint = if (isListening) NmdSuccessGreen else NmdWarningOrange,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.p2p_transport_listener_title),
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark,
                            fontSize = 14.sp
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isListening) Color(0x2E10B981) else Color(0x2EF59E0B)
                    ) {
                        Text(
                            text = if (isListening) stringResource(R.string.p2p_status_listening) else stringResource(R.string.p2p_status_stopped),
                            color = if (isListening) NmdSuccessGreen else NmdWarningOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.p2p_local_endpoint_label),
                            fontSize = 11.sp,
                            color = NmdTextSecondaryDark
                        )
                        Text(
                            text = "$localIp:${boundPort ?: "--"}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = NmdElectricCyan
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = stringResource(R.string.p2p_active_peers_count_label),
                            fontSize = 11.sp,
                            color = NmdTextSecondaryDark
                        )
                        Text(
                            text = "${authenticatedPeers.size} / 10",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = NmdTextPrimaryDark
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onToggleListening,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListening) Color(0xFF331616) else NmdElectricBlue
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("p2p_toggle_listener_btn")
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (isListening) NmdDangerRed else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isListening) stringResource(R.string.p2p_action_stop_listener) else stringResource(R.string.p2p_action_start_listener),
                            fontSize = 12.sp,
                            color = if (isListening) NmdDangerRed else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onOpenManualConnectDialog,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NmdElectricCyan),
                        modifier = Modifier.testTag("p2p_manual_connect_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddLink,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.p2p_action_manual_connect),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Authenticated Connected Real Peers Section
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.p2p_authenticated_peers_title),
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark,
                    fontSize = 14.sp
                )
                Text(
                    text = "${authenticatedPeers.size} ${stringResource(R.string.p2p_peers_connected_suffix)}",
                    color = NmdTextSecondaryDark,
                    fontSize = 11.sp
                )
            }

            if (authenticatedPeers.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(R.string.p2p_no_active_peers_hint),
                            color = NmdTextSecondaryDark,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                authenticatedPeers.forEach { peer ->
                    val isSelected = selectedPeerForSend == peer.connectionId
                    val session = sessions.find { it.sessionId == peer.connectionId }
                    val healthColor = when (session?.connectionHealth) {
                        ConnectionHealth.EXCELLENT -> NmdSuccessGreen
                        ConnectionHealth.GOOD -> NmdElectricCyan
                        ConnectionHealth.DEGRADED -> NmdWarningOrange
                        ConnectionHealth.UNRESPONSIVE -> NmdDangerRed
                        null -> NmdSuccessGreen
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedPeerForSend = if (isSelected) null else peer.connectionId
                            }
                            .testTag("real_peer_card_${peer.connectionId}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF142442) else NmdDarkCard
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NmdElectricCyan else NmdDarkCardBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(healthColor)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = peer.authenticatedNodeId?.take(16) ?: "Connecting...",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = NmdCyanBright,
                                        fontSize = 13.sp
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${peer.lastPingLatencyMs}ms",
                                        fontSize = 11.sp,
                                        color = healthColor,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    // Details Action
                                    session?.let { s ->
                                        OutlinedButton(
                                            onClick = { activeSessionForDetail = s },
                                            modifier = Modifier.height(28.dp),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, NmdElectricCyan)
                                        ) {
                                            Text(
                                                text = stringResource(R.string.p2p_action_view_details),
                                                fontSize = 10.sp,
                                                color = NmdElectricCyan,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    IconButton(
                                        onClick = { onDisconnectPeer(peer.connectionId) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Disconnect",
                                            tint = NmdTextSecondaryDark,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${peer.endpoint.host}:${peer.endpoint.port} • ${if (peer.isOutbound) "Outbound" else "Inbound"}",
                                    fontSize = 11.sp,
                                    color = NmdTextSecondaryDark
                                )
                                Text(
                                    text = "Tx: ${peer.messagesSent} | Rx: ${peer.messagesReceived} | ACK: ${session?.successfulDeliveriesCount ?: 0}",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = NmdTextSecondaryDark
                                )
                            }

                            // Quick message send action when selected
                            AnimatedVisibility(visible = isSelected) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    HorizontalDivider(color = NmdDarkCardBorder)
                                    Text(
                                        text = stringResource(R.string.p2p_send_test_message_title),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NmdTextPrimaryDark
                                    )
                                    OutlinedTextField(
                                        value = testPayloadText,
                                        onValueChange = { testPayloadText = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NmdElectricCyan,
                                            unfocusedBorderColor = NmdDarkCardBorder,
                                            focusedTextColor = NmdTextPrimaryDark,
                                            unfocusedTextColor = NmdTextPrimaryDark
                                        ),
                                        textStyle = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp
                                        ),
                                        maxLines = 2
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { onSendPing(peer.connectionId) },
                                            shape = RoundedCornerShape(8.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, NmdElectricCyan),
                                            modifier = Modifier.testTag("quick_ping_peer_btn")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.NetworkCheck,
                                                contentDescription = null,
                                                tint = NmdElectricCyan,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = stringResource(R.string.p2p_action_ping),
                                                fontSize = 11.sp,
                                                color = NmdElectricCyan,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Spacer(modifier = Modifier.weight(1f))

                                        Button(
                                            onClick = {
                                                onSendReliableMessage(
                                                    peer.connectionId,
                                                    P2pMessageType.DATA,
                                                    testPayloadText
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.testTag("send_p2p_message_btn")
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Send,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = stringResource(R.string.p2p_action_send_reliable),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Stage 6: Dedicated Protocol Test Lab Section
        P2pTestLabSection(
            sessions = sessions,
            testReport = testReport,
            isRunning = isTestLabRunning,
            onRunTestSuite = onRunTestLabSuite,
            onClearReport = onClearTestReport
        )

        // Discovered Local Peers (mDNS / NSD)
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.p2p_discovered_peers_title),
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark,
                    fontSize = 14.sp
                )
                Text(
                    text = "${discoveredPeers.size} ${stringResource(R.string.p2p_peers_discovered_suffix)}",
                    color = NmdTextSecondaryDark,
                    fontSize = 11.sp
                )
            }

            if (discoveredPeers.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(R.string.p2p_no_discovered_peers_hint),
                            color = NmdTextSecondaryDark,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                discoveredPeers.forEach { peer ->
                    val isAlreadyConnected = authenticatedPeers.any {
                        it.endpoint.host == peer.host && it.endpoint.port == peer.port
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = peer.serviceName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = NmdTextPrimaryDark
                                )
                                Text(
                                    text = "${peer.host}:${peer.port}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = NmdElectricCyan
                                )
                                peer.advertisedNodeId?.let { id ->
                                    Text(
                                        text = id.take(16) + "...",
                                        fontSize = 10.sp,
                                        color = NmdTextSecondaryDark
                                    )
                                }
                            }

                            Button(
                                onClick = { onConnectToPeer(peer.host, peer.port, peer.advertisedNodeId) },
                                enabled = !isAlreadyConnected,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isAlreadyConnected) Color(0xFF1E293B) else NmdElectricBlue
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("connect_discovered_peer_${peer.port}")
                            ) {
                                Text(
                                    text = if (isAlreadyConnected) stringResource(R.string.p2p_status_connected) else stringResource(R.string.p2p_action_connect),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Stage 6 Reliable P2P Protocol Messages Log
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = stringResource(R.string.p2p_reliable_log_title),
                fontWeight = FontWeight.Bold,
                color = NmdTextPrimaryDark,
                fontSize = 14.sp
            )

            if (reliableMessageLog.isEmpty() && messageHistory.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(R.string.p2p_no_reliable_messages_hint),
                            color = NmdTextSecondaryDark,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                // Display Stage 6 reliable messages if available
                reliableMessageLog.take(20).forEach { record ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (record.direction == MessageDirection.OUTGOING) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = null,
                                tint = if (record.direction == MessageDirection.OUTGOING) NmdElectricCyan else NmdSuccessGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${record.messageType.name} • ${if (record.direction == MessageDirection.OUTGOING) "To" else "From"}: ${record.displayRemotePeerId}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = NmdTextPrimaryDark
                                    )
                                    // Status Badge
                                    val (badgeText, badgeColor) = when {
                                        record.isDuplicate -> Pair(stringResource(R.string.p2p_badge_duplicate), NmdWarningOrange)
                                        record.status == DeliveryStatus.ACKNOWLEDGED -> Pair(
                                            if (record.roundTripLatencyMs > 0) "${stringResource(R.string.p2p_badge_ack)} (${record.roundTripLatencyMs}ms)" else stringResource(R.string.p2p_badge_ack),
                                            NmdSuccessGreen
                                        )
                                        record.status == DeliveryStatus.TIMED_OUT -> Pair(stringResource(R.string.p2p_badge_timeout), NmdDangerRed)
                                        record.status == DeliveryStatus.FAILED -> Pair(stringResource(R.string.p2p_badge_failed), NmdDangerRed)
                                        else -> Pair("PENDING ACK", NmdWarningOrange)
                                    }
                                    Text(
                                        text = badgeText,
                                        fontSize = 9.sp,
                                        color = badgeColor,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = record.payload,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = NmdTextSecondaryDark,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // If reliableMessageLog is empty but Stage 5 messageHistory has entries, show Stage 5 log
                if (reliableMessageLog.isEmpty()) {
                    messageHistory.forEach { record ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (record.direction == MessageDirection.OUTGOING) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                    contentDescription = null,
                                    tint = if (record.direction == MessageDirection.OUTGOING) NmdElectricCyan else NmdSuccessGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${record.messageType} • ${if (record.direction == MessageDirection.OUTGOING) "To" else "From"}: ${record.remoteNodeId.take(10)}...",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = NmdTextPrimaryDark
                                        )
                                        Text(
                                            text = "NMD-SIG-V2",
                                            fontSize = 9.sp,
                                            color = NmdSuccessGreen,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = record.payload,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = NmdTextSecondaryDark,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Stage 7: Distributed Peer Discovery, Bootstrap & Topology Registry
        DistributedDiscoverySection(
            topologyMetrics = topologyMetrics,
            discoveryStatus = discoveryStatus,
            discoveryMethod = discoveryMethod,
            lastSuccessfulDiscoveryMs = lastSuccessfulDiscoveryMs,
            registeredPeers = registeredPeers,
            bootstrapPeers = bootstrapPeers,
            selectedFilter = selectedRegistryFilter,
            onSelectFilter = onSelectRegistryFilter,
            onRefreshDiscovery = onRefreshDiscovery,
            onRequestPeerExchange = onRequestPeerExchange,
            onConnectToRegistryPeer = onConnectToRegistryPeer,
            onRemoveRegistryPeer = onRemoveRegistryPeer,
            onConnectBootstrapPeer = onConnectBootstrapPeer,
            onToggleBootstrapPeer = onToggleBootstrapPeer,
            onRemoveBootstrapPeer = onRemoveBootstrapPeer,
            onAddCustomBootstrapPeer = onAddCustomBootstrapPeer
        )
    }
}
