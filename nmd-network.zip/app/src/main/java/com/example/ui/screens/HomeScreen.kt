package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ActivityType
import com.example.data.RecentActivityItem
import com.example.ui.components.NmdLogoBadge
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdSuccessGreenBg
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToSend: () -> Unit,
    onNavigateToReceive: () -> Unit,
    onNavigateToSecurity: () -> Unit,
    onNavigateToNetwork: () -> Unit,
    onViewAllActivities: () -> Unit,
    modifier: Modifier = Modifier
) {
    val walletState by viewModel.walletState.collectAsState()
    val activities by viewModel.recentActivities.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("home_screen_content")
    ) {
        // Total Balance Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0x6600D2FF),
                            Color(0x330077FE),
                            Color(0x221E2D4E)
                        )
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .testTag("balance_card"),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF0C172E)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF132B52),
                                Color(0xFF0C172E)
                            ),
                            radius = 450f
                        )
                    )
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NmdLogoBadge(size = 56.dp, fontSize = 28)

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = stringResource(R.string.wallet_total_balance),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = NmdTextSecondaryDark
                                )
                            )

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0x3300D2FF),
                                modifier = Modifier.border(0.5.dp, NmdCyanBright, RoundedCornerShape(8.dp))
                            ) {
                                Text(
                                    text = stringResource(R.string.stage19_wallet_live_badge),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NmdElectricCyan,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = walletState.totalBalanceFormatted,
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NmdTextPrimaryDark,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = walletState.tokenSymbol,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = NmdElectricCyan
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = if (walletState.walletAddress.isNotEmpty()) {
                                "${walletState.walletAddress.take(14)}...${walletState.walletAddress.takeLast(6)}"
                            } else {
                                stringResource(R.string.stage19_no_identity_prompt)
                            },
                            color = NmdTextSecondaryDark,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Action Buttons Row (Send, Receive, Backup Keys, Node Center)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            HomeActionButton(
                title = stringResource(R.string.action_send),
                icon = Icons.AutoMirrored.Filled.Send,
                onClick = onNavigateToSend,
                testTag = "home_btn_send",
                modifier = Modifier.weight(1f)
            )
            HomeActionButton(
                title = stringResource(R.string.action_receive),
                icon = Icons.Filled.FileDownload,
                onClick = onNavigateToReceive,
                testTag = "home_btn_receive",
                modifier = Modifier.weight(1f)
            )
            HomeActionButton(
                title = stringResource(R.string.stage19_home_btn_security),
                icon = Icons.Filled.Security,
                onClick = onNavigateToSecurity,
                testTag = "home_btn_security",
                modifier = Modifier.weight(1f)
            )
            HomeActionButton(
                title = stringResource(R.string.stage19_home_btn_node),
                icon = Icons.Filled.Hub,
                onClick = onNavigateToNetwork,
                testTag = "home_btn_node",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Recent Activity Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.activity_title),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
            )

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onViewAllActivities() }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.activity_view_all),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = NmdElectricCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Activity List Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                if (activities.isEmpty()) {
                    Text(
                        text = stringResource(R.string.stage19_activity_empty),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextMutedDark,
                            lineHeight = 18.sp
                        ),
                        modifier = Modifier.padding(10.dp)
                    )
                } else {
                    activities.forEachIndexed { index, item ->
                        ActivityRowItem(item = item)
                        if (index < activities.size - 1) {
                            Spacer(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .padding(vertical = 4.dp)
                                    .background(Color(0x1A1E2D4E))
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Ledger Notice Chip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x1A00D2FF))
                .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ⓘ " + stringResource(R.string.stage19_wallet_disclaimer),
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NmdCyanBright,
                    lineHeight = 16.sp
                )
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun HomeActionButton(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF11203A),
                        Color(0xFF0C1629)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x3300D2FF),
                        Color(0x111E2D4E)
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 4.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x2200D2FF)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = NmdElectricCyan,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = NmdTextPrimaryDark
            ),
            maxLines = 1
        )
    }
}

@Composable
fun ActivityRowItem(item: RecentActivityItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icon badge
        val badgeBg = when (item.type) {
            ActivityType.RECEIVE -> NmdSuccessGreenBg
            ActivityType.SEND -> Color(0x220077FE)
            ActivityType.REWARD -> Color(0x22FF9F43)
        }
        val iconTint = when (item.type) {
            ActivityType.RECEIVE -> NmdSuccessGreen
            ActivityType.SEND -> NmdElectricBlue
            ActivityType.REWARD -> NmdWarningOrange
        }
        val iconVector = when (item.type) {
            ActivityType.RECEIVE -> Icons.AutoMirrored.Filled.TrendingDown
            ActivityType.SEND -> Icons.AutoMirrored.Filled.TrendingUp
            ActivityType.REWARD -> Icons.Default.CardGiftcard
        }

        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(badgeBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = iconVector,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(item.titleRes),
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = NmdTextPrimaryDark
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = stringResource(item.timeRes),
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NmdTextMutedDark
                )
            )
        }

        Text(
            text = item.amountFormatted,
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (item.isCredit) NmdSuccessGreen else Color(0xFFFF6B6B)
            )
        )
    }
}
