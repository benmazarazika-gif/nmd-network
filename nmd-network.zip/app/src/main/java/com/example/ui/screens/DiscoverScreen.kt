package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.blockchain.config.BlockchainParameters
import com.example.blockchain.economics.TokenomicsEngine
import com.example.ui.components.FeatureNoticeDialog
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark

data class DiscoverCardItem(
    val categoryKey: String,
    val titleRes: Int,
    val subtitleRes: Int,
    val specDetail: String,
    val icon: ImageVector,
    val bgColors: List<Color>,
    val testTag: String
)

@Composable
fun DiscoverScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("all") }
    var clickedCategoryItem by remember { mutableStateOf<DiscoverCardItem?>(null) }

    if (clickedCategoryItem != null) {
        val selected = clickedCategoryItem!!
        FeatureNoticeDialog(
            title = stringResource(selected.titleRes),
            message = selected.specDetail,
            onDismiss = { clickedCategoryItem = null }
        )
    }

    val categories = listOf(
        DiscoverCardItem(
            categoryKey = "games",
            titleRes = R.string.category_gaming,
            subtitleRes = R.string.category_gaming_sub,
            specDetail = "BFT Consensus Engine:\n• Quorum Threshold: 2f+1 Voting Power\n• Finality: Instant Single-Slot CommitCertificate\n• Equivocation Detection & Evidence Logging Active",
            icon = Icons.Default.SportsEsports,
            bgColors = listOf(Color(0xFF8B257E), Color(0xFF4A104E)),
            testTag = "category_gaming"
        ),
        DiscoverCardItem(
            categoryKey = "finance",
            titleRes = R.string.category_defi,
            subtitleRes = R.string.category_defi_sub,
            specDetail = "Audited Tokenomics & Deterministic State:\n• Max Cap: 100,000,000,000 NMD (Fixed-point uNMD)\n• Schedule: 1B Genesis + 25y Emission (1y cliff, 24y linear)\n• Split: 5% Founders / 15% Ecosystem / 20% Staking / 60% Mining\n• Mainnet Issuance: ${if (TokenomicsEngine.isTokenIssuanceActive(BlockchainParameters())) "ACTIVE" else "DORMANT (Pre-Audit Guard)"}",
            icon = Icons.Default.Leaderboard,
            bgColors = listOf(Color(0xFF0077B6), Color(0xFF03045E)),
            testTag = "category_defi"
        ),
        DiscoverCardItem(
            categoryKey = "social",
            titleRes = R.string.category_social,
            subtitleRes = R.string.category_social_sub,
            specDetail = "Encrypted P2P Session Transport:\n• Identity: Ed25519 Persistent KeyStore / Encrypted Storage\n• Forward Secrecy: Ephemeral X25519 Key Exchange\n• Cipher: ChaCha20-Poly1305 AEAD Framed Messages\n• Trust Model: 15-min CGNAT lease + MITM detection",
            icon = Icons.Default.People,
            bgColors = listOf(Color(0xFF007F5F), Color(0xFF104537)),
            testTag = "category_social"
        ),
        DiscoverCardItem(
            categoryKey = "finance",
            titleRes = R.string.category_marketplace,
            subtitleRes = R.string.category_marketplace_sub,
            specDetail = "Transaction Engine & Fee Market:\n• Non-custodial Local Ed25519 Signing\n• Persistent Mempool with Nonce Gap & Replay Checks\n• Priority Fee Sorting & Archival Room Persistence\n• Dynamic Fee Split & Zero-Overflow BigInteger Ledger",
            icon = Icons.Default.ShoppingBag,
            bgColors = listOf(Color(0xFF9E5A18), Color(0xFF4D2800)),
            testTag = "category_marketplace"
        ),
        DiscoverCardItem(
            categoryKey = "tools",
            titleRes = R.string.category_storage,
            subtitleRes = R.string.category_storage_sub,
            specDetail = "Blockchain Storage & Chain-ID Isolation:\n• Room SQLite v2 with Archival Transactions & AccountState\n• Deterministic Canonical StateRoot (SHA-256)\n• Isolated DB Namespaces per Chain ID\n• Verified Range Block Sync & CommitCertificate Catch-up",
            icon = Icons.Default.CloudQueue,
            bgColors = listOf(Color(0xFF1D4ED8), Color(0xFF0F172A)),
            testTag = "category_storage"
        ),
        DiscoverCardItem(
            categoryKey = "tools",
            titleRes = R.string.category_developers,
            subtitleRes = R.string.category_developers_sub,
            specDetail = "NAT Traversal & Public Infrastructure:\n• WebRTC ICE Candidate Gathering (Host / STUN / TURN)\n• Production Bootstrap & Signaling WebSocket Services\n• Ed25519 Signed Challenge-Response Peer Auth\n• AndroidKeyStore Encrypted TURN Credentials",
            icon = Icons.Default.Code,
            bgColors = listOf(Color(0xFF6B21A8), Color(0xFF2E1065)),
            testTag = "category_developers"
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("discover_screen_content")
    ) {
        // Screen Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NmdDarkCard)
                    .testTag("discover_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Text(
                text = stringResource(R.string.nav_discover),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
            )

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NmdDarkCard),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Explore,
                    contentDescription = null,
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = stringResource(R.string.stage19_discover_subtitle),
            style = MaterialTheme.typography.bodySmall.copy(color = NmdTextSecondaryDark)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = {
                Text(
                    stringResource(R.string.discover_search_hint),
                    color = NmdTextMutedDark,
                    fontSize = 13.sp
                )
            },
            trailingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = NmdElectricCyan
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("discover_search_input"),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0F1A30),
                unfocusedContainerColor = Color(0xFF0F1A30),
                focusedBorderColor = NmdElectricCyan,
                unfocusedBorderColor = NmdDarkCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Filter Tags Row
        val filters = listOf(
            "all" to stringResource(R.string.discover_filter_all),
            "games" to stringResource(R.string.discover_filter_games),
            "finance" to stringResource(R.string.discover_filter_finance),
            "social" to stringResource(R.string.discover_filter_social),
            "tools" to stringResource(R.string.discover_filter_tools)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filters.forEach { (key, label) ->
                val isSelected = selectedFilter == key
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) NmdElectricBlue else Color(0xFF10192D))
                        .border(1.dp, if (isSelected) NmdElectricCyan else NmdDarkCardBorder, RoundedCornerShape(12.dp))
                        .clickable { selectedFilter = key }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("filter_$key"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else NmdTextSecondaryDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        val filteredCategories = categories.filter { item ->
            val matchesFilter = selectedFilter == "all" || item.categoryKey == selectedFilter
            val q = searchQuery.trim().lowercase()
            val matchesSearch = q.isEmpty() ||
                stringResource(item.titleRes).lowercase().contains(q) ||
                stringResource(item.subtitleRes).lowercase().contains(q) ||
                item.specDetail.lowercase().contains(q)
            matchesFilter && matchesSearch
        }

        // 2-Column Grid of Filtered Cards
        for (i in filteredCategories.indices step 2) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val left = filteredCategories[i]
                CategoryGridCard(
                    item = left,
                    onClick = { clickedCategoryItem = left },
                    modifier = Modifier.weight(1f)
                )

                if (i + 1 < filteredCategories.size) {
                    val right = filteredCategories[i + 1]
                    CategoryGridCard(
                        item = right,
                        onClick = { clickedCategoryItem = right },
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun CategoryGridCard(
    item: DiscoverCardItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(115.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(item.testTag),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(item.bgColors))
                .padding(14.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(item.titleRes),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stringResource(item.subtitleRes),
                    fontSize = 10.sp,
                    color = Color(0xCCFFFFFF)
                )
            }
        }
    }
}
