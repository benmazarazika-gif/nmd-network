package com.example.ui.screens.network

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.p2p.service.P2pTestLabReport
import com.example.p2p.session.PeerSession
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun P2pTestLabSection(
    sessions: List<PeerSession>,
    testReport: P2pTestLabReport?,
    isRunning: Boolean,
    onRunTestSuite: (sessionId: String) -> Unit,
    onClearReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeSession = sessions.firstOrNull { it.isTrusted }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Science,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.p2p_test_lab_title),
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark,
                        fontSize = 14.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0x2E00E5FF)
                ) {
                    Text(
                        text = stringResource(R.string.p2p_test_lab_tag),
                        color = NmdElectricCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Physical vs Local Environment Disclosure Banner
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF132238),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3A5F)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.p2p_test_lab_environment_notice),
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark,
                        lineHeight = 15.sp
                    )
                }
            }

            Text(
                text = stringResource(R.string.p2p_test_lab_desc),
                fontSize = 12.sp,
                color = NmdTextSecondaryDark
            )

            // Target Session Selector Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.p2p_test_lab_target_label),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
                Text(
                    text = activeSession?.let { "Node: ${it.displayPeerId}" } ?: stringResource(R.string.p2p_test_lab_no_active_peer),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (activeSession != null) NmdCyanBright else NmdWarningOrange
                )
            }

            // Run Test Button
            Button(
                onClick = {
                    activeSession?.let { onRunTestSuite(it.sessionId) }
                },
                enabled = activeSession != null && !isRunning,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NmdElectricBlue,
                    disabledContainerColor = Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("run_p2p_test_lab_btn")
            ) {
                if (isRunning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.p2p_test_lab_running_status),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.p2p_test_lab_action_run),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Report Results
            AnimatedVisibility(visible = testReport != null) {
                testReport?.let { report ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HorizontalDivider(color = NmdDarkCardBorder)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (report.allPassed) NmdSuccessGreen else NmdDangerRed)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (report.allPassed) stringResource(R.string.p2p_test_lab_all_passed) else "${report.passedTests}/${report.totalTests} Passed",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (report.allPassed) NmdSuccessGreen else NmdDangerRed
                                )
                            }
                            IconButton(onClick = onClearReport, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear",
                                    tint = NmdTextSecondaryDark,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        report.results.forEach { result ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF141F30),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (result.isSuccess) Color(0x3310B981) else Color(0x33EF4444)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (result.isSuccess) Icons.Default.CheckCircle else Icons.Default.Close,
                                        contentDescription = null,
                                        tint = if (result.isSuccess) NmdSuccessGreen else NmdDangerRed,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = result.testName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = NmdTextPrimaryDark
                                        )
                                        Text(
                                            text = result.details,
                                            fontSize = 10.sp,
                                            color = NmdTextSecondaryDark
                                        )
                                    }
                                    Text(
                                        text = "${result.durationMs}ms",
                                        fontSize = 10.sp,
                                        color = NmdTextSecondaryDark
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
