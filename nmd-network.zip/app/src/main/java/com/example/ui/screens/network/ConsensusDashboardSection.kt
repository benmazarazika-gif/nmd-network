package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.consensus.ConsensusIntegrityReport
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ConsensusEngineState
import com.example.consensus.model.ConsensusPhase
import com.example.consensus.model.ValidatorAvailability
import com.example.consensus.model.ValidatorParticipationSummary
import com.example.consensus.model.ValidatorStatus
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun ConsensusDashboardSection(
    consensusState: ConsensusEngineState,
    integrityReport: ConsensusIntegrityReport?,
    onVerifyAndRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("consensus_status_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage10_consensus_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                if (consensusState.isDevelopmentConsensus) {
                    Surface(
                        color = NmdWarningOrange.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, NmdWarningOrange.copy(alpha = 0.45f))
                    ) {
                        Text(
                            text = stringResource(R.string.stage10_dev_consensus_badge),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdWarningOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.stage10_dev_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            // Engine state & round telemetry
            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_status),
                value = if (consensusState.isInitialized) {
                    stringResource(R.string.stage10_status_ready)
                } else {
                    stringResource(R.string.stage10_status_uninitialized)
                },
                valueColor = if (consensusState.isInitialized) NmdSuccessGreen else NmdWarningOrange
            )

            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_height_round),
                value = "H #${consensusState.currentHeight} • R ${consensusState.currentRound}",
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            val phaseColor = when (consensusState.phase) {
                ConsensusPhase.COMMITTED -> NmdSuccessGreen
                ConsensusPhase.PROPOSED,
                ConsensusPhase.PRE_VOTING,
                ConsensusPhase.PRE_COMMITTING -> NmdElectricCyan
                ConsensusPhase.TIMED_OUT -> NmdWarningOrange
                ConsensusPhase.REJECTED -> NmdDangerRed
            }
            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_phase),
                value = consensusState.phase.name,
                valueColor = phaseColor,
                isMonospace = true
            )

            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_validators),
                value = "${consensusState.activeValidatorCount} / ${consensusState.availableValidatorCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_quorum_safety),
                value = "Q=${consensusState.requiredQuorum} (F=${consensusState.toleratedByzantineFaults}) • " +
                    if (consensusState.bftSafetyMet) {
                        stringResource(R.string.stage10_bft_safety_met)
                    } else {
                        stringResource(R.string.stage10_bft_safety_insufficient)
                    },
                valueColor = if (consensusState.bftSafetyMet) NmdSuccessGreen else NmdWarningOrange
            )

            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_proposer),
                value = consensusState.currentProposerId?.let { id ->
                    if (id.length > 18) "${id.take(16)}..." else id
                } ?: "—",
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_votes_progress),
                value = "${consensusState.prevotesReceived} / ${consensusState.precommitsReceived} (need ${consensusState.requiredQuorum})",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            val shortFinalHash = if (consensusState.latestFinalizedHash == ConsensusConstants.NIL_BLOCK_HASH) {
                "genesis/0"
            } else {
                consensusState.latestFinalizedHash.take(12) + "..."
            }
            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_finalized_tip),
                value = "#${consensusState.latestFinalizedHeight} ($shortFinalHash)",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            ConsensusKeyValueRow(
                label = stringResource(R.string.stage10_field_equivocations),
                value = "${consensusState.equivocationCount}",
                valueColor = if (consensusState.equivocationCount > 0) NmdDangerRed else NmdSuccessGreen,
                isMonospace = true
            )

            if (consensusState.localMobilePaused && !consensusState.mobilePauseReason.isNullOrBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NmdWarningOrange.copy(alpha = 0.14f))
                        .border(1.dp, NmdWarningOrange.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = stringResource(R.string.stage10_mobile_paused_label),
                        tint = NmdWarningOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = consensusState.mobilePauseReason,
                        fontSize = 11.sp,
                        color = NmdWarningOrange
                    )
                }
            }

            consensusState.lastError?.let { err ->
                Text(
                    text = err,
                    fontSize = 11.sp,
                    color = NmdDangerRed
                )
            }

            integrityReport?.let { report ->
                val prefix = if (report.isHealthy) {
                    stringResource(R.string.stage10_integrity_ok_prefix)
                } else {
                    stringResource(R.string.stage10_integrity_fail_prefix)
                }
                Text(
                    text = "$prefix ${report.message}",
                    fontSize = 11.sp,
                    color = if (report.isHealthy) NmdSuccessGreen else NmdDangerRed
                )
            }

            HorizontalDivider(color = NmdDarkCardBorder)

            Text(
                text = stringResource(R.string.stage10_validator_list_title),
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
            )

            if (consensusState.validatorParticipations.isEmpty()) {
                Text(
                    text = stringResource(R.string.stage10_validator_list_empty),
                    fontSize = 11.sp,
                    color = NmdTextMutedDark
                )
            } else {
                consensusState.validatorParticipations.forEach { summary ->
                    ValidatorParticipationRow(
                        summary = summary,
                        isLocal = summary.validatorId == consensusState.localValidatorId
                    )
                }
            }

            OutlinedButton(
                onClick = onVerifyAndRefresh,
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("stage10_verify_consensus_btn"),
                border = BorderStroke(1.dp, NmdElectricCyan),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan)
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.stage10_action_verify),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun ValidatorParticipationRow(
    summary: ValidatorParticipationSummary,
    isLocal: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(NmdDarkCard.copy(alpha = 0.7f))
            .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = summary.displayName + if (isLocal) " ★" else "",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NmdTextPrimaryDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (summary.isCurrentProposer) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = NmdElectricCyan.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.stage10_tag_proposer),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdElectricCyan,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }
            Text(
                text = "${summary.validatorId.take(18)}... • PV:${summary.validPrevotesTotal} PC:${summary.validPrecommitsTotal}",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = NmdTextSecondaryDark
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        val statusColor = when {
            summary.status == ValidatorStatus.SLASHED_PENDING_REVIEW -> NmdDangerRed
            summary.status != ValidatorStatus.ACTIVE -> NmdWarningOrange
            summary.availability == ValidatorAvailability.ONLINE_AVAILABLE -> NmdSuccessGreen
            else -> NmdWarningOrange
        }
        Text(
            text = if (summary.status == ValidatorStatus.ACTIVE) {
                summary.availability.name
            } else {
                summary.status.name
            },
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = statusColor
        )
    }
}

@Composable
private fun ConsensusKeyValueRow(
    label: String,
    value: String,
    valueColor: Color,
    isMonospace: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = valueColor
        )
    }
}
