package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BuildCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.consensus.model.ConsensusConstants
import com.example.production.model.BlockProductionState
import com.example.production.model.ProductionPhase
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun BlockProductionSection(
    productionState: BlockProductionState,
    lastAttemptMessage: String?,
    onRefreshAndCheckSlot: () -> Unit,
    onAttemptEligibleProposal: () -> Unit,
    onRegisterValidator: () -> Unit = {},
    onExitValidator: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("block_production_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.BuildCircle,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage11_production_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                if (productionState.isDevelopmentMode) {
                    Surface(
                        color = NmdWarningOrange.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, NmdWarningOrange.copy(alpha = 0.45f))
                    ) {
                        Text(
                            text = stringResource(R.string.stage11_dev_badge),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdWarningOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.stage11_dev_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_engine_status),
                value = if (productionState.isInitialized) {
                    stringResource(R.string.stage11_status_ready)
                } else {
                    stringResource(R.string.stage11_status_uninitialized)
                },
                valueColor = if (productionState.isInitialized) NmdSuccessGreen else NmdWarningOrange
            )

            val phaseColor = when (productionState.phase) {
                ProductionPhase.FINALIZED,
                ProductionPhase.CONSENSUS_APPROVED -> NmdSuccessGreen
                ProductionPhase.ELIGIBLE_SCHEDULED,
                ProductionPhase.SELECTING_TRANSACTIONS,
                ProductionPhase.CONSTRUCTING_CANDIDATE,
                ProductionPhase.SIGNING_PROPOSAL,
                ProductionPhase.PROPOSED_AWAITING_CONSENSUS -> NmdElectricCyan
                ProductionPhase.PAUSED_MOBILE_RESOURCE,
                ProductionPhase.TIMEOUT_ROTATED -> NmdWarningOrange
                ProductionPhase.FAILED -> NmdDangerRed
                ProductionPhase.IDLE -> NmdTextPrimaryDark
            }
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_phase),
                value = productionState.phase.name,
                valueColor = phaseColor,
                isMonospace = true
            )

            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_height_round),
                value = "H #${productionState.currentProductionHeight} • R ${productionState.currentRound}",
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            val shortProposer = productionState.scheduledProposerId?.let { id ->
                if (id.length > 18) "${id.take(16)}..." else id
            } ?: stringResource(R.string.stage11_none_yet)
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_scheduled_proposer),
                value = shortProposer,
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            val localRoleLabel = when {
                productionState.localValidatorId == null -> stringResource(R.string.stage11_local_not_registered)
                productionState.localValidatorEligible -> stringResource(R.string.stage11_local_scheduled)
                else -> stringResource(R.string.stage11_local_standby)
            }
            val localRoleColor = when {
                productionState.localValidatorEligible -> NmdSuccessGreen
                productionState.localValidatorId == null -> NmdWarningOrange
                else -> NmdTextSecondaryDark
            }
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_local_status),
                value = localRoleLabel,
                valueColor = localRoleColor
            )

            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_mobile_guard),
                value = if (productionState.localMobilePaused) {
                    productionState.mobilePauseReason ?: "PAUSED"
                } else {
                    stringResource(R.string.stage11_mobile_guard_ok)
                },
                valueColor = if (productionState.localMobilePaused) NmdWarningOrange else NmdSuccessGreen
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            // Honest 4-Stage Pipeline Visibility: Candidate -> Proposed -> Consensus -> Finalized
            val noneLabel = stringResource(R.string.stage11_none_yet)
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_stage_candidate),
                value = productionState.candidateBlockHash?.let { "${it.take(12)}..." } ?: noneLabel,
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_candidate_txs),
                value = "${productionState.candidateTransactionCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_stage_proposed),
                value = "${productionState.proposalSubmissionStatus.name}" +
                    (productionState.proposedBlockHash?.let { " (${it.take(10)}...)" } ?: ""),
                valueColor = NmdElectricCyan,
                isMonospace = true
            )
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_stage_consensus),
                value = productionState.consensusApprovalStatus,
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            val shortFinalHash = if (productionState.latestFinalizedBlockHash == ConsensusConstants.NIL_BLOCK_HASH) {
                "genesis/0"
            } else {
                "${productionState.latestFinalizedBlockHash.take(12)}..."
            }
            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_stage_finalized),
                value = "#${productionState.latestFinalizedBlockHeight} ($shortFinalHash)",
                valueColor = NmdSuccessGreen,
                isMonospace = true
            )

            ProductionKeyValueRow(
                label = stringResource(R.string.stage11_field_counters),
                value = "${productionState.blocksProposedCount} / ${productionState.blocksFinalizedCount} / " +
                    "${productionState.missedProposalCount} / ${productionState.productionFailureCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            if (productionState.localMobilePaused && !productionState.mobilePauseReason.isNullOrBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NmdWarningOrange.copy(alpha = 0.14f))
                        .border(1.dp, NmdWarningOrange.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = stringResource(R.string.stage11_field_mobile_guard),
                        tint = NmdWarningOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = productionState.mobilePauseReason,
                        fontSize = 11.sp,
                        color = NmdWarningOrange
                    )
                }
            }

            lastAttemptMessage?.let { msg ->
                Text(
                    text = msg,
                    fontSize = 11.sp,
                    color = NmdCyanBright
                )
            }

            productionState.lastFailureReason?.let { err ->
                Text(
                    text = err,
                    fontSize = 11.sp,
                    color = NmdWarningOrange
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRefreshAndCheckSlot,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage11_refresh_schedule_btn"),
                    border = BorderStroke(1.dp, NmdElectricCyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage11_action_refresh_slot),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Button(
                    onClick = onAttemptEligibleProposal,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage11_attempt_propose_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage11_action_attempt_propose),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Stage 21: On-Chain Validator Staking / Lifecycle Registration & Exit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRegisterValidator,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_validator_register"),
                    border = BorderStroke(1.dp, NmdSuccessGreen),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdSuccessGreen)
                ) {
                    Text(
                        text = stringResource(R.string.stage19_validator_register_btn),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = onExitValidator,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_validator_exit"),
                    border = BorderStroke(1.dp, NmdWarningOrange),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdWarningOrange)
                ) {
                    Text(
                        text = stringResource(R.string.stage19_validator_exit_btn),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun ProductionKeyValueRow(
    label: String,
    value: String,
    valueColor: Color,
    isMonospace: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
