package com.example.ui.screens

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.crypto.NodeIdentityManager
import com.example.crypto.backup.IdentityBackupManager
import com.example.crypto.model.KeyStorageSecurityStatus
import com.example.data.ActivityType
import com.example.data.NmdAddressValidationResult
import com.example.data.NmdAddressValidator
import com.example.data.TransactionFilterType
import com.example.data.TransactionStatus
import com.example.data.TransactionStatusFilter
import com.example.data.WalletState
import com.example.data.WalletTransaction
import com.example.data.WalletViewMode
import com.example.transaction.NmdTransactionEngineRegistry
import com.example.transaction.TransactionEngineManager
import com.example.transaction.WalletTxCreationOutcome
import com.example.transaction.fee.FeeEstimate
import com.example.transaction.fee.TransactionFeeCalculator
import com.example.transaction.model.AccountNonceState
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.TransactionType
import com.example.transaction.storage.ConfirmedTransactionEntry
import com.example.ui.screens.wallet.TxSigningUiStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class WalletViewModel @JvmOverloads constructor(
    injectedEngine: TransactionEngineManager? = null,
    injectedIdentityManager: NodeIdentityManager? = null
) : ViewModel() {

    private val _walletState = MutableStateFlow(WalletState())
    val walletState: StateFlow<WalletState> = _walletState.asStateFlow()

    private val _viewMode = MutableStateFlow(WalletViewMode.OVERVIEW)
    val viewMode: StateFlow<WalletViewMode> = _viewMode.asStateFlow()

    // Send Form State
    private val _recipientAddress = MutableStateFlow("")
    val recipientAddress: StateFlow<String> = _recipientAddress.asStateFlow()

    private val _amount = MutableStateFlow("")
    val amount: StateFlow<String> = _amount.asStateFlow()

    private val _addressError = MutableStateFlow<Int?>(null)
    val addressError: StateFlow<Int?> = _addressError.asStateFlow()

    private val _amountError = MutableStateFlow<Int?>(null)
    val amountError: StateFlow<Int?> = _amountError.asStateFlow()

    private val _selectedPercentage = MutableStateFlow<String?>(null)
    val selectedPercentage: StateFlow<String?> = _selectedPercentage.asStateFlow()

    // History Filter & Search State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _typeFilter = MutableStateFlow(TransactionFilterType.ALL)
    val typeFilter: StateFlow<TransactionFilterType> = _typeFilter.asStateFlow()

    private val _statusFilter = MutableStateFlow(TransactionStatusFilter.ALL)
    val statusFilter: StateFlow<TransactionStatusFilter> = _statusFilter.asStateFlow()

    private val _selectedTransaction = MutableStateFlow<WalletTransaction?>(null)
    val selectedTransaction: StateFlow<WalletTransaction?> = _selectedTransaction.asStateFlow()

    // Real Signed Transaction Engine & Non-Custodial Key Backup State
    private var activeEngine: TransactionEngineManager? = injectedEngine
    private var activeIdentityManager: NodeIdentityManager? = injectedIdentityManager
    private var mempoolCollectorJob: Job? = null
    private val defaultFeeCalculator = TransactionFeeCalculator()

    private val _signedSenderAddress = MutableStateFlow<String?>(null)
    val signedSenderAddress: StateFlow<String?> = _signedSenderAddress.asStateFlow()

    private val _isSigningIdentityReady = MutableStateFlow(false)
    val isSigningIdentityReady: StateFlow<Boolean> = _isSigningIdentityReady.asStateFlow()

    private val _keyStorageSecurityStatus = MutableStateFlow<KeyStorageSecurityStatus?>(null)
    val keyStorageSecurityStatus: StateFlow<KeyStorageSecurityStatus?> = _keyStorageSecurityStatus.asStateFlow()

    private val _selectedTxType = MutableStateFlow(TransactionType.TRANSFER)
    val selectedTxType: StateFlow<TransactionType> = _selectedTxType.asStateFlow()

    private val _txMemoPayload = MutableStateFlow("")
    val txMemoPayload: StateFlow<String> = _txMemoPayload.asStateFlow()

    private val _dynamicFeeEstimate = MutableStateFlow(
        defaultFeeCalculator.estimateFeeForDraft(TransactionType.TRANSFER, 0)
    )
    val dynamicFeeEstimate: StateFlow<FeeEstimate> = _dynamicFeeEstimate.asStateFlow()

    private val _accountNonceState = MutableStateFlow<AccountNonceState?>(null)
    val accountNonceState: StateFlow<AccountNonceState?> = _accountNonceState.asStateFlow()

    private val _txSigningStatus = MutableStateFlow(TxSigningUiStatus.IDLE)
    val txSigningStatus: StateFlow<TxSigningUiStatus> = _txSigningStatus.asStateFlow()

    private val _lastSubmissionOutcome = MutableStateFlow<String?>(null)
    val lastSubmissionOutcome: StateFlow<String?> = _lastSubmissionOutcome.asStateFlow()

    private val _lastSubmittedTxId = MutableStateFlow<String?>(null)
    val lastSubmittedTxId: StateFlow<String?> = _lastSubmittedTxId.asStateFlow()

    private val _signedMempoolTransactions = MutableStateFlow<List<MempoolTransactionRecord>>(emptyList())
    val signedMempoolTransactions: StateFlow<List<MempoolTransactionRecord>> = _signedMempoolTransactions.asStateFlow()

    private val _backupRecoveryWords = MutableStateFlow<List<String>?>(null)
    val backupRecoveryWords: StateFlow<List<String>?> = _backupRecoveryWords.asStateFlow()

    private val _exportedKeystoreJson = MutableStateFlow<String?>(null)
    val exportedKeystoreJson: StateFlow<String?> = _exportedKeystoreJson.asStateFlow()

    private val _backupStatusMessage = MutableStateFlow<String?>(null)
    val backupStatusMessage: StateFlow<String?> = _backupStatusMessage.asStateFlow()

    private val _transactions = MutableStateFlow<List<WalletTransaction>>(emptyList())
    val transactions: StateFlow<List<WalletTransaction>> = _transactions.asStateFlow()

    init {
        if (injectedEngine != null && injectedIdentityManager != null) {
            bindEngine(injectedEngine, injectedIdentityManager)
        }
    }

    fun setViewMode(mode: WalletViewMode) {
        _viewMode.value = mode
        if (mode == WalletViewMode.SEND) {
            clearSendErrors()
        }
    }

    fun toggleBalanceVisibility() {
        val current = _walletState.value
        _walletState.value = current.copy(isBalanceVisible = !current.isBalanceVisible)
    }

    fun onRecipientChange(address: String) {
        _recipientAddress.value = address
        if (_addressError.value != null) {
            validateAddress(address)
        }
    }

    fun onAmountChange(newAmount: String) {
        _amount.value = newAmount
        _selectedPercentage.value = null
        if (_amountError.value != null) {
            validateAmount(newAmount)
        }
    }

    fun applyPercentage(percentage: String) {
        _selectedPercentage.value = percentage
        val available = _walletState.value.availableBalance
        val fee = _walletState.value.estimatedFee

        val calculated = when (percentage) {
            "25%" -> (available * 0.25)
            "50%" -> (available * 0.50)
            "75%" -> (available * 0.75)
            "MAX" -> maxOf(0.0, available - fee)
            else -> 0.0
        }
        _amount.value = String.format(Locale.US, "%.2f", calculated)
        clearSendErrors()
    }

    fun pasteAddress(pastedAddress: String) {
        _recipientAddress.value = pastedAddress
        validateAddress(pastedAddress)
    }

    fun validateAddress(address: String): Boolean {
        return when (val result = NmdAddressValidator.validateDemoAddress(address)) {
            is NmdAddressValidationResult.Valid -> {
                _addressError.value = null
                true
            }
            is NmdAddressValidationResult.Invalid -> {
                _addressError.value = result.errorRes
                false
            }
        }
    }

    fun validateAmount(amountStr: String): Boolean {
        val parsed = amountStr.toDoubleOrNull()
        if (parsed == null || parsed <= 0.0) {
            _amountError.value = R.string.send_error_zero_amount
            return false
        }
        val currentAvailable = _walletState.value.availableBalance
        val fee = _walletState.value.estimatedFee
        if (parsed + fee > currentAvailable) {
            _amountError.value = R.string.send_error_insufficient_balance
            return false
        }
        _amountError.value = null
        return true
    }

    private fun clearSendErrors() {
        _addressError.value = null
        _amountError.value = null
    }

    fun validateAndProceedToSendReview(): Boolean {
        val isAddrValid = validateAddress(_recipientAddress.value)
        val isAmountValid = validateAmount(_amount.value)

        if (isAddrValid && isAmountValid) {
            _viewMode.value = WalletViewMode.SEND_REVIEW
            return true
        }
        return false
    }

    /**
     * Signs and submits a real Ed25519 transfer from the standard Send Review flow
     * into the persistent Room mempool and P2P gossip gateway.
     */
    fun confirmAndSignTransfer(onFinished: ((WalletTxCreationOutcome) -> Unit)? = null) {
        val engine = activeEngine
        val idMgr = activeIdentityManager
        if (engine == null || idMgr == null) {
            val fail = WalletTxCreationOutcome.Failed("Transaction engine unavailable")
            _txSigningStatus.value = TxSigningUiStatus.FAILED
            _lastSubmissionOutcome.value = fail.reason
            onFinished?.invoke(fail)
            return
        }

        if (!validateAddress(_recipientAddress.value)) {
            val fail = WalletTxCreationOutcome.Failed("Invalid NMD recipient address")
            _txSigningStatus.value = TxSigningUiStatus.FAILED
            _lastSubmissionOutcome.value = fail.reason
            onFinished?.invoke(fail)
            return
        }

        val parsedAmountUnits = NmdAmountCodec.parseNmdToUnits(_amount.value)
        if (parsedAmountUnits == null || parsedAmountUnits <= 0L) {
            _amountError.value = R.string.send_error_zero_amount
            val fail = WalletTxCreationOutcome.Failed("Invalid transfer amount")
            _txSigningStatus.value = TxSigningUiStatus.FAILED
            _lastSubmissionOutcome.value = fail.reason
            onFinished?.invoke(fail)
            return
        }

        val estimatedFeeUnits = _dynamicFeeEstimate.value.minimumRequiredFeeUnits
        val requiredUnits = parsedAmountUnits + estimatedFeeUnits
        if (requiredUnits > _walletState.value.availableUnits) {
            _amountError.value = R.string.send_error_insufficient_balance
            val fail = WalletTxCreationOutcome.Failed("Insufficient available balance including fee")
            _txSigningStatus.value = TxSigningUiStatus.FAILED
            _lastSubmissionOutcome.value = fail.reason
            onFinished?.invoke(fail)
            return
        }

        _txSigningStatus.value = TxSigningUiStatus.SIGNING
        val recipient = _recipientAddress.value.trim()
        val memo = _txMemoPayload.value
        val txType = _selectedTxType.value

        viewModelScope.launch(Dispatchers.IO) {
            val outcome = engine.createSignAndSubmitFromWallet(
                identityManager = idMgr,
                recipientAddress = recipient,
                amountUnits = parsedAmountUnits,
                txType = txType,
                memoOrPayload = memo,
                attemptBroadcast = true
            )
            when (outcome) {
                is WalletTxCreationOutcome.Submitted -> {
                    _txSigningStatus.value = TxSigningUiStatus.SIGNED
                    _lastSubmittedTxId.value = outcome.record.transaction.txId
                    val propLabel = outcome.broadcastOutcome?.propagationStatus?.name ?: outcome.record.propagationStatus.name
                    _lastSubmissionOutcome.value = "${outcome.record.status.name} ($propLabel)"
                    _recipientAddress.value = ""
                    _amount.value = ""
                    _selectedPercentage.value = null
                    clearSendErrors()
                    _viewMode.value = WalletViewMode.OVERVIEW
                }
                is WalletTxCreationOutcome.Failed -> {
                    _txSigningStatus.value = TxSigningUiStatus.FAILED
                    _lastSubmissionOutcome.value = outcome.reason
                }
            }
            refreshSigningIdentityStateInternal()
            onFinished?.invoke(outcome)
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun onTypeFilterChange(type: TransactionFilterType) {
        _typeFilter.value = type
    }

    fun onStatusFilterChange(status: TransactionStatusFilter) {
        _statusFilter.value = status
    }

    fun selectTransactionForDetail(tx: WalletTransaction?) {
        _selectedTransaction.value = tx
    }

    fun clearSubmissionOutcome() {
        _lastSubmissionOutcome.value = null
    }

    // ==========================================
    // Real Signed Transaction Engine & Live Ledger Binding
    // ==========================================

    fun attachContext(context: Context) {
        if (activeEngine != null && activeIdentityManager != null) {
            refreshSigningIdentityState()
            return
        }
        val appContext = context.applicationContext
        val idMgr = NodeIdentityManager(appContext)
        val engine = NmdTransactionEngineRegistry.getOrCreate(appContext)
        bindEngine(engine, idMgr)
    }

    private fun bindEngine(engine: TransactionEngineManager, idMgr: NodeIdentityManager) {
        activeEngine = engine
        activeIdentityManager = idMgr
        mempoolCollectorJob?.cancel()
        mempoolCollectorJob = viewModelScope.launch(Dispatchers.IO) {
            engine.initialize()
            engine.ledgerState.initialize()
            refreshSigningIdentityStateInternal()

            combine(
                idMgr.identity,
                engine.ledgerState.accounts,
                engine.mempoolTransactions
            ) { identity, accounts, mempoolList ->
                Triple(identity, accounts, mempoolList)
            }.collect { (identity, accounts, mempoolList) ->
                _signedMempoolTransactions.value = mempoolList
                val derivedAddr = engine.deriveSenderAddress(identity) ?: ""
                _isSigningIdentityReady.value = identity != null && derivedAddr.isNotEmpty()
                _signedSenderAddress.value = derivedAddr.ifEmpty { null }
                _keyStorageSecurityStatus.value = identity?.securityStatus

                val accountState = if (derivedAddr.isNotEmpty()) {
                    accounts[derivedAddr] ?: engine.ledgerState.getAccountState(derivedAddr)
                } else {
                    null
                }
                val totalUnits = accountState?.balanceUnits ?: 0L
                val activePendingOutflow = if (derivedAddr.isNotEmpty()) {
                    mempoolList
                        .filter {
                            it.transaction.senderAddress == derivedAddr && (
                                it.status == MempoolTxStatus.PENDING ||
                                    it.status == MempoolTxStatus.VALIDATED ||
                                    it.status == MempoolTxStatus.QUEUED
                                )
                        }
                        .sumOf { it.transaction.amountUnits + it.transaction.feeUnits }
                } else {
                    0L
                }
                val reservedUnits = minOf(totalUnits, activePendingOutflow)
                val availableUnits = maxOf(0L, totalUnits - reservedUnits)
                val estFeeUnits = _dynamicFeeEstimate.value.minimumRequiredFeeUnits

                _walletState.value = _walletState.value.copy(
                    walletAddress = derivedAddr,
                    totalUnits = totalUnits,
                    availableUnits = availableUnits,
                    reservedUnits = reservedUnits,
                    totalBalance = totalUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD,
                    availableBalance = availableUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD,
                    reservedBalance = reservedUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD,
                    estimatedFee = estFeeUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD,
                    isDemo = false,
                    changePercent = ""
                )

                if (derivedAddr.isNotEmpty()) {
                    _accountNonceState.value = engine.getAccountNonceState(derivedAddr)
                    val confirmedArchive = engine.storage.getConfirmedArchiveForAddress(derivedAddr, 100)
                    _transactions.value = mapToWalletTransactions(derivedAddr, mempoolList, confirmedArchive)
                } else {
                    _accountNonceState.value = null
                    _transactions.value = emptyList()
                }
            }
        }
    }

    private fun mapToWalletTransactions(
        myAddress: String,
        mempool: List<MempoolTransactionRecord>,
        confirmed: List<ConfirmedTransactionEntry>
    ): List<WalletTransaction> {
        val seenIds = HashSet<String>()
        val result = mutableListOf<WalletTransaction>()
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

        for (entry in confirmed) {
            val tx = entry.transaction
            if (!seenIds.add(tx.txId)) continue
            val isCredit = tx.recipientAddress == myAddress && tx.senderAddress != myAddress
            val amountVal = tx.amountUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD
            val sign = if (isCredit) "+" else "-"
            result.add(
                WalletTransaction(
                    id = tx.txId,
                    txHash = tx.txId,
                    type = if (isCredit) ActivityType.RECEIVE else ActivityType.SEND,
                    titleRes = if (isCredit) R.string.activity_received_friend else R.string.activity_sent_wallet,
                    amountFormatted = "$sign${NmdAmountCodec.formatUnitsToNmd(tx.amountUnits)} NMD",
                    amountValue = amountVal,
                    isCredit = isCredit,
                    timeRes = R.string.history_status_confirmed,
                    timestampFormatted = fmt.format(Date(entry.confirmedAtMs)),
                    status = TransactionStatus.CONFIRMED,
                    feeFormatted = "${NmdAmountCodec.formatUnitsToNmd(tx.feeUnits)} NMD",
                    counterpartyAddress = if (isCredit) tx.senderAddress else tx.recipientAddress,
                    blockNumber = entry.blockHeight
                )
            )
        }

        for (rec in mempool) {
            val tx = rec.transaction
            if (tx.senderAddress != myAddress && tx.recipientAddress != myAddress) continue
            if (!seenIds.add(tx.txId)) continue
            val isCredit = tx.recipientAddress == myAddress && tx.senderAddress != myAddress
            val amountVal = tx.amountUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD
            val sign = if (isCredit) "+" else "-"
            val uiStatus = when (rec.status) {
                MempoolTxStatus.CONFIRMED -> TransactionStatus.CONFIRMED
                MempoolTxStatus.REJECTED, MempoolTxStatus.EXPIRED -> TransactionStatus.FAILED
                else -> TransactionStatus.PENDING
            }
            result.add(
                WalletTransaction(
                    id = tx.txId,
                    txHash = tx.txId,
                    type = if (isCredit) ActivityType.RECEIVE else ActivityType.SEND,
                    titleRes = if (isCredit) R.string.activity_received_friend else R.string.activity_sent_wallet,
                    amountFormatted = "$sign${NmdAmountCodec.formatUnitsToNmd(tx.amountUnits)} NMD",
                    amountValue = amountVal,
                    isCredit = isCredit,
                    timeRes = when (uiStatus) {
                        TransactionStatus.CONFIRMED -> R.string.history_status_confirmed
                        TransactionStatus.FAILED -> R.string.history_status_failed
                        else -> R.string.history_status_pending
                    },
                    timestampFormatted = fmt.format(Date(tx.timestamp)),
                    status = uiStatus,
                    feeFormatted = "${NmdAmountCodec.formatUnitsToNmd(tx.feeUnits)} NMD",
                    counterpartyAddress = if (isCredit) tx.senderAddress else tx.recipientAddress,
                    blockNumber = rec.confirmedBlockHeight ?: 0L
                )
            )
        }

        return result
    }

    fun refreshSigningIdentityState() {
        viewModelScope.launch(Dispatchers.IO) {
            refreshSigningIdentityStateInternal()
        }
    }

    private suspend fun refreshSigningIdentityStateInternal() {
        val engine = activeEngine ?: return
        val idMgr = activeIdentityManager ?: return
        val identity = idMgr.getActiveIdentity()
        val derived = engine.deriveSenderAddress(identity)
        _isSigningIdentityReady.value = identity != null && derived != null
        _signedSenderAddress.value = derived
        _keyStorageSecurityStatus.value = identity?.securityStatus
        if (derived != null) {
            _accountNonceState.value = engine.getAccountNonceState(derived)
            _walletState.value = _walletState.value.copy(walletAddress = derived, isDemo = false)
        } else {
            _accountNonceState.value = null
            _walletState.value = _walletState.value.copy(walletAddress = "", isDemo = false)
        }
    }

    fun initializeSigningIdentity() {
        val idMgr = activeIdentityManager ?: return
        viewModelScope.launch(Dispatchers.IO) {
            if (idMgr.getActiveIdentity() == null) {
                idMgr.generateNewIdentity()
            }
            refreshSigningIdentityStateInternal()
        }
    }

    fun onTxTypeSelected(type: TransactionType) {
        if (!type.isActiveInCurrentStage) return
        _selectedTxType.value = type
        recomputeDynamicFee()
    }

    fun onTxMemoChange(memo: String) {
        _txMemoPayload.value = memo
        recomputeDynamicFee()
    }

    private fun recomputeDynamicFee() {
        val engine = activeEngine
        val type = _selectedTxType.value
        val memo = _txMemoPayload.value
        val estimate = engine?.estimateFeeForDraft(type, memo)
            ?: defaultFeeCalculator.estimateFeeForDraft(type, memo.toByteArray(Charsets.UTF_8).size)
        _dynamicFeeEstimate.value = estimate
        _walletState.value = _walletState.value.copy(
            estimatedFee = estimate.minimumRequiredFeeUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD
        )
    }

    fun signAndSubmitRealTransaction() {
        val engine = activeEngine
        val idMgr = activeIdentityManager
        if (engine == null || idMgr == null) {
            _txSigningStatus.value = TxSigningUiStatus.FAILED
            _lastSubmissionOutcome.value = "Transaction engine unavailable"
            return
        }

        val isAddrValid = validateAddress(_recipientAddress.value)
        if (!isAddrValid) {
            _txSigningStatus.value = TxSigningUiStatus.FAILED
            _lastSubmissionOutcome.value = "Invalid NMD recipient address"
            return
        }

        val txType = _selectedTxType.value
        val parsedAmountUnits = if (txType == TransactionType.ACCOUNT_INITIALIZATION && _amount.value.isBlank()) {
            0L
        } else {
            NmdAmountCodec.parseNmdToUnits(_amount.value)
        }

        if (parsedAmountUnits == null || (txType == TransactionType.TRANSFER && parsedAmountUnits <= 0L)) {
            _amountError.value = R.string.send_error_zero_amount
            _txSigningStatus.value = TxSigningUiStatus.FAILED
            _lastSubmissionOutcome.value = "Invalid transfer amount"
            return
        }

        _amountError.value = null
        _txSigningStatus.value = TxSigningUiStatus.SIGNING

        viewModelScope.launch(Dispatchers.IO) {
            val outcome = engine.createSignAndSubmitFromWallet(
                identityManager = idMgr,
                recipientAddress = _recipientAddress.value.trim(),
                amountUnits = parsedAmountUnits,
                txType = txType,
                memoOrPayload = _txMemoPayload.value,
                attemptBroadcast = true
            )

            when (outcome) {
                is WalletTxCreationOutcome.Submitted -> {
                    _txSigningStatus.value = TxSigningUiStatus.SIGNED
                    _lastSubmittedTxId.value = outcome.record.transaction.txId
                    val propLabel = outcome.broadcastOutcome?.propagationStatus?.name ?: outcome.record.propagationStatus.name
                    _lastSubmissionOutcome.value = "${outcome.record.status.name} ($propLabel)"
                    refreshSigningIdentityStateInternal()
                }
                is WalletTxCreationOutcome.Failed -> {
                    _txSigningStatus.value = TxSigningUiStatus.FAILED
                    _lastSubmissionOutcome.value = outcome.reason
                }
            }
        }
    }

    // ==========================================
    // Non-Custodial Key Backup, Recovery & Identity Management
    // ==========================================

    fun loadRecoveryWords() {
        val idMgr = activeIdentityManager ?: run {
            _backupStatusMessage.value = "Identity manager not initialized"
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val res = IdentityBackupManager.exportRecoveryPhraseWords(idMgr)
            if (res.isSuccess) {
                _backupRecoveryWords.value = res.getOrNull()
                _backupStatusMessage.value = "33-word checksummed phrase unlocked in memory"
            } else {
                _backupStatusMessage.value = res.exceptionOrNull()?.message ?: "Failed to export recovery phrase"
            }
        }
    }

    fun clearExposedRecoveryWords() {
        _backupRecoveryWords.value = null
    }

    fun exportKeystoreBackup(passphrase: String) {
        val idMgr = activeIdentityManager ?: run {
            _backupStatusMessage.value = "Identity manager not initialized"
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val res = IdentityBackupManager.exportEncryptedKeystoreJson(idMgr, passphrase)
            if (res.isSuccess) {
                _exportedKeystoreJson.value = res.getOrNull()
                _backupStatusMessage.value = "Encrypted NMD_KEYSTORE_V1 JSON generated"
            } else {
                _backupStatusMessage.value = res.exceptionOrNull()?.message ?: "Keystore export failed"
            }
        }
    }

    fun clearExportedKeystore() {
        _exportedKeystoreJson.value = null
    }

    fun restoreFromKeystoreBackup(keystoreJson: String, passphrase: String) {
        val idMgr = activeIdentityManager ?: run {
            _backupStatusMessage.value = "Identity manager not initialized"
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val res = IdentityBackupManager.restoreFromEncryptedKeystoreJson(idMgr, keystoreJson, passphrase)
            if (res.isSuccess) {
                val restored = res.getOrNull()!!
                refreshSigningIdentityStateInternal()
                _backupStatusMessage.value = "Restored identity: ${restored.nmdAddress}"
            } else {
                _backupStatusMessage.value = res.exceptionOrNull()?.message ?: "Keystore restore failed"
            }
        }
    }

    fun restoreFromRecoveryPhrase(phraseText: String) {
        val idMgr = activeIdentityManager ?: run {
            _backupStatusMessage.value = "Identity manager not initialized"
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val res = IdentityBackupManager.restoreFromRecoveryPhrase(idMgr, phraseText)
            if (res.isSuccess) {
                val restored = res.getOrNull()!!
                refreshSigningIdentityStateInternal()
                _backupStatusMessage.value = "Recovered account: ${restored.nmdAddress}"
            } else {
                _backupStatusMessage.value = res.exceptionOrNull()?.message ?: "Recovery phrase invalid"
            }
        }
    }

    fun clearBackupStatusMessage() {
        _backupStatusMessage.value = null
    }

    fun deleteLocalIdentity() {
        val idMgr = activeIdentityManager ?: return
        viewModelScope.launch(Dispatchers.IO) {
            idMgr.deleteIdentity()
            _backupRecoveryWords.value = null
            _exportedKeystoreJson.value = null
            refreshSigningIdentityStateInternal()
            _backupStatusMessage.value = "Local Ed25519 private key wiped from device KeyStore"
        }
    }
}
