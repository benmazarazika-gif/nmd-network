package com.example.ui.screens.wallet

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.transaction.fee.FeeEstimate
import com.example.transaction.model.AccountNonceState
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import com.example.transaction.model.TransactionType
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

enum class TxSigningUiStatus {
    IDLE,
    SIGNING,
    SIGNED,
    FAILED
}

/**
 * Stage 9 Real Signed Transaction Composer Card placed on Wallet Send screen.
 * Strictly separates locally signed, mempool-persisted transactions (UNCONFIRMED)
 * from Stage 2 simulated demo transfers.
 */
@Composable
fun SignedTransactionComposerCard(
    signedSenderAddress: String?,
    isSigningIdentityReady: Boolean,
    selectedTxType: TransactionType,
    txMemoPayload: String,
    feeEstimate: FeeEstimate,
    nonceState: AccountNonceState?,
    signingStatus: TxSigningUiStatus,
    submissionStatusText: String?,
    lastSubmittedTxId: String?,
    onInitializeKey: () -> Unit,
    onSelectTxType: (TransactionType) -> Unit,
    onMemoChange: (String) -> Unit,
    onSignAndSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stage9_wallet_signed_tx_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdElectricCyan.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage9_tx_engine_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Surface(
                    color = NmdWarningOrange.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, NmdWarningOrange.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = stringResource(R.string.stage9_mempool_badge),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdWarningOrange,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            // Signing Key / Derived Address Row
            if (isSigningIdentityReady && signedSenderAddress != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.stage9_signed_address_label),
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark
                    )
                    Text(
                        text = "${signedSenderAddress.take(10)}...${signedSenderAddress.takeLast(6)}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        color = NmdCyanBright
                    )
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1E160A))
                        .border(1.dp, NmdWarningOrange.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.stage9_identity_not_ready),
                        fontSize = 11.sp,
                        color = NmdWarningOrange,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = onInitializeKey,
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("stage9_init_key_btn"),
                        border = BorderStroke(1.dp, NmdElectricCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = NmdElectricCyan
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.stage9_action_init_key),
                            fontSize = 11.sp,
                            color = NmdElectricCyan
                        )
                    }
                }
            }

            // Transaction Type Selector
            Text(
                text = stringResource(R.string.stage9_tx_type_label),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val activeTypes = listOf(
                    TransactionType.TRANSFER to R.string.stage9_tx_type_transfer,
                    TransactionType.ACCOUNT_INITIALIZATION to R.string.stage9_tx_type_account_init
                )
                activeTypes.forEach { (type, labelRes) ->
                    val selected = selectedTxType == type
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) NmdElectricBlue else Color(0xFF0C1628))
                            .border(
                                1.dp,
                                if (selected) NmdElectricCyan else NmdDarkCardBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { onSelectTxType(type) }
                            .testTag("stage9_type_${type.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(labelRes),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) Color.White else NmdTextSecondaryDark
                        )
                    }
                }
            }

            // Optional Memo / Payload
            OutlinedTextField(
                value = txMemoPayload,
                onValueChange = onMemoChange,
                label = {
                    Text(
                        text = stringResource(R.string.stage9_tx_memo_label),
                        fontSize = 11.sp,
                        color = NmdTextMutedDark
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("stage9_input_memo"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF0C1628),
                    unfocusedContainerColor = Color(0xFF0C1628),
                    focusedBorderColor = NmdElectricCyan,
                    unfocusedBorderColor = NmdDarkCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true
            )

            // Fee Metadata & Nonce Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${stringResource(R.string.wallet_fee_label)} (${feeEstimate.estimatedSizeBytes}B)",
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
                Text(
                    text = feeEstimate.formattedMinimumFee,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = NmdElectricCyan
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.stage9_tx_nonce_label),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
                Text(
                    text = nonceState?.let { "#${it.nextAvailableNonce} (Confirmed: ${it.confirmedNextNonce})" } ?: "#0",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = NmdTextPrimaryDark
                )
            }

            // Signing & Submission Status
            val statusText = when (signingStatus) {
                TxSigningUiStatus.IDLE -> stringResource(R.string.stage9_signing_idle)
                TxSigningUiStatus.SIGNING -> "..."
                TxSigningUiStatus.SIGNED -> stringResource(R.string.stage9_signing_signed)
                TxSigningUiStatus.FAILED -> stringResource(R.string.stage9_signing_failed)
            }
            val statusColor = when (signingStatus) {
                TxSigningUiStatus.IDLE -> NmdTextSecondaryDark
                TxSigningUiStatus.SIGNING -> NmdWarningOrange
                TxSigningUiStatus.SIGNED -> NmdSuccessGreen
                TxSigningUiStatus.FAILED -> NmdDangerRed
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.stage9_signing_status_label),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
                Text(
                    text = statusText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusColor
                )
            }

            submissionStatusText?.let { sub ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.stage9_submission_status_label),
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark
                    )
                    Text(
                        text = sub,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (signingStatus == TxSigningUiStatus.FAILED) NmdDangerRed else NmdSuccessGreen
                    )
                }
            }

            lastSubmittedTxId?.let { txId ->
                Text(
                    text = "TX ID: ${txId.take(14)}...${txId.takeLast(8)}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NmdCyanBright
                )
            }

            Button(
                onClick = onSignAndSubmit,
                enabled = isSigningIdentityReady && signingStatus != TxSigningUiStatus.SIGNING,
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("stage9_sign_submit_tx_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
            ) {
                Text(
                    text = stringResource(R.string.stage9_action_sign_submit),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Text(
                text = stringResource(R.string.stage9_honest_unconfirmed_notice),
                fontSize = 10.sp,
                color = NmdTextMutedDark,
                lineHeight = 14.sp
            )
        }
    }
}

/**
 * Displays real persisted Stage 9 signed transactions stored in the Room mempool.
 */
@Composable
fun SignedMempoolHistoryCard(
    records: List<MempoolTransactionRecord>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stage9_wallet_mempool_history_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = stringResource(R.string.stage9_signed_history_title),
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
            )
            HorizontalDivider(color = NmdDarkCardBorder)

            if (records.isEmpty()) {
                Text(
                    text = stringResource(R.string.stage9_signed_history_empty),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
            } else {
                records.take(10).forEach { rec ->
                    val statusColor = when (rec.status) {
                        MempoolTxStatus.VALIDATED -> NmdSuccessGreen
                        MempoolTxStatus.QUEUED, MempoolTxStatus.PENDING -> NmdWarningOrange
                        MempoolTxStatus.REJECTED, MempoolTxStatus.EXPIRED -> NmdDangerRed
                        MempoolTxStatus.CONFIRMED -> NmdElectricCyan
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0A1426))
                            .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${rec.transaction.txType.name} • #${rec.transaction.nonce}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                            Text(
                                text = "${rec.transaction.shortTxId} → ${rec.transaction.recipientAddress.take(10)}...",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NmdTextSecondaryDark
                            )
                            Text(
                                text = "${NmdAmountCodec.formatUnitsToNmd(rec.transaction.amountUnits)} NMD (Fee: ${NmdAmountCodec.formatUnitsToNmd(rec.transaction.feeUnits)}) • ${rec.propagationStatus.name}",
                                fontSize = 10.sp,
                                color = NmdCyanBright
                            )
                        }
                        Surface(
                            color = statusColor.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = rec.status.name,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
