package com.example.ui.navigation

enum class NavScreen {
    Home,
    Wallet,
    Network,
    Discover,
    Profile
}
