package com.example.ui.screens.wallet

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.NmdLogoBadge
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import kotlinx.coroutines.delay

@Composable
fun WalletReceiveSection(
    walletAddress: String,
    onBackToOverview: () -> Unit,
    onInitializeIdentity: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager: ClipboardManager = LocalClipboardManager.current
    var hasCopied by remember { mutableStateOf(false) }

    LaunchedEffect(hasCopied) {
        if (hasCopied) {
            delay(2500)
            hasCopied = false
        }
    }

    val shareTitle = stringResource(R.string.receive_share_title)

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        // Section Header with Back Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToOverview,
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F1A30))
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                    .testTag("receive_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Overview",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = stringResource(R.string.receive_screen_title),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )
                Text(
                    text = stringResource(R.string.status_live_network),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NmdElectricCyan,
                        fontSize = 11.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big QR Code Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        listOf(Color(0x6600D2FF), Color(0x220077FE), NmdDarkCardBorder)
                    ),
                    shape = RoundedCornerShape(22.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.wallet_my_qr),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (walletAddress.isBlank()) {
                    Text(
                        text = stringResource(R.string.stage19_no_identity_prompt),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NmdTextSecondaryDark,
                            textAlign = TextAlign.Center
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onInitializeIdentity,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                        modifier = Modifier.testTag("btn_receive_init_identity")
                    ) {
                        Text(
                            text = stringResource(R.string.stage19_receive_init_identity),
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                } else {
                    // Real QR Container dynamically encoding exact walletAddress
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color.White)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        com.example.ui.components.qr.NmdQrCodeView(
                            text = walletAddress,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Small center logo badge overlay
                        NmdLogoBadge(size = 36.dp, fontSize = 16)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = stringResource(R.string.stage19_receive_qr_real_label),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Address display pill with copy action
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0A1424))
                            .border(
                                1.dp,
                                if (hasCopied) NmdSuccessGreen else Color(0x3300D2FF),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                clipboardManager.setText(AnnotatedString(walletAddress))
                                hasCopied = true
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                            .testTag("receive_address_copy_row"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = walletAddress,
                            fontSize = 12.sp,
                            color = if (hasCopied) NmdSuccessGreen else NmdCyanBright,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Icon(
                            imageVector = if (hasCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = if (hasCopied) NmdSuccessGreen else NmdElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    if (hasCopied) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.receive_copied_toast),
                            color = NmdSuccessGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons Row (Copy & Share)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    if (walletAddress.isNotBlank()) {
                        clipboardManager.setText(AnnotatedString(walletAddress))
                        hasCopied = true
                    }
                },
                enabled = walletAddress.isNotBlank(),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("btn_receive_copy"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.wallet_copy_address),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }

            OutlinedButton(
                onClick = {
                    if (walletAddress.isNotBlank()) {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, walletAddress)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, shareTitle))
                    }
                },
                enabled = walletAddress.isNotBlank(),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("btn_receive_share"),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x5500D2FF))
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.receive_share_action),
                        fontWeight = FontWeight.Bold,
                        color = NmdElectricCyan,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Warning Callout
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x1FFF9F43))
                .border(1.dp, Color(0x33FF9F43), RoundedCornerShape(14.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚠ " + stringResource(R.string.receive_testnet_warning),
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color(0xFFFFC078),
                    lineHeight = 16.sp
                )
            )
        }
    }
}
