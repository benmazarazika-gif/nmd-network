package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.sync.model.SyncProtocolConstants
import com.example.sync.model.SyncStatusState
import com.example.sync.model.SyncUiState
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SyncDashboardSection(
    syncState: SyncUiState,
    onSyncNow: () -> Unit,
    onTogglePauseResume: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("blockchain_sync_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudSync,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage12_sync_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                if (syncState.isDevelopmentMode) {
                    Surface(
                        color = NmdWarningOrange.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, NmdWarningOrange.copy(alpha = 0.45f))
                    ) {
                        Text(
                            text = stringResource(R.string.stage12_dev_badge),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdWarningOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.stage12_dev_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            val (statusLabelRes, statusColor) = when (syncState.syncStatus) {
                SyncStatusState.IDLE -> R.string.stage12_status_idle to NmdTextPrimaryDark
                SyncStatusState.DISCOVERING_PEERS -> R.string.stage12_status_discovering to NmdElectricCyan
                SyncStatusState.SYNCHRONIZING -> R.string.stage12_status_synchronizing to NmdElectricCyan
                SyncStatusState.VERIFYING_BLOCKS -> R.string.stage12_status_verifying to NmdCyanBright
                SyncStatusState.PAUSED -> R.string.stage12_status_paused to NmdWarningOrange
                SyncStatusState.SYNCED -> R.string.stage12_status_synced to NmdSuccessGreen
                SyncStatusState.FAILED -> R.string.stage12_status_failed to NmdDangerRed
                SyncStatusState.CONFLICT_DETECTED -> R.string.stage12_status_conflict to NmdDangerRed
            }

            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_sync_status),
                value = stringResource(statusLabelRes),
                valueColor = statusColor,
                isMonospace = true
            )

            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_local_height),
                value = "#${syncState.localHeight}",
                valueColor = NmdSuccessGreen,
                isMonospace = true
            )

            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_reported_peer_height),
                value = "#${syncState.highestReportedPeerHeight}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_verified_peer_height),
                value = "#${syncState.highestVerifiedPeerHeight}",
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            val shortFinalHash = if (syncState.latestFinalizedBlockHash == SyncProtocolConstants.ZERO_HASH ||
                syncState.latestFinalizedBlockHash.isBlank()
            ) {
                "genesis/0"
            } else {
                "${syncState.latestFinalizedBlockHash.take(12)}..."
            }
            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_finalized_block),
                value = "#${syncState.latestFinalizedHeight} ($shortFinalHash)",
                valueColor = NmdSuccessGreen,
                isMonospace = true
            )

            val noneLabel = stringResource(R.string.stage11_none_yet)
            val peerDisplay = syncState.currentSyncPeerId?.let { id ->
                if (id.length > 18) "${id.take(16)}..." else id
            } ?: noneLabel
            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_current_peer),
                value = peerDisplay,
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_blocks_counters),
                value = "${syncState.downloadedBlocksCount} / ${syncState.verifiedBlocksCount} / ${syncState.remainingBlocksCount}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                SyncKeyValueRow(
                    label = stringResource(R.string.stage12_field_progress),
                    value = "${syncState.progressPercent}%",
                    valueColor = statusColor,
                    isMonospace = true
                )
                LinearProgressIndicator(
                    progress = { syncState.progressFraction.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .testTag("stage12_sync_progress_bar"),
                    color = statusColor,
                    trackColor = Color(0x3300D2FF)
                )
            }

            val lastSyncFormatted = syncState.lastSyncTimestampMs?.let { ts ->
                SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(ts))
            } ?: stringResource(R.string.stage12_never_synced)
            SyncKeyValueRow(
                label = stringResource(R.string.stage12_field_last_sync),
                value = lastSyncFormatted,
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            if (syncState.conflictRecords.isNotEmpty()) {
                val conflict = syncState.conflictRecords.first()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NmdDangerRed.copy(alpha = 0.14f))
                        .border(1.dp, NmdDangerRed.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("stage12_conflict_banner"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = stringResource(R.string.stage12_conflict_banner_title),
                        tint = NmdDangerRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.stage12_conflict_banner_title),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdDangerRed
                        )
                        Text(
                            text = "H #${conflict.conflictHeight}: ${conflict.reason}",
                            fontSize = 10.sp,
                            color = NmdTextPrimaryDark
                        )
                    }
                }
            } else if (!syncState.errorMessage.isNullOrBlank()) {
                Text(
                    text = syncState.errorMessage,
                    fontSize = 11.sp,
                    color = if (syncState.syncStatus == SyncStatusState.PAUSED) NmdWarningOrange else NmdDangerRed
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onTogglePauseResume,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage12_pause_resume_btn"),
                    border = BorderStroke(1.dp, NmdElectricCyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan)
                ) {
                    Icon(
                        imageVector = if (syncState.isUserPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(
                            if (syncState.isUserPaused) R.string.stage12_action_resume else R.string.stage12_action_pause
                        ),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Button(
                    onClick = onSyncNow,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage12_sync_now_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.stage12_action_sync_now),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun SyncKeyValueRow(
    label: String,
    value: String,
    valueColor: Color,
    isMonospace: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
