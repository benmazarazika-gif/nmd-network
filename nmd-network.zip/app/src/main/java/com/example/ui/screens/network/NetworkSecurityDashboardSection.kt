package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.p2p.security.model.NetworkSecurityUiState
import com.example.p2p.security.model.PeerTrustState
import com.example.p2p.security.model.TransportSecurityStatus
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NetworkSecurityDashboardSection(
    securityState: NetworkSecurityUiState,
    onRevokePeer: (String) -> Unit,
    onUnrevokePeer: (String) -> Unit,
    onRotateSessions: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("network_security_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = stringResource(R.string.stage13_security_title),
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage13_security_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Surface(
                    color = NmdSuccessGreen.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, NmdSuccessGreen.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = stringResource(R.string.stage13_badge_encrypted),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdSuccessGreen,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = stringResource(R.string.stage13_security_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark,
                lineHeight = 15.sp
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            val (statusRes, statusColor) = statusResAndColor(securityState.status)
            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_status),
                value = stringResource(statusRes),
                valueColor = statusColor,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_protocol),
                value = securityState.encryptionProtocolId,
                valueColor = NmdCyanBright,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_chain_version),
                value = "${securityState.chainId} • v${securityState.protocolVersion}",
                valueColor = NmdTextPrimaryDark,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_auth_peers),
                value = "${securityState.authenticatedPeersCount}",
                valueColor = NmdSuccessGreen,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_encrypted_sessions),
                value = "${securityState.encryptedSessionsCount}",
                valueColor = NmdElectricCyan,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_pending_handshakes),
                value = "${securityState.pendingHandshakesCount}",
                valueColor = if (securityState.pendingHandshakesCount > 0) NmdWarningOrange else NmdTextPrimaryDark,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_failed_handshakes),
                value = "${securityState.failedHandshakesCount}",
                valueColor = if (securityState.failedHandshakesCount > 0) NmdDangerRed else NmdTextPrimaryDark,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_rejected_replays),
                value = "${securityState.rejectedReplaysCount}",
                valueColor = if (securityState.rejectedReplaysCount > 0) NmdDangerRed else NmdTextPrimaryDark,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_rate_limited),
                value = "${securityState.rateLimitedPeersCount}",
                valueColor = if (securityState.rateLimitedPeersCount > 0) NmdWarningOrange else NmdTextPrimaryDark,
                isMonospace = true
            )

            SecurityKeyValueRow(
                label = stringResource(R.string.stage13_field_revoked_peers),
                value = "${securityState.revokedPeersCount}",
                valueColor = if (securityState.revokedPeersCount > 0) NmdDangerRed else NmdTextPrimaryDark,
                isMonospace = true
            )

            // Last Security Event Banner
            val lastEvent = securityState.lastSecurityEvent
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        if (lastEvent?.isFailure == true) NmdDangerRed.copy(alpha = 0.12f)
                        else Color(0xFF0A1426)
                    )
                    .border(
                        1.dp,
                        if (lastEvent?.isFailure == true) NmdDangerRed.copy(alpha = 0.45f) else NmdDarkCardBorder,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .testTag("stage13_last_security_event")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (lastEvent?.isFailure == true) Icons.Default.Warning else Icons.Default.Lock,
                        contentDescription = stringResource(R.string.stage13_field_last_event),
                        tint = if (lastEvent?.isFailure == true) NmdDangerRed else NmdElectricCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.stage13_field_last_event),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (lastEvent?.isFailure == true) NmdDangerRed else NmdCyanBright
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                if (lastEvent == null) {
                    Text(
                        text = stringResource(R.string.stage13_no_events),
                        fontSize = 10.sp,
                        color = NmdTextSecondaryDark
                    )
                } else {
                    val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(lastEvent.timestampMs))
                    Text(
                        text = "[${lastEvent.type.name} • $timeFmt] ${lastEvent.summary}",
                        fontSize = 10.sp,
                        color = NmdTextPrimaryDark,
                        lineHeight = 14.sp
                    )
                }
            }

            // Peer Authentication & Encryption States
            Text(
                text = stringResource(R.string.stage13_peer_statuses_title),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = NmdTextSecondaryDark
            )

            if (securityState.peerStatuses.isEmpty()) {
                Text(
                    text = stringResource(R.string.stage13_no_active_sessions),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
            } else {
                securityState.peerStatuses.forEach { peer ->
                    val (peerStatusRes, peerStatusColor) = statusResAndColor(peer.status)
                    val (trustRes, trustColor) = trustResAndColor(peer.trustState)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0A1426))
                            .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = peerStatusColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (peer.peerId.length > 18) "${peer.peerId.take(12)}...${peer.peerId.takeLast(4)}" else peer.peerId,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = NmdTextPrimaryDark,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = "${peer.endpointFormatted} • ${stringResource(peerStatusRes)} • ${stringResource(trustRes)} • Tx:${peer.framesSent}/Rx:${peer.framesReceived}",
                                fontSize = 10.sp,
                                color = trustColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = { onRevokePeer(peer.peerId) },
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("stage13_revoke_peer_${peer.peerId.take(8)}"),
                            border = BorderStroke(1.dp, NmdDangerRed.copy(alpha = 0.7f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdDangerRed),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Block,
                                contentDescription = stringResource(R.string.stage13_action_revoke),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.stage13_action_revoke),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            if (securityState.revokedPeerIds.isNotEmpty()) {
                Text(
                    text = stringResource(R.string.stage13_revoked_list_title),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NmdDangerRed
                )
                securityState.revokedPeerIds.forEach { revokedId ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(NmdDangerRed.copy(alpha = 0.08f))
                            .border(1.dp, NmdDangerRed.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (revokedId.length > 20) "${revokedId.take(14)}...${revokedId.takeLast(4)}" else revokedId,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NmdTextPrimaryDark,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = { onUnrevokePeer(revokedId) },
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("stage13_unrevoke_peer_${revokedId.take(8)}"),
                            border = BorderStroke(1.dp, NmdElectricCyan),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.stage13_action_unrevoke),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Button(
                onClick = onRotateSessions,
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("stage13_rotate_sessions_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NmdElectricCyan.copy(alpha = 0.16f),
                    contentColor = NmdElectricCyan
                ),
                border = BorderStroke(1.dp, NmdElectricCyan.copy(alpha = 0.55f))
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.stage13_action_rotate_sessions),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun statusResAndColor(status: TransportSecurityStatus): Pair<Int, Color> {
    return when (status) {
        TransportSecurityStatus.SECURE -> R.string.stage13_status_secure to NmdSuccessGreen
        TransportSecurityStatus.CONNECTING -> R.string.stage13_status_connecting to NmdWarningOrange
        TransportSecurityStatus.AUTHENTICATING -> R.string.stage13_status_authenticating to NmdElectricCyan
        TransportSecurityStatus.ENCRYPTED -> R.string.stage13_status_encrypted to NmdSuccessGreen
        TransportSecurityStatus.AUTHENTICATION_FAILED -> R.string.stage13_status_auth_failed to NmdDangerRed
        TransportSecurityStatus.DISCONNECTED -> R.string.stage13_status_disconnected to NmdTextSecondaryDark
        TransportSecurityStatus.PEER_REVOKED -> R.string.stage13_status_peer_revoked to NmdDangerRed
    }
}

private fun trustResAndColor(trust: PeerTrustState): Pair<Int, Color> {
    return when (trust) {
        PeerTrustState.TRUSTED_AUTHENTICATED -> R.string.stage13_trust_trusted to NmdSuccessGreen
        PeerTrustState.AUTH_FAILED -> R.string.stage13_trust_failed to NmdDangerRed
        PeerTrustState.REVOKED -> R.string.stage13_trust_revoked to NmdDangerRed
        PeerTrustState.IDENTITY_MISMATCH -> R.string.stage13_trust_mismatch to NmdDangerRed
        PeerTrustState.UNVERIFIED -> R.string.stage13_trust_unverified to NmdWarningOrange
    }
}

@Composable
private fun SecurityKeyValueRow(
    label: String,
    value: String,
    valueColor: Color,
    isMonospace: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
