package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.NodeRole
import com.example.data.PeerConnectionState
import com.example.data.PeerInfo
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun PeerManagementSection(
    peers: List<PeerInfo>,
    searchQuery: String,
    selectedRoleFilter: NodeRole?,
    onSearchChange: (String) -> Unit,
    onRoleFilterChange: (NodeRole?) -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredPeers = peers.filter { peer ->
        val matchesSearch = if (searchQuery.isBlank()) true else {
            peer.name.contains(searchQuery, ignoreCase = true) ||
            peer.id.contains(searchQuery, ignoreCase = true) ||
            peer.location.contains(searchQuery, ignoreCase = true)
        }
        val matchesRole = selectedRoleFilter == null || peer.role == selectedRoleFilter
        matchesSearch && matchesRole
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (peers.any { it.isDemo }) {
            // Disclaimer Banner only if explicit demo fixture peers exist
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x1F00D2FF))
                    .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.peers_demo_disclaimer),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark,
                    lineHeight = 15.sp
                )
            }
        }

        // Search Input Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = {
                Text(
                    stringResource(R.string.peers_search_hint),
                    color = NmdTextMutedDark,
                    fontSize = 12.sp
                )
            },
            trailingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_peer_search"),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF0F1A30),
                unfocusedContainerColor = Color(0xFF0F1A30),
                focusedBorderColor = NmdElectricCyan,
                unfocusedBorderColor = NmdDarkCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            singleLine = true
        )

        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // "All Roles" chip
            val isAllSelected = selectedRoleFilter == null
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isAllSelected) NmdElectricBlue else Color(0xFF10192D))
                    .border(1.dp, if (isAllSelected) NmdElectricCyan else NmdDarkCardBorder, RoundedCornerShape(10.dp))
                    .clickable { onRoleFilterChange(null) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("filter_peer_all"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.peers_all_roles),
                    fontSize = 11.sp,
                    fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isAllSelected) Color.White else NmdTextSecondaryDark
                )
            }

            NodeRole.entries.forEach { role ->
                val isSelected = selectedRoleFilter == role
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NmdElectricBlue else Color(0xFF10192D))
                        .border(1.dp, if (isSelected) NmdElectricCyan else NmdDarkCardBorder, RoundedCornerShape(10.dp))
                        .clickable { onRoleFilterChange(role) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("filter_peer_${role.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(role.titleRes),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else NmdTextSecondaryDark
                    )
                }
            }
        }

        // Peers List
        if (filteredPeers.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 20.dp)
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.peers_empty_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.stage19_peers_empty),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    filteredPeers.forEachIndexed { index, peer ->
                        PeerRowItem(peer = peer)
                        if (index < filteredPeers.size - 1) {
                            Spacer(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .padding(vertical = 4.dp)
                                    .background(Color(0x1A1E2D4E))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PeerRowItem(peer: PeerInfo) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("peer_row_${peer.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val stateDotColor = when (peer.connectionState) {
            PeerConnectionState.CONNECTED -> NmdSuccessGreen
            PeerConnectionState.SYNCING -> NmdElectricCyan
            PeerConnectionState.IDLE -> NmdWarningOrange
        }

        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(stateDotColor)
        )

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = peer.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )
                if (peer.isDemo) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0x1F00D2FF)
                    ) {
                        Text(
                            text = "DEMO",
                            color = NmdCyanBright,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = NmdTextSecondaryDark,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = peer.location,
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "• ${peer.lastSeenText}",
                    fontSize = 10.sp,
                    color = NmdTextMutedDark
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFF0F1E38)
            ) {
                Text(
                    text = stringResource(peer.role.titleRes),
                    color = NmdCyanBright,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = null,
                    tint = NmdSuccessGreen,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = "${peer.latencyMs} ms",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = NmdSuccessGreen
                )
            }
        }
    }
}
