package com.example.ui.screens.wallet

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.WalletState
import com.example.transaction.fee.FeeEstimate
import com.example.transaction.fee.TransactionFeeCalculator
import com.example.transaction.model.AccountNonceState
import com.example.transaction.model.TransactionType
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import java.util.Locale

@Composable
fun WalletSendSection(
    walletState: WalletState,
    recipientAddress: String,
    amount: String,
    addressError: Int?,
    amountError: Int?,
    selectedPercentage: String?,
    onRecipientChange: (String) -> Unit,
    onAmountChange: (String) -> Unit,
    onPercentageClick: (String) -> Unit,
    onPasteClick: (String) -> Unit,
    onReviewClick: () -> Unit,
    onBackToOverview: () -> Unit,
    modifier: Modifier = Modifier,
    // Stage 9 Signed Transaction Engine Parameters
    signedSenderAddress: String? = null,
    isSigningIdentityReady: Boolean = false,
    selectedTxType: TransactionType = TransactionType.TRANSFER,
    txMemoPayload: String = "",
    dynamicFeeEstimate: FeeEstimate = TransactionFeeCalculator().estimateFeeForDraft(TransactionType.TRANSFER, 0),
    accountNonceState: AccountNonceState? = null,
    signingStatus: TxSigningUiStatus = TxSigningUiStatus.IDLE,
    submissionStatusText: String? = null,
    lastSubmittedTxId: String? = null,
    onInitializeSigningKey: () -> Unit = {},
    onSelectTxType: (TransactionType) -> Unit = {},
    onTxMemoChange: (String) -> Unit = {},
    onSignAndSubmitRealTransaction: () -> Unit = {}
) {
    val clipboardManager: ClipboardManager = LocalClipboardManager.current
    val parsedAmount = amount.toDoubleOrNull() ?: 0.0
    val totalDeduction = if (parsedAmount > 0) parsedAmount + walletState.estimatedFee else 0.0

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        // Section Header with Back Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToOverview,
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F1A30))
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                    .testTag("send_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Overview",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = stringResource(R.string.send_screen_title),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )
                Text(
                    text = stringResource(R.string.status_live_network),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NmdElectricCyan,
                        fontSize = 11.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Recipient Address Input Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.wallet_recipient_title),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = NmdTextPrimaryDark
                        )
                    )

                    // Paste From Clipboard Button
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF13233F),
                        modifier = Modifier
                            .border(0.5.dp, Color(0x3300D2FF), RoundedCornerShape(8.dp))
                            .clickable {
                                val text = clipboardManager.getText()?.text
                                if (!text.isNullOrBlank()) {
                                    onPasteClick(text.trim())
                                }
                            }
                            .testTag("btn_paste_clipboard")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = null,
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.send_paste_action),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = NmdElectricCyan
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = recipientAddress,
                    onValueChange = onRecipientChange,
                    placeholder = {
                        Text(
                            stringResource(R.string.wallet_recipient_hint),
                            color = NmdTextMutedDark,
                            fontSize = 12.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_send_recipient"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0C1628),
                        unfocusedContainerColor = Color(0xFF0C1628),
                        focusedBorderColor = if (addressError != null) NmdDangerRed else NmdElectricCyan,
                        unfocusedBorderColor = if (addressError != null) NmdDangerRed else NmdDarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )

                if (addressError != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(addressError),
                        color = NmdDangerRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Amount Input Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.wallet_amount_title),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = NmdTextPrimaryDark
                        )
                    )

                    Text(
                        text = "${stringResource(R.string.wallet_available_balance)}: ${walletState.availableBalanceFormatted} NMD",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdCyanBright,
                            fontSize = 11.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Amount text field with currency token pill
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0C1628))
                        .border(
                            1.dp,
                            if (amountError != null) NmdDangerRed else NmdDarkCardBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF13274A),
                        modifier = Modifier.border(0.5.dp, Color(0x4400D2FF), RoundedCornerShape(8.dp))
                    ) {
                        Text(
                            text = "NMD",
                            color = NmdElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    OutlinedTextField(
                        value = amount,
                        onValueChange = onAmountChange,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_send_amount"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        textStyle = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.End
                        ),
                        placeholder = {
                            Text(
                                text = "0.00",
                                color = NmdTextMutedDark,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )
                        },
                        singleLine = true
                    )
                }

                if (amountError != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(amountError),
                        color = NmdDangerRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Percentage Quick Chips (25%, 50%, 75%, MAX)
                val percentageList = listOf(
                    "25%",
                    "50%",
                    "75%",
                    "MAX"
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    percentageList.forEach { pct ->
                        val isSelected = selectedPercentage == pct
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NmdElectricBlue else Color(0xFF0F1A30))
                                .border(
                                    1.dp,
                                    if (isSelected) NmdElectricCyan else NmdDarkCardBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { onPercentageClick(pct) }
                                .padding(vertical = 8.dp)
                                .testTag("chip_send_$pct"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = pct,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else NmdTextSecondaryDark
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Fee & Total Deduction Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D172A)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = stringResource(R.string.wallet_fee_label),
                            style = MaterialTheme.typography.bodySmall.copy(color = NmdTextSecondaryDark)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    Text(
                        text = walletState.estimatedFeeFormatted,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.send_total_deduction),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                    Text(
                        text = String.format(Locale.US, "%.2f NMD", totalDeduction),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdElectricCyan
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Review Transfer Primary Action Button
        Button(
            onClick = onReviewClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("btn_proceed_to_review"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = NmdElectricBlue
            )
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(R.string.send_review_title),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(17.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Non-custodial signing notice
        Text(
            text = "ⓘ " + stringResource(R.string.stage19_send_sign_notice),
            style = MaterialTheme.typography.bodySmall.copy(
                color = NmdTextMutedDark,
                lineHeight = 16.sp
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Stage 9: Cryptographic Ed25519 Signed Transaction Engine
        SignedTransactionComposerCard(
            signedSenderAddress = signedSenderAddress,
            isSigningIdentityReady = isSigningIdentityReady,
            selectedTxType = selectedTxType,
            txMemoPayload = txMemoPayload,
            feeEstimate = dynamicFeeEstimate,
            nonceState = accountNonceState,
            signingStatus = signingStatus,
            submissionStatusText = submissionStatusText,
            lastSubmittedTxId = lastSubmittedTxId,
            onInitializeKey = onInitializeSigningKey,
            onSelectTxType = onSelectTxType,
            onMemoChange = onTxMemoChange,
            onSignAndSubmit = onSignAndSubmitRealTransaction
        )
    }
}
