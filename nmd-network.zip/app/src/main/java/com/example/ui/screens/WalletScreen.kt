package com.example.ui.screens

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.WalletViewMode
import com.example.transaction.WalletTxCreationOutcome
import com.example.ui.screens.wallet.WalletHistorySection
import com.example.ui.screens.wallet.WalletOverviewSection
import com.example.ui.screens.wallet.WalletReceiveSection
import com.example.ui.screens.wallet.WalletSecuritySection
import com.example.ui.screens.wallet.WalletSendReviewDialog
import com.example.ui.screens.wallet.WalletSendSection
import com.example.ui.theme.NmdDarkBackground
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdTextPrimaryDark
import kotlinx.coroutines.launch

@Composable
fun WalletScreen(
    initialMode: WalletViewMode = WalletViewMode.OVERVIEW,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: WalletViewModel = viewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val walletState by viewModel.walletState.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val viewMode by viewModel.viewMode.collectAsState()

    val recipientAddress by viewModel.recipientAddress.collectAsState()
    val amount by viewModel.amount.collectAsState()
    val addressError by viewModel.addressError.collectAsState()
    val amountError by viewModel.amountError.collectAsState()
    val selectedPercentage by viewModel.selectedPercentage.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val typeFilter by viewModel.typeFilter.collectAsState()
    val statusFilter by viewModel.statusFilter.collectAsState()
    val selectedTransaction by viewModel.selectedTransaction.collectAsState()

    // Stage 9 Signed Transaction Engine State
    val signedSenderAddress by viewModel.signedSenderAddress.collectAsState()
    val isSigningIdentityReady by viewModel.isSigningIdentityReady.collectAsState()
    val selectedTxType by viewModel.selectedTxType.collectAsState()
    val txMemoPayload by viewModel.txMemoPayload.collectAsState()
    val dynamicFeeEstimate by viewModel.dynamicFeeEstimate.collectAsState()
    val accountNonceState by viewModel.accountNonceState.collectAsState()
    val txSigningStatus by viewModel.txSigningStatus.collectAsState()
    val lastSubmissionOutcome by viewModel.lastSubmissionOutcome.collectAsState()
    val lastSubmittedTxId by viewModel.lastSubmittedTxId.collectAsState()
    val signedMempoolTransactions by viewModel.signedMempoolTransactions.collectAsState()
    val keyStorageSecurityStatus by viewModel.keyStorageSecurityStatus.collectAsState()
    val backupRecoveryWords by viewModel.backupRecoveryWords.collectAsState()
    val exportedKeystoreJson by viewModel.exportedKeystoreJson.collectAsState()
    val backupStatusMessage by viewModel.backupStatusMessage.collectAsState()

    // Attach Stage 9 local transaction engine & synchronize initial mode
    LaunchedEffect(context) {
        viewModel.attachContext(context)
    }
    LaunchedEffect(initialMode) {
        viewModel.setViewMode(initialMode)
    }

    // Handle back button hierarchically
    BackHandler {
        if (viewMode != WalletViewMode.OVERVIEW) {
            viewModel.setViewMode(WalletViewMode.OVERVIEW)
        } else {
            onBack()
        }
    }

    // Review transfer modal (triggers real Ed25519 signing + mempool/P2P submission)
    if (viewMode == WalletViewMode.SEND_REVIEW) {
        WalletSendReviewDialog(
            recipientAddress = recipientAddress,
            amountStr = amount,
            feeStr = walletState.estimatedFeeFormatted,
            onConfirm = {
                viewModel.confirmAndSignTransfer { outcome ->
                    val message = when (outcome) {
                        is WalletTxCreationOutcome.Submitted ->
                            context.getString(
                                R.string.stage19_send_submitted_toast,
                                outcome.record.transaction.shortTxId
                            )
                        is WalletTxCreationOutcome.Failed ->
                            context.getString(
                                R.string.stage19_send_failed_toast,
                                outcome.reason
                            )
                    }
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                    }
                }
            },
            onDismiss = {
                viewModel.setViewMode(WalletViewMode.SEND)
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NmdDarkBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("wallet_screen_content")
        ) {
            // Main Screen Title Top Bar (Visible in Overview mode)
            if (viewMode == WalletViewMode.OVERVIEW) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NmdDarkCard)
                            .testTag("wallet_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = stringResource(R.string.wallet_title),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NmdDarkCard),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Crossfade transitions between Overview, Send, Receive, History, Security
            Crossfade(
                targetState = viewMode,
                animationSpec = tween(durationMillis = 200),
                label = "wallet_subview_crossfade"
            ) { mode ->
                when (mode) {
                    WalletViewMode.OVERVIEW -> {
                        WalletOverviewSection(
                            walletState = walletState,
                            recentTransactions = transactions,
                            onToggleVisibility = { viewModel.toggleBalanceVisibility() },
                            onNavigateToSend = { viewModel.setViewMode(WalletViewMode.SEND) },
                            onNavigateToReceive = { viewModel.setViewMode(WalletViewMode.RECEIVE) },
                            onNavigateToHistory = { viewModel.setViewMode(WalletViewMode.HISTORY) },
                            onNavigateToSecurity = { viewModel.setViewMode(WalletViewMode.SECURITY) },
                            onTransactionClick = { tx -> viewModel.selectTransactionForDetail(tx) },
                            onAddressCopied = {
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.receive_copied_toast),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )
                    }

                    WalletViewMode.SEND, WalletViewMode.SEND_REVIEW -> {
                        WalletSendSection(
                            walletState = walletState,
                            recipientAddress = recipientAddress,
                            amount = amount,
                            addressError = addressError,
                            amountError = amountError,
                            selectedPercentage = selectedPercentage,
                            onRecipientChange = { viewModel.onRecipientChange(it) },
                            onAmountChange = { viewModel.onAmountChange(it) },
                            onPercentageClick = { viewModel.applyPercentage(it) },
                            onPasteClick = { viewModel.pasteAddress(it) },
                            onReviewClick = { viewModel.validateAndProceedToSendReview() },
                            onBackToOverview = { viewModel.setViewMode(WalletViewMode.OVERVIEW) },
                            signedSenderAddress = signedSenderAddress,
                            isSigningIdentityReady = isSigningIdentityReady,
                            selectedTxType = selectedTxType,
                            txMemoPayload = txMemoPayload,
                            dynamicFeeEstimate = dynamicFeeEstimate,
                            accountNonceState = accountNonceState,
                            signingStatus = txSigningStatus,
                            submissionStatusText = lastSubmissionOutcome,
                            lastSubmittedTxId = lastSubmittedTxId,
                            onInitializeSigningKey = viewModel::initializeSigningIdentity,
                            onSelectTxType = viewModel::onTxTypeSelected,
                            onTxMemoChange = viewModel::onTxMemoChange,
                            onSignAndSubmitRealTransaction = viewModel::signAndSubmitRealTransaction
                        )
                    }

                    WalletViewMode.RECEIVE -> {
                        WalletReceiveSection(
                            walletAddress = walletState.walletAddress,
                            onBackToOverview = { viewModel.setViewMode(WalletViewMode.OVERVIEW) },
                            onInitializeIdentity = viewModel::initializeSigningIdentity
                        )
                    }

                    WalletViewMode.HISTORY -> {
                        WalletHistorySection(
                            transactions = transactions,
                            searchQuery = searchQuery,
                            typeFilter = typeFilter,
                            statusFilter = statusFilter,
                            selectedTransaction = selectedTransaction,
                            onSearchChange = { viewModel.onSearchQueryChange(it) },
                            onTypeFilterChange = { viewModel.onTypeFilterChange(it) },
                            onStatusFilterChange = { viewModel.onStatusFilterChange(it) },
                            onSelectTransaction = { viewModel.selectTransactionForDetail(it) },
                            onBackToOverview = { viewModel.setViewMode(WalletViewMode.OVERVIEW) },
                            signedMempoolRecords = signedMempoolTransactions
                        )
                    }

                    WalletViewMode.SECURITY -> {
                        WalletSecuritySection(
                            onBackToOverview = { viewModel.setViewMode(WalletViewMode.OVERVIEW) },
                            keyStorageStatus = keyStorageSecurityStatus,
                            isIdentityReady = isSigningIdentityReady,
                            signedSenderAddress = signedSenderAddress,
                            backupRecoveryWords = backupRecoveryWords,
                            exportedKeystoreJson = exportedKeystoreJson,
                            backupStatusMessage = backupStatusMessage,
                            onInitializeIdentity = viewModel::initializeSigningIdentity,
                            onViewRecoveryWords = viewModel::loadRecoveryWords,
                            onClearRecoveryWords = viewModel::clearExposedRecoveryWords,
                            onExportKeystore = viewModel::exportKeystoreBackup,
                            onClearExportedKeystore = viewModel::clearExportedKeystore,
                            onRestoreFromKeystore = viewModel::restoreFromKeystoreBackup,
                            onRestoreFromPhrase = viewModel::restoreFromRecoveryPhrase,
                            onClearStatusMessage = viewModel::clearBackupStatusMessage
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
