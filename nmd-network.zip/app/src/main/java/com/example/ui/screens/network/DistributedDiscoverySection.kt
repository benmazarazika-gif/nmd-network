package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.p2p.discovery.DiscoveryMethod
import com.example.p2p.discovery.DiscoveryStatusState
import com.example.p2p.discovery.bootstrap.BootstrapPeer
import com.example.p2p.discovery.bootstrap.BootstrapStatus
import com.example.p2p.discovery.registry.PeerFilterOption
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.discovery.topology.TopologyMetrics
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DistributedDiscoverySection(
    topologyMetrics: TopologyMetrics,
    discoveryStatus: DiscoveryStatusState,
    discoveryMethod: DiscoveryMethod,
    lastSuccessfulDiscoveryMs: Long?,
    registeredPeers: List<PeerRegistryRecord>,
    bootstrapPeers: List<BootstrapPeer>,
    selectedFilter: PeerFilterOption,
    onSelectFilter: (PeerFilterOption) -> Unit,
    onRefreshDiscovery: () -> Unit,
    onRequestPeerExchange: () -> Unit,
    onConnectToRegistryPeer: (String) -> Unit,
    onRemoveRegistryPeer: (String) -> Unit,
    onConnectBootstrapPeer: (String) -> Unit,
    onToggleBootstrapPeer: (String, Boolean) -> Unit,
    onRemoveBootstrapPeer: (String) -> Unit,
    onAddCustomBootstrapPeer: (name: String, host: String, port: Int, expectedNodeId: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddBootstrapDialog by remember { mutableStateOf(false) }

    if (showAddBootstrapDialog) {
        AddBootstrapPeerDialog(
            onDismiss = { showAddBootstrapDialog = false },
            onAdd = { name, host, port, nodeId ->
                onAddCustomBootstrapPeer(name, host, port, nodeId)
                showAddBootstrapDialog = false
            }
        )
    }

    val filteredPeers = remember(registeredPeers, selectedFilter) {
        when (selectedFilter) {
            PeerFilterOption.ALL -> registeredPeers
            PeerFilterOption.CONNECTED -> registeredPeers.filter { it.isConnected }
            PeerFilterOption.AUTHENTICATED -> registeredPeers.filter { it.isAuthenticated }
            PeerFilterOption.DISCOVERED -> registeredPeers.filter {
                !it.isConnected && it.reachabilityStatus != ReachabilityStatus.UNREACHABLE && it.reachabilityStatus != ReachabilityStatus.STALE
            }
            PeerFilterOption.UNREACHABLE -> registeredPeers.filter {
                it.reachabilityStatus == ReachabilityStatus.UNREACHABLE || it.reachabilityStatus == ReachabilityStatus.STALE
            }
            PeerFilterOption.BOOTSTRAP -> registeredPeers.filter { it.isBootstrap }
        }
    }

    val availableCount = remember(registeredPeers) {
        registeredPeers.count { it.reachabilityStatus == ReachabilityStatus.REACHABLE || it.reachabilityStatus == ReachabilityStatus.CONNECTED }
    }
    val totalUnreachableCount = topologyMetrics.unreachablePeersCount + topologyMetrics.stalePeersCount

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Distributed Discovery & Topology Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            border = BorderStroke(1.dp, NmdDarkCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hub,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.stage7_discovery_title),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                    }

                    val statusColor = when (discoveryStatus) {
                        DiscoveryStatusState.DISCOVERING_LOCAL, DiscoveryStatusState.EXCHANGING_PEERS -> NmdSuccessGreen
                        DiscoveryStatusState.BOOTSTRAPPING -> NmdWarningOrange
                        DiscoveryStatusState.ERROR -> NmdDangerRed
                        DiscoveryStatusState.IDLE -> NmdTextSecondaryDark
                    }
                    val statusText = when (discoveryStatus) {
                        DiscoveryStatusState.IDLE -> stringResource(R.string.stage7_status_idle)
                        DiscoveryStatusState.DISCOVERING_LOCAL -> stringResource(R.string.stage7_status_discovering_local)
                        DiscoveryStatusState.EXCHANGING_PEERS -> stringResource(R.string.stage7_status_exchanging_peers)
                        DiscoveryStatusState.BOOTSTRAPPING -> stringResource(R.string.stage7_status_bootstrapping)
                        DiscoveryStatusState.ERROR -> stringResource(R.string.stage7_status_error)
                    }
                    Surface(
                        color = statusColor.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = statusText,
                            color = statusColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Discovery Method & Last Discovery Row
                val formattedLastTime = remember(lastSuccessfulDiscoveryMs) {
                    lastSuccessfulDiscoveryMs?.let {
                        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(it))
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${stringResource(R.string.stage7_discovery_method_label)}: ${discoveryMethod.name}",
                        fontSize = 11.sp,
                        color = NmdCyanBright
                    )
                    Text(
                        text = "${stringResource(R.string.stage7_last_discovery_label)}: ${formattedLastTime ?: stringResource(R.string.stage7_never_discovered)}",
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark
                    )
                }

                HorizontalDivider(color = NmdDarkCardBorder)

                // Topology Stats Row 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TopologyStatItem(
                        label = stringResource(R.string.stage7_stat_total_discovered),
                        value = "${topologyMetrics.totalDiscoveredPeers}",
                        color = NmdCyanBright,
                        modifier = Modifier.weight(1f)
                    )
                    TopologyStatItem(
                        label = stringResource(R.string.stage7_stat_authenticated),
                        value = "${topologyMetrics.authenticatedPeersCount}",
                        color = NmdSuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                    TopologyStatItem(
                        label = stringResource(R.string.stage7_stat_connected),
                        value = "${topologyMetrics.connectedPeersCount}",
                        color = NmdElectricCyan,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Topology Stats Row 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TopologyStatItem(
                        label = stringResource(R.string.stage7_stat_available),
                        value = "$availableCount",
                        color = NmdTextPrimaryDark,
                        modifier = Modifier.weight(1f)
                    )
                    TopologyStatItem(
                        label = stringResource(R.string.stage7_stat_unreachable),
                        value = "$totalUnreachableCount",
                        color = if (totalUnreachableCount > 0) NmdWarningOrange else NmdTextSecondaryDark,
                        modifier = Modifier.weight(1f)
                    )
                    TopologyStatItem(
                        label = stringResource(R.string.stage7_stat_bootstrap),
                        value = "${topologyMetrics.bootstrapPeersCount}",
                        color = NmdElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Discovery Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onRefreshDiscovery,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("stage7_refresh_discovery_btn"),
                        border = BorderStroke(1.dp, NmdElectricCyan),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.stage7_action_refresh_discovery),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = onRequestPeerExchange,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("stage7_request_pex_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.stage7_action_request_pex),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // 2. Bootstrap Peer Architecture Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            border = BorderStroke(1.dp, NmdDarkCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = null,
                            tint = NmdElectricBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.stage7_bootstrap_section_title),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                    }

                    OutlinedButton(
                        onClick = { showAddBootstrapDialog = true },
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("stage7_add_bootstrap_btn"),
                        border = BorderStroke(1.dp, NmdElectricBlue)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.stage7_action_add_bootstrap),
                            fontSize = 11.sp
                        )
                    }
                }

                Text(
                    text = stringResource(R.string.stage7_bootstrap_dev_notice),
                    fontSize = 11.sp,
                    color = NmdTextSecondaryDark,
                    lineHeight = 15.sp
                )

                bootstrapPeers.forEach { bPeer ->
                    BootstrapPeerItem(
                        peer = bPeer,
                        onConnect = { onConnectBootstrapPeer(bPeer.id) },
                        onToggle = { enabled -> onToggleBootstrapPeer(bPeer.id, enabled) },
                        onRemove = { onRemoveBootstrapPeer(bPeer.id) }
                    )
                }
            }
        }

        // 3. Distributed Peer Registry Card with Filter Chips
        Card(
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            border = BorderStroke(1.dp, NmdDarkCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = stringResource(R.string.stage7_registry_title),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )

                val filters = listOf(
                    PeerFilterOption.ALL to R.string.stage7_filter_all,
                    PeerFilterOption.CONNECTED to R.string.stage7_filter_connected,
                    PeerFilterOption.AUTHENTICATED to R.string.stage7_filter_authenticated,
                    PeerFilterOption.DISCOVERED to R.string.stage7_filter_discovered,
                    PeerFilterOption.UNREACHABLE to R.string.stage7_filter_unreachable
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filters.forEach { (option, titleRes) ->
                        val isSelected = selectedFilter == option
                        Box(
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) NmdElectricBlue else Color(0xFF0F1A30))
                                .border(
                                    1.dp,
                                    if (isSelected) NmdElectricCyan else NmdDarkCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onSelectFilter(option) }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("registry_filter_${option.name}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stringResource(titleRes),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else NmdTextSecondaryDark
                            )
                        }
                    }
                }

                if (filteredPeers.isEmpty()) {
                    Text(
                        text = stringResource(R.string.stage7_no_registry_peers_hint),
                        fontSize = 12.sp,
                        color = NmdTextSecondaryDark,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        filteredPeers.forEach { record ->
                            PeerRegistryItem(
                                record = record,
                                onConnect = { onConnectToRegistryPeer(record.peerId) },
                                onRemove = { onRemoveRegistryPeer(record.peerId) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopologyStatItem(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            color = NmdTextSecondaryDark,
            maxLines = 1
        )
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
private fun BootstrapPeerItem(
    peer: BootstrapPeer,
    onConnect: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onRemove: () -> Unit
) {
    Surface(
        color = Color(0xFF0B1426),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = peer.name,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                        if (peer.isPreconfiguredDev) {
                            Surface(
                                color = NmdWarningOrange.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.stage7_bootstrap_dev_badge),
                                    fontSize = 9.sp,
                                    color = NmdWarningOrange,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = peer.addressFormatted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NmdCyanBright
                    )
                }

                Switch(
                    checked = peer.isEnabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("bootstrap_switch_${peer.id}")
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val statusColor = when (peer.status) {
                    BootstrapStatus.CONNECTED -> NmdSuccessGreen
                    BootstrapStatus.CONNECTING -> NmdElectricCyan
                    BootstrapStatus.BACKOFF, BootstrapStatus.FAILED -> NmdDangerRed
                    BootstrapStatus.IDLE -> NmdTextSecondaryDark
                }
                Text(
                    text = "${peer.status.name}${if (peer.consecutiveFailures > 0) " (${peer.consecutiveFailures}x)" else ""}",
                    fontSize = 10.sp,
                    color = statusColor,
                    fontWeight = FontWeight.SemiBold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!peer.isPreconfiguredDev) {
                        IconButton(
                            onClick = onRemove,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("bootstrap_delete_${peer.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete Bootstrap Peer",
                                tint = NmdDangerRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onConnect,
                        enabled = peer.isEnabled && peer.status != BootstrapStatus.CONNECTING,
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("bootstrap_connect_${peer.id}"),
                        border = BorderStroke(1.dp, NmdElectricCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Link,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.p2p_action_connect),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            peer.lastError?.let { err ->
                Text(
                    text = err,
                    fontSize = 10.sp,
                    color = NmdDangerRed
                )
            }
        }
    }
}

@Composable
private fun PeerRegistryItem(
    record: PeerRegistryRecord,
    onConnect: () -> Unit,
    onRemove: () -> Unit
) {
    Surface(
        color = Color(0xFF0B1426),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = record.displayNodeId,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                    Text(
                        text = "${record.formattedAddress} • v${record.protocolVersion} • ${record.discoverySource.name}",
                        fontSize = 10.sp,
                        color = NmdTextSecondaryDark
                    )
                }

                val reachColor = when (record.reachabilityStatus) {
                    ReachabilityStatus.CONNECTED -> NmdSuccessGreen
                    ReachabilityStatus.REACHABLE -> NmdElectricCyan
                    ReachabilityStatus.UNREACHABLE, ReachabilityStatus.STALE -> NmdDangerRed
                    ReachabilityStatus.UNKNOWN -> NmdWarningOrange
                }
                Surface(
                    color = reachColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = record.reachabilityStatus.name,
                        color = reachColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = if (record.isAuthenticated) NmdSuccessGreen else NmdTextSecondaryDark,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = record.authenticationStatus.name,
                            fontSize = 10.sp,
                            color = if (record.isAuthenticated) NmdSuccessGreen else NmdTextSecondaryDark
                        )
                    }
                    Text(
                        text = "${stringResource(R.string.stage7_reputation_label)}: ${record.reputationScore}/100",
                        fontSize = 10.sp,
                        color = NmdCyanBright
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("registry_remove_${record.peerId}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Remove Peer",
                            tint = NmdTextSecondaryDark,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    if (!record.isConnected) {
                        OutlinedButton(
                            onClick = onConnect,
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("registry_connect_${record.peerId}"),
                            border = BorderStroke(1.dp, NmdElectricCyan)
                        ) {
                            Text(
                                text = stringResource(R.string.p2p_action_connect),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddBootstrapPeerDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, host: String, port: Int, expectedNodeId: String?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var portStr by remember { mutableStateOf("9876") }
    var nodeId by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NmdDarkCard,
        title = {
            Text(
                text = stringResource(R.string.stage7_bootstrap_dialog_title),
                color = NmdTextPrimaryDark,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.stage7_bootstrap_name_label)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark,
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bootstrap_input_name")
                )
                OutlinedTextField(
                    value = host,
                    onValueChange = {
                        host = it
                        validationError = null
                    },
                    label = { Text(stringResource(R.string.p2p_field_host_label)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark,
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bootstrap_input_host")
                )
                OutlinedTextField(
                    value = portStr,
                    onValueChange = {
                        portStr = it
                        validationError = null
                    },
                    label = { Text(stringResource(R.string.p2p_field_port_label)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark,
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bootstrap_input_port")
                )
                OutlinedTextField(
                    value = nodeId,
                    onValueChange = { nodeId = it },
                    label = { Text(stringResource(R.string.p2p_field_node_id_optional_label)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark,
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("bootstrap_input_node_id")
                )
                validationError?.let { err ->
                    Text(text = err, color = NmdDangerRed, fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmedHost = host.trim()
                    val parsedPort = portStr.trim().toIntOrNull()
                    if (trimmedHost.isBlank() || trimmedHost == "0.0.0.0" || trimmedHost == "255.255.255.255") {
                        validationError = "Valid host IP or address is required"
                        return@Button
                    }
                    if (parsedPort == null || parsedPort !in 1..65535) {
                        validationError = "Port must be between 1 and 65535"
                        return@Button
                    }
                    onAdd(name.trim(), trimmedHost, parsedPort, nodeId.trim().ifBlank { null })
                },
                modifier = Modifier
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("bootstrap_confirm_add_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
            ) {
                Text(stringResource(R.string.stage7_action_add_bootstrap))
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp)
            ) {
                Text("Cancel", color = NmdTextSecondaryDark)
            }
        }
    )
}
