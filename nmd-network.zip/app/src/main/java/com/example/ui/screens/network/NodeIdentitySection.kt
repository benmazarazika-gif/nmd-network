package com.example.ui.screens.network

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.crypto.SelfVerificationStatus
import com.example.crypto.model.KeyStorageSecurityStatus
import com.example.crypto.model.NodeIdentity
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun NodeIdentitySection(
    nodeIdentity: NodeIdentity?,
    selfVerificationStatus: SelfVerificationStatus,
    onGenerateIdentity: () -> Unit,
    onVerifySelfIdentity: () -> Unit,
    onViewPublicIdentity: () -> Unit,
    onSignTestMessage: () -> Unit,
    onDeleteIdentity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("node_identity_section")
    ) {
        // Top Header Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("identity_header_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0x1F00D2FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.crypto_identity_title),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                        Text(
                            text = stringResource(R.string.crypto_identity_subtitle),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NmdCyanBright,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (nodeIdentity != null) Color(0x1A00E676) else Color(0x26FFA726)
                ) {
                    Text(
                        text = if (nodeIdentity != null) {
                            stringResource(R.string.crypto_status_active)
                        } else {
                            stringResource(R.string.crypto_status_empty)
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (nodeIdentity != null) NmdSuccessGreen else NmdWarningOrange,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (nodeIdentity == null) {
            // Empty State Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("empty_identity_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0x1F00D2FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = stringResource(R.string.crypto_no_identity_title),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = stringResource(R.string.crypto_no_identity_desc),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        ),
                        modifier = Modifier.fillMaxWidth(0.9f)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = onGenerateIdentity,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_identity_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.crypto_btn_generate),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            // Identity Details & Actions
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("identity_details_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Node Identifier
                    CryptoFieldItem(
                        icon = Icons.Default.Fingerprint,
                        label = stringResource(R.string.crypto_node_id_title),
                        value = nodeIdentity.nodeId,
                        onCopy = {
                            copyToClipboard(context, "Node ID", nodeIdentity.nodeId)
                        },
                        testTag = "node_id_field"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Public Key Hex
                    CryptoFieldItem(
                        icon = Icons.Default.Key,
                        label = stringResource(R.string.crypto_public_key_title),
                        value = nodeIdentity.publicKeyHex,
                        onCopy = {
                            copyToClipboard(context, "Public Key", nodeIdentity.publicKeyHex)
                        },
                        testTag = "public_key_field"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Public Key Fingerprint
                    CryptoFieldItem(
                        icon = Icons.Default.Security,
                        label = stringResource(R.string.crypto_fingerprint_title),
                        value = nodeIdentity.publicKeyFingerprint,
                        onCopy = {
                            copyToClipboard(context, "Fingerprint", nodeIdentity.publicKeyFingerprint)
                        },
                        testTag = "fingerprint_field"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Metadata Row (Algorithm & Creation Date)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF070D18),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = stringResource(R.string.crypto_algorithm_title),
                                    fontSize = 10.sp,
                                    color = NmdTextSecondaryDark
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = nodeIdentity.algorithm,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NmdElectricCyan
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF070D18),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = stringResource(R.string.crypto_creation_date_title),
                                    fontSize = 10.sp,
                                    color = NmdTextSecondaryDark
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = nodeIdentity.creationDateFormatted,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NmdTextPrimaryDark
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Storage Security Status Card (Honest representation of hardware/software backed KeyStore)
                    val (storageTitleRes, storageDescRes, storageColor) = when (nodeIdentity.securityStatus) {
                        KeyStorageSecurityStatus.HARDWARE_BACKED_KEYSTORE -> Triple(
                            R.string.crypto_storage_hardware_title,
                            R.string.crypto_storage_hardware_desc,
                            NmdSuccessGreen
                        )
                        KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE -> Triple(
                            R.string.crypto_storage_software_title,
                            R.string.crypto_storage_software_desc,
                            NmdCyanBright
                        )
                        KeyStorageSecurityStatus.ENCRYPTED_STORAGE -> Triple(
                            R.string.crypto_storage_enclave_title,
                            R.string.crypto_storage_enclave_desc,
                            NmdElectricCyan
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF070D18),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("storage_security_card")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = storageColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = stringResource(storageTitleRes),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = storageColor
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = stringResource(storageDescRes),
                                    fontSize = 10.sp,
                                    color = NmdTextSecondaryDark,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Self-Verification Status Banner (Challenge-response verification)
                    if (selfVerificationStatus != SelfVerificationStatus.IDLE) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = when (selfVerificationStatus) {
                                SelfVerificationStatus.VERIFYING -> Color(0x1F00D2FF)
                                SelfVerificationStatus.VERIFIED_SUCCESS -> Color(0x1A00E676)
                                SelfVerificationStatus.VERIFIED_FAILED -> Color(0x26FF5252)
                                else -> Color.Transparent
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("self_verify_status_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                when (selfVerificationStatus) {
                                    SelfVerificationStatus.VERIFYING -> {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            strokeWidth = 2.dp,
                                            color = NmdElectricCyan
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Running cryptographic challenge-response...",
                                            fontSize = 11.sp,
                                            color = NmdElectricCyan
                                        )
                                    }
                                    SelfVerificationStatus.VERIFIED_SUCCESS -> {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = NmdSuccessGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = stringResource(R.string.crypto_self_verify_success),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NmdSuccessGreen
                                        )
                                    }
                                    SelfVerificationStatus.VERIFIED_FAILED -> {
                                        Icon(
                                            imageVector = Icons.Default.Error,
                                            contentDescription = null,
                                            tint = Color(0xFFFF5252),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = stringResource(R.string.crypto_self_verify_failed),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFF5252)
                                        )
                                    }
                                    else -> Unit
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                    }

                    // Action Buttons Grid
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onViewPublicIdentity,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("view_public_identity_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.crypto_btn_view_public),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onVerifySelfIdentity,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("verify_self_identity_btn"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = NmdElectricCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Verify Keys",
                                    fontSize = 11.sp,
                                    color = NmdElectricCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = onSignTestMessage,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("sign_test_msg_btn"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Create,
                                    contentDescription = null,
                                    tint = NmdCyanBright,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Sign Message",
                                    fontSize = 11.sp,
                                    color = NmdCyanBright,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onDeleteIdentity,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("delete_identity_btn"),
                            shape = RoundedCornerShape(10.dp),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(Color(0x66FF5252))
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = null,
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.crypto_btn_delete),
                                color = Color(0xFFFF5252),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CryptoFieldItem(
    icon: ImageVector,
    label: String,
    value: String,
    onCopy: () -> Unit,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF070D18),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        color = NmdTextSecondaryDark
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = value,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color.White,
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    )
                }
            }

            IconButton(
                onClick = onCopy,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy",
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, context.getString(R.string.crypto_copied_toast), Toast.LENGTH_SHORT).show()
}
