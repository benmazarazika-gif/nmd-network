package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.crypto.model.MessageVerificationResult
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.crypto.model.VerificationFailureReason
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SignMessageTestDialog(
    lastSignedMessage: SignedProtocolMessage?,
    lastVerificationResult: MessageVerificationResult?,
    onSign: (ProtocolMessageType, String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedType by remember { mutableStateOf(ProtocolMessageType.NODE_ANNOUNCEMENT) }
    var payloadText by remember {
        mutableStateOf("{\"status\":\"ACTIVE_DEMO\",\"node_version\":\"1.0.0\"}")
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp)
                .padding(vertical = 16.dp)
                .testTag("sign_message_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(NmdDarkCardBorder)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x1F00D2FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Create,
                                contentDescription = null,
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.crypto_sign_dialog_title),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NmdTextPrimaryDark
                                )
                            )
                            Text(
                                text = "RFC 8032 Ed25519 Verification Sandbox",
                                fontSize = 11.sp,
                                color = NmdCyanBright
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp).testTag("sign_dialog_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = stringResource(R.string.dialog_close),
                            tint = NmdTextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Safety Notice
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x1F00D2FF),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.crypto_sign_dialog_desc),
                            fontSize = 11.sp,
                            color = NmdTextSecondaryDark,
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Message Type Selector
                Text(
                    text = "Protocol Message Type",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ProtocolMessageType.entries.forEach { type ->
                        val isSelected = selectedType == type
                        val typeTitle = when (type) {
                            ProtocolMessageType.NODE_ANNOUNCEMENT -> stringResource(R.string.msg_type_announcement)
                            ProtocolMessageType.HEARTBEAT -> stringResource(R.string.msg_type_heartbeat)
                            ProtocolMessageType.PEER_PING -> stringResource(R.string.msg_type_ping)
                            ProtocolMessageType.STATE_SYNC_REQUEST -> stringResource(R.string.msg_type_sync_req)
                            ProtocolMessageType.GOSSIP_DATA -> stringResource(R.string.msg_type_gossip)
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedType = type
                                if (type == ProtocolMessageType.HEARTBEAT) {
                                    payloadText = "{\"uptime_sec\":85620,\"peer_count\":18}"
                                } else if (type == ProtocolMessageType.PEER_PING) {
                                    payloadText = "{\"ping_nonce\":\"0x9f8a1b\"}"
                                } else if (type == ProtocolMessageType.STATE_SYNC_REQUEST) {
                                    payloadText = "{\"start_block\":1849200,\"end_block\":1849208}"
                                } else if (type == ProtocolMessageType.GOSSIP_DATA) {
                                    payloadText = "{\"channel\":\"mempool_v1\",\"data_hash\":\"0x7e8c3...\"}"
                                } else {
                                    payloadText = "{\"status\":\"ACTIVE_DEMO\",\"node_version\":\"1.0.0\"}"
                                }
                            },
                            label = { Text(typeTitle, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NmdElectricBlue,
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFF0F1A30),
                                labelColor = NmdTextSecondaryDark
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) NmdElectricCyan else NmdDarkCardBorder
                            ),
                            modifier = Modifier.testTag("chip_msg_type_${type.name}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Payload Input
                Text(
                    text = "Message Payload (JSON / String)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = payloadText,
                    onValueChange = { payloadText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payload_input_field"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF070D18),
                        unfocusedContainerColor = Color(0xFF070D18)
                    ),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    ),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Sign Action Button
                Button(
                    onClick = { onSign(selectedType, payloadText) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sign_now_action_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Create,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Sign Protocol Message (Ed25519)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // Results Section (Visible after signing)
                if (lastSignedMessage != null) {
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Signed Protocol Message Output",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF070D18))
                            .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            // Verification Status Badge
                            val isVerified = lastVerificationResult is MessageVerificationResult.Valid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isVerified) Icons.Default.CheckCircle else Icons.Default.Error,
                                        contentDescription = null,
                                        tint = if (isVerified) NmdSuccessGreen else Color(0xFFFF5252),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isVerified) {
                                            stringResource(R.string.crypto_verify_success)
                                        } else {
                                            stringResource(R.string.crypto_verify_failed)
                                        },
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isVerified) NmdSuccessGreen else Color(0xFFFF5252)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0x2600D2FF)
                                ) {
                                    Text(
                                        text = stringResource(R.string.crypto_test_msg_badge),
                                        fontSize = 8.sp,
                                        color = NmdElectricCyan,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            if (lastVerificationResult is MessageVerificationResult.Invalid) {
                                val reasonText = when (lastVerificationResult.reason) {
                                    VerificationFailureReason.INVALID_SIGNATURE -> stringResource(R.string.verify_err_invalid_signature)
                                    VerificationFailureReason.SENDER_NODE_ID_MISMATCH -> stringResource(R.string.verify_err_sender_mismatch)
                                    VerificationFailureReason.EXPIRED_TIMESTAMP -> stringResource(R.string.verify_err_expired_timestamp)
                                    VerificationFailureReason.FUTURE_TIMESTAMP -> stringResource(R.string.verify_err_future_timestamp)
                                    VerificationFailureReason.DUPLICATE_MESSAGE_ID -> stringResource(R.string.verify_err_duplicate_message_id)
                                    VerificationFailureReason.MALFORMED_FORMAT -> stringResource(R.string.verify_err_malformed)
                                }
                                Text(
                                    text = "Failure reason: $reasonText (${lastVerificationResult.detail})",
                                    fontSize = 10.sp,
                                    color = Color(0xFFFF5252),
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Message ID: ${lastSignedMessage.messageId}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = NmdTextSecondaryDark
                            )

                            Text(
                                text = "Timestamp: ${lastSignedMessage.timestampFormatted}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = NmdTextSecondaryDark
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Ed25519 Signature (64 bytes / 128 hex):",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NmdCyanBright
                            )
                            Text(
                                text = lastSignedMessage.signatureHex,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Color.White,
                                lineHeight = 14.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(vertical = 4.dp)
                                    .testTag("signature_hex_output")
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Canonical Bytes Representation:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NmdCyanBright
                            )
                            Text(
                                text = lastSignedMessage.canonicalRepresentation,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = NmdTextSecondaryDark,
                                lineHeight = 13.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().testTag("sign_dialog_dismiss_btn"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = stringResource(R.string.dialog_close),
                        color = NmdTextSecondaryDark
                    )
                }
            }
        }
    }
}
