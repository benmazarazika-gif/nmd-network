package com.example.ui.screens.network

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.NodeConfiguration
import com.example.data.NodeRole
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun NodeConfigDialog(
    initialConfig: NodeConfiguration,
    onSave: (NodeRole, String, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedRole by remember { mutableStateOf(initialConfig.selectedRole) }
    var displayName by remember { mutableStateOf(initialConfig.displayName) }
    var isDemoActive by remember { mutableStateOf(initialConfig.isDemoActive) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = NmdDarkCard,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(22.dp))
                .testTag("node_config_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0F1A30)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = stringResource(R.string.node_config_dialog_title),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark
                            )
                        )
                        Text(
                            text = stringResource(R.string.node_mode_demo_tag),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NmdCyanBright,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Node Display Name Input
                Text(
                    text = stringResource(R.string.node_display_name_title),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NmdTextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    placeholder = {
                        Text(
                            stringResource(R.string.node_display_name_hint),
                            color = NmdTextMutedDark,
                            fontSize = 12.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_node_display_name"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0B1424),
                        unfocusedContainerColor = Color(0xFF0B1424),
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Role Selector Chips
                Text(
                    text = stringResource(R.string.tab_network_roles),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NmdTextPrimaryDark
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NodeRole.entries.forEach { role ->
                        val isSelected = selectedRole == role
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF13284A) else Color(0xFF0C1628))
                                .border(
                                    1.dp,
                                    if (isSelected) NmdElectricCyan else NmdDarkCardBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedRole = role }
                                .padding(12.dp)
                                .testTag("role_select_${role.name}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(role.titleRes),
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else NmdTextPrimaryDark
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = stringResource(role.descRes),
                                    fontSize = 11.sp,
                                    color = NmdTextSecondaryDark
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Estimated Resource Specs for Selected Role
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1424)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.tab_network_device),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NmdCyanBright
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        SpecItemRow(
                            label = stringResource(R.string.node_specs_ram),
                            value = selectedRole.estimatedRam
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        SpecItemRow(
                            label = stringResource(R.string.node_specs_storage),
                            value = selectedRole.estimatedStorage
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        SpecItemRow(
                            label = stringResource(R.string.node_specs_battery),
                            value = selectedRole.estimatedBattery
                        )
                    }
                }

                // Validator Warning (Shown only when Validator role is selected)
                if (selectedRole == NodeRole.VALIDATOR) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x22FF9F43))
                            .border(1.dp, Color(0x55FF9F43), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = NmdWarningOrange,
                            modifier = Modifier
                                .size(20.dp)
                                .padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.node_validator_warning_title),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFC078)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = stringResource(R.string.node_validator_warning_desc),
                                fontSize = 11.sp,
                                color = NmdTextSecondaryDark,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Demo Node Mode Toggle Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0C1628))
                        .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.node_demo_mode_switch),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(R.string.node_demo_mode_desc),
                            fontSize = 10.sp,
                            color = NmdTextSecondaryDark
                        )
                    }

                    Switch(
                        checked = isDemoActive,
                        onCheckedChange = { isDemoActive = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NmdElectricBlue,
                            uncheckedThumbColor = NmdTextMutedDark,
                            uncheckedTrackColor = Color(0xFF080E1C)
                        ),
                        modifier = Modifier.testTag("switch_demo_node_mode")
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Button(
                    onClick = { onSave(selectedRole, displayName, isDemoActive) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_save_node_config"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                ) {
                    Text(
                        text = stringResource(R.string.node_save_config_btn),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("btn_cancel_node_config"),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                ) {
                    Text(
                        text = stringResource(R.string.dialog_close),
                        color = NmdTextSecondaryDark
                    )
                }
            }
        }
    }
}

@Composable
fun SpecItemRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = NmdTextSecondaryDark)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = NmdTextPrimaryDark)
    }
}
