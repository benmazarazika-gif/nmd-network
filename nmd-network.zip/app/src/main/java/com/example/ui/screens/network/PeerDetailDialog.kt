package com.example.ui.screens.network

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.session.ConnectionHealth
import com.example.p2p.session.PeerSession
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdDarkSurface
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PeerDetailDialog(
    session: PeerSession,
    onDismiss: () -> Unit,
    onSendMessage: (sessionId: String, type: P2pMessageType, payload: String) -> Unit,
    onSendPing: (sessionId: String) -> Unit,
    onDisconnect: (sessionId: String) -> Unit
) {
    val context = LocalContext.current
    var selectedType by remember { mutableStateOf(P2pMessageType.DATA) }
    var payloadText by remember { mutableStateOf("{\"type\":\"DATA\",\"content\":\"Hello NMD Stage 6 Peer!\"}") }
    var isTypeMenuExpanded by remember { mutableStateOf(false) }

    val healthColor = when (session.connectionHealth) {
        ConnectionHealth.EXCELLENT -> NmdSuccessGreen
        ConnectionHealth.GOOD -> NmdElectricCyan
        ConnectionHealth.DEGRADED -> NmdWarningOrange
        ConnectionHealth.UNRESPONSIVE -> NmdDangerRed
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = NmdDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.p2p_peer_details_title),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = NmdTextPrimaryDark
                        )
                        Text(
                            text = if (session.isOutbound) stringResource(R.string.p2p_session_outbound) else stringResource(R.string.p2p_session_inbound),
                            fontSize = 11.sp,
                            color = NmdTextSecondaryDark
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = NmdTextSecondaryDark
                        )
                    }
                }

                HorizontalDivider(color = NmdDarkCardBorder)

                // Status & Health Badge Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0x2E10B981)
                    ) {
                        Text(
                            text = session.state.name,
                            color = NmdSuccessGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(healthColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = session.connectionHealth.name,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = healthColor
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${session.lastRoundTripLatencyMs}ms",
                            fontSize = 12.sp,
                            color = NmdTextSecondaryDark
                        )
                    }
                }

                // Peer ID
                Column {
                    Text(
                        text = stringResource(R.string.p2p_field_node_id_label),
                        fontSize = 11.sp,
                        color = NmdTextSecondaryDark
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = session.peerId,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NmdCyanBright,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Peer ID", session.peerId))
                                Toast.makeText(context, R.string.crypto_copied_toast, Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Peer ID",
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Endpoint & Duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.p2p_field_endpoint_label),
                            fontSize = 11.sp,
                            color = NmdTextSecondaryDark
                        )
                        Text(
                            text = "${session.endpoint.host}:${session.endpoint.port}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = NmdTextPrimaryDark
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = stringResource(R.string.p2p_field_duration_label),
                            fontSize = 11.sp,
                            color = NmdTextSecondaryDark
                        )
                        Text(
                            text = "${session.durationSeconds}s",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = NmdTextPrimaryDark
                        )
                    }
                }

                // Delivery Statistics Grid
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NmdDarkCardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.p2p_delivery_metrics_title),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = NmdElectricCyan
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Sent: ${session.messagesSentCount}", fontSize = 11.sp, color = NmdTextSecondaryDark)
                                Text(text = "Received: ${session.messagesReceivedCount}", fontSize = 11.sp, color = NmdTextSecondaryDark)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "ACKed: ${session.successfulDeliveriesCount}",
                                    fontSize = 11.sp,
                                    color = NmdSuccessGreen,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Failed: ${session.failedDeliveriesCount}",
                                    fontSize = 11.sp,
                                    color = if (session.failedDeliveriesCount > 0) NmdDangerRed else NmdTextSecondaryDark
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = NmdDarkCardBorder)

                // Message Composer Section
                Text(
                    text = stringResource(R.string.p2p_composer_title),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = NmdTextPrimaryDark
                )

                // Type Picker
                ExposedDropdownMenuBox(
                    expanded = isTypeMenuExpanded,
                    onExpandedChange = { isTypeMenuExpanded = !isTypeMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedType.name,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(stringResource(R.string.p2p_field_type_label), fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTypeMenuExpanded) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NmdElectricCyan,
                            unfocusedBorderColor = NmdDarkCardBorder,
                            focusedTextColor = NmdTextPrimaryDark,
                            unfocusedTextColor = NmdTextPrimaryDark
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = isTypeMenuExpanded,
                        onDismissRequest = { isTypeMenuExpanded = false }
                    ) {
                        listOf(P2pMessageType.DATA, P2pMessageType.PEER_HELLO, P2pMessageType.PEER_STATUS, P2pMessageType.PING).forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.name, fontSize = 12.sp) },
                                onClick = {
                                    selectedType = type
                                    isTypeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Payload Input
                OutlinedTextField(
                    value = payloadText,
                    onValueChange = { payloadText = it },
                    label = { Text(stringResource(R.string.p2p_field_payload_label), fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder,
                        focusedTextColor = NmdTextPrimaryDark,
                        unfocusedTextColor = NmdTextPrimaryDark
                    ),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    ),
                    maxLines = 3
                )

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onSendMessage(session.sessionId, selectedType, payloadText)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_send_reliable_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.p2p_action_send_reliable),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = { onSendPing(session.sessionId) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdElectricCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NmdElectricCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("dialog_ping_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.NetworkCheck,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.p2p_action_ping),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Disconnect Peer Button
                OutlinedButton(
                    onClick = {
                        onDisconnect(session.sessionId)
                        onDismiss()
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NmdDangerRed),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NmdDangerRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_disconnect_peer_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = null,
                        tint = NmdDangerRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.p2p_action_disconnect_peer),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NmdDangerRed
                    )
                }
            }
        }
    }
}
