package com.example.ui.screens.wallet

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.WalletState
import com.example.data.WalletTransaction
import com.example.ui.components.NmdLogoBadge
import com.example.ui.screens.ActivityRowItem
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdSuccessGreenBg
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark

@Composable
fun WalletOverviewSection(
    walletState: WalletState,
    recentTransactions: List<WalletTransaction>,
    onToggleVisibility: () -> Unit,
    onNavigateToSend: () -> Unit,
    onNavigateToReceive: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSecurity: () -> Unit,
    onTransactionClick: (WalletTransaction) -> Unit,
    onAddressCopied: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager: ClipboardManager = LocalClipboardManager.current

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        // Wallet Account Identification Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NmdLogoBadge(size = 38.dp, fontSize = 18)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = stringResource(R.string.wallet_main_account),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                    if (walletState.walletAddress.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable {
                                    clipboardManager.setText(AnnotatedString(walletState.walletAddress))
                                    onAddressCopied()
                                }
                                .testTag("wallet_overview_copy_address")
                        ) {
                            Text(
                                text = walletState.walletAddress.take(10) + "..." + walletState.walletAddress.takeLast(6),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = NmdCyanBright,
                                    fontSize = 11.sp
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy address",
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    } else {
                        Text(
                            text = stringResource(R.string.stage19_no_identity_prompt),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NmdTextMutedDark,
                                fontSize = 11.sp
                            ),
                            modifier = Modifier
                                .clickable(onClick = onNavigateToSecurity)
                                .testTag("wallet_overview_init_identity")
                        )
                    }
                }
            }

            // Testnet badge
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0x1F00D2FF),
                modifier = Modifier.border(0.5.dp, Color(0x4400D2FF), RoundedCornerShape(12.dp))
            ) {
                Text(
                    text = stringResource(R.string.status_live_network),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NmdElectricCyan,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Total Balance Hero Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0x6600D2FF),
                            Color(0x220077FE),
                            Color(0x151E2D4E)
                        )
                    ),
                    shape = RoundedCornerShape(22.dp)
                )
                .testTag("wallet_balance_card"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C172E)),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF132B52),
                                Color(0xFF0C172E)
                            ),
                            radius = 420f
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.wallet_total_balance),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = NmdTextSecondaryDark
                            )
                        )

                        IconButton(
                            onClick = onToggleVisibility,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(0x2200D2FF))
                                .testTag("btn_toggle_balance_visibility")
                        ) {
                            Icon(
                                imageVector = if (walletState.isBalanceVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = stringResource(R.string.wallet_toggle_visibility),
                                tint = NmdElectricCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = if (walletState.isBalanceVisible) walletState.totalBalanceFormatted else stringResource(R.string.wallet_hidden_balance),
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NmdTextPrimaryDark,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = walletState.tokenSymbol,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = NmdElectricCyan
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (walletState.changePercent.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(NmdSuccessGreenBg)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = walletState.changePercent,
                                    color = NmdSuccessGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                        }
                        Text(
                            text = stringResource(
                                if (walletState.isDemo) R.string.wallet_demo_badge
                                else R.string.stage19_wallet_live_badge
                            ),
                            color = NmdCyanBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Available & Reserved Balance Sub-cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Available
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.wallet_available_balance),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (walletState.isBalanceVisible) "${walletState.availableBalanceFormatted} NMD" else "••••••",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }
            }

            // Staked / Reserved
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.wallet_reserved_balance),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (walletState.isBalanceVisible) "${walletState.reservedBalanceFormatted} NMD" else "••••••",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Main Primary Actions (Send & Receive)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            WalletHeroActionButton(
                title = stringResource(R.string.action_send),
                icon = Icons.AutoMirrored.Filled.Send,
                containerColor = NmdElectricBlue,
                onClick = onNavigateToSend,
                testTag = "wallet_action_send",
                modifier = Modifier.weight(1f)
            )

            WalletHeroActionButton(
                title = stringResource(R.string.action_receive),
                icon = Icons.Default.FileDownload,
                containerColor = Color(0xFF0F264A),
                borderColor = Color(0x6600D2FF),
                onClick = onNavigateToReceive,
                testTag = "wallet_action_receive",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Sub Navigation Shortcuts (Transaction History & Security)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            WalletQuickLinkChip(
                title = stringResource(R.string.wallet_btn_history),
                icon = Icons.Default.History,
                onClick = onNavigateToHistory,
                testTag = "wallet_link_history",
                modifier = Modifier.weight(1f)
            )

            WalletQuickLinkChip(
                title = stringResource(R.string.wallet_btn_security),
                icon = Icons.Default.Security,
                onClick = onNavigateToSecurity,
                testTag = "wallet_link_security",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Compact Recent Transactions Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.activity_title),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NmdTextPrimaryDark
                )
            )

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onNavigateToHistory)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.activity_view_all),
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = NmdElectricCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Recent 3 Transactions Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                val previewList = recentTransactions.take(3)
                if (previewList.isEmpty()) {
                    Text(
                        text = stringResource(R.string.stage19_activity_empty),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NmdTextSecondaryDark,
                            lineHeight = 18.sp
                        ),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    previewList.forEachIndexed { index, tx ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onTransactionClick(tx) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ActivityRowItem(item = tx.toRecentActivityItem())
                        }
                        if (index < previewList.size - 1) {
                            Spacer(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .padding(vertical = 4.dp)
                                    .background(Color(0x1A1E2D4E))
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Ledger disclaimer chip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x1400D2FF))
                .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ⓘ " + stringResource(
                    if (walletState.isDemo) R.string.wallet_demo_disclaimer
                    else R.string.stage19_wallet_disclaimer
                ),
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NmdCyanBright,
                    lineHeight = 16.sp
                )
            )
        }
    }
}

private fun WalletTransaction.toRecentActivityItem() = com.example.data.RecentActivityItem(
    id = id,
    titleRes = titleRes,
    amountFormatted = amountFormatted,
    isCredit = isCredit,
    timeRes = timeRes,
    type = type
)

@Composable
fun WalletHeroActionButton(
    title: String,
    icon: ImageVector,
    containerColor: Color,
    borderColor: Color? = null,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(containerColor)
            .then(
                if (borderColor != null) Modifier.border(1.dp, borderColor, RoundedCornerShape(16.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(vertical = 15.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(19.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        )
    }
}

@Composable
fun WalletQuickLinkChip(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F1A30))
            .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NmdElectricCyan,
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = NmdTextPrimaryDark
                )
            )
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = NmdTextMutedDark,
            modifier = Modifier.size(14.dp)
        )
    }
}
