package com.example.ui.screens.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.p2p.scalability.model.CongestionState
import com.example.p2p.scalability.model.DeviceResourceMode
import com.example.p2p.scalability.model.NetworkScalabilitySnapshot
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDangerRed
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NetworkScalabilitySection(
    snapshot: NetworkScalabilitySnapshot,
    onRunHealthSweep: () -> Unit,
    onResetCircuitBreakers: () -> Unit,
    onSelectResourceMode: (DeviceResourceMode?) -> Unit,
    modifier: Modifier = Modifier
) {
    val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val lastSweepText = if (snapshot.lastSweepTimestampMs > 0L) {
        formatter.format(Date(snapshot.lastSweepTimestampMs))
    } else {
        stringResource(R.string.stage15_never_recorded)
    }

    val congestionColor = when (snapshot.congestionState) {
        CongestionState.NORMAL -> NmdSuccessGreen
        CongestionState.ELEVATED -> NmdCyanBright
        CongestionState.CONGESTED -> NmdDangerRed
        CongestionState.RECOVERING -> NmdWarningOrange
    }

    val openBreakersText = if (snapshot.openCircuitBreakers.isEmpty()) {
        stringResource(R.string.stage16_none_open)
    } else {
        snapshot.openCircuitBreakers.joinToString(", ") { "${it.targetType.name}:${it.state.name}" }
    }

    val resourceModeText = buildString {
        append(snapshot.deviceResource.mode.name)
        if (snapshot.deviceResource.isManualOverride) append(" (Manual)")
        snapshot.deviceResource.batteryPercent?.let { append(" • $it%") }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("stage16_scalability_card"),
        colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
        border = BorderStroke(1.dp, NmdDarkCardBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = stringResource(R.string.stage16_title),
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(R.string.stage16_title),
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = NmdTextPrimaryDark,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0x2200D2FF),
                    border = BorderStroke(1.dp, Color(0x4400D2FF))
                ) {
                    Text(
                        text = stringResource(R.string.stage16_badge),
                        color = NmdElectricCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = stringResource(R.string.stage16_notice),
                fontSize = 11.sp,
                color = NmdTextSecondaryDark
            )

            HorizontalDivider(color = NmdDarkCardBorder)

            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_connected_peers),
                value = "${snapshot.connectedPeersCount} / ${snapshot.maxConnectedCap} (In:${snapshot.maxInboundCap} Out:${snapshot.maxOutboundCap})",
                valueColor = NmdTextPrimaryDark
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_health_breakdown),
                value = "${snapshot.healthyPeersCount} / ${snapshot.degradedPeersCount} / ${snapshot.unreachablePeersCount}",
                valueColor = if (snapshot.unreachablePeersCount > 0) NmdWarningOrange else NmdSuccessGreen
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_quarantined_revoked),
                value = "${snapshot.quarantinedPeersCount} / ${snapshot.revokedPeersCount}",
                valueColor = if (snapshot.quarantinedPeersCount + snapshot.revokedPeersCount > 0) NmdWarningOrange else NmdTextSecondaryDark
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_queue_depths),
                value = "${snapshot.outboundQueueDepth} / ${snapshot.inboundQueueDepth}",
                valueColor = NmdTextPrimaryDark
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_dropped_expired),
                value = "${snapshot.droppedQueueMessagesCount} / ${snapshot.expiredQueueMessagesCount}",
                valueColor = NmdTextSecondaryDark
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_rate_limited),
                value = snapshot.rateLimitedEventsCount.toString(),
                valueColor = if (snapshot.rateLimitedEventsCount > 0L) NmdWarningOrange else NmdTextSecondaryDark
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_congestion_state),
                value = snapshot.congestionState.name,
                valueColor = congestionColor
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_circuit_breakers),
                value = openBreakersText,
                valueColor = if (snapshot.openCircuitBreakers.isNotEmpty()) NmdDangerRed else NmdSuccessGreen
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_bootstrap_health),
                value = "${snapshot.healthyBootstrapCount} OK / ${snapshot.unavailableBootstrapCount} Down",
                valueColor = if (snapshot.healthyBootstrapCount > 0) NmdSuccessGreen else NmdWarningOrange
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_signaling_health),
                value = snapshot.signalingHealthSummary,
                valueColor = NmdCyanBright
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_resource_mode),
                value = resourceModeText,
                valueColor = NmdTextPrimaryDark
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_validator_quorum),
                value = snapshot.validatorAvailability.quorumStatusSummary,
                valueColor = when {
                    snapshot.validatorAvailability.canSatisfyCurrentQuorum -> NmdSuccessGreen
                    snapshot.validatorAvailability.configuredValidatorsCount == 0 -> NmdTextSecondaryDark
                    else -> NmdDangerRed
                }
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_topology_health),
                value = "${snapshot.topologyHealth.topologyHealthScore}/100 (Subnets:${snapshot.topologyHealth.uniqueSubnetPrefixCount}, Src:${snapshot.topologyHealth.uniqueSourceCount})",
                valueColor = if (snapshot.topologyHealth.topologyHealthScore >= 70) NmdSuccessGreen else NmdWarningOrange
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_avg_rtt),
                value = snapshot.averagePeerRttMs?.let { "${it} ms" } ?: stringResource(R.string.stage14_none_recorded),
                valueColor = NmdCyanBright
            )
            ScalabilityMetricRow(
                label = stringResource(R.string.stage16_field_last_sweep),
                value = lastSweepText,
                valueColor = NmdTextSecondaryDark
            )

            // Operational resource mode quick selectors
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = !snapshot.deviceResource.isManualOverride,
                    onClick = { onSelectResourceMode(null) },
                    modifier = Modifier
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage16_mode_auto_chip"),
                    label = { Text(stringResource(R.string.stage16_mode_auto), fontSize = 11.sp) }
                )
                FilterChip(
                    selected = snapshot.deviceResource.isManualOverride && snapshot.deviceResource.mode == DeviceResourceMode.LOW_RESOURCE,
                    onClick = { onSelectResourceMode(DeviceResourceMode.LOW_RESOURCE) },
                    modifier = Modifier
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage16_mode_low_chip"),
                    label = { Text(stringResource(R.string.stage16_mode_low), fontSize = 11.sp) }
                )
                FilterChip(
                    selected = snapshot.deviceResource.isManualOverride && snapshot.deviceResource.mode == DeviceResourceMode.BALANCED,
                    onClick = { onSelectResourceMode(DeviceResourceMode.BALANCED) },
                    modifier = Modifier
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage16_mode_balanced_chip"),
                    label = { Text(stringResource(R.string.stage16_mode_balanced), fontSize = 11.sp) }
                )
                FilterChip(
                    selected = snapshot.deviceResource.isManualOverride && snapshot.deviceResource.mode == DeviceResourceMode.HIGH_CAPABILITY,
                    onClick = { onSelectResourceMode(DeviceResourceMode.HIGH_CAPABILITY) },
                    modifier = Modifier
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage16_mode_high_chip"),
                    label = { Text(stringResource(R.string.stage16_mode_high), fontSize = 11.sp) }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onRunHealthSweep,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage16_run_sweep_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.HealthAndSafety, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.stage16_action_health_sweep),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = onResetCircuitBreakers,
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("stage16_reset_breakers_btn"),
                    border = BorderStroke(1.dp, NmdElectricCyan),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null, tint = NmdElectricCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.stage16_action_reset_breakers),
                        fontSize = 11.sp,
                        color = NmdElectricCyan,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun ScalabilityMetricRow(
    label: String,
    value: String,
    valueColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = NmdTextSecondaryDark,
            modifier = Modifier.weight(0.46f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = valueColor,
            modifier = Modifier.weight(0.54f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
