package com.example.ui.screens

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.crypto.NodeIdentityManager
import com.example.data.ActivityType
import com.example.data.NetworkMetrics
import com.example.data.RecentActivityItem
import com.example.data.WalletState
import com.example.service.NmdNodeForegroundService
import com.example.transaction.NmdTransactionEngineRegistry
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdAmountCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    private val _walletState = MutableStateFlow(WalletState())
    val walletState: StateFlow<WalletState> = _walletState.asStateFlow()

    private val _networkMetrics = MutableStateFlow(NetworkMetrics())
    val networkMetrics: StateFlow<NetworkMetrics> = _networkMetrics.asStateFlow()

    private val _recentActivities = MutableStateFlow<List<RecentActivityItem>>(emptyList())
    val recentActivities: StateFlow<List<RecentActivityItem>> = _recentActivities.asStateFlow()

    private var contextJob: Job? = null

    fun attachContext(context: Context) {
        if (contextJob?.isActive == true) return
        val appContext = context.applicationContext
        contextJob = viewModelScope.launch(Dispatchers.IO) {
            val idManager = NodeIdentityManager(appContext)
            val engine = NmdTransactionEngineRegistry.getOrCreate(appContext)
            engine.initialize()
            engine.ledgerState.initialize()

            combine(
                idManager.identity,
                engine.ledgerState.accounts,
                engine.mempoolTransactions,
                NmdNodeForegroundService.isRunning
            ) { identity, accounts, mempool, serviceRunning ->
                Triple(identity, accounts, Pair(mempool, serviceRunning))
            }.collect { (identity, accounts, mempoolAndService) ->
                val (mempool, serviceRunning) = mempoolAndService
                val addr = engine.deriveSenderAddress(identity) ?: ""
                val acct = if (addr.isNotEmpty()) accounts[addr] else null
                val totalUnits = acct?.balanceUnits ?: 0L
                val pendingOutflow = mempool
                    .filter {
                        it.transaction.senderAddress == addr && (
                            it.status == MempoolTxStatus.PENDING ||
                                it.status == MempoolTxStatus.VALIDATED ||
                                it.status == MempoolTxStatus.QUEUED
                            )
                    }
                    .sumOf { it.transaction.amountUnits + it.transaction.feeUnits }
                val reservedUnits = minOf(totalUnits, pendingOutflow)
                val availableUnits = maxOf(0L, totalUnits - reservedUnits)

                _walletState.value = _walletState.value.copy(
                    walletAddress = addr,
                    totalUnits = totalUnits,
                    availableUnits = availableUnits,
                    reservedUnits = reservedUnits,
                    totalBalance = totalUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD,
                    availableBalance = availableUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD,
                    reservedBalance = reservedUnits.toDouble() / NmdAmountCodec.UNITS_PER_NMD,
                    isDemo = false,
                    changePercent = ""
                )

                val confirmedArchive = if (addr.isNotEmpty()) {
                    engine.storage.getConfirmedArchiveForAddress(addr, 10)
                } else {
                    emptyList()
                }
                _recentActivities.value = buildRecentActivities(addr, mempool, confirmedArchive)

                val activePeers = engine.peerRegistry?.peers?.value?.count {
                    it.reachabilityStatus == com.example.p2p.discovery.registry.ReachabilityStatus.REACHABLE
                } ?: 0
                _networkMetrics.value = _networkMetrics.value.copy(
                    isConnected = serviceRunning || activePeers > 0,
                    isSimulatedDemo = false
                )
            }
        }
    }

    private fun buildRecentActivities(
        addr: String,
        mempool: List<MempoolTransactionRecord>,
        confirmed: List<com.example.transaction.storage.ConfirmedTransactionEntry>
    ): List<RecentActivityItem> {
        val seenIds = HashSet<String>()
        val items = mutableListOf<RecentActivityItem>()

        for (entry in confirmed) {
            val tx = entry.transaction
            if (!seenIds.add(tx.txId)) continue
            val isCredit = addr.isNotEmpty() && tx.recipientAddress == addr && tx.senderAddress != addr
            val amountStr = "${if (isCredit) "+" else "-"}${NmdAmountCodec.formatUnitsToNmd(tx.amountUnits)} NMD"
            items.add(
                RecentActivityItem(
                    id = tx.txId,
                    titleRes = if (isCredit) R.string.activity_received_friend else R.string.activity_sent_wallet,
                    amountFormatted = amountStr,
                    isCredit = isCredit,
                    timeRes = R.string.history_status_confirmed,
                    type = if (isCredit) ActivityType.RECEIVE else ActivityType.SEND
                )
            )
        }

        for (rec in mempool) {
            val tx = rec.transaction
            if (addr.isNotEmpty() && tx.senderAddress != addr && tx.recipientAddress != addr) continue
            if (!seenIds.add(tx.txId)) continue
            val isCredit = addr.isNotEmpty() && tx.recipientAddress == addr && tx.senderAddress != addr
            val amountStr = "${if (isCredit) "+" else "-"}${NmdAmountCodec.formatUnitsToNmd(tx.amountUnits)} NMD"
            items.add(
                RecentActivityItem(
                    id = tx.txId,
                    titleRes = if (isCredit) R.string.activity_received_friend else R.string.activity_sent_wallet,
                    amountFormatted = amountStr,
                    isCredit = isCredit,
                    timeRes = when (rec.status) {
                        MempoolTxStatus.CONFIRMED -> R.string.history_status_confirmed
                        MempoolTxStatus.REJECTED, MempoolTxStatus.EXPIRED -> R.string.history_status_failed
                        else -> R.string.history_status_pending
                    },
                    type = if (isCredit) ActivityType.RECEIVE else ActivityType.SEND
                )
            )
        }

        return items.take(5)
    }
}

