package com.example.ui.screens.wallet

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.crypto.model.KeyStorageSecurityStatus
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextMutedDark
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun WalletSecuritySection(
    onBackToOverview: () -> Unit,
    modifier: Modifier = Modifier,
    keyStorageStatus: KeyStorageSecurityStatus? = null,
    isIdentityReady: Boolean = false,
    signedSenderAddress: String? = null,
    backupRecoveryWords: List<String>? = null,
    exportedKeystoreJson: String? = null,
    backupStatusMessage: String? = null,
    onInitializeIdentity: () -> Unit = {},
    onViewRecoveryWords: () -> Unit = {},
    onClearRecoveryWords: () -> Unit = {},
    onExportKeystore: (String) -> Unit = {},
    onClearExportedKeystore: () -> Unit = {},
    onRestoreFromKeystore: (String, String) -> Unit = { _, _ -> },
    onRestoreFromPhrase: (String) -> Unit = {},
    onClearStatusMessage: () -> Unit = {}
) {
    val clipboardManager = LocalClipboardManager.current
    var showExportPassphraseDialog by remember { mutableStateOf(false) }
    var exportPassphrase by remember { mutableStateOf("") }
    var restorePayloadInput by remember { mutableStateOf("") }
    var restorePassphraseInput by remember { mutableStateOf("") }

    if (showExportPassphraseDialog) {
        AlertDialog(
            onDismissRequest = {
                showExportPassphraseDialog = false
                exportPassphrase = ""
            },
            containerColor = NmdDarkCard,
            title = {
                Text(
                    text = stringResource(R.string.stage19_btn_export_keystore),
                    color = NmdTextPrimaryDark,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.stage19_backup_desc),
                        color = NmdTextSecondaryDark,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = exportPassphrase,
                        onValueChange = { exportPassphrase = it },
                        placeholder = {
                            Text(
                                text = stringResource(R.string.stage19_passphrase_hint),
                                color = NmdTextMutedDark,
                                fontSize = 12.sp
                            )
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = NmdElectricCyan,
                            unfocusedBorderColor = NmdDarkCardBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_export_keystore_passphrase")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onExportKeystore(exportPassphrase)
                        showExportPassphraseDialog = false
                        exportPassphrase = ""
                    },
                    enabled = exportPassphrase.length >= 8,
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue),
                    modifier = Modifier.testTag("btn_confirm_export_keystore")
                ) {
                    Text(stringResource(R.string.stage19_btn_export_keystore), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showExportPassphraseDialog = false
                        exportPassphrase = ""
                    }
                ) {
                    Text(stringResource(R.string.dialog_close), color = NmdTextSecondaryDark)
                }
            }
        )
    }

    if (backupRecoveryWords != null) {
        val joinedWords = backupRecoveryWords.joinToString(" ")
        AlertDialog(
            onDismissRequest = onClearRecoveryWords,
            containerColor = NmdDarkCard,
            title = {
                Text(
                    text = stringResource(R.string.stage19_btn_show_phrase),
                    color = NmdTextPrimaryDark,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = backupRecoveryWords.mapIndexed { idx, w -> "${idx + 1}. $w" }.joinToString("   "),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = NmdCyanBright,
                        lineHeight = 19.sp
                    )
                    Text(
                        text = stringResource(R.string.security_phrase_rule_1),
                        fontSize = 11.sp,
                        color = NmdWarningOrange
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(joinedWords))
                        onClearRecoveryWords()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.wallet_copy_address), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = onClearRecoveryWords) {
                    Text(stringResource(R.string.dialog_close), color = NmdTextSecondaryDark)
                }
            }
        )
    }

    if (exportedKeystoreJson != null) {
        AlertDialog(
            onDismissRequest = onClearExportedKeystore,
            containerColor = NmdDarkCard,
            title = {
                Text(
                    text = stringResource(R.string.stage19_btn_export_keystore),
                    color = NmdTextPrimaryDark,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = exportedKeystoreJson,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = NmdCyanBright,
                    lineHeight = 15.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(exportedKeystoreJson))
                        onClearExportedKeystore()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.wallet_copy_address), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = onClearExportedKeystore) {
                    Text(stringResource(R.string.dialog_close), color = NmdTextSecondaryDark)
                }
            }
        )
    }

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToOverview,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F1A30))
                    .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(10.dp))
                    .testTag("security_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Overview",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = stringResource(R.string.stage19_security_screen_title),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )
                Text(
                    text = signedSenderAddress?.let { "${it.take(12)}...${it.takeLast(6)}" }
                        ?: stringResource(R.string.stage19_no_identity_prompt),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NmdElectricCyan,
                        fontSize = 11.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Non-Custodial KeyStore Status Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        listOf(Color(0x6600D2FF), Color(0x220077FE), NmdDarkCardBorder)
                    ),
                    shape = RoundedCornerShape(20.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0x2200D2FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.security_card_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = stringResource(R.string.stage19_security_card_desc),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = NmdTextSecondaryDark,
                        lineHeight = 20.sp
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                val (statusLabelRes, statusColor) = when (keyStorageStatus) {
                    KeyStorageSecurityStatus.HARDWARE_BACKED_KEYSTORE ->
                        R.string.stage19_keystore_hw_backed to NmdSuccessGreen
                    KeyStorageSecurityStatus.SOFTWARE_BACKED_KEYSTORE,
                    KeyStorageSecurityStatus.ENCRYPTED_STORAGE ->
                        R.string.stage19_keystore_sw_backed to NmdElectricCyan
                    null ->
                        R.string.stage19_keystore_uninitialized to NmdWarningOrange
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = statusColor.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = stringResource(statusLabelRes),
                        color = statusColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                if (!isIdentityReady) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onInitializeIdentity,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("btn_security_init_identity"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.stage19_receive_init_identity),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Key Backup & Restore Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = NmdElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.stage19_backup_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Text(
                    text = stringResource(R.string.stage19_backup_desc),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NmdTextSecondaryDark,
                        lineHeight = 17.sp
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onViewRecoveryWords,
                        enabled = isIdentityReady,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("btn_security_show_phrase"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, NmdElectricCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = NmdElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.stage19_btn_show_phrase),
                            color = NmdElectricCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = { showExportPassphraseDialog = true },
                        enabled = isIdentityReady,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("btn_security_export_keystore"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.stage19_btn_export_keystore),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                OutlinedTextField(
                    value = restorePayloadInput,
                    onValueChange = { restorePayloadInput = it },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.stage19_restore_input_hint),
                            color = NmdTextMutedDark,
                            fontSize = 11.sp
                        )
                    },
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0C1628),
                        unfocusedContainerColor = Color(0xFF0C1628),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_security_restore_payload")
                )

                OutlinedTextField(
                    value = restorePassphraseInput,
                    onValueChange = { restorePassphraseInput = it },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.stage19_passphrase_hint),
                            color = NmdTextMutedDark,
                            fontSize = 11.sp
                        )
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0C1628),
                        unfocusedContainerColor = Color(0xFF0C1628),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = NmdElectricCyan,
                        unfocusedBorderColor = NmdDarkCardBorder
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_security_restore_passphrase")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onRestoreFromPhrase(restorePayloadInput) },
                        enabled = restorePayloadInput.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("btn_security_restore_phrase"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, NmdCyanBright)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Restore,
                            contentDescription = null,
                            tint = NmdCyanBright,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.stage19_btn_restore_phrase),
                            color = NmdCyanBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = { onRestoreFromKeystore(restorePayloadInput, restorePassphraseInput) },
                        enabled = restorePayloadInput.isNotBlank() && restorePassphraseInput.length >= 8,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("btn_security_restore_keystore"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NmdElectricBlue)
                    ) {
                        Text(
                            text = stringResource(R.string.stage19_btn_restore_keystore),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (!backupStatusMessage.isNullOrBlank()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x1F00D2FF))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = backupStatusMessage,
                            color = NmdCyanBright,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onClearStatusMessage) {
                            Text(stringResource(R.string.dialog_close), color = NmdElectricCyan, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Recovery Phrase Safety Guidelines Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = NmdDarkCard),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = NmdWarningOrange,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.security_phrase_rule_title),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NmdTextPrimaryDark
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                SecurityBulletItem(text = stringResource(R.string.security_phrase_rule_1))
                Spacer(modifier = Modifier.height(8.dp))
                SecurityBulletItem(text = stringResource(R.string.security_phrase_rule_2))
                Spacer(modifier = Modifier.height(8.dp))
                SecurityBulletItem(text = stringResource(R.string.security_phrase_rule_3))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Transparent Implementation Status Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NmdDarkCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1628)),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = stringResource(R.string.security_status_title),
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                StatusFeatureRow(
                    isActive = true,
                    text = stringResource(R.string.security_impl_active_1)
                )
                Spacer(modifier = Modifier.height(8.dp))
                StatusFeatureRow(
                    isActive = true,
                    text = stringResource(R.string.security_impl_active_2)
                )
                Spacer(modifier = Modifier.height(8.dp))
                StatusFeatureRow(
                    isActive = true,
                    text = stringResource(R.string.security_impl_active_3)
                )
                Spacer(modifier = Modifier.height(8.dp))
                StatusFeatureRow(
                    isActive = true,
                    text = stringResource(R.string.stage19_backup_title)
                )
                Spacer(modifier = Modifier.height(8.dp))
                StatusFeatureRow(
                    isActive = false,
                    text = stringResource(R.string.security_impl_planned_3)
                )
            }
        }
    }
}

@Composable
fun SecurityBulletItem(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .padding(top = 4.dp)
                .size(6.dp)
                .clip(CircleShape)
                .background(NmdElectricCyan)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(
                color = NmdTextSecondaryDark,
                lineHeight = 18.sp
            )
        )
    }
}

@Composable
fun StatusFeatureRow(isActive: Boolean, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isActive) Icons.Default.CheckCircle else Icons.Default.HourglassEmpty,
            contentDescription = null,
            tint = if (isActive) NmdSuccessGreen else NmdWarningOrange,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(
                color = if (isActive) NmdTextPrimaryDark else NmdTextSecondaryDark,
                fontSize = 11.sp
            )
        )
    }
}
