package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppLanguage
import com.example.data.LocalAppLanguage
import com.example.data.WalletViewMode
import com.example.data.createLocalizedContext
import com.example.ui.components.LanguageSelectionDialog
import com.example.ui.components.NmdBottomNavBar
import com.example.ui.components.NmdTopBar
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HomeViewModel
import com.example.ui.screens.NetworkScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.NmdDarkBackground

@Composable
fun NmdApp(
    modifier: Modifier = Modifier
) {
    var currentScreen by remember { mutableStateOf(NavScreen.Home) }
    var currentLanguage by remember { mutableStateOf(AppLanguage.ARABIC) }
    var walletInitialMode by remember { mutableStateOf(WalletViewMode.OVERVIEW) }

    var showLanguageDialog by remember { mutableStateOf(false) }

    val homeViewModel: HomeViewModel = viewModel()
    val networkMetrics by homeViewModel.networkMetrics.collectAsState()
    val baseContext = LocalContext.current

    LaunchedEffect(baseContext) {
        homeViewModel.attachContext(baseContext)
    }

    if (currentScreen != NavScreen.Home) {
        BackHandler {
            currentScreen = NavScreen.Home
        }
    }

    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguage = currentLanguage,
            onSelectLanguage = { selected ->
                currentLanguage = selected
            },
            onDismiss = { showLanguageDialog = false }
        )
    }

    val localizedContext = remember(currentLanguage, baseContext) {
        baseContext.createLocalizedContext(currentLanguage)
    }

    CompositionLocalProvider(
        LocalAppLanguage provides currentLanguage,
        LocalLayoutDirection provides currentLanguage.layoutDirection,
        LocalConfiguration provides localizedContext.resources.configuration,
        LocalContext provides localizedContext
    ) {
        Scaffold(
            modifier = modifier
                .fillMaxSize()
                .background(NmdDarkBackground),
            containerColor = NmdDarkBackground,
            topBar = {
                NmdTopBar(
                    onLanguageClick = { showLanguageDialog = true },
                    onNotificationClick = { currentScreen = NavScreen.Network },
                    isConnected = networkMetrics.isConnected
                )
            },
            bottomBar = {
                NmdBottomNavBar(
                    currentScreen = currentScreen,
                    onNavigate = { screen ->
                        if (screen == NavScreen.Wallet) {
                            walletInitialMode = WalletViewMode.OVERVIEW
                        }
                        currentScreen = screen
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(
                    targetState = currentScreen,
                    animationSpec = tween(durationMillis = 200),
                    label = "screen_crossfade"
                ) { screen ->
                    when (screen) {
                        NavScreen.Home -> {
                            HomeScreen(
                                viewModel = homeViewModel,
                                onNavigateToSend = {
                                    walletInitialMode = WalletViewMode.SEND
                                    currentScreen = NavScreen.Wallet
                                },
                                onNavigateToReceive = {
                                    walletInitialMode = WalletViewMode.RECEIVE
                                    currentScreen = NavScreen.Wallet
                                },
                                onNavigateToSecurity = {
                                    walletInitialMode = WalletViewMode.SECURITY
                                    currentScreen = NavScreen.Wallet
                                },
                                onNavigateToNetwork = {
                                    currentScreen = NavScreen.Network
                                },
                                onViewAllActivities = {
                                    walletInitialMode = WalletViewMode.HISTORY
                                    currentScreen = NavScreen.Wallet
                                }
                            )
                        }

                        NavScreen.Wallet -> {
                            WalletScreen(
                                initialMode = walletInitialMode,
                                onBack = { currentScreen = NavScreen.Home }
                            )
                        }

                        NavScreen.Network -> {
                            NetworkScreen(
                                onBack = { currentScreen = NavScreen.Home }
                            )
                        }

                        NavScreen.Discover -> {
                            DiscoverScreen(
                                onBack = { currentScreen = NavScreen.Home }
                            )
                        }

                        NavScreen.Profile -> {
                            ProfileScreen(
                                currentLanguage = currentLanguage,
                                onLanguageChange = { selected ->
                                    currentLanguage = selected
                                },
                                onNavigateToSecurity = {
                                    walletInitialMode = WalletViewMode.SECURITY
                                    currentScreen = NavScreen.Wallet
                                },
                                onNavigateToNetwork = {
                                    currentScreen = NavScreen.Network
                                },
                                onBack = { currentScreen = NavScreen.Home }
                            )
                        }
                    }
                }
            }
        }
    }
}
