package com.example.ui.components.qr

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color

/**
 * Visual QR Code Prototype Generator for Stage 2 UI Demonstration.
 *
 * Implements a 29x29 matrix (Model 2 Version 3 dimensions) with standard layout
 * elements (finder patterns, separators, timing tracks, and alignment pattern)
 * to provide a realistic visual QR code for demo address rendering.
 *
 * CRITICAL TRANSPARENCY NOTICE:
 * This component is designed and labeled strictly as a visual UI prototype.
 * Full end-to-end optical hardware scanner decodability across arbitrary physical devices
 * is not guaranteed in this build and should not be claimed as certified standards-compliant
 * until dedicated camera integration is completed in later stages.
 */
object QrCodeGenerator {

    private const val VERSION = 3
    const val MATRIX_SIZE = 29 // 4 * version + 17 = 29
    private const val TOTAL_CODEWORDS = 70
    private const val DATA_CODEWORDS = 55
    private const val EC_CODEWORDS = 15

    // GF(256) tables with primitive polynomial 0x11D
    private val expTable = IntArray(512)
    private val logTable = IntArray(256)

    init {
        var value = 1
        for (i in 0 until 255) {
            expTable[i] = value
            expTable[i + 255] = value
            logTable[value] = i
            value = value shl 1
            if (value >= 256) {
                value = value xor 0x11D
            }
        }
    }

    private fun gfMul(x: Int, y: Int): Int {
        if (x == 0 || y == 0) return 0
        return expTable[logTable[x] + logTable[y]]
    }

    // Generator polynomial coefficients for degree 15
    private val generatorPolynomial = intArrayOf(
        26, 134, 32, 151, 132, 139, 105, 105, 10, 74, 112, 163, 111, 196, 29, 1
    )

    fun encode(text: String): Array<BooleanArray> {
        val rawBytes = text.toByteArray(Charsets.ISO_8859_1)
        val dataBytes = IntArray(DATA_CODEWORDS)

        // Bit stream construction: Mode (4 bits: 0100 for Byte) + Count (8 bits) + Data + Terminator
        val bitBuffer = mutableListOf<Int>()

        fun appendBits(value: Int, count: Int) {
            for (i in count - 1 downTo 0) {
                bitBuffer.add((value ushr i) and 1)
            }
        }

        // Byte mode indicator: 0100
        appendBits(4, 4)
        // Character count indicator: 8 bits for version 1-9
        val byteLength = minOf(rawBytes.size, DATA_CODEWORDS - 2)
        appendBits(byteLength, 8)

        // Text data bits
        for (i in 0 until byteLength) {
            appendBits(rawBytes[i].toInt() and 0xFF, 8)
        }

        // Terminator: up to 4 zero bits
        val terminatorCount = minOf(4, (DATA_CODEWORDS * 8) - bitBuffer.size)
        appendBits(0, terminatorCount)

        // Pad to byte boundary
        while (bitBuffer.size % 8 != 0) {
            bitBuffer.add(0)
        }

        // Convert bits to data codewords
        var byteIndex = 0
        var currentByte = 0
        for (i in bitBuffer.indices) {
            currentByte = (currentByte shl 1) or bitBuffer[i]
            if ((i + 1) % 8 == 0) {
                dataBytes[byteIndex++] = currentByte
                currentByte = 0
                if (byteIndex >= DATA_CODEWORDS) break
            }
        }

        // Pad alternating bytes: 0xEC (236) and 0x11 (17)
        var padByte = 236
        while (byteIndex < DATA_CODEWORDS) {
            dataBytes[byteIndex++] = padByte
            padByte = if (padByte == 236) 17 else 236
        }

        // Calculate Reed-Solomon Error Correction Codewords
        val ecCodewords = IntArray(EC_CODEWORDS)
        for (dataWord in dataBytes) {
            val factor = dataWord xor ecCodewords[0]
            System.arraycopy(ecCodewords, 1, ecCodewords, 0, EC_CODEWORDS - 1)
            ecCodewords[EC_CODEWORDS - 1] = 0
            for (j in 0 until EC_CODEWORDS) {
                ecCodewords[j] = ecCodewords[j] xor gfMul(generatorPolynomial[EC_CODEWORDS - 1 - j], factor)
            }
        }

        // Interleave / Combine data and EC into total codewords
        val allCodewords = IntArray(TOTAL_CODEWORDS)
        System.arraycopy(dataBytes, 0, allCodewords, 0, DATA_CODEWORDS)
        System.arraycopy(ecCodewords, 0, allCodewords, DATA_CODEWORDS, EC_CODEWORDS)

        // Build 29x29 Matrix
        val matrix = Array(MATRIX_SIZE) { BooleanArray(MATRIX_SIZE) }
        val isFunction = Array(MATRIX_SIZE) { BooleanArray(MATRIX_SIZE) }

        fun setFunctionModule(r: Int, c: Int, isDark: Boolean) {
            if (r in 0 until MATRIX_SIZE && c in 0 until MATRIX_SIZE) {
                matrix[r][c] = isDark
                isFunction[r][c] = true
            }
        }

        fun drawFinderPattern(rowStart: Int, colStart: Int) {
            for (r in 0..6) {
                for (c in 0..6) {
                    val isDark = (r == 0 || r == 6 || c == 0 || c == 6 || (r in 2..4 && c in 2..4))
                    setFunctionModule(rowStart + r, colStart + c, isDark)
                }
            }
            // Separator line surrounding finder pattern
            for (r in -1..7) {
                for (c in -1..7) {
                    if (r == -1 || r == 7 || c == -1 || c == 7) {
                        setFunctionModule(rowStart + r, colStart + c, false)
                    }
                }
            }
        }

        // Place 3 Finder Patterns
        drawFinderPattern(0, 0)
        drawFinderPattern(0, MATRIX_SIZE - 7)
        drawFinderPattern(MATRIX_SIZE - 7, 0)

        // Place Alignment Pattern for Version 3 at center (22, 22)
        val alignCenter = 22
        for (r in -2..2) {
            for (c in -2..2) {
                val isDark = (r == -2 || r == 2 || c == -2 || c == 2 || (r == 0 && c == 0))
                setFunctionModule(alignCenter + r, alignCenter + c, isDark)
            }
        }

        // Timing Patterns (Row 6 and Column 6)
        for (i in 8 until MATRIX_SIZE - 8) {
            val isDark = (i % 2 == 0)
            setFunctionModule(6, i, isDark)
            setFunctionModule(i, 6, isDark)
        }

        // Dark module for Version 3: at (4 * 3 + 9, 8) = (21, 8)
        setFunctionModule(4 * VERSION + 9, 8, true)

        // Format information (15 bits for ECC Level L and Mask 0: 0x77C4)
        val formatBits = 0x77C4 // 111011111000100
        for (i in 0..14) {
            val bit = ((formatBits ushr (14 - i)) and 1) == 1
            // Top-left
            if (i <= 5) setFunctionModule(8, i, bit)
            else if (i == 6) setFunctionModule(8, 7, bit)
            else if (i == 7) setFunctionModule(8, 8, bit)
            else if (i == 8) setFunctionModule(7, 8, bit)
            else setFunctionModule(14 - i, 8, bit)

            // Right & Bottom mirrors
            if (i < 8) {
                setFunctionModule(8, MATRIX_SIZE - 1 - i, bit)
            } else {
                setFunctionModule(MATRIX_SIZE - 15 + i, 8, bit)
            }
        }

        // Layout Data Bits into available matrix coordinates (2-column zigzag right-to-left)
        val allBits = mutableListOf<Boolean>()
        for (word in allCodewords) {
            for (b in 7 downTo 0) {
                allBits.add(((word ushr b) and 1) == 1)
            }
        }

        var bitPtr = 0
        var upward = true
        var rightCol = MATRIX_SIZE - 1

        while (rightCol > 0) {
            if (rightCol == 6) rightCol-- // Skip timing column 6

            val rowRange = if (upward) (MATRIX_SIZE - 1 downTo 0) else (0 until MATRIX_SIZE)
            for (row in rowRange) {
                for (colOffset in 0..1) {
                    val col = rightCol - colOffset
                    if (!isFunction[row][col]) {
                        val bit = if (bitPtr < allBits.size) allBits[bitPtr++] else false
                        // Apply Mask Pattern 0: (row + col) % 2 == 0
                        val isMasked = (row + col) % 2 == 0
                        matrix[row][col] = bit xor isMasked
                    }
                }
            }
            upward = !upward
            rightCol -= 2
        }

        return matrix
    }
}

@Composable
fun NmdQrCodeView(
    text: String,
    modifier: Modifier = Modifier,
    darkColor: Color = Color(0xFF070B16),
    lightColor: Color = Color.White
) {
    val matrix = remember(text) { QrCodeGenerator.encode(text) }

    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val matrixDim = matrix.size
            val modulePixel = size.minDimension / matrixDim
            val offsetX = (size.width - (modulePixel * matrixDim)) / 2f
            val offsetY = (size.height - (modulePixel * matrixDim)) / 2f

            // Fill light background
            drawRect(
                color = lightColor,
                topLeft = Offset.Zero,
                size = size
            )

            // Draw dark modules
            for (r in 0 until matrixDim) {
                for (c in 0 until matrixDim) {
                    if (matrix[r][c]) {
                        drawRect(
                            color = darkColor,
                            topLeft = Offset(offsetX + c * modulePixel, offsetY + r * modulePixel),
                            size = Size(modulePixel + 0.5f, modulePixel + 0.5f) // avoid fractional anti-aliasing gaps
                        )
                    }
                }
            }
        }
    }
}
