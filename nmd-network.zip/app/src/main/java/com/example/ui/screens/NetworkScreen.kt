package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.NetworkTab
import com.example.ui.screens.network.DeleteIdentityDialog
import com.example.ui.screens.network.DeviceTelemetrySection
import com.example.ui.screens.network.NetworkActivitySection
import com.example.ui.screens.network.NetworkDashboardSection
import com.example.ui.screens.network.NodeConfigDialog
import com.example.ui.screens.network.NodeIdentitySection
import com.example.ui.screens.network.NodeRolesSection
import com.example.ui.screens.network.PeerManagementSection
import com.example.ui.screens.network.PublicIdentityDialog
import com.example.ui.screens.network.SignMessageTestDialog
import com.example.ui.theme.NmdCyanBright
import com.example.ui.theme.NmdDarkCard
import com.example.ui.theme.NmdDarkCardBorder
import com.example.ui.theme.NmdElectricBlue
import com.example.ui.theme.NmdElectricCyan
import com.example.ui.theme.NmdSuccessGreen
import com.example.ui.theme.NmdTextPrimaryDark
import com.example.ui.theme.NmdTextSecondaryDark
import com.example.ui.theme.NmdWarningOrange

@Composable
fun NetworkScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: NetworkViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val nodeConfig by viewModel.nodeConfig.collectAsState()
    val deviceTelemetry by viewModel.deviceTelemetry.collectAsState()
    val networkTelemetry by viewModel.networkTelemetry.collectAsState()
    val showConfigDialog by viewModel.showConfigDialog.collectAsState()
    val peerSearchQuery by viewModel.peerSearchQuery.collectAsState()
    val peerRoleFilter by viewModel.peerRoleFilter.collectAsState()
    val peers by viewModel.peers.collectAsState()
    val networkActivities by viewModel.networkActivities.collectAsState()

    // Stage 4 Cryptographic State
    val nodeIdentity by viewModel.nodeIdentity.collectAsState()
    val selfVerificationStatus by viewModel.selfVerificationStatus.collectAsState()
    val lastSignedMessage by viewModel.lastSignedMessage.collectAsState()
    val lastVerificationResult by viewModel.lastVerificationResult.collectAsState()
    val showPublicIdentityDialog by viewModel.showPublicIdentityDialog.collectAsState()
    val showSignMessageDialog by viewModel.showSignMessageDialog.collectAsState()
    val showDeleteIdentityDialog by viewModel.showDeleteIdentityDialog.collectAsState()

    // Stage 5 Real P2P State
    val isP2pListening by viewModel.isP2pListening.collectAsState()
    val p2pBoundPort by viewModel.p2pBoundPort.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()
    val authenticatedRealPeers by viewModel.authenticatedRealPeers.collectAsState()
    val p2pMessageHistory by viewModel.p2pMessageHistory.collectAsState()
    val showManualConnectDialog by viewModel.showManualConnectDialog.collectAsState()
    val p2pErrorMessage by viewModel.p2pErrorMessage.collectAsState()

    // Stage 6 Reliable P2P State
    val activePeerSessions by viewModel.activePeerSessions.collectAsState()
    val reliableMessageLog by viewModel.reliableMessageLog.collectAsState()
    val p2pTestReport by viewModel.p2pTestReport.collectAsState()
    val isTestLabRunning by viewModel.isTestLabRunning.collectAsState()

    // Stage 7 Distributed Peer Discovery State
    val registeredPeers by viewModel.registeredPeers.collectAsState()
    val bootstrapPeers by viewModel.bootstrapPeers.collectAsState()
    val topologyMetrics by viewModel.topologyMetrics.collectAsState()
    val discoveryStatus by viewModel.discoveryStatus.collectAsState()
    val activeDiscoveryMethod by viewModel.activeDiscoveryMethod.collectAsState()
    val lastSuccessfulDiscoveryMs by viewModel.lastSuccessfulDiscoveryMs.collectAsState()
    val selectedRegistryFilter by viewModel.registryFilter.collectAsState()

    // Stage 8 Blockchain Core State
    val chainState by viewModel.chainState.collectAsState()

    // Stage 9 Transaction Mempool State
    val mempoolStats by viewModel.mempoolStats.collectAsState()
    val mempoolTransactions by viewModel.mempoolTransactions.collectAsState()

    // Stage 10 Distributed Consensus State
    val consensusState by viewModel.consensusState.collectAsState()
    val consensusIntegrityReport by viewModel.consensusIntegrityReport.collectAsState()

    // Stage 11 Block Production & Validator Scheduling State
    val productionState by viewModel.productionState.collectAsState()
    val lastProductionAttemptMessage by viewModel.lastProductionAttemptMessage.collectAsState()

    // Stage 12 Blockchain Synchronization State
    val syncState by viewModel.syncState.collectAsState()

    // Stage 13 Transport Security State
    val securityState by viewModel.securityUiState.collectAsState()

    // Stage 14 NAT Traversal & Connectivity Diagnostics State
    val connectivityDiagnostics by viewModel.connectivityDiagnostics.collectAsState()

    // Stage 15 Public Network Infrastructure & Bootstrap State
    val infrastructureSnapshot by viewModel.infrastructureSnapshot.collectAsState()

    // Stage 16 Scalability, Health & Fault Tolerance State
    val scalabilitySnapshot by viewModel.scalabilitySnapshot.collectAsState()

    // Stage 20: Foreground Node Sync Service State & Play-Compliant Permission Launcher
    val context = LocalContext.current
    val isForegroundServiceRunning by viewModel.isForegroundServiceRunning.collectAsState()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.startNodeForegroundService()
    }
    val launchNodeForegroundService = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                viewModel.startNodeForegroundService()
            } else {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            viewModel.startNodeForegroundService()
        }
    }

    // Sub-tab BackHandler: If inside a sub-tab, return to Dashboard; if on Dashboard, exit to Home.
    BackHandler(enabled = true) {
        if (currentTab != NetworkTab.DASHBOARD) {
            viewModel.setTab(NetworkTab.DASHBOARD)
        } else {
            onBack()
        }
    }

    if (showConfigDialog) {
        NodeConfigDialog(
            initialConfig = nodeConfig,
            onSave = viewModel::saveNodeConfiguration,
            onDismiss = viewModel::closeConfigDialog
        )
    }

    if (showPublicIdentityDialog && nodeIdentity != null) {
        PublicIdentityDialog(
            publicJson = viewModel.exportPublicIdentityJson(),
            onDismiss = viewModel::closePublicIdentityDialog
        )
    }

    if (showSignMessageDialog) {
        SignMessageTestDialog(
            lastSignedMessage = lastSignedMessage,
            lastVerificationResult = lastVerificationResult,
            onSign = { type, payload ->
                viewModel.signTestProtocolMessage(type, payload)
            },
            onDismiss = viewModel::closeSignMessageDialog
        )
    }

    if (showDeleteIdentityDialog) {
        DeleteIdentityDialog(
            onConfirm = { viewModel.deleteNodeIdentity() },
            onDismiss = viewModel::closeDeleteIdentityDialog
        )
    }

    if (showManualConnectDialog) {
        com.example.ui.screens.network.ManualConnectDialog(
            onDismiss = viewModel::closeManualConnectDialog,
            onConnect = { host, port, claimedId ->
                viewModel.connectToRealPeer(host, port, claimedId)
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("network_screen_content")
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = {
                    if (currentTab != NetworkTab.DASHBOARD) {
                        viewModel.setTab(NetworkTab.DASHBOARD)
                    } else {
                        onBack()
                    }
                },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NmdDarkCard)
                    .testTag("network_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = stringResource(R.string.nav_network),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = NmdTextPrimaryDark
                    )
                )
                Text(
                    text = "L1 Layer Control Center",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = NmdCyanBright,
                        fontSize = 10.sp
                    )
                )
            }

            IconButton(
                onClick = { viewModel.openConfigDialog() },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NmdDarkCard)
                    .testTag("network_config_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Configure Node",
                    tint = NmdElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Node Status Banner (Reactive to Demo Node Mode)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (nodeConfig.isDemoActive) Color(0xFF0A1E20) else Color(0xFF26190B))
                .border(
                    1.dp,
                    if (nodeConfig.isDemoActive) NmdSuccessGreen else NmdWarningOrange,
                    RoundedCornerShape(16.dp)
                )
                .clickable { viewModel.openConfigDialog() }
                .padding(horizontal = 14.dp, vertical = 12.dp)
                .testTag("node_status_banner"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (nodeConfig.isDemoActive) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (nodeConfig.isDemoActive) NmdSuccessGreen else NmdWarningOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (nodeConfig.isDemoActive) {
                                stringResource(R.string.status_node_ok)
                            } else {
                                stringResource(R.string.node_status_inactive_label)
                            },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (nodeConfig.isDemoActive) NmdSuccessGreen else NmdWarningOrange
                            )
                        )
                        Text(
                            text = "${nodeConfig.displayName} • ${stringResource(nodeConfig.selectedRole.titleRes)}",
                            fontSize = 10.sp,
                            color = NmdTextSecondaryDark
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0x1F00D2FF)
                ) {
                    Text(
                        text = if (networkTelemetry.isDemo) {
                            stringResource(R.string.node_mode_demo_tag)
                        } else {
                            networkTelemetry.networkMode
                        },
                        color = NmdElectricCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Horizontal Segmented Tab Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NetworkTab.entries.forEach { tab ->
                val isSelected = currentTab == tab
                val tabTitleRes = when (tab) {
                    NetworkTab.DASHBOARD -> R.string.tab_network_dashboard
                    NetworkTab.IDENTITY -> R.string.tab_network_identity
                    NetworkTab.ROLES -> R.string.tab_network_roles
                    NetworkTab.PEERS -> R.string.tab_network_peers
                    NetworkTab.REAL_P2P -> R.string.tab_network_real_p2p
                    NetworkTab.ACTIVITY -> R.string.tab_network_activity
                    NetworkTab.DEVICE -> R.string.tab_network_device
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) NmdElectricBlue else Color(0xFF0F1A30))
                        .border(
                            1.dp,
                            if (isSelected) NmdElectricCyan else NmdDarkCardBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { viewModel.setTab(tab) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("tab_network_${tab.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(tabTitleRes),
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else NmdTextSecondaryDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Tab Content
        Crossfade(
            targetState = currentTab,
            animationSpec = tween(durationMillis = 180),
            label = "network_tab_crossfade"
        ) { tab ->
            when (tab) {
                NetworkTab.DASHBOARD -> {
                    NetworkDashboardSection(
                        nodeConfig = nodeConfig,
                        networkTelemetry = networkTelemetry,
                        onConfigureClick = viewModel::openConfigDialog,
                        chainState = chainState,
                        onVerifyChainIntegrity = viewModel::verifyBlockchainIntegrity,
                        mempoolStats = mempoolStats,
                        mempoolTransactions = mempoolTransactions,
                        onBroadcastValidatedTxs = viewModel::broadcastValidatedTransactions,
                        onPruneExpiredTxs = viewModel::pruneExpiredMempoolTransactions,
                        consensusState = consensusState,
                        consensusIntegrityReport = consensusIntegrityReport,
                        onVerifyAndRefreshConsensus = viewModel::verifyAndRefreshConsensus,
                        productionState = productionState,
                        lastProductionAttemptMessage = lastProductionAttemptMessage,
                        onRefreshProductionSlot = viewModel::refreshAndCheckProductionSlot,
                        onAttemptEligibleProposal = viewModel::attemptEligibleBlockProduction,
                        syncState = syncState,
                        onSyncNow = viewModel::triggerBlockchainSync,
                        onToggleSyncPauseResume = viewModel::toggleBlockchainSyncPauseResume,
                        securityState = securityState,
                        onRevokePeer = viewModel::revokePeerIdentity,
                        onUnrevokePeer = viewModel::unrevokePeerIdentity,
                        onRotateSecuritySessions = viewModel::rotateEncryptedSessions,
                        connectivityDiagnostics = connectivityDiagnostics,
                        onRefreshNatConnectivity = viewModel::refreshNatConnectivity,
                        onTriggerIceRestart = viewModel::triggerIceRestart,
                        onConfigureStunTurn = viewModel::configureStunTurnServers,
                        infrastructureSnapshot = infrastructureSnapshot,
                        onBootstrapAndSync = viewModel::bootstrapAndSyncPeers,
                        onProbeBootstrapHealth = viewModel::probeBootstrapEndpointsHealth,
                        onReconnectSignaling = viewModel::reconnectSignalingTransport,
                        onConfigureInfrastructure = viewModel::configureInfrastructureEndpoints,
                        scalabilitySnapshot = scalabilitySnapshot,
                        onRunScalabilitySweep = viewModel::runScalabilitySweep,
                        onResetCircuitBreakers = viewModel::resetAllCircuitBreakers,
                        onSelectResourceMode = viewModel::setDeviceResourceModeOverride,
                        isForegroundServiceRunning = isForegroundServiceRunning,
                        onStartForegroundService = launchNodeForegroundService,
                        onStopForegroundService = viewModel::stopNodeForegroundService,
                        onRegisterValidator = { viewModel.submitValidatorRegistration(1L) },
                        onExitValidator = viewModel::submitValidatorExit
                    )
                }
                NetworkTab.IDENTITY -> {
                    NodeIdentitySection(
                        nodeIdentity = nodeIdentity,
                        selfVerificationStatus = selfVerificationStatus,
                        onGenerateIdentity = viewModel::generateNodeIdentity,
                        onVerifySelfIdentity = viewModel::verifySelfIdentity,
                        onViewPublicIdentity = viewModel::openPublicIdentityDialog,
                        onSignTestMessage = viewModel::openSignMessageDialog,
                        onDeleteIdentity = viewModel::openDeleteIdentityDialog
                    )
                }
                NetworkTab.ROLES -> {
                    NodeRolesSection(
                        nodeConfig = nodeConfig,
                        onConfigureRole = { role ->
                            viewModel.selectRoleQuickAction(role)
                            viewModel.openConfigDialog()
                        }
                    )
                }
                NetworkTab.PEERS -> {
                    PeerManagementSection(
                        peers = peers,
                        searchQuery = peerSearchQuery,
                        selectedRoleFilter = peerRoleFilter,
                        onSearchChange = viewModel::setPeerSearchQuery,
                        onRoleFilterChange = viewModel::setPeerRoleFilter
                    )
                }
                NetworkTab.REAL_P2P -> {
                    com.example.ui.screens.network.RealP2pSection(
                        isListening = isP2pListening,
                        boundPort = p2pBoundPort,
                        localIp = viewModel.getLocalIpAddress(),
                        discoveredPeers = discoveredPeers,
                        authenticatedPeers = authenticatedRealPeers,
                        messageHistory = p2pMessageHistory,
                        errorMessage = p2pErrorMessage,
                        onToggleListening = viewModel::toggleP2pListening,
                        onConnectToPeer = viewModel::connectToRealPeer,
                        onDisconnectPeer = viewModel::disconnectRealPeer,
                        onSendSignedMessage = viewModel::sendSignedProtocolMessageToPeer,
                        onOpenManualConnectDialog = viewModel::openManualConnectDialog,
                        onClearErrorMessage = viewModel::clearP2pErrorMessage,
                        // Stage 6 reliable messaging additions
                        sessions = activePeerSessions,
                        reliableMessageLog = reliableMessageLog,
                        testReport = p2pTestReport,
                        isTestLabRunning = isTestLabRunning,
                        onSelectSessionForDetail = viewModel::selectSessionForDetail,
                        onSendReliableMessage = viewModel::sendReliableP2pMessage,
                        onSendPing = viewModel::sendPingToSession,
                        onRunTestLabSuite = viewModel::runP2pTestLabSuite,
                        onClearTestReport = viewModel::clearP2pTestReport,
                        // Stage 7 Distributed Peer Discovery
                        topologyMetrics = topologyMetrics,
                        discoveryStatus = discoveryStatus,
                        discoveryMethod = activeDiscoveryMethod,
                        lastSuccessfulDiscoveryMs = lastSuccessfulDiscoveryMs,
                        registeredPeers = registeredPeers,
                        bootstrapPeers = bootstrapPeers,
                        selectedRegistryFilter = selectedRegistryFilter,
                        onSelectRegistryFilter = viewModel::setRegistryFilter,
                        onRefreshDiscovery = viewModel::refreshDistributedDiscovery,
                        onRequestPeerExchange = viewModel::requestPeerExchange,
                        onConnectToRegistryPeer = viewModel::connectToRegistryPeer,
                        onRemoveRegistryPeer = viewModel::removeRegistryPeer,
                        onConnectBootstrapPeer = viewModel::connectBootstrapPeer,
                        onToggleBootstrapPeer = viewModel::toggleBootstrapPeer,
                        onRemoveBootstrapPeer = viewModel::removeBootstrapPeer,
                        onAddCustomBootstrapPeer = viewModel::addCustomBootstrapPeer
                    )
                }
                NetworkTab.ACTIVITY -> {
                    NetworkActivitySection(
                        activities = networkActivities
                    )
                }
                NetworkTab.DEVICE -> {
                    DeviceTelemetrySection(
                        deviceTelemetry = deviceTelemetry,
                        networkTelemetry = networkTelemetry,
                        onRefresh = viewModel::refreshDeviceTelemetry
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
