package com.example.production.engine

import com.example.blockchain.manager.BlockIngestionResult
import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.consensus.model.CommitCertificate
import com.example.production.config.BlockProductionConfig
import com.example.production.model.FinalizedBlockRecord
import com.example.production.model.ProductionCheckpoint
import com.example.production.storage.BlockProductionStorage
import com.example.transaction.blockchain.TransactionBlockBridge
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.MempoolTxStatus

data class FinalizationProcessingOutcome(
    val updatedCheckpoint: ProductionCheckpoint,
    val finalizedRecord: FinalizedBlockRecord?,
    val newlyProcessed: Boolean
)

/**
 * Stage 11 Finalized Block Processor.
 *
 * Strictly executes ONLY after Stage 10 BFT [CommitCertificate] finality:
 * 1. Ensures the canonical finalized Stage 8 [Block] matching `certificate.blockHash` is atomically
 *    persisted in [BlockchainManager] (recovering from persisted candidate storage if not yet committed).
 * 2. Idempotently confirms all included Stage 9 transactions via [TransactionBlockBridge.onBlockCommitted],
 *    advancing `confirmedNextNonce` and removing confirmed entries from the active pending pool.
 * 3. Prunes expired transactions in [TransactionMempool].
 * 4. Atomically persists [ProductionCheckpoint] advancement and cleans up superseded candidate slots.
 */
class FinalizedBlockProcessor(
    private val config: BlockProductionConfig,
    private val storage: BlockProductionStorage,
    private val blockchainManager: BlockchainManager,
    private val txMempool: TransactionMempool,
    private val txBlockBridge: TransactionBlockBridge,
    private val consensusEngine: com.example.consensus.engine.ConsensusEngine? = null
) {

    suspend fun processFinalizedCertificate(
        certificate: CommitCertificate,
        currentCheckpoint: ProductionCheckpoint,
        fallbackCandidateBlock: Block? = null,
        nowMs: Long = System.currentTimeMillis()
    ): FinalizationProcessingOutcome {
        if (certificate.chainId != config.chainId) {
            return FinalizationProcessingOutcome(
                updatedCheckpoint = currentCheckpoint,
                finalizedRecord = null,
                newlyProcessed = false
            )
        }

        // Resolve or persist the canonical Stage 8 block matching certificate.blockHash
        var committedBlock = blockchainManager.getBlockByHeight(certificate.blockHeight)
        if (committedBlock == null) {
            val candidate = fallbackCandidateBlock?.takeIf {
                it.height == certificate.blockHeight && it.hash.equals(certificate.blockHash, ignoreCase = true)
            } ?: storage.getCandidateBlock(config.chainId, certificate.blockHeight, certificate.round)?.takeIf {
                it.hash.equals(certificate.blockHash, ignoreCase = true)
            } ?: storage.getCandidateBlockByHash(config.chainId, certificate.blockHash)?.takeIf {
                it.height == certificate.blockHeight
            }

            if (candidate != null) {
                when (val ingestRes = blockchainManager.submitIncomingBlock(candidate, nowMs = nowMs)) {
                    is BlockIngestionResult.Accepted -> committedBlock = ingestRes.block
                    is BlockIngestionResult.Duplicate -> committedBlock = blockchainManager.getBlockByHeight(certificate.blockHeight)
                    else -> Unit
                }
            }
        }

        // Confirm Stage 9 transactions idempotently AND execute deterministic LedgerState transitions
        var confirmedTxCount = 0
        if (committedBlock != null && committedBlock.hash.equals(certificate.blockHash, ignoreCase = true)) {
            val refs = committedBlock.body.transactionRefs
            if (refs.isNotEmpty()) {
                val resolvedTxs = refs.mapNotNull { txMempool.getConfirmedOrActiveTransaction(it.txHash) }
                val hasUnconfirmed = refs.any { ref ->
                    val rec = txMempool.getByTxId(ref.txHash)
                    rec != null && rec.status != MempoolTxStatus.CONFIRMED
                }
                if (hasUnconfirmed) {
                    txBlockBridge.onBlockCommitted(committedBlock)
                }
                confirmedTxCount = refs.count { ref ->
                    txMempool.getByTxId(ref.txHash)?.status == MempoolTxStatus.CONFIRMED
                }
                if (resolvedTxs.isNotEmpty()) {
                    val ledger = txMempool.ledgerStateEngine
                    val transition = ledger?.applyFinalizedBlock(
                        transactions = resolvedTxs,
                        blockHeight = committedBlock.height,
                        parameters = blockchainManager.config.parameters,
                        nowMs = committedBlock.timestamp
                    )
                    if (transition != null && consensusEngine != null) {
                        for (reg in transition.validatorRegistrations) {
                            consensusEngine.registerAuthorizedValidator(
                                publicKeyHex = reg.publicKeyHex,
                                displayName = reg.displayName,
                                votingPower = reg.votingPower
                            )
                        }
                        for (exit in transition.validatorExits) {
                            val valId = consensusEngine.signer.deriveValidatorIdFromHex(exit.publicKeyHex)
                            if (valId != null) {
                                consensusEngine.retireValidator(valId)
                            }
                        }
                    }
                }
            }
        }

        // Clean expired transactions deterministically after block finality
        txMempool.pruneExpired(nowMs)

        // Idempotent guard: never double-count checkpoint metrics for already-processed height
        if (certificate.blockHeight <= currentCheckpoint.lastFinalizedHeight) {
            return FinalizationProcessingOutcome(
                updatedCheckpoint = currentCheckpoint,
                finalizedRecord = null,
                newlyProcessed = false
            )
        }

        val updatedCheckpoint = currentCheckpoint.copy(
            lastFinalizedHeight = certificate.blockHeight,
            lastFinalizedHash = certificate.blockHash.lowercase(),
            blocksFinalizedCount = currentCheckpoint.blocksFinalizedCount + 1L,
            updatedAtMs = nowMs
        )
        storage.finalizeSlotAtomically(updatedCheckpoint, certificate.blockHeight)

        val record = FinalizedBlockRecord(
            certificate = certificate,
            finalizedBlock = committedBlock,
            confirmedTxCount = confirmedTxCount,
            finalizedAtMs = nowMs
        )

        return FinalizationProcessingOutcome(
            updatedCheckpoint = updatedCheckpoint,
            finalizedRecord = record,
            newlyProcessed = true
        )
    }
}
