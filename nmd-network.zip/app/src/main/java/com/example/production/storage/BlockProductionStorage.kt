package com.example.production.storage

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import com.example.blockchain.model.Block
import com.example.production.model.ProductionCheckpoint
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable

@Entity(tableName = "production_checkpoints")
data class ProductionCheckpointEntity(
    @PrimaryKey val chainId: String,
    val lastFinalizedHeight: Long,
    val lastFinalizedHash: String,
    val lastProposedHeight: Long,
    val lastProposedRound: Int,
    val lastProposedBlockHash: String?,
    val lastProducedAtMs: Long,
    val missedProposalCount: Long,
    val failureCount: Long,
    val blocksProposedCount: Long,
    val blocksFinalizedCount: Long,
    val updatedAtMs: Long
) {
    fun toDomain() = ProductionCheckpoint(
        chainId = chainId,
        lastFinalizedHeight = lastFinalizedHeight,
        lastFinalizedHash = lastFinalizedHash,
        lastProposedHeight = lastProposedHeight,
        lastProposedRound = lastProposedRound,
        lastProposedBlockHash = lastProposedBlockHash,
        lastProducedAtMs = lastProducedAtMs,
        missedProposalCount = missedProposalCount,
        failureCount = failureCount,
        blocksProposedCount = blocksProposedCount,
        blocksFinalizedCount = blocksFinalizedCount,
        updatedAtMs = updatedAtMs
    )

    companion object {
        fun fromDomain(c: ProductionCheckpoint) = ProductionCheckpointEntity(
            chainId = c.chainId,
            lastFinalizedHeight = c.lastFinalizedHeight,
            lastFinalizedHash = c.lastFinalizedHash,
            lastProposedHeight = c.lastProposedHeight,
            lastProposedRound = c.lastProposedRound,
            lastProposedBlockHash = c.lastProposedBlockHash,
            lastProducedAtMs = c.lastProducedAtMs,
            missedProposalCount = c.missedProposalCount,
            failureCount = c.failureCount,
            blocksProposedCount = c.blocksProposedCount,
            blocksFinalizedCount = c.blocksFinalizedCount,
            updatedAtMs = c.updatedAtMs
        )
    }
}

@Entity(
    tableName = "production_candidates",
    indices = [
        Index(value = ["blockHeight", "round"]),
        Index(value = ["blockHash"])
    ]
)
data class ProductionCandidateEntity(
    @PrimaryKey val slotKey: String,
    val chainId: String,
    val blockHeight: Long,
    val round: Int,
    val proposerId: String,
    val blockHash: String,
    val blockJson: String,
    val transactionCount: Int,
    val proposedSubmitted: Boolean,
    val createdAtMs: Long
)

@Dao
interface BlockProductionDao {

    @Query("SELECT * FROM production_checkpoints WHERE chainId = :chainId LIMIT 1")
    suspend fun getCheckpoint(chainId: String): ProductionCheckpointEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCheckpoint(entity: ProductionCheckpointEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCandidate(entity: ProductionCandidateEntity)

    @Query("SELECT * FROM production_candidates WHERE slotKey = :slotKey LIMIT 1")
    suspend fun getCandidateBySlotKey(slotKey: String): ProductionCandidateEntity?

    @Query("SELECT * FROM production_candidates WHERE chainId = :chainId AND blockHash = :blockHash LIMIT 1")
    suspend fun getCandidateByHash(chainId: String, blockHash: String): ProductionCandidateEntity?

    @Query(
        "SELECT EXISTS(SELECT 1 FROM production_candidates " +
            "WHERE chainId = :chainId AND blockHeight = :height AND round = :round AND proposedSubmitted = 1)"
    )
    suspend fun hasProposedForSlot(chainId: String, height: Long, round: Int): Boolean

    @Query("SELECT * FROM production_candidates WHERE chainId = :chainId AND blockHeight = :height ORDER BY round DESC LIMIT 1")
    suspend fun getLatestCandidateForHeight(chainId: String, height: Long): ProductionCandidateEntity?

    @Query("DELETE FROM production_candidates WHERE chainId = :chainId AND blockHeight <= :maxHeight")
    suspend fun deleteCandidatesUpToHeight(chainId: String, maxHeight: Long)

    @Transaction
    suspend fun finalizeSlotAtomically(
        checkpoint: ProductionCheckpointEntity,
        finalizedHeight: Long
    ) {
        upsertCheckpoint(checkpoint)
        deleteCandidatesUpToHeight(checkpoint.chainId, finalizedHeight)
    }
}

@Database(
    entities = [ProductionCheckpointEntity::class, ProductionCandidateEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BlockProductionDatabase : RoomDatabase() {
    abstract fun dao(): BlockProductionDao

    companion object {
        fun build(context: Context, dbName: String, inMemory: Boolean): BlockProductionDatabase {
            val appCtx = context.applicationContext ?: context
            return if (inMemory) {
                Room.inMemoryDatabaseBuilder(appCtx, BlockProductionDatabase::class.java).build()
            } else {
                Room.databaseBuilder(appCtx, BlockProductionDatabase::class.java, dbName).build()
            }
        }
    }
}

interface BlockProductionStorage : Closeable {
    suspend fun getCheckpoint(chainId: String): ProductionCheckpoint?
    suspend fun saveCheckpoint(checkpoint: ProductionCheckpoint)
    suspend fun saveCandidateBlock(
        chainId: String,
        round: Int,
        proposerId: String,
        block: Block,
        proposedSubmitted: Boolean
    )
    suspend fun markSlotProposed(chainId: String, height: Long, round: Int, blockHash: String)
    suspend fun hasProposedForSlot(chainId: String, height: Long, round: Int): Boolean
    suspend fun getCandidateBlock(chainId: String, height: Long, round: Int): Block?
    suspend fun getCandidateBlockByHash(chainId: String, blockHash: String): Block?
    suspend fun getLatestCandidateForHeight(chainId: String, height: Long): Block?
    suspend fun finalizeSlotAtomically(checkpoint: ProductionCheckpoint, finalizedHeight: Long)
}

class RoomBlockProductionStorage(
    context: Context,
    dbName: String = "nmd_block_production.db",
    inMemory: Boolean = false,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : BlockProductionStorage {

    private val db: BlockProductionDatabase = BlockProductionDatabase.build(context, dbName, inMemory)
    private val dao: BlockProductionDao = db.dao()

    private fun slotKey(chainId: String, height: Long, round: Int): String = "$chainId:$height:$round"

    override suspend fun getCheckpoint(chainId: String): ProductionCheckpoint? = withContext(ioDispatcher) {
        dao.getCheckpoint(chainId)?.toDomain()
    }

    override suspend fun saveCheckpoint(checkpoint: ProductionCheckpoint) = withContext(ioDispatcher) {
        dao.upsertCheckpoint(ProductionCheckpointEntity.fromDomain(checkpoint))
    }

    override suspend fun saveCandidateBlock(
        chainId: String,
        round: Int,
        proposerId: String,
        block: Block,
        proposedSubmitted: Boolean
    ) = withContext(ioDispatcher) {
        dao.upsertCandidate(
            ProductionCandidateEntity(
                slotKey = slotKey(chainId, block.height, round),
                chainId = chainId,
                blockHeight = block.height,
                round = round,
                proposerId = proposerId,
                blockHash = block.hash.lowercase(),
                blockJson = block.toStorageJson(),
                transactionCount = block.header.transactionCount,
                proposedSubmitted = proposedSubmitted,
                createdAtMs = block.timestamp
            )
        )
    }

    override suspend fun markSlotProposed(chainId: String, height: Long, round: Int, blockHash: String) =
        withContext(ioDispatcher) {
            val existing = dao.getCandidateBySlotKey(slotKey(chainId, height, round))
            if (existing != null && existing.blockHash.equals(blockHash, ignoreCase = true)) {
                dao.upsertCandidate(existing.copy(proposedSubmitted = true))
            }
        }

    override suspend fun hasProposedForSlot(chainId: String, height: Long, round: Int): Boolean =
        withContext(ioDispatcher) {
            dao.hasProposedForSlot(chainId, height, round)
        }

    override suspend fun getCandidateBlock(chainId: String, height: Long, round: Int): Block? =
        withContext(ioDispatcher) {
            dao.getCandidateBySlotKey(slotKey(chainId, height, round))?.let { Block.fromStorageJson(it.blockJson) }
        }

    override suspend fun getCandidateBlockByHash(chainId: String, blockHash: String): Block? =
        withContext(ioDispatcher) {
            dao.getCandidateByHash(chainId, blockHash.lowercase())?.let { Block.fromStorageJson(it.blockJson) }
        }

    override suspend fun getLatestCandidateForHeight(chainId: String, height: Long): Block? =
        withContext(ioDispatcher) {
            dao.getLatestCandidateForHeight(chainId, height)?.let { Block.fromStorageJson(it.blockJson) }
        }

    override suspend fun finalizeSlotAtomically(checkpoint: ProductionCheckpoint, finalizedHeight: Long) =
        withContext(ioDispatcher) {
            dao.finalizeSlotAtomically(
                checkpoint = ProductionCheckpointEntity.fromDomain(checkpoint),
                finalizedHeight = finalizedHeight
            )
        }

    override fun close() {
        db.close()
    }
}
