package com.example.production.builder

import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.blockchain.validation.BlockValidationResult
import com.example.blockchain.validation.BlockValidator
import com.example.production.config.BlockProductionConfig
import com.example.production.model.CandidateBlockResult
import com.example.transaction.blockchain.TransactionBlockBridge
import com.example.transaction.model.NmdTransaction

sealed class CandidateBuildOutcome {
    data class Built(val candidate: CandidateBlockResult) : CandidateBuildOutcome()
    data class Rejected(val reason: String) : CandidateBuildOutcome()
}

/**
 * Stage 11 Deterministic Candidate Block Constructor.
 *
 * Builds candidate Stage 8 [Block] instances strictly reusing:
 * - Stage 8 [BlockHasher] (canonical SHA-256 header hash & Merkle root without altering hashing rules)
 * - Stage 8 [BlockValidator] (rejects malformed/oversized/badly-linked candidates before signing)
 * - Stage 9 [TransactionBlockBridge] (`toTransactionReferences`)
 *
 * Candidate blocks are NEVER finalized here — only signed and submitted to Stage 10 consensus.
 */
class BlockConstructor(
    private val config: BlockProductionConfig,
    private val blockHasher: BlockHasher,
    private val blockValidator: BlockValidator,
    private val txBlockBridge: TransactionBlockBridge? = null
) {

    fun buildCandidateBlock(
        parentBlock: Block,
        targetHeight: Long,
        round: Int,
        proposerId: String,
        selectedTransactions: List<NmdTransaction>,
        rejectedTxIds: List<String> = emptyList(),
        nowMs: Long = System.currentTimeMillis(),
        stateRoot: String = "",
        validatorSetHash: String = ""
    ): CandidateBuildOutcome {
        if (targetHeight <= 0L || targetHeight != parentBlock.height + 1L) {
            return CandidateBuildOutcome.Rejected(
                "Target height $targetHeight does not sequentially follow parent height ${parentBlock.height}"
            )
        }
        if (proposerId.isBlank()) {
            return CandidateBuildOutcome.Rejected("Missing proposer identity for candidate block")
        }
        if (selectedTransactions.isEmpty() && !config.produceEmptyBlocks) {
            return CandidateBuildOutcome.Rejected("Empty block production is disabled in config")
        }
        if (selectedTransactions.size > config.maxTransactionsPerBlock) {
            return CandidateBuildOutcome.Rejected(
                "Selected transactions (${selectedTransactions.size}) exceed maxTransactionsPerBlock (${config.maxTransactionsPerBlock})"
            )
        }

        // Convert ordered transactions deterministically into Stage 8 TransactionReferences
        val refs = txBlockBridge?.toTransactionReferences(selectedTransactions)
            ?: selectedTransactions.mapIndexed { index, tx ->
                com.example.blockchain.model.TransactionReference(
                    txHash = tx.txId.lowercase(),
                    txIndex = index,
                    txType = tx.txType.name
                )
            }

        val body = BlockBody(
            transactionRefs = refs,
            extraData = if (refs.isEmpty()) "nmd-empty-h${targetHeight}-r${round}" else ""
        )
        val merkleRoot = blockHasher.computeBodyMerkleRoot(body)
        // Enforce monotonic non-decreasing timestamp while staying within future drift limits
        val safeTimestamp = maxOf(nowMs, parentBlock.timestamp)

        val header = BlockHeader(
            height = targetHeight,
            previousHash = parentBlock.hash.lowercase(),
            timestamp = safeTimestamp,
            chainId = config.chainId,
            protocolVersion = config.protocolVersion,
            merkleRoot = merkleRoot,
            transactionCount = refs.size,
            producerId = proposerId,
            consensusMetadata = "",
            stateRoot = stateRoot,
            validatorSetHash = validatorSetHash
        )
        val blockHash = blockHasher.computeHeaderHash(header)
        val candidateBlock = Block(
            header = header,
            body = body,
            hash = blockHash
        )

        // Independent Stage 8 structural & cryptographic pre-flight validation before signing proposal
        val validation = blockValidator.validateBlock(
            block = candidateBlock,
            parentBlock = parentBlock,
            nowMs = maxOf(nowMs, safeTimestamp)
        )
        if (validation is BlockValidationResult.Invalid) {
            return CandidateBuildOutcome.Rejected(
                "Candidate block failed Stage 8 validation (${validation.code.name}): ${validation.reason}"
            )
        }

        val sizeBytes = blockHasher.computeBlockSizeBytes(candidateBlock)
        if (sizeBytes > config.maxBlockSizeBytes) {
            return CandidateBuildOutcome.Rejected(
                "Candidate block size ($sizeBytes B) exceeds maxBlockSizeBytes (${config.maxBlockSizeBytes} B)"
            )
        }

        return CandidateBuildOutcome.Built(
            CandidateBlockResult(
                block = candidateBlock,
                includedTransactions = selectedTransactions,
                rejectedTxIds = rejectedTxIds,
                serializedSizeBytes = sizeBytes,
                proposerId = proposerId,
                createdAtMs = safeTimestamp
            )
        )
    }
}
