package com.example.production

import android.content.Context
import com.example.blockchain.manager.BlockchainManager
import com.example.consensus.ConsensusCoordinator
import com.example.crypto.NodeIdentityManager
import com.example.data.DeviceTelemetry
import com.example.production.config.BlockProductionConfig
import com.example.production.engine.BlockProductionEngine
import com.example.production.mobile.MobileProductionPolicy
import com.example.production.model.BlockProductionAttemptResult
import com.example.production.model.BlockProductionState
import com.example.production.model.FinalizedBlockRecord
import com.example.production.model.ValidatorScheduleEntry
import com.example.production.storage.BlockProductionStorage
import com.example.production.storage.RoomBlockProductionStorage
import com.example.transaction.TransactionEngineManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.Closeable

/**
 * Central Stage 11 Block Production & Validator Scheduling Coordinator.
 *
 * Bridges Stage 8 [BlockchainManager], Stage 9 [TransactionEngineManager], and Stage 10 [ConsensusCoordinator]
 * while keeping lifecycle event collection clean and memory-leak free.
 */
class BlockProductionCoordinator(
    val config: BlockProductionConfig = BlockProductionConfig(),
    val storage: BlockProductionStorage,
    val blockchainManager: BlockchainManager,
    val txEngineManager: TransactionEngineManager,
    val consensusCoordinator: ConsensusCoordinator,
    ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    constructor(
        context: Context,
        blockchainManager: BlockchainManager,
        txEngineManager: TransactionEngineManager,
        consensusCoordinator: ConsensusCoordinator,
        config: BlockProductionConfig = BlockProductionConfig.fromBlockchainConfig(blockchainManager.config),
        inMemoryStorage: Boolean = false
    ) : this(
        config = config,
        storage = RoomBlockProductionStorage(
            context = context,
            dbName = config.databaseName,
            inMemory = inMemoryStorage
        ),
        blockchainManager = blockchainManager,
        txEngineManager = txEngineManager,
        consensusCoordinator = consensusCoordinator
    )

    val engine = BlockProductionEngine(
        config = config,
        storage = storage,
        blockchainManager = blockchainManager,
        txMempool = txEngineManager.mempool,
        txBlockBridge = txEngineManager.blockBridge
            ?: com.example.transaction.blockchain.TransactionBlockBridge(txEngineManager.mempool, blockchainManager),
        consensusEngine = consensusCoordinator.engine,
        consensusP2pGateway = consensusCoordinator.p2pGateway,
        ioDispatcher = ioDispatcher
    )

    val state: StateFlow<BlockProductionState> = engine.state
    val scheduleEntry: StateFlow<ValidatorScheduleEntry?> = engine.scheduleEntry
    val finalizedEvents: SharedFlow<FinalizedBlockRecord> = engine.finalizedEvents

    private val scope = CoroutineScope(SupervisorJob() + ioDispatcher)
    private var collectorJob: Job? = null

    suspend fun initialize(
        context: Context? = null,
        localPublicKeyHex: String? = null,
        telemetry: DeviceTelemetry = DeviceTelemetry()
    ): BlockProductionState {
        if (collectorJob == null) {
            collectorJob = scope.launch {
                consensusCoordinator.events.collect { event ->
                    engine.handleConsensusEvent(event)
                }
            }
        }
        val thermalSevere = context?.let { MobileProductionPolicy.isDeviceThermallyThrottled(it) } ?: false
        return engine.initialize(
            localPublicKeyHex = localPublicKeyHex,
            telemetry = telemetry,
            thermalSevere = thermalSevere
        )
    }

    suspend fun onLocalIdentityUpdated(publicKeyHex: String?): BlockProductionState {
        return engine.setLocalIdentity(publicKeyHex)
    }

    suspend fun refreshScheduleAndTelemetry(
        context: Context? = null,
        telemetry: DeviceTelemetry
    ): BlockProductionState {
        val thermalSevere = context?.let { MobileProductionPolicy.isDeviceThermallyThrottled(it) } ?: false
        return engine.evaluateSchedule(telemetry = telemetry, thermalSevere = thermalSevere)
    }

    suspend fun attemptEligibleProduction(
        context: Context? = null,
        identityManager: NodeIdentityManager,
        telemetry: DeviceTelemetry,
        broadcastOverP2p: Boolean = true
    ): BlockProductionAttemptResult {
        val thermalSevere = context?.let { MobileProductionPolicy.isDeviceThermallyThrottled(it) } ?: false
        return engine.tryProduceAndProposeBlock(
            identityRepository = identityManager.repository,
            telemetry = telemetry,
            thermalSevere = thermalSevere,
            broadcastOverP2p = broadcastOverP2p
        )
    }

    override fun close() {
        collectorJob?.cancel()
        scope.cancel()
        engine.close()
    }
}

/**
 * Application-scoped shared registry matching Stage 9 & Stage 10 registries so UI and transport
 * observe a single Stage 11 [BlockProductionCoordinator].
 */
object NmdBlockProductionRegistry {
    @Volatile
    private var sharedInstance: BlockProductionCoordinator? = null

    fun getOrCreate(
        context: Context,
        blockchainManager: BlockchainManager,
        txEngineManager: TransactionEngineManager,
        consensusCoordinator: ConsensusCoordinator
    ): BlockProductionCoordinator {
        val existing = sharedInstance
        if (existing != null) return existing
        return synchronized(this) {
            sharedInstance ?: BlockProductionCoordinator(
                context = context.applicationContext,
                blockchainManager = blockchainManager,
                txEngineManager = txEngineManager,
                consensusCoordinator = consensusCoordinator
            ).also {
                sharedInstance = it
            }
        }
    }

    fun resetForTests() {
        synchronized(this) {
            sharedInstance?.close()
            sharedInstance = null
        }
    }
}
