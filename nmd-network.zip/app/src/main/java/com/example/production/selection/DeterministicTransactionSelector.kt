package com.example.production.selection

import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.model.Block
import com.example.blockchain.model.BlockBody
import com.example.blockchain.model.BlockHeader
import com.example.blockchain.model.TransactionReference
import com.example.production.config.BlockProductionConfig
import com.example.transaction.mempool.TransactionMempool
import com.example.transaction.model.MempoolTransactionRecord
import com.example.transaction.model.MempoolTxStatus
import com.example.transaction.model.NmdTransaction
import com.example.transaction.validation.TransactionValidator
import java.util.PriorityQueue

data class TransactionSelectionResult(
    val selectedTransactions: List<NmdTransaction>,
    val rejectedTxIds: List<String>,
    val skippedDueToNonceGapTxIds: List<String>,
    val estimatedBlockSizeBytes: Int
)

/**
 * Stage 11 Deterministic Transaction Selection & Ordering Policy.
 *
 * Ensures identical mempool + confirmed account nonce state produces identical ordered blocks across nodes:
 * 1. Candidate filtering: keeps only [MempoolTxStatus.VALIDATED] transactions that pass
 *    `validator.validateStateless(tx, nowMs)` at block assembly time (rejecting newly expired/invalid txs).
 * 2. Deduplication & conflict elimination: drops duplicate `txId`s and prevents conflicting
 *    transactions sharing `(senderAddress, nonce)` — retaining only the highest priority entry
 *    by `(feeUnits DESC, timestamp ASC, txId ASC)`.
 * 3. Per-sender contiguous nonce enforcement: starting from `confirmedNextNonce(sender)`, only
 *    contiguous sequential nonces `(N, N+1, ...)` for each sender are eligible for inclusion.
 * 4. Cross-sender deterministic ranking: a priority frontier pops each sender's next nonce head in
 *    strict deterministic order: `feeUnits DESC`, then `timestamp ASC`, then `txId ASC`.
 * 5. Size & count caps: enforces `maxTransactionsPerBlock` and `maxBlockSizeBytes` measured cleanly
 *    with Stage 8 [BlockHasher.computeBlockSizeBytes] so invalid/oversized blocks are never constructed.
 */
class DeterministicTransactionSelector(
    private val config: BlockProductionConfig,
    private val validator: TransactionValidator,
    private val blockHasher: BlockHasher = BlockHasher()
) {

    private data class FrontierEntry(
        val sender: String,
        val indexInSenderChain: Int,
        val chain: List<NmdTransaction>
    ) {
        val currentTx: NmdTransaction get() = chain[indexInSenderChain]
    }

    private val deterministicTxComparator = Comparator<NmdTransaction> { a, b ->
        // 1. Higher fee first
        val feeCmp = b.feeUnits.compareTo(a.feeUnits)
        if (feeCmp != 0) return@Comparator feeCmp
        // 2. Older timestamp first
        val tsCmp = a.timestamp.compareTo(b.timestamp)
        if (tsCmp != 0) return@Comparator tsCmp
        // 3. Lower txId lexicographically as total deterministic tie-breaker
        val idCmp = a.txId.lowercase().compareTo(b.txId.lowercase())
        if (idCmp != 0) return@Comparator idCmp
        // 4. Fallback sender/nonce
        val senderCmp = a.senderAddress.compareTo(b.senderAddress)
        if (senderCmp != 0) senderCmp else a.nonce.compareTo(b.nonce)
    }

    suspend fun selectForCandidateBlock(
        mempool: TransactionMempool,
        targetHeight: Long,
        previousHash: String,
        proposerId: String,
        nowMs: Long = System.currentTimeMillis()
    ): TransactionSelectionResult {
        val rawCandidates = mempool.getBlockCandidateTransactions(
            limit = maxOf(config.maxTransactionsPerBlock * 2, 400)
        )
        if (rawCandidates.isEmpty()) {
            return TransactionSelectionResult(
                selectedTransactions = emptyList(),
                rejectedTxIds = emptyList(),
                skippedDueToNonceGapTxIds = emptyList(),
                estimatedBlockSizeBytes = estimateEmptyBlockBytes(targetHeight, previousHash, proposerId, nowMs)
            )
        }

        val senderAddresses = rawCandidates.map { it.transaction.senderAddress }.distinct()
        val confirmedNonces = HashMap<String, Long>(senderAddresses.size)
        for (sender in senderAddresses) {
            confirmedNonces[sender] = mempool.getConfirmedNextNonce(sender)
        }

        return selectFromRecords(
            records = rawCandidates,
            confirmedNextNonceBySender = confirmedNonces,
            targetHeight = targetHeight,
            previousHash = previousHash,
            proposerId = proposerId,
            nowMs = nowMs
        )
    }

    /**
     * Pure deterministic selection helper useful for both runtime assembly and deterministic unit testing.
     */
    fun selectFromRecords(
        records: List<MempoolTransactionRecord>,
        confirmedNextNonceBySender: Map<String, Long>,
        targetHeight: Long,
        previousHash: String,
        proposerId: String,
        nowMs: Long = System.currentTimeMillis()
    ): TransactionSelectionResult {
        val seenTxIds = HashSet<String>()
        val rejectedIds = mutableListOf<String>()
        val skippedNonceIds = mutableListOf<String>()

        // Per sender: nonce -> best valid tx
        val validBySenderAndNonce = HashMap<String, MutableMap<Long, NmdTransaction>>()

        for (rec in records) {
            val tx = rec.transaction
            val cleanId = tx.txId.lowercase()
            if (cleanId.isBlank() || !seenTxIds.add(cleanId)) {
                if (cleanId.isNotBlank()) rejectedIds.add(cleanId)
                continue
            }
            if (rec.status != MempoolTxStatus.VALIDATED) {
                rejectedIds.add(cleanId)
                continue
            }
            if (!validator.validateStateless(tx, nowMs).isValid) {
                rejectedIds.add(cleanId)
                continue
            }
            val confirmedNext = confirmedNextNonceBySender[tx.senderAddress] ?: 0L
            if (tx.nonce < confirmedNext) {
                rejectedIds.add(cleanId)
                continue
            }

            val senderNonceMap = validBySenderAndNonce.getOrPut(tx.senderAddress) { HashMap() }
            val existingAtNonce = senderNonceMap[tx.nonce]
            if (existingAtNonce == null) {
                senderNonceMap[tx.nonce] = tx
            } else {
                // Conflicting tx at same (sender, nonce): keep deterministically higher-ranked one, reject loser
                if (deterministicTxComparator.compare(tx, existingAtNonce) < 0) {
                    rejectedIds.add(existingAtNonce.txId.lowercase())
                    senderNonceMap[tx.nonce] = tx
                } else {
                    rejectedIds.add(cleanId)
                }
            }
        }

        // Build contiguous sequential nonce chains per sender starting cleanly at confirmedNextNonce
        val priorityQueue = PriorityQueue<FrontierEntry>(Comparator { e1, e2 ->
            deterministicTxComparator.compare(e1.currentTx, e2.currentTx)
        })

        for (sender in validBySenderAndNonce.keys.sorted()) {
            val nonceMap = validBySenderAndNonce[sender] ?: continue
            var expectedNonce = confirmedNextNonceBySender[sender] ?: 0L
            val contiguousChain = mutableListOf<NmdTransaction>()
            val sortedNonces = nonceMap.keys.sorted()
            for (n in sortedNonces) {
                val tx = nonceMap[n] ?: continue
                if (n == expectedNonce) {
                    contiguousChain.add(tx)
                    expectedNonce++
                } else if (n > expectedNonce) {
                    skippedNonceIds.add(tx.txId.lowercase())
                }
            }
            if (contiguousChain.isNotEmpty()) {
                priorityQueue.add(FrontierEntry(sender, 0, contiguousChain))
            }
        }

        val selected = mutableListOf<NmdTransaction>()
        val selectedRefs = mutableListOf<TransactionReference>()

        while (priorityQueue.isNotEmpty() && selected.size < config.maxTransactionsPerBlock) {
            val entry = priorityQueue.poll() ?: break
            val tx = entry.currentTx
            val candidateRef = TransactionReference(
                txHash = tx.txId.lowercase(),
                txIndex = selectedRefs.size,
                txType = tx.txType.name
            )
            val trialRefs = selectedRefs + candidateRef
            val trialBlockSize = estimateBlockBytes(
                refs = trialRefs,
                targetHeight = targetHeight,
                previousHash = previousHash,
                proposerId = proposerId,
                nowMs = nowMs
            )

            if (trialBlockSize <= config.maxBlockSizeBytes) {
                selected.add(tx)
                selectedRefs.add(candidateRef)
                val nextIdx = entry.indexInSenderChain + 1
                if (nextIdx < entry.chain.size) {
                    priorityQueue.add(entry.copy(indexInSenderChain = nextIdx))
                }
            }
            // If adding this tx would exceed maxBlockSizeBytes, we do NOT advance this sender's higher nonces
            // (preserving strict nonce order within the block!).
        }

        val finalSizeBytes = estimateBlockBytes(
            refs = selectedRefs,
            targetHeight = targetHeight,
            previousHash = previousHash,
            proposerId = proposerId,
            nowMs = nowMs
        )

        return TransactionSelectionResult(
            selectedTransactions = selected,
            rejectedTxIds = rejectedIds,
            skippedDueToNonceGapTxIds = skippedNonceIds,
            estimatedBlockSizeBytes = finalSizeBytes
        )
    }

    private fun estimateEmptyBlockBytes(
        targetHeight: Long,
        previousHash: String,
        proposerId: String,
        nowMs: Long
    ): Int = estimateBlockBytes(emptyList(), targetHeight, previousHash, proposerId, nowMs)

    private fun estimateBlockBytes(
        refs: List<TransactionReference>,
        targetHeight: Long,
        previousHash: String,
        proposerId: String,
        nowMs: Long
    ): Int {
        val body = BlockBody(
            transactionRefs = refs,
            extraData = if (refs.isEmpty()) "nmd-block-$targetHeight" else ""
        )
        val header = BlockHeader(
            height = targetHeight,
            previousHash = previousHash.lowercase(),
            timestamp = nowMs,
            chainId = config.chainId,
            protocolVersion = config.protocolVersion,
            merkleRoot = "0".repeat(64),
            transactionCount = refs.size,
            producerId = proposerId,
            consensusMetadata = ""
        )
        return blockHasher.computeBlockSizeBytes(Block(header = header, body = body, hash = "0".repeat(64)))
    }
}
