package com.example.production.engine

import com.example.blockchain.manager.BlockchainManager
import com.example.blockchain.model.Block
import com.example.consensus.engine.ConsensusEngine
import com.example.consensus.engine.ConsensusEvent
import com.example.consensus.engine.ProposalSubmissionResult
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.VotePhase
import com.example.consensus.p2p.ConsensusP2pGateway
import com.example.crypto.repository.IdentityRepository
import com.example.data.DeviceTelemetry
import com.example.production.builder.BlockConstructor
import com.example.production.builder.CandidateBuildOutcome
import com.example.production.config.BlockProductionConfig
import com.example.production.mobile.MobileProductionPolicy
import com.example.production.model.BlockProductionAttemptResult
import com.example.production.model.BlockProductionState
import com.example.production.model.FinalizedBlockRecord
import com.example.production.model.ProductionCheckpoint
import com.example.production.model.ProductionErrorCode
import com.example.production.model.ProductionPhase
import com.example.production.model.ProposalSubmissionStatus
import com.example.production.model.ValidatorScheduleEntry
import com.example.production.scheduler.ValidatorSchedulingEngine
import com.example.production.selection.DeterministicTransactionSelector
import com.example.production.storage.BlockProductionStorage
import com.example.transaction.blockchain.TransactionBlockBridge
import com.example.transaction.mempool.TransactionMempool
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable

/**
 * Stage 11 Block Production & Validator Scheduling Engine.
 *
 * Strictly enforces consensus-gated block production:
 * 1. Computes deterministic proposer schedule via [ValidatorSchedulingEngine] atop Stage 10.
 * 2. Enforces mobile battery, RAM, connectivity, and thermal safeguards via [MobileProductionPolicy].
 * 3. Selects & deterministically orders valid pending Stage 9 transactions via [DeterministicTransactionSelector].
 * 4. Builds & pre-validates candidate Stage 8 [Block] via [BlockConstructor].
 * 5. Signs [BlockProposal] locally via Stage 4/10 Ed25519 cryptography with slot replay prevention.
 * 6. Submits proposal ONLY to [ConsensusEngine] (and optionally [ConsensusP2pGateway]) — NEVER committing blocks directly.
 * 7. Finalizes blocks ONLY when [ConsensusEvent.BlockFinalized] delivers a verified >2/3 [CommitCertificate].
 */
class BlockProductionEngine(
    val config: BlockProductionConfig = BlockProductionConfig(),
    val storage: BlockProductionStorage,
    val blockchainManager: BlockchainManager,
    val txMempool: TransactionMempool,
    val txBlockBridge: TransactionBlockBridge,
    val consensusEngine: ConsensusEngine,
    val consensusP2pGateway: ConsensusP2pGateway? = null,
    val schedulingEngine: ValidatorSchedulingEngine = ValidatorSchedulingEngine(consensusEngine.registry),
    val txSelector: DeterministicTransactionSelector = DeterministicTransactionSelector(
        config = config,
        validator = txMempool.validator,
        blockHasher = blockchainManager.blockHasher
    ),
    val blockConstructor: BlockConstructor = BlockConstructor(
        config = config,
        blockHasher = blockchainManager.blockHasher,
        blockValidator = com.example.blockchain.validation.BlockValidator(
            blockchainManager.config,
            blockchainManager.blockHasher
        ),
        txBlockBridge = txBlockBridge
    ),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    private val mutex = Mutex()
    private val finalizedProcessor = FinalizedBlockProcessor(
        config = config,
        storage = storage,
        blockchainManager = blockchainManager,
        txMempool = txMempool,
        txBlockBridge = txBlockBridge,
        consensusEngine = consensusEngine
    )

    private val _state = MutableStateFlow(
        BlockProductionState(
            isInitialized = false,
            isDevelopmentMode = !config.isProductionMainnetActive
        )
    )
    val state: StateFlow<BlockProductionState> = _state.asStateFlow()

    private val _scheduleEntry = MutableStateFlow<ValidatorScheduleEntry?>(null)
    val scheduleEntry: StateFlow<ValidatorScheduleEntry?> = _scheduleEntry.asStateFlow()

    private val _finalizedEvents = MutableSharedFlow<FinalizedBlockRecord>(extraBufferCapacity = 32)
    val finalizedEvents: SharedFlow<FinalizedBlockRecord> = _finalizedEvents.asSharedFlow()

    private var isInitialized = false
    private var localIdentityPublicKeyHex: String? = null
    private var localValidatorId: String? = null
    private var checkpoint = ProductionCheckpoint(chainId = config.chainId)
    private var lastCandidateBlock: Block? = null
    private var lastCandidateTxCount: Int = 0
    private var lastProposedBlockHash: String? = null
    private var lastSubmissionStatus: ProposalSubmissionStatus = ProposalSubmissionStatus.NOT_SUBMITTED
    private var lastConsensusApprovalStatus: String = "WAITING"
    private var lastFailureReason: String? = null
    private var lastErrorCode: ProductionErrorCode = ProductionErrorCode.NONE
    private var lastTelemetry: DeviceTelemetry = DeviceTelemetry()
    private var lastThermalSevere: Boolean = false

    suspend fun initialize(
        localPublicKeyHex: String? = null,
        telemetry: DeviceTelemetry = DeviceTelemetry(),
        thermalSevere: Boolean = false,
        nowMs: Long = System.currentTimeMillis()
    ): BlockProductionState = withContext(ioDispatcher) {
        mutex.withLock {
            localIdentityPublicKeyHex = localPublicKeyHex?.trim()?.lowercase()
            localValidatorId = localIdentityPublicKeyHex?.let { consensusEngine.signer.deriveValidatorIdFromHex(it) }
            lastTelemetry = telemetry
            lastThermalSevere = thermalSevere

            val chainTip = blockchainManager.getLatestBlock()
            val savedCheckpoint = storage.getCheckpoint(config.chainId)
            checkpoint = savedCheckpoint ?: ProductionCheckpoint(
                chainId = config.chainId,
                lastFinalizedHeight = chainTip?.height ?: 0L,
                lastFinalizedHash = chainTip?.hash?.lowercase() ?: ConsensusConstants.NIL_BLOCK_HASH,
                updatedAtMs = nowMs
            ).also { storage.saveCheckpoint(it) }

            // Reconcile if Stage 8 blockchain advanced further before crash/restart
            if (chainTip != null && chainTip.height > checkpoint.lastFinalizedHeight) {
                checkpoint = checkpoint.copy(
                    lastFinalizedHeight = chainTip.height,
                    lastFinalizedHash = chainTip.hash.lowercase(),
                    updatedAtMs = nowMs
                )
                storage.saveCheckpoint(checkpoint)
            }

            // Reconcile any Stage 10 finalized CommitCertificate that hadn't been recorded in checkpoint yet
            val latestCert = consensusEngine.latestCommitCertificate.value
            if (latestCert != null && latestCert.blockHeight > checkpoint.lastFinalizedHeight) {
                val res = finalizedProcessor.processFinalizedCertificate(
                    certificate = latestCert,
                    currentCheckpoint = checkpoint,
                    nowMs = nowMs
                )
                checkpoint = res.updatedCheckpoint
                res.finalizedRecord?.let { _finalizedEvents.emit(it) }
            }

            val consState = consensusEngine.state.value
            val restoredCandidate = storage.getCandidateBlock(config.chainId, consState.currentHeight, consState.currentRound)
            if (restoredCandidate != null) {
                lastCandidateBlock = restoredCandidate
                lastCandidateTxCount = restoredCandidate.header.transactionCount
                val alreadySubmitted = storage.hasProposedForSlot(config.chainId, consState.currentHeight, consState.currentRound)
                if (alreadySubmitted) {
                    lastProposedBlockHash = restoredCandidate.hash.lowercase()
                    lastSubmissionStatus = ProposalSubmissionStatus.ACCEPTED_BY_CONSENSUS
                    lastConsensusApprovalStatus = "AWAITING_BFT_VOTES"
                }
            } else {
                lastCandidateBlock = null
                lastCandidateTxCount = 0
                lastProposedBlockHash = null
                lastSubmissionStatus = ProposalSubmissionStatus.NOT_SUBMITTED
                lastConsensusApprovalStatus = "WAITING"
            }

            isInitialized = true
            refreshAndPublishStateLocked()
        }
    }

    suspend fun setLocalIdentity(publicKeyHex: String?): BlockProductionState = withContext(ioDispatcher) {
        mutex.withLock {
            localIdentityPublicKeyHex = publicKeyHex?.trim()?.lowercase()
            localValidatorId = localIdentityPublicKeyHex?.let { consensusEngine.signer.deriveValidatorIdFromHex(it) }
            if (isInitialized) refreshAndPublishStateLocked() else _state.value
        }
    }

    suspend fun evaluateSchedule(
        telemetry: DeviceTelemetry = lastTelemetry,
        thermalSevere: Boolean = lastThermalSevere
    ): BlockProductionState = withContext(ioDispatcher) {
        mutex.withLock {
            lastTelemetry = telemetry
            lastThermalSevere = thermalSevere
            if (!isInitialized) return@withLock _state.value
            refreshAndPublishStateLocked()
        }
    }

    suspend fun tryProduceAndProposeBlock(
        identityRepository: IdentityRepository? = null,
        privateKeyBytesForTest: ByteArray? = null,
        telemetry: DeviceTelemetry = lastTelemetry,
        thermalSevere: Boolean = lastThermalSevere,
        broadcastOverP2p: Boolean = true,
        nowMs: Long = System.currentTimeMillis()
    ): BlockProductionAttemptResult = withContext(ioDispatcher) {
        mutex.withLock {
            lastTelemetry = telemetry
            lastThermalSevere = thermalSevere

            if (!isInitialized) {
                return@withLock BlockProductionAttemptResult.Rejected(
                    ProductionErrorCode.UNINITIALIZED,
                    "BlockProductionEngine is not initialized"
                )
            }

            val derivedIdentity = resolveLocalSignerIdentity(identityRepository, privateKeyBytesForTest)
            if (derivedIdentity == null) {
                lastErrorCode = ProductionErrorCode.NO_LOCAL_IDENTITY
                lastFailureReason = "No local Ed25519 validator identity available"
                refreshAndPublishStateLocked(overridePhase = ProductionPhase.IDLE)
                return@withLock BlockProductionAttemptResult.Skipped(
                    ProductionErrorCode.NO_LOCAL_IDENTITY,
                    lastFailureReason!!
                )
            }

            val (signerValId, signerPubHex) = derivedIdentity
            localValidatorId = signerValId
            localIdentityPublicKeyHex = signerPubHex

            val consState = consensusEngine.state.value
            val targetHeight = consState.currentHeight
            val targetRound = consState.currentRound
            val snapshot = consensusEngine.getCurrentValidatorSetSnapshot()
            val schedule = schedulingEngine.computeSchedule(targetHeight, targetRound, signerValId, snapshot)
            _scheduleEntry.value = schedule

            if (!consensusEngine.registry.isRegisteredActiveValidator(signerValId, targetHeight)) {
                val reason = "Local node $signerValId is not an active authorized validator"
                lastErrorCode = ProductionErrorCode.UNAUTHORIZED_VALIDATOR
                lastFailureReason = reason
                refreshAndPublishStateLocked(overridePhase = ProductionPhase.IDLE)
                return@withLock BlockProductionAttemptResult.Rejected(ProductionErrorCode.UNAUTHORIZED_VALIDATOR, reason)
            }

            if (!schedule.isLocalValidatorScheduled ||
                !schedulingEngine.isAuthorizedProposerForSlot(signerValId, targetHeight, targetRound, snapshot)
            ) {
                val reason = "Not scheduled proposer for (h=$targetHeight, r=$targetRound); scheduled=${schedule.scheduledProposerId ?: "none"}"
                lastErrorCode = ProductionErrorCode.NOT_SCHEDULED_PROPOSER
                lastFailureReason = reason
                refreshAndPublishStateLocked(overridePhase = ProductionPhase.IDLE)
                return@withLock BlockProductionAttemptResult.Skipped(ProductionErrorCode.NOT_SCHEDULED_PROPOSER, reason)
            }

            // Mobile-first resource safeguard (battery, RAM, network, thermal) — local pause ONLY
            val mobileDecision = MobileProductionPolicy.evaluate(telemetry, config, thermalSevere)
            if (!mobileDecision.allowLocalProduction) {
                lastErrorCode = ProductionErrorCode.MOBILE_RESOURCE_PAUSED
                lastFailureReason = mobileDecision.reason
                refreshAndPublishStateLocked(overridePhase = ProductionPhase.PAUSED_MOBILE_RESOURCE)
                return@withLock BlockProductionAttemptResult.Skipped(
                    ProductionErrorCode.MOBILE_RESOURCE_PAUSED,
                    mobileDecision.reason ?: "Paused due to mobile resource constraints"
                )
            }

            // Prevent duplicate/replay proposal in same (height, round)
            if (storage.hasProposedForSlot(config.chainId, targetHeight, targetRound) ||
                (checkpoint.lastProposedHeight == targetHeight && checkpoint.lastProposedRound == targetRound)
            ) {
                val reason = "Proposal already submitted for slot (h=$targetHeight, r=$targetRound)"
                lastErrorCode = ProductionErrorCode.PROPOSAL_ALREADY_SUBMITTED_FOR_SLOT
                lastFailureReason = reason
                refreshAndPublishStateLocked()
                return@withLock BlockProductionAttemptResult.Skipped(
                    ProductionErrorCode.PROPOSAL_ALREADY_SUBMITTED_FOR_SLOT,
                    reason
                )
            }

            // Min block interval pacing
            if (config.minBlockIntervalMs > 0L &&
                checkpoint.lastProducedAtMs > 0L &&
                (nowMs - checkpoint.lastProducedAtMs) in 0 until config.minBlockIntervalMs
            ) {
                val remaining = config.minBlockIntervalMs - (nowMs - checkpoint.lastProducedAtMs)
                val reason = "Min block interval throttle active (${remaining}ms remaining)"
                lastErrorCode = ProductionErrorCode.INTERVAL_THROTTLED
                lastFailureReason = reason
                refreshAndPublishStateLocked(overridePhase = ProductionPhase.ELIGIBLE_SCHEDULED)
                return@withLock BlockProductionAttemptResult.Skipped(ProductionErrorCode.INTERVAL_THROTTLED, reason)
            }

            val parentBlock = blockchainManager.getBlockByHeight(targetHeight - 1L)
                ?: blockchainManager.getLatestBlock()
            if (parentBlock == null || parentBlock.height + 1L != targetHeight) {
                val reason = "Missing sequential parent block for height $targetHeight (tip=${parentBlock?.height})"
                return@withLock recordFailureAndRejectLocked(ProductionErrorCode.MISSING_PARENT_BLOCK, reason, nowMs)
            }

            // Step 1: Transaction Selection
            refreshAndPublishStateLocked(overridePhase = ProductionPhase.SELECTING_TRANSACTIONS)
            val selection = txSelector.selectForCandidateBlock(
                mempool = txMempool,
                targetHeight = targetHeight,
                previousHash = parentBlock.hash,
                proposerId = signerValId,
                nowMs = nowMs
            )
            if (selection.selectedTransactions.isEmpty() && !config.produceEmptyBlocks) {
                val reason = "No valid pending transactions and produceEmptyBlocks is false"
                lastErrorCode = ProductionErrorCode.NO_PENDING_TRANSACTIONS
                lastFailureReason = reason
                refreshAndPublishStateLocked(overridePhase = ProductionPhase.ELIGIBLE_SCHEDULED)
                return@withLock BlockProductionAttemptResult.Skipped(ProductionErrorCode.NO_PENDING_TRANSACTIONS, reason)
            }

            // Step 2: Candidate Block Construction + Stage 8 Structural Validation
            refreshAndPublishStateLocked(overridePhase = ProductionPhase.CONSTRUCTING_CANDIDATE)
            val previewStateRoot = txMempool.ledgerStateEngine?.previewBlockStateRoot(
                transactions = selection.selectedTransactions,
                blockHeight = targetHeight,
                parameters = blockchainManager.config.parameters,
                nowMs = nowMs
            ).orEmpty()
            val buildOutcome = blockConstructor.buildCandidateBlock(
                parentBlock = parentBlock,
                targetHeight = targetHeight,
                round = targetRound,
                proposerId = signerValId,
                selectedTransactions = selection.selectedTransactions,
                rejectedTxIds = selection.rejectedTxIds,
                nowMs = nowMs,
                stateRoot = previewStateRoot,
                validatorSetHash = snapshot.snapshotHash
            )

            val candidateResult = when (buildOutcome) {
                is CandidateBuildOutcome.Built -> buildOutcome.candidate
                is CandidateBuildOutcome.Rejected -> {
                    val code = when {
                        buildOutcome.reason.contains("merkle", ignoreCase = true) -> ProductionErrorCode.MERKLE_MISMATCH
                        buildOutcome.reason.contains("size", ignoreCase = true) -> ProductionErrorCode.BLOCK_SIZE_EXCEEDED
                        else -> ProductionErrorCode.INVALID_CANDIDATE_BLOCK
                    }
                    return@withLock recordFailureAndRejectLocked(code, buildOutcome.reason, nowMs)
                }
            }

            lastCandidateBlock = candidateResult.block
            lastCandidateTxCount = candidateResult.includedTransactions.size
            storage.saveCandidateBlock(
                chainId = config.chainId,
                round = targetRound,
                proposerId = signerValId,
                block = candidateResult.block,
                proposedSubmitted = false
            )

            // Step 3: Sign BlockProposal via Stage 4/10 Ed25519
            refreshAndPublishStateLocked(overridePhase = ProductionPhase.SIGNING_PROPOSAL)
            val unsignedProposal = BlockProposal(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                blockHeight = targetHeight,
                round = targetRound,
                proposerId = signerValId,
                proposerPublicKeyHex = signerPubHex,
                previousBlockHash = parentBlock.hash.lowercase(),
                proposedBlockHash = candidateResult.block.hash.lowercase(),
                timestamp = candidateResult.createdAtMs,
                attachedBlock = candidateResult.block
            )
            val signedProposal = when {
                identityRepository != null -> consensusEngine.signer.signProposalWithDeviceIdentity(
                    unsignedProposal,
                    identityRepository
                )
                privateKeyBytesForTest != null -> consensusEngine.signer.signProposalWithKeyPair(
                    unsignedProposal,
                    privateKeyBytesForTest
                )
                else -> return@withLock recordFailureAndRejectLocked(
                    ProductionErrorCode.NO_LOCAL_IDENTITY,
                    "Missing local signer key",
                    nowMs
                )
            }

            // Step 4: Submit ONLY to Stage 10 BFT Consensus (NEVER commit directly)
            return@withLock when (val subRes = consensusEngine.submitProposal(signedProposal, nowMs)) {
                is ProposalSubmissionResult.Accepted -> {
                    storage.markSlotProposed(config.chainId, targetHeight, targetRound, candidateResult.block.hash)
                    checkpoint = checkpoint.copy(
                        lastProposedHeight = targetHeight,
                        lastProposedRound = targetRound,
                        lastProposedBlockHash = candidateResult.block.hash.lowercase(),
                        lastProducedAtMs = nowMs,
                        blocksProposedCount = checkpoint.blocksProposedCount + 1L,
                        updatedAtMs = nowMs
                    )
                    storage.saveCheckpoint(checkpoint)

                    val deliveredCount = if (broadcastOverP2p && consensusP2pGateway != null) {
                        consensusP2pGateway.broadcastProposal(signedProposal)
                    } else 0

                    lastProposedBlockHash = candidateResult.block.hash.lowercase()
                    lastSubmissionStatus = ProposalSubmissionStatus.ACCEPTED_BY_CONSENSUS
                    lastConsensusApprovalStatus = "AWAITING_BFT_VOTES"
                    lastErrorCode = ProductionErrorCode.NONE
                    lastFailureReason = null
                    refreshAndPublishStateLocked(overridePhase = ProductionPhase.PROPOSED_AWAITING_CONSENSUS)

                    BlockProductionAttemptResult.Proposed(
                        height = targetHeight,
                        round = targetRound,
                        candidateBlock = candidateResult.block,
                        signedProposal = signedProposal,
                        includedTxCount = candidateResult.includedTransactions.size,
                        p2pPeersNotified = deliveredCount
                    )
                }
                is ProposalSubmissionResult.Duplicate -> {
                    storage.markSlotProposed(config.chainId, targetHeight, targetRound, candidateResult.block.hash)
                    lastSubmissionStatus = ProposalSubmissionStatus.DUPLICATE
                    lastErrorCode = ProductionErrorCode.PROPOSAL_ALREADY_SUBMITTED_FOR_SLOT
                    lastFailureReason = subRes.reason
                    refreshAndPublishStateLocked()
                    BlockProductionAttemptResult.Skipped(
                        ProductionErrorCode.PROPOSAL_ALREADY_SUBMITTED_FOR_SLOT,
                        subRes.reason
                    )
                }
                is ProposalSubmissionResult.Rejected -> {
                    lastSubmissionStatus = ProposalSubmissionStatus.REJECTED
                    recordFailureAndRejectLocked(
                        ProductionErrorCode.CONSENSUS_REJECTED,
                        "Consensus rejected proposal (${subRes.code.name}): ${subRes.reason}",
                        nowMs
                    )
                }
            }
        }
    }

    /**
     * Bridges Stage 10 [ConsensusEvent] lifecycle transitions cleanly into Stage 11 state,
     * finalizing blocks strictly after [ConsensusEvent.BlockFinalized].
     */
    suspend fun handleConsensusEvent(
        event: ConsensusEvent,
        nowMs: Long = System.currentTimeMillis()
    ): BlockProductionState = withContext(ioDispatcher) {
        mutex.withLock {
            if (!isInitialized) return@withLock _state.value
            when (event) {
                is ConsensusEvent.ProposalAccepted -> {
                    val cons = consensusEngine.state.value
                    if (event.height == cons.currentHeight && event.round == cons.currentRound) {
                        lastProposedBlockHash = event.blockHash.lowercase()
                        lastSubmissionStatus = ProposalSubmissionStatus.ACCEPTED_BY_CONSENSUS
                        lastConsensusApprovalStatus = "PROPOSAL_ACCEPTED"
                        refreshAndPublishStateLocked(overridePhase = ProductionPhase.PROPOSED_AWAITING_CONSENSUS)
                    } else _state.value
                }
                is ConsensusEvent.QuorumReached -> {
                    val phaseOverride = if (event.phase == VotePhase.PRECOMMIT) {
                        lastConsensusApprovalStatus = "PRECOMMIT_QUORUM (${event.count}/${event.required})"
                        ProductionPhase.CONSENSUS_APPROVED
                    } else {
                        lastConsensusApprovalStatus = "PREVOTE_QUORUM (${event.count}/${event.required})"
                        ProductionPhase.PROPOSED_AWAITING_CONSENSUS
                    }
                    refreshAndPublishStateLocked(overridePhase = phaseOverride)
                }
                is ConsensusEvent.BlockFinalized -> {
                    val outcome = finalizedProcessor.processFinalizedCertificate(
                        certificate = event.certificate,
                        currentCheckpoint = checkpoint,
                        fallbackCandidateBlock = lastCandidateBlock,
                        nowMs = nowMs
                    )
                    checkpoint = outcome.updatedCheckpoint
                    if (outcome.finalizedRecord != null) {
                        _finalizedEvents.emit(outcome.finalizedRecord)
                    }
                    lastConsensusApprovalStatus = "FINALIZED (H#${event.certificate.blockHeight})"
                    lastSubmissionStatus = ProposalSubmissionStatus.ACCEPTED_BY_CONSENSUS
                    lastErrorCode = ProductionErrorCode.NONE
                    lastFailureReason = null
                    lastCandidateBlock = null
                    lastCandidateTxCount = 0
                    lastProposedBlockHash = null
                    refreshAndPublishStateLocked(overridePhase = ProductionPhase.FINALIZED)
                }
                is ConsensusEvent.RoundTimedOut -> {
                    checkpoint = checkpoint.copy(
                        missedProposalCount = checkpoint.missedProposalCount + 1L,
                        updatedAtMs = nowMs
                    )
                    storage.saveCheckpoint(checkpoint)
                    lastCandidateBlock = null
                    lastCandidateTxCount = 0
                    lastProposedBlockHash = null
                    lastSubmissionStatus = ProposalSubmissionStatus.NOT_SUBMITTED
                    lastConsensusApprovalStatus = "ROUND_TIMEOUT_ROTATED (R${event.oldRound}->R${event.newRound})"
                    refreshAndPublishStateLocked(overridePhase = ProductionPhase.TIMEOUT_ROTATED)
                }
                is ConsensusEvent.ValidationRejected -> {
                    lastConsensusApprovalStatus = "CONSENSUS_REJECTED (${event.code.name})"
                    lastFailureReason = event.reason
                    refreshAndPublishStateLocked()
                }
                else -> refreshAndPublishStateLocked()
            }
        }
    }

    private fun resolveLocalSignerIdentity(
        identityRepository: IdentityRepository?,
        privateKeyBytesForTest: ByteArray?
    ): Pair<String, String>? {
        val pubHex = when {
            identityRepository != null -> identityRepository.getPublicIdentity()?.publicKeyHex
            privateKeyBytesForTest != null -> consensusEngine.signer.cryptoProvider.toHex(
                consensusEngine.signer.cryptoProvider.derivePublicKeyFromPrivate(privateKeyBytesForTest)
            )
            else -> null
        }?.trim()?.lowercase() ?: return null
        val valId = consensusEngine.signer.deriveValidatorIdFromHex(pubHex) ?: return null
        return valId to pubHex
    }

    private suspend fun recordFailureAndRejectLocked(
        code: ProductionErrorCode,
        reason: String,
        nowMs: Long
    ): BlockProductionAttemptResult.Rejected {
        checkpoint = checkpoint.copy(
            failureCount = checkpoint.failureCount + 1L,
            updatedAtMs = nowMs
        )
        storage.saveCheckpoint(checkpoint)
        lastErrorCode = code
        lastFailureReason = reason
        refreshAndPublishStateLocked(overridePhase = ProductionPhase.FAILED)
        return BlockProductionAttemptResult.Rejected(code, reason)
    }

    private fun refreshAndPublishStateLocked(overridePhase: ProductionPhase? = null): BlockProductionState {
        val cons = consensusEngine.state.value
        val snapshot = consensusEngine.getCurrentValidatorSetSnapshot()
        val schedule = schedulingEngine.computeSchedule(
            height = cons.currentHeight,
            round = cons.currentRound,
            localValidatorId = localValidatorId,
            snapshot = snapshot
        )
        _scheduleEntry.value = schedule

        val mobileDecision = MobileProductionPolicy.evaluate(lastTelemetry, config, lastThermalSevere)
        val localActive = localValidatorId != null &&
            consensusEngine.registry.isRegisteredActiveValidator(localValidatorId!!, cons.currentHeight)

        val effectivePhase = overridePhase ?: when {
            !mobileDecision.allowLocalProduction -> ProductionPhase.PAUSED_MOBILE_RESOURCE
            lastProposedBlockHash != null && lastSubmissionStatus == ProposalSubmissionStatus.ACCEPTED_BY_CONSENSUS ->
                ProductionPhase.PROPOSED_AWAITING_CONSENSUS
            schedule.isLocalValidatorScheduled && localActive -> ProductionPhase.ELIGIBLE_SCHEDULED
            else -> ProductionPhase.IDLE
        }

        val updated = BlockProductionState(
            isInitialized = isInitialized,
            isDevelopmentMode = !config.isProductionMainnetActive,
            phase = effectivePhase,
            currentFinalizedHeight = checkpoint.lastFinalizedHeight,
            currentFinalizedHash = checkpoint.lastFinalizedHash,
            currentProductionHeight = cons.currentHeight,
            currentRound = cons.currentRound,
            scheduledProposerId = schedule.scheduledProposerId,
            scheduledProposerName = schedule.scheduledProposerName,
            nextRoundProposerId = schedule.nextRoundProposerId,
            nextHeightProposerId = schedule.nextHeightProposerId,
            localValidatorId = localValidatorId,
            localValidatorEligible = localActive && schedule.isLocalValidatorScheduled,
            localMobilePaused = !mobileDecision.allowLocalProduction,
            mobilePauseReason = mobileDecision.reason,
            candidateBlockHash = lastCandidateBlock?.hash?.lowercase(),
            candidateTransactionCount = lastCandidateTxCount,
            proposedBlockHash = lastProposedBlockHash,
            proposalSubmissionStatus = lastSubmissionStatus,
            consensusApprovalStatus = lastConsensusApprovalStatus,
            latestFinalizedBlockHeight = checkpoint.lastFinalizedHeight,
            latestFinalizedBlockHash = checkpoint.lastFinalizedHash,
            missedProposalCount = checkpoint.missedProposalCount,
            productionFailureCount = checkpoint.failureCount,
            blocksProposedCount = checkpoint.blocksProposedCount,
            blocksFinalizedCount = checkpoint.blocksFinalizedCount,
            lastFailureReason = lastFailureReason,
            lastErrorCode = lastErrorCode
        )
        _state.value = updated
        return updated
    }

    override fun close() {
        storage.close()
    }
}
