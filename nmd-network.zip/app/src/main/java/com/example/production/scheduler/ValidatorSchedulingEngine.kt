package com.example.production.scheduler

import com.example.consensus.model.ValidatorInfo
import com.example.consensus.model.ValidatorSetSnapshot
import com.example.consensus.validator.ValidatorEligibilityRegistry
import com.example.production.model.ValidatorScheduleEntry

/**
 * Stage 11 Validator Scheduling Engine built strictly atop Stage 10 [ValidatorEligibilityRegistry].
 *
 * Deterministic Proposer Selection Policy across Heights & Rounds:
 * - Authorized validators with `status == ACTIVE` and positive voting power are ordered
 *   lexicographically by `validatorId` (`snapshot.activeValidatorsSorted`).
 * - For any `(height, round)` where `height >= 0` and `round >= 0`:
 *       scheduledIndex = (height + round) % activeValidatorsSorted.size
 * - Across heights (`round == 0`): each committed block advances `height` by 1, cleanly rotating
 *   to the next active validator `(height + 1) % N`.
 * - Across rounds (on timeout/missed proposal at same `height`): BFT round-change advances `round`
 *   by 1, immediately rotating to `(height + round + 1) % N`.
 * - A device's local battery/connectivity pause NEVER alters [ValidatorSetSnapshot.activeValidatorsSorted],
 *   guaranteeing every participating node computes the exact same scheduled proposer for `(height, round)`.
 */
class ValidatorSchedulingEngine(
    private val registry: ValidatorEligibilityRegistry
) {

    /**
     * Computes the deterministic schedule for `(height, round)` including current proposer,
     * fallback next-round proposer (timeout), and next-height proposer (after finality).
     */
    fun computeSchedule(
        height: Long,
        round: Int,
        localValidatorId: String? = null,
        snapshot: ValidatorSetSnapshot = registry.buildSnapshot(height)
    ): ValidatorScheduleEntry {
        val currentProposer = registry.selectDeterministicProposer(snapshot, height, round)
        val nextRoundProposer = if (height >= 0L && round >= 0) {
            registry.selectDeterministicProposer(snapshot, height, round + 1)
        } else null
        val nextHeightProposer = if (height >= 0L) {
            registry.selectDeterministicProposer(snapshot, height + 1L, 0)
        } else null

        return ValidatorScheduleEntry(
            height = height,
            round = round,
            scheduledProposerId = currentProposer?.validatorId,
            scheduledProposerName = currentProposer?.displayName,
            proposerAvailability = currentProposer?.availability,
            nextRoundProposerId = nextRoundProposer?.validatorId,
            nextHeightProposerId = nextHeightProposer?.validatorId,
            isLocalValidatorScheduled = localValidatorId != null &&
                currentProposer != null &&
                currentProposer.validatorId == localValidatorId,
            activeValidatorCount = snapshot.activeValidatorsSorted.size,
            snapshotHash = snapshot.snapshotHash
        )
    }

    /**
     * Checks strictly whether [validatorId] is eligible AND is the deterministic proposer for `(height, round)`.
     */
    fun isAuthorizedProposerForSlot(
        validatorId: String,
        height: Long,
        round: Int,
        snapshot: ValidatorSetSnapshot = registry.buildSnapshot(height)
    ): Boolean {
        if (!registry.isRegisteredActiveValidator(validatorId, height)) return false
        val scheduled = registry.selectDeterministicProposer(snapshot, height, round) ?: return false
        return scheduled.validatorId == validatorId
    }

    /**
     * Returns true when the scheduled proposer is known to be unavailable locally (offline/low-battery),
     * signaling that BFT timeout rotation may be needed if no proposal arrives.
     */
    fun isScheduledProposerUnavailable(
        height: Long,
        round: Int,
        snapshot: ValidatorSetSnapshot = registry.buildSnapshot(height)
    ): Boolean {
        val scheduled = registry.selectDeterministicProposer(snapshot, height, round) ?: return true
        return !scheduled.isOnlineAndReady
    }

    fun getValidatorInfo(validatorId: String): ValidatorInfo? = registry.getValidator(validatorId)
}
