package com.example.production.config

import com.example.blockchain.config.BlockchainConfig

/**
 * Configurable parameters for Stage 11 Block Production & Validator Scheduling.
 *
 * Strictly mobile-first and development-scoped:
 * - Honors Stage 8 max block size & max transactions per block.
 * - Honors mobile resource limits (RAM, low uncharging battery, thermal throttling).
 * - Does not activate mainnet or token/reward economics.
 */
data class BlockProductionConfig(
    val chainId: String = BlockchainConfig().chainId,
    val protocolVersion: Int = BlockchainConfig().parameters.protocolVersion,
    val maxBlockSizeBytes: Int = BlockchainConfig().parameters.maxBlockSizeBytes,
    val maxTransactionsPerBlock: Int = BlockchainConfig().parameters.maxTransactionsPerBlock,
    val minBlockIntervalMs: Long = 3_000L,
    val produceEmptyBlocks: Boolean = true,
    val databaseName: String = "nmd_block_production.db",
    val minAvailableRamMb: Long = 128L,
    val batteryLowPauseThresholdPercent: Int = 15,
    val respectLowBatteryGuard: Boolean = true,
    val respectThermalGuard: Boolean = true,
    val isProductionMainnetActive: Boolean = BlockchainConfig().parameters.isPublicMainnetActive
) {
    companion object {
        fun fromBlockchainConfig(
            blockchainConfig: BlockchainConfig,
            databaseName: String = BlockchainConfig.databaseNameFor(
                "nmd_block_production.db",
                blockchainConfig.chainId
            )
        ): BlockProductionConfig {
            return BlockProductionConfig(
                chainId = blockchainConfig.chainId,
                protocolVersion = blockchainConfig.parameters.protocolVersion,
                maxBlockSizeBytes = blockchainConfig.parameters.maxBlockSizeBytes,
                maxTransactionsPerBlock = blockchainConfig.parameters.maxTransactionsPerBlock,
                databaseName = databaseName,
                isProductionMainnetActive = blockchainConfig.parameters.isPublicMainnetActive
            )
        }
    }
}
