package com.example.production.mobile

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.validator.MobileParticipationPolicy
import com.example.data.DeviceTelemetry
import com.example.production.config.BlockProductionConfig

data class MobileProductionDecision(
    val allowLocalProduction: Boolean,
    val reason: String? = null
)

/**
 * Stage 11 Mobile-First Block Production Safeguard.
 *
 * Evaluates real Android battery, RAM, connectivity, and thermal signals ONLY to decide whether
 * this local smartphone should pause constructing/signing block proposals for its own slot.
 *
 * CRITICAL INVARIANT:
 * - Local mobile resource pausing NEVER mutates the global deterministic validator schedule.
 *   All nodes still compute the identical scheduled proposer `(height + round) % N`; if a paused
 *   smartphone skips its local turn, BFT timeout rotates cleanly to the next round proposer.
 */
object MobileProductionPolicy {

    fun isDeviceThermallyThrottled(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
            pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
        } catch (_: Throwable) {
            false
        }
    }

    fun evaluate(
        telemetry: DeviceTelemetry,
        config: BlockProductionConfig,
        thermalSevere: Boolean = false
    ): MobileProductionDecision {
        if (config.respectThermalGuard && thermalSevere) {
            return MobileProductionDecision(
                allowLocalProduction = false,
                reason = "Thermal throttling active (SEVERE+) — pausing local block assembly"
            )
        }

        val consensusEval = MobileParticipationPolicy.evaluateDevice(
            telemetry = telemetry,
            config = ConsensusConfig(
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                batteryLowPauseThresholdPercent = config.batteryLowPauseThresholdPercent,
                respectLowBatteryPause = config.respectLowBatteryGuard
            )
        )
        if (consensusEval.shouldPauseActiveSigning) {
            return MobileProductionDecision(
                allowLocalProduction = false,
                reason = consensusEval.reason ?: "Paused due to mobile battery or connectivity constraint"
            )
        }

        val availRam = telemetry.availableRamMb
        if (telemetry.isLowRam || (availRam != null && availRam < config.minAvailableRamMb)) {
            return MobileProductionDecision(
                allowLocalProduction = false,
                reason = "Low available RAM (${availRam ?: 0}MB < ${config.minAvailableRamMb}MB threshold) — pausing local block assembly"
            )
        }

        return MobileProductionDecision(
            allowLocalProduction = true,
            reason = null
        )
    }
}
