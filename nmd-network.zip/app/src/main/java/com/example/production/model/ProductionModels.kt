package com.example.production.model

import com.example.blockchain.model.Block
import com.example.consensus.model.BlockProposal
import com.example.consensus.model.CommitCertificate
import com.example.consensus.model.ConsensusConstants
import com.example.consensus.model.ValidatorAvailability
import com.example.transaction.model.NmdTransaction

enum class ProductionPhase {
    IDLE,
    ELIGIBLE_SCHEDULED,
    SELECTING_TRANSACTIONS,
    CONSTRUCTING_CANDIDATE,
    SIGNING_PROPOSAL,
    PROPOSED_AWAITING_CONSENSUS,
    CONSENSUS_APPROVED,
    FINALIZED,
    PAUSED_MOBILE_RESOURCE,
    TIMEOUT_ROTATED,
    FAILED
}

enum class ProposalSubmissionStatus {
    NOT_SUBMITTED,
    SUBMITTED,
    ACCEPTED_BY_CONSENSUS,
    DUPLICATE,
    REJECTED
}

enum class ProductionErrorCode {
    NONE,
    UNINITIALIZED,
    NO_LOCAL_IDENTITY,
    NOT_SCHEDULED_PROPOSER,
    UNAUTHORIZED_VALIDATOR,
    MOBILE_RESOURCE_PAUSED,
    INTERVAL_THROTTLED,
    MISSING_PARENT_BLOCK,
    NO_PENDING_TRANSACTIONS,
    INVALID_CANDIDATE_BLOCK,
    MERKLE_MISMATCH,
    BLOCK_SIZE_EXCEEDED,
    CONSENSUS_REJECTED,
    PROPOSAL_ALREADY_SUBMITTED_FOR_SLOT,
    STORAGE_ERROR
}

/**
 * Deterministic validator scheduling view for `(height, round)`.
 * All devices running identical validator snapshots compute identical schedules.
 */
data class ValidatorScheduleEntry(
    val height: Long,
    val round: Int,
    val scheduledProposerId: String?,
    val scheduledProposerName: String?,
    val proposerAvailability: ValidatorAvailability?,
    val nextRoundProposerId: String?,
    val nextHeightProposerId: String?,
    val isLocalValidatorScheduled: Boolean,
    val activeValidatorCount: Int,
    val snapshotHash: String
)

data class CandidateBlockResult(
    val block: Block,
    val includedTransactions: List<NmdTransaction>,
    val rejectedTxIds: List<String>,
    val serializedSizeBytes: Int,
    val proposerId: String,
    val createdAtMs: Long
)

data class ProductionCheckpoint(
    val chainId: String,
    val lastFinalizedHeight: Long = 0L,
    val lastFinalizedHash: String = ConsensusConstants.NIL_BLOCK_HASH,
    val lastProposedHeight: Long = 0L,
    val lastProposedRound: Int = -1,
    val lastProposedBlockHash: String? = null,
    val lastProducedAtMs: Long = 0L,
    val missedProposalCount: Long = 0L,
    val failureCount: Long = 0L,
    val blocksProposedCount: Long = 0L,
    val blocksFinalizedCount: Long = 0L,
    val updatedAtMs: Long = System.currentTimeMillis()
)

sealed class BlockProductionAttemptResult {
    data class Proposed(
        val height: Long,
        val round: Int,
        val candidateBlock: Block,
        val signedProposal: BlockProposal,
        val includedTxCount: Int,
        val p2pPeersNotified: Int = 0
    ) : BlockProductionAttemptResult()

    data class Skipped(
        val code: ProductionErrorCode,
        val reason: String
    ) : BlockProductionAttemptResult()

    data class Rejected(
        val code: ProductionErrorCode,
        val reason: String
    ) : BlockProductionAttemptResult()
}

data class FinalizedBlockRecord(
    val certificate: CommitCertificate,
    val finalizedBlock: Block?,
    val confirmedTxCount: Int,
    val finalizedAtMs: Long
)

data class BlockProductionState(
    val isInitialized: Boolean = false,
    val isDevelopmentMode: Boolean = true,
    val phase: ProductionPhase = ProductionPhase.IDLE,
    val currentFinalizedHeight: Long = 0L,
    val currentFinalizedHash: String = ConsensusConstants.NIL_BLOCK_HASH,
    val currentProductionHeight: Long = 1L,
    val currentRound: Int = 0,
    val scheduledProposerId: String? = null,
    val scheduledProposerName: String? = null,
    val nextRoundProposerId: String? = null,
    val nextHeightProposerId: String? = null,
    val localValidatorId: String? = null,
    val localValidatorEligible: Boolean = false,
    val localMobilePaused: Boolean = false,
    val mobilePauseReason: String? = null,
    val candidateBlockHash: String? = null,
    val candidateTransactionCount: Int = 0,
    val proposedBlockHash: String? = null,
    val proposalSubmissionStatus: ProposalSubmissionStatus = ProposalSubmissionStatus.NOT_SUBMITTED,
    val consensusApprovalStatus: String = "WAITING",
    val latestFinalizedBlockHeight: Long = 0L,
    val latestFinalizedBlockHash: String = ConsensusConstants.NIL_BLOCK_HASH,
    val missedProposalCount: Long = 0L,
    val productionFailureCount: Long = 0L,
    val blocksProposedCount: Long = 0L,
    val blocksFinalizedCount: Long = 0L,
    val lastFailureReason: String? = null,
    val lastErrorCode: ProductionErrorCode = ProductionErrorCode.NONE
)
