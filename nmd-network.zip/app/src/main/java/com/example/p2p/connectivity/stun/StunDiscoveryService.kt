package com.example.p2p.connectivity.stun

import com.example.p2p.connectivity.model.IpVersion
import com.example.p2p.connectivity.model.StunDiscoverySummary
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.StunServerProbeResult
import com.example.p2p.connectivity.model.StunServerStatus
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.security.SecureRandom

/**
 * Abstract probe interface allowing real RFC 5389 UDP STUN probing by default
 * and deterministic test injection when simulating STUN unavailability or IP shifts.
 */
fun interface StunUdpProber {
    suspend fun probeServer(server: StunServerConfig): StunServerProbeResult
}

/**
 * Real RFC 5389 STUN Binding Request / Response UDP client:
 * - Constructs standard 20-byte Binding Request (0x0001) with Magic Cookie (0x2112A442)
 *   and cryptographic 96-bit transaction ID.
 * - Verifies exact transaction ID match on response to defend against off-path spoofing.
 * - Parses XOR-MAPPED-ADDRESS (0x0020) for IPv4 & IPv6, with MAPPED-ADDRESS (0x0001) fallback.
 */
object Rfc5389StunUdpProber : StunUdpProber {

    private const val STUN_BINDING_REQUEST = 0x0001
    private const val STUN_BINDING_RESPONSE = 0x0101
    private const val STUN_MAGIC_COOKIE = 0x2112A442
    private const val STUN_HEADER_BYTES = 20

    private const val ATTR_MAPPED_ADDRESS = 0x0001
    private const val ATTR_XOR_MAPPED_ADDRESS = 0x0020

    private val random = SecureRandom()

    override suspend fun probeServer(server: StunServerConfig): StunServerProbeResult = withContext(Dispatchers.IO) {
        val hostPort = server.parseHostAndPort()
            ?: return@withContext StunServerProbeResult(
                serverUri = server.uri,
                status = StunServerStatus.UNREACHABLE,
                errorReason = "Invalid STUN URI syntax"
            )
        val (host, port) = hostPort
        val txId = ByteArray(12).apply { random.nextBytes(this) }
        val requestBytes = buildBindingRequest(txId)

        var socket: DatagramSocket? = null
        val startMs = System.currentTimeMillis()
        try {
            val targetAddr = InetAddress.getByName(host)
            socket = DatagramSocket().apply {
                soTimeout = server.timeoutMs.toInt()
            }
            val packet = DatagramPacket(requestBytes, requestBytes.size, InetSocketAddress(targetAddr, port))
            socket.send(packet)

            val recvBuf = ByteArray(512)
            val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
            socket.receive(recvPacket)
            val rttMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)

            val mapped = parseBindingResponse(recvBuf, recvPacket.length, txId)
                ?: return@withContext StunServerProbeResult(
                    serverUri = server.uri,
                    status = StunServerStatus.UNREACHABLE,
                    rttMs = rttMs,
                    errorReason = "Malformed STUN Binding Response or missing mapped address"
                )

            val ipVer = when {
                mapped.first.contains(':') -> IpVersion.IPV6
                else -> IpVersion.IPV4
            }
            StunServerProbeResult(
                serverUri = server.uri,
                status = StunServerStatus.AVAILABLE,
                mappedPublicIp = mapped.first,
                mappedPublicPort = mapped.second,
                ipVersion = ipVer,
                rttMs = rttMs
            )
        } catch (e: SocketTimeoutException) {
            StunServerProbeResult(
                serverUri = server.uri,
                status = StunServerStatus.TIMED_OUT,
                errorReason = "STUN probe timed out after ${server.timeoutMs}ms"
            )
        } catch (e: Exception) {
            StunServerProbeResult(
                serverUri = server.uri,
                status = StunServerStatus.UNREACHABLE,
                errorReason = e.message ?: "STUN probe failed"
            )
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {
            }
        }
    }

    fun buildBindingRequest(transactionId: ByteArray): ByteArray {
        require(transactionId.size == 12) { "STUN transaction ID must be 12 bytes" }
        val buf = ByteBuffer.allocate(STUN_HEADER_BYTES)
        buf.putShort(STUN_BINDING_REQUEST.toShort())
        buf.putShort(0) // message length = 0
        buf.putInt(STUN_MAGIC_COOKIE)
        buf.put(transactionId)
        return buf.array()
    }

    /**
     * Builds a valid RFC 5389 Binding Success Response containing XOR-MAPPED-ADDRESS.
     * Used by RFC 5389 unit tests and embedded local test STUN responders.
     */
    fun buildBindingSuccessResponse(
        transactionId: ByteArray,
        clientAddress: InetAddress,
        clientPort: Int
    ): ByteArray {
        require(transactionId.size == 12) { "STUN transaction ID must be 12 bytes" }
        val rawIp = clientAddress.address
        val family = if (clientAddress is Inet6Address || rawIp.size == 16) 0x02 else 0x01
        val attrValLen = 4 + rawIp.size
        val attrTotalLen = 4 + attrValLen

        val buf = ByteBuffer.allocate(STUN_HEADER_BYTES + attrTotalLen)
        buf.putShort(STUN_BINDING_RESPONSE.toShort())
        buf.putShort(attrTotalLen.toShort())
        buf.putInt(STUN_MAGIC_COOKIE)
        buf.put(transactionId)

        // XOR-MAPPED-ADDRESS (0x0020)
        buf.putShort(ATTR_XOR_MAPPED_ADDRESS.toShort())
        buf.putShort(attrValLen.toShort())
        buf.put(0.toByte())
        buf.put(family.toByte())

        val xorPort = clientPort xor (STUN_MAGIC_COOKIE ushr 16)
        buf.putShort(xorPort.toShort())

        val cookieBytes = ByteBuffer.allocate(4).putInt(STUN_MAGIC_COOKIE).array()
        for (i in rawIp.indices) {
            val mask = if (i < 4) cookieBytes[i] else transactionId[i - 4]
            buf.put((rawIp[i].toInt() xor mask.toInt()).toByte())
        }
        return buf.array()
    }

    fun parseBindingResponse(
        bytes: ByteArray,
        length: Int,
        expectedTxId: ByteArray
    ): Pair<String, Int>? {
        if (length < STUN_HEADER_BYTES || expectedTxId.size != 12) return null
        val buf = ByteBuffer.wrap(bytes, 0, length)
        val msgType = buf.short.toInt() and 0xFFFF
        val msgLen = buf.short.toInt() and 0xFFFF
        val magicCookie = buf.int
        if (msgType != STUN_BINDING_RESPONSE || magicCookie != STUN_MAGIC_COOKIE) return null

        val rxTxId = ByteArray(12)
        buf.get(rxTxId)
        if (!rxTxId.contentEquals(expectedTxId)) return null

        val attrsEnd = minOf(length, STUN_HEADER_BYTES + msgLen)
        var fallbackMapped: Pair<String, Int>? = null

        while (buf.position() + 4 <= attrsEnd) {
            val attrType = buf.short.toInt() and 0xFFFF
            val attrLen = buf.short.toInt() and 0xFFFF
            if (buf.position() + attrLen > attrsEnd) break

            val valBytes = ByteArray(attrLen)
            buf.get(valBytes)
            // RFC 5389 4-byte alignment padding
            val padding = (4 - (attrLen % 4)) % 4
            if (buf.position() + padding <= attrsEnd) {
                buf.position(buf.position() + padding)
            }

            if (attrType == ATTR_XOR_MAPPED_ADDRESS) {
                val parsed = parseXorMappedAttribute(valBytes, rxTxId)
                if (parsed != null) return parsed
            } else if (attrType == ATTR_MAPPED_ADDRESS && fallbackMapped == null) {
                fallbackMapped = parseMappedAttribute(valBytes)
            }
        }
        return fallbackMapped
    }

    private fun parseXorMappedAttribute(valBytes: ByteArray, txId: ByteArray): Pair<String, Int>? {
        if (valBytes.size < 8) return null
        val family = valBytes[1].toInt() and 0xFF
        val xPort = ((valBytes[2].toInt() and 0xFF) shl 8) or (valBytes[3].toInt() and 0xFF)
        val port = xPort xor (STUN_MAGIC_COOKIE ushr 16)
        if (port !in 1..65535) return null

        val addrLen = when (family) {
            0x01 -> 4
            0x02 -> 16
            else -> return null
        }
        if (valBytes.size < 4 + addrLen) return null

        val cookieBytes = ByteBuffer.allocate(4).putInt(STUN_MAGIC_COOKIE).array()
        val unmasked = ByteArray(addrLen)
        for (i in 0 until addrLen) {
            val mask = if (i < 4) cookieBytes[i] else txId[i - 4]
            unmasked[i] = (valBytes[4 + i].toInt() xor mask.toInt()).toByte()
        }

        return try {
            val inetAddr = InetAddress.getByAddress(unmasked)
            if (inetAddr is Inet4Address || inetAddr is Inet6Address) {
                (inetAddr.hostAddress ?: return null) to port
            } else null
        } catch (_: Exception) {
            null
        }
    }

    private fun parseMappedAttribute(valBytes: ByteArray): Pair<String, Int>? {
        if (valBytes.size < 8) return null
        val family = valBytes[1].toInt() and 0xFF
        val port = ((valBytes[2].toInt() and 0xFF) shl 8) or (valBytes[3].toInt() and 0xFF)
        if (port !in 1..65535) return null
        val addrLen = when (family) {
            0x01 -> 4
            0x02 -> 16
            else -> return null
        }
        if (valBytes.size < 4 + addrLen) return null
        return try {
            val addr = InetAddress.getByAddress(valBytes.copyOfRange(4, 4 + addrLen))
            (addr.hostAddress ?: return null) to port
        } catch (_: Exception) {
            null
        }
    }
}

/**
 * Discovers server-reflexive public endpoints using configurable STUN servers.
 *
 * Explicit architectural guarantees:
 * - Supports multiple configurable STUN servers (no reliance on a single hardcoded server).
 * - Never treats an observed public IP as a permanent peer identity.
 * - Detects public IP/port shifts across probes and notifies connectivity listeners.
 * - Explicitly discloses that STUN alone cannot guarantee direct connectivity behind
 *   symmetric NAT or strict carrier-grade NAT (CGNAT).
 */
class StunDiscoveryService(
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val udpProber: StunUdpProber = Rfc5389StunUdpProber
) {
    private val _summary = MutableStateFlow(StunDiscoverySummary())
    val summary: StateFlow<StunDiscoverySummary> = _summary.asStateFlow()

    @Volatile
    private var configuredServers: List<StunServerConfig> = emptyList()

    @Volatile
    private var lastObservedPublicEndpoint: String? = null

    var onPublicEndpointChanged: ((oldEndpoint: String?, newEndpoint: String) -> Unit)? = null

    fun configureServers(servers: List<StunServerConfig>) {
        configuredServers = servers.filter { it.enabled && it.isValidConfig() }
        val current = _summary.value
        if (configuredServers.isEmpty()) {
            _summary.value = StunDiscoverySummary(
                overallStatus = StunServerStatus.UNCONFIGURED,
                configuredServersCount = 0,
                publicIpChangedCount = current.publicIpChangedCount
            )
        } else {
            _summary.value = current.copy(
                configuredServersCount = configuredServers.size,
                overallStatus = if (current.overallStatus == StunServerStatus.UNCONFIGURED) {
                    StunServerStatus.PROBING
                } else current.overallStatus
            )
        }
    }

    fun getConfiguredServers(): List<StunServerConfig> = configuredServers

    /**
     * Probes all configured STUN servers sequentially/bounded, aggregates reachability,
     * and detects server-reflexive public IP changes.
     */
    suspend fun discoverReflexiveEndpoints(): StunDiscoverySummary = withContext(ioDispatcher) {
        val activeServers = configuredServers
        if (activeServers.isEmpty()) {
            val unconfigured = StunDiscoverySummary(
                overallStatus = StunServerStatus.UNCONFIGURED,
                configuredServersCount = 0,
                reachableServersCount = 0,
                publicIpChangedCount = _summary.value.publicIpChangedCount
            )
            _summary.value = unconfigured
            return@withContext unconfigured
        }

        _summary.value = _summary.value.copy(
            overallStatus = StunServerStatus.PROBING,
            configuredServersCount = activeServers.size
        )

        val results = mutableListOf<StunServerProbeResult>()
        for (server in activeServers) {
            results.add(udpProber.probeServer(server))
        }

        val reachable = results.filter { it.status == StunServerStatus.AVAILABLE && it.mappedPublicIp != null }
        val primary = reachable.minByOrNull { it.rttMs ?: Long.MAX_VALUE }
        val overallStatus = when {
            reachable.isNotEmpty() -> StunServerStatus.AVAILABLE
            results.any { it.status == StunServerStatus.TIMED_OUT } -> StunServerStatus.TIMED_OUT
            else -> StunServerStatus.UNREACHABLE
        }

        var ipChangedCount = _summary.value.publicIpChangedCount
        val newEndpointStr = primary?.let { "${it.mappedPublicIp}:${it.mappedPublicPort}" }
        val previousEndpoint = lastObservedPublicEndpoint
        if (newEndpointStr != null) {
            if (previousEndpoint != null && previousEndpoint != newEndpointStr) {
                ipChangedCount += 1
                onPublicEndpointChanged?.invoke(previousEndpoint, newEndpointStr)
            }
            lastObservedPublicEndpoint = newEndpointStr
        }

        val updated = StunDiscoverySummary(
            overallStatus = overallStatus,
            configuredServersCount = activeServers.size,
            reachableServersCount = reachable.size,
            observedPublicIp = primary?.mappedPublicIp,
            observedPublicPort = primary?.mappedPublicPort,
            ipVersion = primary?.ipVersion ?: IpVersion.UNKNOWN,
            lastProbeAtMs = System.currentTimeMillis(),
            publicIpChangedCount = ipChangedCount,
            probeResults = results
        )
        _summary.value = updated
        updated
    }

    /**
     * Records a server-reflexive candidate reported asynchronously by ICE/WebRTC gathering
     * (when a remote peer / ICE agent resolves our reflexive IP/port).
     */
    fun recordIceReflexiveObservation(publicIp: String, publicPort: Int, ipVersion: IpVersion) {
        if (publicIp.isBlank() || publicPort !in 1..65535) return
        val newEndpoint = "$publicIp:$publicPort"
        val prev = lastObservedPublicEndpoint
        var changeCount = _summary.value.publicIpChangedCount
        if (prev != null && prev != newEndpoint) {
            changeCount += 1
            onPublicEndpointChanged?.invoke(prev, newEndpoint)
        }
        lastObservedPublicEndpoint = newEndpoint
        _summary.value = _summary.value.copy(
            overallStatus = StunServerStatus.AVAILABLE,
            observedPublicIp = publicIp,
            observedPublicPort = publicPort,
            ipVersion = ipVersion,
            lastProbeAtMs = System.currentTimeMillis(),
            publicIpChangedCount = changeCount
        )
    }

    fun resetOnNetworkLoss() {
        _summary.value = _summary.value.copy(
            overallStatus = if (configuredServers.isEmpty()) StunServerStatus.UNCONFIGURED else StunServerStatus.UNREACHABLE,
            observedPublicIp = null,
            observedPublicPort = null,
            reachableServersCount = 0
        )
    }
}
