package com.example.p2p.security.crypto

import org.bouncycastle.crypto.agreement.X25519Agreement
import org.bouncycastle.crypto.generators.X25519KeyPairGenerator
import org.bouncycastle.crypto.params.X25519KeyGenerationParameters
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import org.bouncycastle.util.Arrays
import java.io.Closeable
import java.security.SecureRandom

/**
 * Ephemeral X25519 key pair for a single transport handshake only.
 * Private key material is kept strictly in memory and zeroized on [close].
 */
class EphemeralX25519KeyPair(
    private val privateKeyBytesInternal: ByteArray,
    val publicKeyBytes: ByteArray
) : Closeable {

    init {
        require(privateKeyBytesInternal.size == 32) { "X25519 private key must be 32 bytes" }
        require(publicKeyBytes.size == 32) { "X25519 public key must be 32 bytes" }
    }

    @Volatile
    private var cleared = false

    fun computeAgreement(remotePublicKeyBytes: ByteArray): ByteArray {
        check(!cleared) { "Ephemeral X25519 key pair has already been zeroized" }
        return X25519KeyExchange.computeSharedSecret(privateKeyBytesInternal, remotePublicKeyBytes)
    }

    override fun close() {
        if (!cleared) {
            cleared = true
            X25519KeyExchange.zeroize(privateKeyBytesInternal)
        }
    }

    override fun toString(): String = "EphemeralX25519KeyPair(pubLen=${publicKeyBytes.size}, cleared=$cleared)"
}

/**
 * RFC 7748 X25519 Elliptic-Curve Diffie-Hellman key exchange powered by Bouncy Castle 1.80.
 */
object X25519KeyExchange {

    const val KEY_LENGTH_BYTES = 32
    private val ALL_ZERO_32 = ByteArray(KEY_LENGTH_BYTES)

    fun generateEphemeralKeyPair(secureRandom: SecureRandom = SecureRandom()): EphemeralX25519KeyPair {
        val generator = X25519KeyPairGenerator()
        generator.init(X25519KeyGenerationParameters(secureRandom))
        val pair = generator.generateKeyPair()
        val priv = (pair.private as X25519PrivateKeyParameters).encoded
        val pub = (pair.public as X25519PublicKeyParameters).encoded
        return EphemeralX25519KeyPair(priv, pub)
    }

    fun isValidPublicKey(publicKeyBytes: ByteArray): Boolean {
        if (publicKeyBytes.size != KEY_LENGTH_BYTES) return false
        return !Arrays.constantTimeAreEqual(publicKeyBytes, ALL_ZERO_32)
    }

    /**
     * Computes a 32-byte X25519 shared secret and rejects low-order / all-zero contributor outputs
     * per RFC 7748 Section 6.1.
     */
    fun computeSharedSecret(localPrivateKeyBytes: ByteArray, remotePublicKeyBytes: ByteArray): ByteArray {
        require(localPrivateKeyBytes.size == KEY_LENGTH_BYTES) { "Invalid local X25519 private key length" }
        if (!isValidPublicKey(remotePublicKeyBytes)) {
            throw SecurityException("Invalid or all-zero remote X25519 ephemeral public key")
        }
        val privParam = X25519PrivateKeyParameters(localPrivateKeyBytes, 0)
        val pubParam = X25519PublicKeyParameters(remotePublicKeyBytes, 0)
        val agreement = X25519Agreement()
        agreement.init(privParam)
        val secret = ByteArray(agreement.agreementSize)
        agreement.calculateAgreement(pubParam, secret, 0)
        if (Arrays.constantTimeAreEqual(secret, ALL_ZERO_32)) {
            zeroize(secret)
            throw SecurityException("X25519 ECDH produced an all-zero weak shared secret")
        }
        return secret
    }

    fun zeroize(vararg arrays: ByteArray?) {
        arrays.forEach { arr ->
            if (arr != null) {
                Arrays.fill(arr, 0.toByte())
            }
        }
    }
}
