package com.example.p2p.scalability.validator

import com.example.consensus.config.ConsensusConfig
import com.example.consensus.model.ValidatorAvailability
import com.example.consensus.quorum.QuorumCalculator
import com.example.consensus.validator.ValidatorEligibilityRegistry
import com.example.p2p.model.RealPeerInfo
import com.example.p2p.scalability.health.PeerHealthMonitor
import com.example.p2p.scalability.model.PeerHealthStatus
import com.example.p2p.scalability.model.ValidatorAvailabilitySnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Monitors availability of permissioned Stage 10 validators and evaluates whether
 * currently reachable authorized validators satisfy the immutable BFT quorum Q.
 *
 * Security Invariants:
 * - Never counts ordinary P2P peers as validators.
 * - Never modifies Stage 10 [QuorumCalculator] or [ValidatorEligibilityRegistry] authorization rules.
 */
class ValidatorAvailabilityMonitor(
    private val healthMonitor: PeerHealthMonitor,
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private val _snapshot = MutableStateFlow(ValidatorAvailabilitySnapshot())
    val snapshot: StateFlow<ValidatorAvailabilitySnapshot> = _snapshot.asStateFlow()

    private val commFailuresByValidatorId = ConcurrentHashMap<String, AtomicInteger>()
    private val lastActivityByValidatorId = ConcurrentHashMap<String, Long>()

    @Volatile
    private var attachedRegistry: ValidatorEligibilityRegistry? = null
    @Volatile
    private var attachedConfig: ConsensusConfig = ConsensusConfig()
    @Volatile
    private var attachedLocalValidatorId: String? = null

    fun attachValidatorRegistry(
        registry: ValidatorEligibilityRegistry?,
        consensusConfig: ConsensusConfig = ConsensusConfig(),
        localValidatorId: String? = null
    ) {
        attachedRegistry = registry
        attachedConfig = consensusConfig
        attachedLocalValidatorId = localValidatorId
    }

    fun recordValidatorCommunicationFailure(validatorOrNodeId: String) {
        commFailuresByValidatorId
            .computeIfAbsent(validatorOrNodeId) { AtomicInteger(0) }
            .incrementAndGet()
    }

    fun recordValidatorActivity(validatorOrNodeId: String, timestampMs: Long = clockMs()) {
        lastActivityByValidatorId[validatorOrNodeId] = timestampMs
    }

    fun evaluateAvailability(
        connectedPeers: List<RealPeerInfo>,
        localNodeId: String? = null,
        localValidatorOnline: Boolean = true,
        currentHeight: Long = 0L,
        overrideRegistry: ValidatorEligibilityRegistry? = attachedRegistry,
        overrideConfig: ConsensusConfig = attachedConfig
    ): ValidatorAvailabilitySnapshot {
        val reg = overrideRegistry
        if (reg == null) {
            val empty = ValidatorAvailabilitySnapshot(
                quorumStatusSummary = "Validator registry idle"
            )
            _snapshot.value = empty
            return empty
        }

        val activeValidators = reg.getActiveValidators(currentHeight)
        val totalConfigured = activeValidators.size
        val quorum = QuorumCalculator.calculate(totalConfigured, overrideConfig.minValidatorsForBft)
        val connectedByNodeId = connectedPeers.mapNotNull { p ->
            p.authenticatedNodeId?.let { id -> id to p }
        }.toMap()

        var onlineCount = 0
        var unreachableCount = 0
        var latestActivity: Long? = null
        var recentFailures = 0

        for (v in activeValidators) {
            val isLocal = (localNodeId != null && v.nodeId == localNodeId) ||
                (attachedLocalValidatorId != null && v.validatorId == attachedLocalValidatorId)

            val peerInfo = connectedByNodeId[v.nodeId]
            val peerHealth = healthMonitor.getHealth(v.nodeId)
            val commFails = (commFailuresByValidatorId[v.validatorId]?.get() ?: 0) +
                (commFailuresByValidatorId[v.nodeId]?.get() ?: 0)
            recentFailures += commFails

            val tsCandidate = listOfNotNull(
                v.lastActiveAtMs.takeIf { it > 0L },
                peerHealth?.lastSuccessfulCommMs?.takeIf { it > 0L },
                lastActivityByValidatorId[v.validatorId],
                lastActivityByValidatorId[v.nodeId]
            ).maxOrNull()
            if (tsCandidate != null && (latestActivity == null || tsCandidate > latestActivity)) {
                latestActivity = tsCandidate
            }

            val isOnlineAndHealthy = if (isLocal) {
                localValidatorOnline && v.availability == ValidatorAvailability.ONLINE_AVAILABLE
            } else {
                peerInfo != null &&
                    (peerHealth == null ||
                        (peerHealth.status != PeerHealthStatus.UNREACHABLE &&
                            peerHealth.status != PeerHealthStatus.QUARANTINED &&
                            peerHealth.status != PeerHealthStatus.REVOKED)) &&
                    v.availability != ValidatorAvailability.DISCONNECTED &&
                    v.availability != ValidatorAvailability.TEMPORARILY_UNAVAILABLE
            }

            if (isOnlineAndHealthy) {
                onlineCount++
            } else {
                unreachableCount++
            }
        }

        val canSatisfy = quorum.hasQuorum(onlineCount)
        val summary = when {
            totalConfigured == 0 -> "No authorized validators configured"
            !quorum.isBftSafetyAchieved -> "BFT safety requires >= ${overrideConfig.minValidatorsForBft} validators (have $totalConfigured)"
            canSatisfy -> "Quorum satisfied ($onlineCount/$totalConfigured online, Q=${quorum.requiredQuorum})"
            else -> "Quorum lost ($onlineCount/$totalConfigured online < Q=${quorum.requiredQuorum})"
        }

        val result = ValidatorAvailabilitySnapshot(
            configuredValidatorsCount = totalConfigured,
            activeOnlineValidatorsCount = onlineCount,
            unreachableValidatorsCount = unreachableCount,
            requiredBftQuorum = quorum.requiredQuorum,
            canSatisfyCurrentQuorum = canSatisfy,
            isBftSafetyAchieved = quorum.isBftSafetyAchieved,
            recentValidatorCommFailures = recentFailures,
            lastValidatorActivityMs = latestActivity,
            quorumStatusSummary = summary
        )
        _snapshot.value = result
        return result
    }
}
