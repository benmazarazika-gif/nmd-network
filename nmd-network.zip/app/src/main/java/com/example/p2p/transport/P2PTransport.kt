package com.example.p2p.transport

import com.example.p2p.model.PeerEndpoint
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.Closeable
import java.net.Socket

/**
 * P2PTransport defines the contract for low-level peer-to-peer network operations.
 */
interface P2PTransport : Closeable {

    /**
     * Whether the local node is actively listening on a network port.
     */
    val isListening: StateFlow<Boolean>

    /**
     * The port on which the node is currently bound and listening, or null if stopped.
     */
    val boundPort: StateFlow<Int?>

    /**
     * Emits newly accepted incoming client sockets.
     */
    val incomingSockets: SharedFlow<Socket>

    /**
     * Binds a local server socket and starts accepting incoming connections.
     *
     * @param preferredPort The port to bind to (e.g. 9876, or 0 for an ephemeral port).
     * @return The actual port bound.
     */
    suspend fun startListening(preferredPort: Int = 9876): Int

    /**
     * Stops the local listening socket and terminates inbound accept loop.
     */
    suspend fun stopListening()

    /**
     * Establishes an outbound TCP socket connection to a remote peer endpoint.
     *
     * @param endpoint The remote peer endpoint.
     * @param timeoutMs Connection timeout in milliseconds (default 10,000 ms).
     * @return An open, connected Socket.
     */
    suspend fun connectTo(endpoint: PeerEndpoint, timeoutMs: Int = 10_000): Socket

    /**
     * Resolves the primary local IPv4 address of this device (e.g. on Wi-Fi or loopback).
     */
    fun getLocalIpAddress(): String
}
