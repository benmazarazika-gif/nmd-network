package com.example.p2p.security.trust

import android.content.Context
import android.content.SharedPreferences
import com.example.crypto.provider.BouncyCastleEd25519Provider
import com.example.crypto.provider.CryptographicProvider
import com.example.p2p.security.model.PeerTrustState
import com.example.p2p.security.model.RevokedIdentityRecord
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

sealed class IdentityTrustCheckResult {
    object Allowed : IdentityTrustCheckResult()
    data class Revoked(val nodeId: String, val reason: String) : IdentityTrustCheckResult()
    data class IdentityMismatch(val reason: String) : IdentityTrustCheckResult()
}

/**
 * Manages peer identity verification, public-key pinning / unexpected identity-change detection,
 * and local revocation of compromised peer identities.
 *
 * Security rules:
 * - Zero-trust by default: discovery or past connection never implies current live authentication.
 * - Never stores private keys or ephemeral session keys. Only stores public Node IDs,
 *   SHA-256 public key hashes, and revocation metadata.
 */
class PeerTrustManager(
    context: Context? = null,
    preferencesName: String = DEFAULT_PREFS_NAME,
    private val cryptoProvider: CryptographicProvider = BouncyCastleEd25519Provider(),
    private val rejectUnexpectedIdentityChange: Boolean = true,
    private val endpointPinTtlMs: Long = DEFAULT_ENDPOINT_PIN_TTL_MS,
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private data class EndpointPinRecord(
        val nodeId: String,
        val recordedAtMs: Long
    )

    companion object {
        const val DEFAULT_PREFS_NAME = "nmd_p2p_trust_store"
        const val DEFAULT_ENDPOINT_PIN_TTL_MS = 15L * 60L * 1000L // 15 min DHCP/CGNAT protection window
        private const val KEY_REVOKED_JSON = "revoked_identities_json"
        private const val KEY_PINNED_KEYS_JSON = "pinned_public_keys_json"

        private val DYNAMIC_ENDPOINT_PREFIXES = listOf(
            "unknown", "ice://", "turn://", "relay:", "webrtc:", "signaling:"
        )

        private fun isDynamicEndpoint(endpointKey: String): Boolean {
            val lower = endpointKey.trim().lowercase()
            return lower.isEmpty() || DYNAMIC_ENDPOINT_PREFIXES.any { lower.startsWith(it) }
        }
    }

    private val lock = Any()
    private val revokedByNodeId = ConcurrentHashMap<String, RevokedIdentityRecord>()
    private val revokedPubKeyHashes = ConcurrentHashMap<String, RevokedIdentityRecord>()
    private val pinnedPublicKeyByNodeId = ConcurrentHashMap<String, String>()
    private val pinnedNodeByEndpoint = ConcurrentHashMap<String, EndpointPinRecord>()
    private val peerTrustStates = ConcurrentHashMap<String, PeerTrustState>()

    private val prefs: SharedPreferences? = context?.applicationContext?.getSharedPreferences(
        preferencesName,
        Context.MODE_PRIVATE
    )

    init {
        loadFromPrefs()
    }

    fun hashPublicKeyHex(publicKeyHex: String): String {
        val digest = cryptoProvider.sha256(publicKeyHex.lowercase().toByteArray(Charsets.UTF_8))
        return cryptoProvider.toHex(digest)
    }

    fun checkHandshakeIdentityAllowed(
        remoteNodeId: String,
        remotePublicKeyHex: String,
        endpointKey: String? = null,
        expectedNodeId: String? = null
    ): IdentityTrustCheckResult = synchronized(lock) {
        val normalizedId = remoteNodeId.lowercase()
        val normalizedPub = remotePublicKeyHex.lowercase()
        val pubHash = hashPublicKeyHex(normalizedPub)
        val now = clockMs()

        revokedByNodeId[normalizedId]?.let { rec ->
            peerTrustStates[normalizedId] = PeerTrustState.REVOKED
            return IdentityTrustCheckResult.Revoked(remoteNodeId, rec.reason)
        }
        revokedPubKeyHashes[pubHash]?.let { rec ->
            peerTrustStates[normalizedId] = PeerTrustState.REVOKED
            return IdentityTrustCheckResult.Revoked(remoteNodeId, rec.reason)
        }

        if (expectedNodeId != null && !expectedNodeId.equals(remoteNodeId, ignoreCase = true)) {
            peerTrustStates[normalizedId] = PeerTrustState.IDENTITY_MISMATCH
            return IdentityTrustCheckResult.IdentityMismatch(
                "Peer identity changed or mismatch at endpoint: expected $expectedNodeId, got $remoteNodeId"
            )
        }

        val existingPinnedKey = pinnedPublicKeyByNodeId[normalizedId]
        if (existingPinnedKey != null && !existingPinnedKey.equals(normalizedPub, ignoreCase = true)) {
            peerTrustStates[normalizedId] = PeerTrustState.IDENTITY_MISMATCH
            if (rejectUnexpectedIdentityChange) {
                return IdentityTrustCheckResult.IdentityMismatch(
                    "Unexpected public key change detected for peer $remoteNodeId"
                )
            }
        }

        if (endpointKey != null && !isDynamicEndpoint(endpointKey) && rejectUnexpectedIdentityChange) {
            val previousPin = pinnedNodeByEndpoint[endpointKey]
            if (previousPin != null) {
                if (now - previousPin.recordedAtMs > endpointPinTtlMs) {
                    // Expired lease (e.g. mobile CGNAT or DHCP reallocation)
                    pinnedNodeByEndpoint.remove(endpointKey)
                } else if (!previousPin.nodeId.equals(normalizedId, ignoreCase = true)) {
                    peerTrustStates[normalizedId] = PeerTrustState.IDENTITY_MISMATCH
                    return IdentityTrustCheckResult.IdentityMismatch(
                        "Identity change detected at $endpointKey: expected ${previousPin.nodeId}, got $remoteNodeId"
                    )
                }
            }
        }

        return IdentityTrustCheckResult.Allowed
    }

    fun recordAuthenticatedIdentity(
        remoteNodeId: String,
        remotePublicKeyHex: String,
        endpointKey: String? = null
    ) = synchronized(lock) {
        val normalizedId = remoteNodeId.lowercase()
        val normalizedPub = remotePublicKeyHex.lowercase()
        val now = clockMs()
        pinnedPublicKeyByNodeId[normalizedId] = normalizedPub
        if (endpointKey != null && !isDynamicEndpoint(endpointKey)) {
            // Clear older IP pin owned by this same roaming node before binding its new endpoint
            pinnedNodeByEndpoint.entries.removeIf { it.value.nodeId.equals(normalizedId, ignoreCase = true) }
            pinnedNodeByEndpoint[endpointKey] = EndpointPinRecord(normalizedId, now)
        }
        peerTrustStates[normalizedId] = PeerTrustState.TRUSTED_AUTHENTICATED
        persistToPrefs()
    }

    fun recordAuthenticationFailed(remoteNodeId: String?) = synchronized(lock) {
        if (!remoteNodeId.isNullOrBlank()) {
            val normalizedId = remoteNodeId.lowercase()
            if (peerTrustStates[normalizedId] != PeerTrustState.REVOKED) {
                peerTrustStates[normalizedId] = PeerTrustState.AUTH_FAILED
            }
        }
    }

    fun revokePeerIdentity(
        nodeId: String,
        publicKeyHex: String? = null,
        reason: String = "Revoked by local operator"
    ): RevokedIdentityRecord = synchronized(lock) {
        val normalizedId = nodeId.lowercase()
        val effectivePubHex = publicKeyHex?.lowercase() ?: pinnedPublicKeyByNodeId[normalizedId]
        val pubHash = effectivePubHex?.let { hashPublicKeyHex(it) }
        val record = RevokedIdentityRecord(
            nodeId = nodeId,
            publicKeyHashHex = pubHash,
            reason = reason,
            revokedAtMs = System.currentTimeMillis()
        )
        revokedByNodeId[normalizedId] = record
        if (pubHash != null) {
            revokedPubKeyHashes[pubHash] = record
        }
        peerTrustStates[normalizedId] = PeerTrustState.REVOKED
        persistToPrefs()
        record
    }

    fun unrevokePeerIdentity(nodeId: String): Boolean = synchronized(lock) {
        val normalizedId = nodeId.lowercase()
        val removed = revokedByNodeId.remove(normalizedId) ?: return false
        removed.publicKeyHashHex?.let { revokedPubKeyHashes.remove(it) }
        peerTrustStates[normalizedId] = PeerTrustState.UNVERIFIED
        persistToPrefs()
        true
    }

    fun isPeerRevoked(nodeId: String, publicKeyHex: String? = null): Boolean = synchronized(lock) {
        val normalizedId = nodeId.lowercase()
        if (revokedByNodeId.containsKey(normalizedId)) return true
        val pub = publicKeyHex?.lowercase() ?: pinnedPublicKeyByNodeId[normalizedId]
        if (pub != null && revokedPubKeyHashes.containsKey(hashPublicKeyHex(pub))) return true
        return false
    }

    fun getTrustState(nodeId: String): PeerTrustState = synchronized(lock) {
        if (isPeerRevoked(nodeId)) return PeerTrustState.REVOKED
        peerTrustStates[nodeId.lowercase()] ?: PeerTrustState.UNVERIFIED
    }

    fun getRevokedRecords(): List<RevokedIdentityRecord> = synchronized(lock) {
        revokedByNodeId.values.sortedByDescending { it.revokedAtMs }
    }

    fun getPinnedPublicKey(nodeId: String): String? = synchronized(lock) {
        pinnedPublicKeyByNodeId[nodeId.lowercase()]
    }

    fun clearForTesting() = synchronized(lock) {
        revokedByNodeId.clear()
        revokedPubKeyHashes.clear()
        pinnedPublicKeyByNodeId.clear()
        pinnedNodeByEndpoint.clear()
        peerTrustStates.clear()
        prefs?.edit()?.clear()?.apply()
    }

    private fun loadFromPrefs() {
        val sp = prefs ?: return
        synchronized(lock) {
            try {
                sp.getString(KEY_REVOKED_JSON, null)?.let { jsonStr ->
                    val arr = JSONArray(jsonStr)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val nodeId = obj.getString("node_id")
                        val pubHash = if (obj.has("pub_hash") && !obj.isNull("pub_hash")) obj.getString("pub_hash") else null
                        val reason = obj.optString("reason", "Revoked")
                        val ts = obj.optLong("revoked_at", System.currentTimeMillis())
                        val rec = RevokedIdentityRecord(nodeId, pubHash, reason, ts)
                        revokedByNodeId[nodeId.lowercase()] = rec
                        if (pubHash != null) revokedPubKeyHashes[pubHash] = rec
                        peerTrustStates[nodeId.lowercase()] = PeerTrustState.REVOKED
                    }
                }
                sp.getString(KEY_PINNED_KEYS_JSON, null)?.let { pinnedStr ->
                    val obj = JSONObject(pinnedStr)
                    obj.keys().forEach { key ->
                        pinnedPublicKeyByNodeId[key.lowercase()] = obj.getString(key)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun persistToPrefs() {
        val sp = prefs ?: return
        try {
            val arr = JSONArray()
            revokedByNodeId.values.forEach { rec ->
                arr.put(
                    JSONObject().apply {
                        put("node_id", rec.nodeId)
                        put("pub_hash", rec.publicKeyHashHex)
                        put("reason", rec.reason)
                        put("revoked_at", rec.revokedAtMs)
                    }
                )
            }
            val pinnedObj = JSONObject()
            pinnedPublicKeyByNodeId.forEach { (k, v) -> pinnedObj.put(k, v) }
            sp.edit()
                .putString(KEY_REVOKED_JSON, arr.toString())
                .putString(KEY_PINNED_KEYS_JSON, pinnedObj.toString())
                .apply()
        } catch (_: Exception) {
        }
    }
}
