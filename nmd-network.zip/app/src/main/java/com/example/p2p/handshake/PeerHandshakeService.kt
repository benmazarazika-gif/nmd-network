package com.example.p2p.handshake

import android.content.Context
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.CryptographicProvider
import com.example.p2p.model.FrameType
import com.example.p2p.model.HandshakeFinal
import com.example.p2p.model.HandshakeHello
import com.example.p2p.model.HandshakeResponse
import com.example.p2p.transport.MessageFramer
import java.io.InputStream
import java.io.OutputStream
import java.io.IOException
import java.security.SecureRandom

/**
 * Result of a completed cryptographic peer handshake.
 */
data class HandshakeResult(
    val remoteNodeId: String,
    val remotePublicKeyHex: String,
    val latencyMs: Long
)

/**
 * PeerHandshakeService coordinates the mutual Ed25519 challenge-response handshake over an open TCP socket.
 *
 * Security Architecture (Hardened):
 * 1. Mutual Transcript Binding:
 *    - Signatures sign deterministic binary canonical transcripts constructed with explicit field lengths
 *      and domain separator "NMD-P2P-HANDSHAKE-V2\u0000".
 *    - The transcript binds: domain separator, protocol version, role, initiator Node ID, initiator public key,
 *      responder Node ID, responder public key, initiator challenge, and responder challenge.
 * 2. Persistent Process-wide Replay Protection:
 *    - Backed by HandshakeChallengeReplayCache, storing SHA-256 hashes of challenges across restarts.
 *    - Monotonic expiration while running, wall-clock bounded expiry across restarts.
 *    - Multiple instances share the same replay protection state.
 *    - Cache saturation rejects/defers new handshakes rather than evicting unexpired active challenges.
 * 3. Poisoning Resistance:
 *    - Challenges are verified for length, format, protocol version, freshness, and Node ID derivation
 *      BEFORE they are registered into the replay cache. Invalid or malformed traffic cannot poison or
 *      exhaust the cache capacity.
 * 4. Transparent Scope:
 *    - TCP transport remains raw and unencrypted. Signatures provide mutual authentication, integrity,
 *      and session binding, NOT confidentiality.
 */
class PeerHandshakeService(
    private val identityManager: NodeIdentityManager,
    private val cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider,
    context: Context? = null,
    private val replayCache: HandshakeChallengeReplayCache = HandshakeChallengeReplayCache(
        context = context,
        cryptoProvider = cryptoProvider
    )
) {
    companion object {
        const val MAX_HANDSHAKE_DRIFT_MS = 60_000L // 60 seconds freshness window
        const val CHALLENGE_HEX_LENGTH = 64 // 32 bytes in hex
    }

    private val secureRandom = SecureRandom()

    private fun generateChallenge(): String {
        val bytes = ByteArray(32)
        secureRandom.nextBytes(bytes)
        return cryptoProvider.toHex(bytes)
    }

    /**
     * Atomically checks whether a challenge has already been processed and registers it.
     * Throws IOException if the challenge is a replay, or if the cache is saturated with unexpired challenges.
     */
    fun checkAndRegisterChallenge(challengeHex: String) {
        replayCache.checkAndRegisterChallenge(challengeHex)
    }

    val activeChallengeCount: Int
        get() = replayCache.activeChallengeCount

    fun pruneExpiredForTest() {
        replayCache.pruneExpiredForTest()
    }

    /**
     * Executes the initiator side of the handshake over the socket streams.
     */
    @Throws(IOException::class)
    fun performInitiatorHandshake(
        inputStream: InputStream,
        outputStream: OutputStream,
        expectedRemoteNodeId: String? = null
    ): HandshakeResult {
        val startTime = System.currentTimeMillis()
        val localIdentity = identityManager.getActiveIdentity()
            ?: throw IOException("Local node identity not initialized. Cannot perform handshake.")

        val myChallenge = generateChallenge()
        val hello = HandshakeHello(
            protocolVersion = HandshakeHello.CURRENT_PROTOCOL_VERSION,
            senderNodeId = localIdentity.nodeId,
            senderPublicKeyHex = localIdentity.publicKeyHex,
            challengeHex = myChallenge,
            timestamp = System.currentTimeMillis()
        )

        // 1. Send HELLO
        MessageFramer.writeFrame(outputStream, FrameType.HANDSHAKE_HELLO, hello.toJson().toByteArray(Charsets.UTF_8))

        // 2. Read RESPONSE
        val responseFrame = MessageFramer.readFrame(inputStream)
            ?: throw IOException("Remote peer closed connection before sending handshake response")

        if (responseFrame.first != FrameType.HANDSHAKE_RESPONSE) {
            throw IOException("Expected HANDSHAKE_RESPONSE (0x02), received frame type 0x%02X".format(responseFrame.first))
        }

        val responseJson = String(responseFrame.second, Charsets.UTF_8)
        val response = HandshakeResponse.fromJson(responseJson)
            ?: throw IOException("Malformed HANDSHAKE_RESPONSE JSON payload")

        // Step 2a: Validate structural format and protocol version BEFORE registering to prevent cache poisoning
        if (response.protocolVersion != HandshakeResponse.CURRENT_PROTOCOL_VERSION) {
            throw IOException("Unsupported protocol version: ${response.protocolVersion} (expected ${HandshakeResponse.CURRENT_PROTOCOL_VERSION})")
        }

        // Step 2b: Verify timestamp freshness (drift window <= 60s)
        val now = System.currentTimeMillis()
        if (Math.abs(now - response.timestamp) > MAX_HANDSHAKE_DRIFT_MS) {
            throw IOException("Handshake response timestamp expired or in the future: ${response.timestamp} vs local $now")
        }

        // Step 2c: Verify responder challenge length (32 bytes = 64 hex characters)
        if (response.responderChallengeHex.length != CHALLENGE_HEX_LENGTH) {
            throw IOException("Malformed responder challenge length: ${response.responderChallengeHex.length} (expected $CHALLENGE_HEX_LENGTH)")
        }

        // Step 2d: Verify expected remote Node ID if provided
        if (expectedRemoteNodeId != null && !expectedRemoteNodeId.equals(response.responderNodeId, ignoreCase = true)) {
            throw IOException("Remote peer Node ID mismatch: expected $expectedRemoteNodeId, but peer claimed ${response.responderNodeId}")
        }

        // Step 2e: Verify remote Node ID matches SHA256 of its public key
        val responderPubBytes = cryptoProvider.fromHex(response.responderPublicKeyHex)
        val derivedNodeId = cryptoProvider.deriveNodeId(responderPubBytes)
        if (!derivedNodeId.equals(response.responderNodeId, ignoreCase = true)) {
            throw IOException("Cryptographic verification failed: Responder Node ID does not match SHA-256 derivation of public key")
        }

        // Step 2f: Prevent self-connection
        if (response.responderNodeId.equals(localIdentity.nodeId, ignoreCase = true)) {
            throw IOException("Loopback connection rejected: Remote peer has identical Node ID to local node")
        }

        // Step 2g: Replay Protection: Atomically verify responder challenge has not been seen or replayed
        // (Invoked only after basic authentication checks passed, defending against cache poisoning)
        checkAndRegisterChallenge(response.responderChallengeHex)

        // Step 2h: Hardened Transcript Binding (Responder Signature Verification):
        val responderTranscriptBytes = HandshakeTranscript.buildTranscriptBytes(
            protocolVersion = HandshakeHello.CURRENT_PROTOCOL_VERSION,
            role = HandshakeRole.RESPONDER,
            initiatorNodeId = localIdentity.nodeId,
            initiatorPublicKeyHex = localIdentity.publicKeyHex,
            responderNodeId = response.responderNodeId,
            responderPublicKeyHex = response.responderPublicKeyHex,
            initiatorChallengeHex = myChallenge,
            responderChallengeHex = response.responderChallengeHex
        )

        val signatureBytes = cryptoProvider.fromHex(response.signatureOfHelloChallengeHex)
        val isSignatureValid = cryptoProvider.verify(
            publicKeyBytes = responderPubBytes,
            data = responderTranscriptBytes,
            signature = signatureBytes
        )
        if (!isSignatureValid) {
            throw IOException("Cryptographic handshake failed: Responder failed transcript signature verification")
        }

        // 3. Build INITIATOR transcript, sign it, and send HANDSHAKE_FINAL
        val initiatorTranscriptBytes = HandshakeTranscript.buildTranscriptBytes(
            protocolVersion = HandshakeHello.CURRENT_PROTOCOL_VERSION,
            role = HandshakeRole.INITIATOR,
            initiatorNodeId = localIdentity.nodeId,
            initiatorPublicKeyHex = localIdentity.publicKeyHex,
            responderNodeId = response.responderNodeId,
            responderPublicKeyHex = response.responderPublicKeyHex,
            initiatorChallengeHex = myChallenge,
            responderChallengeHex = response.responderChallengeHex
        )

        val mySignatureBytes = identityManager.signRawData(initiatorTranscriptBytes)
        val mySignatureHex = cryptoProvider.toHex(mySignatureBytes)
        val finalFrame = HandshakeFinal(
            counterChallengeSignatureHex = mySignatureHex,
            status = "ACCEPTED"
        )
        MessageFramer.writeFrame(outputStream, FrameType.HANDSHAKE_FINAL, finalFrame.toJson().toByteArray(Charsets.UTF_8))

        val latencyMs = System.currentTimeMillis() - startTime
        return HandshakeResult(
            remoteNodeId = response.responderNodeId,
            remotePublicKeyHex = response.responderPublicKeyHex,
            latencyMs = latencyMs
        )
    }

    /**
     * Executes the responder side of the handshake over an incoming socket connection.
     */
    @Throws(IOException::class)
    fun performResponderHandshake(
        inputStream: InputStream,
        outputStream: OutputStream
    ): HandshakeResult {
        val startTime = System.currentTimeMillis()
        val localIdentity = identityManager.getActiveIdentity()
            ?: throw IOException("Local node identity not initialized. Cannot perform handshake.")

        // 1. Read HELLO
        val helloFrame = MessageFramer.readFrame(inputStream)
            ?: throw IOException("Remote peer closed connection before sending handshake hello")

        if (helloFrame.first != FrameType.HANDSHAKE_HELLO) {
            throw IOException("Expected HANDSHAKE_HELLO (0x01), received frame type 0x%02X".format(helloFrame.first))
        }

        val helloJson = String(helloFrame.second, Charsets.UTF_8)
        val hello = HandshakeHello.fromJson(helloJson)
            ?: throw IOException("Malformed HANDSHAKE_HELLO JSON payload")

        // Step 1a: Validate protocol version BEFORE registering to prevent cache poisoning
        if (hello.protocolVersion != HandshakeHello.CURRENT_PROTOCOL_VERSION) {
            throw IOException("Unsupported protocol version: ${hello.protocolVersion} (expected ${HandshakeHello.CURRENT_PROTOCOL_VERSION})")
        }

        // Step 1b: Verify timestamp freshness (drift window <= 60s)
        val now = System.currentTimeMillis()
        if (Math.abs(now - hello.timestamp) > MAX_HANDSHAKE_DRIFT_MS) {
            throw IOException("Handshake hello timestamp expired or in the future: ${hello.timestamp} vs local $now")
        }

        // Step 1c: Verify initiator challenge length (32 bytes = 64 hex characters)
        if (hello.challenge.length != CHALLENGE_HEX_LENGTH) {
            throw IOException("Malformed initiator challenge length: ${hello.challenge.length} (expected $CHALLENGE_HEX_LENGTH)")
        }

        // Step 1d: Verify Node ID matches SHA256 of sender public key
        val senderPubBytes = cryptoProvider.fromHex(hello.senderPublicKeyHex)
        val derivedNodeId = cryptoProvider.deriveNodeId(senderPubBytes)
        if (!derivedNodeId.equals(hello.senderNodeId, ignoreCase = true)) {
            throw IOException("Cryptographic verification failed: Sender Node ID does not match SHA-256 derivation of public key")
        }

        // Step 1e: Prevent self-connection
        if (hello.senderNodeId.equals(localIdentity.nodeId, ignoreCase = true)) {
            throw IOException("Loopback connection rejected: Inbound peer has identical Node ID to local node")
        }

        // Step 1f: Replay Protection: Atomically verify initiator challenge has not been seen or replayed
        // (Invoked only after basic authentication checks passed, defending against cache poisoning)
        checkAndRegisterChallenge(hello.challenge)

        // 2. Generate responder challenge, build RESPONDER transcript, sign, and reply with RESPONSE
        val myChallenge = generateChallenge()

        val responderTranscriptBytes = HandshakeTranscript.buildTranscriptBytes(
            protocolVersion = HandshakeHello.CURRENT_PROTOCOL_VERSION,
            role = HandshakeRole.RESPONDER,
            initiatorNodeId = hello.senderNodeId,
            initiatorPublicKeyHex = hello.senderPublicKeyHex,
            responderNodeId = localIdentity.nodeId,
            responderPublicKeyHex = localIdentity.publicKeyHex,
            initiatorChallengeHex = hello.challenge,
            responderChallengeHex = myChallenge
        )

        val mySignatureBytes = identityManager.signRawData(responderTranscriptBytes)
        val mySignatureHex = cryptoProvider.toHex(mySignatureBytes)

        val response = HandshakeResponse(
            protocolVersion = HandshakeResponse.CURRENT_PROTOCOL_VERSION,
            responderNodeId = localIdentity.nodeId,
            responderPublicKeyHex = localIdentity.publicKeyHex,
            challengeSignatureHex = mySignatureHex,
            counterChallengeHex = myChallenge,
            timestamp = System.currentTimeMillis()
        )
        MessageFramer.writeFrame(outputStream, FrameType.HANDSHAKE_RESPONSE, response.toJson().toByteArray(Charsets.UTF_8))

        // 3. Read FINAL
        val finalFrame = MessageFramer.readFrame(inputStream)
            ?: throw IOException("Remote peer closed connection before sending handshake final")

        if (finalFrame.first != FrameType.HANDSHAKE_FINAL) {
            throw IOException("Expected HANDSHAKE_FINAL (0x03), received frame type 0x%02X".format(finalFrame.first))
        }

        val finalJson = String(finalFrame.second, Charsets.UTF_8)
        val handshakeFinal = HandshakeFinal.fromJson(finalJson)
            ?: throw IOException("Malformed HANDSHAKE_FINAL JSON payload")

        // Hardened Transcript Binding (Initiator Final Signature Verification):
        val initiatorTranscriptBytes = HandshakeTranscript.buildTranscriptBytes(
            protocolVersion = HandshakeHello.CURRENT_PROTOCOL_VERSION,
            role = HandshakeRole.INITIATOR,
            initiatorNodeId = hello.senderNodeId,
            initiatorPublicKeyHex = hello.senderPublicKeyHex,
            responderNodeId = localIdentity.nodeId,
            responderPublicKeyHex = localIdentity.publicKeyHex,
            initiatorChallengeHex = hello.challenge,
            responderChallengeHex = myChallenge
        )

        val initiatorFinalSigBytes = cryptoProvider.fromHex(handshakeFinal.signatureOfResponseChallengeHex)
        val isFinalValid = cryptoProvider.verify(
            publicKeyBytes = senderPubBytes,
            data = initiatorTranscriptBytes,
            signature = initiatorFinalSigBytes
        )
        if (!isFinalValid) {
            throw IOException("Cryptographic handshake failed: Initiator failed transcript signature verification")
        }

        val latencyMs = System.currentTimeMillis() - startTime
        return HandshakeResult(
            remoteNodeId = hello.senderNodeId,
            remotePublicKeyHex = hello.senderPublicKeyHex,
            latencyMs = latencyMs
        )
    }
}
