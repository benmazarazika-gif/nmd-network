package com.example.p2p.scalability.model

import com.example.p2p.connectivity.model.TransportPathType
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.protocol.P2pMessageType

/**
 * Peer health classification with multi-signal hysteresis.
 * A peer is NEVER marked UNREACHABLE solely from a single missed heartbeat.
 */
enum class PeerHealthStatus {
    HEALTHY,
    DEGRADED,
    UNREACHABLE,
    RECOVERING,
    QUARANTINED,
    REVOKED
}

/**
 * Multi-signal per-peer health record managed by [com.example.p2p.scalability.health.PeerHealthMonitor].
 */
data class PeerHealthRecord(
    val peerId: String,
    val status: PeerHealthStatus = PeerHealthStatus.HEALTHY,
    val protocolVersion: Int = 1,
    val protocolCompatible: Boolean = true,
    val availabilityStatus: String = "ONLINE",
    val lastSuccessfulCommMs: Long = 0L,
    val lastAuthenticatedSessionMs: Long = 0L,
    val lastSyncInteractionMs: Long = 0L,
    val lastLatencyMs: Long? = null,
    val ewmaLatencyMs: Double? = null,
    val stabilityScore: Int = 100, // 0..100
    val consecutiveMissedHeartbeats: Int = 0,
    val recentMessageFailures: Int = 0,
    val recentTimeouts: Int = 0,
    val recentReconnections: Int = 0,
    val totalFailures: Long = 0L,
    val totalSuccesses: Long = 0L,
    val quarantinedUntilMs: Long = 0L,
    val isRevoked: Boolean = false,
    val lastUpdatedMs: Long = System.currentTimeMillis()
)

/**
 * Explicit circuit breaker state machine.
 */
enum class CircuitBreakerState {
    CLOSED,
    OPEN,
    HALF_OPEN
}

enum class CircuitBreakerTargetType {
    BOOTSTRAP,
    SIGNALING,
    PEER,
    STUN,
    TURN
}

data class CircuitBreakerConfig(
    val failureThreshold: Int = 3,
    val recoveryWindowMs: Long = 30_000L,
    val maxHalfOpenProbes: Int = 1,
    val successThresholdToClose: Int = 1
) {
    init {
        require(failureThreshold >= 1)
        require(recoveryWindowMs >= 100L)
        require(maxHalfOpenProbes >= 1)
        require(successThresholdToClose >= 1)
    }
}

data class CircuitBreakerSnapshot(
    val targetId: String,
    val targetType: CircuitBreakerTargetType,
    val state: CircuitBreakerState = CircuitBreakerState.CLOSED,
    val consecutiveFailures: Int = 0,
    val halfOpenSuccesses: Int = 0,
    val activeHalfOpenProbes: Int = 0,
    val openedAtMs: Long = 0L,
    val nextRetryAllowedMs: Long = 0L,
    val totalTrips: Long = 0L,
    val lastFailureReason: String? = null
)

/**
 * Operational resource capability modes driving adaptive caps and batch sizes.
 */
enum class DeviceResourceMode {
    LOW_RESOURCE,
    BALANCED,
    HIGH_CAPABILITY
}

data class ResourceModePolicy(
    val mode: DeviceResourceMode,
    val maxConnectedPeers: Int,
    val maxOutboundConnections: Int,
    val maxInboundConnections: Int,
    val syncBatchSize: Int,
    val discoveryIntervalMs: Long,
    val maxConcurrentSyncJobs: Int
) {
    companion object {
        fun forMode(mode: DeviceResourceMode): ResourceModePolicy = when (mode) {
            DeviceResourceMode.LOW_RESOURCE -> ResourceModePolicy(
                mode = DeviceResourceMode.LOW_RESOURCE,
                maxConnectedPeers = 4,
                maxOutboundConnections = 2,
                maxInboundConnections = 2,
                syncBatchSize = 5,
                discoveryIntervalMs = 120_000L,
                maxConcurrentSyncJobs = 1
            )
            DeviceResourceMode.BALANCED -> ResourceModePolicy(
                mode = DeviceResourceMode.BALANCED,
                maxConnectedPeers = 8,
                maxOutboundConnections = 4,
                maxInboundConnections = 4,
                syncBatchSize = 20,
                discoveryIntervalMs = 45_000L,
                maxConcurrentSyncJobs = 2
            )
            DeviceResourceMode.HIGH_CAPABILITY -> ResourceModePolicy(
                mode = DeviceResourceMode.HIGH_CAPABILITY,
                maxConnectedPeers = 16,
                maxOutboundConnections = 8,
                maxInboundConnections = 8,
                syncBatchSize = 50,
                discoveryIntervalMs = 20_000L,
                maxConcurrentSyncJobs = 4
            )
        }
    }
}

data class DeviceResourceSnapshot(
    val mode: DeviceResourceMode = DeviceResourceMode.BALANCED,
    val isManualOverride: Boolean = false,
    val batteryPercent: Int? = null,
    val isCharging: Boolean? = null,
    val batteryTemperatureCelsius: Float? = null,
    val availableRamMb: Long = 0L,
    val totalRamMb: Long = 0L,
    val isLowRam: Boolean = false,
    val cpuLoadEstimatePercent: Float? = null, // Nullable when platform restricts /proc access
    val availableStorageMb: Long = 0L,
    val networkType: String = "Unknown",
    val isMeteredNetwork: Boolean = false,
    val connectionQualityScore: Int = 50, // 0..100
    val policy: ResourceModePolicy = ResourceModePolicy.forMode(DeviceResourceMode.BALANCED),
    val sampledAtMs: Long = System.currentTimeMillis()
)

/**
 * Strict Stage 16 Message Priority Classes:
 * 1. BFT consensus votes/control (never starved or silently dropped)
 * 2. Block proposals & commits
 * 3. Transaction announcements & payloads
 * 4. Blockchain sync requests/responses
 * 5. Peer discovery, exchange & diagnostics
 */
enum class MessagePriorityClass(val level: Int) {
    CONSENSUS_BFT(1),
    BLOCK_PROPOSAL_COMMIT(2),
    TX_PROPAGATION(3),
    BLOCKCHAIN_SYNC(4),
    DISCOVERY_DIAGNOSTICS(5);

    companion object {
        fun fromMessageType(type: P2pMessageType): MessagePriorityClass = when (type) {
            P2pMessageType.CONSENSUS_PREVOTE,
            P2pMessageType.CONSENSUS_PRECOMMIT,
            P2pMessageType.ROUND_CHANGE,
            P2pMessageType.VALIDATOR_STATUS -> CONSENSUS_BFT

            P2pMessageType.BLOCK_PROPOSAL,
            P2pMessageType.CONSENSUS_COMMIT -> BLOCK_PROPOSAL_COMMIT

            P2pMessageType.TX_ANNOUNCEMENT,
            P2pMessageType.TX_PAYLOAD,
            P2pMessageType.TX_ACK -> TX_PROPAGATION

            P2pMessageType.CHAIN_STATUS_REQUEST,
            P2pMessageType.CHAIN_STATUS_RESPONSE,
            P2pMessageType.BLOCK_HEADERS_REQUEST,
            P2pMessageType.BLOCK_HEADERS_RESPONSE,
            P2pMessageType.BLOCKS_REQUEST,
            P2pMessageType.BLOCKS_RESPONSE -> BLOCKCHAIN_SYNC

            else -> DISCOVERY_DIAGNOSTICS
        }
    }
}

enum class CongestionState {
    NORMAL,
    ELEVATED,
    CONGESTED,
    RECOVERING
}

data class CongestionMetricsSnapshot(
    val congestionState: CongestionState = CongestionState.NORMAL,
    val outgoingQueueDepth: Int = 0,
    val maxOutgoingQueueDepth: Int = 256,
    val incomingQueueDepth: Int = 0,
    val maxIncomingQueueDepth: Int = 256,
    val consensusQueueDepth: Int = 0,
    val syncQueueDepth: Int = 0,
    val discoveryQueueDepth: Int = 0,
    val acceptedCount: Long = 0L,
    val droppedLowPriorityCount: Long = 0L,
    val expiredQueueItemsCount: Long = 0L,
    val duplicateSuppressedCount: Long = 0L,
    val rateLimitedCount: Long = 0L,
    val retryBackoffActiveCount: Int = 0
)

/**
 * Extended topology diversity & risk analysis (strictly decentralized, bounded, no global central coordinator).
 */
data class TopologyHealthReport(
    val topologyHealthScore: Int = 100, // 0..100
    val uniqueSourceCount: Int = 0,
    val sourceDistribution: Map<DiscoverySource, Int> = emptyMap(),
    val uniqueSubnetPrefixCount: Int = 0,
    val uniqueTransportPathCount: Int = 0,
    val transportPathDistribution: Map<TransportPathType, Int> = emptyMap(),
    val isIsolatedNodeRisk: Boolean = false,
    val isPoorlyConnectedRegion: Boolean = false,
    val isSinglePeerDependencyRisk: Boolean = false,
    val dominantPeerSharePercent: Int = 0,
    val recommendedReplacementPeerIds: List<String> = emptyList(),
    val recommendedCandidatePeerIds: List<String> = emptyList()
)

/**
 * Observes validator availability & whether current online authorized validators satisfy BFT quorum Q
 * without altering Stage 10 quorum math or allowing ordinary peers to satisfy validator quorum.
 */
data class ValidatorAvailabilitySnapshot(
    val configuredValidatorsCount: Int = 0,
    val activeOnlineValidatorsCount: Int = 0,
    val unreachableValidatorsCount: Int = 0,
    val requiredBftQuorum: Int = 0,
    val canSatisfyCurrentQuorum: Boolean = false,
    val isBftSafetyAchieved: Boolean = false,
    val recentValidatorCommFailures: Int = 0,
    val lastValidatorActivityMs: Long? = null,
    val quorumStatusSummary: String = "No authorized validators configured"
)

/**
 * Complete Stage 16 snapshot rendered on the Network Diagnostics Dashboard.
 */
data class NetworkScalabilitySnapshot(
    val connectedPeersCount: Int = 0,
    val healthyPeersCount: Int = 0,
    val degradedPeersCount: Int = 0,
    val unreachablePeersCount: Int = 0,
    val quarantinedPeersCount: Int = 0,
    val revokedPeersCount: Int = 0,
    val maxConnectedCap: Int = 8,
    val maxOutboundCap: Int = 4,
    val maxInboundCap: Int = 4,
    val outboundQueueDepth: Int = 0,
    val inboundQueueDepth: Int = 0,
    val droppedQueueMessagesCount: Long = 0L,
    val expiredQueueMessagesCount: Long = 0L,
    val rateLimitedEventsCount: Long = 0L,
    val congestionState: CongestionState = CongestionState.NORMAL,
    val openCircuitBreakers: List<CircuitBreakerSnapshot> = emptyList(),
    val allCircuitBreakers: List<CircuitBreakerSnapshot> = emptyList(),
    val healthyBootstrapCount: Int = 0,
    val unavailableBootstrapCount: Int = 0,
    val signalingHealthSummary: String = "DISCONNECTED",
    val deviceResource: DeviceResourceSnapshot = DeviceResourceSnapshot(),
    val validatorAvailability: ValidatorAvailabilitySnapshot = ValidatorAvailabilitySnapshot(),
    val topologyHealth: TopologyHealthReport = TopologyHealthReport(),
    val averagePeerRttMs: Long? = null,
    val peerHealthRecords: List<PeerHealthRecord> = emptyList(),
    val lastSweepTimestampMs: Long = 0L,
    val recentScalabilityEvents: List<String> = emptyList()
)
