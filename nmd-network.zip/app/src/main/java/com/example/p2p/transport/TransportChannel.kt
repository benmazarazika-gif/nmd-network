package com.example.p2p.transport

import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.TransportPathType
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Unified full-duplex stream carrier abstraction for NMD P2P connections.
 *
 * Allows Stage 13's X25519 + Ed25519 handshake, ChaCha20-Poly1305 AEAD framing,
 * MessageFramer, and Stages 6-12 protocols to execute identically over:
 * - Direct Local TCP sockets ([SocketTransportChannel])
 * - WebRTC ICE Direct DataChannels ([BufferedStreamTransportChannel])
 * - TURN Relayed DataChannels ([BufferedStreamTransportChannel])
 *
 * Stage 14 transport carriers NEVER bypass Stage 13 authentication or encryption.
 */
interface TransportChannel : Closeable {
    val channelId: String
    val pathType: TransportPathType
    val selectedCandidateType: IceCandidateType?
    val remoteAddressLabel: String
    val inputStream: InputStream
    val outputStream: OutputStream
    val isClosed: Boolean

    fun setReadTimeoutMs(timeoutMs: Int)
}

/**
 * Wraps a standard TCP [Socket] (Stage 5 LAN direct path) into [TransportChannel].
 */
class SocketTransportChannel(
    val socket: Socket,
    override val channelId: String = UUID.randomUUID().toString(),
    override val pathType: TransportPathType = TransportPathType.LOCAL_DIRECT_TCP,
    override val selectedCandidateType: IceCandidateType? = IceCandidateType.HOST
) : TransportChannel {

    override val remoteAddressLabel: String
        get() = "${socket.inetAddress?.hostAddress ?: "unknown"}:${socket.port}"

    override val inputStream: InputStream
        get() = socket.getInputStream()

    override val outputStream: OutputStream
        get() = socket.getOutputStream()

    override val isClosed: Boolean
        get() = socket.isClosed

    override fun setReadTimeoutMs(timeoutMs: Int) {
        if (!socket.isClosed) {
            socket.soTimeout = timeoutMs.coerceAtLeast(0)
        }
    }

    override fun close() {
        try {
            socket.close()
        } catch (_: Exception) {
        }
    }
}

/**
 * Bounded, backpressure-safe stream adapter for message/packet-oriented carriers
 * such as WebRTC SCTP DataChannels or ICE/TURN binary packet bridges.
 *
 * Enforces:
 * - Bounded inbound chunk queue to prevent memory exhaustion floods.
 * - Configurable blocking read timeout ([setReadTimeoutMs]) compatible with Stage 13 handshake timeouts.
 * - Clean EOF and closed-stream semantics.
 */
class BufferedStreamTransportChannel(
    override val channelId: String = UUID.randomUUID().toString(),
    override var pathType: TransportPathType,
    override var selectedCandidateType: IceCandidateType? = null,
    override val remoteAddressLabel: String,
    private val maxQueuedChunks: Int = DEFAULT_MAX_QUEUED_CHUNKS,
    private val maxSingleChunkBytes: Int = DEFAULT_MAX_CHUNK_BYTES,
    private val sendPacket: (ByteArray) -> Boolean,
    private val onCloseCallback: () -> Unit = {}
) : TransportChannel {

    companion object {
        const val DEFAULT_MAX_QUEUED_CHUNKS = 512
        const val DEFAULT_MAX_CHUNK_BYTES = 128 * 1024 // 128 KB max incoming packet
        private val EOF_SENTINEL = ByteArray(0)
    }

    private val closed = AtomicBoolean(false)
    private val readTimeoutMs = AtomicInteger(0)
    private val inboundQueue = ArrayBlockingQueue<ByteArray>(maxQueuedChunks.coerceAtLeast(8))

    private val streamInput = object : InputStream() {
        private var currentChunk: ByteArray? = null
        private var currentOffset: Int = 0
        private var eofReached: Boolean = false

        override fun read(): Int {
            val single = ByteArray(1)
            val n = read(single, 0, 1)
            return if (n == -1) -1 else (single[0].toInt() and 0xFF)
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            if (off < 0 || len < 0 || off + len > b.size) {
                throw IndexOutOfBoundsException("Invalid read bounds off=$off len=$len size=${b.size}")
            }
            if (eofReached) return -1

            while (currentChunk == null || currentOffset >= currentChunk!!.size) {
                if (closed.get() && inboundQueue.isEmpty()) {
                    eofReached = true
                    return -1
                }
                val timeout = readTimeoutMs.get()
                val next: ByteArray? = try {
                    if (timeout > 0) {
                        inboundQueue.poll(timeout.toLong(), TimeUnit.MILLISECONDS)
                            ?: throw SocketTimeoutException("TransportChannel read timed out after ${timeout}ms")
                    } else {
                        inboundQueue.take()
                    }
                } catch (ie: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw IOException("Channel read interrupted", ie)
                }

                if (next === EOF_SENTINEL) {
                    eofReached = true
                    return -1
                }
                if (next != null && next.isNotEmpty()) {
                    currentChunk = next
                    currentOffset = 0
                    break
                }
            }

            val chunk = currentChunk ?: return -1
            val available = chunk.size - currentOffset
            val toCopy = minOf(len, available)
            System.arraycopy(chunk, currentOffset, b, off, toCopy)
            currentOffset += toCopy
            if (currentOffset >= chunk.size) {
                currentChunk = null
                currentOffset = 0
            }
            return toCopy
        }

        override fun close() {
            this@BufferedStreamTransportChannel.close()
        }
    }

    private val streamOutput = object : OutputStream() {
        private val buffer = ByteArrayOutputStream(2048)
        private val writeLock = Any()

        override fun write(b: Int) {
            synchronized(writeLock) {
                if (closed.get()) throw IOException("TransportChannel is closed")
                buffer.write(b)
            }
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            synchronized(writeLock) {
                if (closed.get()) throw IOException("TransportChannel is closed")
                if (buffer.size() + len > maxSingleChunkBytes) {
                    flushBufferLocked()
                }
                buffer.write(b, off, len)
            }
        }

        override fun flush() {
            synchronized(writeLock) {
                if (closed.get()) throw IOException("TransportChannel is closed")
                flushBufferLocked()
            }
        }

        private fun flushBufferLocked() {
            if (buffer.size() == 0) return
            val payload = buffer.toByteArray()
            buffer.reset()
            if (!sendPacket(payload)) {
                throw IOException("Underlying transport carrier failed sending ${payload.size} bytes")
            }
        }

        override fun close() {
            this@BufferedStreamTransportChannel.close()
        }
    }

    override val inputStream: InputStream
        get() = streamInput

    override val outputStream: OutputStream
        get() = streamOutput

    override val isClosed: Boolean
        get() = closed.get()

    override fun setReadTimeoutMs(timeoutMs: Int) {
        readTimeoutMs.set(timeoutMs.coerceAtLeast(0))
    }

    /**
     * Pushes received binary payload bytes from WebRTC DataChannel / relay carrier
     * into the bounded inbound stream queue. Drops/rejects oversized packets safely.
     */
    fun deliverIncomingBytes(bytes: ByteArray): Boolean {
        if (closed.get()) return false
        if (bytes.isEmpty()) return true
        if (bytes.size > maxSingleChunkBytes) {
            return false
        }
        return inboundQueue.offer(bytes.copyOf())
    }

    /**
     * Updates active path/candidate metadata when ICE nominates or switches pairs.
     */
    fun updatePathMetadata(newPathType: TransportPathType, candidateType: IceCandidateType?) {
        pathType = newPathType
        if (candidateType != null) {
            selectedCandidateType = candidateType
        }
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            inboundQueue.offer(EOF_SENTINEL)
            try {
                onCloseCallback()
            } catch (_: Exception) {
            }
        }
    }
}

/**
 * Helper creating two cross-wired [BufferedStreamTransportChannel] endpoints for
 * deterministic integration testing of full Stage 13 encryption and P2P protocols
 * over ICE Direct / TURN Relay carriers without mocking security layers.
 */
object InMemoryTransportChannelPair {
    fun create(
        pathType: TransportPathType,
        candidateType: IceCandidateType,
        endpointALabel: String = "ice-peer-a",
        endpointBLabel: String = "ice-peer-b"
    ): Pair<BufferedStreamTransportChannel, BufferedStreamTransportChannel> {
        lateinit var channelA: BufferedStreamTransportChannel
        lateinit var channelB: BufferedStreamTransportChannel

        channelA = BufferedStreamTransportChannel(
            pathType = pathType,
            selectedCandidateType = candidateType,
            remoteAddressLabel = endpointBLabel,
            sendPacket = { bytes -> channelB.deliverIncomingBytes(bytes) },
            onCloseCallback = { channelB.close() }
        )
        channelB = BufferedStreamTransportChannel(
            pathType = pathType,
            selectedCandidateType = candidateType,
            remoteAddressLabel = endpointALabel,
            sendPacket = { bytes -> channelA.deliverIncomingBytes(bytes) },
            onCloseCallback = { channelA.close() }
        )
        return channelA to channelB
    }
}
