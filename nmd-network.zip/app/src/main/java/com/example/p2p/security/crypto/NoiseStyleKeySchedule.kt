package com.example.p2p.security.crypto

import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.generators.HKDFBytesGenerator
import org.bouncycastle.crypto.params.HKDFParameters
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.security.MessageDigest

/**
 * Result of Noise-style HKDF-SHA256 key derivation separating send/receive ChaCha20-Poly1305 keys.
 */
class DerivedTransportKeys(
    val initiatorToResponderKey: ByteArray,
    val responderToInitiatorKey: ByteArray,
    val transcriptHash: ByteArray
) {
    override fun toString(): String = "DerivedTransportKeys(redacted)"
}

/**
 * Noise-inspired symmetric handshake state machine (`Noise_XX_25519_Ed25519_ChaChaPoly_SHA256`)
 * built strictly atop reviewed primitives from Bouncy Castle 1.80:
 * - Hash / MixHash: SHA-256
 * - Key Derivation / MixKey / Split: RFC 5869 HKDF-SHA256
 * - ECDHE: RFC 7748 X25519 (`ee`)
 * - Mutual Identity Auth: RFC 8032 Ed25519 signatures over canonical transcript `h`
 *
 * All sensitive chaining keys and intermediate ECDH secrets are zeroized on Split().
 */
class NoiseStyleKeySchedule(
    chainId: String,
    protocolVersion: Int,
    cipherSuiteId: String,
    minSupportedProtocolVersion: Int
) {
    companion object {
        const val PROTOCOL_NAME = "NMD_NoiseXX_25519_Ed25519_ChaChaPoly_SHA256_v1"
    }

    private var chainingKey: ByteArray
    private var handshakeHash: ByteArray

    init {
        val initDigest = sha256(PROTOCOL_NAME.toByteArray(Charsets.UTF_8))
        chainingKey = initDigest.copyOf()
        handshakeHash = initDigest.copyOf()
        X25519KeyExchange.zeroize(initDigest)

        // Domain-bind network parameters to prevent cross-chain and downgrade confusion
        mixHash("chain_id", chainId.toByteArray(Charsets.UTF_8))
        mixHash("protocol_version", intToBigEndian(protocolVersion))
        mixHash("min_supported_version", intToBigEndian(minSupportedProtocolVersion))
        mixHash("cipher_suite", cipherSuiteId.toByteArray(Charsets.UTF_8))
    }

    fun mixHash(label: String, data: ByteArray) {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.write(handshakeHash)
        val labelBytes = label.toByteArray(Charsets.UTF_8)
        dos.writeInt(labelBytes.size)
        dos.write(labelBytes)
        dos.writeInt(data.size)
        dos.write(data)
        dos.flush()
        val nextHash = sha256(baos.toByteArray())
        X25519KeyExchange.zeroize(handshakeHash)
        handshakeHash = nextHash
    }

    fun currentTranscriptHash(): ByteArray = handshakeHash.copyOf()

    /**
     * Mixes the ephemeral X25519 (`ee`) shared secret into chainingKey using HKDF-SHA256,
     * binds the final transcript hash into key derivation info, and splits into independent
     * 32-byte unidirectional AEAD keys (`initiatorToResponderKey`, `responderToInitiatorKey`).
     */
    fun mixKeyAndSplit(
        eeSharedSecret: ByteArray,
        sessionId: String
    ): DerivedTransportKeys {
        require(eeSharedSecret.size == X25519KeyExchange.KEY_LENGTH_BYTES) {
            "Expected 32-byte X25519 shared secret"
        }
        val finalTranscript = handshakeHash.copyOf()

        // Step 1: MixKey(ee) -> 64 bytes -> new chainingKey (32B) || splitSeed (32B)
        val mixOutput = ByteArray(64)
        val hkdfMix = HKDFBytesGenerator(SHA256Digest())
        hkdfMix.init(HKDFParameters(eeSharedSecret, chainingKey, finalTranscript))
        hkdfMix.generateBytes(mixOutput, 0, mixOutput.size)

        val newCk = mixOutput.copyOfRange(0, 32)
        val splitSalt = mixOutput.copyOfRange(32, 64)

        // Step 2: Split() with directional labels + session ID bound into HKDF info
        val infoI2R = buildInfo("i2r", sessionId, finalTranscript)
        val infoR2I = buildInfo("r2i", sessionId, finalTranscript)

        val keyI2R = ByteArray(32)
        val keyR2I = ByteArray(32)

        val hkdfI2R = HKDFBytesGenerator(SHA256Digest())
        hkdfI2R.init(HKDFParameters(newCk, splitSalt, infoI2R))
        hkdfI2R.generateBytes(keyI2R, 0, 32)

        val hkdfR2I = HKDFBytesGenerator(SHA256Digest())
        hkdfR2I.init(HKDFParameters(newCk, splitSalt, infoR2I))
        hkdfR2I.generateBytes(keyR2I, 0, 32)

        // Zeroize all intermediate secrets immediately
        X25519KeyExchange.zeroize(chainingKey, handshakeHash, mixOutput, newCk, splitSalt)

        return DerivedTransportKeys(
            initiatorToResponderKey = keyI2R,
            responderToInitiatorKey = keyR2I,
            transcriptHash = finalTranscript
        )
    }

    private fun buildInfo(directionLabel: String, sessionId: String, transcriptHash: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        val labelBytes = "NMD-TRANSPORT-$directionLabel".toByteArray(Charsets.UTF_8)
        val sessionBytes = sessionId.toByteArray(Charsets.UTF_8)
        dos.writeInt(labelBytes.size)
        dos.write(labelBytes)
        dos.writeInt(sessionBytes.size)
        dos.write(sessionBytes)
        dos.writeInt(transcriptHash.size)
        dos.write(transcriptHash)
        dos.flush()
        return baos.toByteArray()
    }

    private fun sha256(bytes: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(bytes)
    }

    private fun intToBigEndian(value: Int): ByteArray {
        return byteArrayOf(
            ((value ushr 24) and 0xFF).toByte(),
            ((value ushr 16) and 0xFF).toByte(),
            ((value ushr 8) and 0xFF).toByte(),
            (value and 0xFF).toByte()
        )
    }
}
