package com.example.p2p.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.util.Log
import com.example.p2p.model.DiscoveredPeer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap

/**
 * PeerDiscoveryService uses Android Network Service Discovery (NSD/mDNS) to advertise the local
 * node on the Wi-Fi/local network and discover other NMD nodes.
 *
 * Service type: _nmd-node._tcp.
 */
class PeerDiscoveryService(
    private val context: Context,
    private val scope: CoroutineScope
) : Closeable {

    companion object {
        private const val TAG = "PeerDiscoveryService"
        const val SERVICE_TYPE = "_nmd-node._tcp."
        const val SERVICE_NAME_PREFIX = "NMD-Node-"
    }

    private val nsdManager: NsdManager? by lazy {
        try {
            context.getSystemService(Context.NSD_SERVICE) as? NsdManager
        } catch (e: Exception) {
            Log.w(TAG, "NsdManager unavailable: ${e.message}")
            null
        }
    }

    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val discoveredMap = ConcurrentHashMap<String, DiscoveredPeer>()
    private val _discoveredPeers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val discoveredPeers: StateFlow<List<DiscoveredPeer>> = _discoveredPeers.asStateFlow()

    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    // Stage 7: Discovery event callbacks for DistributedPeerRegistry
    var onPeerDiscovered: ((DiscoveredPeer) -> Unit)? = null
    var onPeerLost: ((DiscoveredPeer) -> Unit)? = null

    /**
     * Advertises local node on local network via NSD.
     */
    fun startAdvertising(localNodeId: String, port: Int) {
        val manager = nsdManager ?: return
        if (_isAdvertising.value) return

        val shortId = if (localNodeId.length >= 8) localNodeId.take(8) else localNodeId
        val serviceName = "$SERVICE_NAME_PREFIX$shortId"

        val serviceInfo = NsdServiceInfo().apply {
            this.serviceName = serviceName
            this.serviceType = SERVICE_TYPE
            this.port = port
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setAttribute("nodeId", localNodeId)
                setAttribute("version", "2")
            }
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                Log.i(TAG, "NSD service successfully registered: ${serviceInfo.serviceName}")
                _isAdvertising.value = true
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "NSD registration failed: error code $errorCode")
                _isAdvertising.value = false
            }

            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {
                Log.i(TAG, "NSD service unregistered: ${serviceInfo.serviceName}")
                _isAdvertising.value = false
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "NSD unregistration failed: error code $errorCode")
                _isAdvertising.value = false
            }
        }

        try {
            manager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register NSD service: ${e.message}")
            _isAdvertising.value = false
        }
    }

    /**
     * Stops advertising local node on NSD.
     */
    fun stopAdvertising() {
        val manager = nsdManager ?: return
        val listener = registrationListener ?: return
        try {
            manager.unregisterService(listener)
        } catch (e: Exception) {
            Log.w(TAG, "Error unregistering NSD service: ${e.message}")
        } finally {
            registrationListener = null
            _isAdvertising.value = false
        }
    }

    /**
     * Starts discovering other NMD nodes on local network.
     */
    fun startDiscovery(localNodeId: String) {
        val manager = nsdManager ?: return
        if (_isDiscovering.value) return

        discoveredMap.clear()
        _discoveredPeers.value = emptyList()

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                Log.i(TAG, "NSD discovery started for $regType")
                _isDiscovering.value = true
            }

            override fun onServiceFound(service: NsdServiceInfo) {
                Log.d(TAG, "NSD service found: ${service.serviceName}")
                if (!service.serviceType.contains("nmd-node")) {
                    return
                }

                // Resolve service to get host IP and port
                try {
                    manager.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                            Log.w(TAG, "Failed to resolve service ${serviceInfo.serviceName}: code $errorCode")
                        }

                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val host = serviceInfo.host?.hostAddress ?: return
                            val port = serviceInfo.port
                            val advertisedNodeId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                serviceInfo.attributes["nodeId"]?.let { String(it, Charsets.UTF_8) }
                            } else null

                            // Validate port and address
                            if (port !in 1..65535 || host.isBlank() || host == "0.0.0.0" || host == "255.255.255.255") {
                                Log.w(TAG, "Ignoring NSD service with invalid address: $host:$port")
                                return
                            }

                            // Don't list ourselves
                            if (advertisedNodeId != null && advertisedNodeId.equals(localNodeId, ignoreCase = true)) {
                                return
                            }

                            val peerKey = "$host:$port"
                            val peer = DiscoveredPeer(
                                serviceName = serviceInfo.serviceName,
                                host = host,
                                port = port,
                                advertisedNodeId = advertisedNodeId,
                                discoveredAt = System.currentTimeMillis()
                            )
                            discoveredMap[peerKey] = peer
                            updateDiscoveredList()
                            onPeerDiscovered?.invoke(peer)
                        }
                    })
                } catch (e: Exception) {
                    Log.w(TAG, "Error initiating resolve for ${service.serviceName}: ${e.message}")
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                Log.i(TAG, "NSD service lost: ${service.serviceName}")
                val lostPeers = discoveredMap.values.filter { it.serviceName == service.serviceName }
                discoveredMap.values.removeIf { it.serviceName == service.serviceName }
                updateDiscoveredList()
                lostPeers.forEach { onPeerLost?.invoke(it) }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                Log.i(TAG, "NSD discovery stopped for $serviceType")
                _isDiscovering.value = false
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "NSD start discovery failed: code $errorCode")
                _isDiscovering.value = false
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "NSD stop discovery failed: code $errorCode")
                _isDiscovering.value = false
            }
        }

        try {
            manager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start NSD discovery: ${e.message}")
            _isDiscovering.value = false
        }
    }

    /**
     * Manually adds a discovered or manually specified peer into the discovered list.
     */
    fun addManualPeer(host: String, port: Int, claimedNodeId: String? = null) {
        val key = "$host:$port"
        val peer = DiscoveredPeer(
            serviceName = "Manual-$host:$port",
            host = host,
            port = port,
            advertisedNodeId = claimedNodeId,
            discoveredAt = System.currentTimeMillis()
        )
        discoveredMap[key] = peer
        updateDiscoveredList()
        onPeerDiscovered?.invoke(peer)
    }

    private fun updateDiscoveredList() {
        scope.launch {
            _discoveredPeers.value = discoveredMap.values.toList()
        }
    }

    /**
     * Stops NSD discovery.
     */
    fun stopDiscovery() {
        val manager = nsdManager ?: return
        val listener = discoveryListener ?: return
        try {
            manager.stopServiceDiscovery(listener)
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping NSD discovery: ${e.message}")
        } finally {
            discoveryListener = null
            _isDiscovering.value = false
        }
    }

    override fun close() {
        stopAdvertising()
        stopDiscovery()
        discoveredMap.clear()
        _discoveredPeers.value = emptyList()
    }
}
