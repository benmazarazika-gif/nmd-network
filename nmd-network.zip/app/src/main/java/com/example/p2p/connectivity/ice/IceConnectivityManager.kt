package com.example.p2p.connectivity.ice

import android.content.Context
import android.util.Log
import com.example.p2p.connectivity.model.IceCandidateInfo
import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.IceConnectionStatus
import com.example.p2p.connectivity.model.IceGatheringProgress
import com.example.p2p.connectivity.model.IpVersion
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.TransportPathType
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.transport.BufferedStreamTransportChannel
import com.example.p2p.transport.TransportChannel
import org.webrtc.CandidatePairChangeEvent
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.io.Closeable
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

data class IceSessionConfig(
    val sessionId: String = UUID.randomUUID().toString(),
    val localNodeId: String,
    val remoteNodeId: String,
    val isInitiator: Boolean,
    val stunServers: List<StunServerConfig> = emptyList(),
    val turnServers: List<TurnServerConfig> = emptyList(),
    val forceRelayOnly: Boolean = false
)

interface IceSessionCallbacks {
    fun onLocalOfferCreated(sdp: String)
    fun onLocalAnswerCreated(sdp: String)
    fun onLocalIceCandidate(candidate: IceCandidateInfo)
    fun onGatheringStateChanged(state: IceGatheringProgress)
    fun onConnectionStateChanged(state: IceConnectionStatus)
    fun onSelectedCandidatePairChanged(
        localCandidateType: IceCandidateType,
        remoteCandidateType: IceCandidateType,
        pairSummary: String,
        activePathType: TransportPathType
    )
    fun onDataChannelOpen(channel: TransportChannel)
    fun onError(reason: String)
}

interface IcePeerSession : Closeable {
    val sessionId: String
    val remoteNodeId: String
    fun startOffer()
    fun acceptRemoteOfferAndCreateAnswer(remoteOfferSdp: String)
    fun acceptRemoteAnswer(remoteAnswerSdp: String)
    fun addRemoteCandidate(candidate: IceCandidateInfo): Boolean
    fun restartIce()
}

/**
 * Abstraction over the maintained ICE/WebRTC stack (`io.getstream:stream-webrtc-android`).
 * Production builds on Android use [WebRtcIceEngine]. JVM/Robolectric unit tests where
 * native Android JNI binaries (`libjingle_peerconnection_so`) are unavailable can inject
 * an explicit test engine implementing this same contract.
 */
interface IceEngine : Closeable {
    val engineName: String
    val isNativeAvailable: Boolean
    fun createSession(config: IceSessionConfig, callbacks: IceSessionCallbacks): IcePeerSession
}

/**
 * Real Android WebRTC ICE/STUN/TURN/DataChannel engine powered by
 * `io.getstream:stream-webrtc-android:1.3.10` (`org.webrtc.*`).
 *
 * Uses established RFC 8445 ICE agent, STUN srflx gathering, TURN UDP/TCP/TLS
 * relay allocation, ICE connectivity checks, candidate pair prioritization,
 * `restartIce()`, and ordered/reliable SCTP `DataChannel` adapted into [TransportChannel].
 */
class WebRtcIceEngine(
    private val context: Context
) : IceEngine {

    companion object {
        private const val TAG = "WebRtcIceEngine"
        private const val DATA_CHANNEL_LABEL = "nmd-p2p-v3"
        private val factoryInitialized = AtomicBoolean(false)
    }

    override val engineName: String = "Stream WebRTC Android SDK 1.3.10 (org.webrtc)"

    private val peerConnectionFactory: PeerConnectionFactory? by lazy {
        initFactorySafely()
    }

    override val isNativeAvailable: Boolean
        get() = peerConnectionFactory != null

    private fun initFactorySafely(): PeerConnectionFactory? {
        return try {
            if (factoryInitialized.compareAndSet(false, true)) {
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                        .setEnableInternalTracer(false)
                        .createInitializationOptions()
                )
            }
            PeerConnectionFactory.builder()
                .setOptions(PeerConnectionFactory.Options())
                .createPeerConnectionFactory()
        } catch (t: Throwable) {
            Log.w(TAG, "Native WebRTC PeerConnectionFactory unavailable in current environment: ${t.message}")
            null
        }
    }

    override fun createSession(config: IceSessionConfig, callbacks: IceSessionCallbacks): IcePeerSession {
        val factory = peerConnectionFactory
            ?: throw IllegalStateException("Native WebRTC library not loaded in current runtime")
        return WebRtcIcePeerSession(factory, config, callbacks)
    }

    override fun close() {
        try {
            peerConnectionFactory?.dispose()
        } catch (_: Exception) {
        }
    }

    private class WebRtcIcePeerSession(
        factory: PeerConnectionFactory,
        private val config: IceSessionConfig,
        private val callbacks: IceSessionCallbacks
    ) : IcePeerSession {

        override val sessionId: String = config.sessionId
        override val remoteNodeId: String = config.remoteNodeId

        private val closed = AtomicBoolean(false)
        @Volatile
        private var currentPathType: TransportPathType = TransportPathType.ICE_DIRECT
        @Volatile
        private var currentCandidateType: IceCandidateType? = null
        @Volatile
        private var activeDataChannel: DataChannel? = null
        @Volatile
        private var bridgedChannel: BufferedStreamTransportChannel? = null

        private val peerConnection: PeerConnection

        init {
            val iceServers = mutableListOf<PeerConnection.IceServer>()
            config.stunServers
                .filter { it.enabled && it.isValidConfig() }
                .forEach { stun ->
                    iceServers.add(PeerConnection.IceServer.builder(stun.uri).createIceServer())
                }
            config.turnServers
                .filter { it.isCredentialValid() }
                .forEach { turn ->
                    iceServers.add(
                        PeerConnection.IceServer.builder(turn.effectiveIceUri())
                            .setUsername(turn.username)
                            .setPassword(turn.credential)
                            .createIceServer()
                    )
                }

            val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
                iceTransportsType = if (config.forceRelayOnly) {
                    PeerConnection.IceTransportsType.RELAY
                } else {
                    PeerConnection.IceTransportsType.ALL
                }
                bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
                rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
                iceCandidatePoolSize = 2
            }

            val created = factory.createPeerConnection(rtcConfig, createObserver())
                ?: throw IllegalStateException("WebRTC failed creating PeerConnection")
            peerConnection = created

            if (config.isInitiator) {
                val dcInit = DataChannel.Init().apply {
                    ordered = true
                    maxRetransmits = -1
                }
                val dc = peerConnection.createDataChannel(DATA_CHANNEL_LABEL, dcInit)
                if (dc != null) {
                    attachDataChannel(dc)
                }
            }
        }

        override fun startOffer() {
            if (closed.get()) return
            peerConnection.createOffer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(desc: SessionDescription?) {
                    if (desc == null || closed.get()) return
                    peerConnection.setLocalDescription(object : SimpleSdpObserver() {
                        override fun onSetSuccess() {
                            callbacks.onLocalOfferCreated(desc.description)
                        }

                        override fun onSetFailure(error: String?) {
                            callbacks.onError("setLocalDescription(offer) failed: $error")
                        }
                    }, desc)
                }

                override fun onCreateFailure(error: String?) {
                    callbacks.onError("createOffer failed: $error")
                }
            }, MediaConstraints())
        }

        override fun acceptRemoteOfferAndCreateAnswer(remoteOfferSdp: String) {
            if (closed.get()) return
            val remoteDesc = SessionDescription(SessionDescription.Type.OFFER, remoteOfferSdp)
            peerConnection.setRemoteDescription(object : SimpleSdpObserver() {
                override fun onSetSuccess() {
                    if (closed.get()) return
                    peerConnection.createAnswer(object : SimpleSdpObserver() {
                        override fun onCreateSuccess(answerDesc: SessionDescription?) {
                            if (answerDesc == null || closed.get()) return
                            peerConnection.setLocalDescription(object : SimpleSdpObserver() {
                                override fun onSetSuccess() {
                                    callbacks.onLocalAnswerCreated(answerDesc.description)
                                }

                                override fun onSetFailure(error: String?) {
                                    callbacks.onError("setLocalDescription(answer) failed: $error")
                                }
                            }, answerDesc)
                        }

                        override fun onCreateFailure(error: String?) {
                            callbacks.onError("createAnswer failed: $error")
                        }
                    }, MediaConstraints())
                }

                override fun onSetFailure(error: String?) {
                    callbacks.onError("setRemoteDescription(offer) failed: $error")
                }
            }, remoteDesc)
        }

        override fun acceptRemoteAnswer(remoteAnswerSdp: String) {
            if (closed.get()) return
            val remoteDesc = SessionDescription(SessionDescription.Type.ANSWER, remoteAnswerSdp)
            peerConnection.setRemoteDescription(object : SimpleSdpObserver() {
                override fun onSetFailure(error: String?) {
                    callbacks.onError("setRemoteDescription(answer) failed: $error")
                }
            }, remoteDesc)
        }

        override fun addRemoteCandidate(candidate: IceCandidateInfo): Boolean {
            if (closed.get()) return false
            val iceCandidate = IceCandidate(candidate.sdpMid, candidate.sdpMLineIndex, candidate.rawSdp)
            return peerConnection.addIceCandidate(iceCandidate)
        }

        override fun restartIce() {
            if (closed.get()) return
            peerConnection.restartIce()
            if (config.isInitiator) {
                startOffer()
            }
        }

        private fun createObserver(): PeerConnection.Observer {
            return object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState?) = Unit

                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    val mapped = when (state) {
                        PeerConnection.IceConnectionState.NEW -> IceConnectionStatus.NEW
                        PeerConnection.IceConnectionState.CHECKING -> IceConnectionStatus.CHECKING
                        PeerConnection.IceConnectionState.CONNECTED -> IceConnectionStatus.CONNECTED
                        PeerConnection.IceConnectionState.COMPLETED -> IceConnectionStatus.COMPLETED
                        PeerConnection.IceConnectionState.FAILED -> IceConnectionStatus.FAILED
                        PeerConnection.IceConnectionState.DISCONNECTED -> IceConnectionStatus.DISCONNECTED
                        PeerConnection.IceConnectionState.CLOSED -> IceConnectionStatus.CLOSED
                        null -> IceConnectionStatus.NEW
                    }
                    callbacks.onConnectionStateChanged(mapped)
                }

                override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit

                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
                    val mapped = when (state) {
                        PeerConnection.IceGatheringState.NEW -> IceGatheringProgress.NEW
                        PeerConnection.IceGatheringState.GATHERING -> IceGatheringProgress.GATHERING
                        PeerConnection.IceGatheringState.COMPLETE -> IceGatheringProgress.COMPLETE
                        null -> IceGatheringProgress.NEW
                    }
                    callbacks.onGatheringStateChanged(mapped)
                }

                override fun onIceCandidate(candidate: IceCandidate?) {
                    if (candidate == null || closed.get()) return
                    val parsed = IceCandidateInfo.parseSafe(
                        rawSdp = candidate.sdp,
                        sdpMid = candidate.sdpMid ?: "0",
                        sdpMLineIndex = candidate.sdpMLineIndex
                    )
                    if (parsed != null) {
                        callbacks.onLocalIceCandidate(parsed)
                    }
                }

                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) = Unit

                override fun onSelectedCandidatePairChanged(event: CandidatePairChangeEvent?) {
                    if (event == null) return
                    val localParsed = IceCandidateInfo.parseSafe(event.local.sdp)
                    val remoteParsed = IceCandidateInfo.parseSafe(event.remote.sdp)
                    val localType = localParsed?.type ?: IceCandidateType.UNKNOWN
                    val remoteType = remoteParsed?.type ?: IceCandidateType.UNKNOWN
                    val isRelay = localType == IceCandidateType.RELAY || remoteType == IceCandidateType.RELAY
                    val path = if (isRelay) TransportPathType.TURN_RELAY else TransportPathType.ICE_DIRECT
                    currentPathType = path
                    currentCandidateType = if (isRelay) IceCandidateType.RELAY else localType
                    bridgedChannel?.updatePathMetadata(path, currentCandidateType)
                    val summary = "${localType.sdpToken}(${localParsed?.address ?: "?"}) <-> ${remoteType.sdpToken}(${remoteParsed?.address ?: "?"})"
                    callbacks.onSelectedCandidatePairChanged(localType, remoteType, summary, path)
                }

                override fun onAddStream(stream: org.webrtc.MediaStream?) = Unit
                override fun onRemoveStream(stream: org.webrtc.MediaStream?) = Unit

                override fun onDataChannel(dc: DataChannel?) {
                    if (dc != null && !closed.get()) {
                        attachDataChannel(dc)
                    }
                }

                override fun onRenegotiationNeeded() = Unit
                override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out org.webrtc.MediaStream>?) = Unit
            }
        }

        private fun attachDataChannel(dc: DataChannel) {
            activeDataChannel = dc
            val channelAdapter = BufferedStreamTransportChannel(
                channelId = sessionId,
                pathType = currentPathType,
                selectedCandidateType = currentCandidateType,
                remoteAddressLabel = "webrtc://${config.remoteNodeId.take(12)}",
                sendPacket = { bytes ->
                    val currentDc = activeDataChannel
                    if (closed.get() || currentDc == null || currentDc.state() != DataChannel.State.OPEN) {
                        false
                    } else {
                        currentDc.send(DataChannel.Buffer(ByteBuffer.wrap(bytes), true))
                    }
                },
                onCloseCallback = { close() }
            )
            bridgedChannel = channelAdapter

            dc.registerObserver(object : DataChannel.Observer {
                override fun onBufferedAmountChange(previousAmount: Long) = Unit

                override fun onStateChange() {
                    when (dc.state()) {
                        DataChannel.State.OPEN -> callbacks.onDataChannelOpen(channelAdapter)
                        DataChannel.State.CLOSING, DataChannel.State.CLOSED -> channelAdapter.close()
                        else -> Unit
                    }
                }

                override fun onMessage(buffer: DataChannel.Buffer?) {
                    val buf = buffer?.data ?: return
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    channelAdapter.deliverIncomingBytes(bytes)
                }
            })
        }

        override fun close() {
            if (closed.compareAndSet(false, true)) {
                try {
                    activeDataChannel?.close()
                    activeDataChannel?.dispose()
                } catch (_: Exception) {
                }
                try {
                    peerConnection.close()
                    peerConnection.dispose()
                } catch (_: Exception) {
                }
                bridgedChannel?.close()
            }
        }
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) = Unit
        override fun onSetSuccess() = Unit
        override fun onCreateFailure(error: String?) = Unit
        override fun onSetFailure(error: String?) = Unit
    }
}
