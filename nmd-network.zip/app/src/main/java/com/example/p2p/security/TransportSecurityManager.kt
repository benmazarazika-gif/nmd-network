package com.example.p2p.security

import android.content.Context
import android.util.Log
import com.example.crypto.NodeIdentityManager
import com.example.p2p.model.FrameType
import com.example.p2p.security.crypto.DecryptedFrameResult
import com.example.p2p.security.crypto.EncryptedTransportSession
import com.example.p2p.security.crypto.FrameDecryptOutcome
import com.example.p2p.security.guard.ConnectionAbuseProtector
import com.example.p2p.security.guard.GuardAdmissionResult
import com.example.p2p.security.handshake.SecureSessionHandshakeService
import com.example.p2p.security.handshake.SecurityHandshakeException
import com.example.p2p.security.model.NetworkSecurityUiState
import com.example.p2p.security.model.PeerSecurityStatusSummary
import com.example.p2p.security.model.PeerTrustState
import com.example.p2p.security.model.SecurityEventRecord
import com.example.p2p.security.model.SecurityEventType
import com.example.p2p.security.model.TransportSecurityConfig
import com.example.p2p.security.model.TransportSecurityStatus
import com.example.p2p.security.trust.PeerTrustManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

sealed class IncomingSecurityResult {
    data class PlaintextFrame(val result: DecryptedFrameResult) : IncomingSecurityResult()
    data class SecurityViolation(
        val eventType: SecurityEventType,
        val reason: String,
        val terminateConnection: Boolean = true
    ) : IncomingSecurityResult()
}

/**
 * Coordinates Stage 13 transport security for NMD P2P connections:
 * - Connection abuse protection (flood limits, pending handshake caps, cooldowns)
 * - Authenticated X25519 + Ed25519 key establishment (no legacy downgrade)
 * - In-memory ChaCha20-Poly1305 AEAD transport encryption & sliding replay defense
 * - Peer trust pinning & persistent revocation enforcement
 * - Live security observability state without exposing cryptographic secrets
 */
class TransportSecurityManager(
    context: Context? = null,
    private val identityManager: NodeIdentityManager,
    val config: TransportSecurityConfig = TransportSecurityConfig(),
    val trustManager: PeerTrustManager = PeerTrustManager(
        context = context,
        preferencesName = "nmd_p2p_trust_${identityManager.getActiveIdentity()?.nodeId?.take(16) ?: "default"}",
        cryptoProvider = identityManager.repository.cryptoProvider,
        rejectUnexpectedIdentityChange = config.rejectUnexpectedIdentityChange
    ),
    val abuseProtector: ConnectionAbuseProtector = ConnectionAbuseProtector(config),
    val handshakeService: SecureSessionHandshakeService = SecureSessionHandshakeService(
        identityManager = identityManager,
        trustManager = trustManager,
        config = config,
        cryptoProvider = identityManager.repository.cryptoProvider,
        context = context
    )
) : Closeable {

    companion object {
        private const val TAG = "TransportSecurityMgr"
        private const val MAX_RECENT_EVENTS = 25
    }

    private data class ActiveSessionEntry(
        val connectionId: String,
        val endpointFormatted: String,
        val session: EncryptedTransportSession,
        val onForceDisconnect: (() -> Unit)?
    )

    private val lock = Any()
    private val closed = AtomicBoolean(false)
    private val activeSessions = ConcurrentHashMap<String, ActiveSessionEntry>()
    private val connectingCount = AtomicInteger(0)
    private val outboundAuthenticatingCount = AtomicInteger(0)
    private val inboundAuthenticatingCount = AtomicInteger(0)
    private val failedHandshakesCount = AtomicLong(0L)
    private val rejectedReplaysCount = AtomicLong(0L)
    private val recentEvents = ArrayDeque<SecurityEventRecord>(MAX_RECENT_EVENTS)
    @Volatile
    private var lastOverallStatusOverride: TransportSecurityStatus? = null

    private val _uiState = MutableStateFlow(
        NetworkSecurityUiState(
            status = TransportSecurityStatus.DISCONNECTED,
            encryptionProtocolId = config.cipherSuiteId,
            protocolVersion = config.protocolVersion,
            chainId = config.chainId,
            revokedPeersCount = trustManager.getRevokedRecords().size,
            revokedPeerIds = trustManager.getRevokedRecords().map { it.nodeId }
        )
    )
    val uiState: StateFlow<NetworkSecurityUiState> = _uiState.asStateFlow()

    fun checkInboundAdmission(remoteHost: String): GuardAdmissionResult {
        if (closed.get()) {
            return GuardAdmissionResult.Rejected("TransportSecurityManager is closed")
        }
        val result = abuseProtector.tryAcquirePendingHandshakeSlot(remoteHost)
        if (result is GuardAdmissionResult.Rejected) {
            recordEvent(
                type = SecurityEventType.FLOOD_OR_RATE_LIMITED,
                peerIdOrHost = remoteHost,
                summary = result.reason,
                isFailure = true
            )
            refreshUiState()
        }
        return result
    }

    fun releaseInboundAdmissionSlot() {
        abuseProtector.releaseUnauthenticatedSlot()
        refreshUiState()
    }

    fun checkOutboundAdmission(hostOrPeerKey: String): GuardAdmissionResult {
        if (closed.get()) {
            return GuardAdmissionResult.Rejected("TransportSecurityManager is closed")
        }
        val result = abuseProtector.checkOutboundAllowed(hostOrPeerKey)
        if (result is GuardAdmissionResult.Rejected) {
            recordEvent(
                type = SecurityEventType.FLOOD_OR_RATE_LIMITED,
                peerIdOrHost = hostOrPeerKey,
                summary = result.reason,
                isFailure = true
            )
            refreshUiState()
        }
        return result
    }

    fun beginConnecting(): Boolean {
        if (closed.get()) return false
        connectingCount.incrementAndGet()
        lastOverallStatusOverride = null
        refreshUiState()
        return true
    }

    fun endConnecting() {
        val current = connectingCount.get()
        if (current > 0) connectingCount.decrementAndGet()
        refreshUiState()
    }

    @Throws(IOException::class)
    fun performOutboundHandshake(
        connectionId: String,
        endpointFormatted: String,
        inputStream: InputStream,
        outputStream: OutputStream,
        expectedRemoteNodeId: String? = null,
        onForceDisconnect: (() -> Unit)? = null,
        nowProvider: () -> Long = { System.currentTimeMillis() }
    ): EncryptedTransportSession {
        if (closed.get()) {
            throw IOException("TransportSecurityManager is closed")
        }
        outboundAuthenticatingCount.incrementAndGet()
        lastOverallStatusOverride = null
        recordEvent(
            type = SecurityEventType.HANDSHAKE_STARTED,
            peerIdOrHost = expectedRemoteNodeId ?: endpointFormatted,
            summary = "Initiating X25519+Ed25519 encrypted handshake with $endpointFormatted",
            isFailure = false
        )
        refreshUiState()

        return try {
            val outcome = handshakeService.performInitiatorHandshake(
                inputStream = inputStream,
                outputStream = outputStream,
                expectedRemoteNodeId = expectedRemoteNodeId,
                remoteEndpointKey = endpointFormatted,
                nowProvider = nowProvider
            )
            val session = outcome.encryptedSession
            activeSessions[connectionId] = ActiveSessionEntry(
                connectionId = connectionId,
                endpointFormatted = endpointFormatted,
                session = session,
                onForceDisconnect = onForceDisconnect
            )
            abuseProtector.recordAuthSuccess(endpointFormatted.substringBefore(":"))
            abuseProtector.recordAuthSuccess(session.remoteNodeId)

            recordEvent(
                type = SecurityEventType.HANDSHAKE_AUTHENTICATED,
                peerIdOrHost = session.remoteNodeId,
                summary = "Mutual Ed25519 & ChaCha20-Poly1305 session established (${outcome.latencyMs}ms)",
                isFailure = false
            )
            recordEvent(
                type = SecurityEventType.ENCRYPTED_SESSION_ACTIVE,
                peerIdOrHost = session.remoteNodeId,
                summary = "Encrypted session ${session.sessionId.take(12)} active with ${endpointFormatted}",
                isFailure = false
            )
            refreshUiState()
            session
        } catch (e: Exception) {
            handleHandshakeFailure(endpointFormatted, expectedRemoteNodeId, e)
            throw e
        } finally {
            val c = outboundAuthenticatingCount.get()
            if (c > 0) outboundAuthenticatingCount.decrementAndGet()
            refreshUiState()
        }
    }

    @Throws(IOException::class)
    fun performInboundHandshake(
        connectionId: String,
        remoteHost: String,
        endpointFormatted: String,
        inputStream: InputStream,
        outputStream: OutputStream,
        onForceDisconnect: (() -> Unit)? = null,
        nowProvider: () -> Long = { System.currentTimeMillis() }
    ): EncryptedTransportSession {
        if (closed.get()) {
            throw IOException("TransportSecurityManager is closed")
        }
        inboundAuthenticatingCount.incrementAndGet()
        lastOverallStatusOverride = null
        recordEvent(
            type = SecurityEventType.HANDSHAKE_STARTED,
            peerIdOrHost = endpointFormatted,
            summary = "Inbound X25519+Ed25519 encrypted handshake from $endpointFormatted",
            isFailure = false
        )
        refreshUiState()

        return try {
            val outcome = handshakeService.performResponderHandshake(
                inputStream = inputStream,
                outputStream = outputStream,
                remoteEndpointKey = endpointFormatted,
                nowProvider = nowProvider
            )
            val session = outcome.encryptedSession
            activeSessions[connectionId] = ActiveSessionEntry(
                connectionId = connectionId,
                endpointFormatted = endpointFormatted,
                session = session,
                onForceDisconnect = onForceDisconnect
            )
            abuseProtector.recordAuthSuccess(remoteHost)
            abuseProtector.recordAuthSuccess(session.remoteNodeId)

            recordEvent(
                type = SecurityEventType.HANDSHAKE_AUTHENTICATED,
                peerIdOrHost = session.remoteNodeId,
                summary = "Inbound peer authenticated & encrypted (${outcome.latencyMs}ms)",
                isFailure = false
            )
            refreshUiState()
            session
        } catch (e: Exception) {
            handleHandshakeFailure(remoteHost, null, e)
            throw e
        } finally {
            val c = inboundAuthenticatingCount.get()
            if (c > 0) inboundAuthenticatingCount.decrementAndGet()
            refreshUiState()
        }
    }

    private fun handleHandshakeFailure(
        hostOrEndpoint: String,
        expectedNodeId: String?,
        error: Exception
    ) {
        failedHandshakesCount.incrementAndGet()
        val hostOnly = hostOrEndpoint.substringBefore(":")
        val eventType = if (error is SecurityHandshakeException) error.eventType else SecurityEventType.HANDSHAKE_FAILED

        if (eventType == SecurityEventType.REPLAY_REJECTED) {
            rejectedReplaysCount.incrementAndGet()
        }
        if (eventType == SecurityEventType.PEER_REVOKED) {
            lastOverallStatusOverride = TransportSecurityStatus.PEER_REVOKED
        } else {
            lastOverallStatusOverride = TransportSecurityStatus.AUTHENTICATION_FAILED
        }

        val triggeredCooldown = abuseProtector.recordAuthFailure(hostOnly)
        if (!expectedNodeId.isNullOrBlank()) {
            abuseProtector.recordAuthFailure(expectedNodeId)
        }

        recordEvent(
            type = eventType,
            peerIdOrHost = expectedNodeId ?: hostOrEndpoint,
            summary = error.message ?: "Handshake authentication failed",
            isFailure = true
        )
        if (triggeredCooldown) {
            recordEvent(
                type = SecurityEventType.FLOOD_OR_RATE_LIMITED,
                peerIdOrHost = hostOnly,
                summary = "Cooldown engaged for $hostOnly after repeated auth failures",
                isFailure = true
            )
        }
        refreshUiState()
    }

    fun getActiveSession(connectionId: String): EncryptedTransportSession? {
        return activeSessions[connectionId]?.session
    }

    fun getRemoteNodeId(connectionId: String): String? {
        return activeSessions[connectionId]?.session?.remoteNodeId
    }

    fun hasActiveEncryptedSession(connectionId: String, nowMs: Long = System.currentTimeMillis()): Boolean {
        val entry = activeSessions[connectionId] ?: return false
        return entry.session.isActive(nowMs) && !trustManager.isPeerRevoked(entry.session.remoteNodeId, entry.session.remotePublicKeyHex)
    }

    @Throws(IOException::class)
    fun encryptOutgoing(
        connectionId: String,
        innerFrameType: Byte,
        plaintext: ByteArray,
        nowMs: Long = System.currentTimeMillis()
    ): ByteArray {
        val entry = activeSessions[connectionId]
            ?: throw IOException("No active encrypted transport session for connection $connectionId")

        if (trustManager.isPeerRevoked(entry.session.remoteNodeId, entry.session.remotePublicKeyHex)) {
            terminateSession(connectionId, "Peer identity was revoked", disconnectSocket = true)
            throw IOException("Refusing to transmit to revoked peer ${entry.session.remoteNodeId}")
        }
        if (plaintext.size > config.maxInnerPlaintextBytes) {
            recordEvent(
                type = SecurityEventType.OVERSIZED_FRAME_REJECTED,
                peerIdOrHost = entry.session.remoteNodeId,
                summary = "Outbound plaintext (${plaintext.size} B) exceeds limit ${config.maxInnerPlaintextBytes} B",
                isFailure = true
            )
            refreshUiState()
            throw IOException("Outbound plaintext exceeds maximum limit")
        }

        return try {
            val encrypted = entry.session.encryptFrame(innerFrameType, plaintext, nowMs)
            refreshUiState()
            encrypted
        } catch (e: IOException) {
            if (entry.session.isExpired(nowMs)) {
                recordEvent(
                    type = SecurityEventType.SESSION_EXPIRED,
                    peerIdOrHost = entry.session.remoteNodeId,
                    summary = "Session ${entry.session.sessionId.take(12)} expired; re-handshake required",
                    isFailure = true
                )
                terminateSession(connectionId, e.message ?: "Session expired", disconnectSocket = true)
            }
            throw e
        }
    }

    fun decryptAndAuthorizeIncoming(
        connectionId: String,
        wireFrameType: Byte,
        wirePayload: ByteArray,
        nowMs: Long = System.currentTimeMillis()
    ): IncomingSecurityResult {
        val entry = activeSessions[connectionId]
            ?: return IncomingSecurityResult.SecurityViolation(
                eventType = SecurityEventType.HANDSHAKE_FAILED,
                reason = "Unauthenticated frame received without active encrypted session"
            )
        val remoteNodeId = entry.session.remoteNodeId

        if (trustManager.isPeerRevoked(remoteNodeId, entry.session.remotePublicKeyHex)) {
            recordEvent(
                type = SecurityEventType.PEER_REVOKED,
                peerIdOrHost = remoteNodeId,
                summary = "Terminating session for revoked peer $remoteNodeId",
                isFailure = true
            )
            terminateSession(connectionId, "Peer revoked", disconnectSocket = true)
            return IncomingSecurityResult.SecurityViolation(
                eventType = SecurityEventType.PEER_REVOKED,
                reason = "Peer $remoteNodeId is revoked"
            )
        }

        if (wireFrameType != FrameType.ENCRYPTED_FRAME) {
            val eventType = if (wireFrameType == FrameType.HANDSHAKE_HELLO ||
                wireFrameType == FrameType.HANDSHAKE_RESPONSE ||
                wireFrameType == FrameType.PROTOCOL_MESSAGE ||
                wireFrameType == FrameType.RELIABLE_MSG
            ) {
                SecurityEventType.DOWNGRADE_REJECTED
            } else {
                SecurityEventType.MALFORMED_FRAME_REJECTED
            }
            val msg = "Rejected unencrypted post-handshake frame type 0x%02X (downgrade blocked)".format(wireFrameType)
            recordEvent(eventType, remoteNodeId, msg, isFailure = true)
            lastOverallStatusOverride = TransportSecurityStatus.AUTHENTICATION_FAILED
            refreshUiState()
            return IncomingSecurityResult.SecurityViolation(eventType, msg, terminateConnection = true)
        }

        when (val rateCheck = abuseProtector.checkPeerMessageRate(remoteNodeId, nowMs)) {
            is GuardAdmissionResult.Rejected -> {
                recordEvent(SecurityEventType.FLOOD_OR_RATE_LIMITED, remoteNodeId, rateCheck.reason, isFailure = true)
                refreshUiState()
                return IncomingSecurityResult.SecurityViolation(
                    eventType = SecurityEventType.FLOOD_OR_RATE_LIMITED,
                    reason = rateCheck.reason,
                    terminateConnection = true
                )
            }
            GuardAdmissionResult.Allowed -> Unit
        }

        if (wirePayload.size > config.maxEncryptedFrameBytes) {
            val msg = "Encrypted frame size (${wirePayload.size} B) exceeds limit ${config.maxEncryptedFrameBytes} B"
            recordEvent(SecurityEventType.OVERSIZED_FRAME_REJECTED, remoteNodeId, msg, isFailure = true)
            refreshUiState()
            return IncomingSecurityResult.SecurityViolation(SecurityEventType.OVERSIZED_FRAME_REJECTED, msg)
        }

        return when (val outcome = entry.session.decryptFrame(wirePayload, nowMs)) {
            is FrameDecryptOutcome.Success -> {
                refreshUiState()
                IncomingSecurityResult.PlaintextFrame(outcome.result)
            }
            is FrameDecryptOutcome.Rejected -> {
                val eventType = when {
                    outcome.isExpired -> SecurityEventType.SESSION_EXPIRED
                    outcome.isReplay -> {
                        rejectedReplaysCount.incrementAndGet()
                        if (outcome.reason.contains("cross-session", ignoreCase = true) ||
                            outcome.reason.contains("Stale", ignoreCase = true)
                        ) {
                            SecurityEventType.STALE_SESSION_REJECTED
                        } else {
                            SecurityEventType.REPLAY_REJECTED
                        }
                    }
                    else -> SecurityEventType.AEAD_DECRYPT_FAILED
                }
                recordEvent(eventType, remoteNodeId, outcome.reason, isFailure = true)
                refreshUiState()
                IncomingSecurityResult.SecurityViolation(eventType, outcome.reason, terminateConnection = true)
            }
        }
    }

    fun terminateSession(
        connectionId: String,
        reason: String = "Session closed",
        disconnectSocket: Boolean = false
    ) {
        val removed = activeSessions.remove(connectionId)
        if (removed != null) {
            removed.session.close()
            if (disconnectSocket) {
                try {
                    removed.onForceDisconnect?.invoke()
                } catch (_: Exception) {
                }
            }
            Log.d(TAG, "Terminated encrypted session ${removed.session.sessionId}: $reason")
            refreshUiState()
        }
    }

    fun revokePeerIdentity(
        nodeId: String,
        publicKeyHex: String? = null,
        reason: String = "Revoked via Network Security dashboard"
    ): Int {
        val matchingEntry = activeSessions.values.find { it.session.remoteNodeId.equals(nodeId, ignoreCase = true) }
        val effectivePubKey = publicKeyHex ?: matchingEntry?.session?.remotePublicKeyHex
        trustManager.revokePeerIdentity(nodeId, effectivePubKey, reason)

        var terminatedCount = 0
        val toTerminate = activeSessions.values.filter { it.session.remoteNodeId.equals(nodeId, ignoreCase = true) }
        toTerminate.forEach { entry ->
            terminateSession(entry.connectionId, "Peer identity revoked: $reason", disconnectSocket = true)
            terminatedCount++
        }

        lastOverallStatusOverride = if (activeSessions.isEmpty()) TransportSecurityStatus.PEER_REVOKED else null
        recordEvent(
            type = SecurityEventType.PEER_REVOKED,
            peerIdOrHost = nodeId,
            summary = "Peer identity revoked ($reason); terminated $terminatedCount active session(s)",
            isFailure = true
        )
        refreshUiState()
        return terminatedCount
    }

    fun unrevokePeerIdentity(nodeId: String): Boolean {
        val ok = trustManager.unrevokePeerIdentity(nodeId)
        if (ok) {
            lastOverallStatusOverride = null
            refreshUiState()
        }
        return ok
    }

    fun rotateAllSessions(reason: String = "Manual encrypted session key rotation"): Int {
        val ids = activeSessions.keys.toList()
        ids.forEach { connId ->
            terminateSession(connId, reason, disconnectSocket = true)
        }
        recordEvent(
            type = SecurityEventType.SESSION_ROTATED,
            peerIdOrHost = "local_node",
            summary = "$reason: cleared ${ids.size} session(s); peers will re-handshake with fresh X25519 keys",
            isFailure = false
        )
        refreshUiState()
        return ids.size
    }

    fun sweepExpiredSessions(nowMs: Long = System.currentTimeMillis()): Int {
        val expired = activeSessions.values.filter { it.session.isExpired(nowMs) }
        expired.forEach { entry ->
            recordEvent(
                type = SecurityEventType.SESSION_EXPIRED,
                peerIdOrHost = entry.session.remoteNodeId,
                summary = "Session ${entry.session.sessionId.take(12)} reached TTL/frame limit; re-handshake required",
                isFailure = false
            )
            terminateSession(entry.connectionId, "Session TTL/frame cap expired", disconnectSocket = true)
        }
        return expired.size
    }

    fun recordExternalSecurityEvent(
        type: SecurityEventType,
        peerIdOrHost: String,
        summary: String,
        isFailure: Boolean
    ) {
        if (type == SecurityEventType.REPLAY_REJECTED) {
            rejectedReplaysCount.incrementAndGet()
        }
        recordEvent(type, peerIdOrHost, summary, isFailure)
        refreshUiState()
    }

    private fun recordEvent(
        type: SecurityEventType,
        peerIdOrHost: String,
        summary: String,
        isFailure: Boolean
    ) {
        synchronized(lock) {
            val rec = SecurityEventRecord(
                id = UUID.randomUUID().toString(),
                type = type,
                peerIdOrHost = peerIdOrHost,
                summary = summary,
                isFailure = isFailure,
                timestampMs = System.currentTimeMillis()
            )
            recentEvents.addFirst(rec)
            while (recentEvents.size > MAX_RECENT_EVENTS) {
                recentEvents.removeLast()
            }
        }
    }

    fun refreshUiState(nowMs: Long = System.currentTimeMillis()) {
        val sessions = activeSessions.values.map { entry ->
            val s = entry.session
            val isRevoked = trustManager.isPeerRevoked(s.remoteNodeId, s.remotePublicKeyHex)
            PeerSecurityStatusSummary(
                sessionId = s.sessionId,
                peerId = s.remoteNodeId,
                endpointFormatted = entry.endpointFormatted,
                status = if (isRevoked) TransportSecurityStatus.PEER_REVOKED else TransportSecurityStatus.ENCRYPTED,
                trustState = trustManager.getTrustState(s.remoteNodeId),
                protocolVersion = s.protocolVersion,
                cipherSuiteId = s.cipherSuiteId,
                framesSent = s.framesSentCount(),
                framesReceived = s.framesReceivedCount(),
                expiresAtMs = s.expiresAtMs,
                isOutbound = s.isOutbound
            )
        }.sortedByDescending { it.expiresAtMs }

        val totalAuthenticating = outboundAuthenticatingCount.get() + inboundAuthenticatingCount.get()
        val pendingHandshakes = outboundAuthenticatingCount.get() + abuseProtector.currentPendingHandshakesCount()
        val revokedRecords = trustManager.getRevokedRecords()
        val eventsSnapshot: List<SecurityEventRecord> = synchronized(lock) { recentEvents.toList() }

        val derivedStatus = when {
            sessions.isNotEmpty() -> TransportSecurityStatus.SECURE
            totalAuthenticating > 0 -> TransportSecurityStatus.AUTHENTICATING
            connectingCount.get() > 0 -> TransportSecurityStatus.CONNECTING
            lastOverallStatusOverride != null -> lastOverallStatusOverride!!
            else -> TransportSecurityStatus.DISCONNECTED
        }

        _uiState.value = NetworkSecurityUiState(
            status = derivedStatus,
            encryptionProtocolId = config.cipherSuiteId,
            protocolVersion = config.protocolVersion,
            chainId = config.chainId,
            authenticatedPeersCount = sessions.size,
            encryptedSessionsCount = sessions.size,
            pendingHandshakesCount = pendingHandshakes,
            failedHandshakesCount = failedHandshakesCount.get(),
            rejectedReplaysCount = rejectedReplaysCount.get(),
            rateLimitedPeersCount = abuseProtector.currentRateLimitedKeysCount(nowMs),
            revokedPeersCount = revokedRecords.size,
            peerStatuses = sessions,
            revokedPeerIds = revokedRecords.map { it.nodeId },
            lastSecurityEvent = eventsSnapshot.firstOrNull(),
            recentEvents = eventsSnapshot
        )
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            activeSessions.keys.toList().forEach { id ->
                terminateSession(id, "TransportSecurityManager closed", disconnectSocket = true)
            }
            activeSessions.clear()
            connectingCount.set(0)
            outboundAuthenticatingCount.set(0)
            inboundAuthenticatingCount.set(0)
            refreshUiState()
        }
    }
}
