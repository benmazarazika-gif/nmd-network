package com.example.p2p.scalability

import android.content.Context
import com.example.consensus.config.ConsensusConfig
import com.example.consensus.validator.ValidatorEligibilityRegistry
import com.example.crypto.NodeIdentityManager
import com.example.p2p.connectivity.PeerConnectivityManager
import com.example.p2p.connectivity.model.StunServerStatus
import com.example.p2p.connectivity.model.TurnRelayStatus
import com.example.p2p.discovery.DistributedDiscoveryCoordinator
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.topology.NetworkTopologyManager
import com.example.p2p.infrastructure.NetworkInfrastructureCoordinator
import com.example.p2p.infrastructure.model.EndpointHealthState
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.scalability.circuit.CircuitBreakerManager
import com.example.p2p.scalability.congestion.NetworkCongestionController
import com.example.p2p.scalability.connection.AdaptivePeerConnectionManager
import com.example.p2p.scalability.connection.ConnectionMaintenanceReport
import com.example.p2p.scalability.health.PeerHealthMonitor
import com.example.p2p.scalability.model.CircuitBreakerState
import com.example.p2p.scalability.model.CircuitBreakerTargetType
import com.example.p2p.scalability.model.DeviceResourceMode
import com.example.p2p.scalability.model.NetworkScalabilitySnapshot
import com.example.p2p.scalability.model.PeerHealthStatus
import com.example.p2p.scalability.resource.DeviceNetworkResourceMonitor
import com.example.p2p.scalability.validator.ValidatorAvailabilityMonitor
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.Closeable

/**
 * Unified Stage 16 Scalability, Fault-Tolerance, Health & Resilience Coordinator.
 *
 * Ties together:
 * - [PeerHealthMonitor] (multi-signal hysteresis, RTT EWMA, quarantine/recovery)
 * - [CircuitBreakerManager] (Bootstrap, Signaling, Peer, STUN, TURN failure isolation)
 * - [NetworkCongestionController] (bounded priority queues preventing consensus starvation)
 * - [DeviceNetworkResourceMonitor] (battery/RAM/storage/network resource modes)
 * - [AdaptivePeerConnectionManager] (dynamic peer caps, churn recovery, replacement)
 * - [ValidatorAvailabilityMonitor] (BFT quorum availability telemetry)
 */
class NetworkScalabilityCoordinator(
    private val context: Context?,
    private val identityManager: NodeIdentityManager,
    private val connectionManager: PeerConnectionManager,
    private val discoveryCoordinator: DistributedDiscoveryCoordinator,
    private val connectivityManager: PeerConnectivityManager,
    private val infrastructureCoordinator: NetworkInfrastructureCoordinator,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val clockMs: () -> Long = { System.currentTimeMillis() },
    val circuitBreakerManager: CircuitBreakerManager = CircuitBreakerManager(clockMs = clockMs),
    val resourceMonitor: DeviceNetworkResourceMonitor = DeviceNetworkResourceMonitor(context = context, clockMs = clockMs),
    val peerHealthMonitor: PeerHealthMonitor = PeerHealthMonitor(
        peerRegistry = discoveryCoordinator.peerRegistry,
        trustManager = connectionManager.transportSecurityManager.trustManager,
        clockMs = clockMs
    ),
    val congestionController: NetworkCongestionController = NetworkCongestionController(clockMs = clockMs),
    val topologyManager: NetworkTopologyManager = connectionManager.topologyManager,
    val adaptiveConnectionManager: AdaptivePeerConnectionManager = AdaptivePeerConnectionManager(
        connectionManager = connectionManager,
        peerRegistry = discoveryCoordinator.peerRegistry,
        healthMonitor = peerHealthMonitor,
        circuitBreakers = circuitBreakerManager,
        resourceMonitor = resourceMonitor,
        topologyManager = topologyManager,
        clockMs = clockMs
    ),
    val validatorAvailabilityMonitor: ValidatorAvailabilityMonitor = ValidatorAvailabilityMonitor(
        healthMonitor = peerHealthMonitor,
        clockMs = clockMs
    )
) : Closeable {

    private val _snapshot = MutableStateFlow(NetworkScalabilitySnapshot())
    val snapshot: StateFlow<NetworkScalabilitySnapshot> = _snapshot.asStateFlow()

    private val recentEvents = ArrayDeque<String>()
    private var periodicJob: Job? = null

    init {
        observeExistingComponents()
        startPeriodicHealthLoop()
    }

    fun attachValidatorRegistry(
        registry: ValidatorEligibilityRegistry?,
        consensusConfig: ConsensusConfig = ConsensusConfig(),
        localValidatorId: String? = null
    ) {
        validatorAvailabilityMonitor.attachValidatorRegistry(registry, consensusConfig, localValidatorId)
        refreshSnapshot()
    }

    fun setManualResourceMode(mode: DeviceResourceMode?): NetworkScalabilitySnapshot {
        val res = resourceMonitor.setManualModeOverride(mode)
        addEvent("Resource mode set to ${res.mode.name} (${if (res.isManualOverride) "manual" else "auto"})")
        return refreshSnapshot()
    }

    fun resetAllCircuitBreakers(): NetworkScalabilitySnapshot {
        circuitBreakerManager.resetAllBreakers()
        addEvent("All circuit breakers manually reset to CLOSED")
        return refreshSnapshot()
    }

    suspend fun runHealthAndTopologySweep(attemptOutboundDial: Boolean = true): ConnectionMaintenanceReport {
        resourceMonitor.sampleAndPublish()
        peerHealthMonitor.syncFromRegistryAndTrust()
        val unquarantined = peerHealthMonitor.evaluateQuarantineCooldowns()
        if (unquarantined > 0) {
            addEvent("Transitioned $unquarantined peer(s) from QUARANTINED -> RECOVERING")
        }

        // Sync infrastructure endpoint failures into circuit breakers
        syncInfraBreakers()

        val report = if (attemptOutboundDial) {
            adaptiveConnectionManager.runAdaptiveMaintenanceSweep(identityManager.getActiveIdentity()?.nodeId)
        } else {
            ConnectionMaintenanceReport()
        }

        if (report.replacedPeerIds.isNotEmpty()) {
            addEvent("Replaced unhealthy peer(s): ${report.replacedPeerIds.joinToString { it.take(10) }}")
        }
        if (report.establishedPeerIds.isNotEmpty()) {
            addEvent("Connected ${report.establishedPeerIds.size} healthy replacement peer(s)")
        }
        if (report.prunedDownForCapCount > 0) {
            addEvent("Pruned ${report.prunedDownForCapCount} peer(s) to enforce resource cap")
        }

        congestionController.pruneExpired()
        refreshSnapshot()
        return report
    }

    fun refreshSnapshot(): NetworkScalabilitySnapshot {
        val now = clockMs()
        val resource = resourceMonitor.snapshot.value
        val connectedPeers = connectionManager.authenticatedPeers.value
        val healthList = peerHealthMonitor.records.value
        val congestion = congestionController.metrics.value
        val infra = infrastructureCoordinator.snapshot.value
        val connectivity = connectivityManager.diagnostics.value
        val allBreakers = circuitBreakerManager.snapshots.value

        // Sync STUN & TURN server probe outcomes into circuit breaker registry automatically
        connectivityManager.stunService.summary.value.probeResults.forEach { probe ->
            val targetId = probe.serverUri
            when (probe.status) {
                StunServerStatus.AVAILABLE ->
                    circuitBreakerManager.recordSuccess(CircuitBreakerTargetType.STUN, targetId)
                StunServerStatus.UNREACHABLE,
                StunServerStatus.TIMED_OUT -> {
                    if (circuitBreakerManager.getState(CircuitBreakerTargetType.STUN, targetId).state == CircuitBreakerState.CLOSED) {
                        circuitBreakerManager.recordFailure(CircuitBreakerTargetType.STUN, targetId, probe.errorReason ?: "STUN ${probe.status.name}")
                    }
                }
                else -> Unit
            }
        }
        val turnTargetId = connectivityManager.relayManager.state.value.activeAllocations.firstOrNull()?.serverUri
            ?: "turn-relay-pool"
        when (connectivity.turnStatus) {
            TurnRelayStatus.AVAILABLE,
            TurnRelayStatus.ALLOCATED,
            TurnRelayStatus.RELAYING ->
                circuitBreakerManager.recordSuccess(CircuitBreakerTargetType.TURN, turnTargetId)
            TurnRelayStatus.UNREACHABLE,
            TurnRelayStatus.FAILED,
            TurnRelayStatus.UNAVAILABLE_EXPIRED -> {
                if (circuitBreakerManager.getState(CircuitBreakerTargetType.TURN, turnTargetId).state == CircuitBreakerState.CLOSED) {
                    circuitBreakerManager.recordFailure(CircuitBreakerTargetType.TURN, turnTargetId, connectivity.turnAvailabilityMessage)
                }
            }
            TurnRelayStatus.UNCONFIGURED -> Unit
        }

        val trafficMap = connectedPeers.mapNotNull { info ->
            info.authenticatedNodeId?.let { id -> id to (info.messagesSent + info.messagesReceived) }
        }.toMap()
        val healthScoreMap = healthList.associate { it.peerId to it.stabilityScore }

        val topologyHealth = topologyManager.analyzeTopologyHealth(
            registry = discoveryCoordinator.peerRegistry,
            connectedPeers = connectedPeers,
            peerTrafficCounts = trafficMap,
            peerHealthScores = healthScoreMap
        )

        val validatorSnap = validatorAvailabilityMonitor.evaluateAvailability(
            connectedPeers = connectedPeers,
            localNodeId = identityManager.getActiveIdentity()?.nodeId
        )

        val healthyCount = healthList.count { it.status == PeerHealthStatus.HEALTHY || it.status == PeerHealthStatus.RECOVERING }
        val degradedCount = healthList.count { it.status == PeerHealthStatus.DEGRADED }
        val unreachableCount = healthList.count { it.status == PeerHealthStatus.UNREACHABLE }
        val quarantinedCount = healthList.count { it.status == PeerHealthStatus.QUARANTINED }
        val revokedCount = healthList.count { it.status == PeerHealthStatus.REVOKED }

        val rtts = connectedPeers.mapNotNull { it.lastPingLatencyMs.takeIf { l -> l > 0L } }
        val avgRtt = if (rtts.isEmpty()) null else (rtts.sum() / rtts.size)

        val openBreakers = circuitBreakerManager.openBreakers()

        val snap = NetworkScalabilitySnapshot(
            connectedPeersCount = connectedPeers.size,
            healthyPeersCount = healthyCount,
            degradedPeersCount = degradedCount,
            unreachablePeersCount = unreachableCount,
            quarantinedPeersCount = quarantinedCount,
            revokedPeersCount = revokedCount,
            maxConnectedCap = resource.policy.maxConnectedPeers,
            maxOutboundCap = resource.policy.maxOutboundConnections,
            maxInboundCap = resource.policy.maxInboundConnections,
            outboundQueueDepth = congestion.outgoingQueueDepth,
            inboundQueueDepth = congestion.incomingQueueDepth,
            droppedQueueMessagesCount = congestion.droppedLowPriorityCount,
            expiredQueueMessagesCount = congestion.expiredQueueItemsCount,
            rateLimitedEventsCount = congestion.rateLimitedCount,
            congestionState = congestion.congestionState,
            openCircuitBreakers = openBreakers,
            allCircuitBreakers = circuitBreakerManager.snapshots.value,
            healthyBootstrapCount = infra.healthyBootstrapCount,
            unavailableBootstrapCount = infra.unavailableBootstrapCount,
            signalingHealthSummary = "${infra.signalingStatus.name} (${infra.activeSignalingEndpoint ?: "none"})",
            deviceResource = resource,
            validatorAvailability = validatorSnap,
            topologyHealth = topologyHealth,
            averagePeerRttMs = avgRtt,
            peerHealthRecords = healthList,
            lastSweepTimestampMs = now,
            recentScalabilityEvents = synchronized(recentEvents) { recentEvents.toList() }
        )
        _snapshot.value = snap
        return snap
    }

    private fun syncInfraBreakers() {
        val cfg = infrastructureCoordinator.bootstrapManager.activeProfileConfig.value
        cfg.bootstrapEndpoints.forEach { ep ->
            when (ep.healthState) {
                EndpointHealthState.HEALTHY -> circuitBreakerManager.recordSuccess(CircuitBreakerTargetType.BOOTSTRAP, ep.baseUrl)
                EndpointHealthState.COOLDOWN,
                EndpointHealthState.UNAVAILABLE -> {
                    val snap = circuitBreakerManager.getState(CircuitBreakerTargetType.BOOTSTRAP, ep.baseUrl)
                    if (snap.state == CircuitBreakerState.CLOSED && ep.consecutiveFailures > snap.consecutiveFailures) {
                        circuitBreakerManager.recordFailure(CircuitBreakerTargetType.BOOTSTRAP, ep.baseUrl, ep.lastError ?: "Bootstrap unreachable")
                    }
                }
                else -> Unit
            }
        }
        val sigUrl = infrastructureCoordinator.webSocketSignalingChannel.activeEndpointUrl.value
        if (!sigUrl.isNullOrBlank()) {
            val sigErr = infrastructureCoordinator.webSocketSignalingChannel.lastError.value
            when (infrastructureCoordinator.webSocketSignalingChannel.status.value) {
                com.example.p2p.infrastructure.model.SignalingTransportStatus.AUTHENTICATED ->
                    circuitBreakerManager.recordSuccess(CircuitBreakerTargetType.SIGNALING, sigUrl)
                com.example.p2p.infrastructure.model.SignalingTransportStatus.FAILED ->
                    circuitBreakerManager.recordFailure(CircuitBreakerTargetType.SIGNALING, sigUrl, sigErr ?: "Signaling failed")
                else -> Unit
            }
        }
    }

    private fun observeExistingComponents() {
        scope.launch(ioDispatcher) {
            connectionManager.authenticatedPeers.collect { peers ->
                peers.forEach { peer ->
                    peer.authenticatedNodeId?.let { id ->
                        peerHealthMonitor.recordAuthenticatedSession(
                            peerId = id,
                            latencyMs = peer.lastPingLatencyMs.takeIf { it > 0L }
                        )
                    }
                }
                refreshSnapshot()
            }
        }
        scope.launch(ioDispatcher) {
            discoveryCoordinator.peerRegistry.peers.collect {
                peerHealthMonitor.syncFromRegistryAndTrust()
                refreshSnapshot()
            }
        }
    }

    private fun startPeriodicHealthLoop() {
        periodicJob = scope.launch(ioDispatcher) {
            while (isActive) {
                val intervalMs = resourceMonitor.snapshot.value.policy.discoveryIntervalMs.coerceIn(15_000L, 120_000L)
                delay(intervalMs)
                runCatching {
                    resourceMonitor.sampleAndPublish()
                    peerHealthMonitor.evaluateQuarantineCooldowns()
                    congestionController.pruneExpired()
                    refreshSnapshot()
                }
            }
        }
    }

    private fun addEvent(msg: String) {
        synchronized(recentEvents) {
            recentEvents.addFirst("${clockMs()}:$msg")
            while (recentEvents.size > 20) {
                recentEvents.removeLast()
            }
        }
    }

    override fun close() {
        periodicJob?.cancel()
        periodicJob = null
    }
}
