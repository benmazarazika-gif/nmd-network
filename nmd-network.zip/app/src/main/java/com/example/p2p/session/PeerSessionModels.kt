package com.example.p2p.session

import com.example.p2p.model.PeerEndpoint

/**
 * Lifecycle states of an application-level P2P peer session.
 */
enum class P2pSessionState {
    CONNECTING,
    CONNECTED,
    AUTHENTICATED,
    ACTIVE,
    DISCONNECTED,
    CONNECTION_FAILURE;

    val isTrusted: Boolean
        get() = this == AUTHENTICATED || this == ACTIVE
}

/**
 * Dynamic connection health indicators based on heartbeat and delivery metrics.
 */
enum class ConnectionHealth {
    EXCELLENT,
    GOOD,
    DEGRADED,
    UNRESPONSIVE;

    companion object {
        fun computeHealth(
            state: P2pSessionState,
            lastSeenTimestamp: Long,
            lastLatencyMs: Long,
            now: Long = System.currentTimeMillis()
        ): ConnectionHealth {
            if (state == P2pSessionState.DISCONNECTED || state == P2pSessionState.CONNECTION_FAILURE) {
                return UNRESPONSIVE
            }
            val elapsedSinceLastSeen = now - lastSeenTimestamp
            return when {
                elapsedSinceLastSeen > 40_000L -> UNRESPONSIVE
                elapsedSinceLastSeen > 20_000L || lastLatencyMs > 500L -> DEGRADED
                lastLatencyMs in 1..99 -> EXCELLENT
                else -> GOOD
            }
        }
    }
}

/**
 * PeerSession represents a managed P2P session with an authenticated remote peer.
 */
data class PeerSession(
    val sessionId: String,
    val peerId: String,
    val remotePublicKeyHex: String,
    val endpoint: PeerEndpoint,
    val state: P2pSessionState,
    val connectedAt: Long = System.currentTimeMillis(),
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val messagesSentCount: Long = 0L,
    val messagesReceivedCount: Long = 0L,
    val successfulDeliveriesCount: Long = 0L,
    val failedDeliveriesCount: Long = 0L,
    val lastRoundTripLatencyMs: Long = 0L,
    val connectionHealth: ConnectionHealth = ConnectionHealth.GOOD,
    val isOutbound: Boolean = false,
    val lastError: String? = null
) {
    val isTrusted: Boolean
        get() = state.isTrusted

    val displayPeerId: String
        get() = if (peerId.length > 20) {
            "${peerId.take(12)}...${peerId.takeLast(6)}"
        } else {
            peerId
        }

    val displayPublicKey: String
        get() = if (remotePublicKeyHex.length > 20) {
            "${remotePublicKeyHex.take(10)}...${remotePublicKeyHex.takeLast(8)}"
        } else {
            remotePublicKeyHex
        }

    val durationSeconds: Long
        get() = if (connectedAt > 0 && (state == P2pSessionState.AUTHENTICATED || state == P2pSessionState.ACTIVE)) {
            (System.currentTimeMillis() - connectedAt) / 1000L
        } else {
            0L
        }

    val deliverySuccessRatePercent: Int
        get() {
            val total = successfulDeliveriesCount + failedDeliveriesCount
            return if (total > 0) ((successfulDeliveriesCount * 100) / total).toInt() else 100
        }
}
