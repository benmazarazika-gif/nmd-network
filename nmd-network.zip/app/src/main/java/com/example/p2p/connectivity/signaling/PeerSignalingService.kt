package com.example.p2p.connectivity.signaling

import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.CryptographicProvider
import com.example.p2p.connectivity.model.IceCandidateInfo
import com.example.p2p.connectivity.model.NatTraversalConfig
import com.example.p2p.security.trust.IdentityTrustCheckResult
import com.example.p2p.security.trust.PeerTrustManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

enum class SignalingMessageType {
    ICE_OFFER,
    ICE_ANSWER,
    ICE_CANDIDATE,
    ICE_RESTART_REQUEST,
    SESSION_BYE
}

/**
 * Authenticated, signed P2P ICE signaling envelope.
 * Binds sender Node ID + public key, recipient Node ID, Chain ID, signaling session ID,
 * monotonic sequence number, fresh nonce, and Ed25519 signature.
 */
data class SignalingEnvelope(
    val envelopeId: String = UUID.randomUUID().toString(),
    val signalingSessionId: String,
    val chainId: String,
    val senderNodeId: String,
    val senderPublicKeyHex: String,
    val recipientNodeId: String,
    val messageType: SignalingMessageType,
    val sequenceNumber: Long,
    val timestampMs: Long = System.currentTimeMillis(),
    val nonceHex: String,
    val payloadJson: String,
    val signatureHex: String = ""
) {
    companion object {
        private const val DOMAIN_HEADER = "NMD-SIGNALING-V1\u0000"
        const val MAX_TIMESTAMP_DRIFT_MS = 120_000L

        fun fromJson(jsonStr: String): SignalingEnvelope? {
            return try {
                val obj = JSONObject(jsonStr)
                SignalingEnvelope(
                    envelopeId = obj.getString("envelope_id"),
                    signalingSessionId = obj.getString("signaling_session_id"),
                    chainId = obj.getString("chain_id"),
                    senderNodeId = obj.getString("sender_node_id"),
                    senderPublicKeyHex = obj.getString("sender_public_key_hex"),
                    recipientNodeId = obj.getString("recipient_node_id"),
                    messageType = SignalingMessageType.valueOf(obj.getString("message_type")),
                    sequenceNumber = obj.getLong("sequence_number"),
                    timestampMs = obj.getLong("timestamp_ms"),
                    nonceHex = obj.getString("nonce_hex"),
                    payloadJson = obj.getString("payload_json"),
                    signatureHex = obj.optString("signature_hex", "")
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    fun getCanonicalBytes(): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.write(DOMAIN_HEADER.toByteArray(Charsets.UTF_8))
        dos.writeUTF(envelopeId)
        dos.writeUTF(signalingSessionId)
        dos.writeUTF(chainId)
        dos.writeUTF(senderNodeId)
        dos.writeUTF(senderPublicKeyHex)
        dos.writeUTF(recipientNodeId)
        dos.writeUTF(messageType.name)
        dos.writeLong(sequenceNumber)
        dos.writeLong(timestampMs)
        dos.writeUTF(nonceHex)
        val payloadBytes = payloadJson.toByteArray(Charsets.UTF_8)
        dos.writeInt(payloadBytes.size)
        dos.write(payloadBytes)
        dos.flush()
        return baos.toByteArray()
    }

    fun toJson(): String {
        val obj = JSONObject()
        obj.put("envelope_id", envelopeId)
        obj.put("signaling_session_id", signalingSessionId)
        obj.put("chain_id", chainId)
        obj.put("sender_node_id", senderNodeId)
        obj.put("sender_public_key_hex", senderPublicKeyHex)
        obj.put("recipient_node_id", recipientNodeId)
        obj.put("message_type", messageType.name)
        obj.put("sequence_number", sequenceNumber)
        obj.put("timestamp_ms", timestampMs)
        obj.put("nonce_hex", nonceHex)
        obj.put("payload_json", payloadJson)
        obj.put("signature_hex", signatureHex)
        return obj.toString()
    }
}

sealed class SignalingValidationResult {
    data class Valid(val envelope: SignalingEnvelope) : SignalingValidationResult()
    data class Rejected(val reason: String, val isAuthFailure: Boolean = true) : SignalingValidationResult()
}

/**
 * Replaceable signaling channel abstraction.
 * Allows plugging in decentralized peer-assisted relay channels, HTTPS rendezvous relays,
 * or local dev/test brokers without modifying ICE/security logic.
 */
interface SignalingChannel {
    val channelName: String
    val incomingEnvelopes: SharedFlow<SignalingEnvelope>
    suspend fun sendEnvelope(envelope: SignalingEnvelope): Result<Unit>
}

/**
 * Shared in-process signaling broker for deterministic multi-peer NAT traversal tests
 * and local development setups across distinct simulated network domains.
 */
class InMemorySignalingBroker {
    private val channels = ConcurrentHashMap<String, BrokerEndpointChannel>()

    fun registerPeer(nodeId: String): SignalingChannel {
        val endpoint = BrokerEndpointChannel(nodeId, this)
        channels[nodeId] = endpoint
        return endpoint
    }

    fun unregisterPeer(nodeId: String) {
        channels.remove(nodeId)
    }

    internal suspend fun route(envelope: SignalingEnvelope): Result<Unit> {
        val target = channels[envelope.recipientNodeId]
            ?: return Result.failure(IllegalStateException("Target peer ${envelope.recipientNodeId} not registered in signaling broker"))
        target.deliver(envelope)
        return Result.success(Unit)
    }

    private class BrokerEndpointChannel(
        private val ownerNodeId: String,
        private val broker: InMemorySignalingBroker
    ) : SignalingChannel {
        override val channelName: String = "InMemorySignalingBroker"
        private val _incoming = MutableSharedFlow<SignalingEnvelope>(extraBufferCapacity = 128)
        override val incomingEnvelopes: SharedFlow<SignalingEnvelope> = _incoming.asSharedFlow()

        override suspend fun sendEnvelope(envelope: SignalingEnvelope): Result<Unit> {
            return broker.route(envelope)
        }

        suspend fun deliver(envelope: SignalingEnvelope) {
            _incoming.emit(envelope)
        }
    }
}

/**
 * Authenticated, replay-protected ICE signaling service.
 *
 * Enforces:
 * - Ed25519 signature creation & strict verification bound to sender Node ID + target Node ID + Chain ID
 * - Nonce & monotonic sequence replay rejection
 * - Peer revocation enforcement via [PeerTrustManager]
 * - Bounded signaling payload sizes & candidate queues
 * - Duplicate candidate deduplication & out-of-order candidate buffering prior to SDP Offer/Answer
 * - Per-peer negotiation rate limits & abandoned session expiration cleanup
 */
class PeerSignalingService(
    private val identityManager: NodeIdentityManager,
    private val trustManager: PeerTrustManager,
    private val config: NatTraversalConfig = NatTraversalConfig(),
    private val cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider
) {
    companion object {
        private val secureRandom = SecureRandom()
    }

    private data class SessionBufferState(
        val sessionId: String,
        val peerNodeId: String,
        val createdAtMs: Long = System.currentTimeMillis(),
        var lastActivityAtMs: Long = System.currentTimeMillis(),
        var offerOrAnswerReceived: Boolean = false,
        var highestIncomingSeq: Long = 0L,
        val seenIncomingSeqs: LinkedHashSet<Long> = linkedSetOf(),
        var outgoingSeq: Long = 0L,
        val seenCandidateStrings: LinkedHashSet<String> = linkedSetOf(),
        val pendingEarlyCandidates: ArrayDeque<IceCandidateInfo> = ArrayDeque()
    )

    private val lock = Any()
    private val sessions = ConcurrentHashMap<String, SessionBufferState>()
    private val seenNonces = LinkedHashMap<String, Long>(512)
    private val peerNegotiationTimestamps = ConcurrentHashMap<String, ArrayDeque<Long>>()

    fun createSignedOffer(
        signalingSessionId: String,
        recipientNodeId: String,
        sdp: String,
        nowMs: Long = System.currentTimeMillis()
    ): Result<SignalingEnvelope> {
        val payload = JSONObject().apply { put("sdp", sdp) }.toString()
        return createSignedEnvelope(signalingSessionId, recipientNodeId, SignalingMessageType.ICE_OFFER, payload, nowMs)
    }

    fun createSignedAnswer(
        signalingSessionId: String,
        recipientNodeId: String,
        sdp: String,
        nowMs: Long = System.currentTimeMillis()
    ): Result<SignalingEnvelope> {
        val payload = JSONObject().apply { put("sdp", sdp) }.toString()
        return createSignedEnvelope(signalingSessionId, recipientNodeId, SignalingMessageType.ICE_ANSWER, payload, nowMs)
    }

    fun createSignedCandidate(
        signalingSessionId: String,
        recipientNodeId: String,
        candidate: IceCandidateInfo,
        nowMs: Long = System.currentTimeMillis()
    ): Result<SignalingEnvelope> {
        val payload = JSONObject().apply {
            put("candidate", candidate.rawSdp)
            put("sdp_mid", candidate.sdpMid)
            put("sdp_mline_index", candidate.sdpMLineIndex)
        }.toString()
        return createSignedEnvelope(signalingSessionId, recipientNodeId, SignalingMessageType.ICE_CANDIDATE, payload, nowMs)
    }

    fun createSignedIceRestart(
        signalingSessionId: String,
        recipientNodeId: String,
        sdp: String,
        reason: String,
        nowMs: Long = System.currentTimeMillis()
    ): Result<SignalingEnvelope> {
        val payload = JSONObject().apply {
            put("sdp", sdp)
            put("reason", reason)
        }.toString()
        return createSignedEnvelope(signalingSessionId, recipientNodeId, SignalingMessageType.ICE_RESTART_REQUEST, payload, nowMs)
    }

    fun createSignedBye(
        signalingSessionId: String,
        recipientNodeId: String,
        reason: String,
        nowMs: Long = System.currentTimeMillis()
    ): Result<SignalingEnvelope> {
        val payload = JSONObject().apply { put("reason", reason) }.toString()
        return createSignedEnvelope(signalingSessionId, recipientNodeId, SignalingMessageType.SESSION_BYE, payload, nowMs)
    }

    private fun createSignedEnvelope(
        signalingSessionId: String,
        recipientNodeId: String,
        type: SignalingMessageType,
        payloadJson: String,
        nowMs: Long
    ): Result<SignalingEnvelope> {
        val identity = identityManager.getActiveIdentity()
            ?: return Result.failure(IllegalStateException("Local node identity not initialized"))

        if (payloadJson.toByteArray(Charsets.UTF_8).size > config.maxSignalingPayloadBytes) {
            return Result.failure(IllegalArgumentException("Signaling payload exceeds ${config.maxSignalingPayloadBytes} byte cap"))
        }

        val seq = synchronized(lock) {
            val state = sessions.getOrPut(signalingSessionId) {
                SessionBufferState(sessionId = signalingSessionId, peerNodeId = recipientNodeId, createdAtMs = nowMs)
            }
            state.lastActivityAtMs = nowMs
            state.outgoingSeq += 1L
            state.outgoingSeq
        }

        val nonceBytes = ByteArray(16).apply { secureRandom.nextBytes(this) }
        val unsigned = SignalingEnvelope(
            signalingSessionId = signalingSessionId,
            chainId = config.chainId,
            senderNodeId = identity.nodeId,
            senderPublicKeyHex = identity.publicKeyHex,
            recipientNodeId = recipientNodeId,
            messageType = type,
            sequenceNumber = seq,
            timestampMs = nowMs,
            nonceHex = cryptoProvider.toHex(nonceBytes),
            payloadJson = payloadJson
        )
        val sigBytes = try {
            identityManager.signRawData(unsigned.getCanonicalBytes())
        } catch (e: Exception) {
            return Result.failure(IllegalStateException("Unable to sign signaling envelope: ${e.message}", e))
        }
        val signatureHex = cryptoProvider.toHex(sigBytes)
        return Result.success(unsigned.copy(signatureHex = signatureHex))
    }

    /**
     * Strictly verifies an incoming signaling envelope's structure, size, Chain ID,
     * target recipient, timestamp drift, nonce replay, monotonic sequence, revocation status,
     * public key -> Node ID derivation, and Ed25519 signature.
     */
    fun verifyAndProcessIncoming(
        envelope: SignalingEnvelope,
        nowMs: Long = System.currentTimeMillis()
    ): SignalingValidationResult {
        sweepExpiredSessions(nowMs)

        val localIdentity = identityManager.getActiveIdentity()
            ?: return SignalingValidationResult.Rejected("Local node identity unavailable", isAuthFailure = true)

        if (envelope.signalingSessionId.isBlank() || envelope.senderNodeId.isBlank()) {
            return SignalingValidationResult.Rejected("Missing signaling session or sender identity", isAuthFailure = true)
        }
        if (envelope.payloadJson.toByteArray(Charsets.UTF_8).size > config.maxSignalingPayloadBytes) {
            return SignalingValidationResult.Rejected("Signaling payload exceeded ${config.maxSignalingPayloadBytes} byte limit", isAuthFailure = false)
        }
        if (envelope.chainId != config.chainId) {
            return SignalingValidationResult.Rejected("Chain ID mismatch: expected ${config.chainId}, got ${envelope.chainId}", isAuthFailure = true)
        }
        if (!envelope.recipientNodeId.equals(localIdentity.nodeId, ignoreCase = true)) {
            return SignalingValidationResult.Rejected("Signaling envelope bound to different peer (${envelope.recipientNodeId})", isAuthFailure = true)
        }
        if (envelope.senderNodeId.equals(localIdentity.nodeId, ignoreCase = true)) {
            return SignalingValidationResult.Rejected("Refusing self-looped signaling envelope", isAuthFailure = false)
        }
        if (kotlin.math.abs(nowMs - envelope.timestampMs) > SignalingEnvelope.MAX_TIMESTAMP_DRIFT_MS) {
            return SignalingValidationResult.Rejected("Stale/expired signaling envelope timestamp", isAuthFailure = true)
        }
        if (trustManager.isPeerRevoked(envelope.senderNodeId, envelope.senderPublicKeyHex)) {
            return SignalingValidationResult.Rejected("Peer identity ${envelope.senderNodeId.take(12)} is revoked", isAuthFailure = true)
        }

        // Verify cryptographic key -> Node ID binding and Ed25519 signature
        val pubBytes = try {
            cryptoProvider.fromHex(envelope.senderPublicKeyHex)
        } catch (_: Exception) {
            return SignalingValidationResult.Rejected("Invalid sender public key hex", isAuthFailure = true)
        }
        val derivedNodeId = cryptoProvider.deriveNodeId(pubBytes)
        if (!derivedNodeId.equals(envelope.senderNodeId, ignoreCase = true)) {
            return SignalingValidationResult.Rejected("Sender Node ID does not match public key", isAuthFailure = true)
        }
        val sigBytes = try {
            cryptoProvider.fromHex(envelope.signatureHex)
        } catch (_: Exception) {
            return SignalingValidationResult.Rejected("Invalid signaling signature encoding", isAuthFailure = true)
        }
        if (!cryptoProvider.verify(pubBytes, envelope.getCanonicalBytes(), sigBytes)) {
            return SignalingValidationResult.Rejected("Ed25519 signature verification failed on signaling message", isAuthFailure = true)
        }

        // Check peer identity pinning / key rotation rules
        when (val trustRes = trustManager.checkHandshakeIdentityAllowed(envelope.senderNodeId, envelope.senderPublicKeyHex)) {
            is IdentityTrustCheckResult.Revoked -> {
                return SignalingValidationResult.Rejected("Peer identity revoked: ${trustRes.reason}", isAuthFailure = true)
            }
            is IdentityTrustCheckResult.IdentityMismatch -> {
                return SignalingValidationResult.Rejected(trustRes.reason, isAuthFailure = true)
            }
            IdentityTrustCheckResult.Allowed -> Unit
        }

        val nonceKey = "${envelope.senderNodeId}:${envelope.nonceHex}"
        synchronized(lock) {
            if (seenNonces.containsKey(nonceKey)) {
                return SignalingValidationResult.Rejected("Replayed signaling nonce rejected", isAuthFailure = true)
            }

            // Enforce max concurrent negotiations & per-peer rate limit for new sessions
            val existingSession = sessions[envelope.signalingSessionId]
            if (existingSession == null) {
                if (sessions.size >= config.maxConcurrentNegotiations) {
                    return SignalingValidationResult.Rejected("Max concurrent signaling negotiations (${config.maxConcurrentNegotiations}) reached", isAuthFailure = false)
                }
                if (!checkAndRecordNegotiationRateLocked(envelope.senderNodeId, nowMs)) {
                    return SignalingValidationResult.Rejected("Signaling negotiation rate limit exceeded for peer ${envelope.senderNodeId.take(12)}", isAuthFailure = false)
                }
            } else {
                if (!existingSession.peerNodeId.equals(envelope.senderNodeId, ignoreCase = true)) {
                    return SignalingValidationResult.Rejected("Signaling session hijacking attempt: sender changed", isAuthFailure = true)
                }
                if (envelope.sequenceNumber <= 0L || existingSession.seenIncomingSeqs.contains(envelope.sequenceNumber)) {
                    return SignalingValidationResult.Rejected("Replayed or out-of-window signaling sequence number", isAuthFailure = true)
                }
                if (existingSession.highestIncomingSeq - envelope.sequenceNumber > 64L) {
                    return SignalingValidationResult.Rejected("Stale out-of-window signaling sequence number", isAuthFailure = true)
                }
            }

            // Record nonce (bounded map)
            if (seenNonces.size >= 1024) {
                val oldestKey = seenNonces.keys.firstOrNull()
                if (oldestKey != null) seenNonces.remove(oldestKey)
            }
            seenNonces[nonceKey] = nowMs

            val state = sessions.getOrPut(envelope.signalingSessionId) {
                SessionBufferState(
                    sessionId = envelope.signalingSessionId,
                    peerNodeId = envelope.senderNodeId,
                    createdAtMs = nowMs
                )
            }
            if (state.seenIncomingSeqs.size >= 256) {
                val oldestSeq = state.seenIncomingSeqs.firstOrNull()
                if (oldestSeq != null) state.seenIncomingSeqs.remove(oldestSeq)
            }
            state.seenIncomingSeqs.add(envelope.sequenceNumber)
            if (envelope.sequenceNumber > state.highestIncomingSeq) {
                state.highestIncomingSeq = envelope.sequenceNumber
            }
            state.lastActivityAtMs = nowMs

            if (envelope.messageType == SignalingMessageType.ICE_OFFER ||
                envelope.messageType == SignalingMessageType.ICE_ANSWER ||
                envelope.messageType == SignalingMessageType.ICE_RESTART_REQUEST
            ) {
                state.offerOrAnswerReceived = true
            }
        }

        return SignalingValidationResult.Valid(envelope)
    }

    /**
     * Checks outbound rate limit and concurrent negotiation ceiling before starting ICE negotiation.
     */
    fun tryReserveOutboundNegotiation(
        signalingSessionId: String,
        peerNodeId: String,
        nowMs: Long = System.currentTimeMillis()
    ): Result<Unit> {
        sweepExpiredSessions(nowMs)
        synchronized(lock) {
            if (sessions.size >= config.maxConcurrentNegotiations) {
                return Result.failure(IllegalStateException("Max concurrent negotiations (${config.maxConcurrentNegotiations}) reached"))
            }
            if (!checkAndRecordNegotiationRateLocked(peerNodeId, nowMs)) {
                return Result.failure(IllegalStateException("Per-peer negotiation rate limit exceeded"))
            }
            sessions[signalingSessionId] = SessionBufferState(
                sessionId = signalingSessionId,
                peerNodeId = peerNodeId,
                createdAtMs = nowMs,
                lastActivityAtMs = nowMs
            )
        }
        return Result.success(Unit)
    }

    /**
     * Buffers an incoming remote ICE candidate safely, handling:
     * - Duplicate candidate deduplication
     * - Bounded queue limits ([NatTraversalConfig.maxCandidateQueueSize])
     * - Out-of-order buffering until offer/answer SDP is applied
     *
     * Returns candidate immediately if SDP is already set and candidate is non-duplicate,
     * or null if buffered early or ignored as duplicate/over-limit.
     */
    fun ingestRemoteCandidate(
        signalingSessionId: String,
        candidate: IceCandidateInfo
    ): CandidateIngestOutcome {
        synchronized(lock) {
            val state = sessions[signalingSessionId]
                ?: return CandidateIngestOutcome.UnknownSession

            val dedupKey = "${candidate.rawSdp}|${candidate.sdpMid}|${candidate.sdpMLineIndex}"
            if (!state.seenCandidateStrings.add(dedupKey)) {
                return CandidateIngestOutcome.DuplicateIgnored
            }
            if (state.seenCandidateStrings.size > config.maxCandidateQueueSize) {
                return CandidateIngestOutcome.QueueLimitExceeded
            }
            state.lastActivityAtMs = System.currentTimeMillis()

            return if (state.offerOrAnswerReceived) {
                CandidateIngestOutcome.ReadyToApply(candidate)
            } else {
                if (state.pendingEarlyCandidates.size >= config.maxCandidateQueueSize) {
                    CandidateIngestOutcome.QueueLimitExceeded
                } else {
                    state.pendingEarlyCandidates.addLast(candidate)
                    CandidateIngestOutcome.BufferedEarly
                }
            }
        }
    }

    /**
     * Marks SDP ready for a session and drains all previously buffered out-of-order candidates.
     */
    fun markRemoteSdpAppliedAndDrainCandidates(signalingSessionId: String): List<IceCandidateInfo> {
        synchronized(lock) {
            val state = sessions[signalingSessionId] ?: return emptyList()
            state.offerOrAnswerReceived = true
            state.lastActivityAtMs = System.currentTimeMillis()
            val drained = state.pendingEarlyCandidates.toList()
            state.pendingEarlyCandidates.clear()
            return drained
        }
    }

    fun closeSession(signalingSessionId: String) {
        synchronized(lock) {
            sessions.remove(signalingSessionId)
        }
    }

    fun activeNegotiationCount(): Int = sessions.size

    fun sweepExpiredSessions(nowMs: Long = System.currentTimeMillis()): Int {
        var removed = 0
        synchronized(lock) {
            val expiredIds = sessions.values
                .filter { nowMs - it.lastActivityAtMs > config.abandonedSessionTtlMs }
                .map { it.sessionId }
            expiredIds.forEach { id ->
                if (sessions.remove(id) != null) removed++
            }
            // Prune stale nonces older than 2x drift
            val nonceCutoff = nowMs - (SignalingEnvelope.MAX_TIMESTAMP_DRIFT_MS * 2)
            seenNonces.entries.removeIf { it.value < nonceCutoff }
        }
        return removed
    }

    private fun checkAndRecordNegotiationRateLocked(peerNodeId: String, nowMs: Long): Boolean {
        val windowStart = nowMs - config.negotiationRateWindowMs
        val deque = peerNegotiationTimestamps.getOrPut(peerNodeId) { ArrayDeque() }
        while (deque.isNotEmpty() && deque.first() < windowStart) {
            deque.removeFirst()
        }
        if (deque.size >= config.maxNegotiationStartsPerPeerPerWindow) {
            return false
        }
        deque.addLast(nowMs)
        return true
    }

    fun parseSdpFromPayload(envelope: SignalingEnvelope): String? {
        return try {
            val sdp = JSONObject(envelope.payloadJson).optString("sdp", "")
            sdp.takeIf { it.isNotBlank() && it.length <= config.maxSignalingPayloadBytes }
        } catch (_: Exception) {
            null
        }
    }

    fun parseCandidateFromPayload(envelope: SignalingEnvelope): IceCandidateInfo? {
        return try {
            val obj = JSONObject(envelope.payloadJson)
            val rawCandidate = obj.getString("candidate")
            val mid = obj.optString("sdp_mid", "0")
            val mLineIndex = obj.optInt("sdp_mline_index", 0)
            val candidate = IceCandidateInfo.parseSafe(rawCandidate, mid, mLineIndex) ?: return null
            if (!config.enableIpv6Candidates && candidate.ipVersion == com.example.p2p.connectivity.model.IpVersion.IPV6) {
                return null
            }
            candidate
        } catch (_: Exception) {
            null
        }
    }
}

sealed class CandidateIngestOutcome {
    data class ReadyToApply(val candidate: IceCandidateInfo) : CandidateIngestOutcome()
    object BufferedEarly : CandidateIngestOutcome()
    object DuplicateIgnored : CandidateIngestOutcome()
    object QueueLimitExceeded : CandidateIngestOutcome()
    object UnknownSession : CandidateIngestOutcome()
}
