package com.example.p2p.protocol

import com.example.p2p.reliable.DeliveryStatus
import com.example.p2p.repository.MessageDirection
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Historical record of a Stage 6 reliable P2P message exchange.
 */
data class ReliableMessageRecord(
    val id: String,
    val direction: MessageDirection,
    val remotePeerId: String,
    val messageType: P2pMessageType,
    val payload: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: DeliveryStatus = DeliveryStatus.ACKNOWLEDGED,
    val roundTripLatencyMs: Long = 0L,
    val ackForMessageId: String? = null,
    val isDuplicate: Boolean = false,
    val errorCode: String? = null
) {
    val formattedTime: String
        get() {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.US)
            sdf.timeZone = TimeZone.getDefault()
            return sdf.format(Date(timestamp))
        }

    val displayRemotePeerId: String
        get() = if (remotePeerId.length > 20) {
            "${remotePeerId.take(10)}...${remotePeerId.takeLast(6)}"
        } else {
            remotePeerId
        }
}
