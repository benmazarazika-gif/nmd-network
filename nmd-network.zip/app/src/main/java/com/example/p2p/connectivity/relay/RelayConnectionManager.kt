package com.example.p2p.connectivity.relay

import com.example.p2p.connectivity.model.RelayAllocationMetrics
import com.example.p2p.connectivity.model.RelayFallbackState
import com.example.p2p.connectivity.model.TurnRelayStatus
import com.example.p2p.connectivity.model.TurnServerConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Manages externalized TURN relay servers, credential expiry checks, relay allocation limits,
 * fallback tracking when direct ICE paths fail, and relay connection monitoring.
 *
 * Never hardcodes permanent production TURN servers or credentials in source code.
 * Reports availability explicitly (e.g., "Relay fallback unavailable (no TURN server configured)").
 */
class RelayConnectionManager(
    private val maxAllocationsPerPeer: Int = 2,
    private val maxTotalRelayAllocations: Int = 8
) {
    private val _state = MutableStateFlow(RelayFallbackState())
    val state: StateFlow<RelayFallbackState> = _state.asStateFlow()

    @Volatile
    private var configuredServers: List<TurnServerConfig> = emptyList()

    private val allocations = ConcurrentHashMap<String, RelayAllocationMetrics>()
    private val fallbackCount = AtomicLong(0L)
    private val failureCount = AtomicLong(0L)

    fun configureTurnServers(servers: List<TurnServerConfig>, nowMs: Long = System.currentTimeMillis()) {
        configuredServers = servers.filter { it.enabled && it.isValidConfig() }
        refreshAvailabilityState(nowMs)
    }

    fun getValidTurnServers(nowMs: Long = System.currentTimeMillis()): List<TurnServerConfig> {
        return configuredServers.filter { it.isCredentialValid(nowMs) }
    }

    fun isRelayAvailable(nowMs: Long = System.currentTimeMillis()): Boolean {
        return getValidTurnServers(nowMs).isNotEmpty()
    }

    fun refreshAvailabilityState(nowMs: Long = System.currentTimeMillis()): RelayFallbackState {
        val total = configuredServers.size
        val valid = configuredServers.filter { it.isCredentialValid(nowMs) }
        val activeList = allocations.values.filter { it.isActive }

        val (status, message) = when {
            total == 0 -> TurnRelayStatus.UNCONFIGURED to "Relay fallback unavailable (no TURN server configured)"
            valid.isEmpty() -> TurnRelayStatus.UNAVAILABLE_EXPIRED to "Relay fallback unavailable (configured TURN credentials expired)"
            activeList.isNotEmpty() -> TurnRelayStatus.RELAYING to "Relaying ${activeList.size} peer path(s) via ${valid.first().transport.name}"
            else -> TurnRelayStatus.AVAILABLE to "${valid.size} TURN relay server(s) ready (${valid.joinToString { it.transport.name }})"
        }

        val snapshot = RelayFallbackState(
            status = status,
            configuredServersCount = total,
            validServersCount = valid.size,
            activeAllocationsCount = activeList.size,
            fallbackTriggeredCount = fallbackCount.get(),
            relayFailuresCount = failureCount.get(),
            activeAllocations = activeList,
            availabilityMessage = message
        )
        _state.value = snapshot
        return snapshot
    }

    /**
     * Attempts to reserve a TURN relay allocation slot when direct connectivity fails.
     * Enforces configured credential validity and allocation rate/quota caps.
     */
    fun beginRelayFallbackAllocation(
        peerNodeId: String,
        preferredServer: TurnServerConfig? = null,
        nowMs: Long = System.currentTimeMillis()
    ): Result<RelayAllocationMetrics> {
        val validServers = getValidTurnServers(nowMs)
        if (validServers.isEmpty()) {
            val reason = if (configuredServers.isEmpty()) {
                "Relay fallback unavailable: no TURN server configured"
            } else {
                "Relay fallback unavailable: TURN credentials expired"
            }
            failureCount.incrementAndGet()
            refreshAvailabilityState(nowMs)
            return Result.failure(IllegalStateException(reason))
        }

        val activeForPeer = allocations.values.count { it.isActive && it.peerNodeId == peerNodeId }
        if (activeForPeer >= maxAllocationsPerPeer) {
            failureCount.incrementAndGet()
            refreshAvailabilityState(nowMs)
            return Result.failure(IllegalStateException("TURN allocation limit ($maxAllocationsPerPeer) reached for peer $peerNodeId"))
        }

        val activeTotal = allocations.values.count { it.isActive }
        if (activeTotal >= maxTotalRelayAllocations) {
            failureCount.incrementAndGet()
            refreshAvailabilityState(nowMs)
            return Result.failure(IllegalStateException("Global TURN relay allocation cap ($maxTotalRelayAllocations) reached"))
        }

        val chosen = preferredServer?.takeIf { it.isCredentialValid(nowMs) } ?: validServers.first()
        fallbackCount.incrementAndGet()

        val allocation = RelayAllocationMetrics(
            allocationId = UUID.randomUUID().toString(),
            peerNodeId = peerNodeId,
            serverUri = chosen.effectiveIceUri(),
            transport = chosen.transport,
            allocatedAtMs = nowMs,
            lastActivityAtMs = nowMs,
            isActive = true
        )
        allocations[allocation.allocationId] = allocation
        refreshAvailabilityState(nowMs)
        return Result.success(allocation)
    }

    fun updateRelayQuality(allocationId: String, estimatedRttMs: Long) {
        allocations.computeIfPresent(allocationId) { _, existing ->
            existing.copy(
                estimatedRttMs = estimatedRttMs.coerceAtLeast(1L),
                lastActivityAtMs = System.currentTimeMillis()
            )
        }
        refreshAvailabilityState()
    }

    fun recordRelayDisconnected(allocationId: String, reason: String) {
        val removed = allocations.remove(allocationId)
        if (removed != null) {
            refreshAvailabilityState()
        }
        if (reason.contains("fail", ignoreCase = true) || reason.contains("error", ignoreCase = true)) {
            failureCount.incrementAndGet()
            refreshAvailabilityState()
        }
    }

    fun recordRelayFailure(peerNodeId: String, reason: String) {
        allocations.entries.removeIf { it.value.peerNodeId == peerNodeId }
        failureCount.incrementAndGet()
        val base = refreshAvailabilityState()
        _state.value = base.copy(
            status = if (configuredServers.isEmpty()) TurnRelayStatus.UNCONFIGURED else TurnRelayStatus.FAILED,
            availabilityMessage = "Relay error for ${peerNodeId.take(12)}: $reason"
        )
    }

    fun releasePeerAllocations(peerNodeId: String) {
        val changed = allocations.entries.removeIf { it.value.peerNodeId == peerNodeId }
        if (changed) {
            refreshAvailabilityState()
        }
    }

    fun releaseAllAllocations() {
        if (allocations.isNotEmpty()) {
            allocations.clear()
            refreshAvailabilityState()
        }
    }
}
