package com.example.p2p.service

import android.content.Context
import android.util.Log
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.CryptographicProvider
import com.example.p2p.discovery.pex.PeerExchangeService
import com.example.p2p.discovery.pex.ProcessPexResult
import com.example.p2p.heartbeat.HeartbeatMonitor
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.FrameType
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.model.RealPeerInfo
import com.example.p2p.protocol.MessageValidationResult
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.protocol.ReliableMessageRecord
import com.example.p2p.reliable.DeliveryResult
import com.example.p2p.reliable.DeliveryStatus
import com.example.p2p.reliable.ReliableDeliveryManager
import com.example.p2p.repository.MessageDirection
import com.example.p2p.scalability.congestion.EnqueueOutcome
import com.example.p2p.scalability.congestion.NetworkCongestionController
import com.example.p2p.scalability.health.PeerHealthMonitor
import com.example.p2p.session.ConnectionHealth
import com.example.p2p.session.P2pSessionState
import com.example.p2p.session.PeerSession
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Result of executing Stage 6 P2P Protocol Test Lab scenarios.
 */
data class P2pTestScenarioResult(
    val testName: String,
    val isSuccess: Boolean,
    val details: String,
    val durationMs: Long
)

data class P2pTestLabReport(
    val executedAt: Long = System.currentTimeMillis(),
    val totalTests: Int,
    val passedTests: Int,
    val results: List<P2pTestScenarioResult>
) {
    val allPassed: Boolean
        get() = totalTests > 0 && totalTests == passedTests
}

/**
 * ReliableP2pMessagingService coordinates application-level P2P messaging,
 * peer sessions, delivery acknowledgements, duplicate detection, and heartbeats.
 */
class ReliableP2pMessagingService(
    private val context: Context,
    private val identityManager: NodeIdentityManager,
    private val connectionManager: PeerConnectionManager,
    private val cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    companion object {
        private const val TAG = "ReliableP2pService"
    }

    val deliveryManager = ReliableDeliveryManager(scope, ioDispatcher)

    // Stage 7: Optional PEX service and local endpoint resolver wired by coordinator/repository
    @Volatile
    var peerExchangeService: PeerExchangeService? = null
    @Volatile
    var localHostPortProvider: (() -> Pair<String, Int>)? = null
    var onPexPeersIngested: ((Int, Int) -> Unit)? = null

    // Stage 9: Optional transaction propagation handler wired by TransactionEngineManager/Repository
    @Volatile
    var onIncomingTransactionMessage: (suspend (PeerSession, P2pMessage) -> Unit)? = null

    // Stage 10: Optional consensus message handler wired by ConsensusP2pGateway/NetworkViewModel
    @Volatile
    var onIncomingConsensusMessage: (suspend (PeerSession, P2pMessage) -> Unit)? = null

    // Stage 12: Optional blockchain sync message handler wired by BlockchainSyncCoordinator/NetworkViewModel
    @Volatile
    var onIncomingSyncMessage: (suspend (PeerSession, P2pMessage) -> Unit)? = null

    // Stage 16: Optional bounded congestion controller and multi-signal peer health monitor
    @Volatile
    var peerHealthMonitor: PeerHealthMonitor? = null
    @Volatile
    var congestionController: NetworkCongestionController? = null

    private val sessionMap = ConcurrentHashMap<String, PeerSession>()
    private val _sessions = MutableStateFlow<List<PeerSession>>(emptyList())
    val sessions: StateFlow<List<PeerSession>> = _sessions.asStateFlow()

    private val _reliableMessageLog = MutableStateFlow<List<ReliableMessageRecord>>(emptyList())
    val reliableMessageLog: StateFlow<List<ReliableMessageRecord>> = _reliableMessageLog.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<Pair<PeerSession, P2pMessage>>(extraBufferCapacity = 64)
    val incomingMessages: SharedFlow<Pair<PeerSession, P2pMessage>> = _incomingMessages.asSharedFlow()

    private val _testReport = MutableStateFlow<P2pTestLabReport?>(null)
    val testReport: StateFlow<P2pTestLabReport?> = _testReport.asStateFlow()

    private val sequenceCounter = AtomicLong(0L)
    private var frameCollectorJob: Job? = null
    private var peerSyncJob: Job? = null
    private var heartbeatTickerJob: Job? = null

    val heartbeatMonitor: HeartbeatMonitor = HeartbeatMonitor(
        scope = scope,
        ioDispatcher = ioDispatcher,
        onSendPing = { session -> sendHeartbeatPing(session) },
        onPeerUnresponsive = { session -> handlePeerUnresponsive(session) },
        onHealthUpdated = { session, health, latency -> updateSessionHealth(session.sessionId, health, latency) }
    )

    init {
        // 1. Sync sessions with Stage 5 authenticated peers
        peerSyncJob = scope.launch(ioDispatcher) {
            connectionManager.authenticatedPeers.collect { peersList ->
                syncSessionsFromPeers(peersList)
            }
        }

        // 2. Listen for incoming RELIABLE_MSG frames
        frameCollectorJob = scope.launch(ioDispatcher) {
            connectionManager.receivedReliableFrames.collect { (peerInfo, payload) ->
                try {
                    handleIncomingReliablePayload(peerInfo, payload)
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    Log.w(TAG, "Error handling incoming reliable frame from ${peerInfo.connectionId}: ${e.message}")
                }
            }
        }

        // 3. Start Heartbeat ticker (every 15s)
        heartbeatMonitor.start()
        heartbeatTickerJob = scope.launch(ioDispatcher) {
            while (isActive) {
                kotlinx.coroutines.delay(15_000L)
                heartbeatMonitor.checkSessions(sessionMap.values.toList())
            }
        }
    }

    private fun syncSessionsFromPeers(peersList: List<RealPeerInfo>) {
        val currentPeerIds = peersList.mapNotNull { it.authenticatedNodeId }.toSet()

        // Remove disconnected sessions
        sessionMap.entries.removeIf { (_, session) ->
            if (!currentPeerIds.contains(session.peerId)) {
                deliveryManager.cancelSessionPendingMessages(session.sessionId, "Peer disconnected")
                true
            } else {
                false
            }
        }

        // Update or create sessions
        for (peer in peersList) {
            val peerId = peer.authenticatedNodeId ?: continue
            val existing = sessionMap[peer.connectionId]
            if (existing == null) {
                val newSession = PeerSession(
                    sessionId = peer.connectionId,
                    peerId = peerId,
                    remotePublicKeyHex = peer.authenticatedPublicKeyHex ?: "",
                    endpoint = peer.endpoint,
                    state = if (peer.state == RealPeerConnectionState.AUTHENTICATED) P2pSessionState.ACTIVE else P2pSessionState.CONNECTED,
                    connectedAt = peer.connectedAt,
                    lastSeenTimestamp = System.currentTimeMillis(),
                    messagesSentCount = peer.messagesSent,
                    messagesReceivedCount = peer.messagesReceived,
                    lastRoundTripLatencyMs = peer.lastPingLatencyMs,
                    isOutbound = peer.isOutbound
                )
                sessionMap[peer.connectionId] = newSession
            } else {
                sessionMap[peer.connectionId] = existing.copy(
                    endpoint = peer.endpoint,
                    state = if (peer.state == RealPeerConnectionState.AUTHENTICATED) P2pSessionState.ACTIVE else existing.state,
                    messagesSentCount = Math.max(existing.messagesSentCount, peer.messagesSent),
                    messagesReceivedCount = Math.max(existing.messagesReceivedCount, peer.messagesReceived),
                    lastRoundTripLatencyMs = if (peer.lastPingLatencyMs > 0) peer.lastPingLatencyMs else existing.lastRoundTripLatencyMs
                )
            }
        }
        publishSessions()
    }

    private fun publishSessions() {
        _sessions.value = sessionMap.values.sortedByDescending { it.connectedAt }
    }

    private fun updateSessionHealth(sessionId: String, health: ConnectionHealth, latency: Long) {
        val session = sessionMap[sessionId] ?: return
        sessionMap[sessionId] = session.copy(
            connectionHealth = health,
            lastRoundTripLatencyMs = latency
        )
        publishSessions()
    }

    private suspend fun handlePeerUnresponsive(session: PeerSession) {
        Log.w(TAG, "Handling unresponsive peer session ${session.sessionId}")
        peerHealthMonitor?.recordMissedHeartbeat(session.peerId)
        sessionMap[session.sessionId] = session.copy(
            state = P2pSessionState.CONNECTION_FAILURE,
            connectionHealth = ConnectionHealth.UNRESPONSIVE,
            lastError = "Heartbeat timeout"
        )
        publishSessions()
        deliveryManager.cancelSessionPendingMessages(session.sessionId, "Peer unresponsive")
        try {
            connectionManager.disconnectPeer(session.sessionId)
        } catch (_: Exception) {}
    }

    suspend fun sendReliableMessage(
        sessionId: String,
        messageType: P2pMessageType,
        payload: String,
        requireSignature: Boolean = true
    ): Result<DeliveryResult> = withContext(ioDispatcher) {
        val session = sessionMap[sessionId]
            ?: return@withContext Result.failure(IllegalArgumentException("Peer session not found: $sessionId"))

        if (!session.isTrusted) {
            return@withContext Result.failure(IllegalStateException("Cannot send message: Peer is not in an authenticated or active state"))
        }

        val localIdentity = identityManager.getActiveIdentity()
            ?: return@withContext Result.failure(IllegalStateException("Local node identity not initialized"))

        val messageId = UUID.randomUUID().toString()
        val seq = sequenceCounter.incrementAndGet()
        val now = System.currentTimeMillis()

        // 1. Build unsigned message
        var message = P2pMessage(
            messageId = messageId,
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = localIdentity.nodeId,
            recipientPeerId = session.peerId,
            messageType = messageType,
            timestamp = now,
            sequenceNumber = seq,
            payload = payload
        )

        // 2. Cryptographically sign message if required
        if (requireSignature) {
            val canonicalBytes = message.getCanonicalBytes()
            val sigBytes = identityManager.signRawData(canonicalBytes)
            val sigHex = cryptoProvider.toHex(sigBytes)
            message = message.copy(signatureHex = sigHex)
        }

        // 2b. Check Stage 16 bounded congestion & priority admission before dispatch
        val controller = congestionController
        if (controller != null) {
            when (val admission = controller.enqueueOutgoing(session.peerId, sessionId, message)) {
                is EnqueueOutcome.RejectedRateLimited -> {
                    peerHealthMonitor?.recordMessageFailure(session.peerId, isTimeout = false)
                    return@withContext Result.failure(IllegalStateException("Rate limited to ${session.peerId}; retry in ${admission.retryAfterMs}ms"))
                }
                is EnqueueOutcome.RejectedBackpressure -> {
                    return@withContext Result.failure(IllegalStateException("Congestion backpressure: ${admission.reason}"))
                }
                is EnqueueOutcome.RejectedDuplicate,
                is EnqueueOutcome.Enqueued -> {
                    // Drain highest priority message immediately while preserving reliable delivery guarantee
                    controller.dequeueNextOutgoing()
                }
            }
        }

        // 3. Delegate to reliable delivery engine with retries
        val sendAction: suspend (P2pMessage) -> Unit = { msgToSend ->
            val json = msgToSend.toJson()
            val payloadBytes = json.toByteArray(Charsets.UTF_8)
            connectionManager.sendRawFrame(sessionId, FrameType.RELIABLE_MSG, payloadBytes)
        }

        val result = deliveryManager.sendReliably(
            message = message,
            targetSessionId = sessionId,
            sendAction = sendAction
        )
        if (result.isSuccess) {
            controller?.recordDeliverySuccess(session.peerId)
            peerHealthMonitor?.recordHeartbeatSuccess(session.peerId, result.roundTripLatencyMs.coerceAtLeast(1L))
        } else {
            peerHealthMonitor?.recordMessageFailure(session.peerId, isTimeout = result.status == DeliveryStatus.TIMED_OUT)
        }

        // 4. Update session statistics
        val currentSession = sessionMap[sessionId]
        if (currentSession != null) {
            val updated = if (result.isSuccess) {
                currentSession.copy(
                    messagesSentCount = currentSession.messagesSentCount + 1,
                    successfulDeliveriesCount = currentSession.successfulDeliveriesCount + 1,
                    lastRoundTripLatencyMs = result.roundTripLatencyMs,
                    connectionHealth = ConnectionHealth.computeHealth(
                        state = currentSession.state,
                        lastSeenTimestamp = System.currentTimeMillis(),
                        lastLatencyMs = result.roundTripLatencyMs
                    )
                )
            } else {
                currentSession.copy(
                    messagesSentCount = currentSession.messagesSentCount + 1,
                    failedDeliveriesCount = currentSession.failedDeliveriesCount + 1,
                    lastError = result.errorMessage
                )
            }
            sessionMap[sessionId] = updated
            publishSessions()
        }

        // 5. Append to log
        val record = ReliableMessageRecord(
            id = messageId,
            direction = MessageDirection.OUTGOING,
            remotePeerId = session.peerId,
            messageType = messageType,
            payload = payload,
            timestamp = now,
            status = result.status,
            roundTripLatencyMs = result.roundTripLatencyMs,
            errorCode = result.errorMessage
        )
        addMessageRecord(record)

        if (result.isSuccess) {
            Result.success(result)
        } else {
            Result.failure(Exception(result.errorMessage ?: "Message delivery failed with status: ${result.status}"))
        }
    }

    /**
     * Stage 7 helper: Signs and sends a pre-built PEX P2pMessage over an authenticated session.
     */
    suspend fun sendPexMessage(
        sessionId: String,
        prebuiltMessage: P2pMessage
    ): Result<DeliveryResult> = withContext(ioDispatcher) {
        val session = sessionMap[sessionId]
            ?: return@withContext Result.failure(IllegalArgumentException("Peer session not found: $sessionId"))
        if (!session.isTrusted) {
            return@withContext Result.failure(IllegalStateException("Cannot send PEX message: Peer not authenticated"))
        }

        val seq = sequenceCounter.incrementAndGet()
        val withSeq = prebuiltMessage.copy(sequenceNumber = seq)
        val sigBytes = identityManager.signRawData(withSeq.getCanonicalBytes())
        val signedMsg = withSeq.copy(signatureHex = cryptoProvider.toHex(sigBytes))

        val sendAction: suspend (P2pMessage) -> Unit = { msgToSend ->
            connectionManager.sendRawFrame(sessionId, FrameType.RELIABLE_MSG, msgToSend.toJson().toByteArray(Charsets.UTF_8))
        }

        if (signedMsg.messageType.requiresAck) {
            val result = deliveryManager.sendReliably(
                message = signedMsg,
                targetSessionId = sessionId,
                sendAction = sendAction
            )
            addMessageRecord(
                ReliableMessageRecord(
                    id = signedMsg.messageId,
                    direction = MessageDirection.OUTGOING,
                    remotePeerId = signedMsg.recipientPeerId,
                    messageType = signedMsg.messageType,
                    payload = signedMsg.payload,
                    timestamp = signedMsg.timestamp,
                    status = result.status,
                    roundTripLatencyMs = result.roundTripLatencyMs,
                    errorCode = result.errorMessage
                )
            )
            if (result.isSuccess) Result.success(result)
            else Result.failure(Exception(result.errorMessage ?: "PEX delivery failed"))
        } else {
            return@withContext try {
                sendAction(signedMsg)
                addMessageRecord(
                    ReliableMessageRecord(
                        id = signedMsg.messageId,
                        direction = MessageDirection.OUTGOING,
                        remotePeerId = signedMsg.recipientPeerId,
                        messageType = signedMsg.messageType,
                        payload = signedMsg.payload,
                        timestamp = signedMsg.timestamp,
                        status = DeliveryStatus.ACKNOWLEDGED
                    )
                )
                Result.success(
                    DeliveryResult(
                        messageId = signedMsg.messageId,
                        status = DeliveryStatus.ACKNOWLEDGED,
                        attempts = 1,
                        roundTripLatencyMs = 1L
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    /**
     * Stage 12 helper: Signs and sends a Stage 12 sync message, waiting for ACK only when [messageType.requiresAck] is true.
     */
    suspend fun sendSyncProtocolMessage(
        sessionId: String,
        messageType: P2pMessageType,
        payload: String
    ): Result<DeliveryResult> = withContext(ioDispatcher) {
        val localIdentity = identityManager.getActiveIdentity()
            ?: return@withContext Result.failure(IllegalStateException("Local node identity not initialized"))
        val session = sessionMap[sessionId]
            ?: return@withContext Result.failure(IllegalArgumentException("Peer session not found: $sessionId"))
        if (!session.isTrusted) {
            return@withContext Result.failure(IllegalStateException("Cannot send sync message: Peer not authenticated"))
        }
        val msg = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = localIdentity.nodeId,
            recipientPeerId = session.peerId,
            messageType = messageType,
            timestamp = System.currentTimeMillis(),
            sequenceNumber = sequenceCounter.incrementAndGet(),
            payload = payload
        )
        sendPexMessage(sessionId, msg)
    }

    private suspend fun sendHeartbeatPing(session: PeerSession) {
        val localIdentity = identityManager.getActiveIdentity() ?: return
        val pingMessage = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = localIdentity.nodeId,
            recipientPeerId = session.peerId,
            messageType = P2pMessageType.PING,
            timestamp = System.currentTimeMillis(),
            sequenceNumber = sequenceCounter.incrementAndGet(),
            payload = "{\"ping\":true}"
        )
        val json = pingMessage.toJson()
        connectionManager.sendRawFrame(session.sessionId, FrameType.RELIABLE_MSG, json.toByteArray(Charsets.UTF_8))
    }

    suspend fun sendManualPing(sessionId: String): Result<Long> = withContext(ioDispatcher) {
        val session = sessionMap[sessionId]
            ?: return@withContext Result.failure(IllegalArgumentException("Peer session not found: $sessionId"))
        val startTime = System.currentTimeMillis()
        val result = sendReliableMessage(sessionId, P2pMessageType.PING, "{\"manual_ping\":true}", requireSignature = false)
        if (result.isSuccess) {
            val rtt = Math.max(1L, System.currentTimeMillis() - startTime)
            Result.success(rtt)
        } else {
            Result.failure(Exception(result.exceptionOrNull()?.message ?: "Ping failed"))
        }
    }

    private suspend fun handleIncomingReliablePayload(peerInfo: RealPeerInfo, payload: ByteArray) {
        val jsonStr = try {
            String(payload, Charsets.UTF_8)
        } catch (_: Exception) {
            Log.e(TAG, "Failed reading raw UTF-8 payload")
            return
        }

        val message = P2pMessage.fromJson(jsonStr)
        if (message == null) {
            Log.w(TAG, "Received malformed P2P message JSON from ${peerInfo.authenticatedNodeId}")
            sendErrorMessage(peerInfo.connectionId, null, "MALFORMED_JSON", "Invalid JSON syntax")
            return
        }

        val session = sessionMap[peerInfo.connectionId]
        val localIdentity = identityManager.getActiveIdentity()
        val localNodeId = localIdentity?.nodeId ?: ""

        // 1. Validate sender identity matches authenticated socket
        if (peerInfo.authenticatedNodeId != null && !message.senderPeerId.equals(peerInfo.authenticatedNodeId, ignoreCase = true)) {
            Log.w(TAG, "Origin spoofing detected: socket claims ${peerInfo.authenticatedNodeId}, message claims ${message.senderPeerId}")
            sendErrorMessage(peerInfo.connectionId, message.messageId, "SPOOFED_ORIGIN", "Sender peer ID does not match authenticated socket identity")
            return
        }

        // 2. Validate structural integrity and signature
        val pubBytes = peerInfo.authenticatedPublicKeyHex?.let {
            try { cryptoProvider.fromHex(it) } catch (_: Exception) { null }
        }
        val validation = message.validate(
            expectedRecipientPeerId = localNodeId,
            cryptoProvider = cryptoProvider,
            senderPublicKeyBytes = pubBytes
        )

        if (validation is MessageValidationResult.Invalid) {
            Log.w(TAG, "Invalid message from ${message.senderPeerId}: ${validation.reason}")
            sendErrorMessage(peerInfo.connectionId, message.messageId, "VALIDATION_FAILED", validation.reason)
            val errRecord = ReliableMessageRecord(
                id = message.messageId,
                direction = MessageDirection.INCOMING,
                remotePeerId = message.senderPeerId,
                messageType = message.messageType,
                payload = message.payload,
                timestamp = message.timestamp,
                status = DeliveryStatus.FAILED,
                errorCode = validation.reason
            )
            addMessageRecord(errRecord)
            return
        }

        // Update session lastSeen and message counters
        session?.let { s ->
            sessionMap[s.sessionId] = s.copy(
                lastSeenTimestamp = System.currentTimeMillis(),
                messagesReceivedCount = s.messagesReceivedCount + 1,
                state = P2pSessionState.ACTIVE
            )
            publishSessions()
        }

        // 3. Route by message type
        when (message.messageType) {
            P2pMessageType.ACK -> {
                deliveryManager.handleAckReceived(message)
                val record = ReliableMessageRecord(
                    id = message.messageId,
                    direction = MessageDirection.INCOMING,
                    remotePeerId = message.senderPeerId,
                    messageType = P2pMessageType.ACK,
                    payload = message.payload,
                    timestamp = message.timestamp,
                    status = DeliveryStatus.ACKNOWLEDGED,
                    ackForMessageId = message.ackForMessageId
                )
                addMessageRecord(record)
            }
            P2pMessageType.PING -> {
                // Reply with PONG immediately
                val pong = heartbeatMonitor.createPongResponse(message, localNodeId)
                connectionManager.sendRawFrame(peerInfo.connectionId, FrameType.RELIABLE_MSG, pong.toJson().toByteArray(Charsets.UTF_8))
                val record = ReliableMessageRecord(
                    id = message.messageId,
                    direction = MessageDirection.INCOMING,
                    remotePeerId = message.senderPeerId,
                    messageType = P2pMessageType.PING,
                    payload = message.payload,
                    timestamp = message.timestamp,
                    status = DeliveryStatus.ACKNOWLEDGED
                )
                addMessageRecord(record)
            }
            P2pMessageType.PONG -> {
                val rtt = Math.max(1L, System.currentTimeMillis() - message.timestamp)
                session?.let { s ->
                    peerHealthMonitor?.recordHeartbeatSuccess(s.peerId, rtt)
                    updateSessionHealth(s.sessionId, ConnectionHealth.computeHealth(s.state, System.currentTimeMillis(), rtt), rtt)
                }
                val record = ReliableMessageRecord(
                    id = message.messageId,
                    direction = MessageDirection.INCOMING,
                    remotePeerId = message.senderPeerId,
                    messageType = P2pMessageType.PONG,
                    payload = message.payload,
                    timestamp = message.timestamp,
                    status = DeliveryStatus.ACKNOWLEDGED,
                    roundTripLatencyMs = rtt,
                    ackForMessageId = message.ackForMessageId
                )
                addMessageRecord(record)
            }
            P2pMessageType.DATA, P2pMessageType.PEER_HELLO, P2pMessageType.PEER_STATUS -> {
                // Check duplicate detection
                val isNew = deliveryManager.deduplicationCache.checkAndMarkProcessed(message.messageId)

                // Always send ACK back to satisfy sender retry engine
                val ack = P2pMessage.createAck(message, localNodeId)
                connectionManager.sendRawFrame(peerInfo.connectionId, FrameType.RELIABLE_MSG, ack.toJson().toByteArray(Charsets.UTF_8))

                val record = ReliableMessageRecord(
                    id = message.messageId,
                    direction = MessageDirection.INCOMING,
                    remotePeerId = message.senderPeerId,
                    messageType = message.messageType,
                    payload = message.payload,
                    timestamp = message.timestamp,
                    status = DeliveryStatus.ACKNOWLEDGED,
                    isDuplicate = !isNew
                )
                addMessageRecord(record)

                if (isNew && session != null) {
                    _incomingMessages.emit(Pair(session, message))
                } else {
                    Log.d(TAG, "Suppressed duplicate message ${message.messageId} from application callback")
                }
            }
            P2pMessageType.DISCONNECT -> {
                Log.i(TAG, "Received DISCONNECT from ${message.senderPeerId}")
                session?.let { s ->
                    sessionMap[s.sessionId] = s.copy(
                        state = P2pSessionState.DISCONNECTED,
                        connectionHealth = ConnectionHealth.UNRESPONSIVE
                    )
                    publishSessions()
                }
                connectionManager.disconnectPeer(peerInfo.connectionId)
            }
            P2pMessageType.ERROR -> {
                Log.w(TAG, "Received ERROR from ${message.senderPeerId}: [${message.errorCode}] ${message.payload}")
                val record = ReliableMessageRecord(
                    id = message.messageId,
                    direction = MessageDirection.INCOMING,
                    remotePeerId = message.senderPeerId,
                    messageType = P2pMessageType.ERROR,
                    payload = message.payload,
                    timestamp = message.timestamp,
                    status = DeliveryStatus.FAILED,
                    errorCode = message.errorCode,
                    ackForMessageId = message.ackForMessageId
                )
                addMessageRecord(record)
            }
            P2pMessageType.PEER_DISCOVERY_REQUEST,
            P2pMessageType.PEER_DISCOVERY_RESPONSE,
            P2pMessageType.PEER_ANNOUNCEMENT,
            P2pMessageType.PEER_LIST_REQUEST,
            P2pMessageType.PEER_LIST_RESPONSE,
            P2pMessageType.PEER_UNAVAILABLE -> {
                val isNew = deliveryManager.deduplicationCache.checkAndMarkProcessed(message.messageId)
                if (message.messageType.requiresAck) {
                    val ack = P2pMessage.createAck(message, localNodeId)
                    connectionManager.sendRawFrame(peerInfo.connectionId, FrameType.RELIABLE_MSG, ack.toJson().toByteArray(Charsets.UTF_8))
                }

                if (!isNew || session == null) {
                    return
                }

                val pex = peerExchangeService
                if (pex == null) {
                    addMessageRecord(
                        ReliableMessageRecord(
                            id = message.messageId,
                            direction = MessageDirection.INCOMING,
                            remotePeerId = message.senderPeerId,
                            messageType = message.messageType,
                            payload = message.payload,
                            timestamp = message.timestamp,
                            status = DeliveryStatus.ACKNOWLEDGED
                        )
                    )
                    return
                }

                val (localHost, localPort) = localHostPortProvider?.invoke() ?: Pair("127.0.0.1", 0)
                when (val res = pex.processIncomingPexMessage(message, session, localHost, localPort)) {
                    is ProcessPexResult.ResponseReady -> {
                        addMessageRecord(
                            ReliableMessageRecord(
                                id = message.messageId,
                                direction = MessageDirection.INCOMING,
                                remotePeerId = message.senderPeerId,
                                messageType = message.messageType,
                                payload = message.payload,
                                timestamp = message.timestamp,
                                status = DeliveryStatus.ACKNOWLEDGED
                            )
                        )
                        sendPexMessage(peerInfo.connectionId, res.responseMessage)
                    }
                    is ProcessPexResult.Ingested -> {
                        addMessageRecord(
                            ReliableMessageRecord(
                                id = message.messageId,
                                direction = MessageDirection.INCOMING,
                                remotePeerId = message.senderPeerId,
                                messageType = message.messageType,
                                payload = message.payload,
                                timestamp = message.timestamp,
                                status = DeliveryStatus.ACKNOWLEDGED
                            )
                        )
                        if (res.newPeersCount > 0 || res.updatedPeersCount > 0) {
                            onPexPeersIngested?.invoke(res.newPeersCount, res.updatedPeersCount)
                        }
                    }
                    is ProcessPexResult.RateLimited -> {
                        sendErrorMessage(peerInfo.connectionId, message.messageId, "RATE_LIMITED", "PEX rate limit exceeded")
                        addMessageRecord(
                            ReliableMessageRecord(
                                id = message.messageId,
                                direction = MessageDirection.INCOMING,
                                remotePeerId = message.senderPeerId,
                                messageType = message.messageType,
                                payload = message.payload,
                                timestamp = message.timestamp,
                                status = DeliveryStatus.FAILED,
                                errorCode = "RATE_LIMITED"
                            )
                        )
                    }
                    is ProcessPexResult.Rejected -> {
                        sendErrorMessage(peerInfo.connectionId, message.messageId, "PEX_REJECTED", res.reason)
                        addMessageRecord(
                            ReliableMessageRecord(
                                id = message.messageId,
                                direction = MessageDirection.INCOMING,
                                remotePeerId = message.senderPeerId,
                                messageType = message.messageType,
                                payload = message.payload,
                                timestamp = message.timestamp,
                                status = DeliveryStatus.FAILED,
                                errorCode = res.reason
                            )
                        )
                    }
                    ProcessPexResult.Ignored -> Unit
                }
            }
            P2pMessageType.TX_ANNOUNCEMENT,
            P2pMessageType.TX_PAYLOAD,
            P2pMessageType.TX_ACK -> {
                val isNew = deliveryManager.deduplicationCache.checkAndMarkProcessed(message.messageId)
                if (message.messageType.requiresAck) {
                    val ack = P2pMessage.createAck(message, localNodeId)
                    connectionManager.sendRawFrame(peerInfo.connectionId, FrameType.RELIABLE_MSG, ack.toJson().toByteArray(Charsets.UTF_8))
                }
                addMessageRecord(
                    ReliableMessageRecord(
                        id = message.messageId,
                        direction = MessageDirection.INCOMING,
                        remotePeerId = message.senderPeerId,
                        messageType = message.messageType,
                        payload = message.payload,
                        timestamp = message.timestamp,
                        status = DeliveryStatus.ACKNOWLEDGED,
                        isDuplicate = !isNew
                    )
                )
                if (isNew && session != null && message.messageType != P2pMessageType.TX_ACK) {
                    onIncomingTransactionMessage?.invoke(session, message)
                }
            }
            P2pMessageType.BLOCK_PROPOSAL,
            P2pMessageType.CONSENSUS_PREVOTE,
            P2pMessageType.CONSENSUS_PRECOMMIT,
            P2pMessageType.CONSENSUS_COMMIT,
            P2pMessageType.ROUND_CHANGE,
            P2pMessageType.VALIDATOR_STATUS -> {
                val isNew = deliveryManager.deduplicationCache.checkAndMarkProcessed(message.messageId)
                if (message.messageType.requiresAck) {
                    val ack = P2pMessage.createAck(message, localNodeId)
                    connectionManager.sendRawFrame(peerInfo.connectionId, FrameType.RELIABLE_MSG, ack.toJson().toByteArray(Charsets.UTF_8))
                }
                addMessageRecord(
                    ReliableMessageRecord(
                        id = message.messageId,
                        direction = MessageDirection.INCOMING,
                        remotePeerId = message.senderPeerId,
                        messageType = message.messageType,
                        payload = message.payload,
                        timestamp = message.timestamp,
                        status = DeliveryStatus.ACKNOWLEDGED,
                        isDuplicate = !isNew
                    )
                )
                if (isNew && session != null) {
                    onIncomingConsensusMessage?.invoke(session, message)
                }
            }
            P2pMessageType.CHAIN_STATUS_REQUEST,
            P2pMessageType.CHAIN_STATUS_RESPONSE,
            P2pMessageType.BLOCK_HEADERS_REQUEST,
            P2pMessageType.BLOCK_HEADERS_RESPONSE,
            P2pMessageType.BLOCKS_REQUEST,
            P2pMessageType.BLOCKS_RESPONSE -> {
                val isNew = deliveryManager.deduplicationCache.checkAndMarkProcessed(message.messageId)
                if (message.messageType.requiresAck) {
                    val ack = P2pMessage.createAck(message, localNodeId)
                    connectionManager.sendRawFrame(peerInfo.connectionId, FrameType.RELIABLE_MSG, ack.toJson().toByteArray(Charsets.UTF_8))
                }
                addMessageRecord(
                    ReliableMessageRecord(
                        id = message.messageId,
                        direction = MessageDirection.INCOMING,
                        remotePeerId = message.senderPeerId,
                        messageType = message.messageType,
                        payload = message.payload,
                        timestamp = message.timestamp,
                        status = DeliveryStatus.ACKNOWLEDGED,
                        isDuplicate = !isNew
                    )
                )
                if (isNew && session != null) {
                    onIncomingSyncMessage?.invoke(session, message)
                }
            }
        }
    }

    private suspend fun sendErrorMessage(
        connectionId: String,
        originalMessageId: String?,
        errorCode: String,
        errorDesc: String
    ) {
        val localIdentity = identityManager.getActiveIdentity() ?: return
        val errMessage = P2pMessage.createError(
            originalMessageId = originalMessageId,
            senderPeerId = localIdentity.nodeId,
            recipientPeerId = P2pMessage.BROADCAST_RECIPIENT,
            errorCode = errorCode,
            errorMessage = errorDesc
        )
        try {
            connectionManager.sendRawFrame(connectionId, FrameType.RELIABLE_MSG, errMessage.toJson().toByteArray(Charsets.UTF_8))
        } catch (_: Exception) {}
    }

    private fun addMessageRecord(record: ReliableMessageRecord) {
        _reliableMessageLog.value = listOf(record) + _reliableMessageLog.value.take(99)
    }

    /**
     * Executes the P2P Protocol Test Lab verification scenarios.
     */
    suspend fun runTestLabSuite(targetSessionId: String): P2pTestLabReport = withContext(ioDispatcher) {
        val results = mutableListOf<P2pTestScenarioResult>()
        val session = sessionMap[targetSessionId]

        if (session == null || !session.isTrusted) {
            results.add(
                P2pTestScenarioResult(
                    testName = "Peer Session Active Check",
                    isSuccess = false,
                    details = "No authenticated peer session selected for test run",
                    durationMs = 0L
                )
            )
            val report = P2pTestLabReport(totalTests = 1, passedTests = 0, results = results)
            _testReport.value = report
            return@withContext report
        }

        // Scenario 1: Bidirectional Message & ACK Verification
        val t1Start = System.currentTimeMillis()
        val sendResult = sendReliableMessage(
            sessionId = targetSessionId,
            messageType = P2pMessageType.DATA,
            payload = "{\"test\":\"bidirectional_ack\",\"timestamp\":$t1Start}"
        )
        val t1Duration = System.currentTimeMillis() - t1Start
        results.add(
            P2pTestScenarioResult(
                testName = "Bidirectional Message & ACK Delivery",
                isSuccess = sendResult.isSuccess,
                details = if (sendResult.isSuccess) "ACK received with ${sendResult.getOrNull()?.roundTripLatencyMs}ms latency" else sendResult.exceptionOrNull()?.message ?: "Failed",
                durationMs = t1Duration
            )
        )

        // Scenario 2: Heartbeat PING & PONG Latency Measurement
        val t2Start = System.currentTimeMillis()
        val pingResult = sendManualPing(targetSessionId)
        val t2Duration = System.currentTimeMillis() - t2Start
        results.add(
            P2pTestScenarioResult(
                testName = "Heartbeat PING & PONG Health Check",
                isSuccess = pingResult.isSuccess,
                details = if (pingResult.isSuccess) "PONG reply verified in ${pingResult.getOrNull()}ms" else pingResult.exceptionOrNull()?.message ?: "Failed",
                durationMs = t2Duration
            )
        )

        // Scenario 3: Duplicate Message Ingestion & Suppression Test
        val t3Start = System.currentTimeMillis()
        val localId = identityManager.getActiveIdentity()?.nodeId ?: "local"
        val testMsgId = "dup-test-${UUID.randomUUID()}"
        val firstProcessed = deliveryManager.deduplicationCache.checkAndMarkProcessed(testMsgId)
        val secondProcessed = deliveryManager.deduplicationCache.checkAndMarkProcessed(testMsgId)
        val duplicateDetected = firstProcessed && !secondProcessed
        val t3Duration = System.currentTimeMillis() - t3Start
        results.add(
            P2pTestScenarioResult(
                testName = "Duplicate Message Detection & Suppression",
                isSuccess = duplicateDetected,
                details = if (duplicateDetected) "Duplicate message ID successfully identified and suppressed" else "Deduplication failed",
                durationMs = t3Duration
            )
        )

        // Scenario 4: Controlled Timeout Handling
        val t4Start = System.currentTimeMillis()
        val timeoutMsg = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            senderPeerId = localId,
            recipientPeerId = session.peerId,
            messageType = P2pMessageType.DATA,
            payload = "{\"simulate\":\"timeout\"}"
        )
        // Send with dummy action that drops packet to verify timeout triggers cleanly
        val timeoutResult = deliveryManager.sendReliably(
            message = timeoutMsg,
            targetSessionId = "dummy-session",
            sendAction = { /* drop packet to simulate network loss */ },
            maxRetries = 2,
            ackTimeoutMs = 300L
        )
        val t4Duration = System.currentTimeMillis() - t4Start
        val timeoutHandledCleanly = timeoutResult.status == DeliveryStatus.TIMED_OUT
        results.add(
            P2pTestScenarioResult(
                testName = "Controlled Retry & Timeout Management",
                isSuccess = timeoutHandledCleanly,
                details = if (timeoutHandledCleanly) "Controlled retry triggered and bounded timeout handled in ${t4Duration}ms" else "Timeout not handled",
                durationMs = t4Duration
            )
        )

        // Scenario 5: Cryptographic Tampering Rejection
        val t5Start = System.currentTimeMillis()
        val validMsg = P2pMessage(
            messageId = UUID.randomUUID().toString(),
            senderPeerId = localId,
            recipientPeerId = session.peerId,
            messageType = P2pMessageType.DATA,
            payload = "{\"tamper\":false}"
        )
        val goodBytes = validMsg.getCanonicalBytes()
        val goodSig = cryptoProvider.toHex(identityManager.signRawData(goodBytes))
        val tamperedMsg = validMsg.copy(payload = "{\"tamper\":true}", signatureHex = goodSig)
        val pubBytes = identityManager.getActiveIdentity()?.publicKeyHex?.let { cryptoProvider.fromHex(it) }
        val tamperValidation = tamperedMsg.validate(
            expectedRecipientPeerId = session.peerId,
            cryptoProvider = cryptoProvider,
            senderPublicKeyBytes = pubBytes
        )
        val tamperRejected = tamperValidation is MessageValidationResult.Invalid
        val t5Duration = System.currentTimeMillis() - t5Start
        results.add(
            P2pTestScenarioResult(
                testName = "Cryptographic Tampering Rejection",
                isSuccess = tamperRejected,
                details = if (tamperRejected) "Tampered payload rejected: ${(tamperValidation as MessageValidationResult.Invalid).reason}" else "Tampered message accepted",
                durationMs = t5Duration
            )
        )

        val passedCount = results.count { it.isSuccess }
        val report = P2pTestLabReport(
            totalTests = results.size,
            passedTests = passedCount,
            results = results
        )
        _testReport.value = report
        report
    }

    fun clearTestReport() {
        _testReport.value = null
    }

    override fun close() {
        frameCollectorJob?.cancel()
        peerSyncJob?.cancel()
        heartbeatTickerJob?.cancel()
        heartbeatMonitor.stop()
        deliveryManager.clear()
        sessionMap.clear()
        _sessions.value = emptyList()
    }
}
