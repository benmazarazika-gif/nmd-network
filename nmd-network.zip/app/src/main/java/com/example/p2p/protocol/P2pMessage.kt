package com.example.p2p.protocol

import com.example.crypto.provider.CryptographicProvider
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.util.UUID

/**
 * Extensible message types supported by the Stage 6 NMD P2P messaging protocol.
 */
enum class P2pMessageType {
    PING,
    PONG,
    PEER_HELLO,
    PEER_STATUS,
    DATA,
    ACK,
    DISCONNECT,
    ERROR,

    // Stage 7: Distributed Peer Discovery & Exchange (PEX)
    PEER_DISCOVERY_REQUEST,
    PEER_DISCOVERY_RESPONSE,
    PEER_ANNOUNCEMENT,
    PEER_LIST_REQUEST,
    PEER_LIST_RESPONSE,
    PEER_UNAVAILABLE,

    // Stage 9: Transaction Propagation
    TX_ANNOUNCEMENT,
    TX_PAYLOAD,
    TX_ACK,

    // Stage 10: Distributed Consensus Protocol
    BLOCK_PROPOSAL,
    CONSENSUS_PREVOTE,
    CONSENSUS_PRECOMMIT,
    CONSENSUS_COMMIT,
    ROUND_CHANGE,
    VALIDATOR_STATUS,

    // Stage 12: Blockchain Synchronization Protocol
    CHAIN_STATUS_REQUEST,
    CHAIN_STATUS_RESPONSE,
    BLOCK_HEADERS_REQUEST,
    BLOCK_HEADERS_RESPONSE,
    BLOCKS_REQUEST,
    BLOCKS_RESPONSE;

    val requiresAck: Boolean
        get() = this == DATA || this == PEER_HELLO || this == PEER_STATUS ||
                this == PEER_DISCOVERY_REQUEST || this == PEER_ANNOUNCEMENT ||
                this == PEER_LIST_REQUEST || this == TX_PAYLOAD ||
                this == BLOCK_PROPOSAL || this == CONSENSUS_COMMIT ||
                this == ROUND_CHANGE || this == CHAIN_STATUS_REQUEST ||
                this == BLOCK_HEADERS_REQUEST || this == BLOCKS_REQUEST
}

/**
 * Structured application-level P2P message for the NMD network.
 *
 * Supports unique message IDs, versioning, bilateral peer identities,
 * cryptographic signatures, delivery acknowledgements, and error reporting.
 */
data class P2pMessage(
    val messageId: String = UUID.randomUUID().toString(),
    val protocolVersion: Int = CURRENT_PROTOCOL_VERSION,
    val senderPeerId: String,
    val recipientPeerId: String,
    val messageType: P2pMessageType,
    val timestamp: Long = System.currentTimeMillis(),
    val sequenceNumber: Long = 0L,
    val payload: String = "",
    val signatureHex: String? = null,
    val ackForMessageId: String? = null,
    val errorCode: String? = null
) {
    companion object {
        const val CURRENT_PROTOCOL_VERSION = 1
        const val BROADCAST_RECIPIENT = "*"
        const val MAX_TIMESTAMP_DRIFT_MS = 120_000L // 2 minutes

        private const val CANONICAL_DOMAIN_HEADER = "NMD-P2P-MSG-V1\u0000"

        fun createAck(
            originalMessage: P2pMessage,
            senderPeerId: String,
            sequenceNumber: Long = 0L,
            payload: String = "{\"status\":\"ACK_RECEIVED\"}"
        ): P2pMessage {
            return P2pMessage(
                messageId = UUID.randomUUID().toString(),
                protocolVersion = CURRENT_PROTOCOL_VERSION,
                senderPeerId = senderPeerId,
                recipientPeerId = originalMessage.senderPeerId,
                messageType = P2pMessageType.ACK,
                timestamp = System.currentTimeMillis(),
                sequenceNumber = sequenceNumber,
                payload = payload,
                ackForMessageId = originalMessage.messageId
            )
        }

        fun createError(
            originalMessageId: String?,
            senderPeerId: String,
            recipientPeerId: String,
            errorCode: String,
            errorMessage: String
        ): P2pMessage {
            return P2pMessage(
                messageId = UUID.randomUUID().toString(),
                protocolVersion = CURRENT_PROTOCOL_VERSION,
                senderPeerId = senderPeerId,
                recipientPeerId = recipientPeerId,
                messageType = P2pMessageType.ERROR,
                timestamp = System.currentTimeMillis(),
                payload = errorMessage,
                ackForMessageId = originalMessageId,
                errorCode = errorCode
            )
        }

        fun fromJson(jsonStr: String): P2pMessage? {
            return try {
                val json = JSONObject(jsonStr)
                P2pMessage(
                    messageId = json.getString("message_id"),
                    protocolVersion = json.optInt("protocol_version", CURRENT_PROTOCOL_VERSION),
                    senderPeerId = json.getString("sender_peer_id"),
                    recipientPeerId = json.optString("recipient_peer_id", BROADCAST_RECIPIENT),
                    messageType = P2pMessageType.valueOf(json.getString("message_type")),
                    timestamp = json.getLong("timestamp"),
                    sequenceNumber = json.optLong("sequence_number", 0L),
                    payload = json.optString("payload", ""),
                    signatureHex = if (json.has("signature") && !json.isNull("signature")) json.getString("signature") else null,
                    ackForMessageId = if (json.has("ack_for_message_id") && !json.isNull("ack_for_message_id")) json.getString("ack_for_message_id") else null,
                    errorCode = if (json.has("error_code") && !json.isNull("error_code")) json.getString("error_code") else null
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    /**
     * Builds deterministic, canonical binary bytes for digital signature generation and verification.
     * Prevents ambiguity, delimiter collision, and tampering.
     */
    fun getCanonicalBytes(): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.write(CANONICAL_DOMAIN_HEADER.toByteArray(Charsets.UTF_8))
        dos.writeInt(protocolVersion)
        dos.writeUTF(messageId)
        dos.writeUTF(senderPeerId)
        dos.writeUTF(recipientPeerId)
        dos.writeUTF(messageType.name)
        dos.writeLong(timestamp)
        dos.writeLong(sequenceNumber)
        val payloadBytes = payload.toByteArray(Charsets.UTF_8)
        dos.writeInt(payloadBytes.size)
        dos.write(payloadBytes)
        dos.writeUTF(ackForMessageId ?: "")
        dos.writeUTF(errorCode ?: "")
        dos.flush()
        return baos.toByteArray()
    }

    fun toJson(): String {
        val json = JSONObject()
        json.put("message_id", messageId)
        json.put("protocol_version", protocolVersion)
        json.put("sender_peer_id", senderPeerId)
        json.put("recipient_peer_id", recipientPeerId)
        json.put("message_type", messageType.name)
        json.put("timestamp", timestamp)
        json.put("sequence_number", sequenceNumber)
        json.put("payload", payload)
        if (signatureHex != null) {
            json.put("signature", signatureHex)
        }
        if (ackForMessageId != null) {
            json.put("ack_for_message_id", ackForMessageId)
        }
        if (errorCode != null) {
            json.put("error_code", errorCode)
        }
        return json.toString()
    }

    /**
     * Validates structural integrity, timestamp drift, and signature if required.
     */
    fun validate(
        expectedRecipientPeerId: String? = null,
        cryptoProvider: CryptographicProvider? = null,
        senderPublicKeyBytes: ByteArray? = null
    ): MessageValidationResult {
        if (messageId.isBlank()) {
            return MessageValidationResult.Invalid("Empty message ID")
        }
        if (senderPeerId.isBlank()) {
            return MessageValidationResult.Invalid("Empty sender peer ID")
        }
        if (protocolVersion != CURRENT_PROTOCOL_VERSION) {
            return MessageValidationResult.Invalid("Unsupported protocol version: $protocolVersion (expected $CURRENT_PROTOCOL_VERSION)")
        }

        val now = System.currentTimeMillis()
        if (Math.abs(now - timestamp) > MAX_TIMESTAMP_DRIFT_MS) {
            return MessageValidationResult.Invalid("Timestamp expired or in future: drift ${Math.abs(now - timestamp)}ms > $MAX_TIMESTAMP_DRIFT_MS ms")
        }

        if (expectedRecipientPeerId != null &&
            recipientPeerId != BROADCAST_RECIPIENT &&
            !recipientPeerId.equals(expectedRecipientPeerId, ignoreCase = true)
        ) {
            return MessageValidationResult.Invalid("Recipient mismatch: expected $expectedRecipientPeerId, got $recipientPeerId")
        }

        if (signatureHex != null && cryptoProvider != null && senderPublicKeyBytes != null) {
            try {
                val sigBytes = cryptoProvider.fromHex(signatureHex)
                val canonicalBytes = getCanonicalBytes()
                val isValid = cryptoProvider.verify(
                    publicKeyBytes = senderPublicKeyBytes,
                    data = canonicalBytes,
                    signature = sigBytes
                )
                if (!isValid) {
                    return MessageValidationResult.Invalid("Cryptographic signature verification failed")
                }
            } catch (e: Exception) {
                return MessageValidationResult.Invalid("Signature verification error: ${e.message}")
            }
        }

        return MessageValidationResult.Valid
    }
}

sealed class MessageValidationResult {
    object Valid : MessageValidationResult()
    data class Invalid(val reason: String) : MessageValidationResult()
}
