package com.example.p2p.connectivity.selector

import com.example.p2p.connectivity.model.IceCandidateInfo
import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.IpVersion
import com.example.p2p.connectivity.model.NatTraversalConfig
import com.example.p2p.connectivity.model.TransportPathType
import java.net.Inet4Address
import java.net.InetAddress

enum class ConnectivityAttemptStage {
    LOCAL_DIRECT_TCP,
    ICE_DIRECT,
    TURN_RELAY,
    FAILED
}

data class PathDecision(
    val selectedPath: TransportPathType,
    val orderedFallbackPlan: List<ConnectivityAttemptStage>,
    val reason: String
)

/**
 * Selects and prioritizes NMD P2P connectivity paths strictly in order:
 * 1. Direct local network TCP (when local subnet / LAN peer endpoint is reachable)
 * 2. Direct internet via ICE (HOST -> PRFLX -> SRFLX; IPv4 & IPv6 candidates)
 * 3. TURN relay fallback (when direct ICE connectivity checks fail and valid TURN is configured)
 * 4. Explicit connectivity failure (NO_CONNECTIVITY)
 */
class NetworkPathSelector(
    private val config: NatTraversalConfig = NatTraversalConfig()
) {

    fun buildConnectivityPlan(
        hasLocalEndpoint: Boolean,
        hasSignalingChannel: Boolean,
        hasValidTurnRelay: Boolean
    ): PathDecision {
        val plan = mutableListOf<ConnectivityAttemptStage>()
        if (hasLocalEndpoint && config.preferLocalDirectBeforeIce) {
            plan.add(ConnectivityAttemptStage.LOCAL_DIRECT_TCP)
        }
        if (hasSignalingChannel) {
            plan.add(ConnectivityAttemptStage.ICE_DIRECT)
            if (hasValidTurnRelay) {
                plan.add(ConnectivityAttemptStage.TURN_RELAY)
            }
        }
        if (hasLocalEndpoint && !config.preferLocalDirectBeforeIce) {
            plan.add(ConnectivityAttemptStage.LOCAL_DIRECT_TCP)
        }
        if (plan.isEmpty()) {
            plan.add(ConnectivityAttemptStage.FAILED)
        }

        val initialPath = when (plan.first()) {
            ConnectivityAttemptStage.LOCAL_DIRECT_TCP -> TransportPathType.LOCAL_DIRECT_TCP
            ConnectivityAttemptStage.ICE_DIRECT -> TransportPathType.ICE_DIRECT
            ConnectivityAttemptStage.TURN_RELAY -> TransportPathType.TURN_RELAY
            ConnectivityAttemptStage.FAILED -> TransportPathType.NONE
        }

        val reason = buildString {
            append("Plan: ${plan.joinToString(" -> ") { it.name }}")
            if (!hasValidTurnRelay) {
                append(" (TURN relay fallback unavailable)")
            }
        }
        return PathDecision(
            selectedPath = initialPath,
            orderedFallbackPlan = plan,
            reason = reason
        )
    }

    /**
     * Ranks ICE candidates so direct candidates are always checked and nominated ahead of
     * relayed candidates (HOST > PRFLX > SRFLX > RELAY), then by RFC 8445 priority.
     */
    fun rankCandidates(candidates: List<IceCandidateInfo>): List<IceCandidateInfo> {
        return candidates
            .filter { config.enableIpv6Candidates || it.ipVersion != IpVersion.IPV6 }
            .sortedWith(
                compareBy<IceCandidateInfo> { candidateTypeRank(it.type) }
                    .thenByDescending { it.priority }
            )
    }

    fun classifyPathFromCandidateType(type: IceCandidateType?): TransportPathType {
        return when (type) {
            IceCandidateType.RELAY -> TransportPathType.TURN_RELAY
            IceCandidateType.HOST, IceCandidateType.SRFLX, IceCandidateType.PRFLX -> TransportPathType.ICE_DIRECT
            IceCandidateType.UNKNOWN, null -> TransportPathType.NONE
        }
    }

    /**
     * Checks if a candidate host string likely sits on the same RFC 1918 / link-local / loopback LAN.
     */
    fun isLikelyLocalLanHost(host: String, localIp: String? = null): Boolean {
        if (host.equals("127.0.0.1", ignoreCase = true) ||
            host.equals("localhost", ignoreCase = true) ||
            host.equals("::1", ignoreCase = true)
        ) {
            return true
        }
        return try {
            val targetAddr = InetAddress.getByName(host)
            if (targetAddr.isLoopbackAddress || targetAddr.isSiteLocalAddress || targetAddr.isLinkLocalAddress) {
                if (localIp.isNullOrBlank() || localIp == "127.0.0.1") {
                    true
                } else if (targetAddr is Inet4Address) {
                    val localAddr = InetAddress.getByName(localIp)
                    if (localAddr is Inet4Address) {
                        val a = targetAddr.address
                        val b = localAddr.address
                        // Same /24 heuristic on private LANs, still allowed fallback to ICE if unreachable
                        a[0] == b[0] && a[1] == b[1] && a[2] == b[2]
                    } else true
                } else true
            } else false
        } catch (_: Exception) {
            false
        }
    }

    private fun candidateTypeRank(type: IceCandidateType): Int {
        return when (type) {
            IceCandidateType.HOST -> 0
            IceCandidateType.PRFLX -> 1
            IceCandidateType.SRFLX -> 2
            IceCandidateType.RELAY -> 3
            IceCandidateType.UNKNOWN -> 4
        }
    }
}
