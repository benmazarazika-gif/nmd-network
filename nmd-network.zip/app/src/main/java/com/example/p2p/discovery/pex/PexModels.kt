package com.example.p2p.discovery.pex

import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.CryptographicProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.util.UUID

/**
 * SignedPeerAnnouncement represents a self-authenticated peer node descriptor.
 *
 * Implements Stage 7 security requirements:
 * - Domain separator: NMD-PEX-ANNOUNCEMENT-V1\0
 * - Bound to public key and cryptographically derived node ID
 * - Nonce & timestamp for strict replay protection and freshness validation
 * - Ed25519 digital signature verification
 * - Safe IP address & port validation (rejects invalid/broadcast/multicast/unspecified)
 */
data class SignedPeerAnnouncement(
    val peerId: String,
    val publicKeyHex: String,
    val host: String,
    val port: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val nonce: String = UUID.randomUUID().toString(),
    val protocolVersion: Int = 1,
    val capabilities: List<String> = listOf("p2p", "stage7_discovery"),
    val signatureHex: String? = null
) {
    companion object {
        const val CANONICAL_DOMAIN = "NMD-PEX-ANNOUNCEMENT-V1\u0000"
        const val MAX_FRESHNESS_DRIFT_MS = 120_000L // 2 minutes
        private val VALID_HOST_REGEX = Regex("^[a-zA-Z0-9.\\-:]{1,253}$")

        fun fromJson(json: JSONObject): SignedPeerAnnouncement? {
            return try {
                val peerId = json.getString("peer_id")
                val pubKey = json.getString("public_key_hex")
                val host = json.getString("host")
                val port = json.getInt("port")
                val timestamp = json.getLong("timestamp")
                val nonce = json.optString("nonce", "")
                val ver = json.optInt("protocol_version", 1)
                val sig = if (json.has("signature") && !json.isNull("signature")) json.getString("signature") else null
                val caps = mutableListOf<String>()
                if (json.has("capabilities")) {
                    val arr = json.getJSONArray("capabilities")
                    for (i in 0 until Math.min(arr.length(), 16)) {
                        caps.add(arr.getString(i))
                    }
                } else {
                    caps.addAll(listOf("p2p", "stage7_discovery"))
                }
                SignedPeerAnnouncement(
                    peerId = peerId,
                    publicKeyHex = pubKey,
                    host = host,
                    port = port,
                    timestamp = timestamp,
                    nonce = nonce,
                    protocolVersion = ver,
                    capabilities = caps,
                    signatureHex = sig
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    /**
     * Constructs deterministic canonical bytes for signature generation and verification.
     */
    fun getCanonicalBytes(): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.write(CANONICAL_DOMAIN.toByteArray(Charsets.UTF_8))
        dos.writeInt(protocolVersion)
        dos.writeUTF(peerId)
        dos.writeUTF(publicKeyHex)
        dos.writeUTF(host)
        dos.writeInt(port)
        dos.writeLong(timestamp)
        dos.writeUTF(nonce)
        dos.writeInt(capabilities.size)
        capabilities.forEach { dos.writeUTF(it) }
        dos.flush()
        return baos.toByteArray()
    }

    /**
     * Signs this announcement using the local node's private key.
     */
    fun sign(identityManager: NodeIdentityManager): SignedPeerAnnouncement {
        val bytes = getCanonicalBytes()
        val sig = identityManager.signRawData(bytes)
        val sigHex = identityManager.repository.cryptoProvider.toHex(sig)
        return this.copy(signatureHex = sigHex)
    }

    /**
     * Verifies both identity binding (peerId == deriveNodeId(publicKey)) and Ed25519 signature.
     */
    fun verify(cryptoProvider: CryptographicProvider): Boolean {
        if (signatureHex.isNullOrBlank() || nonce.isBlank()) return false
        return try {
            val pubBytes = cryptoProvider.fromHex(publicKeyHex)
            val derivedNodeId = cryptoProvider.deriveNodeId(pubBytes)
            if (!derivedNodeId.equals(peerId, ignoreCase = true)) {
                return false
            }
            val sigBytes = cryptoProvider.fromHex(signatureHex)
            val canonicalBytes = getCanonicalBytes()
            cryptoProvider.verify(
                publicKeyBytes = pubBytes,
                data = canonicalBytes,
                signature = sigBytes
            )
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Validates that the announcement timestamp is not expired or from the future.
     */
    fun validateFreshness(maxDriftMs: Long = MAX_FRESHNESS_DRIFT_MS, nowMs: Long = System.currentTimeMillis()): Boolean {
        return Math.abs(nowMs - timestamp) <= maxDriftMs
    }

    /**
     * Validates that the network address and port are safe, valid, and routable.
     * Rejects broadcast (255.255.255.255), unspecified (0.0.0.0, ::), multicast, and invalid ports.
     * Avoids blocking DNS lookups for numeric IPs.
     */
    fun validateAddress(): Boolean {
        if (port !in 1..65535) return false
        val trimmed = host.trim()
        if (trimmed.isBlank() || trimmed.length > 253) return false
        if (!VALID_HOST_REGEX.matches(trimmed)) return false
        if (trimmed == "0.0.0.0" || trimmed == "::" || trimmed == "::0" || trimmed == "255.255.255.255") {
            return false
        }
        // Validate numeric IPv4 octets quickly without DNS
        val ipv4Parts = trimmed.split(".")
        if (ipv4Parts.size == 4 && ipv4Parts.all { it.toIntOrNull() != null }) {
            val octets = ipv4Parts.map { it.toInt() }
            if (octets.any { it < 0 || it > 255 }) return false
            // Reject 0.x.x.x, multicast 224.0.0.0/4 (224..239), broadcast 255.x.x.x
            if (octets[0] == 0 || octets[0] in 224..255) return false
            return true
        }
        // Fallback check via InetAddress for IPv6 or literal hostnames (avoid DNS hangs for invalid chars)
        return try {
            val inet = InetAddress.getByName(trimmed)
            !inet.isMulticastAddress && !inet.isAnyLocalAddress &&
                (inet is Inet4Address || inet is Inet6Address)
        } catch (_: Exception) {
            false
        }
    }

    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("peer_id", peerId)
        json.put("public_key_hex", publicKeyHex)
        json.put("host", host)
        json.put("port", port)
        json.put("timestamp", timestamp)
        json.put("nonce", nonce)
        json.put("protocol_version", protocolVersion)
        val caps = JSONArray()
        capabilities.forEach { caps.put(it) }
        json.put("capabilities", caps)
        if (signatureHex != null) {
            json.put("signature", signatureHex)
        }
        return json
    }
}

/**
 * Payload carried by PEER_LIST_RESPONSE and PEER_DISCOVERY_RESPONSE messages.
 */
data class PeerListPayload(
    val announcements: List<SignedPeerAnnouncement>,
    val timestamp: Long = System.currentTimeMillis()
) {
    companion object {
        const val MAX_PEERS_PER_PAYLOAD = 16

        fun fromJson(jsonStr: String): PeerListPayload? {
            return try {
                val json = JSONObject(jsonStr)
                val ts = json.optLong("timestamp", System.currentTimeMillis())
                val arr = json.getJSONArray("announcements")
                val list = mutableListOf<SignedPeerAnnouncement>()
                val limit = Math.min(arr.length(), MAX_PEERS_PER_PAYLOAD)
                for (i in 0 until limit) {
                    val item = SignedPeerAnnouncement.fromJson(arr.getJSONObject(i))
                    if (item != null) {
                        list.add(item)
                    }
                }
                PeerListPayload(announcements = list, timestamp = ts)
            } catch (_: Exception) {
                null
            }
        }
    }

    fun toJson(): String {
        val json = JSONObject()
        json.put("timestamp", timestamp)
        val arr = JSONArray()
        announcements.take(MAX_PEERS_PER_PAYLOAD).forEach { arr.put(it.toJson()) }
        json.put("announcements", arr)
        return json.toString()
    }
}
