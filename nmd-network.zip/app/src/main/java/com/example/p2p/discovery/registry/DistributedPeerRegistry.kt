package com.example.p2p.discovery.registry

import android.content.Context
import android.util.Log
import com.example.p2p.model.PeerEndpoint
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap

/**
 * DistributedPeerRegistry maintains the local device's knowledge of the NMD Network topology.
 *
 * It stores, scores, updates, and persists discovered peers across all discovery mechanisms:
 * - Local NSD (mDNS)
 * - Peer Exchange (PEX)
 * - Bootstrap nodes
 * - Manual additions
 *
 * Adheres to zero-trust principles:
 * - Advertised or exchanged peers are stored as UNAUTHENTICATED.
 * - Reputation scores track peer reliability and penalize malicious behavior.
 * - Cache sizes are bounded to protect memory and battery.
 */
class DistributedPeerRegistry(
    private val context: Context? = null,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val maxRegistryCapacity: Int = MAX_CAPACITY
) : Closeable {

    companion object {
        private const val TAG = "PeerRegistry"
        const val MAX_CAPACITY = 200
        private const val PREFS_NAME = "nmd_p2p_registry"
        private const val KEY_PEERS_JSON = "registered_peers_json"
    }

    private val mutex = Mutex()
    private val recordMap = ConcurrentHashMap<String, PeerRegistryRecord>()

    private val _peers = MutableStateFlow<List<PeerRegistryRecord>>(emptyList())
    val peers: StateFlow<List<PeerRegistryRecord>> = _peers.asStateFlow()

    init {
        loadPersistedPeers()
    }

    /**
     * Registers or updates a peer in the registry.
     * Detects duplicates (by peerId or matching endpoint) and updates lastSeen, reachability, and endpoint info.
     */
    fun registerOrUpdatePeer(
        peerId: String,
        endpoint: PeerEndpoint,
        source: DiscoverySource,
        publicKeyHex: String? = null,
        protocolVersion: Int = 1,
        reachability: ReachabilityStatus = ReachabilityStatus.UNKNOWN,
        isBootstrap: Boolean = false,
        capabilities: List<String>? = null,
        signedAnnouncementJson: String? = null
    ): PeerRegistryRecord {
        // Deduplicate by endpoint if a provisional placeholder key existed
        val existingByEndpoint = recordMap.values.find {
            it.peerId != peerId &&
                it.endpoint.host == endpoint.host &&
                it.endpoint.port == endpoint.port &&
                (it.peerId.startsWith("nsd_") || it.peerId.startsWith("manual_") || it.peerId.startsWith("bootstrap_"))
        }
        val baseRecord = recordMap[peerId] ?: existingByEndpoint
        if (existingByEndpoint != null && existingByEndpoint.peerId != peerId) {
            recordMap.remove(existingByEndpoint.peerId)
        }

        val now = System.currentTimeMillis()

        val updated = if (baseRecord != null) {
            baseRecord.copy(
                peerId = peerId,
                endpoint = endpoint,
                publicKeyHex = publicKeyHex ?: baseRecord.publicKeyHex,
                protocolVersion = protocolVersion,
                lastSeenTimestamp = now,
                reachabilityStatus = if (reachability != ReachabilityStatus.UNKNOWN) reachability else baseRecord.reachabilityStatus,
                isBootstrap = isBootstrap || baseRecord.isBootstrap,
                capabilities = capabilities ?: baseRecord.capabilities,
                signedAnnouncementJson = signedAnnouncementJson ?: baseRecord.signedAnnouncementJson
            )
        } else {
            if (recordMap.size >= maxRegistryCapacity) {
                evictLowestQualityPeer()
            }
            PeerRegistryRecord(
                peerId = peerId,
                publicKeyHex = publicKeyHex,
                endpoint = endpoint,
                protocolVersion = protocolVersion,
                discoverySource = source,
                firstDiscoveredTimestamp = now,
                lastSeenTimestamp = now,
                reachabilityStatus = reachability,
                authenticationStatus = PeerAuthStatus.UNAUTHENTICATED,
                reputationScore = if (isBootstrap) 80 else PeerRegistryRecord.DEFAULT_REPUTATION_SCORE,
                isBootstrap = isBootstrap,
                capabilities = capabilities ?: listOf(PeerCapability.P2P_TRANSPORT, PeerCapability.STAGE7_DISCOVERY),
                signedAnnouncementJson = signedAnnouncementJson
            )
        }

        recordMap[peerId] = updated
        publishPeers()
        savePersistedPeers()
        return updated
    }

    /**
     * Updates peer reachability status (e.g. CONNECTED, REACHABLE, UNREACHABLE, STALE).
     */
    fun updateReachability(peerId: String, status: ReachabilityStatus) {
        val existing = recordMap[peerId] ?: return
        recordMap[peerId] = existing.copy(
            reachabilityStatus = status,
            authenticationStatus = if (status == ReachabilityStatus.UNREACHABLE || status == ReachabilityStatus.STALE) {
                PeerAuthStatus.UNAUTHENTICATED
            } else {
                existing.authenticationStatus
            },
            lastSeenTimestamp = if (status == ReachabilityStatus.CONNECTED || status == ReachabilityStatus.REACHABLE) {
                System.currentTimeMillis()
            } else {
                existing.lastSeenTimestamp
            }
        )
        publishPeers()
    }

    /**
     * Marks peer as cryptographically authenticated following a successful handshake.
     */
    fun recordSuccessfulAuth(peerId: String, publicKeyHex: String?) {
        val existing = recordMap[peerId] ?: return
        val newScore = Math.min(PeerRegistryRecord.MAX_REPUTATION_SCORE, existing.reputationScore + 15)
        recordMap[peerId] = existing.copy(
            authenticationStatus = PeerAuthStatus.AUTHENTICATED,
            reachabilityStatus = ReachabilityStatus.CONNECTED,
            publicKeyHex = publicKeyHex ?: existing.publicKeyHex,
            reputationScore = newScore,
            consecutiveFailures = 0,
            lastSeenTimestamp = System.currentTimeMillis()
        )
        publishPeers()
        savePersistedPeers()
    }

    /**
     * Marks a currently connected peer as disconnected (no longer live-authenticated).
     */
    fun recordDisconnected(peerId: String) {
        val existing = recordMap[peerId] ?: return
        recordMap[peerId] = existing.copy(
            reachabilityStatus = ReachabilityStatus.REACHABLE,
            authenticationStatus = PeerAuthStatus.UNAUTHENTICATED,
            lastSeenTimestamp = System.currentTimeMillis()
        )
        publishPeers()
    }

    /**
     * Records a failed connection attempt to a peer.
     */
    fun recordConnectionFailed(peerId: String) {
        val existing = recordMap[peerId] ?: return
        val newScore = Math.max(PeerRegistryRecord.MIN_REPUTATION_SCORE, existing.reputationScore - 10)
        recordMap[peerId] = existing.copy(
            reachabilityStatus = ReachabilityStatus.UNREACHABLE,
            authenticationStatus = if (existing.authenticationStatus == PeerAuthStatus.AUTHENTICATED) PeerAuthStatus.UNAUTHENTICATED else existing.authenticationStatus,
            reputationScore = newScore,
            consecutiveFailures = existing.consecutiveFailures + 1
        )
        publishPeers()
    }

    /**
     * Records round-trip ping latency and boosts reputation for responsive peer.
     */
    fun recordSuccessfulPing(peerId: String, latencyMs: Long) {
        val existing = recordMap[peerId] ?: return
        val newScore = Math.min(PeerRegistryRecord.MAX_REPUTATION_SCORE, existing.reputationScore + 2)
        recordMap[peerId] = existing.copy(
            latencyMs = latencyMs,
            lastSeenTimestamp = System.currentTimeMillis(),
            reputationScore = newScore
        )
        publishPeers()
    }

    /**
     * Penalizes peer reputation for malicious, malformed, or invalid protocol behavior.
     */
    fun recordInvalidBehavior(peerId: String, penalty: Int = 30) {
        val existing = recordMap[peerId] ?: return
        val newScore = Math.max(PeerRegistryRecord.MIN_REPUTATION_SCORE, existing.reputationScore - penalty)
        recordMap[peerId] = existing.copy(
            reputationScore = newScore,
            authenticationStatus = PeerAuthStatus.AUTH_FAILED
        )
        publishPeers()
        savePersistedPeers()
    }

    /**
     * Marks a peer as REVOKED and disconnects/penalizes its reputation score.
     */
    fun recordPeerRevoked(peerId: String, reason: String = "Identity revoked") {
        val existing = recordMap[peerId] ?: return
        recordMap[peerId] = existing.copy(
            authenticationStatus = PeerAuthStatus.REVOKED,
            reachabilityStatus = ReachabilityStatus.UNREACHABLE,
            reputationScore = PeerRegistryRecord.MIN_REPUTATION_SCORE,
            notes = reason
        )
        publishPeers()
        savePersistedPeers()
    }

    /**
     * Scans for stale peers and marks them STALE.
     */
    fun pruneStalePeers(
        staleThresholdMs: Long = PeerRegistryRecord.STALE_THRESHOLD_MS,
        nowMs: Long = System.currentTimeMillis()
    ): Int {
        var count = 0
        recordMap.values.forEach { record ->
            if (record.reachabilityStatus != ReachabilityStatus.CONNECTED &&
                record.isStale(staleThresholdMs, nowMs) &&
                record.reachabilityStatus != ReachabilityStatus.STALE
            ) {
                recordMap[record.peerId] = record.copy(
                    reachabilityStatus = ReachabilityStatus.STALE,
                    authenticationStatus = PeerAuthStatus.UNAUTHENTICATED
                )
                count++
            }
        }
        if (count > 0) {
            publishPeers()
        }
        return count
    }

    /**
     * Removes expired peer records completely from the registry (excluding active connected or bootstrap nodes).
     */
    fun removeExpiredPeers(
        expiryThresholdMs: Long = PeerRegistryRecord.EXPIRATION_THRESHOLD_MS,
        nowMs: Long = System.currentTimeMillis()
    ): Int {
        var removedCount = 0
        val iterator = recordMap.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            val record = entry.value
            if (!record.isConnected && !record.isBootstrap && record.isExpired(expiryThresholdMs, nowMs)) {
                iterator.remove()
                removedCount++
            }
        }
        if (removedCount > 0) {
            publishPeers()
            savePersistedPeers()
        }
        return removedCount
    }

    /**
     * Adjusts lastSeenTimestamp in tests or sync paths.
     */
    internal fun updateLastSeenForTesting(peerId: String, timestampMs: Long) {
        val existing = recordMap[peerId] ?: return
        recordMap[peerId] = existing.copy(lastSeenTimestamp = timestampMs)
        publishPeers()
    }

    /**
     * Removes an individual peer by ID.
     */
    fun removePeer(peerId: String): Boolean {
        val removed = recordMap.remove(peerId) != null
        if (removed) {
            publishPeers()
            savePersistedPeers()
        }
        return removed
    }

    fun getPeer(peerId: String): PeerRegistryRecord? = recordMap[peerId]

    fun getPeerByEndpoint(host: String, port: Int): PeerRegistryRecord? {
        return recordMap.values.find { it.endpoint.host == host && it.endpoint.port == port }
    }

    fun getFilteredPeers(filter: PeerFilterOption): List<PeerRegistryRecord> {
        val all = _peers.value
        return when (filter) {
            PeerFilterOption.ALL -> all
            PeerFilterOption.CONNECTED -> all.filter { it.isConnected }
            PeerFilterOption.AUTHENTICATED -> all.filter { it.isAuthenticated }
            PeerFilterOption.DISCOVERED -> all.filter { !it.isConnected && it.reachabilityStatus != ReachabilityStatus.UNREACHABLE && it.reachabilityStatus != ReachabilityStatus.STALE }
            PeerFilterOption.UNREACHABLE -> all.filter { it.reachabilityStatus == ReachabilityStatus.UNREACHABLE || it.reachabilityStatus == ReachabilityStatus.STALE }
            PeerFilterOption.BOOTSTRAP -> all.filter { it.isBootstrap }
        }
    }

    /**
     * Returns a bounded list of high-quality peers to exchange in PEX messages.
     * Excludes unroutable, malformed, or untrusted peers.
     */
    fun getValidPeersForExchange(maxCount: Int = 16, excludePeerId: String? = null): List<PeerRegistryRecord> {
        return recordMap.values
            .filter { record ->
                record.peerId != excludePeerId &&
                        record.reputationScore >= 30 &&
                        record.reachabilityStatus != ReachabilityStatus.UNREACHABLE &&
                        record.reachabilityStatus != ReachabilityStatus.STALE &&
                        record.endpoint.port in 1..65535
            }
            .sortedByDescending { it.reputationScore }
            .take(maxCount)
    }

    private fun evictLowestQualityPeer() {
        val worst = recordMap.values
            .filter { !it.isConnected && !it.isBootstrap }
            .minByOrNull { it.reputationScore }
        if (worst != null) {
            recordMap.remove(worst.peerId)
            Log.i(TAG, "Evicted lowest reputation peer: ${worst.peerId} (score: ${worst.reputationScore})")
        }
    }

    private fun publishPeers() {
        _peers.value = recordMap.values.toList().sortedByDescending { it.lastSeenTimestamp }
    }

    private fun loadPersistedPeers() {
        val ctx = context ?: return
        scope.launch(ioDispatcher) {
            try {
                val prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val jsonStr = prefs.getString(KEY_PEERS_JSON, null) ?: return@launch
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val record = PeerRegistryRecord.fromJson(obj)
                    if (record != null) {
                        recordMap[record.peerId] = record
                    }
                }
                publishPeers()
                Log.d(TAG, "Loaded ${recordMap.size} peers from persistent storage")
            } catch (e: Exception) {
                Log.w(TAG, "Error loading persisted peers: ${e.message}")
            }
        }
    }

    private fun savePersistedPeers() {
        val ctx = context ?: return
        scope.launch(ioDispatcher) {
            mutex.withLock {
                try {
                    val prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    val arr = JSONArray()
                    val peersToPersist = recordMap.values
                        .filter { it.reputationScore >= 30 }
                        .sortedByDescending { it.reputationScore }
                        .take(100)
                    peersToPersist.forEach { arr.put(it.toJson()) }
                    prefs.edit().putString(KEY_PEERS_JSON, arr.toString()).apply()
                } catch (e: Exception) {
                    Log.w(TAG, "Error saving persisted peers: ${e.message}")
                }
            }
        }
    }

    fun clear() {
        recordMap.clear()
        _peers.value = emptyList()
        context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)?.edit()?.clear()?.apply()
    }

    override fun close() {
        savePersistedPeers()
    }
}
