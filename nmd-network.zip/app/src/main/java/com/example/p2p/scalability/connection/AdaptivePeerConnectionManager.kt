package com.example.p2p.scalability.connection

import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.topology.NetworkTopologyManager
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerInfo
import com.example.p2p.scalability.circuit.CircuitBreakerManager
import com.example.p2p.scalability.health.PeerHealthMonitor
import com.example.p2p.scalability.model.CircuitBreakerTargetType
import com.example.p2p.scalability.model.PeerHealthStatus
import com.example.p2p.scalability.resource.DeviceNetworkResourceMonitor
import java.util.concurrent.ConcurrentHashMap

data class ConnectionMaintenanceReport(
    val replacedPeerIds: List<String> = emptyList(),
    val attemptedPeerIds: List<String> = emptyList(),
    val establishedPeerIds: List<String> = emptyList(),
    val skippedCircuitOpenCount: Int = 0,
    val duplicateRejectedCount: Int = 0,
    val prunedDownForCapCount: Int = 0
)

/**
 * Coordinates adaptive peer connection maintenance on top of [PeerConnectionManager],
 * enforcing resource-mode connection caps, duplicate peer suppression, circuit breaker isolation,
 * unhealthy peer replacement, and mandatory Stage 13 authenticated encryption.
 */
class AdaptivePeerConnectionManager(
    private val connectionManager: PeerConnectionManager,
    private val peerRegistry: DistributedPeerRegistry,
    private val healthMonitor: PeerHealthMonitor,
    private val circuitBreakers: CircuitBreakerManager,
    private val resourceMonitor: DeviceNetworkResourceMonitor,
    private val topologyManager: NetworkTopologyManager = connectionManager.topologyManager,
    private val dialAction: suspend (PeerEndpoint) -> Result<RealPeerInfo> = { ep -> connectionManager.connectToPeer(ep) },
    private val disconnectAction: suspend (String) -> Unit = { connId -> connectionManager.disconnectPeer(connId) },
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private val recentDialFailures = ConcurrentHashMap<String, Long>()

    fun canAcceptInboundForResourceMode(
        remoteNodeId: String?,
        currentPeers: List<RealPeerInfo> = connectionManager.authenticatedPeers.value
    ): Boolean {
        if (remoteNodeId != null && currentPeers.any { it.authenticatedNodeId == remoteNodeId }) {
            return false // Duplicate node ID protection
        }
        val policy = resourceMonitor.snapshot.value.policy
        val inboundCount = currentPeers.count { !it.isOutbound }
        return currentPeers.size < policy.maxConnectedPeers && inboundCount < policy.maxInboundConnections
    }

    fun selectCandidatesToDial(
        localNodeId: String?,
        connectedPeers: List<RealPeerInfo> = connectionManager.authenticatedPeers.value,
        maxSlotsOverride: Int? = null
    ): List<PeerRegistryRecord> {
        val now = clockMs()
        val policy = resourceMonitor.snapshot.value.policy
        val outboundCount = connectedPeers.count { it.isOutbound }
        val remainingTotal = (policy.maxConnectedPeers - connectedPeers.size).coerceAtLeast(0)
        val remainingOutbound = (policy.maxOutboundConnections - outboundCount).coerceAtLeast(0)
        val slots = minOf(remainingTotal, remainingOutbound, maxSlotsOverride ?: Int.MAX_VALUE)
        if (slots <= 0) return emptyList()

        val activeNodeIds = connectedPeers.mapNotNull { it.authenticatedNodeId }.toSet()
        val activeEndpoints = connectedPeers.map { it.endpoint.addressFormatted }.toSet()

        return peerRegistry.peers.value
            .asSequence()
            .filter { rec ->
                rec.peerId != localNodeId &&
                    !activeNodeIds.contains(rec.peerId) &&
                    !activeEndpoints.contains(rec.endpoint.addressFormatted) &&
                    healthMonitor.canConnectCandidate(rec.peerId, now) &&
                    circuitBreakers.allowRequest(CircuitBreakerTargetType.PEER, rec.peerId)
            }
            .sortedByDescending { healthMonitor.scoreCandidate(it, now) }
            .take(slots)
            .toList()
    }

    suspend fun runAdaptiveMaintenanceSweep(localNodeId: String?): ConnectionMaintenanceReport {
        val replaced = mutableListOf<String>()
        val attempted = mutableListOf<String>()
        val established = mutableListOf<String>()
        var skippedBreaker = 0
        var dupes = 0
        var prunedForCap = 0

        healthMonitor.syncFromRegistryAndTrust()
        healthMonitor.evaluateQuarantineCooldowns()

        val policy = resourceMonitor.snapshot.value.policy
        val currentConnected = connectionManager.authenticatedPeers.value

        // 1. Prune excess outbound connections if device dropped to LOW_RESOURCE mode
        if (currentConnected.size > policy.maxConnectedPeers) {
            val excessCount = currentConnected.size - policy.maxConnectedPeers
            val victims = currentConnected
                .sortedBy { peer ->
                    val id = peer.authenticatedNodeId
                    val h = id?.let { healthMonitor.getHealth(it) }
                    (h?.stabilityScore ?: 50) + if (peer.isOutbound) 0 else 10
                }
                .take(excessCount)
            victims.forEach { victim ->
                disconnectAction(victim.connectionId)
                prunedForCap++
            }
        }

        // 2. Replace persistently unhealthy/quarantined peers if healthy replacements exist
        val refreshedConnected = connectionManager.authenticatedPeers.value
        val connectedNodeIds = refreshedConnected.mapNotNull { it.authenticatedNodeId }
        val worstPeerId = healthMonitor.selectWorstConnectedPeerForReplacement(connectedNodeIds)
        val hasHealthyAlternate = peerRegistry.peers.value.any { rec ->
            rec.peerId != localNodeId &&
                !connectedNodeIds.contains(rec.peerId) &&
                healthMonitor.canConnectCandidate(rec.peerId) &&
                (healthMonitor.getHealth(rec.peerId)?.status ?: PeerHealthStatus.HEALTHY) == PeerHealthStatus.HEALTHY
        }

        if (worstPeerId != null && hasHealthyAlternate) {
            refreshedConnected.find { it.authenticatedNodeId == worstPeerId }?.let { badPeer ->
                disconnectAction(badPeer.connectionId)
                replaced.add(worstPeerId)
            }
        }

        // 3. Fill open outbound slots cleanly using circuit-breaker + health ranking
        val latestConnected = connectionManager.authenticatedPeers.value
        val activeIds = latestConnected.mapNotNull { it.authenticatedNodeId }.toMutableSet()
        val activeEndpoints = latestConnected.map { it.endpoint.addressFormatted }.toMutableSet()

        val outboundCount = latestConnected.count { it.isOutbound }
        val openSlots = minOf(
            (policy.maxConnectedPeers - latestConnected.size).coerceAtLeast(0),
            (policy.maxOutboundConnections - outboundCount).coerceAtLeast(0)
        )

        if (openSlots > 0) {
            val rankedPool = peerRegistry.peers.value
                .filter { it.peerId != localNodeId }
                .sortedByDescending { healthMonitor.scoreCandidate(it) }

            for (candidate in rankedPool) {
                if (established.size >= openSlots) break

                if (activeIds.contains(candidate.peerId) || activeEndpoints.contains(candidate.endpoint.addressFormatted)) {
                    dupes++
                    continue
                }
                if (!healthMonitor.canConnectCandidate(candidate.peerId)) {
                    continue
                }
                if (!circuitBreakers.allowRequest(CircuitBreakerTargetType.PEER, candidate.peerId)) {
                    skippedBreaker++
                    continue
                }

                attempted.add(candidate.peerId)
                val endpoint = candidate.endpoint.copy(claimedNodeId = candidate.peerId)
                val res = dialAction(endpoint)
                if (res.isSuccess) {
                    val info = res.getOrThrow()
                    circuitBreakers.recordSuccess(CircuitBreakerTargetType.PEER, candidate.peerId)
                    healthMonitor.recordAuthenticatedSession(
                        peerId = candidate.peerId,
                        protocolVersion = candidate.protocolVersion,
                        latencyMs = info.lastPingLatencyMs
                    )
                    recentDialFailures.remove(candidate.peerId)
                    activeIds.add(candidate.peerId)
                    activeEndpoints.add(endpoint.addressFormatted)
                    established.add(candidate.peerId)
                } else {
                    val reason = res.exceptionOrNull()?.message ?: "Connection failed"
                    circuitBreakers.recordFailure(CircuitBreakerTargetType.PEER, candidate.peerId, reason)
                    healthMonitor.recordMessageFailure(candidate.peerId, isTimeout = true)
                    recentDialFailures[candidate.peerId] = clockMs()
                }
            }
        }

        return ConnectionMaintenanceReport(
            replacedPeerIds = replaced,
            attemptedPeerIds = attempted,
            establishedPeerIds = established,
            skippedCircuitOpenCount = skippedBreaker,
            duplicateRejectedCount = dupes,
            prunedDownForCapCount = prunedForCap
        )
    }
}
