package com.example.p2p.scalability.congestion

import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.scalability.model.CongestionMetricsSnapshot
import com.example.p2p.scalability.model.CongestionState
import com.example.p2p.scalability.model.MessagePriorityClass
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min
import kotlin.random.Random

data class CongestionControlConfig(
    val maxOutgoingQueueSize: Int = 256,
    val maxIncomingQueueSize: Int = 256,
    val maxPerPeerQueueSize: Int = 48,
    val maxConsensusQueueCap: Int = 96, // High-priority BFT memory still strictly bounded!
    val defaultMessageTtlMs: Long = 30_000L,
    val syncMessageTtlMs: Long = 20_000L,
    val discoveryMessageTtlMs: Long = 10_000L,
    val perPeerRateWindowMs: Long = 2_000L,
    val maxNonConsensusMessagesPerWindowPerPeer: Int = 24,
    val dedupeWindowCapacity: Int = 4_096,
    val baseRetryDelayMs: Long = 400L,
    val maxRetryDelayMs: Long = 12_000L
) {
    init {
        require(maxOutgoingQueueSize >= 16)
        require(maxIncomingQueueSize >= 16)
        require(maxPerPeerQueueSize >= 4)
        require(maxConsensusQueueCap in 8..maxOutgoingQueueSize)
    }
}

data class QueuedNetworkEnvelope(
    val queueId: String,
    val targetPeerId: String,
    val sessionId: String,
    val message: P2pMessage,
    val priority: MessagePriorityClass = MessagePriorityClass.fromMessageType(message.messageType),
    val enqueuedAtMs: Long = System.currentTimeMillis(),
    val expiresAtMs: Long = enqueuedAtMs + 30_000L
)

sealed class EnqueueOutcome {
    data class Enqueued(val priority: MessagePriorityClass, val queueDepth: Int) : EnqueueOutcome()
    data class RejectedDuplicate(val messageId: String) : EnqueueOutcome()
    data class RejectedRateLimited(val peerId: String, val retryAfterMs: Long) : EnqueueOutcome()
    data class RejectedBackpressure(val reason: String, val retryAfterMs: Long) : EnqueueOutcome()
}

/**
 * Bounded priority congestion controller protecting consensus & block proposals against starvation
 * while guaranteeing strict memory caps, duplicate suppression, queue expiration, rate limits,
 * and adaptive exponential backoff with jitter.
 *
 * Security & Correctness Guarantees:
 * - Never silently drops valid BFT consensus messages: evicts lower-priority discovery/sync items first
 *   and returns explicit [EnqueueOutcome.RejectedBackpressure] only if high-priority memory ceiling itself is full.
 * - Preserves per-peer FIFO sequence ordering within the same priority class.
 * - High-priority traffic is also bounded ([CongestionControlConfig.maxConsensusQueueCap]) to prevent OOM.
 */
class NetworkCongestionController(
    val config: CongestionControlConfig = CongestionControlConfig(),
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private val lock = Any()

    // Separate priority buckets preserve FIFO order per priority class
    private val outgoingBuckets = LinkedHashMap<MessagePriorityClass, ArrayDeque<QueuedNetworkEnvelope>>().apply {
        MessagePriorityClass.entries.sortedBy { it.level }.forEach { put(it, ArrayDeque()) }
    }
    private val incomingBuckets = LinkedHashMap<MessagePriorityClass, ArrayDeque<QueuedNetworkEnvelope>>().apply {
        MessagePriorityClass.entries.sortedBy { it.level }.forEach { put(it, ArrayDeque()) }
    }
    private val perPeerOutgoingCounts = ConcurrentHashMap<String, Int>()

    private val seenMessageIds = LinkedHashMap<String, Long>(256, 0.75f, false)
    private val rateWindows = ConcurrentHashMap<String, ArrayDeque<Long>>()
    private val retryCountsByTarget = ConcurrentHashMap<String, Int>()

    private val acceptedCount = AtomicLong(0L)
    private val droppedLowPriorityCount = AtomicLong(0L)
    private val expiredQueueItemsCount = AtomicLong(0L)
    private val duplicateSuppressedCount = AtomicLong(0L)
    private val rateLimitedCount = AtomicLong(0L)

    private val _metrics = MutableStateFlow(CongestionMetricsSnapshot(
        maxOutgoingQueueDepth = config.maxOutgoingQueueSize,
        maxIncomingQueueDepth = config.maxIncomingQueueSize
    ))
    val metrics: StateFlow<CongestionMetricsSnapshot> = _metrics.asStateFlow()

    fun enqueueOutgoing(
        targetPeerId: String,
        sessionId: String,
        message: P2pMessage
    ): EnqueueOutcome {
        val now = clockMs()
        val priority = MessagePriorityClass.fromMessageType(message.messageType)

        synchronized(lock) {
            pruneExpiredLocked(now)

            // 1. Duplicate suppression (using messageId)
            val dedupeKey = "out:${targetPeerId}:${message.messageId}"
            if (isDuplicateLocked(dedupeKey, now)) {
                duplicateSuppressedCount.incrementAndGet()
                publishMetricsLocked()
                return EnqueueOutcome.RejectedDuplicate(message.messageId)
            }

            // 2. Rate limiting (applies to non-critical TX/SYNC/DISCOVERY traffic; never blocks BFT quorum votes)
            if (priority.level >= MessagePriorityClass.TX_PROPAGATION.level) {
                if (!consumeRateTokenLocked(targetPeerId, now)) {
                    rateLimitedCount.incrementAndGet()
                    val backoff = computeAdaptiveRetryDelayMs(targetPeerId)
                    publishMetricsLocked()
                    return EnqueueOutcome.RejectedRateLimited(targetPeerId, backoff)
                }
            }

            val totalDepth = outgoingTotalDepthLocked()
            val peerDepth = perPeerOutgoingCounts[targetPeerId] ?: 0
            val consensusDepth = (outgoingBuckets[MessagePriorityClass.CONSENSUS_BFT]?.size ?: 0) +
                (outgoingBuckets[MessagePriorityClass.BLOCK_PROPOSAL_COMMIT]?.size ?: 0)

            // 3. Enforce high-priority cap so even BFT traffic cannot exhaust device RAM
            if (priority.level <= MessagePriorityClass.BLOCK_PROPOSAL_COMMIT.level &&
                consensusDepth >= config.maxConsensusQueueCap
            ) {
                val backoff = computeAdaptiveRetryDelayMs(targetPeerId)
                publishMetricsLocked()
                return EnqueueOutcome.RejectedBackpressure(
                    reason = "Consensus priority queue memory ceiling (${config.maxConsensusQueueCap}) reached",
                    retryAfterMs = backoff
                )
            }

            // 4. Enforce global/per-peer queue bounds with explicit priority shedding
            if (totalDepth >= config.maxOutgoingQueueSize || peerDepth >= config.maxPerPeerQueueSize) {
                if (priority.level <= MessagePriorityClass.BLOCK_PROPOSAL_COMMIT.level) {
                    // Evict lowest priority item first so consensus/block commits are NEVER silently starved/dropped
                    val evicted = if (peerDepth >= config.maxPerPeerQueueSize) {
                        evictLowestPriorityForPeerLocked(outgoingBuckets, targetPeerId, priority)
                            ?: evictLowestPriorityGlobalLocked(outgoingBuckets, priority)
                    } else {
                        evictLowestPriorityGlobalLocked(outgoingBuckets, priority)
                    }
                    if (!evicted) {
                        val backoff = computeAdaptiveRetryDelayMs(targetPeerId)
                        publishMetricsLocked()
                        return EnqueueOutcome.RejectedBackpressure("Global queue saturated with high-priority messages", backoff)
                    }
                } else {
                    // Low-priority traffic triggers immediate explicit backpressure or drops lower-than-self items
                    val evicted = if (priority == MessagePriorityClass.TX_PROPAGATION && peerDepth < config.maxPerPeerQueueSize) {
                        evictLowestPriorityGlobalLocked(outgoingBuckets, priority)
                    } else {
                        false
                    }
                    if (!evicted) {
                        droppedLowPriorityCount.incrementAndGet()
                        val backoff = computeAdaptiveRetryDelayMs(targetPeerId)
                        publishMetricsLocked()
                        return EnqueueOutcome.RejectedBackpressure(
                            reason = "Queue backpressure active (depth=$totalDepth/${config.maxOutgoingQueueSize}, peer=$peerDepth/${config.maxPerPeerQueueSize})",
                            retryAfterMs = backoff
                        )
                    }
                }
            }

            val ttlMs = when (priority) {
                MessagePriorityClass.DISCOVERY_DIAGNOSTICS -> config.discoveryMessageTtlMs
                MessagePriorityClass.BLOCKCHAIN_SYNC -> config.syncMessageTtlMs
                else -> config.defaultMessageTtlMs
            }

            val env = QueuedNetworkEnvelope(
                queueId = message.messageId,
                targetPeerId = targetPeerId,
                sessionId = sessionId,
                message = message,
                priority = priority,
                enqueuedAtMs = now,
                expiresAtMs = now + ttlMs
            )
            outgoingBuckets[priority]!!.addLast(env)
            perPeerOutgoingCounts[targetPeerId] = (perPeerOutgoingCounts[targetPeerId] ?: 0) + 1
            recordSeenLocked(dedupeKey, now)
            acceptedCount.incrementAndGet()
            publishMetricsLocked()
            return EnqueueOutcome.Enqueued(priority, outgoingTotalDepthLocked())
        }
    }

    /**
     * Dequeues the next highest-priority unexpired outgoing message.
     * BFT consensus & block proposals always preempt sync & discovery while preserving FIFO within each class.
     */
    fun dequeueNextOutgoing(): QueuedNetworkEnvelope? {
        val now = clockMs()
        synchronized(lock) {
            pruneExpiredLocked(now)
            for (priority in MessagePriorityClass.entries.sortedBy { it.level }) {
                val deque = outgoingBuckets[priority] ?: continue
                if (deque.isNotEmpty()) {
                    val item = deque.removeFirst()
                    val count = (perPeerOutgoingCounts[item.targetPeerId] ?: 1) - 1
                    if (count <= 0) perPeerOutgoingCounts.remove(item.targetPeerId)
                    else perPeerOutgoingCounts[item.targetPeerId] = count
                    publishMetricsLocked()
                    return item
                }
            }
            publishMetricsLocked()
            return null
        }
    }

    fun enqueueIncoming(sourcePeerId: String, sessionId: String, message: P2pMessage): EnqueueOutcome {
        val now = clockMs()
        val priority = MessagePriorityClass.fromMessageType(message.messageType)

        synchronized(lock) {
            pruneExpiredLocked(now)
            val dedupeKey = "in:$sourcePeerId:${message.messageId}"
            if (isDuplicateLocked(dedupeKey, now)) {
                duplicateSuppressedCount.incrementAndGet()
                publishMetricsLocked()
                return EnqueueOutcome.RejectedDuplicate(message.messageId)
            }

            val depth = incomingTotalDepthLocked()
            if (depth >= config.maxIncomingQueueSize) {
                val evicted = if (priority.level <= MessagePriorityClass.BLOCK_PROPOSAL_COMMIT.level) {
                    evictLowestPriorityGlobalLocked(incomingBuckets, priority)
                } else {
                    false
                }
                if (!evicted) {
                    droppedLowPriorityCount.incrementAndGet()
                    publishMetricsLocked()
                    return EnqueueOutcome.RejectedBackpressure("Incoming buffer full ($depth/${config.maxIncomingQueueSize})", 500L)
                }
            }

            incomingBuckets[priority]!!.addLast(
                QueuedNetworkEnvelope(
                    queueId = message.messageId,
                    targetPeerId = sourcePeerId,
                    sessionId = sessionId,
                    message = message,
                    priority = priority,
                    enqueuedAtMs = now,
                    expiresAtMs = now + config.defaultMessageTtlMs
                )
            )
            recordSeenLocked(dedupeKey, now)
            acceptedCount.incrementAndGet()
            publishMetricsLocked()
            return EnqueueOutcome.Enqueued(priority, incomingTotalDepthLocked())
        }
    }

    fun dequeueNextIncoming(): QueuedNetworkEnvelope? {
        val now = clockMs()
        synchronized(lock) {
            pruneExpiredLocked(now)
            for (priority in MessagePriorityClass.entries.sortedBy { it.level }) {
                val deque = incomingBuckets[priority] ?: continue
                if (deque.isNotEmpty()) {
                    val item = deque.removeFirst()
                    publishMetricsLocked()
                    return item
                }
            }
            publishMetricsLocked()
            return null
        }
    }

    fun pruneExpired(): Int {
        val now = clockMs()
        synchronized(lock) {
            val removed = pruneExpiredLocked(now)
            publishMetricsLocked()
            return removed
        }
    }

    fun computeAdaptiveRetryDelayMs(targetKey: String, jitterFactor: Double = 0.2): Long {
        val failures = retryCountsByTarget.compute(targetKey) { _, prev -> ((prev ?: 0) + 1).coerceAtMost(8) } ?: 1
        val exponential = config.baseRetryDelayMs * (1L shl (failures - 1))
        val clamped = min(exponential, config.maxRetryDelayMs)
        val jitterRange = (clamped * jitterFactor).toLong().coerceAtLeast(1L)
        return (clamped + Random.nextLong(0L, jitterRange + 1L)).coerceAtLeast(50L)
    }

    fun recordDeliverySuccess(targetKey: String) {
        retryCountsByTarget.remove(targetKey)
        synchronized(lock) { publishMetricsLocked() }
    }

    fun clearPeerQueues(peerId: String) {
        synchronized(lock) {
            outgoingBuckets.values.forEach { q ->
                q.removeAll { it.targetPeerId == peerId }
            }
            perPeerOutgoingCounts.remove(peerId)
            publishMetricsLocked()
        }
    }

    private fun pruneExpiredLocked(now: Long): Int {
        var expired = 0
        outgoingBuckets.entries.forEach { (prio, q) ->
            // Do NOT expire critical consensus votes while waiting for dispatch; only non-consensus expires on stale TTL
            if (prio.level >= MessagePriorityClass.TX_PROPAGATION.level) {
                val iter = q.iterator()
                while (iter.hasNext()) {
                    val item = iter.next()
                    if (now >= item.expiresAtMs) {
                        iter.remove()
                        val c = (perPeerOutgoingCounts[item.targetPeerId] ?: 1) - 1
                        if (c <= 0) perPeerOutgoingCounts.remove(item.targetPeerId)
                        else perPeerOutgoingCounts[item.targetPeerId] = c
                        expired++
                    }
                }
            }
        }
        incomingBuckets.entries.forEach { (prio, q) ->
            if (prio.level >= MessagePriorityClass.TX_PROPAGATION.level) {
                val iter = q.iterator()
                while (iter.hasNext()) {
                    if (now >= iter.next().expiresAtMs) {
                        iter.remove()
                        expired++
                    }
                }
            }
        }
        if (expired > 0) {
            expiredQueueItemsCount.addAndGet(expired.toLong())
        }
        return expired
    }

    private fun evictLowestPriorityGlobalLocked(
        buckets: Map<MessagePriorityClass, ArrayDeque<QueuedNetworkEnvelope>>,
        incomingPriority: MessagePriorityClass
    ): Boolean {
        for (prio in MessagePriorityClass.entries.sortedByDescending { it.level }) {
            if (prio.level <= incomingPriority.level) break
            val q = buckets[prio] ?: continue
            if (q.isNotEmpty()) {
                val dropped = q.removeFirst()
                val c = (perPeerOutgoingCounts[dropped.targetPeerId] ?: 1) - 1
                if (c <= 0) perPeerOutgoingCounts.remove(dropped.targetPeerId)
                else perPeerOutgoingCounts[dropped.targetPeerId] = c
                droppedLowPriorityCount.incrementAndGet()
                return true
            }
        }
        return false
    }

    private fun evictLowestPriorityForPeerLocked(
        buckets: Map<MessagePriorityClass, ArrayDeque<QueuedNetworkEnvelope>>,
        peerId: String,
        incomingPriority: MessagePriorityClass
    ): Boolean {
        for (prio in MessagePriorityClass.entries.sortedByDescending { it.level }) {
            if (prio.level <= incomingPriority.level) break
            val q = buckets[prio] ?: continue
            val idx = q.indexOfFirst { it.targetPeerId == peerId }
            if (idx >= 0) {
                val dropped = q.removeAt(idx)
                val c = (perPeerOutgoingCounts[dropped.targetPeerId] ?: 1) - 1
                if (c <= 0) perPeerOutgoingCounts.remove(dropped.targetPeerId)
                else perPeerOutgoingCounts[dropped.targetPeerId] = c
                droppedLowPriorityCount.incrementAndGet()
                return true
            }
        }
        return false
    }

    private fun consumeRateTokenLocked(peerId: String, now: Long): Boolean {
        val q = rateWindows.computeIfAbsent(peerId) { ArrayDeque() }
        synchronized(q) {
            while (q.isNotEmpty() && now - q.first() > config.perPeerRateWindowMs) {
                q.removeFirst()
            }
            if (q.size >= config.maxNonConsensusMessagesPerWindowPerPeer) {
                return false
            }
            q.addLast(now)
            return true
        }
    }

    private fun isDuplicateLocked(key: String, now: Long): Boolean {
        val ts = seenMessageIds[key] ?: return false
        return (now - ts) <= 120_000L
    }

    private fun recordSeenLocked(key: String, now: Long) {
        if (seenMessageIds.size >= config.dedupeWindowCapacity) {
            val firstKey = seenMessageIds.keys.firstOrNull()
            if (firstKey != null) seenMessageIds.remove(firstKey)
        }
        seenMessageIds[key] = now
    }

    private fun outgoingTotalDepthLocked(): Int = outgoingBuckets.values.sumOf { it.size }
    private fun incomingTotalDepthLocked(): Int = incomingBuckets.values.sumOf { it.size }

    private fun publishMetricsLocked() {
        val outDepth = outgoingTotalDepthLocked()
        val inDepth = incomingTotalDepthLocked()
        val ratio = outDepth.toDouble() / config.maxOutgoingQueueSize.toDouble()
        val prevState = _metrics.value.congestionState
        val state = when {
            ratio >= 0.85 -> CongestionState.CONGESTED
            ratio >= 0.50 -> CongestionState.ELEVATED
            prevState == CongestionState.CONGESTED || prevState == CongestionState.RECOVERING ->
                if (ratio > 0.15) CongestionState.RECOVERING else CongestionState.NORMAL
            else -> CongestionState.NORMAL
        }
        val consensusDepth = (outgoingBuckets[MessagePriorityClass.CONSENSUS_BFT]?.size ?: 0) +
            (outgoingBuckets[MessagePriorityClass.BLOCK_PROPOSAL_COMMIT]?.size ?: 0)
        _metrics.value = CongestionMetricsSnapshot(
            congestionState = state,
            outgoingQueueDepth = outDepth,
            maxOutgoingQueueDepth = config.maxOutgoingQueueSize,
            incomingQueueDepth = inDepth,
            maxIncomingQueueDepth = config.maxIncomingQueueSize,
            consensusQueueDepth = consensusDepth,
            syncQueueDepth = outgoingBuckets[MessagePriorityClass.BLOCKCHAIN_SYNC]?.size ?: 0,
            discoveryQueueDepth = outgoingBuckets[MessagePriorityClass.DISCOVERY_DIAGNOSTICS]?.size ?: 0,
            acceptedCount = acceptedCount.get(),
            droppedLowPriorityCount = droppedLowPriorityCount.get(),
            expiredQueueItemsCount = expiredQueueItemsCount.get(),
            duplicateSuppressedCount = duplicateSuppressedCount.get(),
            rateLimitedCount = rateLimitedCount.get(),
            retryBackoffActiveCount = retryCountsByTarget.size
        )
    }
}
