package com.example.p2p.model

import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.TransportPathType

enum class RealPeerConnectionState {
    DISCONNECTED,
    CONNECTING,
    HANDSHAKING,
    AUTHENTICATED,
    FAILED
}

data class PeerEndpoint(
    val host: String,
    val port: Int,
    val claimedNodeId: String? = null
) {
    val addressFormatted: String
        get() = "$host:$port"

    override fun toString(): String = addressFormatted
}

data class RealPeerInfo(
    val connectionId: String,
    val endpoint: PeerEndpoint,
    val authenticatedNodeId: String? = null,
    val authenticatedPublicKeyHex: String? = null,
    val state: RealPeerConnectionState,
    val connectedAt: Long = 0L,
    val lastPingLatencyMs: Long = 0L,
    val messagesSent: Long = 0L,
    val messagesReceived: Long = 0L,
    val isOutbound: Boolean,
    val lastError: String? = null,
    val transportPathType: TransportPathType = TransportPathType.LOCAL_DIRECT_TCP,
    val selectedCandidateType: IceCandidateType? = null
) {
    val id: String
        get() = connectionId

    val connectionState: RealPeerConnectionState
        get() = state

    val connectedAtEpochMs: Long
        get() = connectedAt

    val messagesSentCount: Long
        get() = messagesSent

    val messagesReceivedCount: Long
        get() = messagesReceived

    val connectionDurationSeconds: Long
        get() = if (connectedAt > 0 && state == RealPeerConnectionState.AUTHENTICATED) {
            (System.currentTimeMillis() - connectedAt) / 1000L
        } else {
            0L
        }

    val displayNodeId: String
        get() = authenticatedNodeId?.let {
            if (it.length > 20) "${it.take(12)}...${it.takeLast(6)}" else it
        } ?: "Handshaking..."
}

data class DiscoveredPeer(
    val serviceName: String,
    val host: String,
    val port: Int,
    val advertisedNodeId: String?,
    val discoveredAt: Long = System.currentTimeMillis()
) {
    val discoveredAtEpochMs: Long
        get() = discoveredAt

    val endpointFormatted: String
        get() = "$host:$port"

    val displayNodeId: String
        get() = advertisedNodeId?.let {
            if (it.length > 20) "${it.take(12)}...${it.takeLast(6)}" else it
        } ?: serviceName
}
