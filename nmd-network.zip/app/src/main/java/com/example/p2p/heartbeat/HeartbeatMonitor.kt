package com.example.p2p.heartbeat

import android.util.Log
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.session.ConnectionHealth
import com.example.p2p.session.P2pSessionState
import com.example.p2p.session.PeerSession
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * HeartbeatMonitor periodically sends PINGs to active peer sessions,
 * calculates latency from PONG replies, monitors last-seen timestamps,
 * and detects unresponsive peers.
 */
class HeartbeatMonitor(
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val heartbeatIntervalMs: Long = 15_000L,
    private val unresponsiveThresholdMs: Long = 45_000L,
    private val disconnectThresholdMs: Long = 60_000L,
    private val onSendPing: suspend (PeerSession) -> Unit,
    private val onPeerUnresponsive: suspend (PeerSession) -> Unit,
    private val onHealthUpdated: (PeerSession, ConnectionHealth, Long) -> Unit
) {
    companion object {
        private const val TAG = "HeartbeatMonitor"
    }

    private var heartbeatJob: Job? = null

    fun start() {
        if (heartbeatJob != null && heartbeatJob?.isActive == true) {
            return
        }
        heartbeatJob = scope.launch(ioDispatcher) {
            while (isActive) {
                delay(heartbeatIntervalMs)
                // Heartbeat tick handled via runTick or callbacks
            }
        }
    }

    fun stop() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    /**
     * Inspects active sessions, sends PINGs, and updates health states.
     */
    suspend fun checkSessions(sessions: List<PeerSession>, now: Long = System.currentTimeMillis()) {
        for (session in sessions) {
            if (session.state != P2pSessionState.AUTHENTICATED && session.state != P2pSessionState.ACTIVE) {
                continue
            }

            val elapsedSinceLastSeen = now - session.lastSeenTimestamp

            if (elapsedSinceLastSeen >= disconnectThresholdMs) {
                Log.w(TAG, "Peer ${session.peerId} exceeded disconnect threshold ($elapsedSinceLastSeen ms). Triggering teardown.")
                onPeerUnresponsive(session)
                continue
            }

            val newHealth = ConnectionHealth.computeHealth(
                state = session.state,
                lastSeenTimestamp = session.lastSeenTimestamp,
                lastLatencyMs = session.lastRoundTripLatencyMs,
                now = now
            )

            if (newHealth != session.connectionHealth) {
                onHealthUpdated(session, newHealth, session.lastRoundTripLatencyMs)
            }

            // Send periodic PING to keep connection alive and measure latency
            try {
                onSendPing(session)
            } catch (e: Exception) {
                Log.w(TAG, "Failed sending heartbeat PING to ${session.peerId}: ${e.message}")
            }
        }
    }

    /**
     * Creates a PONG response message in reply to an incoming PING.
     */
    fun createPongResponse(
        pingMessage: P2pMessage,
        localPeerId: String
    ): P2pMessage {
        return P2pMessage(
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = localPeerId,
            recipientPeerId = pingMessage.senderPeerId,
            messageType = P2pMessageType.PONG,
            timestamp = System.currentTimeMillis(),
            sequenceNumber = pingMessage.sequenceNumber,
            payload = "{\"pong_to_ping_id\":\"${pingMessage.messageId}\"}",
            ackForMessageId = pingMessage.messageId
        )
    }
}
