package com.example.p2p.transport

import android.util.Log
import com.example.p2p.model.PeerEndpoint
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections

/**
 * TcpPeerTransport manages local TCP server socket lifecycle and outbound client socket connections.
 * Runs on Dispatchers.IO to guarantee zero UI thread blocking.
 */
class TcpPeerTransport(
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : P2PTransport {

    companion object {
        private const val TAG = "TcpPeerTransport"
        const val DEFAULT_NMD_PORT = 9876
    }

    private var serverSocket: ServerSocket? = null
    private var acceptJob: Job? = null

    private val _isListening = MutableStateFlow(false)
    override val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _boundPort = MutableStateFlow<Int?>(null)
    override val boundPort: StateFlow<Int?> = _boundPort.asStateFlow()

    private val _incomingSockets = MutableSharedFlow<Socket>(extraBufferCapacity = 16)
    override val incomingSockets: SharedFlow<Socket> = _incomingSockets.asSharedFlow()

    override suspend fun startListening(preferredPort: Int): Int = withContext(ioDispatcher) {
        if (_isListening.value && serverSocket != null && !serverSocket!!.isClosed) {
            return@withContext serverSocket!!.localPort
        }

        stopListening()

        var portToTry = preferredPort
        var boundSocket: ServerSocket? = null

        try {
            // First attempt preferred port
            boundSocket = ServerSocket(portToTry)
        } catch (e: IOException) {
            Log.w(TAG, "Preferred port $portToTry occupied or unavailable, falling back to OS allocated port (0)")
            boundSocket = ServerSocket(0)
        }

        serverSocket = boundSocket
        val actualPort = boundSocket.localPort
        _boundPort.value = actualPort
        _isListening.value = true
        Log.i(TAG, "NMD TCP Server listening on port $actualPort")

        acceptJob = scope.launch(ioDispatcher) {
            while (isActive && !boundSocket.isClosed) {
                try {
                    val clientSocket = boundSocket.accept()
                    // Set keepalive & TCP_NODELAY for responsive protocol messaging
                    clientSocket.tcpNoDelay = true
                    clientSocket.keepAlive = true
                    clientSocket.soTimeout = 30_000 // 30 second read timeout for active sockets
                    _incomingSockets.emit(clientSocket)
                } catch (e: IOException) {
                    if (!boundSocket.isClosed) {
                        Log.e(TAG, "Exception in TCP accept loop: ${e.message}")
                    }
                    break
                }
            }
            _isListening.value = false
            _boundPort.value = null
        }

        actualPort
    }

    override suspend fun stopListening(): Unit = withContext(ioDispatcher) {
        try {
            acceptJob?.cancel()
            acceptJob = null
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            Log.w(TAG, "Error closing server socket: ${e.message}")
        } finally {
            _isListening.value = false
            _boundPort.value = null
            Log.i(TAG, "NMD TCP Server listener stopped")
        }
    }

    override suspend fun connectTo(endpoint: PeerEndpoint, timeoutMs: Int): Socket = withContext(ioDispatcher) {
        val socket = Socket()
        socket.tcpNoDelay = true
        socket.keepAlive = true
        socket.soTimeout = 30_000
        val socketAddress = InetSocketAddress(endpoint.host, endpoint.port)
        Log.d(TAG, "Initiating TCP connection to $socketAddress with ${timeoutMs}ms timeout")
        socket.connect(socketAddress, timeoutMs)
        socket
    }

    override fun getLocalIpAddress(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                if (intf.isLoopback || !intf.isUp) continue
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val host = addr.hostAddress ?: ""
                        if (host.isNotEmpty() && !host.startsWith("127.")) {
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not determine local network IP: ${e.message}")
        }
        return "127.0.0.1"
    }

    override fun close() {
        acceptJob?.cancel()
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        _isListening.value = false
        _boundPort.value = null
    }
}
