package com.example.p2p.connectivity.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.util.Log
import com.example.p2p.connectivity.model.NetworkChangeEvent
import com.example.p2p.connectivity.model.NetworkInterfaceType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.Closeable
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Observes real Android network transitions via [ConnectivityManager.NetworkCallback]:
 * - Wi-Fi <-> Cellular transitions
 * - Wi-Fi to another Wi-Fi / public IP or local IP updates
 * - Airplane mode / connectivity loss and restoration
 *
 * Debounces rapid OS callback bursts before emitting [NetworkChangeEvent] so ICE restarts
 * and peer reconnections are triggered cleanly without storms.
 */
class AndroidNetworkMonitor(
    private val context: Context,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val debounceMs: Long = 350L
) : Closeable {

    companion object {
        private const val TAG = "AndroidNetworkMonitor"
    }

    private val connectivityManager: ConnectivityManager? = try {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    } catch (_: Exception) {
        null
    }

    private val started = AtomicBoolean(false)
    private var registeredCallback: ConnectivityManager.NetworkCallback? = null
    private var debounceJob: Job? = null

    private val _currentNetworkType = MutableStateFlow(sampleCurrentNetworkType())
    val currentNetworkType: StateFlow<NetworkInterfaceType> = _currentNetworkType.asStateFlow()

    private val _lastNetworkChange = MutableStateFlow<NetworkChangeEvent?>(null)
    val lastNetworkChange: StateFlow<NetworkChangeEvent?> = _lastNetworkChange.asStateFlow()

    private val _networkChanges = MutableSharedFlow<NetworkChangeEvent>(extraBufferCapacity = 16)
    val networkChanges: SharedFlow<NetworkChangeEvent> = _networkChanges.asSharedFlow()

    @Volatile
    private var lastKnownAddresses: List<String> = emptyList()

    fun start() {
        if (!started.compareAndSet(false, true)) return
        val cm = connectivityManager ?: return

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                scheduleChangeEvaluation(cm, network, "Network became available")
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                scheduleChangeEvaluation(cm, network, "Network capabilities updated")
            }

            override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                val addrs = linkProperties.linkAddresses
                    .mapNotNull { it.address?.hostAddress }
                    .sorted()
                scheduleChangeEvaluation(cm, network, "Link properties changed", explicitAddresses = addrs)
            }

            override fun onLost(network: Network) {
                scheduleLossEvaluation(cm)
            }
        }

        registeredCallback = callback
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(callback)
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(request, callback)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "ACCESS_NETWORK_STATE permission unavailable for NetworkCallback: ${e.message}")
            started.set(false)
            registeredCallback = null
        } catch (e: Exception) {
            Log.w(TAG, "Failed registering Android NetworkCallback: ${e.message}")
            started.set(false)
            registeredCallback = null
        }
    }

    fun stop() {
        if (!started.compareAndSet(true, false)) return
        debounceJob?.cancel()
        val cm = connectivityManager
        val cb = registeredCallback
        registeredCallback = null
        if (cm != null && cb != null) {
            try {
                cm.unregisterNetworkCallback(cb)
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Explicit test & OS-hook entry point to evaluate or inject a network change cleanly.
     */
    fun notifyObservedNetworkTransition(
        newType: NetworkInterfaceType,
        newAddresses: List<String>,
        reason: String
    ) {
        val previousType = _currentNetworkType.value
        val sortedAddrs = newAddresses.sorted()
        val ipChanged = lastKnownAddresses.isNotEmpty() && sortedAddrs.isNotEmpty() && lastKnownAddresses != sortedAddrs
        val interfaceChanged = previousType != newType

        if (!interfaceChanged && !ipChanged) {
            return
        }

        lastKnownAddresses = sortedAddrs
        _currentNetworkType.value = newType

        val requiresIceRestart = newType != NetworkInterfaceType.NONE &&
            (interfaceChanged || ipChanged)

        val event = NetworkChangeEvent(
            previousType = previousType,
            newType = newType,
            localAddresses = sortedAddrs,
            reason = reason,
            requiresIceRestart = requiresIceRestart
        )
        _lastNetworkChange.value = event
        scope.launch(ioDispatcher) {
            _networkChanges.emit(event)
        }
    }

    fun sampleCurrentNetworkType(): NetworkInterfaceType {
        val cm = connectivityManager ?: return NetworkInterfaceType.NONE
        return try {
            val active = cm.activeNetwork ?: return NetworkInterfaceType.NONE
            val caps = cm.getNetworkCapabilities(active) ?: return NetworkInterfaceType.NONE
            classifyCapabilities(caps)
        } catch (_: Exception) {
            NetworkInterfaceType.NONE
        }
    }

    private fun scheduleChangeEvaluation(
        cm: ConnectivityManager,
        network: Network,
        reason: String,
        explicitAddresses: List<String>? = null
    ) {
        debounceJob?.cancel()
        debounceJob = scope.launch(ioDispatcher) {
            delay(debounceMs)
            val caps = try {
                cm.getNetworkCapabilities(network) ?: cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
            } catch (_: Exception) {
                null
            }
            val newType = if (caps != null) classifyCapabilities(caps) else sampleCurrentNetworkType()
            val addrs = explicitAddresses ?: try {
                cm.getLinkProperties(network)?.linkAddresses?.mapNotNull { it.address?.hostAddress }.orEmpty()
            } catch (_: Exception) {
                emptyList()
            }
            notifyObservedNetworkTransition(newType, addrs, reason)
        }
    }

    private fun scheduleLossEvaluation(cm: ConnectivityManager) {
        debounceJob?.cancel()
        debounceJob = scope.launch(ioDispatcher) {
            delay(debounceMs)
            val activeType = sampleCurrentNetworkType()
            if (activeType == NetworkInterfaceType.NONE) {
                notifyObservedNetworkTransition(NetworkInterfaceType.NONE, emptyList(), "Active network lost")
            } else {
                val addrs = try {
                    cm.activeNetwork?.let { net ->
                        cm.getLinkProperties(net)?.linkAddresses?.mapNotNull { it.address?.hostAddress }
                    }.orEmpty()
                } catch (_: Exception) {
                    emptyList()
                }
                notifyObservedNetworkTransition(activeType, addrs, "Switched network after link loss")
            }
        }
    }

    private fun classifyCapabilities(caps: NetworkCapabilities): NetworkInterfaceType {
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkInterfaceType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkInterfaceType.CELLULAR
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkInterfaceType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> NetworkInterfaceType.VPN
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> NetworkInterfaceType.OTHER
            else -> NetworkInterfaceType.NONE
        }
    }

    override fun close() {
        stop()
    }
}
