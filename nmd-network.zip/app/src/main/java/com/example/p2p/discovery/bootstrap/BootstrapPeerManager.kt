package com.example.p2p.discovery.bootstrap

import android.content.Context
import android.util.Log
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.RealPeerInfo
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import java.io.Closeable
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * BootstrapPeerManager coordinates discovery bootstrap nodes.
 *
 * Provides:
 * - Configurable multi-bootstrap architecture.
 * - Clearly labeled local testnet / development bootstrap defaults.
 * - Exponential backoff retry policies.
 * - Integration with PeerConnectionManager and DistributedPeerRegistry.
 *
 * NOTE: Does not invent fake public internet servers.
 */
class BootstrapPeerManager(
    private val context: Context? = null,
    private val registry: DistributedPeerRegistry,
    private val connectionManager: PeerConnectionManager? = null,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : Closeable {

    companion object {
        private const val TAG = "BootstrapPeerManager"
        private const val PREFS_NAME = "nmd_bootstrap_prefs"
        private const val KEY_CUSTOM_BOOTSTRAP = "custom_bootstrap_peers"
    }

    private val mutex = Mutex()
    private val bootstrapMap = ConcurrentHashMap<String, BootstrapPeer>()

    private val _bootstrapPeers = MutableStateFlow<List<BootstrapPeer>>(emptyList())
    val bootstrapPeers: StateFlow<List<BootstrapPeer>> = _bootstrapPeers.asStateFlow()

    init {
        initDefaultPeers()
        loadPersistedBootstrapPeers()
    }

    private fun initDefaultPeers() {
        // Pre-configured development / testnet bootstrap nodes
        val devNodes = listOf(
            BootstrapPeer(
                id = "dev_emulator_host",
                name = "Dev Emulator Host (10.0.2.2:8765)",
                host = "10.0.2.2",
                port = 8765,
                isEnabled = true,
                isPreconfiguredDev = true
            ),
            BootstrapPeer(
                id = "dev_local_loopback",
                name = "Local Testnet Loopback (127.0.0.1:8765)",
                host = "127.0.0.1",
                port = 8765,
                isEnabled = false,
                isPreconfiguredDev = true
            )
        )
        devNodes.forEach { node ->
            bootstrapMap[node.id] = node
            syncToRegistry(node)
        }
        publishPeers()
    }

    /**
     * Adds a custom user-defined bootstrap peer.
     */
    fun addCustomBootstrapPeer(
        name: String,
        host: String,
        port: Int,
        expectedNodeId: String? = null,
        expectedPublicKeyHex: String? = null
    ): BootstrapPeer {
        val id = "bootstrap_" + UUID.randomUUID().toString().take(8)
        val peer = BootstrapPeer(
            id = id,
            name = name.ifBlank { "Bootstrap ($host:$port)" },
            host = host.trim(),
            port = port,
            expectedNodeId = expectedNodeId?.trim()?.ifBlank { null },
            expectedPublicKeyHex = expectedPublicKeyHex?.trim()?.ifBlank { null },
            isEnabled = true,
            isPreconfiguredDev = false
        )
        bootstrapMap[id] = peer
        syncToRegistry(peer)
        publishPeers()
        savePersistedBootstrapPeers()
        return peer
    }

    /**
     * Toggles whether a bootstrap peer is enabled.
     */
    fun toggleBootstrapPeer(id: String, isEnabled: Boolean) {
        val existing = bootstrapMap[id] ?: return
        val updated = existing.copy(isEnabled = isEnabled)
        bootstrapMap[id] = updated
        syncToRegistry(updated)
        publishPeers()
        savePersistedBootstrapPeers()
    }

    /**
     * Removes a custom bootstrap peer.
     */
    fun removeBootstrapPeer(id: String): Boolean {
        val existing = bootstrapMap[id] ?: return false
        if (existing.isPreconfiguredDev) {
            // Cannot remove preconfigured dev nodes, only disable them
            toggleBootstrapPeer(id, false)
            return false
        }
        val removed = bootstrapMap.remove(id) != null
        if (removed) {
            registry.removePeer(existing.expectedNodeId ?: id)
            publishPeers()
            savePersistedBootstrapPeers()
        }
        return removed
    }

    /**
     * Initiates a connection to a specific bootstrap peer, with exponential backoff on failure.
     */
    suspend fun connectToBootstrapPeer(id: String): Result<RealPeerInfo> {
        val peer = bootstrapMap[id]
            ?: return Result.failure(IllegalArgumentException("Bootstrap peer not found: $id"))

        if (peer.isInBackoff) {
            val remainingSec = (peer.backoffUntilEpochMs - System.currentTimeMillis()) / 1000L
            return Result.failure(IllegalStateException("Bootstrap node in retry backoff. Retry in ${remainingSec}s"))
        }

        val connManager = connectionManager
            ?: return Result.failure(IllegalStateException("PeerConnectionManager not available"))

        // Set status to CONNECTING
        bootstrapMap[id] = peer.copy(
            status = BootstrapStatus.CONNECTING,
            lastAttemptEpochMs = System.currentTimeMillis()
        )
        publishPeers()

        val result = connManager.connectToPeer(peer.endpoint)
        val now = System.currentTimeMillis()

        if (result.isSuccess) {
            val peerInfo = result.getOrThrow()
            bootstrapMap[id] = peer.copy(
                status = BootstrapStatus.CONNECTED,
                consecutiveFailures = 0,
                backoffUntilEpochMs = 0L,
                lastError = null
            )
            registry.recordSuccessfulAuth(peerInfo.authenticatedNodeId ?: id, peerInfo.authenticatedPublicKeyHex)
            publishPeers()
            return result
        } else {
            val errorMsg = result.exceptionOrNull()?.message ?: "Connection failed"
            val newFailures = peer.consecutiveFailures + 1
            val backoffMs = BootstrapPeer.computeBackoffMs(newFailures)
            val backoffUntil = now + backoffMs

            bootstrapMap[id] = peer.copy(
                status = if (backoffMs > 0) BootstrapStatus.BACKOFF else BootstrapStatus.FAILED,
                consecutiveFailures = newFailures,
                backoffUntilEpochMs = backoffUntil,
                lastError = errorMsg
            )
            registry.recordConnectionFailed(peer.expectedNodeId ?: id)
            publishPeers()
            return result
        }
    }

    private fun syncToRegistry(peer: BootstrapPeer) {
        if (!peer.isEnabled) return
        val peerId = peer.expectedNodeId ?: "bootstrap_${peer.host}_${peer.port}"
        registry.registerOrUpdatePeer(
            peerId = peerId,
            endpoint = peer.endpoint,
            source = DiscoverySource.BOOTSTRAP,
            publicKeyHex = peer.expectedPublicKeyHex,
            isBootstrap = true
        )
    }

    private fun publishPeers() {
        _bootstrapPeers.value = bootstrapMap.values.toList()
    }

    private fun loadPersistedBootstrapPeers() {
        val ctx = context ?: return
        scope.launch(ioDispatcher) {
            try {
                val prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val jsonStr = prefs.getString(KEY_CUSTOM_BOOTSTRAP, null) ?: return@launch
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val peer = BootstrapPeer.fromJson(obj)
                    if (peer != null) {
                        bootstrapMap[peer.id] = peer
                        syncToRegistry(peer)
                    }
                }
                publishPeers()
            } catch (e: Exception) {
                Log.w(TAG, "Error loading persisted bootstrap peers: ${e.message}")
            }
        }
    }

    private fun savePersistedBootstrapPeers() {
        val ctx = context ?: return
        scope.launch(ioDispatcher) {
            mutex.withLock {
                try {
                    val prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    val arr = JSONArray()
                    bootstrapMap.values.filter { !it.isPreconfiguredDev }.forEach { arr.put(it.toJson()) }
                    prefs.edit().putString(KEY_CUSTOM_BOOTSTRAP, arr.toString()).apply()
                } catch (e: Exception) {
                    Log.w(TAG, "Error saving custom bootstrap peers: ${e.message}")
                }
            }
        }
    }

    override fun close() {
        savePersistedBootstrapPeers()
    }
}
