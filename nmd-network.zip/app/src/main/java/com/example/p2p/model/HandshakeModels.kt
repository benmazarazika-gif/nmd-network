package com.example.p2p.model

object FrameType {
    const val HANDSHAKE_HELLO: Byte = 0x01
    const val HANDSHAKE_RESPONSE: Byte = 0x02
    const val HANDSHAKE_FINAL: Byte = 0x03
    const val SECURE_HANDSHAKE_INIT: Byte = 0x04
    const val SECURE_HANDSHAKE_RESP: Byte = 0x05
    const val SECURE_HANDSHAKE_FIN: Byte = 0x06
    const val PROTOCOL_MESSAGE: Byte = 0x10
    const val HEARTBEAT_PING: Byte = 0x20
    const val HEARTBEAT_PONG: Byte = 0x21
    const val RELIABLE_MSG: Byte = 0x30
    const val ENCRYPTED_FRAME: Byte = 0x40
    const val DISCONNECT: Byte = 0xFF.toByte()
}

/**
 * Handshake Hello message initiated by the connecting peer (or received by server).
 */
data class HandshakeHello(
    val protocolVersion: Int,
    val senderNodeId: String,
    val senderPublicKeyHex: String,
    val challengeHex: String,
    val timestamp: Long
) {
    val challenge: String
        get() = challengeHex

    fun toJson(): String {
        return """
        {
          "version": $protocolVersion,
          "sender_node_id": "$senderNodeId",
          "sender_public_key": "$senderPublicKeyHex",
          "challenge": "$challengeHex",
          "timestamp": $timestamp
        }
        """.trimIndent()
    }

    companion object {
        const val CURRENT_PROTOCOL_VERSION = 2

        fun fromJson(json: String): HandshakeHello? {
            return try {
                val org = org.json.JSONObject(json)
                HandshakeHello(
                    protocolVersion = org.getInt("version"),
                    senderNodeId = org.getString("sender_node_id"),
                    senderPublicKeyHex = org.getString("sender_public_key"),
                    challengeHex = org.getString("challenge"),
                    timestamp = org.getLong("timestamp")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

/**
 * Handshake Response containing the signature of the incoming challenge,
 * plus a counter-challenge for mutual authentication.
 */
data class HandshakeResponse(
    val protocolVersion: Int,
    val responderNodeId: String,
    val responderPublicKeyHex: String,
    val challengeSignatureHex: String,
    val counterChallengeHex: String,
    val timestamp: Long
) {
    val signatureOfHelloChallengeHex: String
        get() = challengeSignatureHex

    val responderChallengeHex: String
        get() = counterChallengeHex

    fun toJson(): String {
        return """
        {
          "version": $protocolVersion,
          "responder_node_id": "$responderNodeId",
          "responder_public_key": "$responderPublicKeyHex",
          "signature": "$challengeSignatureHex",
          "counter_challenge": "$counterChallengeHex",
          "timestamp": $timestamp
        }
        """.trimIndent()
    }

    companion object {
        const val CURRENT_PROTOCOL_VERSION = 2

        fun fromJson(json: String): HandshakeResponse? {
            return try {
                val org = org.json.JSONObject(json)
                HandshakeResponse(
                    protocolVersion = org.getInt("version"),
                    responderNodeId = org.getString("responder_node_id"),
                    responderPublicKeyHex = org.getString("responder_public_key"),
                    challengeSignatureHex = org.getString("signature"),
                    counterChallengeHex = org.getString("counter_challenge"),
                    timestamp = org.getLong("timestamp")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

/**
 * Handshake Final message confirming counter-challenge verification.
 */
data class HandshakeFinal(
    val counterChallengeSignatureHex: String,
    val status: String = "ACCEPTED"
) {
    val signatureOfResponseChallengeHex: String
        get() = counterChallengeSignatureHex

    fun toJson(): String {
        return """
        {
          "signature": "$counterChallengeSignatureHex",
          "status": "$status"
        }
        """.trimIndent()
    }

    companion object {
        fun fromJson(json: String): HandshakeFinal? {
            return try {
                val org = org.json.JSONObject(json)
                HandshakeFinal(
                    counterChallengeSignatureHex = org.getString("signature"),
                    status = org.optString("status", "ACCEPTED")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}
