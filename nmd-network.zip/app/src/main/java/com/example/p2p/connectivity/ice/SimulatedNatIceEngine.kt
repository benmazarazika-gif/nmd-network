package com.example.p2p.connectivity.ice

import com.example.p2p.connectivity.model.IceCandidateInfo
import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.IceConnectionStatus
import com.example.p2p.connectivity.model.IceGatheringProgress
import com.example.p2p.connectivity.model.TransportPathType
import com.example.p2p.transport.BufferedStreamTransportChannel
import com.example.p2p.transport.TransportChannel
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Policy flags describing simulated NAT behavior for JVM/Robolectric tests
 * where native Android WebRTC JNI (`libjingle_peerconnection_so.so`) cannot load.
 */
enum class SimulatedNatBehavior {
    DIRECT_ICE_ALLOWED,
    DIRECT_BLOCKED_RELAY_REQUIRED,
    ALL_PATHS_BLOCKED,
    IPV6_PREFERRED_DIRECT
}

/**
 * Shared virtual ICE / TURN wire hub connecting [SimulatedNatIceEngine] instances in tests.
 * Only bridges raw packet streams — NEVER bypasses NMD Ed25519/X25519/ChaCha20-Poly1305 security.
 */
class SimulatedIceNetworkFabric(
    @Volatile var behavior: SimulatedNatBehavior = SimulatedNatBehavior.DIRECT_ICE_ALLOWED
) {
    internal data class EndpointRegistration(
        val sessionId: String,
        val nodeId: String,
        val remoteNodeId: String,
        val session: SimulatedIcePeerSession
    )

    private val activeEndpoints = ConcurrentHashMap<String, EndpointRegistration>()

    internal fun registerSession(reg: EndpointRegistration) {
        activeEndpoints["${reg.nodeId}->${reg.remoteNodeId}:${reg.sessionId}"] = reg
    }

    internal fun unregisterSession(nodeId: String, remoteNodeId: String, sessionId: String) {
        activeEndpoints.remove("$nodeId->$remoteNodeId:$sessionId")
    }

    internal fun findPeerSession(fromNodeId: String, targetNodeId: String): EndpointRegistration? {
        return activeEndpoints.values.firstOrNull {
            it.nodeId == targetNodeId && it.remoteNodeId == fromNodeId
        }
    }
}

/**
 * Explicit simulation [IceEngine] used in JVM/Robolectric integration tests when
 * native Android WebRTC binaries are absent. Exercises full SDP offer/answer exchange,
 * RFC 8445 candidate parsing, candidate ranking, TURN relay gating, timeouts, ICE restart,
 * and end-to-end [TransportChannel] delivery into Stage 13 encryption.
 */
class SimulatedNatIceEngine(
    private val localNodeId: String,
    private val fabric: SimulatedIceNetworkFabric
) : IceEngine {

    override val engineName: String = "Simulated ICE/NAT Engine (JVM Test Adapter)"
    override val isNativeAvailable: Boolean = false

    override fun createSession(config: IceSessionConfig, callbacks: IceSessionCallbacks): IcePeerSession {
        return SimulatedIcePeerSession(localNodeId, config, callbacks, fabric)
    }

    override fun close() = Unit
}

internal class SimulatedIcePeerSession(
    private val localNodeId: String,
    private val config: IceSessionConfig,
    private val callbacks: IceSessionCallbacks,
    private val fabric: SimulatedIceNetworkFabric
) : IcePeerSession {

    override val sessionId: String = config.sessionId
    override val remoteNodeId: String = config.remoteNodeId

    private val closed = AtomicBoolean(false)
    private val localOfferNonce = UUID.randomUUID().toString().take(8)
    @Volatile
    private var restartGeneration = 0
    @Volatile
    private var bridgeChannel: BufferedStreamTransportChannel? = null
    @Volatile
    private var candidateCheckAttempted = false

    init {
        fabric.registerSession(
            SimulatedIceNetworkFabric.EndpointRegistration(
                sessionId = sessionId,
                nodeId = localNodeId,
                remoteNodeId = config.remoteNodeId,
                session = this
            )
        )
    }

    override fun startOffer() {
        if (closed.get()) return
        callbacks.onGatheringStateChanged(IceGatheringProgress.GATHERING)
        val sdp = buildSdp("offer", restartGeneration)
        callbacks.onLocalOfferCreated(sdp)
        emitGatheredCandidates()
        callbacks.onGatheringStateChanged(IceGatheringProgress.COMPLETE)
    }

    override fun acceptRemoteOfferAndCreateAnswer(remoteOfferSdp: String) {
        if (closed.get()) return
        callbacks.onGatheringStateChanged(IceGatheringProgress.GATHERING)
        val sdp = buildSdp("answer", restartGeneration)
        callbacks.onLocalAnswerCreated(sdp)
        emitGatheredCandidates()
        callbacks.onGatheringStateChanged(IceGatheringProgress.COMPLETE)
    }

    override fun acceptRemoteAnswer(remoteAnswerSdp: String) {
        if (closed.get()) return
        callbacks.onConnectionStateChanged(IceConnectionStatus.CHECKING)
    }

    override fun addRemoteCandidate(candidate: IceCandidateInfo): Boolean {
        if (closed.get()) return false
        if (candidateCheckAttempted) return true

        val behavior = fabric.behavior
        val hasValidTurn = config.turnServers.any { it.isCredentialValid() }

        when (behavior) {
            SimulatedNatBehavior.ALL_PATHS_BLOCKED -> {
                if (candidate.type == IceCandidateType.RELAY && !hasValidTurn) {
                    callbacks.onConnectionStateChanged(IceConnectionStatus.FAILED)
                    return false
                }
                callbacks.onConnectionStateChanged(IceConnectionStatus.FAILED)
                callbacks.onError("Simulated NAT: all direct and relay ICE paths blocked")
                return false
            }
            SimulatedNatBehavior.DIRECT_BLOCKED_RELAY_REQUIRED -> {
                if (candidate.type != IceCandidateType.RELAY) {
                    // Direct candidates fail ICE connectivity checks behind symmetric NAT
                    callbacks.onConnectionStateChanged(IceConnectionStatus.CHECKING)
                    if (!hasValidTurn) {
                        callbacks.onConnectionStateChanged(IceConnectionStatus.FAILED)
                        callbacks.onError("Direct ICE blocked by symmetric NAT and no valid TURN server configured")
                    }
                    return false
                }
                if (!hasValidTurn) {
                    callbacks.onConnectionStateChanged(IceConnectionStatus.FAILED)
                    callbacks.onError("TURN relay candidate rejected: missing or expired credentials")
                    return false
                }
                establishConnectedBridge(
                    localType = IceCandidateType.RELAY,
                    remoteType = IceCandidateType.RELAY,
                    pathType = TransportPathType.TURN_RELAY,
                    pairSummary = "relay(turn) <-> relay(turn)"
                )
                return true
            }
            SimulatedNatBehavior.DIRECT_ICE_ALLOWED -> {
                if (config.forceRelayOnly && candidate.type != IceCandidateType.RELAY) {
                    return false
                }
                val chosenPath = if (candidate.type == IceCandidateType.RELAY) {
                    TransportPathType.TURN_RELAY
                } else {
                    TransportPathType.ICE_DIRECT
                }
                val localType = if (chosenPath == TransportPathType.TURN_RELAY) IceCandidateType.RELAY else IceCandidateType.SRFLX
                establishConnectedBridge(
                    localType = localType,
                    remoteType = candidate.type,
                    pathType = chosenPath,
                    pairSummary = "${localType.sdpToken}(198.51.100.10) <-> ${candidate.type.sdpToken}(${candidate.address}:${candidate.port})"
                )
                return true
            }
            SimulatedNatBehavior.IPV6_PREFERRED_DIRECT -> {
                if (candidate.type == IceCandidateType.RELAY && !hasValidTurn) return false
                val chosenPath = if (candidate.type == IceCandidateType.RELAY) TransportPathType.TURN_RELAY else TransportPathType.ICE_DIRECT
                val localType = if (chosenPath == TransportPathType.TURN_RELAY) IceCandidateType.RELAY else IceCandidateType.SRFLX
                establishConnectedBridge(
                    localType = localType,
                    remoteType = candidate.type,
                    pathType = chosenPath,
                    pairSummary = "${localType.sdpToken}([2001:db8::10]) <-> ${candidate.type.sdpToken}(${candidate.address}:${candidate.port})"
                )
                return true
            }
        }
    }

    override fun restartIce() {
        if (closed.get()) return
        restartGeneration += 1
        candidateCheckAttempted = false
        callbacks.onConnectionStateChanged(IceConnectionStatus.CHECKING)
        if (config.isInitiator) {
            startOffer()
        }
    }

    private fun establishConnectedBridge(
        localType: IceCandidateType,
        remoteType: IceCandidateType,
        pathType: TransportPathType,
        pairSummary: String
    ) {
        if (candidateCheckAttempted || closed.get()) return
        val peerReg = fabric.findPeerSession(localNodeId, config.remoteNodeId) ?: return
        candidateCheckAttempted = true

        callbacks.onConnectionStateChanged(IceConnectionStatus.CONNECTED)
        callbacks.onSelectedCandidatePairChanged(localType, remoteType, pairSummary, pathType)

        if (config.isInitiator) {
            val peerSession = peerReg.session
            peerSession.notifyPartnerPairEstablished(localType, remoteType, pathType, pairSummary)

            lateinit var localBridge: BufferedStreamTransportChannel
            lateinit var remoteBridge: BufferedStreamTransportChannel

            localBridge = BufferedStreamTransportChannel(
                channelId = sessionId,
                pathType = pathType,
                selectedCandidateType = remoteType,
                remoteAddressLabel = "ice://${config.remoteNodeId.take(12)}",
                sendPacket = { bytes -> remoteBridge.deliverIncomingBytes(bytes) },
                onCloseCallback = { remoteBridge.close() }
            )
            remoteBridge = BufferedStreamTransportChannel(
                channelId = peerSession.sessionId,
                pathType = pathType,
                selectedCandidateType = localType,
                remoteAddressLabel = "ice://${localNodeId.take(12)}",
                sendPacket = { bytes -> localBridge.deliverIncomingBytes(bytes) },
                onCloseCallback = { localBridge.close() }
            )
            this.bridgeChannel = localBridge
            peerSession.attachPartnerBridgeChannel(remoteBridge)

            callbacks.onDataChannelOpen(localBridge)
            peerSession.callbacks.onDataChannelOpen(remoteBridge)
        }
    }

    internal fun notifyPartnerPairEstablished(
        remoteSideLocalType: IceCandidateType,
        remoteSideRemoteType: IceCandidateType,
        pathType: TransportPathType,
        pairSummary: String
    ) {
        if (closed.get()) return
        candidateCheckAttempted = true
        callbacks.onConnectionStateChanged(IceConnectionStatus.CONNECTED)
        callbacks.onSelectedCandidatePairChanged(remoteSideRemoteType, remoteSideLocalType, pairSummary, pathType)
    }

    internal fun attachPartnerBridgeChannel(channel: BufferedStreamTransportChannel) {
        this.bridgeChannel = channel
    }

    private fun emitGatheredCandidates() {
        val behavior = fabric.behavior
        val hostSdp = if (behavior == SimulatedNatBehavior.IPV6_PREFERRED_DIRECT) {
            "candidate:101 1 udp 2122262783 2001:db8::42 51420 typ host"
        } else {
            "candidate:101 1 udp 2122260223 192.0.2.15 51420 typ host"
        }
        IceCandidateInfo.parseSafe(hostSdp)?.let { callbacks.onLocalIceCandidate(it) }

        if (config.stunServers.any { it.enabled && it.isValidConfig() }) {
            val srflxIp = if (behavior == SimulatedNatBehavior.IPV6_PREFERRED_DIRECT) "2001:db8:1::99" else "198.51.100.25"
            val srflxSdp = "candidate:202 1 udp 1686052607 $srflxIp 62310 typ srflx raddr 192.0.2.15 rport 51420"
            IceCandidateInfo.parseSafe(srflxSdp)?.let { callbacks.onLocalIceCandidate(it) }
        }

        if (config.turnServers.any { it.isCredentialValid() }) {
            val relaySdp = "candidate:303 1 udp 41885439 203.0.113.77 3478 typ relay raddr 198.51.100.25 rport 62310"
            IceCandidateInfo.parseSafe(relaySdp)?.let { callbacks.onLocalIceCandidate(it) }
        }
    }

    private fun buildSdp(kind: String, gen: Int): String {
        return "v=0\no=nmd $localOfferNonce $gen IN IP4 127.0.0.1\ns=nmd-$kind\nt=0 0\na=ice-ufrag:${localOfferNonce}g$gen\na=ice-pwd:nmdpassphrase$gen\n"
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            fabric.unregisterSession(localNodeId, config.remoteNodeId, sessionId)
            try {
                bridgeChannel?.close()
            } catch (_: Exception) {
            }
            callbacks.onConnectionStateChanged(IceConnectionStatus.CLOSED)
        }
    }
}
