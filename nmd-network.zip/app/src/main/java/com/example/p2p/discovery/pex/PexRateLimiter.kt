package com.example.p2p.discovery.pex

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * PexRateLimiter implements a sliding-window rate limiter per peer.
 *
 * Prevents discovery flooding, amplification attacks, and resource exhaustion.
 * Default policy: Max 10 PEX requests per peer per 60 seconds.
 */
class PexRateLimiter(
    private val maxRequestsPerWindow: Int = DEFAULT_MAX_REQUESTS,
    private val windowDurationMs: Long = DEFAULT_WINDOW_MS
) {
    companion object {
        const val DEFAULT_MAX_REQUESTS = 10
        const val DEFAULT_WINDOW_MS = 60_000L // 1 minute
    }

    private val peerRequestTimestamps = ConcurrentHashMap<String, ConcurrentLinkedQueue<Long>>()

    /**
     * Checks if a request from peerId is allowed.
     * Returns true if allowed, false if rate limit is exceeded.
     */
    fun checkAndRecord(peerId: String): Boolean {
        val now = System.currentTimeMillis()
        val queue = peerRequestTimestamps.computeIfAbsent(peerId) { ConcurrentLinkedQueue() }

        // Evict expired timestamps from the sliding window
        while (true) {
            val oldest = queue.peek() ?: break
            if (now - oldest > windowDurationMs) {
                queue.poll()
            } else {
                break
            }
        }

        return if (queue.size < maxRequestsPerWindow) {
            queue.add(now)
            true
        } else {
            false
        }
    }

    fun resetPeer(peerId: String) {
        peerRequestTimestamps.remove(peerId)
    }

    fun clear() {
        peerRequestTimestamps.clear()
    }
}
