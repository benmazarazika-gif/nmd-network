package com.example.p2p.connectivity.model

import com.example.blockchain.config.NmdGenesisConfigs
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

/**
 * Overall NAT traversal and P2P connectivity lifecycle states for Stage 14.
 */
enum class ConnectivityState {
    DISCOVERING,
    GATHERING_CANDIDATES,
    CONNECTING_DIRECTLY,
    CONNECTED_DIRECTLY,
    CONNECTING_THROUGH_RELAY,
    CONNECTED_THROUGH_RELAY,
    RECONNECTING,
    NO_CONNECTIVITY,
    AUTHENTICATION_FAILED
}

/**
 * Active underlying transport path used to carry Stage 13 encrypted frames.
 */
enum class TransportPathType {
    LOCAL_DIRECT_TCP,
    ICE_DIRECT,
    TURN_RELAY,
    NONE
}

/**
 * RFC 8445 ICE candidate types.
 */
enum class IceCandidateType(val sdpToken: String) {
    HOST("host"),
    SRFLX("srflx"),
    PRFLX("prflx"),
    RELAY("relay"),
    UNKNOWN("unknown");

    companion object {
        fun fromToken(token: String?): IceCandidateType {
            return when (token?.lowercase()) {
                "host" -> HOST
                "srflx" -> SRFLX
                "prflx" -> PRFLX
                "relay" -> RELAY
                else -> UNKNOWN
            }
        }
    }
}

enum class IpVersion {
    IPV4,
    IPV6,
    UNKNOWN
}

enum class TurnTransportProtocol(val queryParam: String?) {
    UDP(null),
    TCP("transport=tcp"),
    TLS("transport=tls")
}

enum class IceGatheringProgress {
    NEW,
    GATHERING,
    COMPLETE,
    TIMED_OUT,
    FAILED
}

enum class IceConnectionStatus {
    NEW,
    CHECKING,
    CONNECTED,
    COMPLETED,
    FAILED,
    DISCONNECTED,
    CLOSED
}

enum class NetworkInterfaceType {
    WIFI,
    CELLULAR,
    ETHERNET,
    VPN,
    OTHER,
    NONE
}

/**
 * Configurable STUN server endpoint. No single hardcoded public server is relied upon.
 */
data class StunServerConfig(
    val uri: String,
    val timeoutMs: Long = 3_000L,
    val enabled: Boolean = true
) {
    fun isValidConfig(): Boolean {
        val trimmed = uri.trim()
        if (!trimmed.startsWith("stun:", ignoreCase = true) &&
            !trimmed.startsWith("stuns:", ignoreCase = true)
        ) {
            return false
        }
        return parseHostAndPort() != null && timeoutMs in 300L..30_000L
    }

    fun parseHostAndPort(): Pair<String, Int>? {
        val cleaned = uri.trim()
            .removePrefix("stuns:")
            .removePrefix("STUNS:")
            .removePrefix("stun:")
            .removePrefix("STUN:")
            .substringBefore("?")
            .trim()
        if (cleaned.isBlank() || cleaned.contains(" ") || cleaned.length > 255) return null

        return if (cleaned.startsWith("[")) {
            val endBracket = cleaned.indexOf(']')
            if (endBracket <= 1) return null
            val host = cleaned.substring(1, endBracket)
            val rest = cleaned.substring(endBracket + 1)
            val port = if (rest.startsWith(":")) rest.substring(1).toIntOrNull() else 3478
            if (port == null || port !in 1..65535) null else host to port
        } else {
            val colonIdx = cleaned.lastIndexOf(':')
            if (colonIdx > 0) {
                val host = cleaned.substring(0, colonIdx)
                val port = cleaned.substring(colonIdx + 1).toIntOrNull()
                if (host.isBlank() || port == null || port !in 1..65535) null else host to port
            } else {
                cleaned to 3478
            }
        }
    }
}

/**
 * Externalized TURN relay server configuration supporting UDP, TCP, and TLS plus
 * authenticated, expiring credentials. Never hardcode permanent production secrets.
 */
data class TurnServerConfig(
    val uri: String,
    val transport: TurnTransportProtocol = TurnTransportProtocol.UDP,
    val username: String = "",
    val credential: String = "",
    val expiresAtEpochMs: Long? = null,
    val enabled: Boolean = true
) {
    fun isValidConfig(): Boolean {
        val trimmed = uri.trim()
        val hasTurnScheme = trimmed.startsWith("turn:", ignoreCase = true) ||
            trimmed.startsWith("turns:", ignoreCase = true)
        if (!hasTurnScheme || trimmed.length > 512) return false
        val body = trimmed.substringAfter(":").substringBefore("?")
        if (body.isBlank() || body.contains(" ")) return false
        return username.isNotBlank() && credential.isNotBlank()
    }

    fun isCredentialValid(nowMs: Long = System.currentTimeMillis()): Boolean {
        if (!enabled || !isValidConfig()) return false
        val exp = expiresAtEpochMs ?: return true
        return nowMs < exp
    }

    fun effectiveIceUri(): String {
        val base = uri.trim()
        val param = transport.queryParam ?: return base
        return if (base.contains("transport=", ignoreCase = true)) {
            base
        } else if (base.contains("?")) {
            "$base&$param"
        } else {
            "$base?$param"
        }
    }

    /**
     * Returns a log-safe and UI-safe summary with TURN secret credential redacted.
     */
    fun redactedSummary(): String {
        val expLabel = expiresAtEpochMs?.let { exp ->
            if (System.currentTimeMillis() >= exp) "EXPIRED" else "EXP:${exp}"
        } ?: "NO_EXPIRY"
        return "${effectiveIceUri()} (user=${username.take(12)}, $expLabel)"
    }
}

/**
 * Resource, timeout, rate-limit, and ICE/NAT traversal policy configuration.
 */
data class NatTraversalConfig(
    val chainId: String = NmdGenesisConfigs.LOCAL_DEV.chainId,
    val stunServers: List<StunServerConfig> = emptyList(),
    val turnServers: List<TurnServerConfig> = emptyList(),
    val maxCandidateQueueSize: Int = 64,
    val maxConcurrentNegotiations: Int = 6,
    val iceGatheringTimeoutMs: Long = 8_000L,
    val iceConnectivityTimeoutMs: Long = 12_000L,
    val directPreferredWindowMs: Long = 3_500L,
    val abandonedSessionTtlMs: Long = 45_000L,
    val maxSignalingPayloadBytes: Int = 16 * 1024,
    val maxNegotiationStartsPerPeerPerWindow: Int = 6,
    val negotiationRateWindowMs: Long = 60_000L,
    val maxTurnAllocationsPerSession: Int = 2,
    val maxIceRestartAttempts: Int = 3,
    val enableIpv6Candidates: Boolean = true,
    val preferLocalDirectBeforeIce: Boolean = true,
    val stunProbeIntervalMs: Long = 60_000L
)

/**
 * Validated ICE candidate model parsed safely from untrusted remote SDP attributes.
 */
data class IceCandidateInfo(
    val foundation: String,
    val component: Int,
    val transport: String,
    val priority: Long,
    val address: String,
    val port: Int,
    val type: IceCandidateType,
    val ipVersion: IpVersion,
    val sdpMid: String = "0",
    val sdpMLineIndex: Int = 0,
    val rawSdp: String
) {
    val isDirectPathCandidate: Boolean
        get() = type == IceCandidateType.HOST || type == IceCandidateType.SRFLX || type == IceCandidateType.PRFLX

    companion object {
        private const val MAX_CANDIDATE_SDP_CHARS = 512

        /**
         * Safely validates and parses an RFC 8445 / WebRTC ICE candidate attribute line.
         * Rejects control characters, oversized candidates, invalid ports, invalid protocols,
         * and missing candidate type tokens before passing to WebRTC/ICE layers.
         */
        fun parseSafe(
            rawSdp: String,
            sdpMid: String = "0",
            sdpMLineIndex: Int = 0
        ): IceCandidateInfo? {
            if (rawSdp.isBlank() || rawSdp.length > MAX_CANDIDATE_SDP_CHARS) return null
            if (rawSdp.any { it == '\n' || it == '\r' || it.code < 0x20 }) return null
            if (sdpMid.length > 32 || sdpMLineIndex < 0 || sdpMLineIndex > 16) return null

            val normalized = rawSdp.trim()
                .removePrefix("a=")
                .removePrefix("candidate:")
                .trim()
            val parts = normalized.split(Regex("\\s+"))
            // Minimal RFC 8445: <foundation> <component> <transport> <priority> <address> <port> typ <type>
            if (parts.size < 8) return null

            val foundation = parts[0]
            if (foundation.isBlank() || foundation.length > 32 || !foundation.all { it.isLetterOrDigit() || it == '+' || it == '/' }) {
                return null
            }

            val component = parts[1].toIntOrNull() ?: return null
            if (component !in 1..2) return null

            val transport = parts[2].lowercase()
            if (transport != "udp" && transport != "tcp" && transport != "ssltcp") return null

            val priority = parts[3].toLongOrNull() ?: return null
            if (priority <= 0L) return null

            val address = parts[4]
            if (address.isBlank() || address.length > 253) return null

            val port = parts[5].toIntOrNull() ?: return null
            if (port !in 1..65535) return null

            if (!parts[6].equals("typ", ignoreCase = true)) return null
            val type = IceCandidateType.fromToken(parts[7])
            if (type == IceCandidateType.UNKNOWN) return null

            val ipVersion = detectIpVersion(address)
            return IceCandidateInfo(
                foundation = foundation,
                component = component,
                transport = transport,
                priority = priority,
                address = address,
                port = port,
                type = type,
                ipVersion = ipVersion,
                sdpMid = sdpMid,
                sdpMLineIndex = sdpMLineIndex,
                rawSdp = rawSdp.trim()
            )
        }

        fun detectIpVersion(host: String): IpVersion {
            return try {
                if (host.endsWith(".local", ignoreCase = true)) {
                    // RFC 6762 mDNS obfuscated ICE host candidates
                    IpVersion.IPV4
                } else if (host.contains(':') && !host.contains('.')) {
                    val addr = InetAddress.getByName(host)
                    if (addr is Inet6Address) IpVersion.IPV6 else IpVersion.UNKNOWN
                } else {
                    val v4Regex = Regex("^(\\d{1,3}\\.){3}\\d{1,3}$")
                    if (v4Regex.matches(host)) {
                        val octets = host.split(".").mapNotNull { it.toIntOrNull() }
                        if (octets.size == 4 && octets.all { it in 0..255 }) {
                            val addr = InetAddress.getByName(host)
                            if (addr is Inet4Address) IpVersion.IPV4 else IpVersion.UNKNOWN
                        } else IpVersion.UNKNOWN
                    } else {
                        IpVersion.UNKNOWN
                    }
                }
            } catch (_: Exception) {
                IpVersion.UNKNOWN
            }
        }
    }
}

enum class StunServerStatus {
    UNCONFIGURED,
    PROBING,
    AVAILABLE,
    UNREACHABLE,
    TIMED_OUT
}

data class StunServerProbeResult(
    val serverUri: String,
    val status: StunServerStatus,
    val mappedPublicIp: String? = null,
    val mappedPublicPort: Int? = null,
    val ipVersion: IpVersion = IpVersion.UNKNOWN,
    val rttMs: Long? = null,
    val errorReason: String? = null,
    val probedAtMs: Long = System.currentTimeMillis()
)

data class StunDiscoverySummary(
    val overallStatus: StunServerStatus = StunServerStatus.UNCONFIGURED,
    val configuredServersCount: Int = 0,
    val reachableServersCount: Int = 0,
    val observedPublicIp: String? = null,
    val observedPublicPort: Int? = null,
    val ipVersion: IpVersion = IpVersion.UNKNOWN,
    val lastProbeAtMs: Long? = null,
    val publicIpChangedCount: Int = 0,
    val probeResults: List<StunServerProbeResult> = emptyList(),
    val natLimitationNote: String =
        "STUN reveals server-reflexive addresses only for cone NATs; symmetric NAT or strict CGNAT requires configured TURN relay fallback."
) {
    val formattedPublicEndpoint: String?
        get() = if (observedPublicIp != null && observedPublicPort != null) {
            if (ipVersion == IpVersion.IPV6) "[$observedPublicIp]:$observedPublicPort" else "$observedPublicIp:$observedPublicPort"
        } else null
}

enum class TurnRelayStatus {
    UNCONFIGURED,
    AVAILABLE,
    UNAVAILABLE_EXPIRED,
    UNREACHABLE,
    ALLOCATED,
    RELAYING,
    FAILED
}

data class RelayAllocationMetrics(
    val allocationId: String,
    val peerNodeId: String,
    val serverUri: String,
    val transport: TurnTransportProtocol,
    val allocatedAtMs: Long = System.currentTimeMillis(),
    val lastActivityAtMs: Long = System.currentTimeMillis(),
    val estimatedRttMs: Long? = null,
    val isActive: Boolean = true,
    val disconnectReason: String? = null
)

data class RelayFallbackState(
    val status: TurnRelayStatus = TurnRelayStatus.UNCONFIGURED,
    val configuredServersCount: Int = 0,
    val validServersCount: Int = 0,
    val activeAllocationsCount: Int = 0,
    val fallbackTriggeredCount: Long = 0L,
    val relayFailuresCount: Long = 0L,
    val activeAllocations: List<RelayAllocationMetrics> = emptyList(),
    val availabilityMessage: String = "Relay fallback unavailable (no TURN server configured)"
)

data class NetworkChangeEvent(
    val previousType: NetworkInterfaceType,
    val newType: NetworkInterfaceType,
    val localAddresses: List<String>,
    val reason: String,
    val requiresIceRestart: Boolean,
    val occurredAtMs: Long = System.currentTimeMillis()
)

data class PeerPathRecord(
    val peerNodeId: String,
    val connectionId: String,
    val transportPath: TransportPathType,
    val selectedCandidateType: IceCandidateType? = null,
    val candidatePairSummary: String? = null,
    val establishmentTimeMs: Long? = null,
    val isAuthenticatedEncrypted: Boolean = false,
    val connectedAtMs: Long = System.currentTimeMillis()
)

/**
 * Live connectivity diagnostics snapshot rendered by the Network Dashboard card.
 */
data class ConnectivityDiagnosticsSnapshot(
    val status: ConnectivityState = ConnectivityState.DISCOVERING,
    val totalDiscoveredPeers: Int = 0,
    val authenticatedConnectedPeers: Int = 0,
    val directConnectionsCount: Int = 0,
    val relayedConnectionsCount: Int = 0,
    val iceGatheringState: IceGatheringProgress = IceGatheringProgress.NEW,
    val iceConnectionState: IceConnectionStatus = IceConnectionStatus.NEW,
    val selectedCandidateType: IceCandidateType? = null,
    val selectedCandidatePairSummary: String? = null,
    val stunStatus: StunServerStatus = StunServerStatus.UNCONFIGURED,
    val stunServerCount: Int = 0,
    val observedPublicEndpoint: String? = null,
    val turnStatus: TurnRelayStatus = TurnRelayStatus.UNCONFIGURED,
    val turnServerCount: Int = 0,
    val turnAvailabilityMessage: String = "Relay fallback unavailable (no TURN server configured)",
    val lastConnectionEstablishmentMs: Long? = null,
    val currentNetworkType: NetworkInterfaceType = NetworkInterfaceType.NONE,
    val lastNetworkChangeAtMs: Long? = null,
    val lastNetworkChangeReason: String? = null,
    val failedAttemptsCount: Long = 0L,
    val activeNegotiationsCount: Int = 0,
    val rateLimitedNegotiationsCount: Long = 0L,
    val activeTransportPath: TransportPathType = TransportPathType.NONE,
    val peerPaths: List<PeerPathRecord> = emptyList(),
    val natLimitationNote: String =
        "STUN discovers public IP/port on cone NATs only. Symmetric NAT / strict CGNAT requires an externalized TURN relay.",
    val lastEventSummary: String? = null
)

/**
 * Code-level architecture assessment documenting how Stage 14 integrates with
 * Stages 5, 6, 7, and 13 without duplicating P2P, blockchain, or security logic.
 */
object ConnectivityArchitectureAssessment {
    const val STAGE5_ASSESSMENT =
        "Extends Socket-only PeerConnection into TransportChannel (SocketTransportChannel + BufferedStreamTransportChannel) so TcpPeerTransport LAN sockets remain first-priority and unmodified."
    const val STAGE6_7_ASSESSMENT =
        "Reuses PeerConnectionManager.authenticatedPeers, ReliableP2pMessagingService, and DistributedDiscoveryCoordinator registries; discovered/signaled peers still count as connected only post-authentication."
    const val STAGE13_ASSESSMENT =
        "All ICE Direct and TURN Relayed DataChannels carry raw bytes to PeerConnectionManager.connectOverChannel/handleIncomingChannel, enforcing the exact X25519+Ed25519 handshake, Chain ID check, ChaCha20-Poly1305 AEAD, replay window, and PeerTrustManager revocation."
    const val BLOCKCHAIN_SEPARATION =
        "Zero changes to Stage 8-12 consensus rules, BFT quorums, block formats, Merkle trees, or transaction validation."
}
