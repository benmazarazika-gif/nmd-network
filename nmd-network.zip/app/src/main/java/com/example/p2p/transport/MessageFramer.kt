package com.example.p2p.transport

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.IOException

/**
 * MessageFramer enforces the NMD Network Layer-1 framed transport protocol over raw TCP streams.
 *
 * Wire specification:
 * - Magic header: 4 bytes ASCII "NMDP" (0x4E, 0x4D, 0x44, 0x50)
 * - Frame type: 1 byte (see HandshakeModels.FrameType)
 * - Payload length: 4 bytes (Big-Endian integer)
 * - Payload: [Payload length] bytes (Max 65,536 bytes / 64 KB to defend against memory exhaustion)
 *
 * Thread-safety: Synchronizes write access per stream, and relies on standard blocking IO.
 */
object MessageFramer {

    val MAGIC_HEADER = byteArrayOf(0x4E, 0x4D, 0x44, 0x50) // "NMDP"
    const val MAX_PAYLOAD_SIZE = 64 * 1024 // 64 KB max frame limit
    const val HEADER_SIZE = 9 // 4 bytes magic + 1 byte type + 4 bytes length

    /**
     * Writes a framed packet to the given OutputStream.
     *
     * @param outputStream The network stream to write to.
     * @param frameType The single-byte frame type identifier.
     * @param payload The raw byte payload.
     * @throws IllegalArgumentException if payload exceeds MAX_PAYLOAD_SIZE.
     * @throws IOException on socket write failure.
     */
    @JvmOverloads
    @Throws(IOException::class)
    fun writeFrame(
        outputStream: OutputStream,
        frameType: Byte,
        payload: ByteArray,
        maxPayloadSize: Int = MAX_PAYLOAD_SIZE
    ) {
        require(payload.size <= maxPayloadSize) {
            "Payload size (${payload.size} bytes) exceeds maximum allowable limit of $maxPayloadSize bytes"
        }

        synchronized(outputStream) {
            val dataOut = DataOutputStream(outputStream)
            dataOut.write(MAGIC_HEADER)
            dataOut.writeByte(frameType.toInt())
            dataOut.writeInt(payload.size)
            if (payload.isNotEmpty()) {
                dataOut.write(payload)
            }
            dataOut.flush()
        }
    }

    /**
     * Reads a framed packet from the given InputStream.
     *
     * @param inputStream The network stream to read from.
     * @param maxPayloadSize Maximum permitted frame payload bytes enforced BEFORE memory allocation.
     * @return A Pair containing the frameType and the payload ByteArray, or null if stream is cleanly closed.
     * @throws IOException on socket error, corrupt frame structure, or oversized frame.
     */
    @JvmOverloads
    @Throws(IOException::class)
    fun readFrame(
        inputStream: InputStream,
        maxPayloadSize: Int = MAX_PAYLOAD_SIZE
    ): Pair<Byte, ByteArray>? {
        val dataIn = DataInputStream(inputStream)

        // Read magic header (4 bytes)
        val magic = ByteArray(4)
        val firstByte: Int
        try {
            firstByte = dataIn.read()
            if (firstByte == -1) return null // Clean EOF
            magic[0] = firstByte.toByte()
            dataIn.readFully(magic, 1, 3)
        } catch (_: java.io.EOFException) {
            return null
        }

        if (!magic.contentEquals(MAGIC_HEADER)) {
            val receivedHex = magic.joinToString("") { "%02X".format(it) }
            throw IOException("Invalid NMD frame magic header: expected 'NMDP' (4E4D4450), received $receivedHex")
        }

        // Read frame type (1 byte)
        val frameType = dataIn.readByte()

        // Read payload length (4 bytes Big-Endian)
        val payloadLength = dataIn.readInt()
        if (payloadLength < 0 || payloadLength > maxPayloadSize) {
            throw IOException(
                "Invalid frame payload length: $payloadLength bytes (must be between 0 and $maxPayloadSize)"
            )
        }

        // Read payload bytes
        val payload = ByteArray(payloadLength)
        if (payloadLength > 0) {
            dataIn.readFully(payload)
        }

        return Pair(frameType, payload)
    }
}
