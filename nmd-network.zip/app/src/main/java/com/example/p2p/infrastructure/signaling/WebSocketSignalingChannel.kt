package com.example.p2p.infrastructure.signaling

import com.example.crypto.NodeIdentityManager
import com.example.p2p.connectivity.signaling.SignalingChannel
import com.example.p2p.connectivity.signaling.SignalingEnvelope
import com.example.p2p.infrastructure.model.BootstrapEndpointConfig
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.infrastructure.model.SignalingEndpointConfig
import com.example.p2p.infrastructure.model.SignalingTransportStatus
import com.example.p2p.scalability.circuit.CircuitBreakerManager
import com.example.p2p.scalability.model.CircuitBreakerTargetType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.Closeable
import java.net.URI
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.SSLHandshakeException

/**
 * Production-capable WebSocket (WSS/WS-dev) implementation of Stage 14's [SignalingChannel].
 *
 * Security Model:
 * - TLS (`wss://` + optional certificate pinning) protects transport confidentiality/integrity
 *   between this device and the signaling rendezvous relay.
 * - End-to-end peer identity authentication & replay defense are NEVER delegated to the server:
 *   every routed [SignalingEnvelope] carries the Stage 14 Ed25519 signature verified locally by [PeerSignalingService].
 * - Enforces bounded offline queue with message TTL expiration, message size caps, heartbeat pings,
 *   and exponential backoff + jitter reconnection across failover signaling endpoints.
 */
class WebSocketSignalingChannel(
    private val identityManager: NodeIdentityManager,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val maxEnvelopeBytes: Int = 16_384,
    private val maxQueuedMessages: Int = 32,
    private val offlineQueueTtlMs: Long = 60_000L,
    private val heartbeatIntervalMs: Long = 20_000L,
    private val maxReconnectAttempts: Int = 8,
    private val clockMs: () -> Long = { System.currentTimeMillis() },
    private val baseOkHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
) : SignalingChannel, Closeable {

    override val channelName: String = "WebSocketSignalingChannel"

    private data class QueuedOutbound(
        val envelope: SignalingEnvelope,
        val jsonFrame: String,
        val expiresAtMs: Long
    )

    private val _incomingEnvelopes = MutableSharedFlow<SignalingEnvelope>(extraBufferCapacity = 128)
    override val incomingEnvelopes: SharedFlow<SignalingEnvelope> = _incomingEnvelopes.asSharedFlow()

    private val _status = MutableStateFlow(SignalingTransportStatus.DISCONNECTED)
    val status: StateFlow<SignalingTransportStatus> = _status.asStateFlow()

    private val _activeEndpointUrl = MutableStateFlow<String?>(null)
    val activeEndpointUrl: StateFlow<String?> = _activeEndpointUrl.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val queueLock = Any()
    private val outboundQueue = ArrayDeque<QueuedOutbound>()
    private val totalSent = AtomicLong(0L)
    private val totalReceived = AtomicLong(0L)
    private val totalExpired = AtomicLong(0L)
    private val reconnectAttempts = AtomicInteger(0)
    private val closed = AtomicBoolean(false)

    @Volatile
    var circuitBreakerManager: CircuitBreakerManager? = null

    @Volatile
    private var activeProfile: NmdNetworkProfile = NmdNetworkProfile.DEVELOPMENT
    @Volatile
    private var activeChainId: String = ""
    @Volatile
    private var allowLocalTestOverride: Boolean = false
    @Volatile
    private var configuredEndpoints: List<SignalingEndpointConfig> = emptyList()
    @Volatile
    private var currentEndpointIndex: Int = 0
    @Volatile
    private var currentWebSocket: WebSocket? = null
    @Volatile
    private var reconnectJob: Job? = null

    fun configureAndConnect(
        profile: NmdNetworkProfile,
        chainId: String,
        endpoints: List<SignalingEndpointConfig>,
        allowLocalTestOverride: Boolean = false
    ): Result<Unit> {
        this.activeProfile = profile
        this.activeChainId = chainId
        this.allowLocalTestOverride = allowLocalTestOverride

        val valid = endpoints
            .filter { it.isEnabled }
            .sortedBy { it.priority }

        for (ep in valid) {
            val err = ep.validateForProfile(profile, allowLocalTestOverride)
            if (err != null) {
                _lastError.value = err
                _status.value = SignalingTransportStatus.FAILED
                return Result.failure(IllegalArgumentException(err))
            }
        }

        this.configuredEndpoints = valid
        this.currentEndpointIndex = 0
        reconnectAttempts.set(0)
        reconnectJob?.cancel()
        closeActiveSocketOnly()

        if (valid.isEmpty()) {
            _activeEndpointUrl.value = null
            _status.value = SignalingTransportStatus.DISCONNECTED
            return Result.success(Unit)
        }

        connectCurrentEndpoint()
        return Result.success(Unit)
    }

    fun triggerReconnect(reason: String = "Manual reconnect") {
        if (closed.get() || configuredEndpoints.isEmpty()) return
        _lastError.value = reason
        reconnectJob?.cancel()
        closeActiveSocketOnly()
        reconnectAttempts.set(0)
        connectCurrentEndpoint()
    }

    override suspend fun sendEnvelope(envelope: SignalingEnvelope): Result<Unit> {
        if (closed.get()) {
            return Result.failure(IllegalStateException("Signaling channel closed"))
        }
        if (envelope.chainId != activeChainId) {
            return Result.failure(IllegalArgumentException("Signaling envelope Chain ID mismatch"))
        }
        val frameJson = JSONObject().apply {
            put("type", "ENVELOPE")
            put("envelope", JSONObject(envelope.toJson()))
        }.toString()

        if (frameJson.toByteArray(Charsets.UTF_8).size > maxEnvelopeBytes) {
            return Result.failure(IllegalArgumentException("Signaling envelope exceeds $maxEnvelopeBytes byte cap"))
        }

        val ws = currentWebSocket
        if (ws != null && _status.value == SignalingTransportStatus.AUTHENTICATED) {
            if (ws.send(frameJson)) {
                totalSent.incrementAndGet()
                return Result.success(Unit)
            }
        }

        // Queue while reconnecting with bounded size and explicit expiration TTL
        val now = clockMs()
        synchronized(queueLock) {
            pruneExpiredLocked(now)
            if (outboundQueue.size >= maxQueuedMessages) {
                outboundQueue.removeFirst()
            }
            outboundQueue.addLast(
                QueuedOutbound(
                    envelope = envelope,
                    jsonFrame = frameJson,
                    expiresAtMs = now + offlineQueueTtlMs
                )
            )
        }
        return Result.success(Unit)
    }

    fun expiredQueueCount(): Long = totalExpired.get()
    fun sentCount(): Long = totalSent.get()
    fun receivedCount(): Long = totalReceived.get()

    private fun connectCurrentEndpoint() {
        if (closed.get()) return
        val list = configuredEndpoints
        if (list.isEmpty()) return
        val ep = selectNextPermittedEndpoint(list) ?: list[currentEndpointIndex % list.size]

        val validationErr = ep.validateForProfile(activeProfile, allowLocalTestOverride)
        if (validationErr != null) {
            _lastError.value = validationErr
            _status.value = SignalingTransportStatus.FAILED
            return
        }

        _activeEndpointUrl.value = ep.url
        _status.value = SignalingTransportStatus.CONNECTING

        val client = buildOkHttpClient(ep)
        val request = Request.Builder().url(ep.url).build()
        val socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (closed.get()) {
                    webSocket.close(1000, "Closed")
                    return
                }
                reconnectAttempts.set(0)
                _status.value = SignalingTransportStatus.CONNECTED
                _lastError.value = null

                if (identityManager.getActiveIdentity() == null) {
                    _status.value = SignalingTransportStatus.FAILED
                    _lastError.value = "Node identity unavailable for signaling registration"
                    webSocket.close(1008, "No Node ID")
                    return
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.toByteArray(Charsets.UTF_8).size > maxEnvelopeBytes * 2) {
                    _lastError.value = "Rejected oversized incoming signaling frame"
                    return
                }
                handleIncomingServerText(webSocket, text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                if (code != 1000 && reason.isNotBlank()) {
                    _lastError.value = "Closed ($code): $reason"
                }
                webSocket.close(code, reason)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (currentWebSocket === webSocket) {
                    currentWebSocket = null
                }
                if (code != 1000 && reason.isNotBlank() && _lastError.value == null) {
                    _lastError.value = "Closed ($code): $reason"
                }
                if (!closed.get() && _status.value != SignalingTransportStatus.TLS_ERROR) {
                    _status.value = SignalingTransportStatus.DISCONNECTED
                    if (configuredEndpoints.size > 1) {
                        currentEndpointIndex = (currentEndpointIndex + 1) % configuredEndpoints.size
                    }
                    scheduleReconnect()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (currentWebSocket === webSocket) {
                    currentWebSocket = null
                }
                val isTls = t is SSLHandshakeException || t.cause is SSLHandshakeException
                val errMsg = t.message ?: "WebSocket failure"
                _lastError.value = errMsg
                circuitBreakerManager?.recordFailure(CircuitBreakerTargetType.SIGNALING, ep.url, errMsg)
                _status.value = if (isTls) SignalingTransportStatus.TLS_ERROR else SignalingTransportStatus.RECONNECTING
                if (!isTls && !closed.get()) {
                    currentEndpointIndex = (currentEndpointIndex + 1) % configuredEndpoints.size.coerceAtLeast(1)
                    scheduleReconnect()
                }
            }
        })
        currentWebSocket = socket
    }

    private fun selectNextPermittedEndpoint(list: List<SignalingEndpointConfig>): SignalingEndpointConfig? {
        val cb = circuitBreakerManager ?: return list[currentEndpointIndex % list.size]
        for (offset in list.indices) {
            val idx = (currentEndpointIndex + offset) % list.size
            val candidate = list[idx]
            if (cb.allowRequest(CircuitBreakerTargetType.SIGNALING, candidate.url)) {
                currentEndpointIndex = idx
                return candidate
            }
        }
        return null
    }

    private fun handleIncomingServerText(webSocket: WebSocket, text: String) {
        val obj = try {
            JSONObject(text)
        } catch (_: Exception) {
            return
        }
        when (obj.optString("type", "").uppercase()) {
            "CHALLENGE" -> {
                val challengeChain = obj.optString("chain_id", activeChainId)
                if (challengeChain != activeChainId) {
                    _lastError.value = "Signaling challenge Chain ID mismatch"
                    _status.value = SignalingTransportStatus.FAILED
                    webSocket.close(1008, "Chain ID mismatch")
                    return
                }
                val nonce = obj.optString("nonce", "")
                val identity = identityManager.getActiveIdentity()
                if (identity == null || nonce.isBlank()) {
                    _lastError.value = "Unable to authenticate signaling challenge"
                    _status.value = SignalingTransportStatus.FAILED
                    webSocket.close(1008, "Missing identity or challenge nonce")
                    return
                }
                val ts = clockMs()
                val canonical = "NMD-SIG-AUTH|${identity.nodeId}|$activeChainId|$nonce|$ts"
                val sigBytes = runCatching {
                    identityManager.repository.signRawData(canonical.toByteArray(Charsets.UTF_8))
                }.getOrNull()
                if (sigBytes == null) {
                    _lastError.value = "Failed to sign signaling challenge"
                    _status.value = SignalingTransportStatus.FAILED
                    webSocket.close(1008, "Signing failure")
                    return
                }
                val sigHex = identityManager.repository.cryptoProvider.toHex(sigBytes)
                val regFrame = JSONObject().apply {
                    put("type", "REGISTER")
                    put("node_id", identity.nodeId)
                    put("public_key_hex", identity.publicKeyHex)
                    put("chain_id", activeChainId)
                    put("nonce", nonce)
                    put("timestamp_ms", ts)
                    put("signature_hex", sigHex)
                }.toString()
                webSocket.send(regFrame)
            }
            "REGISTERED" -> {
                val ackChain = obj.optString("chain_id", "")
                if (ackChain != activeChainId) {
                    _lastError.value = "Signaling server Chain ID mismatch"
                    _status.value = SignalingTransportStatus.FAILED
                    closeActiveSocketOnly()
                    return
                }
                _activeEndpointUrl.value?.let { url ->
                    circuitBreakerManager?.recordSuccess(CircuitBreakerTargetType.SIGNALING, url)
                }
                _status.value = SignalingTransportStatus.AUTHENTICATED
                flushOutboundQueue()
            }
            "ENVELOPE" -> {
                val envJson = obj.optJSONObject("envelope") ?: return
                val env = SignalingEnvelope.fromJson(envJson.toString()) ?: return
                totalReceived.incrementAndGet()
                if (!_incomingEnvelopes.tryEmit(env)) {
                    scope.launch(ioDispatcher) {
                        _incomingEnvelopes.emit(env)
                    }
                }
            }
            "ERROR" -> {
                val code = obj.optString("code", "")
                _lastError.value = obj.optString("message", code.ifBlank { "Signaling server error" })
                if (code == "AUTH_FAILED" || code == "CHAIN_MISMATCH") {
                    _status.value = SignalingTransportStatus.FAILED
                }
            }
        }
    }

    private fun flushOutboundQueue() {
        val ws = currentWebSocket ?: return
        val now = clockMs()
        val toSend = mutableListOf<String>()
        synchronized(queueLock) {
            pruneExpiredLocked(now)
            while (outboundQueue.isNotEmpty()) {
                toSend.add(outboundQueue.removeFirst().jsonFrame)
            }
        }
        toSend.forEach { frame ->
            if (ws.send(frame)) {
                totalSent.incrementAndGet()
            }
        }
    }

    private fun pruneExpiredLocked(nowMs: Long) {
        while (outboundQueue.isNotEmpty() && outboundQueue.first().expiresAtMs <= nowMs) {
            outboundQueue.removeFirst()
            totalExpired.incrementAndGet()
        }
    }

    private fun scheduleReconnect() {
        if (closed.get() || configuredEndpoints.isEmpty()) return
        val attempt = reconnectAttempts.incrementAndGet()
        if (attempt > maxReconnectAttempts) {
            _status.value = SignalingTransportStatus.FAILED
            _lastError.value = "Signaling reconnect attempts exhausted ($maxReconnectAttempts)"
            return
        }
        reconnectJob?.cancel()
        reconnectJob = scope.launch(ioDispatcher) {
            val backoff = BootstrapEndpointConfig.computeBackoffWithJitterMs(attempt)
            _status.value = SignalingTransportStatus.RECONNECTING
            delay(backoff.coerceAtLeast(250L))
            if (isActive && !closed.get()) {
                connectCurrentEndpoint()
            }
        }
    }

    private fun buildOkHttpClient(ep: SignalingEndpointConfig): OkHttpClient {
        val builder = baseOkHttpClient.newBuilder()
            .pingInterval(heartbeatIntervalMs.coerceAtLeast(2_000L), TimeUnit.MILLISECONDS)
        val pin = ep.pinnedTlsSha256
        if (ep.url.startsWith("wss://", ignoreCase = true) && !pin.isNullOrBlank()) {
            val host = URI(ep.url).host
            if (!host.isNullOrBlank()) {
                builder.certificatePinner(CertificatePinner.Builder().add(host, pin).build())
            }
        }
        return builder.build()
    }

    private fun closeActiveSocketOnly() {
        val ws = currentWebSocket
        currentWebSocket = null
        runCatching { ws?.close(1000, "Reconfiguring") }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        reconnectJob?.cancel()
        reconnectJob = null
        closeActiveSocketOnly()
        _status.value = SignalingTransportStatus.DISCONNECTED
    }
}
