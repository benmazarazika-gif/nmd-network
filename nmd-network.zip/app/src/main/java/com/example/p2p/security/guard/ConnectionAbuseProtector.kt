package com.example.p2p.security.guard

import com.example.p2p.security.model.TransportSecurityConfig
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

sealed class GuardAdmissionResult {
    object Allowed : GuardAdmissionResult()
    data class Rejected(val reason: String, val isRateLimited: Boolean = true) : GuardAdmissionResult()
}

/**
 * Enforces mobile-friendly connection flooding, unauthenticated handshake bounds,
 * per-peer message rate limits, and repeated auth-failure cooldowns.
 */
class ConnectionAbuseProtector(
    private val config: TransportSecurityConfig = TransportSecurityConfig()
) {
    companion object {
        private const val MAX_TRACKED_KEYS = 256
    }

    private val lock = Any()
    private val pendingQueueCount = AtomicInteger(0)
    private val activeUnauthenticatedCount = AtomicInteger(0)

    private val connectionAttemptsByHost = ConcurrentHashMap<String, ArrayDeque<Long>>()
    private val messagesByPeerId = ConcurrentHashMap<String, ArrayDeque<Long>>()
    private val authFailureCountByKey = ConcurrentHashMap<String, Int>()
    private val cooldownUntilByKey = ConcurrentHashMap<String, Long>()

    fun currentPendingHandshakesCount(): Int =
        pendingQueueCount.get() + activeUnauthenticatedCount.get()

    fun currentRateLimitedKeysCount(nowMs: Long = System.currentTimeMillis()): Int = synchronized(lock) {
        pruneExpiredCooldowns(nowMs)
        cooldownUntilByKey.count { it.value > nowMs }
    }

    fun isInCooldown(key: String, nowMs: Long = System.currentTimeMillis()): Boolean = synchronized(lock) {
        val until = cooldownUntilByKey[key] ?: return false
        if (nowMs >= until) {
            cooldownUntilByKey.remove(key)
            return false
        }
        true
    }

    fun tryAcquirePendingHandshakeSlot(
        sourceHost: String,
        nowMs: Long = System.currentTimeMillis()
    ): GuardAdmissionResult = synchronized(lock) {
        pruneExpiredCooldowns(nowMs)

        val cooldownUntil = cooldownUntilByKey[sourceHost]
        if (cooldownUntil != null && nowMs < cooldownUntil) {
            val remSec = ((cooldownUntil - nowMs) / 1000L).coerceAtLeast(1L)
            return GuardAdmissionResult.Rejected(
                "Source $sourceHost is in authentication failure cooldown (${remSec}s remaining)"
            )
        }

        // Check per-host connection rate limit
        val attempts = connectionAttemptsByHost.getOrPut(sourceHost) { ArrayDeque() }
        val cutoff = nowMs - config.connectionRateWindowMs
        while (attempts.isNotEmpty() && attempts.first() < cutoff) {
            attempts.removeFirst()
        }
        if (attempts.size >= config.maxConnectionAttemptsPerWindow) {
            cooldownUntilByKey[sourceHost] = nowMs + config.peerCooldownMs
            return GuardAdmissionResult.Rejected(
                "Connection flood rate limit exceeded for $sourceHost (${config.maxConnectionAttemptsPerWindow} attempts/${config.connectionRateWindowMs / 1000L}s)"
            )
        }

        // Enforce bounded pending handshake queue & concurrent unauthenticated limit
        if (pendingQueueCount.get() >= config.maxPendingHandshakeQueue) {
            return GuardAdmissionResult.Rejected(
                "Pending handshake queue full (${config.maxPendingHandshakeQueue})",
                isRateLimited = true
            )
        }
        if (activeUnauthenticatedCount.get() >= config.maxConcurrentUnauthenticatedConnections) {
            return GuardAdmissionResult.Rejected(
                "Maximum concurrent unauthenticated connections reached (${config.maxConcurrentUnauthenticatedConnections})",
                isRateLimited = true
            )
        }

        if (connectionAttemptsByHost.size > MAX_TRACKED_KEYS) {
            connectionAttemptsByHost.entries.take(32).forEach { connectionAttemptsByHost.remove(it.key) }
        }

        attempts.addLast(nowMs)
        activeUnauthenticatedCount.incrementAndGet()
        return GuardAdmissionResult.Allowed
    }

    fun releaseUnauthenticatedSlot() {
        val current = activeUnauthenticatedCount.get()
        if (current > 0) {
            activeUnauthenticatedCount.decrementAndGet()
        }
    }

    fun tryEnqueuePending(): Boolean {
        while (true) {
            val current = pendingQueueCount.get()
            if (current >= config.maxPendingHandshakeQueue) return false
            if (pendingQueueCount.compareAndSet(current, current + 1)) return true
        }
    }

    fun releasePendingQueueSlot() {
        val current = pendingQueueCount.get()
        if (current > 0) pendingQueueCount.decrementAndGet()
    }

    fun checkOutboundAllowed(
        hostOrPeerKey: String,
        nowMs: Long = System.currentTimeMillis()
    ): GuardAdmissionResult = synchronized(lock) {
        pruneExpiredCooldowns(nowMs)
        val cooldownUntil = cooldownUntilByKey[hostOrPeerKey]
        if (cooldownUntil != null && nowMs < cooldownUntil) {
            return GuardAdmissionResult.Rejected("Peer $hostOrPeerKey temporarily throttled by security cooldown")
        }
        GuardAdmissionResult.Allowed
    }

    fun recordAuthFailure(
        hostOrPeerKey: String,
        nowMs: Long = System.currentTimeMillis()
    ): Boolean = synchronized(lock) {
        val nextCount = (authFailureCountByKey[hostOrPeerKey] ?: 0) + 1
        authFailureCountByKey[hostOrPeerKey] = nextCount
        if (nextCount >= config.maxAuthFailuresBeforeCooldown) {
            cooldownUntilByKey[hostOrPeerKey] = nowMs + config.peerCooldownMs
            true
        } else {
            false
        }
    }

    fun recordAuthSuccess(hostOrPeerKey: String) = synchronized(lock) {
        authFailureCountByKey.remove(hostOrPeerKey)
        cooldownUntilByKey.remove(hostOrPeerKey)
    }

    fun checkPeerMessageRate(
        peerId: String,
        nowMs: Long = System.currentTimeMillis()
    ): GuardAdmissionResult = synchronized(lock) {
        val window = messagesByPeerId.getOrPut(peerId) { ArrayDeque() }
        val cutoff = nowMs - config.messageRateWindowMs
        while (window.isNotEmpty() && window.first() < cutoff) {
            window.removeFirst()
        }
        if (window.size >= config.maxMessagesPerPeerPerWindow) {
            cooldownUntilByKey[peerId] = nowMs + config.peerCooldownMs
            return GuardAdmissionResult.Rejected(
                "Message rate limit exceeded by peer $peerId (${config.maxMessagesPerPeerPerWindow} msgs/${config.messageRateWindowMs / 1000L}s)"
            )
        }
        if (messagesByPeerId.size > MAX_TRACKED_KEYS) {
            messagesByPeerId.entries.take(32).forEach { messagesByPeerId.remove(it.key) }
        }
        window.addLast(nowMs)
        return GuardAdmissionResult.Allowed
    }

    fun clear() = synchronized(lock) {
        connectionAttemptsByHost.clear()
        messagesByPeerId.clear()
        authFailureCountByKey.clear()
        cooldownUntilByKey.clear()
        pendingQueueCount.set(0)
        activeUnauthenticatedCount.set(0)
    }

    private fun pruneExpiredCooldowns(nowMs: Long) {
        cooldownUntilByKey.entries.removeIf { it.value <= nowMs }
    }
}
