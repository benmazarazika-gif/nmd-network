package com.example.p2p.scalability.circuit

import com.example.p2p.scalability.model.CircuitBreakerConfig
import com.example.p2p.scalability.model.CircuitBreakerSnapshot
import com.example.p2p.scalability.model.CircuitBreakerState
import com.example.p2p.scalability.model.CircuitBreakerTargetType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * Thread-safe Circuit Breaker Manager isolating failures across Bootstrap endpoints,
 * Signaling endpoints, Peer connections, STUN servers, and TURN relays.
 *
 * State transitions:
 * - CLOSED -> OPEN when consecutive failures >= failureThreshold
 * - OPEN -> HALF_OPEN after recoveryWindowMs elapses and a probe slot is acquired
 * - HALF_OPEN -> CLOSED when probe(s) succeed
 * - HALF_OPEN -> OPEN immediately if probe fails
 */
class CircuitBreakerManager(
    private val defaultConfigs: Map<CircuitBreakerTargetType, CircuitBreakerConfig> = DEFAULT_CONFIGS,
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    companion object {
        val DEFAULT_CONFIGS: Map<CircuitBreakerTargetType, CircuitBreakerConfig> = mapOf(
            CircuitBreakerTargetType.BOOTSTRAP to CircuitBreakerConfig(
                failureThreshold = 3,
                recoveryWindowMs = 20_000L,
                maxHalfOpenProbes = 1
            ),
            CircuitBreakerTargetType.SIGNALING to CircuitBreakerConfig(
                failureThreshold = 3,
                recoveryWindowMs = 15_000L,
                maxHalfOpenProbes = 1
            ),
            CircuitBreakerTargetType.PEER to CircuitBreakerConfig(
                failureThreshold = 3,
                recoveryWindowMs = 25_000L,
                maxHalfOpenProbes = 1
            ),
            CircuitBreakerTargetType.STUN to CircuitBreakerConfig(
                failureThreshold = 3,
                recoveryWindowMs = 30_000L,
                maxHalfOpenProbes = 1
            ),
            CircuitBreakerTargetType.TURN to CircuitBreakerConfig(
                failureThreshold = 2,
                recoveryWindowMs = 30_000L,
                maxHalfOpenProbes = 1
            )
        )
    }

    private data class MutableBreaker(
        val key: String,
        val targetId: String,
        val targetType: CircuitBreakerTargetType,
        val config: CircuitBreakerConfig,
        var state: CircuitBreakerState = CircuitBreakerState.CLOSED,
        var consecutiveFailures: Int = 0,
        var halfOpenSuccesses: Int = 0,
        var activeHalfOpenProbes: Int = 0,
        var openedAtMs: Long = 0L,
        var nextRetryAllowedMs: Long = 0L,
        var totalTrips: Long = 0L,
        var lastFailureReason: String? = null
    ) {
        fun toSnapshot() = CircuitBreakerSnapshot(
            targetId = targetId,
            targetType = targetType,
            state = state,
            consecutiveFailures = consecutiveFailures,
            halfOpenSuccesses = halfOpenSuccesses,
            activeHalfOpenProbes = activeHalfOpenProbes,
            openedAtMs = openedAtMs,
            nextRetryAllowedMs = nextRetryAllowedMs,
            totalTrips = totalTrips,
            lastFailureReason = lastFailureReason
        )
    }

    private val breakers = ConcurrentHashMap<String, MutableBreaker>()
    private val customConfigs = ConcurrentHashMap<String, CircuitBreakerConfig>()

    private val _snapshots = MutableStateFlow<List<CircuitBreakerSnapshot>>(emptyList())
    val snapshots: StateFlow<List<CircuitBreakerSnapshot>> = _snapshots.asStateFlow()

    fun configureTarget(
        targetType: CircuitBreakerTargetType,
        targetId: String,
        config: CircuitBreakerConfig
    ) {
        val k = keyFor(targetType, targetId)
        customConfigs[k] = config
        breakers.computeIfPresent(k) { _, old ->
            old.copy(config = config)
        }
        publishSnapshots()
    }

    /**
     * Checks whether a call to [targetId] is currently permitted.
     * Automatically transitions OPEN -> HALF_OPEN once recoveryWindowMs has elapsed,
     * allowing up to [CircuitBreakerConfig.maxHalfOpenProbes] concurrent probe(s).
     */
    fun allowRequest(
        targetType: CircuitBreakerTargetType,
        targetId: String
    ): Boolean {
        val breaker = getOrCreateBreaker(targetType, targetId)
        val now = clockMs()
        val allowed = synchronized(breaker) {
            when (breaker.state) {
                CircuitBreakerState.CLOSED -> true
                CircuitBreakerState.OPEN -> {
                    if (now >= breaker.nextRetryAllowedMs) {
                        breaker.state = CircuitBreakerState.HALF_OPEN
                        breaker.halfOpenSuccesses = 0
                        breaker.activeHalfOpenProbes = 1
                        true
                    } else {
                        false
                    }
                }
                CircuitBreakerState.HALF_OPEN -> {
                    if (breaker.activeHalfOpenProbes < breaker.config.maxHalfOpenProbes) {
                        breaker.activeHalfOpenProbes++
                        true
                    } else {
                        false
                    }
                }
            }
        }
        publishSnapshots()
        return allowed
    }

    fun recordSuccess(
        targetType: CircuitBreakerTargetType,
        targetId: String
    ) {
        val breaker = getOrCreateBreaker(targetType, targetId)
        synchronized(breaker) {
            when (breaker.state) {
                CircuitBreakerState.CLOSED -> {
                    breaker.consecutiveFailures = 0
                    breaker.lastFailureReason = null
                }
                CircuitBreakerState.HALF_OPEN -> {
                    breaker.activeHalfOpenProbes = (breaker.activeHalfOpenProbes - 1).coerceAtLeast(0)
                    breaker.halfOpenSuccesses++
                    if (breaker.halfOpenSuccesses >= breaker.config.successThresholdToClose) {
                        breaker.state = CircuitBreakerState.CLOSED
                        breaker.consecutiveFailures = 0
                        breaker.halfOpenSuccesses = 0
                        breaker.openedAtMs = 0L
                        breaker.nextRetryAllowedMs = 0L
                        breaker.lastFailureReason = null
                    }
                }
                CircuitBreakerState.OPEN -> {
                    // Explicit external recovery success also closes breaker safely
                    breaker.state = CircuitBreakerState.CLOSED
                    breaker.consecutiveFailures = 0
                    breaker.halfOpenSuccesses = 0
                    breaker.activeHalfOpenProbes = 0
                    breaker.openedAtMs = 0L
                    breaker.nextRetryAllowedMs = 0L
                    breaker.lastFailureReason = null
                }
            }
        }
        publishSnapshots()
    }

    fun recordFailure(
        targetType: CircuitBreakerTargetType,
        targetId: String,
        reason: String? = null
    ): CircuitBreakerSnapshot {
        val breaker = getOrCreateBreaker(targetType, targetId)
        val now = clockMs()
        val snap = synchronized(breaker) {
            breaker.lastFailureReason = reason ?: breaker.lastFailureReason
            when (breaker.state) {
                CircuitBreakerState.CLOSED -> {
                    breaker.consecutiveFailures++
                    if (breaker.consecutiveFailures >= breaker.config.failureThreshold) {
                        breaker.state = CircuitBreakerState.OPEN
                        breaker.openedAtMs = now
                        breaker.nextRetryAllowedMs = now + breaker.config.recoveryWindowMs
                        breaker.totalTrips++
                        breaker.activeHalfOpenProbes = 0
                        breaker.halfOpenSuccesses = 0
                    }
                }
                CircuitBreakerState.HALF_OPEN -> {
                    breaker.activeHalfOpenProbes = (breaker.activeHalfOpenProbes - 1).coerceAtLeast(0)
                    breaker.state = CircuitBreakerState.OPEN
                    breaker.openedAtMs = now
                    breaker.nextRetryAllowedMs = now + breaker.config.recoveryWindowMs
                    breaker.totalTrips++
                    breaker.consecutiveFailures = breaker.config.failureThreshold
                    breaker.halfOpenSuccesses = 0
                }
                CircuitBreakerState.OPEN -> {
                    breaker.consecutiveFailures++
                    breaker.nextRetryAllowedMs = maxOf(breaker.nextRetryAllowedMs, now + breaker.config.recoveryWindowMs)
                }
            }
            breaker.toSnapshot()
        }
        publishSnapshots()
        return snap
    }

    fun getState(targetType: CircuitBreakerTargetType, targetId: String): CircuitBreakerSnapshot {
        val breaker = getOrCreateBreaker(targetType, targetId)
        val now = clockMs()
        val snap = synchronized(breaker) {
            if (breaker.state == CircuitBreakerState.OPEN && now >= breaker.nextRetryAllowedMs) {
                breaker.state = CircuitBreakerState.HALF_OPEN
                breaker.halfOpenSuccesses = 0
                breaker.activeHalfOpenProbes = 0
            }
            breaker.toSnapshot()
        }
        return snap
    }

    fun resetBreaker(targetType: CircuitBreakerTargetType, targetId: String) {
        val k = keyFor(targetType, targetId)
        breakers[k]?.let { breaker ->
            synchronized(breaker) {
                breaker.state = CircuitBreakerState.CLOSED
                breaker.consecutiveFailures = 0
                breaker.halfOpenSuccesses = 0
                breaker.activeHalfOpenProbes = 0
                breaker.openedAtMs = 0L
                breaker.nextRetryAllowedMs = 0L
                breaker.lastFailureReason = null
            }
        }
        publishSnapshots()
    }

    fun resetAllBreakers() {
        breakers.values.forEach { breaker ->
            synchronized(breaker) {
                breaker.state = CircuitBreakerState.CLOSED
                breaker.consecutiveFailures = 0
                breaker.halfOpenSuccesses = 0
                breaker.activeHalfOpenProbes = 0
                breaker.openedAtMs = 0L
                breaker.nextRetryAllowedMs = 0L
                breaker.lastFailureReason = null
            }
        }
        publishSnapshots()
    }

    fun openBreakers(): List<CircuitBreakerSnapshot> =
        _snapshots.value.filter { it.state != CircuitBreakerState.CLOSED }

    private fun getOrCreateBreaker(
        targetType: CircuitBreakerTargetType,
        targetId: String
    ): MutableBreaker {
        val k = keyFor(targetType, targetId)
        return breakers.computeIfAbsent(k) {
            val cfg = customConfigs[k] ?: defaultConfigs[targetType] ?: CircuitBreakerConfig()
            MutableBreaker(
                key = k,
                targetId = targetId,
                targetType = targetType,
                config = cfg
            )
        }
    }

    private fun keyFor(targetType: CircuitBreakerTargetType, targetId: String): String =
        "${targetType.name}:$targetId"

    private fun publishSnapshots() {
        val now = clockMs()
        _snapshots.value = breakers.values.map { breaker ->
            synchronized(breaker) {
                if (breaker.state == CircuitBreakerState.OPEN && now >= breaker.nextRetryAllowedMs) {
                    breaker.state = CircuitBreakerState.HALF_OPEN
                    breaker.halfOpenSuccesses = 0
                    breaker.activeHalfOpenProbes = 0
                }
                breaker.toSnapshot()
            }
        }.sortedWith(compareBy({ it.targetType.name }, { it.targetId }))
    }
}
