package com.example.p2p.handshake

import android.content.Context
import android.content.SharedPreferences
import com.example.crypto.provider.CryptographicProvider
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * HandshakeChallengeReplayCache provides per-instance and persistent replay protection
 * for peer handshake challenges across application restarts and across multiple service instances.
 *
 * Security Properties:
 * 1. Process-wide Singleton Cache: All default service instances share the same in-memory and persistent record,
 *    preventing multiple instances of PeerHandshakeService from bypassing challenge replay protection.
 * 2. Privacy & Efficiency: Stores SHA-256 hashes of challenges rather than unnecessary raw challenge strings.
 * 3. Atomic Multi-Threaded Registration: Concurrent attempts with the identical challenge cannot both succeed.
 * 4. Safe Non-Eviction Saturated Capacity: Rejects new handshakes upon capacity saturation rather than
 *    silently evicting unexpired active challenges.
 * 5. Persistent Across Process Restarts: Backed by SharedPreferences so that captured challenges from a
 *    previous run cannot be replayed after the app restarts within their 60-second freshness window.
 * 6. Dual Timestamping: In-memory expiration uses monotonic System.nanoTime() while running;
 *    persistent expiry uses wall-clock epoch ms across restarts with strict freshness bounding.
 */
class HandshakeChallengeReplayCache(
    context: Context? = null,
    private val preferencesName: String = DEFAULT_PREFS_NAME,
    private val cryptoProvider: CryptographicProvider,
    private val maxCapacity: Int = DEFAULT_MAX_CAPACITY
) {
    companion object {
        const val DEFAULT_PREFS_NAME = "nmd_handshake_challenge_replay_cache"
        const val DEFAULT_MAX_CAPACITY = 10_000
        const val FRESHNESS_WINDOW_MS = 60_000L // 60 seconds

        // Global default cache shared across all default instances in the process
        private val globalSeenChallengeHashes = ConcurrentHashMap<String, Long>()
        private val globalLock = Any()

        fun clearGlobalCacheForTest() {
            synchronized(globalLock) {
                globalSeenChallengeHashes.clear()
            }
        }
    }

    private val isCustomInstance = preferencesName != DEFAULT_PREFS_NAME || maxCapacity != DEFAULT_MAX_CAPACITY

    // If custom instance (e.g. for bounded capacity test), use its own in-memory map; otherwise share global
    private val seenChallengeHashes = if (isCustomInstance) {
        ConcurrentHashMap<String, Long>()
    } else {
        globalSeenChallengeHashes
    }

    private val instanceLock = if (isCustomInstance) Any() else globalLock

    private val prefs: SharedPreferences? = context?.applicationContext?.getSharedPreferences(
        preferencesName,
        Context.MODE_PRIVATE
    )

    init {
        // Load persistent unexpired challenge hashes from SharedPreferences upon process start
        prefs?.let { sp ->
            synchronized(instanceLock) {
                val nowEpoch = System.currentTimeMillis()
                val nowNano = System.nanoTime()
                val expiredKeys = mutableListOf<String>()

                sp.all.forEach { (key, value) ->
                    if (value is Long) {
                        val epochExpiry = value
                        if (epochExpiry > nowEpoch && (epochExpiry - nowEpoch) <= FRESHNESS_WINDOW_MS) {
                            val remainingMs = epochExpiry - nowEpoch
                            val monoExpiry = nowNano + (remainingMs * 1_000_000L)
                            seenChallengeHashes.putIfAbsent(key, monoExpiry)
                        } else {
                            expiredKeys.add(key)
                        }
                    }
                }

                if (expiredKeys.isNotEmpty()) {
                    val editor = sp.edit()
                    expiredKeys.forEach { editor.remove(it) }
                    editor.apply()
                }
            }
        }
    }

    /**
     * Hashes challenge using SHA-256 to avoid storing unnecessary raw challenge data.
     */
    private fun hashChallenge(challengeHex: String): String {
        val digest = cryptoProvider.sha256(challengeHex.lowercase().toByteArray(Charsets.UTF_8))
        return cryptoProvider.toHex(digest)
    }

    /**
     * Atomically checks whether a challenge hash has already been registered, and registers it.
     * Throws IOException if the challenge is a replay or if the cache is saturated with unexpired entries.
     */
    @Throws(IOException::class)
    fun checkAndRegisterChallenge(challengeHex: String) {
        val challengeHash = hashChallenge(challengeHex)
        val nowNano = System.nanoTime()
        val nowEpoch = System.currentTimeMillis()

        synchronized(instanceLock) {
            cleanExpired(nowNano, nowEpoch)

            val existingNanoExpiry = seenChallengeHashes[challengeHash]
            if (existingNanoExpiry != null && nowNano < existingNanoExpiry) {
                throw IOException("Handshake challenge replay rejected: challenge has already been used within freshness window")
            }

            // Check capacity limit
            if (seenChallengeHashes.size >= maxCapacity && !seenChallengeHashes.containsKey(challengeHash)) {
                throw IOException("Handshake rejected: challenge cache saturated with active unexpired sessions. Try again later.")
            }

            val monoExpiry = nowNano + (FRESHNESS_WINDOW_MS * 1_000_000L)
            val epochExpiry = nowEpoch + FRESHNESS_WINDOW_MS

            seenChallengeHashes[challengeHash] = monoExpiry

            // Persist to SharedPreferences so it survives immediate process restarts
            prefs?.edit()?.putLong(challengeHash, epochExpiry)?.apply()
        }
    }

    private fun cleanExpired(nowNano: Long, nowEpoch: Long) {
        seenChallengeHashes.entries.removeIf { it.value <= nowNano }

        // Periodically prune expired entries in persistent storage
        prefs?.let { sp ->
            val toRemove = mutableListOf<String>()
            sp.all.forEach { (key, value) ->
                if (value is Long && value <= nowEpoch) {
                    toRemove.add(key)
                }
            }
            if (toRemove.isNotEmpty()) {
                val editor = sp.edit()
                toRemove.forEach { editor.remove(it) }
                editor.apply()
            }
        }
    }

    val activeChallengeCount: Int
        get() = seenChallengeHashes.size

    fun pruneExpiredForTest() {
        synchronized(instanceLock) {
            cleanExpired(System.nanoTime(), System.currentTimeMillis())
        }
    }
}
