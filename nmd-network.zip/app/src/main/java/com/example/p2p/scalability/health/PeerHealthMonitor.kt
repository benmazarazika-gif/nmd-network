package com.example.p2p.scalability.health

import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerAuthStatus
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.scalability.model.PeerHealthRecord
import com.example.p2p.scalability.model.PeerHealthStatus
import com.example.p2p.security.trust.PeerTrustManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

data class PeerHealthConfig(
    val degradedFailureThreshold: Int = 2,
    val missedHeartbeatDegradedThreshold: Int = 1,
    val unreachableFailureThreshold: Int = 3,
    val quarantineFailureThreshold: Int = 6,
    val quarantineDurationMs: Long = 120_000L,
    val recoverySuccessThreshold: Int = 2,
    val maxLatencyWarningMs: Long = 2_500L,
    val minReconnectStabilityScore: Int = 25,
    val staleCommunicationMs: Long = 180_000L,
    val reconnectWindowMs: Long = 120_000L,
    val maxTrackedPeers: Int = 256
) {
    init {
        require(unreachableFailureThreshold >= 2) { "Must never mark unreachable from a single missed heartbeat" }
        require(quarantineFailureThreshold >= unreachableFailureThreshold)
    }
}

/**
 * Multi-signal peer health classifier extending [DistributedPeerRegistry] and
 * respecting [PeerTrustManager] revocations.
 *
 * Design guarantees:
 * - Never classifies a peer as UNREACHABLE from a single missed heartbeat.
 * - Tracks RTT EWMA, recent failures, timeouts, reconnection churn, last sync interaction,
 *   last authenticated session, and protocol compatibility.
 * - Prevents rapid reconnect storms on quarantined peers while allowing controlled recovery probes.
 */
class PeerHealthMonitor(
    private val peerRegistry: DistributedPeerRegistry,
    private val trustManager: PeerTrustManager,
    val config: PeerHealthConfig = PeerHealthConfig(),
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private val healthRecords = ConcurrentHashMap<String, PeerHealthRecord>()
    private val reconnectTimestampsByPeer = ConcurrentHashMap<String, ArrayDeque<Long>>()
    private val recoverySuccessesByPeer = ConcurrentHashMap<String, Int>()

    private val _records = MutableStateFlow<List<PeerHealthRecord>>(emptyList())
    val records: StateFlow<List<PeerHealthRecord>> = _records.asStateFlow()

    fun syncFromRegistryAndTrust() {
        val now = clockMs()
        peerRegistry.peers.value.forEach { reg ->
            val revoked = trustManager.isPeerRevoked(reg.peerId) || reg.authenticationStatus == PeerAuthStatus.REVOKED
            val existing = healthRecords[reg.peerId]
            if (existing == null) {
                val initialStatus = when {
                    revoked -> PeerHealthStatus.REVOKED
                    reg.reachabilityStatus == ReachabilityStatus.UNREACHABLE && reg.consecutiveFailures >= config.unreachableFailureThreshold -> PeerHealthStatus.UNREACHABLE
                    reg.reachabilityStatus == ReachabilityStatus.STALE -> PeerHealthStatus.DEGRADED
                    else -> PeerHealthStatus.HEALTHY
                }
                putBounded(
                    PeerHealthRecord(
                        peerId = reg.peerId,
                        status = initialStatus,
                        protocolVersion = reg.protocolVersion,
                        protocolCompatible = reg.protocolVersion == P2pMessage.CURRENT_PROTOCOL_VERSION,
                        lastSuccessfulCommMs = reg.lastSeenTimestamp,
                        lastAuthenticatedSessionMs = if (reg.isAuthenticated) reg.lastSeenTimestamp else 0L,
                        lastLatencyMs = reg.latencyMs,
                        ewmaLatencyMs = reg.latencyMs?.toDouble(),
                        stabilityScore = reg.reputationScore.coerceIn(0, 100),
                        isRevoked = revoked,
                        lastUpdatedMs = now
                    )
                )
            } else if (revoked && existing.status != PeerHealthStatus.REVOKED) {
                healthRecords[reg.peerId] = existing.copy(
                    status = PeerHealthStatus.REVOKED,
                    isRevoked = true,
                    stabilityScore = 0,
                    lastUpdatedMs = now
                )
            }
        }
        publishRecords()
    }

    fun recordAuthenticatedSession(peerId: String, protocolVersion: Int = P2pMessage.CURRENT_PROTOCOL_VERSION, latencyMs: Long? = null) {
        val now = clockMs()
        val dq = reconnectTimestampsByPeer.computeIfAbsent(peerId) { ArrayDeque() }
        val recentRecons = synchronized(dq) {
            dq.addLast(now)
            while (dq.isNotEmpty() && now - dq.first() > config.reconnectWindowMs) {
                dq.removeFirst()
            }
            dq.size
        }

        val current = getOrCreate(peerId, now)
        if (trustManager.isPeerRevoked(peerId)) {
            markRevoked(peerId)
            return
        }

        val compatible = protocolVersion == P2pMessage.CURRENT_PROTOCOL_VERSION
        val ewma = updateEwma(current.ewmaLatencyMs, latencyMs)
        val churnPenalty = if (recentRecons > 4) 10 else 0
        val newStability = (current.stabilityScore + 12 - churnPenalty).coerceIn(0, 100)
        val nextStatus = when {
            !compatible -> PeerHealthStatus.DEGRADED
            current.status == PeerHealthStatus.QUARANTINED || current.status == PeerHealthStatus.UNREACHABLE || current.status == PeerHealthStatus.RECOVERING -> {
                val okCount = (recoverySuccessesByPeer[peerId] ?: 0) + 1
                recoverySuccessesByPeer[peerId] = okCount
                if (okCount >= config.recoverySuccessThreshold) {
                    recoverySuccessesByPeer.remove(peerId)
                    PeerHealthStatus.HEALTHY
                } else {
                    PeerHealthStatus.RECOVERING
                }
            }
            else -> PeerHealthStatus.HEALTHY
        }

        putBounded(
            current.copy(
                status = nextStatus,
                protocolVersion = protocolVersion,
                protocolCompatible = compatible,
                availabilityStatus = "ONLINE",
                lastSuccessfulCommMs = now,
                lastAuthenticatedSessionMs = now,
                lastLatencyMs = latencyMs ?: current.lastLatencyMs,
                ewmaLatencyMs = ewma,
                stabilityScore = newStability,
                consecutiveMissedHeartbeats = 0,
                recentReconnections = recentRecons,
                totalSuccesses = current.totalSuccesses + 1L,
                quarantinedUntilMs = 0L,
                lastUpdatedMs = now
            )
        )
        publishRecords()
    }

    fun recordHeartbeatSuccess(peerId: String, rttMs: Long) {
        val now = clockMs()
        val current = getOrCreate(peerId, now)
        if (current.isRevoked || trustManager.isPeerRevoked(peerId)) {
            markRevoked(peerId)
            return
        }
        val ewma = updateEwma(current.ewmaLatencyMs, rttMs)
        val highLatency = rttMs > config.maxLatencyWarningMs
        val recoveryCount = if (current.status == PeerHealthStatus.RECOVERING || current.status == PeerHealthStatus.DEGRADED || current.status == PeerHealthStatus.UNREACHABLE) {
            val count = (recoverySuccessesByPeer[peerId] ?: 0) + 1
            recoverySuccessesByPeer[peerId] = count
            count
        } else {
            0
        }

        val nextStatus = when {
            highLatency -> PeerHealthStatus.DEGRADED
            current.status == PeerHealthStatus.HEALTHY -> PeerHealthStatus.HEALTHY
            recoveryCount >= config.recoverySuccessThreshold -> {
                recoverySuccessesByPeer.remove(peerId)
                PeerHealthStatus.HEALTHY
            }
            else -> PeerHealthStatus.RECOVERING
        }

        val stabilityDelta = if (highLatency) -2 else 5
        putBounded(
            current.copy(
                status = nextStatus,
                availabilityStatus = "ONLINE",
                lastSuccessfulCommMs = now,
                lastLatencyMs = rttMs,
                ewmaLatencyMs = ewma,
                stabilityScore = (current.stabilityScore + stabilityDelta).coerceIn(0, 100),
                consecutiveMissedHeartbeats = 0,
                recentMessageFailures = (current.recentMessageFailures - 1).coerceAtLeast(0),
                recentTimeouts = (current.recentTimeouts - 1).coerceAtLeast(0),
                totalSuccesses = current.totalSuccesses + 1L,
                lastUpdatedMs = now
            )
        )
        peerRegistry.recordSuccessfulPing(peerId, rttMs)
        publishRecords()
    }

    /**
     * Never marks UNREACHABLE on a single missed heartbeat:
     * 1 missed heartbeat -> DEGRADED (or remains RECOVERING->DEGRADED)
     * >= [PeerHealthConfig.unreachableFailureThreshold] -> UNREACHABLE
     * >= [PeerHealthConfig.quarantineFailureThreshold] -> QUARANTINED
     */
    fun recordMissedHeartbeat(peerId: String): PeerHealthRecord {
        val now = clockMs()
        val current = getOrCreate(peerId, now)
        if (current.isRevoked || trustManager.isPeerRevoked(peerId)) {
            return markRevoked(peerId)
        }
        recoverySuccessesByPeer.remove(peerId)
        val missed = current.consecutiveMissedHeartbeats + 1
        val totalFailures = current.recentMessageFailures + current.recentTimeouts + missed
        val nextStatus = when {
            totalFailures >= config.quarantineFailureThreshold -> PeerHealthStatus.QUARANTINED
            missed >= config.unreachableFailureThreshold -> PeerHealthStatus.UNREACHABLE
            else -> PeerHealthStatus.DEGRADED
        }
        val quarantinedUntil = if (nextStatus == PeerHealthStatus.QUARANTINED) {
            now + config.quarantineDurationMs
        } else {
            current.quarantinedUntilMs
        }

        val updated = current.copy(
            status = nextStatus,
            availabilityStatus = if (nextStatus == PeerHealthStatus.UNREACHABLE || nextStatus == PeerHealthStatus.QUARANTINED) "UNREACHABLE" else "DEGRADED",
            consecutiveMissedHeartbeats = missed,
            recentTimeouts = current.recentTimeouts,
            totalFailures = current.totalFailures + 1L,
            stabilityScore = (current.stabilityScore - 10).coerceIn(0, 100),
            quarantinedUntilMs = quarantinedUntil,
            lastUpdatedMs = now
        )
        putBounded(updated)

        when (nextStatus) {
            PeerHealthStatus.UNREACHABLE,
            PeerHealthStatus.QUARANTINED -> peerRegistry.recordConnectionFailed(peerId)
            else -> Unit
        }
        publishRecords()
        return updated
    }

    fun recordMessageFailure(peerId: String, isTimeout: Boolean = false): PeerHealthRecord {
        val now = clockMs()
        val current = getOrCreate(peerId, now)
        if (current.isRevoked || trustManager.isPeerRevoked(peerId)) {
            return markRevoked(peerId)
        }
        recoverySuccessesByPeer.remove(peerId)
        val msgFails = current.recentMessageFailures + 1
        val timeouts = current.recentTimeouts + if (isTimeout) 1 else 0
        val failureSignals = msgFails + timeouts + current.consecutiveMissedHeartbeats
        val nextStatus = when {
            failureSignals >= config.quarantineFailureThreshold -> PeerHealthStatus.QUARANTINED
            failureSignals >= config.unreachableFailureThreshold -> PeerHealthStatus.UNREACHABLE
            failureSignals >= config.degradedFailureThreshold -> PeerHealthStatus.DEGRADED
            else -> current.status
        }
        val qUntil = if (nextStatus == PeerHealthStatus.QUARANTINED) now + config.quarantineDurationMs else current.quarantinedUntilMs
        val updated = current.copy(
            status = nextStatus,
            availabilityStatus = if (nextStatus == PeerHealthStatus.UNREACHABLE || nextStatus == PeerHealthStatus.QUARANTINED) "UNREACHABLE" else current.availabilityStatus,
            recentMessageFailures = msgFails,
            recentTimeouts = timeouts,
            totalFailures = current.totalFailures + 1L,
            stabilityScore = (current.stabilityScore - if (isTimeout) 12 else 8).coerceIn(0, 100),
            quarantinedUntilMs = qUntil,
            lastUpdatedMs = now
        )
        putBounded(updated)
        if (nextStatus == PeerHealthStatus.UNREACHABLE || nextStatus == PeerHealthStatus.QUARANTINED) {
            peerRegistry.recordConnectionFailed(peerId)
        }
        publishRecords()
        return updated
    }

    fun recordSyncInteraction(peerId: String, succeeded: Boolean) {
        val now = clockMs()
        val current = getOrCreate(peerId, now)
        if (current.isRevoked) return
        if (succeeded) {
            putBounded(
                current.copy(
                    lastSyncInteractionMs = now,
                    lastSuccessfulCommMs = now,
                    stabilityScore = (current.stabilityScore + 4).coerceIn(0, 100),
                    totalSuccesses = current.totalSuccesses + 1L,
                    lastUpdatedMs = now
                )
            )
            publishRecords()
        } else {
            recordMessageFailure(peerId, isTimeout = true)
        }
    }

    fun markRevoked(peerId: String): PeerHealthRecord {
        val now = clockMs()
        val current = getOrCreate(peerId, now)
        val updated = current.copy(
            status = PeerHealthStatus.REVOKED,
            availabilityStatus = "REVOKED",
            isRevoked = true,
            stabilityScore = 0,
            lastUpdatedMs = now
        )
        putBounded(updated)
        publishRecords()
        return updated
    }

    fun clearRevocation(peerId: String) {
        val now = clockMs()
        val current = healthRecords[peerId] ?: return
        putBounded(
            current.copy(
                status = PeerHealthStatus.RECOVERING,
                availabilityStatus = "UNKNOWN",
                isRevoked = false,
                stabilityScore = 40,
                consecutiveMissedHeartbeats = 0,
                recentMessageFailures = 0,
                lastUpdatedMs = now
            )
        )
        publishRecords()
    }

    fun evaluateQuarantineCooldowns(): Int {
        val now = clockMs()
        var transitioned = 0
        healthRecords.values.forEach { record ->
            if (record.status == PeerHealthStatus.QUARANTINED &&
                !record.isRevoked &&
                now >= record.quarantinedUntilMs
            ) {
                healthRecords[record.peerId] = record.copy(
                    status = PeerHealthStatus.RECOVERING,
                    availabilityStatus = "RECOVERING",
                    recentMessageFailures = (record.recentMessageFailures / 2),
                    consecutiveMissedHeartbeats = 0,
                    lastUpdatedMs = now
                )
                transitioned++
            }
        }
        if (transitioned > 0) {
            publishRecords()
        }
        return transitioned
    }

    fun getHealth(peerId: String): PeerHealthRecord? = healthRecords[peerId]

    fun canConnectCandidate(peerId: String, nowMs: Long = clockMs()): Boolean {
        if (trustManager.isPeerRevoked(peerId)) return false
        val rec = healthRecords[peerId] ?: return true
        return when (rec.status) {
            PeerHealthStatus.REVOKED -> false
            PeerHealthStatus.QUARANTINED -> nowMs >= rec.quarantinedUntilMs
            PeerHealthStatus.HEALTHY, PeerHealthStatus.DEGRADED, PeerHealthStatus.RECOVERING -> rec.protocolCompatible
            PeerHealthStatus.UNREACHABLE -> (nowMs - rec.lastUpdatedMs) >= config.staleCommunicationMs / 4
        }
    }

    fun selectWorstConnectedPeerForReplacement(connectedPeerIds: List<String>): String? {
        if (connectedPeerIds.isEmpty()) return null
        return connectedPeerIds
            .mapNotNull { healthRecords[it] }
            .filter {
                it.status == PeerHealthStatus.QUARANTINED ||
                    it.status == PeerHealthStatus.UNREACHABLE ||
                    it.status == PeerHealthStatus.DEGRADED ||
                    it.stabilityScore < config.minReconnectStabilityScore
            }
            .minWithOrNull(compareBy<PeerHealthRecord> { it.stabilityScore }.thenByDescending { it.totalFailures })
            ?.peerId
    }

    fun scoreCandidate(record: PeerRegistryRecord, nowMs: Long = clockMs()): Int {
        val h = healthRecords[record.peerId]
        var score = record.reputationScore
        if (h != null) {
            score = (score + h.stabilityScore) / 2
            when (h.status) {
                PeerHealthStatus.HEALTHY -> score += 25
                PeerHealthStatus.RECOVERING -> score += 5
                PeerHealthStatus.DEGRADED -> score -= 20
                PeerHealthStatus.UNREACHABLE -> score -= 45
                PeerHealthStatus.QUARANTINED -> if (nowMs < h.quarantinedUntilMs) score -= 100
                PeerHealthStatus.REVOKED -> return -1000
            }
            h.ewmaLatencyMs?.let { rtt ->
                if (rtt < 120.0) score += 10 else if (rtt > 1500.0) score -= 15
            }
        }
        if (record.isBootstrap) score += 5
        return score
    }

    private fun updateEwma(previous: Double?, sampleMs: Long?): Double? {
        if (sampleMs == null || sampleMs <= 0L) return previous
        return if (previous == null) sampleMs.toDouble() else (0.3 * sampleMs + 0.7 * previous)
    }

    private fun getOrCreate(peerId: String, now: Long): PeerHealthRecord {
        return healthRecords.computeIfAbsent(peerId) {
            val reg = peerRegistry.getPeer(peerId)
            val revoked = trustManager.isPeerRevoked(peerId) || reg?.authenticationStatus == PeerAuthStatus.REVOKED
            PeerHealthRecord(
                peerId = peerId,
                status = if (revoked) PeerHealthStatus.REVOKED else PeerHealthStatus.HEALTHY,
                protocolVersion = reg?.protocolVersion ?: P2pMessage.CURRENT_PROTOCOL_VERSION,
                isRevoked = revoked,
                stabilityScore = reg?.reputationScore ?: 75,
                lastUpdatedMs = now
            )
        }
    }

    private fun putBounded(record: PeerHealthRecord) {
        if (healthRecords.size >= config.maxTrackedPeers && !healthRecords.containsKey(record.peerId)) {
            healthRecords.values
                .filter { it.status != PeerHealthStatus.HEALTHY && !it.isRevoked }
                .minByOrNull { it.lastUpdatedMs }
                ?.peerId
                ?.let { healthRecords.remove(it) }
        }
        healthRecords[record.peerId] = record
    }

    private fun publishRecords() {
        _records.value = healthRecords.values.sortedWith(
            compareBy<PeerHealthRecord> { it.status.ordinal }.thenByDescending { it.stabilityScore }
        )
    }
}
