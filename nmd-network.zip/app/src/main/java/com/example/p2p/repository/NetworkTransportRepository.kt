package com.example.p2p.repository

import android.content.Context
import com.example.crypto.NodeIdentityManager
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.p2p.connectivity.PeerConnectivityManager
import com.example.p2p.connectivity.model.ConnectivityDiagnosticsSnapshot
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.connectivity.signaling.SignalingChannel
import com.example.p2p.infrastructure.NetworkInfrastructureCoordinator
import com.example.p2p.infrastructure.model.BootstrapEndpointConfig
import com.example.p2p.infrastructure.model.NetworkInfrastructureSnapshot
import com.example.p2p.infrastructure.model.NetworkProfileConfig
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.scalability.NetworkScalabilityCoordinator
import com.example.p2p.scalability.connection.ConnectionMaintenanceReport
import com.example.p2p.scalability.model.DeviceResourceMode
import com.example.p2p.scalability.model.NetworkScalabilitySnapshot
import com.example.p2p.discovery.DiscoveryMethod
import com.example.p2p.discovery.DiscoveryStatusState
import com.example.p2p.discovery.DistributedDiscoveryCoordinator
import com.example.p2p.discovery.PeerDiscoveryService
import com.example.p2p.discovery.bootstrap.BootstrapPeer
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.topology.TopologyMetrics
import com.example.p2p.handshake.PeerHandshakeService
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.DiscoveredPeer
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerInfo
import com.example.p2p.security.TransportSecurityManager
import com.example.p2p.security.model.NetworkSecurityUiState
import com.example.p2p.security.model.SecurityEventType
import com.example.p2p.transport.P2PTransport
import com.example.p2p.transport.TcpPeerTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.Closeable

/**
 * MessageExchangeRecord represents an authenticated protocol message logged in the P2P UI.
 */
data class MessageExchangeRecord(
    val id: String,
    val direction: MessageDirection,
    val remoteNodeId: String,
    val messageType: String,
    val payload: String,
    val timestamp: Long
)

enum class MessageDirection {
    INCOMING,
    OUTGOING
}

/**
 * NetworkTransportRepository provides the central application-level interface for real local P2P networking.
 */
class NetworkTransportRepository(
    private val context: Context,
    private val identityManager: NodeIdentityManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO),
    val transport: P2PTransport = TcpPeerTransport(scope),
    val handshakeService: PeerHandshakeService = PeerHandshakeService(identityManager),
    val discoveryService: PeerDiscoveryService = PeerDiscoveryService(context, scope),
    val connectionManager: PeerConnectionManager = PeerConnectionManager(
        context = context,
        identityManager = identityManager,
        transport = transport,
        handshakeService = handshakeService,
        discoveryService = discoveryService,
        scope = scope
    ),
    val reliableMessagingService: com.example.p2p.service.ReliableP2pMessagingService = com.example.p2p.service.ReliableP2pMessagingService(
        context = context,
        identityManager = identityManager,
        connectionManager = connectionManager,
        scope = scope
    ),
    val discoveryCoordinator: DistributedDiscoveryCoordinator = DistributedDiscoveryCoordinator(
        context = context,
        identityManager = identityManager,
        transport = transport,
        discoveryService = discoveryService,
        connectionManager = connectionManager,
        reliableMessagingService = reliableMessagingService,
        scope = scope
    ),
    val connectivityManager: PeerConnectivityManager = PeerConnectivityManager(
        context = context,
        identityManager = identityManager,
        connectionManager = connectionManager,
        discoveryCoordinator = discoveryCoordinator,
        scope = scope,
        discoveryService = discoveryService,
        localIpProvider = { transport.getLocalIpAddress() }
    ),
    val infrastructureCoordinator: NetworkInfrastructureCoordinator = NetworkInfrastructureCoordinator(
        context = context,
        identityManager = identityManager,
        transport = transport,
        connectionManager = connectionManager,
        discoveryCoordinator = discoveryCoordinator,
        connectivityManager = connectivityManager,
        scope = scope
    ),
    val scalabilityCoordinator: NetworkScalabilityCoordinator = NetworkScalabilityCoordinator(
        context = context,
        identityManager = identityManager,
        connectionManager = connectionManager,
        discoveryCoordinator = discoveryCoordinator,
        connectivityManager = connectivityManager,
        infrastructureCoordinator = infrastructureCoordinator,
        scope = scope
    )
) : Closeable {

    val transportSecurityManager: TransportSecurityManager = connectionManager.transportSecurityManager

    val isListening: StateFlow<Boolean> = transport.isListening
    val boundPort: StateFlow<Int?> = transport.boundPort
    val discoveredPeers: StateFlow<List<DiscoveredPeer>> = discoveryService.discoveredPeers
    val authenticatedPeers: StateFlow<List<RealPeerInfo>> = connectionManager.authenticatedPeers
    val transportEvents: SharedFlow<String> = connectionManager.transportEvents

    // Stage 13: Transport Security Dashboard State
    val securityUiState: StateFlow<NetworkSecurityUiState> = transportSecurityManager.uiState

    // Stage 14: NAT Traversal & Direct Internet Connectivity Diagnostics State
    val connectivityDiagnostics: StateFlow<ConnectivityDiagnosticsSnapshot> = connectivityManager.diagnostics

    // Stage 15: Public Network Infrastructure & Bootstrap Diagnostics State
    val infrastructureSnapshot: StateFlow<NetworkInfrastructureSnapshot> = infrastructureCoordinator.snapshot

    // Stage 16: Scalability, Peer Health, Congestion, Resource Mode & Validator Quorum Availability
    val scalabilitySnapshot: StateFlow<NetworkScalabilitySnapshot> = scalabilityCoordinator.snapshot

    // Stage 6: Reliable P2P Messaging State
    val activeSessions: StateFlow<List<com.example.p2p.session.PeerSession>> = reliableMessagingService.sessions
    val reliableMessageHistory: StateFlow<List<com.example.p2p.protocol.ReliableMessageRecord>> = reliableMessagingService.reliableMessageLog
    val testReport: StateFlow<com.example.p2p.service.P2pTestLabReport?> = reliableMessagingService.testReport

    // Stage 7: Distributed Peer Discovery & Topology State
    val registeredPeers: StateFlow<List<PeerRegistryRecord>> = discoveryCoordinator.registeredPeers
    val bootstrapPeers: StateFlow<List<BootstrapPeer>> = discoveryCoordinator.bootstrapPeers
    val topologyMetrics: StateFlow<TopologyMetrics> = discoveryCoordinator.topologyMetrics
    val discoveryStatus: StateFlow<DiscoveryStatusState> = discoveryCoordinator.discoveryStatus
    val activeDiscoveryMethod: StateFlow<DiscoveryMethod> = discoveryCoordinator.activeDiscoveryMethod
    val lastSuccessfulDiscoveryMs: StateFlow<Long?> = discoveryCoordinator.lastSuccessfulDiscoveryMs

    private val _messageHistory = MutableStateFlow<List<MessageExchangeRecord>>(emptyList())
    val messageHistory: StateFlow<List<MessageExchangeRecord>> = _messageHistory.asStateFlow()

    init {
        infrastructureCoordinator.bootstrapManager.circuitBreakerManager = scalabilityCoordinator.circuitBreakerManager
        infrastructureCoordinator.webSocketSignalingChannel.circuitBreakerManager = scalabilityCoordinator.circuitBreakerManager
        reliableMessagingService.peerHealthMonitor = scalabilityCoordinator.peerHealthMonitor
        reliableMessagingService.congestionController = scalabilityCoordinator.congestionController

        connectionManager.onPeerSecurityViolation = { peerId, eventType, reason ->
            if (!peerId.isNullOrBlank()) {
                if (eventType == SecurityEventType.PEER_REVOKED) {
                    discoveryCoordinator.peerRegistry.recordPeerRevoked(peerId, reason)
                    scalabilityCoordinator.peerHealthMonitor.markRevoked(peerId)
                } else {
                    discoveryCoordinator.peerRegistry.recordInvalidBehavior(peerId, penalty = 25)
                    scalabilityCoordinator.peerHealthMonitor.recordMessageFailure(peerId, isTimeout = false)
                }
            }
        }

        // Collect incoming authenticated messages
        scope.launch {
            connectionManager.receivedMessages.collect { (peer, message) ->
                val record = MessageExchangeRecord(
                    id = message.messageId,
                    direction = MessageDirection.INCOMING,
                    remoteNodeId = peer.authenticatedNodeId ?: message.senderNodeId,
                    messageType = message.messageType.name,
                    payload = message.payload,
                    timestamp = message.timestamp
                )
                _messageHistory.value = listOf(record) + _messageHistory.value.take(49)
            }
        }
    }

    fun getLocalIpAddress(): String = transport.getLocalIpAddress()

    suspend fun startListening(port: Int = TcpPeerTransport.DEFAULT_NMD_PORT): Int {
        return connectionManager.startP2P(port)
    }

    suspend fun stopListening() {
        connectionManager.stopP2P()
    }

    suspend fun connectToPeer(endpoint: PeerEndpoint): Result<RealPeerInfo> {
        return connectionManager.connectToPeer(endpoint)
    }

    suspend fun disconnectPeer(connectionId: String) {
        connectionManager.disconnectPeer(connectionId)
    }

    suspend fun sendSignedMessage(
        connectionId: String,
        messageType: ProtocolMessageType,
        payload: String
    ): Result<SignedProtocolMessage> {
        val result = connectionManager.sendMessage(connectionId, messageType, payload)
        if (result.isSuccess) {
            val message = result.getOrThrow()
            val targetPeer = authenticatedPeers.value.find { it.connectionId == connectionId }
            val record = MessageExchangeRecord(
                id = message.messageId,
                direction = MessageDirection.OUTGOING,
                remoteNodeId = targetPeer?.authenticatedNodeId ?: "unknown",
                messageType = message.messageType.name,
                payload = message.payload,
                timestamp = message.timestamp
            )
            _messageHistory.value = listOf(record) + _messageHistory.value.take(49)
        }
        return result
    }

    fun addManualPeer(host: String, port: Int, claimedNodeId: String? = null) {
        discoveryService.addManualPeer(host, port, claimedNodeId)
    }

    suspend fun sendReliableP2pMessage(
        sessionId: String,
        messageType: com.example.p2p.protocol.P2pMessageType,
        payload: String
    ): Result<com.example.p2p.reliable.DeliveryResult> {
        return reliableMessagingService.sendReliableMessage(sessionId, messageType, payload)
    }

    suspend fun sendSyncProtocolMessage(
        sessionId: String,
        messageType: com.example.p2p.protocol.P2pMessageType,
        payload: String
    ): Result<com.example.p2p.reliable.DeliveryResult> {
        return reliableMessagingService.sendSyncProtocolMessage(sessionId, messageType, payload)
    }

    suspend fun sendPingToSession(sessionId: String): Result<Long> {
        return reliableMessagingService.sendManualPing(sessionId)
    }

    suspend fun runP2pTestLabSuite(sessionId: String): com.example.p2p.service.P2pTestLabReport {
        return reliableMessagingService.runTestLabSuite(sessionId)
    }

    fun clearP2pTestReport() {
        reliableMessagingService.clearTestReport()
    }

    // Stage 7: Distributed Discovery & Bootstrap Operations
    suspend fun refreshDistributedDiscovery() {
        discoveryCoordinator.refreshDiscovery()
    }

    suspend fun requestPeerExchangeFromAll(): Int {
        return discoveryCoordinator.requestPeerExchangeFromAll()
    }

    suspend fun connectToRegistryPeer(peerId: String): Result<RealPeerInfo> {
        return discoveryCoordinator.connectToRegistryPeer(peerId)
    }

    suspend fun connectBootstrapPeer(id: String): Result<RealPeerInfo> {
        return discoveryCoordinator.connectBootstrapPeer(id)
    }

    fun addCustomBootstrapPeer(
        name: String,
        host: String,
        port: Int,
        expectedNodeId: String? = null
    ): BootstrapPeer {
        return discoveryCoordinator.addCustomBootstrapPeer(name, host, port, expectedNodeId)
    }

    fun toggleBootstrapPeer(id: String, enabled: Boolean) {
        discoveryCoordinator.toggleBootstrapPeer(id, enabled)
    }

    fun removeBootstrapPeer(id: String) {
        discoveryCoordinator.removeBootstrapPeer(id)
    }

    fun removeRegistryPeer(peerId: String): Boolean {
        return discoveryCoordinator.peerRegistry.removePeer(peerId)
    }

    // Stage 13: Transport Security Management Operations
    fun revokePeerIdentity(nodeId: String, reason: String = "Revoked via Network Security dashboard"): Int {
        val terminated = transportSecurityManager.revokePeerIdentity(nodeId, reason = reason)
        discoveryCoordinator.peerRegistry.recordPeerRevoked(nodeId, reason)
        return terminated
    }

    fun unrevokePeerIdentity(nodeId: String): Boolean {
        val removed = transportSecurityManager.unrevokePeerIdentity(nodeId)
        if (removed) {
            discoveryCoordinator.peerRegistry.updateReachability(
                nodeId,
                com.example.p2p.discovery.registry.ReachabilityStatus.UNKNOWN
            )
        }
        return removed
    }

    fun rotateEncryptedSessions(): Int {
        return transportSecurityManager.rotateAllSessions()
    }

    // Stage 14: NAT Traversal, STUN/TURN Configuration & Connectivity Operations
    suspend fun refreshNatConnectivity(): ConnectivityDiagnosticsSnapshot {
        return connectivityManager.refreshConnectivityAndStunProbes()
    }

    fun triggerIceRestart() {
        connectivityManager.triggerManualIceRestart()
    }

    fun configureStunTurnServers(
        stunServers: List<StunServerConfig>,
        turnServers: List<TurnServerConfig>
    ) {
        connectivityManager.configureStunAndTurnServers(stunServers, turnServers)
    }

    fun attachSignalingChannel(channel: SignalingChannel) {
        connectivityManager.attachSignalingChannel(channel)
    }

    suspend fun connectToPeerSmart(
        targetNodeId: String?,
        localEndpoint: PeerEndpoint? = null,
        preferRelayFallback: Boolean = true
    ): Result<RealPeerInfo> {
        return connectivityManager.connectToPeerSmart(targetNodeId, localEndpoint, preferRelayFallback)
    }

    // Stage 15: Public Network Infrastructure, Bootstrap & WebSocket Signaling Operations
    fun switchNetworkProfile(profile: NmdNetworkProfile): Result<NetworkProfileConfig> {
        return infrastructureCoordinator.switchProfilePreset(profile)
    }

    fun applyNetworkInfrastructureConfig(config: NetworkProfileConfig): Result<NetworkProfileConfig> {
        return infrastructureCoordinator.applyNetworkProfileConfig(config)
    }

    suspend fun bootstrapAndSyncPeers(): Result<Int> {
        return infrastructureCoordinator.bootstrapAndSyncPeers()
    }

    suspend fun probeBootstrapEndpointsHealth(): List<BootstrapEndpointConfig> {
        return infrastructureCoordinator.bootstrapManager.probeAllEndpointsHealth()
    }

    fun reconnectSignalingTransport() {
        infrastructureCoordinator.webSocketSignalingChannel.triggerReconnect("Manual reconnect requested")
    }

    // Stage 16: Scalability, Fault Tolerance & Adaptive Resource Operations
    suspend fun runScalabilitySweep(): ConnectionMaintenanceReport {
        return scalabilityCoordinator.runHealthAndTopologySweep(attemptOutboundDial = true)
    }

    fun setDeviceResourceModeOverride(mode: DeviceResourceMode?): NetworkScalabilitySnapshot {
        return scalabilityCoordinator.setManualResourceMode(mode)
    }

    fun resetAllCircuitBreakers(): NetworkScalabilitySnapshot {
        return scalabilityCoordinator.resetAllCircuitBreakers()
    }

    override fun close() {
        scalabilityCoordinator.close()
        infrastructureCoordinator.close()
        connectivityManager.close()
        discoveryCoordinator.close()
        reliableMessagingService.close()
        connectionManager.close()
        discoveryService.close()
        transport.close()
    }
}
