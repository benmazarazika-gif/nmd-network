package com.example.p2p.security.model

import com.example.blockchain.config.NmdGenesisConfigs

/**
 * Stage 13 formal Threat Model for NMD Network P2P Encrypted Transport.
 *
 * Clearly separates mitigated transport-layer threats from residual/out-of-scope risks
 * that transport encryption alone cannot prevent.
 */
object SecurityThreatModel {

    data class ThreatEntry(
        val id: String,
        val threat: String,
        val mitigatedBy: String,
        val residualRiskNote: String
    )

    val MITIGATED_THREATS: List<ThreatEntry> = listOf(
        ThreatEntry(
            id = "T-01",
            threat = "Network traffic interception / passive eavesdropping",
            mitigatedBy = "Ephemeral X25519 ECDHE key agreement (forward secrecy) + HKDF-SHA256 direction-separated 256-bit keys + ChaCha20-Poly1305 AEAD encryption for all post-handshake frames.",
            residualRiskNote = "Packet sizes, connection timing, and IP endpoints remain observable by network observers."
        ),
        ThreatEntry(
            id = "T-02",
            threat = "Message modification / bit-flipping / frame truncation",
            mitigatedBy = "ChaCha20-Poly1305 128-bit Poly1305 MAC over ciphertext and AAD (protocol version, session ID, direction, sequence number, inner frame type, length) plus Ed25519 application signatures.",
            residualRiskNote = "Modified frames are dropped and trigger session termination."
        ),
        ThreatEntry(
            id = "T-03",
            threat = "Peer impersonation / MITM identity spoofing",
            mitigatedBy = "Mutual Ed25519 signatures over Noise-style transcript hash binding chainId, suiteId, protocolVersion, both static Node IDs/Ed25519 keys, both ephemeral X25519 public keys, and fresh 256-bit challenges.",
            residualRiskNote = "First-contact TOFU without external out-of-band pinning verifies cryptographic self-consistency (NodeID = SHA256(PubKey)); subsequent identity swaps are flagged and blocked."
        ),
        ThreatEntry(
            id = "T-04",
            threat = "Replay attacks (handshake challenges and encrypted frames)",
            mitigatedBy = "Persistent SHA-256 handshake challenge replay cache + per-session unique ID + direction-separated monotonic 64-bit send counters and sliding-window duplicate/replay detection on receive.",
            residualRiskNote = "Replayed handshakes or encrypted frames are rejected immediately with security telemetry."
        ),
        ThreatEntry(
            id = "T-05",
            threat = "Unauthorized peer connections (wrong Chain ID / untrusted / unauthenticated frames)",
            mitigatedBy = "Strict Chain ID verification in handshake transcript, trust manager validation, and hard drop of unauthenticated application frames.",
            residualRiskNote = "Open P2P networks accept inbound handshakes from unknown peers unless explicitly revoked; blockchain/validator authorization remains enforced by Stages 9-12."
        ),
        ThreatEntry(
            id = "T-06",
            threat = "Session hijacking / cross-session frame injection",
            mitigatedBy = "Random 128-bit session IDs bound in AEAD AAD and Ed25519 handshake transcript; ephemeral ChaCha20-Poly1305 keys isolated in RAM per session and zeroized on close.",
            residualRiskNote = "Assumes host OS process memory isolation."
        ),
        ThreatEntry(
            id = "T-07",
            threat = "Malformed cryptographic messages & weak ECDH keys",
            mitigatedBy = "Strict bounds checks before parsing, RFC 7748 all-zero X25519 shared-secret rejection, strict hex/length checks, and fail-closed AEAD verification.",
            residualRiskNote = "None beyond standard cryptographic assumptions."
        ),
        ThreatEntry(
            id = "T-08",
            threat = "Resource exhaustion via connection or message flooding",
            mitigatedBy = "ConnectionAbuseProtector enforcing max concurrent unauthenticated handshakes, bounded pending queue, handshake timeout, per-IP connection rate limit, per-peer message rate limit, and failure cooldowns.",
            residualRiskNote = "Volumetric kernel-level SYN floods upstream of the Java ServerSocket cannot be blocked solely in user space."
        ),
        ThreatEntry(
            id = "T-09",
            threat = "Protocol & cipher-suite downgrade attempts",
            mitigatedBy = "Minimum supported protocol version enforcement (v3), rejecting legacy v1/v2 plaintext handshakes, binding cipherSuiteId + minSupportedVersion into signed transcript, and never falling back to plaintext.",
            residualRiskNote = "Requires peer compatibility with v3 Stage 13 encrypted transport."
        ),
        ThreatEntry(
            id = "T-10",
            threat = "Compromised or revoked peer identities",
            mitigatedBy = "Persistent PeerTrustManager revocation list checked before handshake completion and enforced dynamically to terminate active sessions immediately.",
            residualRiskNote = "Revocation in a decentralized network without central CA is local unless explicitly distributed by governance in future stages."
        )
    )

    val UNPREVENTABLE_BY_TRANSPORT_ALONE: List<String> = listOf(
        "Compromised physical Android device, rooted OS kernel, or extraction of hardware/software Keystore secrets by local privileged malware.",
        "Malicious behavior by an authorized BFT validator whose Ed25519 private key is legitimately enrolled (addressed by Stage 10 BFT quorum & equivocation detection, not transport encryption).",
        "Global passive traffic analysis (observing IP endpoints, packet timing, and byte volumes outside encrypted ciphertexts).",
        "Kernel/network-layer volumetric DDoS saturating device bandwidth prior to application socket accept()."
    )
}

enum class TransportSecurityStatus {
    SECURE,
    CONNECTING,
    AUTHENTICATING,
    ENCRYPTED,
    AUTHENTICATION_FAILED,
    DISCONNECTED,
    PEER_REVOKED
}

enum class PeerTrustState {
    UNVERIFIED,
    TRUSTED_AUTHENTICATED,
    AUTH_FAILED,
    REVOKED,
    IDENTITY_MISMATCH
}

enum class SecurityEventType {
    HANDSHAKE_STARTED,
    HANDSHAKE_AUTHENTICATED,
    ENCRYPTED_SESSION_ACTIVE,
    HANDSHAKE_FAILED,
    DOWNGRADE_REJECTED,
    CHAIN_MISMATCH_REJECTED,
    SIGNATURE_INVALID,
    AEAD_DECRYPT_FAILED,
    REPLAY_REJECTED,
    STALE_SESSION_REJECTED,
    SESSION_EXPIRED,
    SESSION_ROTATED,
    PEER_REVOKED,
    IDENTITY_CHANGE_DETECTED,
    FLOOD_OR_RATE_LIMITED,
    OVERSIZED_FRAME_REJECTED,
    MALFORMED_FRAME_REJECTED
}

data class SecurityEventRecord(
    val id: String,
    val type: SecurityEventType,
    val peerIdOrHost: String,
    val summary: String,
    val isFailure: Boolean,
    val timestampMs: Long = System.currentTimeMillis()
)

data class RevokedIdentityRecord(
    val nodeId: String,
    val publicKeyHashHex: String? = null,
    val reason: String,
    val revokedAtMs: Long = System.currentTimeMillis()
)

data class PeerSecurityStatusSummary(
    val sessionId: String,
    val peerId: String,
    val endpointFormatted: String,
    val status: TransportSecurityStatus,
    val trustState: PeerTrustState,
    val protocolVersion: Int,
    val cipherSuiteId: String,
    val framesSent: Long,
    val framesReceived: Long,
    val expiresAtMs: Long,
    val isOutbound: Boolean
)

data class TransportSecurityConfig(
    val chainId: String = NmdGenesisConfigs.LOCAL_DEV.chainId,
    val protocolVersion: Int = CURRENT_SECURE_PROTOCOL_VERSION,
    val minSupportedProtocolVersion: Int = CURRENT_SECURE_PROTOCOL_VERSION,
    val cipherSuiteId: String = DEFAULT_CIPHER_SUITE_ID,
    val requireEncryptedTransport: Boolean = true,
    val maxHandshakeMessageBytes: Int = 8_192,
    val maxInnerPlaintextBytes: Int = 64 * 1024,
    val maxEncryptedFrameBytes: Int = 96 * 1024,
    val handshakeTimeoutMs: Long = 8_000L,
    val maxHandshakeDriftMs: Long = 60_000L,
    val sessionTtlMs: Long = 30 * 60 * 1_000L,
    val maxFramesPerSession: Long = 1_000_000L,
    val maxConcurrentUnauthenticatedConnections: Int = 4,
    val maxPendingHandshakeQueue: Int = 8,
    val maxConnectionAttemptsPerWindow: Int = 12,
    val connectionRateWindowMs: Long = 30_000L,
    val maxMessagesPerPeerPerWindow: Int = 150,
    val messageRateWindowMs: Long = 10_000L,
    val maxAuthFailuresBeforeCooldown: Int = 3,
    val peerCooldownMs: Long = 60_000L,
    val rejectUnexpectedIdentityChange: Boolean = true
) {
    companion object {
        const val CURRENT_SECURE_PROTOCOL_VERSION = 3
        const val DEFAULT_CIPHER_SUITE_ID = "NMD_NOISE_XX_X25519_ED25519_CHACHAPOLY_SHA256"
    }
}

data class NetworkSecurityUiState(
    val status: TransportSecurityStatus = TransportSecurityStatus.DISCONNECTED,
    val encryptionProtocolId: String = TransportSecurityConfig.DEFAULT_CIPHER_SUITE_ID,
    val protocolVersion: Int = TransportSecurityConfig.CURRENT_SECURE_PROTOCOL_VERSION,
    val chainId: String = NmdGenesisConfigs.LOCAL_DEV.chainId,
    val authenticatedPeersCount: Int = 0,
    val encryptedSessionsCount: Int = 0,
    val pendingHandshakesCount: Int = 0,
    val failedHandshakesCount: Long = 0L,
    val rejectedReplaysCount: Long = 0L,
    val rateLimitedPeersCount: Int = 0,
    val revokedPeersCount: Int = 0,
    val peerStatuses: List<PeerSecurityStatusSummary> = emptyList(),
    val revokedPeerIds: List<String> = emptyList(),
    val lastSecurityEvent: SecurityEventRecord? = null,
    val recentEvents: List<SecurityEventRecord> = emptyList()
)
