package com.example.p2p.infrastructure.bootstrap

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.CryptographicProvider
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.infrastructure.model.BootstrapEndpointConfig
import com.example.p2p.infrastructure.model.BootstrapPeerRecord
import com.example.p2p.infrastructure.model.BootstrapTransportProtocol
import com.example.p2p.infrastructure.model.EndpointHealthState
import com.example.p2p.infrastructure.model.NetworkProfileConfig
import com.example.p2p.infrastructure.model.NetworkProfileRegistry
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.scalability.circuit.CircuitBreakerManager
import com.example.p2p.scalability.model.CircuitBreakerTargetType
import com.example.p2p.security.trust.PeerTrustManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.CertificatePinner
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.TimeUnit

data class BootstrapDiscoveryOutcome(
    val usedEndpointId: String?,
    val validPeersAccepted: List<BootstrapPeerRecord>,
    val rejectedRecordsCount: Int,
    val errorSummary: String? = null
)

/**
 * Stage 15 Public Bootstrap Node Manager.
 *
 * Responsibilities:
 * - Multi-endpoint bootstrap discovery with priority ordering, exponential backoff + jitter cooldowns,
 *   automatic failover, IPv4/IPv6 resolution, timeouts, and TLS certificate pinning.
 * - Verifies Chain ID and deterministic Genesis Hash on every bootstrap network config & peer directory.
 * - Verifies optional Ed25519 bootstrap server signatures when pinned public keys are supplied.
 * - Feeds ONLY validated peer records into [DistributedPeerRegistry] — never treats bootstrap
 *   servers as authorities for block validity, consensus, or private keys.
 */
class BootstrapNodeManager(
    private val context: Context?,
    private val identityManager: NodeIdentityManager,
    private val peerRegistry: DistributedPeerRegistry,
    private val trustManager: PeerTrustManager,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider,
    private val clockMs: () -> Long = { System.currentTimeMillis() },
    private val baseHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(6, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val TAG = "BootstrapNodeManager"
        private const val PREFS_NAME = "nmd_stage15_infra_config"
        private const val KEY_ACTIVE_PROFILE_CONFIG = "active_network_profile_config"
        private const val MAX_JSON_RESPONSE_BYTES = 131_072L
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    }

    private val prefs: SharedPreferences? = try {
        context?.applicationContext?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    } catch (_: Exception) {
        null
    }

    private val _activeProfileConfig = MutableStateFlow(loadPersistedOrDefaultConfig())
    val activeProfileConfig: StateFlow<NetworkProfileConfig> = _activeProfileConfig.asStateFlow()

    private val _lastDirectoryRefreshMs = MutableStateFlow<Long?>(null)
    val lastDirectoryRefreshMs: StateFlow<Long?> = _lastDirectoryRefreshMs.asStateFlow()

    private val _lastBootstrapSuccessMs = MutableStateFlow<Long?>(null)
    val lastBootstrapSuccessMs: StateFlow<Long?> = _lastBootstrapSuccessMs.asStateFlow()

    private val _lastErrorSummary = MutableStateFlow<String?>(null)
    val lastErrorSummary: StateFlow<String?> = _lastErrorSummary.asStateFlow()

    @Volatile
    var circuitBreakerManager: CircuitBreakerManager? = null

    /**
     * Switches or updates the active network profile configuration safely.
     * Enforces profile isolation (no accidental TESTNET/MAINNET mix, no unactivated MAINNET,
     * no dev loopback addresses in production/testnet unless explicit test override is set).
     */
    fun applyProfileConfiguration(newConfig: NetworkProfileConfig, persist: Boolean = true): Result<NetworkProfileConfig> {
        val validationError = newConfig.validate()
        if (validationError != null) {
            return Result.failure(IllegalArgumentException(validationError))
        }
        _activeProfileConfig.value = newConfig
        _lastErrorSummary.value = null
        if (persist) {
            persistConfig(newConfig)
        }
        return Result.success(newConfig)
    }

    /**
     * Probes /health on all enabled bootstrap endpoints for the active network profile.
     */
    suspend fun probeAllEndpointsHealth(): List<BootstrapEndpointConfig> = withContext(ioDispatcher) {
        val cfg = _activeProfileConfig.value
        val updated = cfg.bootstrapEndpoints.map { ep ->
            if (!ep.isEnabled) {
                ep
            } else {
                val invalidErr = ep.validateForProfile(cfg.profile, cfg.allowLocalTestOverride)
                if (invalidErr != null) {
                    ep.copy(healthState = EndpointHealthState.CONFIG_INVALID, lastError = invalidErr)
                } else {
                    probeSingleHealth(ep, cfg)
                }
            }
        }
        updateBootstrapList(updated)
        updated
    }

    /**
     * Discovers initial peers from healthy prioritized bootstrap endpoints with automatic failover.
     */
    suspend fun discoverInitialPeers(
        limit: Int = 30,
        bypassCooldown: Boolean = false
    ): Result<BootstrapDiscoveryOutcome> = withContext(ioDispatcher) {
        val cfg = _activeProfileConfig.value
        if (cfg.profile == NmdNetworkProfile.MAINNET && !cfg.isMainnetActivated) {
            return@withContext Result.failure(IllegalStateException("Mainnet profile is disabled"))
        }

        val now = clockMs()
        val ordered = cfg.bootstrapEndpoints
            .filter { it.isEnabled }
            .sortedBy { it.priority }

        if (ordered.isEmpty()) {
            val msg = "No bootstrap endpoints configured for ${cfg.profile.name}"
            _lastErrorSummary.value = msg
            return@withContext Result.failure(IllegalStateException(msg))
        }

        var lastErr: String = "All bootstrap endpoints failed"
        val updatedEndpoints = cfg.bootstrapEndpoints.toMutableList()

        for (endpoint in ordered) {
            val configErr = endpoint.validateForProfile(cfg.profile, cfg.allowLocalTestOverride)
            if (configErr != null) {
                replaceEndpoint(updatedEndpoints, endpoint.copy(healthState = EndpointHealthState.CONFIG_INVALID, lastError = configErr))
                lastErr = configErr
                continue
            }
            if (!bypassCooldown && endpoint.isInCooldown(now)) {
                lastErr = "Endpoint ${endpoint.name} in cooldown until ${endpoint.cooldownUntilEpochMs}"
                continue
            }
            if (!bypassCooldown && circuitBreakerManager?.allowRequest(CircuitBreakerTargetType.BOOTSTRAP, endpoint.baseUrl) == false) {
                lastErr = "Bootstrap circuit breaker OPEN for ${endpoint.name}"
                continue
            }

            val client = buildClientForEndpoint(endpoint)
            val attemptResult = queryEndpointForPeers(client, endpoint, cfg, limit, now)
            if (attemptResult.isSuccess) {
                val outcome = attemptResult.getOrThrow()
                circuitBreakerManager?.recordSuccess(CircuitBreakerTargetType.BOOTSTRAP, endpoint.baseUrl)
                val healthyEp = endpoint.copy(
                    healthState = EndpointHealthState.HEALTHY,
                    lastAttemptMs = now,
                    lastSuccessfulConnectionMs = now,
                    consecutiveFailures = 0,
                    cooldownUntilEpochMs = 0L,
                    lastError = null
                )
                replaceEndpoint(updatedEndpoints, healthyEp)
                updateBootstrapList(updatedEndpoints)
                persistConfig(_activeProfileConfig.value)

                _lastBootstrapSuccessMs.value = now
                _lastDirectoryRefreshMs.value = now
                _lastErrorSummary.value = null

                ingestValidatedPeersIntoRegistry(outcome.validPeersAccepted)
                return@withContext Result.success(outcome)
            } else {
                val errMsg = attemptResult.exceptionOrNull()?.message ?: "Bootstrap query failed"
                circuitBreakerManager?.recordFailure(CircuitBreakerTargetType.BOOTSTRAP, endpoint.baseUrl, errMsg)
                lastErr = errMsg
                val failures = endpoint.consecutiveFailures + 1
                val backoffMs = BootstrapEndpointConfig.computeBackoffWithJitterMs(failures)
                val failedEp = endpoint.copy(
                    healthState = EndpointHealthState.COOLDOWN,
                    lastAttemptMs = now,
                    consecutiveFailures = failures,
                    cooldownUntilEpochMs = now + backoffMs,
                    lastError = errMsg
                )
                replaceEndpoint(updatedEndpoints, failedEp)
            }
        }

        updateBootstrapList(updatedEndpoints)
        _lastErrorSummary.value = lastErr
        Result.failure(IllegalStateException(lastErr))
    }

    /**
     * Publishes ONLY non-sensitive public Node ID + Ed25519 pubkey + reachable endpoint info
     * to healthy bootstrap directories. Never transmits private keys or session keys.
     */
    suspend fun registerLocalNodeWithBootstrap(
        advertisedHost: String,
        advertisedPort: Int,
        capabilities: List<String> = listOf("p2p", "stage7_discovery", "stage14_ice", "block_sync")
    ): Result<String> = withContext(ioDispatcher) {
        val identity = identityManager.getActiveIdentity()
            ?: return@withContext Result.failure(IllegalStateException("Local identity not initialized"))
        val cfg = _activeProfileConfig.value
        val ordered = cfg.bootstrapEndpoints
            .filter { it.isEnabled && it.validateForProfile(cfg.profile, cfg.allowLocalTestOverride) == null }
            .sortedBy { it.priority }

        if (ordered.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("No valid bootstrap endpoint configured"))
        }

        val regTimestampMs = clockMs()
        val canonicalReg = "${identity.nodeId}|${identity.publicKeyHex}|$advertisedHost|$advertisedPort|${cfg.chainId}|$regTimestampMs"
        val sigBytes = runCatching {
            identityManager.repository.signRawData(canonicalReg.toByteArray(Charsets.UTF_8))
        }.getOrElse { return@withContext Result.failure(it) }
        val sigHex = cryptoProvider.toHex(sigBytes)

        val bodyJson = JSONObject().apply {
            put("node_id", identity.nodeId)
            put("public_key_hex", identity.publicKeyHex)
            put("protocol_version", cfg.protocolVersion)
            put("chain_id", cfg.chainId)
            put("genesis_hash", cfg.expectedGenesisHash)
            put("host", advertisedHost)
            put("port", advertisedPort)
            put("timestamp_ms", regTimestampMs)
            put("signature_hex", sigHex)
            put("availability_status", "ONLINE")
            put("capabilities", org.json.JSONArray().apply { capabilities.forEach { put(it) } })
        }.toString()

        var lastErr = "Registration failed"
        for (ep in ordered) {
            try {
                val client = buildClientForEndpoint(ep)
                val req = Request.Builder()
                    .url("${ep.baseUrl}/v1/peers/register")
                    .post(bodyJson.toRequestBody(JSON_MEDIA))
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        return@withContext Result.success(ep.id)
                    } else {
                        lastErr = "HTTP ${resp.code}: ${resp.body?.string()?.take(160)}"
                    }
                }
            } catch (e: Exception) {
                lastErr = e.message ?: "Network error"
            }
        }
        Result.failure(IllegalStateException(lastErr))
    }

    private fun probeSingleHealth(
        endpoint: BootstrapEndpointConfig,
        cfg: NetworkProfileConfig
    ): BootstrapEndpointConfig {
        val now = clockMs()
        return try {
            val client = buildClientForEndpoint(endpoint)
            val req = Request.Builder().url("${endpoint.baseUrl}/health").get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return markEndpointFailure(endpoint, now, "Health HTTP ${resp.code}")
                }
                val raw = resp.body?.string()?.take(MAX_JSON_RESPONSE_BYTES.toInt()).orEmpty()
                val json = JSONObject(raw)
                val chainId = json.optString("chain_id", "")
                val genesis = json.optString("genesis_hash", "")
                if (chainId != cfg.chainId || !genesis.equals(cfg.expectedGenesisHash, ignoreCase = true)) {
                    return markEndpointFailure(endpoint, now, "Health Chain ID or Genesis Hash mismatch")
                }
                endpoint.copy(
                    healthState = EndpointHealthState.HEALTHY,
                    lastAttemptMs = now,
                    lastSuccessfulConnectionMs = now,
                    consecutiveFailures = 0,
                    cooldownUntilEpochMs = 0L,
                    lastError = null
                )
            }
        } catch (e: Exception) {
            markEndpointFailure(endpoint, now, e.message ?: "Health check failed")
        }
    }

    private fun queryEndpointForPeers(
        client: OkHttpClient,
        endpoint: BootstrapEndpointConfig,
        cfg: NetworkProfileConfig,
        limit: Int,
        nowMs: Long
    ): Result<BootstrapDiscoveryOutcome> {
        return try {
            // Step 1: Verify network-config first (Chain ID, genesis hash, optional signed response)
            val cfgReq = Request.Builder().url("${endpoint.baseUrl}/v1/network-config").get().build()
            client.newCall(cfgReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return Result.failure(IllegalStateException("Network config HTTP ${resp.code}"))
                }
                val bodyStr = resp.body?.string()?.take(MAX_JSON_RESPONSE_BYTES.toInt())
                    ?: return Result.failure(IllegalStateException("Empty network config response"))
                val json = JSONObject(bodyStr)
                val remoteChain = json.optString("chain_id", "")
                val remoteGenesis = json.optString("genesis_hash", "")
                val remoteProfile = json.optString("network_profile", "")
                if (remoteChain != cfg.chainId) {
                    return Result.failure(IllegalStateException("Chain ID mismatch: got $remoteChain expected ${cfg.chainId}"))
                }
                if (!remoteGenesis.equals(cfg.expectedGenesisHash, ignoreCase = true)) {
                    return Result.failure(IllegalStateException("Genesis hash mismatch from ${endpoint.name}"))
                }
                if (remoteProfile.isNotBlank() && !remoteProfile.equals(cfg.profile.name, ignoreCase = true)) {
                    return Result.failure(IllegalStateException("Profile mismatch: $remoteProfile != ${cfg.profile.name}"))
                }

                // Verify optional Ed25519 signature if endpoint pins a bootstrap server public key
                val pinnedPub = endpoint.expectedPublicKeyHex
                if (!pinnedPub.isNullOrBlank()) {
                    val sigHex = json.optString("signature_hex", "")
                    val ts = json.optLong("timestamp_ms", -1L)
                    val proto = json.optInt("protocol_version", cfg.protocolVersion)
                    if (sigHex.isBlank() || ts <= 0L) {
                        return Result.failure(IllegalStateException("Missing required bootstrap signature"))
                    }
                    val canonical = "${remoteProfile.ifBlank { cfg.profile.name }}|$remoteChain|$remoteGenesis|$proto|$ts"
                    val sigOk = cryptoProvider.verify(
                        cryptoProvider.fromHex(pinnedPub),
                        canonical.toByteArray(Charsets.UTF_8),
                        cryptoProvider.fromHex(sigHex)
                    )
                    if (!sigOk) {
                        return Result.failure(IllegalStateException("Invalid bootstrap Ed25519 signature"))
                    }
                }
            }

            // Step 2: Request bounded peer directory for verified Chain ID & Genesis Hash
            val url = "${endpoint.baseUrl}/v1/peers?chain_id=${cfg.chainId}&genesis_hash=${cfg.expectedGenesisHash}&limit=$limit"
            val peersReq = Request.Builder().url(url).get().build()
            client.newCall(peersReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return Result.failure(IllegalStateException("Peer discovery HTTP ${resp.code}"))
                }
                val raw = resp.body?.string()?.take(MAX_JSON_RESPONSE_BYTES.toInt())
                    ?: return Result.failure(IllegalStateException("Empty peer response"))
                val json = JSONObject(raw)
                val remoteChain = json.optString("chain_id", "")
                val remoteGenesis = json.optString("genesis_hash", "")
                if (remoteChain != cfg.chainId || !remoteGenesis.equals(cfg.expectedGenesisHash, ignoreCase = true)) {
                    return Result.failure(IllegalStateException("Peer directory Chain ID / Genesis hash mismatch"))
                }

                val peersArr = json.optJSONArray("peers") ?: return Result.failure(IllegalStateException("Missing peers array"))
                val localNodeId = identityManager.getActiveIdentity()?.nodeId
                val accepted = mutableListOf<BootstrapPeerRecord>()
                var rejected = 0

                val pinnedPub = endpoint.expectedPublicKeyHex
                val seenIds = mutableSetOf<String>()
                val rawPeerIdsForSig = mutableListOf<String>()

                for (i in 0 until peersArr.length()) {
                    val obj = peersArr.optJSONObject(i)
                    if (obj == null) {
                        rejected++
                        continue
                    }
                    val parsed = BootstrapPeerRecord.fromJson(obj)
                    if (parsed == null) {
                        rejected++
                        continue
                    }
                    rawPeerIdsForSig.add(parsed.nodeId)

                    val validationErr = parsed.validateAgainst(cfg, localNodeId, nowMs)
                    if (validationErr != null || !seenIds.add(parsed.nodeId)) {
                        rejected++
                        continue
                    }
                    if (trustManager.isPeerRevoked(parsed.nodeId, parsed.publicKeyHex)) {
                        rejected++
                        continue
                    }
                    accepted.add(parsed)
                }

                if (!pinnedPub.isNullOrBlank()) {
                    val sigHex = json.optString("signature_hex", "")
                    val ts = json.optLong("timestamp_ms", -1L)
                    if (sigHex.isBlank() || ts <= 0L) {
                        return Result.failure(IllegalStateException("Missing peer directory Ed25519 signature"))
                    }
                    val summary = "${cfg.chainId}|${cfg.expectedGenesisHash}|$ts|${rawPeerIdsForSig.joinToString(",")}"
                    val sigOk = cryptoProvider.verify(
                        cryptoProvider.fromHex(pinnedPub),
                        summary.toByteArray(Charsets.UTF_8),
                        cryptoProvider.fromHex(sigHex)
                    )
                    if (!sigOk) {
                        return Result.failure(IllegalStateException("Invalid peer directory Ed25519 signature"))
                    }
                }

                Result.success(
                    BootstrapDiscoveryOutcome(
                        usedEndpointId = endpoint.id,
                        validPeersAccepted = accepted,
                        rejectedRecordsCount = rejected
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun ingestValidatedPeersIntoRegistry(peers: List<BootstrapPeerRecord>) {
        for (peer in peers) {
            // Security: advertised peers enter as REACHABLE + UNAUTHENTICATED only.
            // Live Stage 13 handshake must authenticate before any peer becomes trusted/connected.
            peerRegistry.registerOrUpdatePeer(
                peerId = peer.nodeId,
                endpoint = PeerEndpoint(peer.host, peer.port, peer.nodeId),
                source = DiscoverySource.BOOTSTRAP,
                publicKeyHex = peer.publicKeyHex,
                reachability = ReachabilityStatus.REACHABLE,
                isBootstrap = false,
                capabilities = peer.capabilities.ifEmpty { listOf("p2p", "stage7_discovery") }
            )
        }
    }

    private fun markEndpointFailure(
        endpoint: BootstrapEndpointConfig,
        nowMs: Long,
        reason: String
    ): BootstrapEndpointConfig {
        val failures = endpoint.consecutiveFailures + 1
        val backoff = BootstrapEndpointConfig.computeBackoffWithJitterMs(failures)
        return endpoint.copy(
            healthState = if (failures >= 3) EndpointHealthState.UNAVAILABLE else EndpointHealthState.COOLDOWN,
            lastAttemptMs = nowMs,
            consecutiveFailures = failures,
            cooldownUntilEpochMs = nowMs + backoff,
            lastError = reason
        )
    }

    private fun buildClientForEndpoint(endpoint: BootstrapEndpointConfig): OkHttpClient {
        val builder = baseHttpClient.newBuilder()
        // Explicit dual-stack IPv4 + IPv6 preference ordering
        builder.dns(object : Dns {
            override fun lookup(hostname: String): List<InetAddress> {
                val all = InetAddress.getAllByName(hostname).toList()
                return all.sortedBy { if (it is java.net.Inet6Address) 1 else 0 }
            }
        })
        val pin = endpoint.pinnedTlsSha256
        if (endpoint.protocol == BootstrapTransportProtocol.HTTPS && !pin.isNullOrBlank()) {
            val host = URI(endpoint.baseUrl).host ?: endpoint.host
            val pinner = CertificatePinner.Builder().add(host, pin).build()
            builder.certificatePinner(pinner)
        }
        return builder.build()
    }

    private fun replaceEndpoint(list: MutableList<BootstrapEndpointConfig>, updated: BootstrapEndpointConfig) {
        val idx = list.indexOfFirst { it.id == updated.id }
        if (idx >= 0) list[idx] = updated else list.add(updated)
    }

    private fun updateBootstrapList(updated: List<BootstrapEndpointConfig>) {
        _activeProfileConfig.value = _activeProfileConfig.value.copy(bootstrapEndpoints = updated)
    }

    private fun persistConfig(config: NetworkProfileConfig) {
        val sp = prefs ?: return
        try {
            sp.edit().putString(KEY_ACTIVE_PROFILE_CONFIG, config.toJson().toString()).apply()
        } catch (e: Exception) {
            Log.w(TAG, "Unable to persist Stage 15 config: ${e.message}")
        }
    }

    private fun loadPersistedOrDefaultConfig(): NetworkProfileConfig {
        val sp = prefs ?: return NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
        return try {
            val raw = sp.getString(KEY_ACTIVE_PROFILE_CONFIG, null)
                ?: return NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
            val parsed = NetworkProfileConfig.fromJson(JSONObject(raw))
                ?: return NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
            if (parsed.validate() == null) parsed
            else NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
        } catch (_: Exception) {
            NetworkProfileRegistry.defaultConfigFor(NmdNetworkProfile.DEVELOPMENT)
        }
    }
}
