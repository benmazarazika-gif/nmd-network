package com.example.p2p.reliable

import android.util.Log
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

enum class DeliveryStatus {
    PENDING_ACK,
    ACKNOWLEDGED,
    TIMED_OUT,
    FAILED
}

data class DeliveryResult(
    val messageId: String,
    val status: DeliveryStatus,
    val roundTripLatencyMs: Long = 0L,
    val attempts: Int = 1,
    val errorMessage: String? = null
) {
    val isSuccess: Boolean
        get() = status == DeliveryStatus.ACKNOWLEDGED
}

/**
 * MessageDeduplicationCache protects against processing duplicate messages.
 * Thread-safe sliding window with time-based eviction.
 */
class MessageDeduplicationCache(
    private val maxCapacity: Int = 2000,
    private val expirationMs: Long = 600_000L // 10 minutes
) {
    private val processedMessages = ConcurrentHashMap<String, Long>()
    private val mutex = Mutex()

    /**
     * Atomically checks if messageId has been processed.
     * Returns true if newly registered (first time seen), or false if it is a duplicate.
     */
    suspend fun checkAndMarkProcessed(messageId: String): Boolean = mutex.withLock {
        val now = System.currentTimeMillis()
        pruneExpired(now)

        val existing = processedMessages[messageId]
        if (existing != null && now - existing < expirationMs) {
            return false // Duplicate!
        }

        if (processedMessages.size >= maxCapacity) {
            val oldest = processedMessages.entries.minByOrNull { it.value }
            if (oldest != null) {
                processedMessages.remove(oldest.key)
            }
        }

        processedMessages[messageId] = now
        return true
    }

    private fun pruneExpired(now: Long) {
        processedMessages.entries.removeIf { now - it.value > expirationMs }
    }

    fun contains(messageId: String): Boolean {
        return processedMessages.containsKey(messageId)
    }

    fun size(): Int = processedMessages.size

    fun clear() {
        processedMessages.clear()
    }
}

/**
 * Outbound message delivery tracking state.
 */
internal class TrackedOutboundMessage(
    val message: P2pMessage,
    val targetSessionId: String,
    val sendAction: suspend (P2pMessage) -> Unit,
    val deferred: CompletableDeferred<DeliveryResult>,
    val maxRetries: Int,
    val ackTimeoutMs: Long,
    val creationTime: Long = System.currentTimeMillis(),
    var attemptCount: Int = 1,
    var retryJob: Job? = null
)

/**
 * ReliableDeliveryManager manages reliable message transmission, ACK verification,
 * duplicate suppression, controlled retries, and timeout handling.
 */
class ReliableDeliveryManager(
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val defaultMaxRetries: Int = 3,
    private val defaultAckTimeoutMs: Long = 2500L
) {
    companion object {
        private const val TAG = "ReliableDeliveryManager"
    }

    val deduplicationCache = MessageDeduplicationCache()
    private val pendingAcks = ConcurrentHashMap<String, TrackedOutboundMessage>()

    /**
     * Enqueues an outbound message for reliable delivery with automatic retry on timeout.
     */
    suspend fun sendReliably(
        message: P2pMessage,
        targetSessionId: String,
        sendAction: suspend (P2pMessage) -> Unit,
        maxRetries: Int = defaultMaxRetries,
        ackTimeoutMs: Long = defaultAckTimeoutMs
    ): DeliveryResult {
        // If message type does not require ACK (e.g. ACK, PING, PONG, ERROR, DISCONNECT), send once directly
        if (!message.messageType.requiresAck) {
            return try {
                sendAction(message)
                DeliveryResult(
                    messageId = message.messageId,
                    status = DeliveryStatus.ACKNOWLEDGED,
                    roundTripLatencyMs = 0L,
                    attempts = 1
                )
            } catch (e: Exception) {
                DeliveryResult(
                    messageId = message.messageId,
                    status = DeliveryStatus.FAILED,
                    attempts = 1,
                    errorMessage = e.message
                )
            }
        }

        val deferred = CompletableDeferred<DeliveryResult>()
        val tracked = TrackedOutboundMessage(
            message = message,
            targetSessionId = targetSessionId,
            sendAction = sendAction,
            deferred = deferred,
            maxRetries = maxRetries,
            ackTimeoutMs = ackTimeoutMs
        )

        pendingAcks[message.messageId] = tracked

        try {
            sendAction(message)
        } catch (e: Exception) {
            pendingAcks.remove(message.messageId)
            return DeliveryResult(
                messageId = message.messageId,
                status = DeliveryStatus.FAILED,
                attempts = 1,
                errorMessage = e.message
            )
        }

        // Schedule controlled retry loop
        tracked.retryJob = scope.launch(ioDispatcher) {
            scheduleRetry(tracked)
        }

        return deferred.await()
    }

    private suspend fun scheduleRetry(tracked: TrackedOutboundMessage) {
        var delayMs = tracked.ackTimeoutMs
        while (scope.isActive && tracked.attemptCount < tracked.maxRetries) {
            delay(delayMs)
            if (!pendingAcks.containsKey(tracked.message.messageId)) {
                return // Acknowledged or canceled
            }

            tracked.attemptCount++
            Log.d(TAG, "Retrying delivery for message ${tracked.message.messageId} (Attempt ${tracked.attemptCount}/${tracked.maxRetries})")

            try {
                tracked.sendAction(tracked.message)
            } catch (e: Exception) {
                Log.w(TAG, "Failed retry send for message ${tracked.message.messageId}: ${e.message}")
            }

            // Exponential backoff with ceiling
            delayMs = Math.min(delayMs * 2, 8000L)
        }

        // Final timeout delay
        delay(delayMs)
        val removed = pendingAcks.remove(tracked.message.messageId)
        if (removed != null && !removed.deferred.isCompleted) {
            Log.w(TAG, "Message ${tracked.message.messageId} timed out after ${tracked.attemptCount} attempts")
            removed.deferred.complete(
                DeliveryResult(
                    messageId = tracked.message.messageId,
                    status = DeliveryStatus.TIMED_OUT,
                    attempts = tracked.attemptCount,
                    errorMessage = "Timed out waiting for peer acknowledgement after ${tracked.attemptCount} attempts"
                )
            )
        }
    }

    /**
     * Resolves pending delivery upon receipt of an ACK.
     */
    fun handleAckReceived(ackMessage: P2pMessage): Boolean {
        val originalMessageId = ackMessage.ackForMessageId ?: return false
        val tracked = pendingAcks.remove(originalMessageId) ?: return false

        tracked.retryJob?.cancel()
        val rttMs = Math.max(1L, System.currentTimeMillis() - tracked.creationTime)
        tracked.deferred.complete(
            DeliveryResult(
                messageId = originalMessageId,
                status = DeliveryStatus.ACKNOWLEDGED,
                roundTripLatencyMs = rttMs,
                attempts = tracked.attemptCount
            )
        )
        return true
    }

    /**
     * Cancels any pending ACKs for a terminated session.
     */
    fun cancelSessionPendingMessages(sessionId: String, reason: String = "Session disconnected") {
        pendingAcks.entries.removeIf { (_, tracked) ->
            if (tracked.targetSessionId == sessionId) {
                tracked.retryJob?.cancel()
                tracked.deferred.complete(
                    DeliveryResult(
                        messageId = tracked.message.messageId,
                        status = DeliveryStatus.FAILED,
                        attempts = tracked.attemptCount,
                        errorMessage = reason
                    )
                )
                true
            } else {
                false
            }
        }
    }

    fun getPendingCount(): Int = pendingAcks.size

    fun clear() {
        pendingAcks.values.forEach {
            it.retryJob?.cancel()
            it.deferred.cancel()
        }
        pendingAcks.clear()
        deduplicationCache.clear()
    }
}
