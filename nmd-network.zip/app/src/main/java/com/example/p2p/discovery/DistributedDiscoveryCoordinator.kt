package com.example.p2p.discovery

import android.content.Context
import android.util.Log
import com.example.crypto.NodeIdentityManager
import com.example.p2p.discovery.bootstrap.BootstrapPeer
import com.example.p2p.discovery.bootstrap.BootstrapPeerManager
import com.example.p2p.discovery.pex.PeerExchangeService
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.PeerFilterOption
import com.example.p2p.discovery.registry.PeerRegistryRecord
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.discovery.topology.NetworkTopologyManager
import com.example.p2p.discovery.topology.TopologyMetrics
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.DiscoveredPeer
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerInfo
import com.example.p2p.service.ReliableP2pMessagingService
import com.example.p2p.session.PeerSession
import com.example.p2p.transport.P2PTransport
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap

enum class DiscoveryStatusState {
    IDLE,
    DISCOVERING_LOCAL,
    EXCHANGING_PEERS,
    BOOTSTRAPPING,
    ERROR
}

enum class DiscoveryMethod {
    NONE,
    LOCAL_NSD,
    PEER_EXCHANGE,
    BOOTSTRAP,
    HYBRID
}

/**
 * DistributedDiscoveryCoordinator unifies Stage 7 distributed peer discovery:
 * - Local Network NSD discovery (Stage 5 extension)
 * - Distributed Peer Registry (persistent metadata, trust/reputation, expiration)
 * - Peer Exchange Protocol (PEX via Stage 6 reliable messaging)
 * - Configurable Bootstrap Peers (with exponential backoff)
 * - Topology management & metrics
 *
 * Designed for Android battery efficiency with bounded intervals and clean coroutine lifecycle.
 */
class DistributedDiscoveryCoordinator(
    private val context: Context,
    private val identityManager: NodeIdentityManager,
    private val transport: P2PTransport,
    private val discoveryService: PeerDiscoveryService,
    private val connectionManager: PeerConnectionManager,
    private val reliableMessagingService: ReliableP2pMessagingService,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    val peerRegistry: DistributedPeerRegistry = DistributedPeerRegistry(context, scope, ioDispatcher),
    val peerExchangeService: PeerExchangeService = PeerExchangeService(identityManager, peerRegistry),
    val bootstrapManager: BootstrapPeerManager = BootstrapPeerManager(context, peerRegistry, connectionManager, scope, ioDispatcher),
    val topologyManager: NetworkTopologyManager = connectionManager.topologyManager
) : Closeable {

    companion object {
        private const val TAG = "DiscoveryCoordinator"
        private const val MAINTENANCE_INTERVAL_MS = 60_000L
    }

    private val _discoveryStatus = MutableStateFlow(DiscoveryStatusState.IDLE)
    val discoveryStatus: StateFlow<DiscoveryStatusState> = _discoveryStatus.asStateFlow()

    private val _activeDiscoveryMethod = MutableStateFlow(DiscoveryMethod.NONE)
    val activeDiscoveryMethod: StateFlow<DiscoveryMethod> = _activeDiscoveryMethod.asStateFlow()

    private val _lastSuccessfulDiscoveryMs = MutableStateFlow<Long?>(null)
    val lastSuccessfulDiscoveryMs: StateFlow<Long?> = _lastSuccessfulDiscoveryMs.asStateFlow()

    private val _topologyMetrics = MutableStateFlow(TopologyMetrics())
    val topologyMetrics: StateFlow<TopologyMetrics> = _topologyMetrics.asStateFlow()

    val registeredPeers: StateFlow<List<PeerRegistryRecord>> = peerRegistry.peers
    val bootstrapPeers: StateFlow<List<BootstrapPeer>> = bootstrapManager.bootstrapPeers

    // Tracks sessions for which we already exchanged initial PEX list to prevent storms
    private val pexSyncedSessionIds = ConcurrentHashMap.newKeySet<String>()
    private var previousConnectedPeerIds = emptySet<String>()

    private var registryCollectorJob: Job? = null
    private var sessionCollectorJob: Job? = null
    private var bootstrapCollectorJob: Job? = null
    private var listeningStateJob: Job? = null
    private var maintenanceJob: Job? = null

    init {
        // Wire PEX service into Stage 6 reliable messaging
        reliableMessagingService.peerExchangeService = peerExchangeService
        reliableMessagingService.localHostPortProvider = {
            Pair(transport.getLocalIpAddress(), transport.boundPort.value ?: 0)
        }
        reliableMessagingService.onPexPeersIngested = { newCount, updatedCount ->
            if (newCount > 0 || updatedCount > 0) {
                _lastSuccessfulDiscoveryMs.value = System.currentTimeMillis()
                updateDiscoveryMethod(DiscoveryMethod.PEER_EXCHANGE)
                recomputeMetrics()
            }
        }

        // 1. Wire Stage 5 Local NSD callbacks
        discoveryService.onPeerDiscovered = { peer ->
            handleLocalPeerDiscovered(peer)
        }
        discoveryService.onPeerLost = { serviceName ->
            handleLocalPeerLost(serviceName)
        }

        // 2. React to listening state changes
        listeningStateJob = scope.launch(ioDispatcher) {
            transport.isListening.collect { listening ->
                if (listening) {
                    _discoveryStatus.value = DiscoveryStatusState.DISCOVERING_LOCAL
                    updateDiscoveryMethod(DiscoveryMethod.LOCAL_NSD)
                } else {
                    _discoveryStatus.value = DiscoveryStatusState.IDLE
                }
            }
        }

        // 3. React to Stage 6 active sessions (sync registry auth & trigger controlled PEX handshake)
        sessionCollectorJob = scope.launch(ioDispatcher) {
            reliableMessagingService.sessions.collect { sessions ->
                handleSessionsChanged(sessions)
            }
        }

        // 4. Recompute metrics whenever registry or bootstrap list changes
        registryCollectorJob = scope.launch(ioDispatcher) {
            peerRegistry.peers.collect {
                recomputeMetrics()
            }
        }
        bootstrapCollectorJob = scope.launch(ioDispatcher) {
            bootstrapManager.bootstrapPeers.collect {
                recomputeMetrics()
            }
        }

        // 5. Battery-efficient maintenance ticker (every 60s)
        maintenanceJob = scope.launch(ioDispatcher) {
            while (isActive) {
                delay(MAINTENANCE_INTERVAL_MS)
                peerRegistry.pruneStalePeers()
                peerRegistry.removeExpiredPeers()
                recomputeMetrics()
            }
        }

        recomputeMetrics()
    }

    private fun handleLocalPeerDiscovered(peer: DiscoveredPeer) {
        val peerId = peer.advertisedNodeId ?: "nsd_${peer.host}_${peer.port}"
        val source = if (peer.serviceName.startsWith("Manual-")) DiscoverySource.MANUAL else DiscoverySource.LOCAL_NSD
        peerRegistry.registerOrUpdatePeer(
            peerId = peerId,
            endpoint = PeerEndpoint(peer.host, peer.port, peer.advertisedNodeId),
            source = source,
            reachability = ReachabilityStatus.REACHABLE
        )
        _lastSuccessfulDiscoveryMs.value = System.currentTimeMillis()
        updateDiscoveryMethod(DiscoveryMethod.LOCAL_NSD)
        recomputeMetrics()
    }

    private fun handleLocalPeerLost(peer: DiscoveredPeer) {
        val id = peer.advertisedNodeId ?: "nsd_${peer.host}_${peer.port}"
        peerRegistry.updateReachability(id, ReachabilityStatus.UNREACHABLE)
        recomputeMetrics()
    }

    private fun handleSessionsChanged(sessions: List<PeerSession>) {
        val currentPeerIds = sessions.map { it.peerId }.toSet()

        // Mark previously connected peers that disappeared as disconnected (no longer live-authenticated)
        previousConnectedPeerIds.filter { !currentPeerIds.contains(it) }.forEach { disconnectedId ->
            peerRegistry.recordDisconnected(disconnectedId)
        }
        previousConnectedPeerIds = currentPeerIds

        // Prune stale session keys
        val activeSessionIds = sessions.map { it.sessionId }.toSet()
        pexSyncedSessionIds.removeIf { !activeSessionIds.contains(it) }

        // Ensure connected authenticated peers are updated in registry and run initial PEX once
        sessions.forEach { session ->
            val existing = peerRegistry.getPeer(session.peerId)
            if (existing == null) {
                peerRegistry.registerOrUpdatePeer(
                    peerId = session.peerId,
                    endpoint = session.endpoint,
                    source = if (session.isOutbound) DiscoverySource.MANUAL else DiscoverySource.LOCAL_NSD,
                    publicKeyHex = session.remotePublicKeyHex,
                    reachability = ReachabilityStatus.CONNECTED
                )
            }
            peerRegistry.recordSuccessfulAuth(session.peerId, session.remotePublicKeyHex)

            if (session.isTrusted && pexSyncedSessionIds.add(session.sessionId)) {
                scope.launch(ioDispatcher) {
                    sendInitialPexForSession(session)
                }
            }
        }

        recomputeMetrics()
    }

    private suspend fun sendInitialPexForSession(session: PeerSession) {
        val localHost = transport.getLocalIpAddress()
        val localPort = transport.boundPort.value ?: 0
        if (localPort > 0) {
            val announcement = peerExchangeService.createAnnouncementMessage(
                localHost = localHost,
                localPort = localPort,
                targetPeerId = session.peerId
            )
            if (announcement != null) {
                reliableMessagingService.sendPexMessage(session.sessionId, announcement)
            }
        }

        val listReq = peerExchangeService.createPeerListRequest(session.peerId)
        if (listReq != null) {
            _discoveryStatus.value = DiscoveryStatusState.EXCHANGING_PEERS
            reliableMessagingService.sendPexMessage(session.sessionId, listReq)
            _discoveryStatus.value = if (transport.isListening.value) {
                DiscoveryStatusState.DISCOVERING_LOCAL
            } else {
                DiscoveryStatusState.IDLE
            }
        }
    }

    /**
     * Triggers an immediate PEX peer-list exchange across all currently authenticated sessions.
     */
    suspend fun requestPeerExchangeFromAll(): Int {
        val sessions = reliableMessagingService.sessions.value.filter { it.isTrusted }
        if (sessions.isEmpty()) return 0

        _discoveryStatus.value = DiscoveryStatusState.EXCHANGING_PEERS
        var sentCount = 0
        sessions.forEach { session ->
            val req = peerExchangeService.createPeerListRequest(session.peerId)
            if (req != null) {
                val res = reliableMessagingService.sendPexMessage(session.sessionId, req)
                if (res.isSuccess) {
                    sentCount++
                }
            }
        }
        _discoveryStatus.value = if (transport.isListening.value) {
            DiscoveryStatusState.DISCOVERING_LOCAL
        } else {
            DiscoveryStatusState.IDLE
        }
        return sentCount
    }

    /**
     * Triggers local NSD discovery refresh + PEX exchange if listening/connected.
     */
    suspend fun refreshDiscovery() {
        val localNodeId = identityManager.getActiveIdentity()?.nodeId
        if (transport.isListening.value && localNodeId != null) {
            _discoveryStatus.value = DiscoveryStatusState.DISCOVERING_LOCAL
            discoveryService.stopDiscovery()
            delay(150L)
            discoveryService.startDiscovery(localNodeId)
        }
        requestPeerExchangeFromAll()
        peerRegistry.pruneStalePeers()
        recomputeMetrics()
    }

    /**
     * Attempts connection to a peer from the DistributedPeerRegistry.
     */
    suspend fun connectToRegistryPeer(peerId: String): Result<RealPeerInfo> {
        val record = peerRegistry.getPeer(peerId)
            ?: return Result.failure(IllegalArgumentException("Peer not found in registry: $peerId"))

        val result = connectionManager.connectToPeer(record.endpoint)
        if (result.isSuccess) {
            val info = result.getOrThrow()
            peerRegistry.recordSuccessfulAuth(info.authenticatedNodeId ?: peerId, info.authenticatedPublicKeyHex)
            _lastSuccessfulDiscoveryMs.value = System.currentTimeMillis()
        } else {
            peerRegistry.recordConnectionFailed(peerId)
        }
        recomputeMetrics()
        return result
    }

    suspend fun connectBootstrapPeer(id: String): Result<RealPeerInfo> {
        _discoveryStatus.value = DiscoveryStatusState.BOOTSTRAPPING
        val result = bootstrapManager.connectToBootstrapPeer(id)
        if (result.isSuccess) {
            _lastSuccessfulDiscoveryMs.value = System.currentTimeMillis()
            updateDiscoveryMethod(DiscoveryMethod.BOOTSTRAP)
        }
        _discoveryStatus.value = if (transport.isListening.value) {
            DiscoveryStatusState.DISCOVERING_LOCAL
        } else {
            DiscoveryStatusState.IDLE
        }
        recomputeMetrics()
        return result
    }

    fun addCustomBootstrapPeer(
        name: String,
        host: String,
        port: Int,
        expectedNodeId: String? = null
    ): BootstrapPeer {
        val added = bootstrapManager.addCustomBootstrapPeer(name, host, port, expectedNodeId)
        recomputeMetrics()
        return added
    }

    fun toggleBootstrapPeer(id: String, enabled: Boolean) {
        bootstrapManager.toggleBootstrapPeer(id, enabled)
        recomputeMetrics()
    }

    fun removeBootstrapPeer(id: String) {
        bootstrapManager.removeBootstrapPeer(id)
        recomputeMetrics()
    }

    fun getFilteredPeers(filter: PeerFilterOption): List<PeerRegistryRecord> {
        return peerRegistry.getFilteredPeers(filter)
    }

    private fun updateDiscoveryMethod(method: DiscoveryMethod) {
        val current = _activeDiscoveryMethod.value
        _activeDiscoveryMethod.value = when {
            current == DiscoveryMethod.NONE || current == method -> method
            else -> DiscoveryMethod.HYBRID
        }
    }

    private fun recomputeMetrics() {
        _topologyMetrics.value = topologyManager.computeMetrics(
            registry = peerRegistry,
            activeSessions = reliableMessagingService.sessions.value,
            bootstrapPeers = bootstrapManager.bootstrapPeers.value
        )
    }

    override fun close() {
        registryCollectorJob?.cancel()
        sessionCollectorJob?.cancel()
        bootstrapCollectorJob?.cancel()
        listeningStateJob?.cancel()
        maintenanceJob?.cancel()
        bootstrapManager.close()
        peerRegistry.close()
    }
}
