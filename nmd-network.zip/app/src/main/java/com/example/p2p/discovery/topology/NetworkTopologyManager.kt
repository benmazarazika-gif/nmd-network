package com.example.p2p.discovery.topology

import com.example.p2p.discovery.bootstrap.BootstrapPeer
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.session.PeerSession

data class TopologyMetrics(
    val totalDiscoveredPeers: Int = 0,
    val authenticatedPeersCount: Int = 0,
    val connectedPeersCount: Int = 0,
    val directPeersCount: Int = 0,
    val indirectPeersCount: Int = 0,
    val stalePeersCount: Int = 0,
    val unreachablePeersCount: Int = 0,
    val bootstrapPeersCount: Int = 0
)

sealed class ConnectionAdmissionResult {
    object Allowed : ConnectionAdmissionResult()
    data class Rejected(val reason: String) : ConnectionAdmissionResult()
}

/**
 * NetworkTopologyManager governs peer connection limits, loop prevention,
 * and topology metrics for Stage 7.
 *
 * Enforces mobile-friendly resource limits:
 * - Max connected peers limit (default 8)
 * - Max outbound connections limit (default 4)
 * - Self-connection and loopback suppression
 * - Stale peer classification
 */
class NetworkTopologyManager(
    val maxConnectedPeers: Int = DEFAULT_MAX_CONNECTED_PEERS,
    val maxOutboundConnections: Int = DEFAULT_MAX_OUTBOUND_CONNECTIONS
) {
    companion object {
        const val DEFAULT_MAX_CONNECTED_PEERS = 8
        const val DEFAULT_MAX_OUTBOUND_CONNECTIONS = 4
    }

    /**
     * Checks whether an inbound peer connection can be accepted.
     */
    fun canAcceptInbound(currentConnectedCount: Int): ConnectionAdmissionResult {
        return if (currentConnectedCount < maxConnectedPeers) {
            ConnectionAdmissionResult.Allowed
        } else {
            ConnectionAdmissionResult.Rejected("Max connection limit reached ($maxConnectedPeers peers)")
        }
    }

    /**
     * Validates whether an outbound connection can be initiated.
     * Prevents self-connection loops and connection flooding.
     */
    fun validateOutboundConnection(
        targetEndpoint: PeerEndpoint,
        localNodeId: String,
        localPort: Int,
        localIp: String,
        currentOutboundCount: Int,
        activeEndpoints: Set<String>
    ): ConnectionAdmissionResult {
        // 1. Check connection capacity
        if (currentOutboundCount >= maxOutboundConnections) {
            return ConnectionAdmissionResult.Rejected("Max outbound connection limit reached ($maxOutboundConnections)")
        }

        // 2. Prevent self-connection loops (by Node ID)
        if (targetEndpoint.claimedNodeId != null && targetEndpoint.claimedNodeId.equals(localNodeId, ignoreCase = true)) {
            return ConnectionAdmissionResult.Rejected("Self-connection loop detected: Target Node ID matches local node")
        }

        // 3. Prevent self-connection loops (by IP & Port)
        val isLocalIp = targetEndpoint.host == localIp ||
                targetEndpoint.host == "127.0.0.1" ||
                targetEndpoint.host == "localhost"

        if (isLocalIp && targetEndpoint.port == localPort && localPort > 0) {
            return ConnectionAdmissionResult.Rejected("Self-connection loop detected: Target address matches local listening port ($localPort)")
        }

        // 4. Prevent duplicate connection to already active endpoint
        val targetKey = "${targetEndpoint.host}:${targetEndpoint.port}"
        if (activeEndpoints.contains(targetKey)) {
            return ConnectionAdmissionResult.Rejected("Already connected or connecting to $targetKey")
        }

        return ConnectionAdmissionResult.Allowed
    }

    /**
     * Aggregates topology metrics from the peer registry and active sessions.
     */
    fun computeMetrics(
        registry: DistributedPeerRegistry,
        activeSessions: List<PeerSession>,
        bootstrapPeers: List<BootstrapPeer>
    ): TopologyMetrics {
        val peers = registry.peers.value
        val connectedCount = activeSessions.size
        val authenticatedCount = peers.count { it.isAuthenticated }
        val directCount = peers.count { it.discoverySource == DiscoverySource.LOCAL_NSD || it.discoverySource == DiscoverySource.MANUAL }
        val indirectCount = peers.count { it.discoverySource == DiscoverySource.PEER_EXCHANGE }
        val staleCount = peers.count { it.reachabilityStatus == ReachabilityStatus.STALE }
        val unreachableCount = peers.count { it.reachabilityStatus == ReachabilityStatus.UNREACHABLE }
        val bootstrapCount = bootstrapPeers.size

        return TopologyMetrics(
            totalDiscoveredPeers = peers.size,
            authenticatedPeersCount = authenticatedCount,
            connectedPeersCount = connectedCount,
            directPeersCount = directCount,
            indirectPeersCount = indirectCount,
            stalePeersCount = staleCount,
            unreachablePeersCount = unreachableCount,
            bootstrapPeersCount = bootstrapCount
        )
    }

    /**
     * Stage 16: Evaluates decentralized topology diversity and structural risk without any
     * centralized coordinator or loop-creating forwarding.
     */
    fun analyzeTopologyHealth(
        registry: DistributedPeerRegistry,
        connectedPeers: List<com.example.p2p.model.RealPeerInfo>,
        peerTrafficCounts: Map<String, Long> = emptyMap(),
        peerHealthScores: Map<String, Int> = emptyMap()
    ): com.example.p2p.scalability.model.TopologyHealthReport {
        val allPeers = registry.peers.value
        val connectedById = connectedPeers.mapNotNull { info ->
            info.authenticatedNodeId?.let { id -> id to info }
        }.toMap()

        val sourceDistribution = linkedMapOf<DiscoverySource, Int>()
        val subnetPrefixes = linkedSetOf<String>()
        val pathDistribution = linkedMapOf<com.example.p2p.connectivity.model.TransportPathType, Int>()

        connectedPeers.forEach { peer ->
            val reg = peer.authenticatedNodeId?.let { registry.getPeer(it) }
            val src = reg?.discoverySource ?: DiscoverySource.MANUAL
            sourceDistribution[src] = (sourceDistribution[src] ?: 0) + 1
            subnetPrefixes.add(extractSubnetPrefix(peer.endpoint.host))
            pathDistribution[peer.transportPathType] = (pathDistribution[peer.transportPathType] ?: 0) + 1
        }

        val totalTraffic = peerTrafficCounts.values.sum().coerceAtLeast(0L)
        val maxPeerTraffic = peerTrafficCounts.values.maxOrNull() ?: 0L
        val dominantSharePct = when {
            connectedPeers.size == 1 -> 100
            totalTraffic > 0L -> ((maxPeerTraffic * 100L) / totalTraffic).toInt().coerceIn(0, 100)
            else -> if (connectedPeers.isEmpty()) 0 else (100 / connectedPeers.size)
        }

        val availableHealthyCandidates = allPeers.filter { rec ->
            !connectedById.containsKey(rec.peerId) &&
                rec.reachabilityStatus != ReachabilityStatus.UNREACHABLE &&
                rec.reachabilityStatus != ReachabilityStatus.STALE &&
                rec.authenticationStatus != com.example.p2p.discovery.registry.PeerAuthStatus.REVOKED
        }

        val isIsolatedRisk = connectedPeers.isEmpty() || (connectedPeers.size == 1 && availableHealthyCandidates.isNotEmpty())
        val isPoorlyConnectedRegion = connectedPeers.size in 1..2 && subnetPrefixes.size <= 1 && availableHealthyCandidates.size >= 2
        val isSinglePeerDependencyRisk = connectedPeers.size >= 1 && (dominantSharePct >= 75 || (connectedPeers.size == 1 && allPeers.size > 1))

        val replacementRecommendations = connectedById.keys.filter { peerId ->
            val hScore = peerHealthScores[peerId] ?: 100
            hScore < 40
        }.take(4)

        val candidateRecommendations = availableHealthyCandidates
            .sortedWith(
                compareByDescending<com.example.p2p.discovery.registry.PeerRegistryRecord> {
                    if (!subnetPrefixes.contains(extractSubnetPrefix(it.endpoint.host))) 1 else 0
                }.thenByDescending { it.reputationScore }
            )
            .take(5)
            .map { it.peerId }

        var score = 100
        if (connectedPeers.isEmpty()) score -= 60
        else if (connectedPeers.size == 1) score -= 35
        else if (connectedPeers.size == 2) score -= 15
        if (sourceDistribution.size <= 1 && connectedPeers.size > 1) score -= 10
        if (subnetPrefixes.size <= 1 && connectedPeers.size > 2) score -= 10
        if (isSinglePeerDependencyRisk && connectedPeers.size > 1) score -= 20
        if (replacementRecommendations.isNotEmpty()) score -= (replacementRecommendations.size * 8)

        return com.example.p2p.scalability.model.TopologyHealthReport(
            topologyHealthScore = score.coerceIn(0, 100),
            uniqueSourceCount = sourceDistribution.size,
            sourceDistribution = sourceDistribution,
            uniqueSubnetPrefixCount = subnetPrefixes.size,
            uniqueTransportPathCount = pathDistribution.size,
            transportPathDistribution = pathDistribution,
            isIsolatedNodeRisk = isIsolatedRisk,
            isPoorlyConnectedRegion = isPoorlyConnectedRegion,
            isSinglePeerDependencyRisk = isSinglePeerDependencyRisk,
            dominantPeerSharePercent = dominantSharePct,
            recommendedReplacementPeerIds = replacementRecommendations,
            recommendedCandidatePeerIds = candidateRecommendations
        )
    }

    private fun extractSubnetPrefix(host: String): String {
        val clean = host.trim().lowercase()
        val ipv4Parts = clean.split('.')
        return if (ipv4Parts.size == 4 && ipv4Parts.all { it.toIntOrNull() in 0..255 }) {
            "${ipv4Parts[0]}.${ipv4Parts[1]}"
        } else if (clean.contains(':')) {
            clean.split(':').take(3).joinToString(":")
        } else {
            clean.substringAfter('.', clean)
        }
    }
}
