package com.example.p2p.scalability.resource

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.StatFs
import com.example.data.DeviceResourceMonitor
import com.example.data.DeviceTelemetry
import com.example.p2p.scalability.model.DeviceResourceMode
import com.example.p2p.scalability.model.DeviceResourceSnapshot
import com.example.p2p.scalability.model.ResourceModePolicy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/**
 * Monitors real device battery, temperature, RAM pressure, storage space,
 * CPU load (nullable where Android restricts /proc), network type/quality,
 * and computes configurable operational modes: LOW_RESOURCE, BALANCED, HIGH_CAPABILITY.
 *
 * Adapts peer caps, discovery intervals, and sync batch sizes without ever
 * bypassing Stage 13 encryption, Ed25519 signature checks, or Stage 10 BFT safety.
 */
class DeviceNetworkResourceMonitor(
    private val context: Context?,
    private val baseMonitor: DeviceResourceMonitor? = context?.let { DeviceResourceMonitor(it) },
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private val _snapshot = MutableStateFlow(sampleResourceSnapshot())
    val snapshot: StateFlow<DeviceResourceSnapshot> = _snapshot.asStateFlow()

    @Volatile
    private var manualOverrideMode: DeviceResourceMode? = null

    fun setManualModeOverride(mode: DeviceResourceMode?): DeviceResourceSnapshot {
        manualOverrideMode = mode
        return sampleAndPublish()
    }

    fun evaluateFromMetrics(
        batteryPercent: Int?,
        isCharging: Boolean?,
        batteryTemperatureCelsius: Float?,
        availableRamMb: Long,
        totalRamMb: Long,
        isLowRam: Boolean,
        cpuLoadEstimatePercent: Float?,
        availableStorageMb: Long,
        networkType: String,
        isMeteredNetwork: Boolean,
        connectionQualityScore: Int
    ): DeviceResourceSnapshot {
        val computedMode = manualOverrideMode ?: classifyMode(
            batteryPercent = batteryPercent,
            isCharging = isCharging,
            batteryTemperatureCelsius = batteryTemperatureCelsius,
            availableRamMb = availableRamMb,
            isLowRam = isLowRam,
            cpuLoadPercent = cpuLoadEstimatePercent,
            availableStorageMb = availableStorageMb,
            networkType = networkType,
            isMetered = isMeteredNetwork,
            qualityScore = connectionQualityScore
        )
        val snap = DeviceResourceSnapshot(
            mode = computedMode,
            isManualOverride = manualOverrideMode != null,
            batteryPercent = batteryPercent,
            isCharging = isCharging,
            batteryTemperatureCelsius = batteryTemperatureCelsius,
            availableRamMb = availableRamMb,
            totalRamMb = totalRamMb,
            isLowRam = isLowRam,
            cpuLoadEstimatePercent = cpuLoadEstimatePercent,
            availableStorageMb = availableStorageMb,
            networkType = networkType,
            isMeteredNetwork = isMeteredNetwork,
            connectionQualityScore = connectionQualityScore.coerceIn(0, 100),
            policy = ResourceModePolicy.forMode(computedMode),
            sampledAtMs = clockMs()
        )
        _snapshot.value = snap
        return snap
    }

    fun sampleAndPublish(): DeviceResourceSnapshot {
        val snap = sampleResourceSnapshot()
        _snapshot.value = snap
        return snap
    }

    fun sampleResourceSnapshot(): DeviceResourceSnapshot {
        val ctx = context
        if (ctx == null || baseMonitor == null) {
            val rt = Runtime.getRuntime()
            val freeMb = ((rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())) / (1024L * 1024L)).coerceAtLeast(128L)
            val totalMb = (rt.maxMemory() / (1024L * 1024L)).coerceAtLeast(256L)
            val mode = manualOverrideMode ?: DeviceResourceMode.BALANCED
            return DeviceResourceSnapshot(
                mode = mode,
                isManualOverride = manualOverrideMode != null,
                availableRamMb = freeMb,
                totalRamMb = totalMb,
                isLowRam = false,
                cpuLoadEstimatePercent = readSafeCpuLoadPercent(),
                availableStorageMb = 1024L,
                networkType = "JVM_TEST",
                connectionQualityScore = 80,
                policy = ResourceModePolicy.forMode(mode),
                sampledAtMs = clockMs()
            )
        }

        val monitor = baseMonitor ?: return sampleResourceSnapshot()
        val telemetry: DeviceTelemetry = runCatching { monitor.sampleDeviceTelemetry() }.getOrDefault(DeviceTelemetry())
        val batteryTemp = readBatteryTemperatureCelsius(ctx)
        val availableStorageMb = readAvailableStorageMb(ctx)
        val (isMetered, qualityScore) = readNetworkQuality(ctx, telemetry.networkType)
        val cpuLoad = readSafeCpuLoadPercent()
        val availRam = telemetry.availableRamMb ?: 0L
        val totalRam = telemetry.totalRamMb ?: 0L

        val computedMode = manualOverrideMode ?: classifyMode(
            batteryPercent = telemetry.batteryPercent,
            isCharging = telemetry.isCharging,
            batteryTemperatureCelsius = batteryTemp,
            availableRamMb = availRam,
            isLowRam = telemetry.isLowRam,
            cpuLoadPercent = cpuLoad,
            availableStorageMb = availableStorageMb,
            networkType = telemetry.networkType,
            isMetered = isMetered,
            qualityScore = qualityScore
        )

        return DeviceResourceSnapshot(
            mode = computedMode,
            isManualOverride = manualOverrideMode != null,
            batteryPercent = telemetry.batteryPercent,
            isCharging = telemetry.isCharging,
            batteryTemperatureCelsius = batteryTemp,
            availableRamMb = availRam,
            totalRamMb = totalRam,
            isLowRam = telemetry.isLowRam,
            cpuLoadEstimatePercent = cpuLoad,
            availableStorageMb = availableStorageMb,
            networkType = telemetry.networkType,
            isMeteredNetwork = isMetered,
            connectionQualityScore = qualityScore,
            policy = ResourceModePolicy.forMode(computedMode),
            sampledAtMs = clockMs()
        )
    }

    private fun classifyMode(
        batteryPercent: Int?,
        isCharging: Boolean?,
        batteryTemperatureCelsius: Float?,
        availableRamMb: Long,
        isLowRam: Boolean,
        cpuLoadPercent: Float?,
        availableStorageMb: Long,
        networkType: String,
        isMetered: Boolean,
        qualityScore: Int
    ): DeviceResourceMode {
        val unchargingLowBattery = batteryPercent != null && batteryPercent <= 20 && isCharging != true
        val overheated = batteryTemperatureCelsius != null && batteryTemperatureCelsius >= 43.0f
        val memoryTight = isLowRam || (availableRamMb in 1L..250L)
        val storageTight = availableStorageMb in 1L..150L
        val cpuHeavy = cpuLoadPercent != null && cpuLoadPercent >= 85.0f
        val poorNetwork = networkType == "Unavailable" || qualityScore < 30

        if (unchargingLowBattery || overheated || memoryTight || storageTight || poorNetwork) {
            return DeviceResourceMode.LOW_RESOURCE
        }

        val highPower = (isCharging == true || (batteryPercent != null && batteryPercent >= 65))
        val highNetwork = !isMetered && (networkType == "Wi-Fi" || networkType == "Ethernet") && qualityScore >= 75
        val comfortableRam = availableRamMb >= 900L || availableRamMb == 0L
        val lowCpu = cpuLoadPercent == null || cpuLoadPercent < 65.0f

        if (highPower && highNetwork && comfortableRam && !cpuHeavy && lowCpu) {
            return DeviceResourceMode.HIGH_CAPABILITY
        }
        return DeviceResourceMode.BALANCED
    }

    private fun readBatteryTemperatureCelsius(ctx: Context): Float? {
        return try {
            val intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenthsC = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            if (tenthsC != null && tenthsC != Int.MIN_VALUE && tenthsC > -400 && tenthsC < 1200) {
                tenthsC / 10.0f
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readAvailableStorageMb(ctx: Context): Long {
        return try {
            val stat = StatFs(ctx.filesDir.absolutePath)
            stat.availableBytes / (1024L * 1024L)
        } catch (_: Exception) {
            0L
        }
    }

    private fun readSafeCpuLoadPercent(): Float? {
        return try {
            val loadFile = File("/proc/loadavg")
            if (loadFile.canRead()) {
                val first = loadFile.readText().trim().split(Regex("\\s+")).firstOrNull()?.toFloatOrNull()
                if (first != null) {
                    val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
                    ((first / cores) * 100f).coerceIn(0f, 100f)
                } else {
                    null
                }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readNetworkQuality(ctx: Context, networkType: String): Pair<Boolean, Int> {
        if (networkType == "Unavailable") return false to 0
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false to 35
            val caps = cm.getNetworkCapabilities(network) ?: return false to 35
            val isMetered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            val downstreamKbps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                caps.linkDownstreamBandwidthKbps
            } else {
                10_000
            }
            var score = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 95
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 85
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> if (downstreamKbps >= 5_000) 65 else 40
                else -> 50
            }
            if (!validated && networkType != "Wi-Fi") score = (score - 20).coerceAtLeast(15)
            isMetered to score.coerceIn(0, 100)
        } catch (_: Exception) {
            false to 60
        }
    }
}
