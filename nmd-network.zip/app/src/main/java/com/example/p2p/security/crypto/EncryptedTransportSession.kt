package com.example.p2p.security.crypto

import org.bouncycastle.crypto.InvalidCipherTextException
import org.bouncycastle.crypto.modes.ChaCha20Poly1305
import org.bouncycastle.crypto.params.AEADParameters
import org.bouncycastle.crypto.params.KeyParameter
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Sliding replay window for monotonic per-direction AEAD frame sequence numbers.
 * Prevents duplicate encrypted frames, replayed frames, zero/negative sequences, and
 * stale out-of-window packets without conflating transport sequence with blockchain tx nonces.
 */
class ReplayWindowDetector(
    private val windowSize: Int = 256
) {
    private val lock = Any()
    private var highestSeq: Long = 0L
    private val seenInWindow = HashSet<Long>()

    sealed class CheckResult {
        object Accepted : CheckResult()
        data class Rejected(val reason: String, val isReplayOrDuplicate: Boolean) : CheckResult()
    }

    fun checkAndRecord(sequenceNumber: Long): CheckResult = synchronized(lock) {
        if (sequenceNumber <= 0L) {
            return CheckResult.Rejected("Invalid non-positive transport sequence number: $sequenceNumber", isReplayOrDuplicate = true)
        }
        if (sequenceNumber in seenInWindow) {
            return CheckResult.Rejected("Duplicate or replayed encrypted frame sequence #$sequenceNumber", isReplayOrDuplicate = true)
        }
        val minAllowed = (highestSeq - windowSize + 1L).coerceAtLeast(1L)
        if (sequenceNumber < minAllowed) {
            return CheckResult.Rejected("Stale encrypted frame sequence #$sequenceNumber below replay window [$minAllowed..$highestSeq]", isReplayOrDuplicate = true)
        }

        if (sequenceNumber > highestSeq) {
            highestSeq = sequenceNumber
            val newMin = (highestSeq - windowSize + 1L).coerceAtLeast(1L)
            seenInWindow.removeIf { it < newMin }
        }
        seenInWindow.add(sequenceNumber)
        return CheckResult.Accepted
    }

    fun currentHighestSequence(): Long = synchronized(lock) { highestSeq }
}

data class DecryptedFrameResult(
    val innerFrameType: Byte,
    val plaintext: ByteArray,
    val sequenceNumber: Long,
    val sessionId: String
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is DecryptedFrameResult) return false
        return innerFrameType == other.innerFrameType &&
            plaintext.contentEquals(other.plaintext) &&
            sequenceNumber == other.sequenceNumber &&
            sessionId == other.sessionId
    }

    override fun hashCode(): Int {
        var res = innerFrameType.toInt()
        res = 31 * res + plaintext.contentHashCode()
        res = 31 * res + sequenceNumber.hashCode()
        res = 31 * res + sessionId.hashCode()
        return res
    }
}

sealed class FrameDecryptOutcome {
    data class Success(val result: DecryptedFrameResult) : FrameDecryptOutcome()
    data class Rejected(
        val reason: String,
        val isReplay: Boolean = false,
        val isExpired: Boolean = false,
        val isMalformedOrTampered: Boolean = false
    ) : FrameDecryptOutcome()
}

/**
 * Ephemeral in-memory AEAD ChaCha20-Poly1305 (RFC 8439) transport session.
 *
 * Security Properties:
 * - Separate 256-bit send and receive keys kept strictly in RAM (never serialized to disk or logs).
 * - Unique 96-bit nonces: [4-byte big-endian direction tag | 8-byte monotonic 64-bit sequence].
 * - AAD binds wire version, session ID, direction bit, sequence number, inner frame type, and plaintext length.
 * - Automatic zeroization of both keys when closed or expired.
 */
class EncryptedTransportSession(
    val sessionId: String,
    val localNodeId: String,
    val remoteNodeId: String,
    val remotePublicKeyHex: String,
    val chainId: String,
    val protocolVersion: Int,
    val cipherSuiteId: String,
    val isOutbound: Boolean,
    private val sendKeyBytes: ByteArray,
    private val recvKeyBytes: ByteArray,
    val createdAtMs: Long = System.currentTimeMillis(),
    val ttlMs: Long = 30 * 60 * 1_000L,
    val maxFramesPerSession: Long = 1_000_000L,
    val maxEncryptedFrameBytes: Int = 96 * 1024
) : Closeable {

    companion object {
        const val WIRE_FORMAT_VERSION: Byte = 0x03
        const val DIRECTION_INITIATOR_TO_RESPONDER: Byte = 0x01
        const val DIRECTION_RESPONDER_TO_INITIATOR: Byte = 0x02
        const val POLY1305_TAG_BYTES = 16
        const val NONCE_BYTES = 12
        const val KEY_BYTES = 32
        private const val AAD_DOMAIN = "NMD-AEAD-FRAME-V3\u0000"
    }

    init {
        require(sessionId.isNotBlank() && sessionId.length <= 128) { "Invalid sessionId" }
        require(sendKeyBytes.size == KEY_BYTES) { "Send key must be 32 bytes" }
        require(recvKeyBytes.size == KEY_BYTES) { "Receive key must be 32 bytes" }
    }

    private val closed = AtomicBoolean(false)
    private val sendLock = Any()
    private val recvLock = Any()
    private val sendSequence = AtomicLong(0L)
    private val receivedFramesCount = AtomicLong(0L)
    private val replayWindow = ReplayWindowDetector()

    val expiresAtMs: Long = createdAtMs + ttlMs

    val outgoingDirectionByte: Byte
        get() = if (isOutbound) DIRECTION_INITIATOR_TO_RESPONDER else DIRECTION_RESPONDER_TO_INITIATOR

    val expectedIncomingDirectionByte: Byte
        get() = if (isOutbound) DIRECTION_RESPONDER_TO_INITIATOR else DIRECTION_INITIATOR_TO_RESPONDER

    fun isActive(nowMs: Long = System.currentTimeMillis()): Boolean {
        return !closed.get() && !isExpired(nowMs)
    }

    fun isExpired(nowMs: Long = System.currentTimeMillis()): Boolean {
        if (nowMs >= expiresAtMs) return true
        if (sendSequence.get() >= maxFramesPerSession || receivedFramesCount.get() >= maxFramesPerSession) return true
        return false
    }

    fun framesSentCount(): Long = sendSequence.get()
    fun framesReceivedCount(): Long = receivedFramesCount.get()

    @Throws(IOException::class)
    fun encryptFrame(
        innerFrameType: Byte,
        plaintext: ByteArray,
        nowMs: Long = System.currentTimeMillis()
    ): ByteArray = synchronized(sendLock) {
        if (closed.get()) {
            throw IOException("Cannot encrypt frame: transport session $sessionId is closed")
        }
        if (isExpired(nowMs)) {
            close()
            throw IOException("Transport session $sessionId expired; re-handshake required")
        }

        val seq = sendSequence.incrementAndGet()
        if (seq > maxFramesPerSession) {
            close()
            throw IOException("Transport session $sessionId frame limit exceeded; re-handshake required")
        }

        val dirByte = outgoingDirectionByte
        val nonce = buildNonce(dirByte, seq)
        val aad = buildAad(
            protocolVersion = protocolVersion,
            sessionId = sessionId,
            directionByte = dirByte,
            sequenceNumber = seq,
            innerFrameType = innerFrameType,
            ciphertextWithTagLength = plaintext.size + POLY1305_TAG_BYTES
        )

        val cipher = ChaCha20Poly1305()
        cipher.init(true, AEADParameters(KeyParameter(sendKeyBytes), POLY1305_TAG_BYTES * 8, nonce, aad))
        val ciphertext = ByteArray(cipher.getOutputSize(plaintext.size))
        val len = cipher.processBytes(plaintext, 0, plaintext.size, ciphertext, 0)
        try {
            cipher.doFinal(ciphertext, len)
        } catch (e: InvalidCipherTextException) {
            throw IOException("AEAD ChaCha20-Poly1305 encryption failed: ${e.message}", e)
        }

        val encoded = serializeWireEnvelope(
            protocolVersion = protocolVersion,
            directionByte = dirByte,
            innerFrameType = innerFrameType,
            sequenceNumber = seq,
            sessionId = sessionId,
            ciphertext = ciphertext
        )
        if (encoded.size > maxEncryptedFrameBytes) {
            throw IOException("Encrypted frame (${encoded.size} B) exceeds maxEncryptedFrameBytes ($maxEncryptedFrameBytes B)")
        }
        return encoded
    }

    fun decryptFrame(
        wireBytes: ByteArray,
        nowMs: Long = System.currentTimeMillis()
    ): FrameDecryptOutcome = synchronized(recvLock) {
        if (closed.get()) {
            return FrameDecryptOutcome.Rejected("Transport session $sessionId is closed")
        }
        if (isExpired(nowMs)) {
            close()
            return FrameDecryptOutcome.Rejected("Transport session $sessionId expired; re-handshake required", isExpired = true)
        }
        if (wireBytes.size > maxEncryptedFrameBytes || wireBytes.size < 20) {
            return FrameDecryptOutcome.Rejected(
                "Encrypted frame length ${wireBytes.size} out of bounds [20..$maxEncryptedFrameBytes]",
                isMalformedOrTampered = true
            )
        }

        val parsed = deserializeWireEnvelope(wireBytes)
            ?: return FrameDecryptOutcome.Rejected("Malformed encrypted wire envelope", isMalformedOrTampered = true)

        if (parsed.wireFormatVersion != WIRE_FORMAT_VERSION) {
            return FrameDecryptOutcome.Rejected("Unsupported encrypted frame wire version: ${parsed.wireFormatVersion}", isMalformedOrTampered = true)
        }
        if (parsed.protocolVersion != protocolVersion) {
            return FrameDecryptOutcome.Rejected("Encrypted frame protocol version mismatch: ${parsed.protocolVersion}", isMalformedOrTampered = true)
        }
        if (parsed.sessionId != sessionId) {
            return FrameDecryptOutcome.Rejected("Stale or cross-session frame rejected (got ${parsed.sessionId.take(12)}, expected ${sessionId.take(12)})", isReplay = true)
        }
        if (parsed.directionByte != expectedIncomingDirectionByte) {
            return FrameDecryptOutcome.Rejected("Reflection/direction spoof detected on frame dir=${parsed.directionByte}", isMalformedOrTampered = true)
        }
        if (parsed.ciphertext.size < POLY1305_TAG_BYTES) {
            return FrameDecryptOutcome.Rejected("Truncated AEAD ciphertext missing Poly1305 tag", isMalformedOrTampered = true)
        }

        val nonce = buildNonce(parsed.directionByte, parsed.sequenceNumber)
        val aad = buildAad(
            protocolVersion = parsed.protocolVersion,
            sessionId = parsed.sessionId,
            directionByte = parsed.directionByte,
            sequenceNumber = parsed.sequenceNumber,
            innerFrameType = parsed.innerFrameType,
            ciphertextWithTagLength = parsed.ciphertext.size
        )

        val cipher = ChaCha20Poly1305()
        cipher.init(false, AEADParameters(KeyParameter(recvKeyBytes), POLY1305_TAG_BYTES * 8, nonce, aad))
        val plaintext = ByteArray(cipher.getOutputSize(parsed.ciphertext.size))
        val decryptedBytes = try {
            val processed = cipher.processBytes(parsed.ciphertext, 0, parsed.ciphertext.size, plaintext, 0)
            val finalLen = cipher.doFinal(plaintext, processed)
            plaintext.copyOf(processed + finalLen)
        } catch (_: InvalidCipherTextException) {
            // Cryptographic MAC check failed BEFORE admitting sequence number to replay window
            return FrameDecryptOutcome.Rejected("ChaCha20-Poly1305 authentication tag invalid or ciphertext/AAD tampered", isMalformedOrTampered = true)
        } catch (e: Exception) {
            return FrameDecryptOutcome.Rejected("AEAD decryption error: ${e.message}", isMalformedOrTampered = true)
        }

        // Only check & record sequence AFTER authentic Poly1305 verification so unauthenticated garbage cannot poison window
        val replayCheck = replayWindow.checkAndRecord(parsed.sequenceNumber)
        if (replayCheck is ReplayWindowDetector.CheckResult.Rejected) {
            return FrameDecryptOutcome.Rejected(replayCheck.reason, isReplay = replayCheck.isReplayOrDuplicate)
        }

        receivedFramesCount.incrementAndGet()
        return FrameDecryptOutcome.Success(
            DecryptedFrameResult(
                innerFrameType = parsed.innerFrameType,
                plaintext = decryptedBytes,
                sequenceNumber = parsed.sequenceNumber,
                sessionId = parsed.sessionId
            )
        )
    }

    private fun buildNonce(directionByte: Byte, sequenceNumber: Long): ByteArray {
        val buf = ByteBuffer.allocate(NONCE_BYTES)
        buf.put(0x00)
        buf.put(0x00)
        buf.put(0x00)
        buf.put(directionByte)
        buf.putLong(sequenceNumber)
        return buf.array()
    }

    private fun buildAad(
        protocolVersion: Int,
        sessionId: String,
        directionByte: Byte,
        sequenceNumber: Long,
        innerFrameType: Byte,
        ciphertextWithTagLength: Int
    ): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.write(AAD_DOMAIN.toByteArray(Charsets.UTF_8))
        dos.writeInt(protocolVersion)
        val sidBytes = sessionId.toByteArray(Charsets.UTF_8)
        dos.writeShort(sidBytes.size)
        dos.write(sidBytes)
        dos.writeByte(directionByte.toInt())
        dos.writeLong(sequenceNumber)
        dos.writeByte(innerFrameType.toInt())
        dos.writeInt(ciphertextWithTagLength)
        dos.flush()
        return baos.toByteArray()
    }

    private data class ParsedWireEnvelope(
        val wireFormatVersion: Byte,
        val protocolVersion: Int,
        val directionByte: Byte,
        val innerFrameType: Byte,
        val sequenceNumber: Long,
        val sessionId: String,
        val ciphertext: ByteArray
    )

    private fun serializeWireEnvelope(
        protocolVersion: Int,
        directionByte: Byte,
        innerFrameType: Byte,
        sequenceNumber: Long,
        sessionId: String,
        ciphertext: ByteArray
    ): ByteArray {
        val sidBytes = sessionId.toByteArray(Charsets.UTF_8)
        val baos = ByteArrayOutputStream(32 + sidBytes.size + ciphertext.size)
        val dos = DataOutputStream(baos)
        dos.writeByte(WIRE_FORMAT_VERSION.toInt())
        dos.writeInt(protocolVersion)
        dos.writeByte(directionByte.toInt())
        dos.writeByte(innerFrameType.toInt())
        dos.writeLong(sequenceNumber)
        dos.writeShort(sidBytes.size)
        dos.write(sidBytes)
        dos.writeInt(ciphertext.size)
        dos.write(ciphertext)
        dos.flush()
        return baos.toByteArray()
    }

    private fun deserializeWireEnvelope(bytes: ByteArray): ParsedWireEnvelope? {
        return try {
            val dis = DataInputStream(ByteArrayInputStream(bytes))
            val wireVer = dis.readByte()
            val protoVer = dis.readInt()
            val dir = dis.readByte()
            val innerType = dis.readByte()
            val seq = dis.readLong()
            val sidLen = dis.readUnsignedShort()
            if (sidLen <= 0 || sidLen > 128 || sidLen > bytes.size) return null
            val sidBytes = ByteArray(sidLen)
            dis.readFully(sidBytes)
            val ctLen = dis.readInt()
            if (ctLen < 0 || ctLen > bytes.size) return null
            val ctBytes = ByteArray(ctLen)
            dis.readFully(ctBytes)
            if (dis.available() != 0) return null
            ParsedWireEnvelope(
                wireFormatVersion = wireVer,
                protocolVersion = protoVer,
                directionByte = dir,
                innerFrameType = innerType,
                sequenceNumber = seq,
                sessionId = String(sidBytes, Charsets.UTF_8),
                ciphertext = ctBytes
            )
        } catch (_: Exception) {
            null
        }
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            X25519KeyExchange.zeroize(sendKeyBytes, recvKeyBytes)
        }
    }

    override fun toString(): String {
        return "EncryptedTransportSession(sessionId=$sessionId, remoteNodeId=$remoteNodeId, suite=$cipherSuiteId, active=${!closed.get()})"
    }
}
