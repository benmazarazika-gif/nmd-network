package com.example.p2p.discovery.registry

import com.example.p2p.model.PeerEndpoint
import org.json.JSONArray
import org.json.JSONObject

enum class DiscoverySource {
    LOCAL_NSD,
    PEER_EXCHANGE,
    BOOTSTRAP,
    MANUAL
}

enum class ReachabilityStatus {
    REACHABLE,
    CONNECTED,
    UNREACHABLE,
    STALE,
    UNKNOWN
}

enum class PeerAuthStatus {
    UNAUTHENTICATED,
    AUTHENTICATING,
    AUTHENTICATED,
    AUTH_FAILED,
    REVOKED
}

enum class PeerFilterOption {
    ALL,
    CONNECTED,
    AUTHENTICATED,
    DISCOVERED,
    UNREACHABLE,
    BOOTSTRAP
}

/**
 * Forward-compatible capability descriptors for future NMD Network expansion (Stage 8+).
 */
object PeerCapability {
    const val P2P_TRANSPORT = "p2p"
    const val STAGE7_DISCOVERY = "stage7_discovery"
    const val BLOCK_SYNC = "block_sync"
    const val TX_PROPAGATION = "tx_propagation"
    const val BLOCK_PROPAGATION = "block_propagation"
    const val VALIDATOR_DISCOVERY = "validator_discovery"
}

/**
 * Complete peer record in the distributed peer registry.
 *
 * Implements Stage 7 requirements:
 * - Peer ID & Public key hex
 * - Endpoint address
 * - Protocol version
 * - Discovery source
 * - First discovered & last seen timestamps
 * - Reachability & Authentication states
 * - Reputation & trust scoring (0..100)
 *
 * CRITICAL RULE: Persisted peer records never restore as AUTHENTICATED.
 * Cryptographic authentication must be performed live on each active session.
 */
data class PeerRegistryRecord(
    val peerId: String,
    val publicKeyHex: String? = null,
    val endpoint: PeerEndpoint,
    val protocolVersion: Int = 1,
    val discoverySource: DiscoverySource,
    val firstDiscoveredTimestamp: Long = System.currentTimeMillis(),
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val reachabilityStatus: ReachabilityStatus = ReachabilityStatus.UNKNOWN,
    val authenticationStatus: PeerAuthStatus = PeerAuthStatus.UNAUTHENTICATED,
    val reputationScore: Int = DEFAULT_REPUTATION_SCORE,
    val consecutiveFailures: Int = 0,
    val latencyMs: Long = 0L,
    val isBootstrap: Boolean = false,
    val capabilities: List<String> = listOf(PeerCapability.P2P_TRANSPORT, PeerCapability.STAGE7_DISCOVERY),
    val signedAnnouncementJson: String? = null,
    val notes: String? = null
) {
    companion object {
        const val DEFAULT_REPUTATION_SCORE = 50
        const val MIN_REPUTATION_SCORE = 0
        const val MAX_REPUTATION_SCORE = 100
        const val STALE_THRESHOLD_MS = 10 * 60 * 1000L // 10 minutes
        const val EXPIRATION_THRESHOLD_MS = 24 * 60 * 60 * 1000L // 24 hours

        fun fromJson(json: JSONObject): PeerRegistryRecord? {
            return try {
                val peerId = json.getString("peer_id")
                val host = json.getString("host")
                val port = json.getInt("port")
                val claimedNodeId = if (json.has("claimed_node_id") && !json.isNull("claimed_node_id")) json.getString("claimed_node_id") else null
                val sourceStr = json.optString("discovery_source", DiscoverySource.MANUAL.name)
                val source = try { DiscoverySource.valueOf(sourceStr) } catch (_: Exception) { DiscoverySource.MANUAL }
                val isBootstrap = json.optBoolean("is_bootstrap", false)
                val reputation = json.optInt("reputation_score", DEFAULT_REPUTATION_SCORE)
                val firstDiscovered = json.optLong("first_discovered", System.currentTimeMillis())
                val lastSeen = json.optLong("last_seen", System.currentTimeMillis())
                val pubKey = if (json.has("public_key_hex") && !json.isNull("public_key_hex")) json.getString("public_key_hex") else null
                val protocolVer = json.optInt("protocol_version", 1)

                val capabilities = mutableListOf<String>()
                if (json.has("capabilities")) {
                    val arr = json.getJSONArray("capabilities")
                    for (i in 0 until arr.length()) {
                        capabilities.add(arr.getString(i))
                    }
                }

                // SECURITY: Never restore authentication status as AUTHENTICATED from disk!
                PeerRegistryRecord(
                    peerId = peerId,
                    publicKeyHex = pubKey,
                    endpoint = PeerEndpoint(host, port, claimedNodeId),
                    protocolVersion = protocolVer,
                    discoverySource = source,
                    firstDiscoveredTimestamp = firstDiscovered,
                    lastSeenTimestamp = lastSeen,
                    reachabilityStatus = ReachabilityStatus.UNKNOWN,
                    authenticationStatus = PeerAuthStatus.UNAUTHENTICATED,
                    reputationScore = reputation,
                    isBootstrap = isBootstrap,
                    capabilities = capabilities
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    val displayNodeId: String
        get() = if (peerId.length > 16) "${peerId.take(8)}...${peerId.takeLast(6)}" else peerId

    val formattedAddress: String
        get() = "${endpoint.host}:${endpoint.port}"

    val isConnected: Boolean
        get() = reachabilityStatus == ReachabilityStatus.CONNECTED

    val isAuthenticated: Boolean
        get() = authenticationStatus == PeerAuthStatus.AUTHENTICATED

    fun isStale(timeoutMs: Long = STALE_THRESHOLD_MS, nowMs: Long = System.currentTimeMillis()): Boolean {
        return (nowMs - lastSeenTimestamp) > timeoutMs
    }

    fun isExpired(expiryMs: Long = EXPIRATION_THRESHOLD_MS, nowMs: Long = System.currentTimeMillis()): Boolean {
        return (nowMs - lastSeenTimestamp) > expiryMs
    }

    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("peer_id", peerId)
        if (publicKeyHex != null) json.put("public_key_hex", publicKeyHex)
        json.put("host", endpoint.host)
        json.put("port", endpoint.port)
        if (endpoint.claimedNodeId != null) json.put("claimed_node_id", endpoint.claimedNodeId)
        json.put("protocol_version", protocolVersion)
        json.put("discovery_source", discoverySource.name)
        json.put("first_discovered", firstDiscoveredTimestamp)
        json.put("last_seen", lastSeenTimestamp)
        json.put("reputation_score", reputationScore)
        json.put("is_bootstrap", isBootstrap)
        val caps = JSONArray()
        capabilities.forEach { caps.put(it) }
        json.put("capabilities", caps)
        return json
    }
}
