package com.example.p2p.handshake

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/**
 * HandshakeRole defines the cryptographic role/direction in the mutual handshake transcript.
 */
enum class HandshakeRole {
    /**
     * Responder signing the transcript in response to the initiator's HELLO.
     */
    RESPONDER,

    /**
     * Initiator signing the transcript in the FINAL confirmation step.
     */
    INITIATOR
}

/**
 * HandshakeTranscript binds all cryptographic parameters of the mutual Ed25519 handshake
 * into an unambiguous, length-prefixed canonical binary format before signing or verification.
 *
 * Wire Canonical Representation:
 * - Domain Separator: "NMD-P2P-HANDSHAKE-V2\u0000" (UTF-8 bytes)
 * - Protocol Version: 4-byte Big-Endian Int
 * - Role: 1-byte identifier (0x01 = RESPONDER, 0x02 = INITIATOR)
 * - Initiator Node ID: 2-byte Big-Endian length + UTF-8 bytes
 * - Initiator Public Key Hex: 2-byte Big-Endian length + UTF-8 bytes
 * - Responder Node ID: 2-byte Big-Endian length + UTF-8 bytes
 * - Responder Public Key Hex: 2-byte Big-Endian length + UTF-8 bytes
 * - Initiator Challenge Hex: 2-byte Big-Endian length + UTF-8 bytes
 * - Responder Challenge Hex: 2-byte Big-Endian length + UTF-8 bytes
 *
 * Guarantees:
 * - Unambiguous deterministic binary encoding with explicit length prefixes.
 * - Complete cryptographic transcript binding: signatures cannot be spliced, cross-role replayed,
 *   misattributed to a different peer identity, or used with modified challenges.
 */
object HandshakeTranscript {

    const val DOMAIN_SEPARATOR = "NMD-P2P-HANDSHAKE-V2\u0000"

    fun buildTranscriptBytes(
        protocolVersion: Int,
        role: HandshakeRole,
        initiatorNodeId: String,
        initiatorPublicKeyHex: String,
        responderNodeId: String,
        responderPublicKeyHex: String,
        initiatorChallengeHex: String,
        responderChallengeHex: String
    ): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)

        // 1. Domain Separator
        dos.write(DOMAIN_SEPARATOR.toByteArray(Charsets.UTF_8))

        // 2. Protocol Version (Int32 Big-Endian)
        dos.writeInt(protocolVersion)

        // 3. Handshake Role (1 byte)
        val roleByte: Byte = when (role) {
            HandshakeRole.RESPONDER -> 0x01
            HandshakeRole.INITIATOR -> 0x02
        }
        dos.writeByte(roleByte.toInt())

        // 4. Initiator Node ID (Length-prefixed string)
        writeLengthPrefixedString(dos, initiatorNodeId)

        // 5. Initiator Public Key Hex
        writeLengthPrefixedString(dos, initiatorPublicKeyHex)

        // 6. Responder Node ID
        writeLengthPrefixedString(dos, responderNodeId)

        // 7. Responder Public Key Hex
        writeLengthPrefixedString(dos, responderPublicKeyHex)

        // 8. Initiator Challenge Hex
        writeLengthPrefixedString(dos, initiatorChallengeHex)

        // 9. Responder Challenge Hex
        writeLengthPrefixedString(dos, responderChallengeHex)

        dos.flush()
        return baos.toByteArray()
    }

    private fun writeLengthPrefixedString(dos: DataOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        require(bytes.size <= 0xFFFF) { "Transcript field exceeds maximum 16-bit length" }
        dos.writeShort(bytes.size)
        dos.write(bytes)
    }
}
