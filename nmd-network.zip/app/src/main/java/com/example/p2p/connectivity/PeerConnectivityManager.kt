package com.example.p2p.connectivity

import android.content.Context
import android.content.SharedPreferences
import com.example.crypto.NodeIdentityManager
import com.example.p2p.connectivity.ice.IceEngine
import com.example.p2p.connectivity.ice.WebRtcIceEngine
import com.example.p2p.connectivity.model.ConnectivityDiagnosticsSnapshot
import com.example.p2p.connectivity.model.ConnectivityState
import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.IceConnectionStatus
import com.example.p2p.connectivity.model.IceGatheringProgress
import com.example.p2p.connectivity.model.NatTraversalConfig
import com.example.p2p.connectivity.model.NetworkChangeEvent
import com.example.p2p.connectivity.model.NetworkInterfaceType
import com.example.p2p.connectivity.model.PeerPathRecord
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.TransportPathType
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.connectivity.model.TurnTransportProtocol
import com.example.p2p.connectivity.network.AndroidNetworkMonitor
import com.example.p2p.connectivity.relay.RelayConnectionManager
import com.example.p2p.connectivity.selector.ConnectivityAttemptStage
import com.example.p2p.connectivity.selector.NetworkPathSelector
import com.example.p2p.connectivity.signaling.PeerSignalingService
import com.example.p2p.connectivity.signaling.SignalingChannel
import com.example.p2p.connectivity.stun.StunDiscoveryService
import com.example.p2p.discovery.DistributedDiscoveryCoordinator
import com.example.p2p.discovery.PeerDiscoveryService
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.model.RealPeerInfo
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * High-level Stage 14 P2P connectivity coordinator bridging local LAN sockets,
 * WebRTC ICE Direct paths, TURN Relay fallback, STUN reflexive probing, Android network
 * transition recovery, and Stage 13 mandatory X25519+Ed25519+ChaCha20-Poly1305 security.
 */
class PeerConnectivityManager(
    private val context: Context,
    private val identityManager: NodeIdentityManager,
    private val connectionManager: PeerConnectionManager,
    private val discoveryCoordinator: DistributedDiscoveryCoordinator,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val discoveryService: PeerDiscoveryService? = null,
    private val localIpProvider: () -> String = { "127.0.0.1" },
    initialConfig: NatTraversalConfig = NatTraversalConfig(),
    iceEngine: IceEngine = WebRtcIceEngine(context),
    val stunService: StunDiscoveryService = StunDiscoveryService(ioDispatcher),
    val relayManager: RelayConnectionManager = RelayConnectionManager(
        maxAllocationsPerPeer = initialConfig.maxTurnAllocationsPerSession
    ),
    val signalingService: PeerSignalingService = PeerSignalingService(
        identityManager = identityManager,
        trustManager = connectionManager.transportSecurityManager.trustManager,
        config = initialConfig
    ),
    val pathSelector: NetworkPathSelector = NetworkPathSelector(initialConfig),
    val networkMonitor: AndroidNetworkMonitor = AndroidNetworkMonitor(context, scope, ioDispatcher),
    val natTraversalManager: NatTraversalManager = NatTraversalManager(
        identityManager = identityManager,
        iceEngine = iceEngine,
        signalingService = signalingService,
        stunService = stunService,
        relayManager = relayManager,
        pathSelector = pathSelector,
        scope = scope,
        ioDispatcher = ioDispatcher,
        config = initialConfig
    )
) : Closeable {

    companion object {
        private const val PREFS_NAME = "nmd_nat_traversal_config"
        private const val KEY_STUN_JSON = "stun_servers_json"
        private const val KEY_TURN_JSON = "turn_servers_json"
    }

    private val prefs: SharedPreferences? = try {
        context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    } catch (_: Exception) {
        null
    }

    private data class ReconnectTarget(val localEndpoint: PeerEndpoint? = null)

    private val reconnectMutex = Mutex()
    private val monitorJobs = mutableListOf<Job>()
    private val failedAttempts = AtomicLong(0L)
    private val peerPathsByPeerId = ConcurrentHashMap<String, PeerPathRecord>()
    private val eligibleReconnectTargets = ConcurrentHashMap<String, ReconnectTarget>()
    private val hasSignalingAttached = AtomicBoolean(false)

    @Volatile
    private var explicitStateOverride: ConnectivityState? = null
    @Volatile
    private var lastEventNote: String? = null
    @Volatile
    private var lastEstablishmentMs: Long? = null

    private val _diagnostics = MutableStateFlow(ConnectivityDiagnosticsSnapshot())
    val diagnostics: StateFlow<ConnectivityDiagnosticsSnapshot> = _diagnostics.asStateFlow()

    init {
        loadPersistedServerConfigsIfEmpty(initialConfig)

        // Inbound ICE DataChannel connections must still pass full Stage 13 auth & encryption
        natTraversalManager.onInboundDataChannelReady = { outcome ->
            val syntheticEndpoint = PeerEndpoint(
                host = "ice://${outcome.remoteNodeId.take(12)}",
                port = 0,
                claimedNodeId = outcome.remoteNodeId
            )
            connectionManager.handleIncomingChannel(
                endpoint = syntheticEndpoint,
                channel = outcome.channel,
                onAuthenticated = { peerInfo ->
                    peerPathsByPeerId[outcome.remoteNodeId] = PeerPathRecord(
                        peerNodeId = outcome.remoteNodeId,
                        connectionId = peerInfo.connectionId,
                        transportPath = outcome.pathType,
                        selectedCandidateType = outcome.selectedCandidateType,
                        candidatePairSummary = outcome.candidatePairSummary,
                        establishmentTimeMs = outcome.establishmentTimeMs,
                        isAuthenticatedEncrypted = true
                    )
                    explicitStateOverride = null
                    lastEstablishmentMs = outcome.establishmentTimeMs
                    lastEventNote = "Authenticated inbound peer ${outcome.remoteNodeId.take(12)} via ${outcome.pathType.name}"
                    rebuildDiagnostics()
                },
                onAuthFailed = { err ->
                    failedAttempts.incrementAndGet()
                    explicitStateOverride = ConnectivityState.AUTHENTICATION_FAILED
                    lastEventNote = "Inbound ICE peer authentication failed: ${err.message}"
                    rebuildDiagnostics()
                }
            )
        }

        natTraversalManager.onNegotiationProgressEvent = { message, isFailure ->
            lastEventNote = message
            if (isFailure) {
                failedAttempts.incrementAndGet()
                if (message.contains("Signature", ignoreCase = true) ||
                    message.contains("revoked", ignoreCase = true) ||
                    message.contains("Chain ID", ignoreCase = true)
                ) {
                    explicitStateOverride = ConnectivityState.AUTHENTICATION_FAILED
                }
            }
            rebuildDiagnostics()
        }

        stunService.onPublicEndpointChanged = { oldEp, newEp ->
            lastEventNote = "Public reflexive IP changed: ${oldEp ?: "none"} -> $newEp"
            rebuildDiagnostics()
        }

        // Start Android network monitoring and observe state changes
        networkMonitor.start()

        monitorJobs += scope.launch(ioDispatcher) {
            connectionManager.authenticatedPeers.collect { peers ->
                syncAuthenticatedPeersState(peers)
            }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            discoveryCoordinator.registeredPeers.collect {
                rebuildDiagnostics()
            }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            stunService.summary.collect {
                rebuildDiagnostics()
            }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            relayManager.state.collect {
                rebuildDiagnostics()
            }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            natTraversalManager.natTelemetry.collect {
                rebuildDiagnostics()
            }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            networkMonitor.networkChanges.collect { changeEvent ->
                handleNetworkTransition(changeEvent)
            }
        }

        rebuildDiagnostics()
    }

    fun attachSignalingChannel(channel: SignalingChannel) {
        hasSignalingAttached.set(true)
        natTraversalManager.attachSignalingChannel(channel)
        lastEventNote = "Signaling attached (${channel.channelName})"
        rebuildDiagnostics()
    }

    fun configureStunAndTurnServers(
        stunServers: List<StunServerConfig>,
        turnServers: List<TurnServerConfig>,
        persistNonSecretConfig: Boolean = true
    ) {
        natTraversalManager.updateServerConfigurations(stunServers, turnServers)
        if (persistNonSecretConfig) {
            persistServerConfigs(stunServers, turnServers)
        }
        lastEventNote = "Configured ${stunServers.size} STUN & ${turnServers.size} TURN server(s)"
        rebuildDiagnostics()
    }

    suspend fun refreshConnectivityAndStunProbes(): ConnectivityDiagnosticsSnapshot {
        stunService.discoverReflexiveEndpoints()
        relayManager.refreshAvailabilityState()
        rebuildDiagnostics()
        return _diagnostics.value
    }

    /**
     * Prioritized peer connection orchestrator:
     * 1. Direct local network TCP (if local endpoint supplied & LAN-reachable)
     * 2. Direct ICE (`HOST` / `SRFLX`, IPv4 + IPv6)
     * 3. TURN relay fallback (only if configured with valid expiring credentials)
     * 4. Clear failure state
     *
     * Every candidate carrier MUST pass full Stage 13 X25519+Ed25519 handshake &
     * ChaCha20-Poly1305 AEAD verification before being marked connected.
     */
    suspend fun connectToPeerSmart(
        targetNodeId: String?,
        localEndpoint: PeerEndpoint? = null,
        preferRelayFallback: Boolean = true
    ): Result<RealPeerInfo> = withContext(ioDispatcher) {
        if (targetNodeId != null) {
            eligibleReconnectTargets[targetNodeId] = ReconnectTarget(localEndpoint)
        }
        if (localEndpoint == null && targetNodeId == null) {
            return@withContext Result.failure(IllegalArgumentException("Either targetNodeId or localEndpoint is required"))
        }

        // Prevent duplicate active connections for same authenticated node ID
        if (targetNodeId != null) {
            val already = connectionManager.authenticatedPeers.value.find {
                it.authenticatedNodeId.equals(targetNodeId, ignoreCase = true) &&
                    it.state == RealPeerConnectionState.AUTHENTICATED
            }
            if (already != null) {
                return@withContext Result.success(already)
            }
        }

        val currentNet = networkMonitor.sampleCurrentNetworkType()
        if (currentNet == NetworkInterfaceType.NONE && localEndpoint?.host != "127.0.0.1" && localEndpoint?.host != "localhost" && !hasSignalingAttached.get()) {
            failedAttempts.incrementAndGet()
            explicitStateOverride = ConnectivityState.NO_CONNECTIVITY
            lastEventNote = "No active Android network interface available"
            rebuildDiagnostics()
            return@withContext Result.failure(IllegalStateException("No active network connectivity"))
        }

        val hasLocal = localEndpoint != null && pathSelector.isLikelyLocalLanHost(
            localEndpoint.host,
            localIpProvider()
        )
        val plan = pathSelector.buildConnectivityPlan(
            hasLocalEndpoint = localEndpoint != null && hasLocal,
            hasSignalingChannel = hasSignalingAttached.get() && targetNodeId != null,
            hasValidTurnRelay = preferRelayFallback && relayManager.isRelayAvailable()
        )

        var lastFailure: Throwable? = null

        for (stage in plan.orderedFallbackPlan) {
            when (stage) {
                ConnectivityAttemptStage.LOCAL_DIRECT_TCP -> {
                    val ep = localEndpoint ?: continue
                    explicitStateOverride = ConnectivityState.CONNECTING_DIRECTLY
                    lastEventNote = "Attempting direct local TCP to ${ep.addressFormatted}"
                    rebuildDiagnostics()
                    val t0 = System.currentTimeMillis()
                    val res = connectionManager.connectToPeer(ep)
                    if (res.isSuccess) {
                        val info = res.getOrThrow()
                        val elapsed = (System.currentTimeMillis() - t0).coerceAtLeast(1L)
                        recordSuccessfulConnection(info, TransportPathType.LOCAL_DIRECT_TCP, IceCandidateType.HOST, "local-tcp(${ep.addressFormatted})", elapsed)
                        return@withContext res
                    } else {
                        lastFailure = res.exceptionOrNull()
                        if (isAuthenticationFailure(lastFailure)) {
                            handleAuthFailureState(lastFailure)
                            return@withContext res
                        }
                    }
                }
                ConnectivityAttemptStage.ICE_DIRECT -> {
                    val remoteId = targetNodeId ?: continue
                    explicitStateOverride = ConnectivityState.GATHERING_CANDIDATES
                    lastEventNote = "Gathering ICE candidates for ${remoteId.take(12)}..."
                    rebuildDiagnostics()

                    explicitStateOverride = ConnectivityState.CONNECTING_DIRECTLY
                    rebuildDiagnostics()

                    val negResult = natTraversalManager.negotiateOutboundConnection(remoteId, forceRelayOnly = false)
                    if (negResult.isSuccess) {
                        val outcome = negResult.getOrThrow()
                        val ep = PeerEndpoint("ice://${remoteId.take(12)}", 0, remoteId)
                        val authRes = connectionManager.connectOverChannel(ep, outcome.channel)
                        if (authRes.isSuccess) {
                            val info = authRes.getOrThrow()
                            recordSuccessfulConnection(
                                info,
                                outcome.pathType,
                                outcome.selectedCandidateType,
                                outcome.candidatePairSummary,
                                outcome.establishmentTimeMs
                            )
                            return@withContext authRes
                        } else {
                            lastFailure = authRes.exceptionOrNull()
                            if (isAuthenticationFailure(lastFailure)) {
                                handleAuthFailureState(lastFailure)
                                return@withContext authRes
                            }
                        }
                    } else {
                        lastFailure = negResult.exceptionOrNull()
                    }
                }
                ConnectivityAttemptStage.TURN_RELAY -> {
                    val remoteId = targetNodeId ?: continue
                    explicitStateOverride = ConnectivityState.CONNECTING_THROUGH_RELAY
                    lastEventNote = "Direct path failed; falling back to TURN relay for ${remoteId.take(12)}..."
                    rebuildDiagnostics()

                    val relayResult = natTraversalManager.negotiateOutboundConnection(remoteId, forceRelayOnly = true)
                    if (relayResult.isSuccess) {
                        val outcome = relayResult.getOrThrow()
                        val ep = PeerEndpoint("turn://${remoteId.take(12)}", 0, remoteId)
                        val authRes = connectionManager.connectOverChannel(ep, outcome.channel)
                        if (authRes.isSuccess) {
                            val info = authRes.getOrThrow()
                            recordSuccessfulConnection(
                                info,
                                TransportPathType.TURN_RELAY,
                                IceCandidateType.RELAY,
                                outcome.candidatePairSummary,
                                outcome.establishmentTimeMs
                            )
                            return@withContext authRes
                        } else {
                            lastFailure = authRes.exceptionOrNull()
                            if (isAuthenticationFailure(lastFailure)) {
                                handleAuthFailureState(lastFailure)
                                return@withContext authRes
                            }
                        }
                    } else {
                        lastFailure = relayResult.exceptionOrNull()
                    }
                }
                ConnectivityAttemptStage.FAILED -> Unit
            }
        }

        // If local endpoint existed but wasn't classified LAN (e.g. direct WAN IP:port), try direct TCP fallback
        if (localEndpoint != null && !hasLocal) {
            explicitStateOverride = ConnectivityState.CONNECTING_DIRECTLY
            rebuildDiagnostics()
            val t0 = System.currentTimeMillis()
            val tcpRes = connectionManager.connectToPeer(localEndpoint)
            if (tcpRes.isSuccess) {
                val info = tcpRes.getOrThrow()
                val elapsed = (System.currentTimeMillis() - t0).coerceAtLeast(1L)
                recordSuccessfulConnection(info, TransportPathType.LOCAL_DIRECT_TCP, IceCandidateType.HOST, "direct-tcp(${localEndpoint.addressFormatted})", elapsed)
                return@withContext tcpRes
            } else {
                lastFailure = tcpRes.exceptionOrNull()
                if (isAuthenticationFailure(lastFailure)) {
                    handleAuthFailureState(lastFailure)
                    return@withContext tcpRes
                }
            }
        }

        failedAttempts.incrementAndGet()
        explicitStateOverride = ConnectivityState.NO_CONNECTIVITY
        lastEventNote = lastFailure?.message ?: "All connectivity paths exhausted"
        rebuildDiagnostics()
        Result.failure(lastFailure ?: IllegalStateException("No viable connectivity path to peer"))
    }

    /**
     * Handles Android network transitions (Wi-Fi <-> Cellular, IP change, airplane mode recovery):
     * - Cleans up stale ICE/socket sessions cleanly
     * - Updates diagnostics immediately without touching blockchain/mempool/consensus state
     * - Re-probes STUN servers
     * - Restarts ICE or reconnects eligible peers deduplicated by Node ID
     */
    suspend fun handleNetworkTransition(event: NetworkChangeEvent) = reconnectMutex.withLock {
        if (event.newType == NetworkInterfaceType.NONE) {
            explicitStateOverride = ConnectivityState.NO_CONNECTIVITY
            lastEventNote = "Connectivity lost (${event.previousType.name} -> NONE)"
            stunService.resetOnNetworkLoss()
            natTraversalManager.closeAllNegotiations()
            relayManager.releaseAllAllocations()
            connectionManager.authenticatedPeers.value.forEach { peer ->
                connectionManager.disconnectPeer(peer.connectionId)
            }
            rebuildDiagnostics()
            return
        }

        explicitStateOverride = ConnectivityState.RECONNECTING
        lastEventNote = "Network switched (${event.previousType.name} -> ${event.newType.name}): ${event.reason}"
        rebuildDiagnostics()

        if (event.requiresIceRestart) {
            natTraversalManager.triggerIceRestartAll(event.reason)
        }
        stunService.discoverReflexiveEndpoints()

        // Reconnect previously authenticated/eligible peers that dropped during switch (no duplicate sessions)
        val activeIds = connectionManager.authenticatedPeers.value.mapNotNull { it.authenticatedNodeId }.toSet()
        for ((peerId, target) in eligibleReconnectTargets) {
            if (!activeIds.contains(peerId)) {
                connectToPeerSmart(targetNodeId = peerId, localEndpoint = target.localEndpoint)
            }
        }

        if (connectionManager.authenticatedPeers.value.isEmpty() && explicitStateOverride == ConnectivityState.RECONNECTING) {
            explicitStateOverride = ConnectivityState.DISCOVERING
        }
        rebuildDiagnostics()
    }

    fun triggerManualIceRestart() {
        scope.launch(ioDispatcher) {
            explicitStateOverride = ConnectivityState.RECONNECTING
            val restarted = natTraversalManager.triggerIceRestartAll("Manual ICE restart requested")
            lastEventNote = if (restarted > 0) {
                "Restarted ICE on $restarted active negotiation(s)"
            } else {
                "No active ICE sessions to restart; refreshed STUN probes"
            }
            stunService.discoverReflexiveEndpoints()
            rebuildDiagnostics()
        }
    }

    private fun recordSuccessfulConnection(
        info: RealPeerInfo,
        pathType: TransportPathType,
        candidateType: IceCandidateType?,
        pairSummary: String?,
        establishmentMs: Long
    ) {
        val peerId = info.authenticatedNodeId ?: info.connectionId
        peerPathsByPeerId[peerId] = PeerPathRecord(
            peerNodeId = peerId,
            connectionId = info.connectionId,
            transportPath = pathType,
            selectedCandidateType = candidateType,
            candidatePairSummary = pairSummary,
            establishmentTimeMs = establishmentMs,
            isAuthenticatedEncrypted = info.state == RealPeerConnectionState.AUTHENTICATED,
            connectedAtMs = info.connectedAt
        )
        lastEstablishmentMs = establishmentMs
        explicitStateOverride = null
        lastEventNote = "Connected & encrypted via ${pathType.name} (${establishmentMs}ms)"
        rebuildDiagnostics()
    }

    private fun handleAuthFailureState(error: Throwable?) {
        failedAttempts.incrementAndGet()
        explicitStateOverride = ConnectivityState.AUTHENTICATION_FAILED
        lastEventNote = "Stage 13 authentication failed: ${error?.message ?: "unknown"}"
        rebuildDiagnostics()
    }

    private fun isAuthenticationFailure(err: Throwable?): Boolean {
        val msg = err?.message ?: return false
        return msg.contains("handshake", ignoreCase = true) ||
            msg.contains("signature", ignoreCase = true) ||
            msg.contains("revoked", ignoreCase = true) ||
            msg.contains("chain", ignoreCase = true) ||
            msg.contains("identity", ignoreCase = true) ||
            msg.contains("downgrade", ignoreCase = true) ||
            msg.contains("authenticate", ignoreCase = true)
    }

    private fun syncAuthenticatedPeersState(peers: List<RealPeerInfo>) {
        val activeIds = peers.mapNotNull { it.authenticatedNodeId }.toSet()
        peerPathsByPeerId.keys.removeIf { !activeIds.contains(it) }

        peers.filter { it.state == RealPeerConnectionState.AUTHENTICATED }.forEach { peer ->
            val nodeId = peer.authenticatedNodeId ?: peer.connectionId
            if (!peerPathsByPeerId.containsKey(nodeId)) {
                peerPathsByPeerId[nodeId] = PeerPathRecord(
                    peerNodeId = nodeId,
                    connectionId = peer.connectionId,
                    transportPath = peer.transportPathType,
                    selectedCandidateType = peer.selectedCandidateType,
                    candidatePairSummary = "${peer.transportPathType.name}:${peer.endpoint.addressFormatted}",
                    establishmentTimeMs = peer.lastPingLatencyMs,
                    isAuthenticatedEncrypted = true,
                    connectedAtMs = peer.connectedAt
                )
            }
        }
        rebuildDiagnostics()
    }

    private fun rebuildDiagnostics() {
        val authPeers = connectionManager.authenticatedPeers.value.filter {
            it.state == RealPeerConnectionState.AUTHENTICATED
        }
        val paths = peerPathsByPeerId.values.toList()
        val directCount = authPeers.count {
            it.transportPathType == TransportPathType.LOCAL_DIRECT_TCP ||
                it.transportPathType == TransportPathType.ICE_DIRECT
        }
        val relayedCount = authPeers.count {
            it.transportPathType == TransportPathType.TURN_RELAY
        }

        val stun = stunService.summary.value
        val relay = relayManager.state.value
        val nat = natTraversalManager.natTelemetry.value
        val netType = networkMonitor.currentNetworkType.value
        val lastNetChange = networkMonitor.lastNetworkChange.value

        val primaryPath = when {
            directCount > 0 && authPeers.any { it.transportPathType == TransportPathType.LOCAL_DIRECT_TCP } ->
                TransportPathType.LOCAL_DIRECT_TCP
            directCount > 0 -> TransportPathType.ICE_DIRECT
            relayedCount > 0 -> TransportPathType.TURN_RELAY
            else -> TransportPathType.NONE
        }

        val derivedStatus = explicitStateOverride ?: when {
            netType == NetworkInterfaceType.NONE && authPeers.isEmpty() -> ConnectivityState.NO_CONNECTIVITY
            directCount > 0 -> ConnectivityState.CONNECTED_DIRECTLY
            relayedCount > 0 -> ConnectivityState.CONNECTED_THROUGH_RELAY
            nat.gatheringState == IceGatheringProgress.GATHERING -> ConnectivityState.GATHERING_CANDIDATES
            nat.connectionState == IceConnectionStatus.CHECKING -> ConnectivityState.CONNECTING_DIRECTLY
            else -> ConnectivityState.DISCOVERING
        }

        val discoveredCount = discoveryCoordinator.registeredPeers.value.size +
            (discoveryService?.discoveredPeers?.value?.size ?: 0)
        _diagnostics.value = ConnectivityDiagnosticsSnapshot(
            status = derivedStatus,
            totalDiscoveredPeers = discoveredCount,
            authenticatedConnectedPeers = authPeers.size,
            directConnectionsCount = directCount,
            relayedConnectionsCount = relayedCount,
            iceGatheringState = nat.gatheringState,
            iceConnectionState = nat.connectionState,
            selectedCandidateType = nat.selectedCandidateType
                ?: paths.firstOrNull()?.selectedCandidateType
                ?: if (directCount > 0) IceCandidateType.HOST else null,
            selectedCandidatePairSummary = nat.selectedCandidatePairSummary
                ?: paths.firstOrNull()?.candidatePairSummary,
            stunStatus = stun.overallStatus,
            stunServerCount = stun.configuredServersCount,
            observedPublicEndpoint = stun.formattedPublicEndpoint,
            turnStatus = relay.status,
            turnServerCount = relay.configuredServersCount,
            turnAvailabilityMessage = relay.availabilityMessage,
            lastConnectionEstablishmentMs = nat.lastEstablishmentMs ?: lastEstablishmentMs,
            currentNetworkType = netType,
            lastNetworkChangeAtMs = lastNetChange?.occurredAtMs,
            lastNetworkChangeReason = lastNetChange?.reason,
            failedAttemptsCount = failedAttempts.get(),
            activeNegotiationsCount = nat.activeNegotiationsCount,
            rateLimitedNegotiationsCount = nat.rateLimitedNegotiationsCount,
            activeTransportPath = primaryPath,
            peerPaths = paths,
            natLimitationNote = stun.natLimitationNote,
            lastEventSummary = lastEventNote ?: nat.lastNatEvent
        )
    }

    private fun persistServerConfigs(stunServers: List<StunServerConfig>, turnServers: List<TurnServerConfig>) {
        val sp = prefs ?: return
        try {
            val stunArray = JSONArray()
            stunServers.forEach {
                stunArray.put(JSONObject().apply {
                    put("uri", it.uri)
                    put("timeout_ms", it.timeoutMs)
                    put("enabled", it.enabled)
                })
            }
            val turnArray = JSONArray()
            turnServers.forEach {
                turnArray.put(JSONObject().apply {
                    put("uri", it.uri)
                    put("transport", it.transport.name)
                    put("username", it.username)
                    put("credential", it.credential)
                    if (it.expiresAtEpochMs != null) put("expires_at_ms", it.expiresAtEpochMs)
                    put("enabled", it.enabled)
                })
            }
            val rawTurnJson = turnArray.toString()
            val storedTurnPayload = encryptTurnPayload(rawTurnJson)
            val editor = sp.edit().putString(KEY_STUN_JSON, stunArray.toString())
            if (storedTurnPayload != null) {
                editor.putString(KEY_TURN_JSON, storedTurnPayload)
            } else {
                // Never persist plaintext TURN credentials if KeyStore encryption is unavailable.
                val sanitizedArray = JSONArray()
                turnServers.forEach {
                    sanitizedArray.put(JSONObject().apply {
                        put("uri", it.uri)
                        put("transport", it.transport.name)
                        put("username", it.username)
                        put("credential", "")
                        if (it.expiresAtEpochMs != null) put("expires_at_ms", it.expiresAtEpochMs)
                        put("enabled", it.enabled)
                    })
                }
                editor.putString(KEY_TURN_JSON, sanitizedArray.toString())
            }
            editor.apply()
        } catch (_: Exception) {
        }
    }

    private fun loadPersistedServerConfigsIfEmpty(initialConfig: NatTraversalConfig) {
        if (initialConfig.stunServers.isNotEmpty() || initialConfig.turnServers.isNotEmpty()) {
            natTraversalManager.updateServerConfigurations(initialConfig.stunServers, initialConfig.turnServers)
            return
        }
        val sp = prefs ?: return
        try {
            val stunJson = sp.getString(KEY_STUN_JSON, null)
            val storedTurn = sp.getString(KEY_TURN_JSON, null)
            val turnJson = storedTurn?.let { decryptTurnPayload(it) }
            val stunList = mutableListOf<StunServerConfig>()
            val turnList = mutableListOf<TurnServerConfig>()
            if (!stunJson.isNullOrBlank()) {
                val arr = JSONArray(stunJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    stunList.add(
                        StunServerConfig(
                            uri = obj.getString("uri"),
                            timeoutMs = obj.optLong("timeout_ms", 3_000L),
                            enabled = obj.optBoolean("enabled", true)
                        )
                    )
                }
            }
            if (!turnJson.isNullOrBlank()) {
                val arr = JSONArray(turnJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val exp = if (obj.has("expires_at_ms")) obj.getLong("expires_at_ms") else null
                    turnList.add(
                        TurnServerConfig(
                            uri = obj.getString("uri"),
                            transport = TurnTransportProtocol.valueOf(obj.optString("transport", "UDP")),
                            username = obj.optString("username", ""),
                            credential = obj.optString("credential", ""),
                            expiresAtEpochMs = exp,
                            enabled = obj.optBoolean("enabled", true)
                        )
                    )
                }
            }
            if (stunList.isNotEmpty() || turnList.isNotEmpty()) {
                natTraversalManager.updateServerConfigurations(stunList, turnList)
            }
        } catch (_: Exception) {
        }
    }

    private fun encryptTurnPayload(plainJson: String): String? {
        return try {
            val key = getOrCreateTurnMasterKey() ?: return null
            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val ciphertext = cipher.doFinal(plainJson.toByteArray(Charsets.UTF_8))
            val ivB64 = android.util.Base64.encodeToString(iv, android.util.Base64.NO_WRAP)
            val ctB64 = android.util.Base64.encodeToString(ciphertext, android.util.Base64.NO_WRAP)
            "ENC_V1:$ivB64:$ctB64"
        } catch (_: Exception) {
            null
        }
    }

    private fun decryptTurnPayload(stored: String): String? {
        if (!stored.startsWith("ENC_V1:")) {
            return stored
        }
        return try {
            val parts = stored.split(":", limit = 3)
            if (parts.size != 3) return null
            val key = getOrCreateTurnMasterKey() ?: return null
            val iv = android.util.Base64.decode(parts[1], android.util.Base64.NO_WRAP)
            val ciphertext = android.util.Base64.decode(parts[2], android.util.Base64.NO_WRAP)
            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                javax.crypto.Cipher.DECRYPT_MODE,
                key,
                javax.crypto.spec.GCMParameterSpec(128, iv)
            )
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    private fun getOrCreateTurnMasterKey(): javax.crypto.SecretKey? {
        return try {
            val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore")
            keyStore.load(null)
            val alias = "nmd_nat_turn_secrets_master_v1"
            if (keyStore.containsAlias(alias)) {
                (keyStore.getKey(alias, null) as? javax.crypto.SecretKey)?.let { return it }
            }
            val keyGen = javax.crypto.KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore"
            )
            val spec = android.security.keystore.KeyGenParameterSpec.Builder(
                alias,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
            keyGen.init(spec)
            keyGen.generateKey()
        } catch (_: Exception) {
            null
        }
    }

    override fun close() {
        monitorJobs.forEach { it.cancel() }
        monitorJobs.clear()
        networkMonitor.close()
        natTraversalManager.close()
    }
}
