package com.example.p2p.discovery.pex

import android.util.Log
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.CryptographicProvider
import com.example.p2p.discovery.registry.DiscoverySource
import com.example.p2p.discovery.registry.DistributedPeerRegistry
import com.example.p2p.discovery.registry.ReachabilityStatus
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.protocol.P2pMessage
import com.example.p2p.protocol.P2pMessageType
import com.example.p2p.session.PeerSession
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

sealed class ProcessPexResult {
    data class Ingested(val newPeersCount: Int, val updatedPeersCount: Int) : ProcessPexResult()
    data class ResponseReady(val responseMessage: P2pMessage) : ProcessPexResult()
    object RateLimited : ProcessPexResult()
    data class Rejected(val reason: String) : ProcessPexResult()
    object Ignored : ProcessPexResult()
}

/**
 * PeerExchangeService coordinates the Stage 7 PEX protocol:
 * - Exchanging signed peer descriptors across authenticated connections.
 * - Enforcing rate limits, replay protection, and payload size bounds.
 * - Cryptographically verifying peer announcements (signature + nodeId binding + freshness + address)
 *   before registry insertion.
 */
class PeerExchangeService(
    private val identityManager: NodeIdentityManager,
    private val registry: DistributedPeerRegistry,
    private val cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider,
    val rateLimiter: PexRateLimiter = PexRateLimiter()
) {
    companion object {
        private const val TAG = "PeerExchangeService"
        private const val MAX_REPLAY_CACHE_SIZE = 512
    }

    // Bounded replay cache mapping "<peerId>:<nonce>" -> seenTimestampMs
    private val announcementReplayCache = ConcurrentHashMap<String, Long>()

    /**
     * Builds a self-signed peer announcement message.
     */
    fun createAnnouncementMessage(
        localHost: String,
        localPort: Int,
        targetPeerId: String = P2pMessage.BROADCAST_RECIPIENT
    ): P2pMessage? {
        val identity = identityManager.getActiveIdentity() ?: return null
        val unsignedAnnouncement = SignedPeerAnnouncement(
            peerId = identity.nodeId,
            publicKeyHex = identity.publicKeyHex,
            host = localHost,
            port = localPort,
            timestamp = System.currentTimeMillis()
        )
        val signed = unsignedAnnouncement.sign(identityManager)

        return P2pMessage(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = identity.nodeId,
            recipientPeerId = targetPeerId,
            messageType = P2pMessageType.PEER_ANNOUNCEMENT,
            timestamp = System.currentTimeMillis(),
            payload = signed.toJson().toString()
        )
    }

    /**
     * Creates a PEER_LIST_REQUEST (or PEER_DISCOVERY_REQUEST) message to ask a peer for known good nodes.
     */
    fun createPeerListRequest(
        targetPeerId: String,
        messageType: P2pMessageType = P2pMessageType.PEER_LIST_REQUEST
    ): P2pMessage? {
        val identity = identityManager.getActiveIdentity() ?: return null
        return P2pMessage(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = identity.nodeId,
            recipientPeerId = targetPeerId,
            messageType = messageType,
            timestamp = System.currentTimeMillis(),
            payload = "{\"request\":\"active_peers\",\"max\":${PeerListPayload.MAX_PEERS_PER_PAYLOAD}}"
        )
    }

    /**
     * Creates a PEER_UNAVAILABLE notification message when a peer is unreachable.
     */
    fun createPeerUnavailableMessage(
        unavailablePeerId: String,
        targetPeerId: String = P2pMessage.BROADCAST_RECIPIENT
    ): P2pMessage? {
        val identity = identityManager.getActiveIdentity() ?: return null
        val json = JSONObject().apply {
            put("peer_id", unavailablePeerId)
            put("timestamp", System.currentTimeMillis())
        }
        return P2pMessage(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = identity.nodeId,
            recipientPeerId = targetPeerId,
            messageType = P2pMessageType.PEER_UNAVAILABLE,
            timestamp = System.currentTimeMillis(),
            payload = json.toString()
        )
    }

    /**
     * Builds a PEER_LIST_RESPONSE or PEER_DISCOVERY_RESPONSE containing fresh, cryptographically
     * signed announcements of valid known peers.
     */
    fun createPeerListResponse(
        originalRequest: P2pMessage,
        localHost: String,
        localPort: Int
    ): P2pMessage? {
        val identity = identityManager.getActiveIdentity() ?: return null

        val announcements = mutableListOf<SignedPeerAnnouncement>()

        // Include self signed announcement
        val selfAnnounce = SignedPeerAnnouncement(
            peerId = identity.nodeId,
            publicKeyHex = identity.publicKeyHex,
            host = localHost,
            port = localPort,
            timestamp = System.currentTimeMillis()
        ).sign(identityManager)
        announcements.add(selfAnnounce)

        // Include valid peers that have an authentic, still-fresh SignedPeerAnnouncement cached
        val candidatePeers = registry.getValidPeersForExchange(
            maxCount = PeerListPayload.MAX_PEERS_PER_PAYLOAD - 1,
            excludePeerId = originalRequest.senderPeerId
        )

        for (p in candidatePeers) {
            val cachedJson = p.signedAnnouncementJson ?: continue
            val cachedAnnouncement = try {
                SignedPeerAnnouncement.fromJson(JSONObject(cachedJson))
            } catch (_: Exception) {
                null
            } ?: continue

            if (cachedAnnouncement.validateFreshness() &&
                cachedAnnouncement.validateAddress() &&
                cachedAnnouncement.verify(cryptoProvider)
            ) {
                announcements.add(cachedAnnouncement)
            }
        }

        val responseType = if (originalRequest.messageType == P2pMessageType.PEER_DISCOVERY_REQUEST) {
            P2pMessageType.PEER_DISCOVERY_RESPONSE
        } else {
            P2pMessageType.PEER_LIST_RESPONSE
        }

        val payload = PeerListPayload(announcements = announcements)

        return P2pMessage(
            messageId = UUID.randomUUID().toString(),
            protocolVersion = P2pMessage.CURRENT_PROTOCOL_VERSION,
            senderPeerId = identity.nodeId,
            recipientPeerId = originalRequest.senderPeerId,
            messageType = responseType,
            timestamp = System.currentTimeMillis(),
            payload = payload.toJson(),
            ackForMessageId = originalRequest.messageId
        )
    }

    /**
     * Processes an incoming PEX message, validates it cryptographically with replay & flood protection,
     * updates the peer registry, and optionally produces a response message.
     */
    fun processIncomingPexMessage(
        message: P2pMessage,
        session: PeerSession,
        localHost: String,
        localPort: Int
    ): ProcessPexResult {
        // 1. Rate Limiting Check (flood protection)
        if (!rateLimiter.checkAndRecord(session.peerId)) {
            Log.w(TAG, "Rate limit exceeded for PEX requests from peer ${session.peerId}")
            registry.recordInvalidBehavior(session.peerId, penalty = 5)
            return ProcessPexResult.RateLimited
        }

        val localIdentity = identityManager.getActiveIdentity()
        val localNodeId = localIdentity?.nodeId ?: ""

        when (message.messageType) {
            P2pMessageType.PEER_ANNOUNCEMENT -> {
                val announcement = try {
                    SignedPeerAnnouncement.fromJson(JSONObject(message.payload))
                } catch (_: Exception) {
                    null
                }

                if (announcement == null) {
                    registry.recordInvalidBehavior(session.peerId, penalty = 15)
                    return ProcessPexResult.Rejected("Malformed announcement JSON")
                }

                val validationError = validateAnnouncement(announcement, localNodeId, checkReplay = true)
                if (validationError != null) {
                    Log.w(TAG, "Rejected announcement from ${announcement.peerId}: $validationError")
                    registry.recordInvalidBehavior(session.peerId, penalty = 15)
                    return ProcessPexResult.Rejected(validationError)
                }

                val existing = registry.getPeer(announcement.peerId)
                registry.registerOrUpdatePeer(
                    peerId = announcement.peerId,
                    endpoint = PeerEndpoint(announcement.host, announcement.port, announcement.peerId),
                    source = DiscoverySource.PEER_EXCHANGE,
                    publicKeyHex = announcement.publicKeyHex,
                    protocolVersion = announcement.protocolVersion,
                    reachability = ReachabilityStatus.REACHABLE,
                    capabilities = announcement.capabilities,
                    signedAnnouncementJson = announcement.toJson().toString()
                )

                return ProcessPexResult.Ingested(
                    newPeersCount = if (existing == null) 1 else 0,
                    updatedPeersCount = if (existing != null) 1 else 0
                )
            }

            P2pMessageType.PEER_LIST_REQUEST, P2pMessageType.PEER_DISCOVERY_REQUEST -> {
                val responseMsg = createPeerListResponse(message, localHost, localPort)
                return if (responseMsg != null) {
                    ProcessPexResult.ResponseReady(responseMsg)
                } else {
                    ProcessPexResult.Rejected("Failed generating peer list response")
                }
            }

            P2pMessageType.PEER_LIST_RESPONSE, P2pMessageType.PEER_DISCOVERY_RESPONSE -> {
                val payload = PeerListPayload.fromJson(message.payload)
                    ?: run {
                        registry.recordInvalidBehavior(session.peerId, penalty = 15)
                        return ProcessPexResult.Rejected("Malformed PeerListPayload")
                    }

                var newCount = 0
                var updatedCount = 0

                for (announcement in payload.announcements) {
                    if (announcement.peerId.equals(localNodeId, ignoreCase = true)) continue

                    // Strictly require valid cryptographic signature, identity binding, freshness, and address
                    val error = validateAnnouncement(announcement, localNodeId, checkReplay = false)
                    if (error != null) {
                        Log.w(TAG, "Discarded invalid peer entry in list response (${announcement.peerId}): $error")
                        continue
                    }

                    val existing = registry.getPeer(announcement.peerId)
                    registry.registerOrUpdatePeer(
                        peerId = announcement.peerId,
                        endpoint = PeerEndpoint(announcement.host, announcement.port, announcement.peerId),
                        source = DiscoverySource.PEER_EXCHANGE,
                        publicKeyHex = announcement.publicKeyHex,
                        protocolVersion = announcement.protocolVersion,
                        reachability = ReachabilityStatus.UNKNOWN,
                        capabilities = announcement.capabilities,
                        signedAnnouncementJson = announcement.toJson().toString()
                    )
                    if (existing == null) newCount++ else updatedCount++
                }

                return ProcessPexResult.Ingested(newCount, updatedCount)
            }

            P2pMessageType.PEER_UNAVAILABLE -> {
                val unavailablePeerId = try {
                    JSONObject(message.payload).optString("peer_id", "")
                } catch (_: Exception) {
                    ""
                }
                if (unavailablePeerId.isBlank()) {
                    return ProcessPexResult.Rejected("Malformed PEER_UNAVAILABLE payload")
                }
                // Only update peers that are not currently live-connected locally
                val existing = registry.getPeer(unavailablePeerId)
                if (existing != null && !existing.isConnected) {
                    registry.updateReachability(unavailablePeerId, ReachabilityStatus.UNREACHABLE)
                    return ProcessPexResult.Ingested(0, 1)
                }
                return ProcessPexResult.Ingested(0, 0)
            }

            else -> return ProcessPexResult.Ignored
        }
    }

    private fun validateAnnouncement(
        announcement: SignedPeerAnnouncement,
        localNodeId: String,
        checkReplay: Boolean
    ): String? {
        if (announcement.peerId.equals(localNodeId, ignoreCase = true)) {
            return "Cannot announce self"
        }
        if (announcement.peerId.isBlank() || announcement.publicKeyHex.isBlank()) {
            return "Missing peer identity or public key"
        }
        if (!announcement.validateAddress()) {
            return "Invalid address or port: ${announcement.host}:${announcement.port}"
        }
        if (!announcement.validateFreshness()) {
            return "Announcement timestamp expired or in future"
        }
        if (announcement.signatureHex.isNullOrBlank()) {
            return "Announcement missing cryptographic signature"
        }
        if (!announcement.verify(cryptoProvider)) {
            return "Cryptographic signature or node ID binding failed"
        }
        if (checkReplay && !checkAndRecordReplay(announcement)) {
            return "Replayed peer announcement detected"
        }
        return null
    }

    private fun checkAndRecordReplay(announcement: SignedPeerAnnouncement): Boolean {
        val now = System.currentTimeMillis()
        // Prune expired replay entries lazily when cache grows
        if (announcementReplayCache.size >= MAX_REPLAY_CACHE_SIZE) {
            val cutoff = now - SignedPeerAnnouncement.MAX_FRESHNESS_DRIFT_MS
            announcementReplayCache.entries.removeIf { it.value < cutoff }
            if (announcementReplayCache.size >= MAX_REPLAY_CACHE_SIZE) {
                announcementReplayCache.clear()
            }
        }
        val key = "${announcement.peerId}:${announcement.nonce}:${announcement.timestamp}"
        return announcementReplayCache.putIfAbsent(key, now) == null
    }
}
