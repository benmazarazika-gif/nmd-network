package com.example.p2p.manager

import android.content.Context
import android.util.Log
import com.example.crypto.NodeIdentityManager
import com.example.crypto.model.MessageVerificationResult
import com.example.crypto.model.ProtocolMessageType
import com.example.crypto.model.SignedProtocolMessage
import com.example.crypto.provider.CryptographicProvider
import com.example.crypto.service.MessageVerifier
import com.example.p2p.discovery.PeerDiscoveryService
import com.example.p2p.discovery.topology.ConnectionAdmissionResult
import com.example.p2p.discovery.topology.NetworkTopologyManager
import com.example.p2p.handshake.PeerHandshakeService
import com.example.p2p.model.FrameType
import com.example.p2p.model.PeerEndpoint
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.model.RealPeerInfo
import com.example.p2p.security.IncomingSecurityResult
import com.example.p2p.security.TransportSecurityManager
import com.example.p2p.security.guard.GuardAdmissionResult
import com.example.p2p.security.model.SecurityEventType
import com.example.p2p.transport.MessageFramer
import com.example.p2p.transport.P2PTransport
import com.example.p2p.transport.SocketTransportChannel
import com.example.p2p.transport.TcpPeerTransport
import com.example.p2p.transport.TransportChannel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.IOException
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * PeerConnection wraps an active [TransportChannel] (TCP Socket, WebRTC ICE Direct, or TURN Relay)
 * along with its Stage 13 authenticated & encrypted state and background read loop.
 */
class PeerConnection(
    val info: RealPeerInfo,
    val channel: TransportChannel,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher,
    private val onFrameReceived: suspend (PeerConnection, Byte, ByteArray) -> Unit,
    private val onConnectionClosed: (PeerConnection, Throwable?) -> Unit,
    private val useEncryptedTransport: Boolean = false,
    private val maxReadPayloadSize: Int = MessageFramer.MAX_PAYLOAD_SIZE,
    private val securityManager: TransportSecurityManager? = null
) : Closeable {

    constructor(
        info: RealPeerInfo,
        socket: Socket,
        scope: CoroutineScope,
        ioDispatcher: CoroutineDispatcher,
        onFrameReceived: suspend (PeerConnection, Byte, ByteArray) -> Unit,
        onConnectionClosed: (PeerConnection, Throwable?) -> Unit,
        useEncryptedTransport: Boolean = false,
        maxReadPayloadSize: Int = MessageFramer.MAX_PAYLOAD_SIZE,
        securityManager: TransportSecurityManager? = null
    ) : this(
        info = info,
        channel = SocketTransportChannel(socket),
        scope = scope,
        ioDispatcher = ioDispatcher,
        onFrameReceived = onFrameReceived,
        onConnectionClosed = onConnectionClosed,
        useEncryptedTransport = useEncryptedTransport,
        maxReadPayloadSize = maxReadPayloadSize,
        securityManager = securityManager
    )

    val socket: Socket?
        get() = (channel as? SocketTransportChannel)?.socket

    private var readJob: Job? = null
    var currentInfo: RealPeerInfo = info
        private set

    fun updateInfo(block: (RealPeerInfo) -> RealPeerInfo) {
        currentInfo = block(currentInfo)
    }

    fun startReading() {
        readJob = scope.launch(ioDispatcher) {
            try {
                val inputStream = channel.inputStream
                while (isActive && !channel.isClosed) {
                    val frame = MessageFramer.readFrame(inputStream, maxReadPayloadSize)
                    if (frame == null) {
                        break
                    }
                    val (type, payload) = frame
                    updateInfo { it.copy(messagesReceived = it.messagesReceived + 1) }
                    onFrameReceived(this@PeerConnection, type, payload)
                }
                onConnectionClosed(this@PeerConnection, null)
            } catch (e: Exception) {
                onConnectionClosed(this@PeerConnection, e)
            }
        }
    }

    suspend fun sendFrame(frameType: Byte, payload: ByteArray) = withContext(ioDispatcher) {
        try {
            if (useEncryptedTransport && securityManager != null) {
                val encryptedEnvelope = securityManager.encryptOutgoing(
                    connectionId = currentInfo.connectionId,
                    innerFrameType = frameType,
                    plaintext = payload
                )
                MessageFramer.writeFrame(
                    outputStream = channel.outputStream,
                    frameType = FrameType.ENCRYPTED_FRAME,
                    payload = encryptedEnvelope,
                    maxPayloadSize = securityManager.config.maxEncryptedFrameBytes
                )
            } else {
                MessageFramer.writeFrame(channel.outputStream, frameType, payload, maxReadPayloadSize)
            }
            updateInfo { it.copy(messagesSent = it.messagesSent + 1) }
        } catch (e: Exception) {
            close()
            throw e
        }
    }

    override fun close() {
        readJob?.cancel()
        try {
            channel.close()
        } catch (_: Exception) {}
    }
}

/**
 * PeerConnectionManager coordinates TCP transport, incoming connections, outbound connections,
 * Stage 13 mutual cryptographic handshakes + ChaCha20-Poly1305 encrypted framing,
 * duplicate connection deduplication, abuse protection, and authenticated message routing.
 */
class PeerConnectionManager(
    private val context: Context,
    private val identityManager: NodeIdentityManager,
    private val transport: P2PTransport,
    private val handshakeService: PeerHandshakeService,
    private val discoveryService: PeerDiscoveryService,
    private val messageVerifier: MessageVerifier = identityManager.repository.messageVerifier,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    val topologyManager: NetworkTopologyManager = NetworkTopologyManager(),
    val transportSecurityManager: TransportSecurityManager = TransportSecurityManager(
        context = context,
        identityManager = identityManager
    )
) : Closeable {

    companion object {
        private const val TAG = "PeerConnectionManager"
        const val MAX_CONCURRENT_PEERS = 10
    }

    private val activeConnections = ConcurrentHashMap<String, PeerConnection>()

    private val _authenticatedPeers = MutableStateFlow<List<RealPeerInfo>>(emptyList())
    val authenticatedPeers: StateFlow<List<RealPeerInfo>> = _authenticatedPeers.asStateFlow()

    private val _receivedMessages = MutableSharedFlow<Pair<RealPeerInfo, SignedProtocolMessage>>(extraBufferCapacity = 64)
    val receivedMessages: SharedFlow<Pair<RealPeerInfo, SignedProtocolMessage>> = _receivedMessages.asSharedFlow()

    private val _transportEvents = MutableSharedFlow<String>(extraBufferCapacity = 32)
    val transportEvents: SharedFlow<String> = _transportEvents.asSharedFlow()

    private val _receivedReliableFrames = MutableSharedFlow<Pair<RealPeerInfo, ByteArray>>(extraBufferCapacity = 64)
    val receivedReliableFrames: SharedFlow<Pair<RealPeerInfo, ByteArray>> = _receivedReliableFrames.asSharedFlow()

    var onPeerSecurityViolation: ((String?, SecurityEventType, String) -> Unit)? = null

    private var acceptCollectorJob: Job? = null
    private var expirySweepJob: Job? = null

    init {
        acceptCollectorJob = scope.launch(ioDispatcher) {
            transport.incomingSockets.collect { socket ->
                handleIncomingSocket(socket)
            }
        }
        val sweepIntervalMs = minOf(30_000L, (transportSecurityManager.config.sessionTtlMs / 2L).coerceAtLeast(250L))
        expirySweepJob = scope.launch(ioDispatcher) {
            while (isActive) {
                delay(sweepIntervalMs)
                transportSecurityManager.sweepExpiredSessions()
            }
        }
    }

    suspend fun startP2P(port: Int = TcpPeerTransport.DEFAULT_NMD_PORT): Int {
        val actualPort = transport.startListening(port)
        val localIdentity = identityManager.getActiveIdentity()
        if (localIdentity != null) {
            discoveryService.startAdvertising(localIdentity.nodeId, actualPort)
            discoveryService.startDiscovery(localIdentity.nodeId)
        }
        _transportEvents.emit("P2P listener started on port $actualPort")
        return actualPort
    }

    suspend fun stopP2P() {
        discoveryService.stopAdvertising()
        discoveryService.stopDiscovery()
        transport.stopListening()

        activeConnections.keys.toList().forEach { id ->
            transportSecurityManager.terminateSession(id, "P2P listener stopped", disconnectSocket = false)
            activeConnections.remove(id)?.close()
        }
        updatePeersList()
        _transportEvents.emit("P2P listener and all peer connections stopped")
    }

    suspend fun connectToPeer(endpoint: PeerEndpoint): Result<RealPeerInfo> = withContext(ioDispatcher) {
        val localIdentity = identityManager.getActiveIdentity()
            ?: return@withContext Result.failure(IllegalStateException("Local node identity not initialized"))

        transportSecurityManager.sweepExpiredSessions()

        val admissionCheckKey = endpoint.claimedNodeId ?: endpoint.host
        when (val guard = transportSecurityManager.checkOutboundAdmission(admissionCheckKey)) {
            is GuardAdmissionResult.Rejected -> {
                return@withContext Result.failure(IllegalStateException(guard.reason))
            }
            GuardAdmissionResult.Allowed -> Unit
        }

        val outboundCount = activeConnections.values.count { it.currentInfo.isOutbound }
        val activeEndpointSet = activeConnections.values.map { it.currentInfo.endpoint.addressFormatted }.toSet()
        val admission = topologyManager.validateOutboundConnection(
            targetEndpoint = endpoint,
            localNodeId = localIdentity.nodeId,
            localPort = transport.boundPort.value ?: 0,
            localIp = transport.getLocalIpAddress(),
            currentOutboundCount = outboundCount,
            activeEndpoints = activeEndpointSet
        )
        if (admission is ConnectionAdmissionResult.Rejected) {
            return@withContext Result.failure(IllegalStateException(admission.reason))
        }

        if (activeConnections.size >= MAX_CONCURRENT_PEERS) {
            return@withContext Result.failure(IllegalStateException("Maximum peer connection limit ($MAX_CONCURRENT_PEERS) reached"))
        }

        val alreadyConnected = activeConnections.values.any {
            it.currentInfo.endpoint.host == endpoint.host && it.currentInfo.endpoint.port == endpoint.port
        }
        if (alreadyConnected) {
            return@withContext Result.failure(IllegalStateException("Already connected to peer at ${endpoint.host}:${endpoint.port}"))
        }

        var socket: Socket? = null
        var endedConnecting = false
        transportSecurityManager.beginConnecting()
        try {
            _transportEvents.emit("Connecting to ${endpoint.host}:${endpoint.port}...")
            socket = transport.connectTo(endpoint)
            transportSecurityManager.endConnecting()
            endedConnecting = true
            val channel = SocketTransportChannel(socket)
            return@withContext performOutboundChannelHandshake(endpoint, channel, skipAdmissionCheck = true)
        } catch (e: Exception) {
            if (!endedConnecting) {
                transportSecurityManager.endConnecting()
            }
            try { socket?.close() } catch (_: Exception) {}
            Log.e(TAG, "Failed connecting to peer ${endpoint.host}:${endpoint.port}: ${e.message}")
            _transportEvents.emit("Connection to ${endpoint.host}:${endpoint.port} failed: ${e.message}")
            Result.failure(e)
        }
    }

    /**
     * Stage 14: Connects and runs the mandatory Stage 13 X25519+Ed25519 handshake &
     * ChaCha20-Poly1305 encrypted framing over an established [TransportChannel]
     * (ICE Direct DataChannel or TURN Relayed DataChannel).
     */
    suspend fun connectOverChannel(
        endpoint: PeerEndpoint,
        channel: TransportChannel
    ): Result<RealPeerInfo> = withContext(ioDispatcher) {
        performOutboundChannelHandshake(endpoint, channel, skipAdmissionCheck = false)
    }

    private suspend fun performOutboundChannelHandshake(
        endpoint: PeerEndpoint,
        channel: TransportChannel,
        skipAdmissionCheck: Boolean
    ): Result<RealPeerInfo> {
        val localIdentity = identityManager.getActiveIdentity()
        if (localIdentity == null) {
            try { channel.close() } catch (_: Exception) {}
            return Result.failure(IllegalStateException("Local node identity not initialized"))
        }

        transportSecurityManager.sweepExpiredSessions()

        if (!skipAdmissionCheck) {
            val admissionCheckKey = endpoint.claimedNodeId ?: endpoint.host
            when (val guard = transportSecurityManager.checkOutboundAdmission(admissionCheckKey)) {
                is GuardAdmissionResult.Rejected -> {
                    try { channel.close() } catch (_: Exception) {}
                    return Result.failure(IllegalStateException(guard.reason))
                }
                GuardAdmissionResult.Allowed -> Unit
            }

            if (activeConnections.size >= MAX_CONCURRENT_PEERS) {
                try { channel.close() } catch (_: Exception) {}
                return Result.failure(IllegalStateException("Maximum peer connection limit ($MAX_CONCURRENT_PEERS) reached"))
            }

            if (endpoint.claimedNodeId != null) {
                if (endpoint.claimedNodeId.equals(localIdentity.nodeId, ignoreCase = true)) {
                    try { channel.close() } catch (_: Exception) {}
                    return Result.failure(IllegalStateException("Self-connection loop detected: Target Node ID matches local node"))
                }
                val alreadyPeer = activeConnections.values.any { it.currentInfo.authenticatedNodeId == endpoint.claimedNodeId }
                if (alreadyPeer) {
                    try { channel.close() } catch (_: Exception) {}
                    return Result.failure(IllegalStateException("Already connected to peer node ${endpoint.claimedNodeId}"))
                }
            }
        }

        val connectionId = UUID.randomUUID().toString()
        val initialPeerInfo = RealPeerInfo(
            connectionId = connectionId,
            endpoint = endpoint,
            state = RealPeerConnectionState.CONNECTING,
            isOutbound = true,
            transportPathType = channel.pathType,
            selectedCandidateType = channel.selectedCandidateType
        )

        try {
            channel.setReadTimeoutMs(transportSecurityManager.config.handshakeTimeoutMs.toInt())

            val handshakingInfo = initialPeerInfo.copy(state = RealPeerConnectionState.HANDSHAKING)

            _transportEvents.emit("Performing X25519+Ed25519 encrypted handshake (${channel.pathType.name}) with ${endpoint.addressFormatted}...")
            val handshakeStart = System.currentTimeMillis()
            val session = transportSecurityManager.performOutboundHandshake(
                connectionId = connectionId,
                endpointFormatted = endpoint.addressFormatted,
                inputStream = channel.inputStream,
                outputStream = channel.outputStream,
                expectedRemoteNodeId = endpoint.claimedNodeId,
                onForceDisconnect = { activeConnections[connectionId]?.close() }
            )
            channel.setReadTimeoutMs(0)
            val latencyMs = (System.currentTimeMillis() - handshakeStart).coerceAtLeast(1L)

            val existingSamePeer = activeConnections.values.find { it.currentInfo.authenticatedNodeId == session.remoteNodeId }
            if (existingSamePeer != null) {
                transportSecurityManager.terminateSession(connectionId, "Duplicate connection to peer", disconnectSocket = false)
                channel.close()
                return Result.failure(IllegalStateException("Already connected to peer node ${session.remoteNodeId}"))
            }

            val authenticatedInfo = handshakingInfo.copy(
                authenticatedNodeId = session.remoteNodeId,
                authenticatedPublicKeyHex = session.remotePublicKeyHex,
                state = RealPeerConnectionState.AUTHENTICATED,
                connectedAt = System.currentTimeMillis(),
                lastPingLatencyMs = latencyMs,
                transportPathType = channel.pathType,
                selectedCandidateType = channel.selectedCandidateType
            )

            val connection = PeerConnection(
                info = authenticatedInfo,
                channel = channel,
                scope = scope,
                ioDispatcher = ioDispatcher,
                onFrameReceived = { conn, type, payload -> handleFrameReceived(conn, type, payload) },
                onConnectionClosed = { conn, cause -> handleConnectionClosed(conn, cause) },
                useEncryptedTransport = transportSecurityManager.config.requireEncryptedTransport,
                maxReadPayloadSize = transportSecurityManager.config.maxEncryptedFrameBytes,
                securityManager = transportSecurityManager
            )

            activeConnections[connectionId] = connection
            connection.startReading()
            updatePeersList()
            _transportEvents.emit("Encrypted connection (${channel.pathType.name}) established with node ${session.remoteNodeId.take(12)}... (${latencyMs}ms)")

            return Result.success(authenticatedInfo)
        } catch (e: Exception) {
            transportSecurityManager.terminateSession(connectionId, e.message ?: "Outbound handshake failed", disconnectSocket = false)
            try { channel.close() } catch (_: Exception) {}
            Log.e(TAG, "Failed connecting to peer ${endpoint.addressFormatted}: ${e.message}")
            _transportEvents.emit("Connection to ${endpoint.addressFormatted} failed: ${e.message}")
            return Result.failure(e)
        }
    }

    suspend fun sendMessage(
        targetConnectionId: String,
        messageType: ProtocolMessageType,
        payload: String
    ): Result<SignedProtocolMessage> = withContext(ioDispatcher) {
        val connection = activeConnections[targetConnectionId]
            ?: return@withContext Result.failure(IllegalArgumentException("Peer connection not found: $targetConnectionId"))

        if (connection.currentInfo.state != RealPeerConnectionState.AUTHENTICATED) {
            return@withContext Result.failure(IllegalStateException("Peer is not in AUTHENTICATED state"))
        }

        try {
            val signedMessage = identityManager.signProtocolMessage(
                messageType = messageType,
                payload = payload
            )

            val jsonBytes = signedMessage.toJson().toByteArray(Charsets.UTF_8)
            connection.sendFrame(FrameType.PROTOCOL_MESSAGE, jsonBytes)
            updatePeersList()

            _transportEvents.emit("Sent encrypted ${messageType.name} message to ${connection.currentInfo.authenticatedNodeId?.take(10)}...")
            Result.success(signedMessage)
        } catch (e: Exception) {
            Log.e(TAG, "Error sending message to peer: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun sendRawFrame(connectionId: String, frameType: Byte, payload: ByteArray) = withContext(ioDispatcher) {
        val connection = activeConnections[connectionId]
            ?: throw IllegalArgumentException("Peer connection not found: $connectionId")
        connection.sendFrame(frameType, payload)
        updatePeersList()
    }

    fun getConnectionIdForPeer(peerNodeId: String): String? {
        return activeConnections.values.find { it.currentInfo.authenticatedNodeId == peerNodeId }?.info?.connectionId
    }

    suspend fun disconnectPeer(connectionId: String) = withContext(ioDispatcher) {
        val connection = activeConnections.remove(connectionId)
        if (connection != null) {
            try {
                connection.sendFrame(FrameType.DISCONNECT, ByteArray(0))
            } catch (_: Exception) {}
            transportSecurityManager.terminateSession(connectionId, "Local disconnect", disconnectSocket = false)
            connection.close()
            updatePeersList()
            _transportEvents.emit("Disconnected peer ${connection.currentInfo.authenticatedNodeId ?: connectionId}")
        }
    }

    private fun handleIncomingSocket(socket: Socket) {
        val remoteHost = socket.inetAddress?.hostAddress ?: "unknown"
        val remotePort = socket.port
        val endpoint = PeerEndpoint(host = remoteHost, port = remotePort)
        handleIncomingChannel(endpoint, SocketTransportChannel(socket))
    }

    /**
     * Stage 14: Accepts an incoming [TransportChannel] (TCP Socket, ICE Direct, or TURN Relay)
     * and forces it through the exact Stage 13 abuse guard + X25519+Ed25519 handshake pipeline.
     */
    fun handleIncomingChannel(
        endpoint: PeerEndpoint,
        channel: TransportChannel,
        onAuthenticated: ((RealPeerInfo) -> Unit)? = null,
        onAuthFailed: ((Throwable) -> Unit)? = null
    ) {
        scope.launch(ioDispatcher) {
            val remoteHost = endpoint.host
            val remotePort = endpoint.port

            transportSecurityManager.sweepExpiredSessions()

            if (topologyManager.canAcceptInbound(activeConnections.size) is ConnectionAdmissionResult.Rejected ||
                activeConnections.size >= MAX_CONCURRENT_PEERS
            ) {
                Log.w(TAG, "Max peers limit reached. Rejecting incoming connection from $remoteHost:$remotePort")
                try { channel.close() } catch (_: Exception) {}
                onAuthFailed?.invoke(IllegalStateException("Max peers limit reached"))
                return@launch
            }

            when (val guard = transportSecurityManager.checkInboundAdmission(remoteHost)) {
                is GuardAdmissionResult.Rejected -> {
                    Log.w(TAG, "Security admission guard rejected $remoteHost:$remotePort: ${guard.reason}")
                    _transportEvents.emit("Rejected inbound peer $remoteHost: ${guard.reason}")
                    try { channel.close() } catch (_: Exception) {}
                    onAuthFailed?.invoke(IllegalStateException(guard.reason))
                    return@launch
                }
                GuardAdmissionResult.Allowed -> Unit
            }

            val connectionId = UUID.randomUUID().toString()
            val initialInfo = RealPeerInfo(
                connectionId = connectionId,
                endpoint = endpoint,
                state = RealPeerConnectionState.HANDSHAKING,
                isOutbound = false,
                transportPathType = channel.pathType,
                selectedCandidateType = channel.selectedCandidateType
            )

            try {
                channel.setReadTimeoutMs(transportSecurityManager.config.handshakeTimeoutMs.toInt())
                _transportEvents.emit("Inbound connection (${channel.pathType.name}) from $remoteHost:$remotePort. Encrypted handshake...")
                val handshakeStart = System.currentTimeMillis()
                val session = transportSecurityManager.performInboundHandshake(
                    connectionId = connectionId,
                    remoteHost = remoteHost,
                    endpointFormatted = endpoint.addressFormatted,
                    inputStream = channel.inputStream,
                    outputStream = channel.outputStream,
                    onForceDisconnect = { activeConnections[connectionId]?.close() }
                )
                channel.setReadTimeoutMs(0)
                val latencyMs = (System.currentTimeMillis() - handshakeStart).coerceAtLeast(1L)

                if (activeConnections.values.any { it.currentInfo.authenticatedNodeId == session.remoteNodeId }) {
                    Log.w(TAG, "Duplicate connection from Node ID ${session.remoteNodeId}. Closing.")
                    transportSecurityManager.terminateSession(connectionId, "Duplicate inbound node connection", disconnectSocket = false)
                    channel.close()
                    onAuthFailed?.invoke(IllegalStateException("Duplicate connection from ${session.remoteNodeId}"))
                    return@launch
                }

                val authenticatedInfo = initialInfo.copy(
                    authenticatedNodeId = session.remoteNodeId,
                    authenticatedPublicKeyHex = session.remotePublicKeyHex,
                    state = RealPeerConnectionState.AUTHENTICATED,
                    connectedAt = System.currentTimeMillis(),
                    lastPingLatencyMs = latencyMs,
                    transportPathType = channel.pathType,
                    selectedCandidateType = channel.selectedCandidateType
                )

                val connection = PeerConnection(
                    info = authenticatedInfo,
                    channel = channel,
                    scope = scope,
                    ioDispatcher = ioDispatcher,
                    onFrameReceived = { conn, type, payload -> handleFrameReceived(conn, type, payload) },
                    onConnectionClosed = { conn, cause -> handleConnectionClosed(conn, cause) },
                    useEncryptedTransport = transportSecurityManager.config.requireEncryptedTransport,
                    maxReadPayloadSize = transportSecurityManager.config.maxEncryptedFrameBytes,
                    securityManager = transportSecurityManager
                )

                activeConnections[connectionId] = connection
                connection.startReading()
                updatePeersList()
                onAuthenticated?.invoke(authenticatedInfo)
                _transportEvents.emit("Inbound peer encrypted & authenticated (${channel.pathType.name}): node ${session.remoteNodeId.take(12)}... from $remoteHost")
            } catch (e: Exception) {
                transportSecurityManager.terminateSession(connectionId, e.message ?: "Inbound handshake failed", disconnectSocket = false)
                Log.e(TAG, "Inbound handshake failed with $remoteHost:$remotePort: ${e.message}")
                _transportEvents.emit("Inbound handshake failed with $remoteHost: ${e.message}")
                try { channel.close() } catch (_: Exception) {}
                onAuthFailed?.invoke(e)
            } finally {
                transportSecurityManager.releaseInboundAdmissionSlot()
            }
        }
    }

    private suspend fun handleFrameReceived(connection: PeerConnection, frameType: Byte, payload: ByteArray) {
        val effectiveFrameType: Byte
        val effectivePayload: ByteArray

        if (transportSecurityManager.config.requireEncryptedTransport) {
            when (val dec = transportSecurityManager.decryptAndAuthorizeIncoming(
                connectionId = connection.info.connectionId,
                wireFrameType = frameType,
                wirePayload = payload
            )) {
                is IncomingSecurityResult.SecurityViolation -> {
                    Log.w(TAG, "Transport security violation (${dec.eventType}): ${dec.reason}")
                    _transportEvents.emit("Transport security violation (${dec.eventType.name}): ${dec.reason}")
                    onPeerSecurityViolation?.invoke(
                        connection.currentInfo.authenticatedNodeId,
                        dec.eventType,
                        dec.reason
                    )
                    if (dec.terminateConnection) {
                        transportSecurityManager.terminateSession(connection.info.connectionId, dec.reason, disconnectSocket = true)
                        connection.close()
                    }
                    return
                }
                is IncomingSecurityResult.PlaintextFrame -> {
                    effectiveFrameType = dec.result.innerFrameType
                    effectivePayload = dec.result.plaintext
                }
            }
        } else {
            effectiveFrameType = frameType
            effectivePayload = payload
        }

        when (effectiveFrameType) {
            FrameType.PROTOCOL_MESSAGE -> {
                val json = String(effectivePayload, Charsets.UTF_8)
                val signedMessage = try {
                    SignedProtocolMessage.fromJson(json)
                } catch (e: Exception) {
                    Log.w(TAG, "Malformed SignedProtocolMessage JSON inside encrypted frame: ${e.message}")
                    return
                }

                if (signedMessage.senderNodeId != connection.currentInfo.authenticatedNodeId) {
                    Log.w(TAG, "Spoofed sender ID: expected ${connection.currentInfo.authenticatedNodeId}, got ${signedMessage.senderNodeId}")
                    return
                }

                val verificationResult = messageVerifier.verifyMessage(signedMessage)
                if (verificationResult is MessageVerificationResult.Valid) {
                    _receivedMessages.emit(Pair(connection.currentInfo, signedMessage))
                    _transportEvents.emit("Received valid ${signedMessage.messageType} from ${signedMessage.senderNodeId.take(10)}...")
                } else {
                    Log.w(TAG, "Rejected invalid protocol message from ${signedMessage.senderNodeId}: $verificationResult")
                    _transportEvents.emit("Rejected invalid protocol message from ${signedMessage.senderNodeId.take(10)}: $verificationResult")
                }
            }
            FrameType.HEARTBEAT_PING -> {
                try {
                    connection.sendFrame(FrameType.HEARTBEAT_PONG, effectivePayload)
                } catch (e: Exception) {
                    Log.w(TAG, "Failed replying to PING: ${e.message}")
                }
            }
            FrameType.HEARTBEAT_PONG -> {
                Log.d(TAG, "Received heartbeat PONG from peer ${connection.currentInfo.authenticatedNodeId}")
            }
            FrameType.RELIABLE_MSG -> {
                _receivedReliableFrames.emit(Pair(connection.currentInfo, effectivePayload))
            }
            FrameType.DISCONNECT -> {
                Log.i(TAG, "Peer ${connection.currentInfo.authenticatedNodeId} sent DISCONNECT")
                connection.close()
            }
            else -> {
                Log.w(TAG, "Unknown inner frame type received: 0x%02X".format(effectiveFrameType))
            }
        }
    }

    private fun handleConnectionClosed(connection: PeerConnection, cause: Throwable?) {
        transportSecurityManager.terminateSession(
            connectionId = connection.info.connectionId,
            reason = cause?.message ?: "Clean disconnection",
            disconnectSocket = false
        )
        val removed = activeConnections.remove(connection.info.connectionId)
        if (removed != null) {
            removed.close()
            updatePeersList()
            val reason = cause?.message ?: "Clean disconnection"
            scope.launch {
                _transportEvents.emit("Peer connection closed (${removed.currentInfo.authenticatedNodeId?.take(10) ?: "unknown"}): $reason")
            }
        }
    }

    private fun updatePeersList() {
        scope.launch {
            _authenticatedPeers.value = activeConnections.values.map { it.currentInfo }
        }
    }

    override fun close() {
        acceptCollectorJob?.cancel()
        expirySweepJob?.cancel()
        activeConnections.keys.toList().forEach { id ->
            activeConnections.remove(id)?.close()
        }
        transportSecurityManager.close()
        _authenticatedPeers.value = emptyList()
    }
}
