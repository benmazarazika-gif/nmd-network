package com.example.p2p.security.handshake

import android.content.Context
import com.example.crypto.NodeIdentityManager
import com.example.crypto.provider.CryptographicProvider
import com.example.p2p.handshake.HandshakeChallengeReplayCache
import com.example.p2p.model.FrameType
import com.example.p2p.security.crypto.EncryptedTransportSession
import com.example.p2p.security.crypto.NoiseStyleKeySchedule
import com.example.p2p.security.crypto.X25519KeyExchange
import com.example.p2p.security.model.SecurityEventType
import com.example.p2p.security.model.TransportSecurityConfig
import com.example.p2p.security.trust.IdentityTrustCheckResult
import com.example.p2p.security.trust.PeerTrustManager
import com.example.p2p.transport.MessageFramer
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

data class SecureHandshakeOutcome(
    val encryptedSession: EncryptedTransportSession,
    val latencyMs: Long
)

class SecurityHandshakeException(
    val eventType: SecurityEventType,
    message: String
) : IOException(message)

/**
 * Handshake message wire models for Stage 13 Protocol v3 (Noise-XX / X25519 + Ed25519).
 */
data class SecureHandshakeInit(
    val protocolVersion: Int,
    val minSupportedVersion: Int,
    val chainId: String,
    val cipherSuiteId: String,
    val senderNodeId: String,
    val senderPublicKeyHex: String,
    val ephemeralX25519PubHex: String,
    val challengeHex: String,
    val sessionIdProposal: String,
    val timestamp: Long
) {
    fun toJson(): String = JSONObject().apply {
        put("version", protocolVersion)
        put("min_version", minSupportedVersion)
        put("chain_id", chainId)
        put("cipher_suite", cipherSuiteId)
        put("sender_node_id", senderNodeId)
        put("sender_public_key", senderPublicKeyHex)
        put("ephemeral_x25519_pub", ephemeralX25519PubHex)
        put("challenge", challengeHex)
        put("session_id_proposal", sessionIdProposal)
        put("timestamp", timestamp)
    }.toString()

    companion object {
        fun fromJson(json: String): SecureHandshakeInit? = try {
            val obj = JSONObject(json)
            SecureHandshakeInit(
                protocolVersion = obj.getInt("version"),
                minSupportedVersion = obj.getInt("min_version"),
                chainId = obj.getString("chain_id"),
                cipherSuiteId = obj.getString("cipher_suite"),
                senderNodeId = obj.getString("sender_node_id"),
                senderPublicKeyHex = obj.getString("sender_public_key"),
                ephemeralX25519PubHex = obj.getString("ephemeral_x25519_pub"),
                challengeHex = obj.getString("challenge"),
                sessionIdProposal = obj.getString("session_id_proposal"),
                timestamp = obj.getLong("timestamp")
            )
        } catch (_: Exception) {
            null
        }
    }
}

data class SecureHandshakeResp(
    val protocolVersion: Int,
    val minSupportedVersion: Int,
    val chainId: String,
    val cipherSuiteId: String,
    val responderNodeId: String,
    val responderPublicKeyHex: String,
    val ephemeralX25519PubHex: String,
    val counterChallengeHex: String,
    val sessionId: String,
    val timestamp: Long,
    val responderSignatureHex: String
) {
    fun toJson(): String = JSONObject().apply {
        put("version", protocolVersion)
        put("min_version", minSupportedVersion)
        put("chain_id", chainId)
        put("cipher_suite", cipherSuiteId)
        put("responder_node_id", responderNodeId)
        put("responder_public_key", responderPublicKeyHex)
        put("ephemeral_x25519_pub", ephemeralX25519PubHex)
        put("counter_challenge", counterChallengeHex)
        put("session_id", sessionId)
        put("timestamp", timestamp)
        put("signature", responderSignatureHex)
    }.toString()

    companion object {
        fun fromJson(json: String): SecureHandshakeResp? = try {
            val obj = JSONObject(json)
            SecureHandshakeResp(
                protocolVersion = obj.getInt("version"),
                minSupportedVersion = obj.getInt("min_version"),
                chainId = obj.getString("chain_id"),
                cipherSuiteId = obj.getString("cipher_suite"),
                responderNodeId = obj.getString("responder_node_id"),
                responderPublicKeyHex = obj.getString("responder_public_key"),
                ephemeralX25519PubHex = obj.getString("ephemeral_x25519_pub"),
                counterChallengeHex = obj.getString("counter_challenge"),
                sessionId = obj.getString("session_id"),
                timestamp = obj.getLong("timestamp"),
                responderSignatureHex = obj.getString("signature")
            )
        } catch (_: Exception) {
            null
        }
    }
}

data class SecureHandshakeFin(
    val protocolVersion: Int,
    val sessionId: String,
    val keyConfirmationDigestHex: String,
    val initiatorSignatureHex: String,
    val status: String = "AUTHENTICATED_ENCRYPTED"
) {
    fun toJson(): String = JSONObject().apply {
        put("version", protocolVersion)
        put("session_id", sessionId)
        put("key_confirmation_digest", keyConfirmationDigestHex)
        put("signature", initiatorSignatureHex)
        put("status", status)
    }.toString()

    companion object {
        fun fromJson(json: String): SecureHandshakeFin? = try {
            val obj = JSONObject(json)
            SecureHandshakeFin(
                protocolVersion = obj.getInt("version"),
                sessionId = obj.getString("session_id"),
                keyConfirmationDigestHex = obj.getString("key_confirmation_digest"),
                initiatorSignatureHex = obj.getString("signature"),
                status = obj.optString("status", "AUTHENTICATED_ENCRYPTED")
            )
        } catch (_: Exception) {
            null
        }
    }
}

/**
 * Authenticated ECDHE key-establishment handshake for Stage 13 (`NMD_NOISE_XX_X25519_ED25519_CHACHAPOLY_SHA256`).
 *
 * Security Properties:
 * - Binds `chainId`, `protocolVersion`, `minSupportedVersion`, and `cipherSuiteId` into transcript `h`.
 * - Generates fresh ephemeral X25519 keypairs per handshake and zeroizes private keys & ECDH shared secret
 *   immediately in `finally` blocks.
 * - Rejects downgrade attempts (including legacy plaintext v1/v2 HANDSHAKE_HELLO or mismatched suite).
 * - Validates Ed25519 identities, trust/revocation list, and non-zero X25519 public keys BEFORE registering
 *   challenges in the replay cache.
 * - Produces unidirectional ChaCha20-Poly1305 AEAD keys encapsulated in [EncryptedTransportSession].
 */
class SecureSessionHandshakeService(
    private val identityManager: NodeIdentityManager,
    private val trustManager: PeerTrustManager,
    private val config: TransportSecurityConfig = TransportSecurityConfig(),
    private val cryptoProvider: CryptographicProvider = identityManager.repository.cryptoProvider,
    context: Context? = null,
    private val replayCache: HandshakeChallengeReplayCache = HandshakeChallengeReplayCache(
        context = context,
        cryptoProvider = cryptoProvider
    ),
    private val secureRandom: SecureRandom = SecureRandom()
) {
    companion object {
        private val HEX_64_REGEX = Regex("^[0-9a-f]{64}$")
        private val HEX_128_REGEX = Regex("^[0-9a-f]{128}$")
        private const val RESP_SIGN_DOMAIN = "NMD-STAGE13-RESP-SIG\u0000"
        private const val INIT_SIGN_DOMAIN = "NMD-STAGE13-INIT-SIG\u0000"
        private const val KEY_CONFIRM_DOMAIN = "NMD-STAGE13-KEY-CONFIRM\u0000"
    }

    private fun generateRandomHex32(): String {
        val bytes = ByteArray(32)
        secureRandom.nextBytes(bytes)
        return cryptoProvider.toHex(bytes)
    }

    @Throws(IOException::class)
    fun performInitiatorHandshake(
        inputStream: InputStream,
        outputStream: OutputStream,
        expectedRemoteNodeId: String? = null,
        remoteEndpointKey: String? = null,
        nowProvider: () -> Long = { System.currentTimeMillis() }
    ): SecureHandshakeOutcome {
        val startMs = nowProvider()
        val localIdentity = identityManager.getActiveIdentity()
            ?: throw SecurityHandshakeException(SecurityEventType.HANDSHAKE_FAILED, "Local node identity not initialized")

        val myEphemeral = X25519KeyExchange.generateEphemeralKeyPair(secureRandom)
        var eeSecret: ByteArray? = null
        var keyI2R: ByteArray? = null
        var keyR2I: ByteArray? = null
        var handoffSucceeded = false

        try {
            val myChallenge = generateRandomHex32()
            val myProposalId = UUID.randomUUID().toString().replace("-", "").take(16)
            val initMsg = SecureHandshakeInit(
                protocolVersion = config.protocolVersion,
                minSupportedVersion = config.minSupportedProtocolVersion,
                chainId = config.chainId,
                cipherSuiteId = config.cipherSuiteId,
                senderNodeId = localIdentity.nodeId,
                senderPublicKeyHex = localIdentity.publicKeyHex.lowercase(),
                ephemeralX25519PubHex = cryptoProvider.toHex(myEphemeral.publicKeyBytes),
                challengeHex = myChallenge,
                sessionIdProposal = myProposalId,
                timestamp = startMs
            )
            val initBytes = initMsg.toJson().toByteArray(Charsets.UTF_8)
            if (initBytes.size > config.maxHandshakeMessageBytes) {
                throw SecurityHandshakeException(SecurityEventType.OVERSIZED_FRAME_REJECTED, "Outbound handshake init exceeds limit")
            }
            MessageFramer.writeFrame(outputStream, FrameType.SECURE_HANDSHAKE_INIT, initBytes, config.maxHandshakeMessageBytes)

            val respFrame = MessageFramer.readFrame(inputStream, config.maxHandshakeMessageBytes)
                ?: throw SecurityHandshakeException(SecurityEventType.HANDSHAKE_FAILED, "Peer closed connection before handshake response")

            if (respFrame.first == FrameType.HANDSHAKE_RESPONSE || respFrame.first == FrameType.HANDSHAKE_HELLO) {
                throw SecurityHandshakeException(
                    SecurityEventType.DOWNGRADE_REJECTED,
                    "Legacy unencrypted handshake frame 0x%02X rejected (downgrade blocked)".format(respFrame.first)
                )
            }
            if (respFrame.first != FrameType.SECURE_HANDSHAKE_RESP) {
                throw SecurityHandshakeException(
                    SecurityEventType.MALFORMED_FRAME_REJECTED,
                    "Expected SECURE_HANDSHAKE_RESP (0x05), got 0x%02X".format(respFrame.first)
                )
            }

            val resp = SecureHandshakeResp.fromJson(String(respFrame.second, Charsets.UTF_8))
                ?: throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed SECURE_HANDSHAKE_RESP payload")

            validateCommonVersionAndSuite(
                peerVersion = resp.protocolVersion,
                peerMinVersion = resp.minSupportedVersion,
                peerChainId = resp.chainId,
                peerSuite = resp.cipherSuiteId,
                peerTimestamp = resp.timestamp,
                nowMs = nowProvider()
            )
            validateChallengeAndSessionId(resp.counterChallengeHex, resp.sessionId)
            if (!resp.sessionId.startsWith("${myProposalId}_") || resp.sessionId.length < 33) {
                throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Invalid responder session ID binding")
            }

            val respIdentityPubBytes = validateRemoteNodeIdentity(
                claimedNodeId = resp.responderNodeId,
                publicKeyHex = resp.responderPublicKeyHex,
                localNodeId = localIdentity.nodeId,
                expectedRemoteNodeId = expectedRemoteNodeId,
                endpointKey = remoteEndpointKey
            )
            val respEphemeralBytes = parseAndValidateX25519Pub(resp.ephemeralX25519PubHex)

            // Register challenge in persistent replay cache ONLY AFTER all static checks pass
            try {
                replayCache.checkAndRegisterChallenge(resp.counterChallengeHex)
            } catch (e: IOException) {
                throw SecurityHandshakeException(SecurityEventType.REPLAY_REJECTED, e.message ?: "Handshake challenge replay rejected")
            }

            val schedule = buildAndPopulateTranscript(
                init = initMsg,
                initPubBytes = cryptoProvider.fromHex(initMsg.senderPublicKeyHex),
                initEphemeralBytes = myEphemeral.publicKeyBytes,
                resp = resp,
                respPubBytes = respIdentityPubBytes,
                respEphemeralBytes = respEphemeralBytes
            )
            val transcriptHash = schedule.currentTranscriptHash()

            // Verify Responder Ed25519 signature over domain + transcriptHash
            if (!HEX_128_REGEX.matches(resp.responderSignatureHex.lowercase())) {
                throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "Invalid responder signature format")
            }
            val respSigBytes = cryptoProvider.fromHex(resp.responderSignatureHex)
            val respSignInput = buildResponderSigningInput(transcriptHash)
            if (!cryptoProvider.verify(respIdentityPubBytes, respSignInput, respSigBytes)) {
                trustManager.recordAuthenticationFailed(resp.responderNodeId)
                throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "Responder Ed25519 signature verification failed")
            }

            // Compute X25519 ECDH shared secret and split into directional ChaCha20-Poly1305 keys
            eeSecret = myEphemeral.computeAgreement(respEphemeralBytes)
            val derivedKeys = schedule.mixKeyAndSplit(eeSecret, resp.sessionId)
            keyI2R = derivedKeys.initiatorToResponderKey
            keyR2I = derivedKeys.responderToInitiatorKey

            val keyConfirmDigest = computeKeyConfirmationDigest(
                transcriptHash = transcriptHash,
                keyI2R = keyI2R,
                keyR2I = keyR2I
            )
            val keyConfirmHex = cryptoProvider.toHex(keyConfirmDigest)

            val initSignInput = buildInitiatorSigningInput(transcriptHash, keyConfirmDigest)
            val mySigHex = cryptoProvider.toHex(identityManager.signRawData(initSignInput))

            val finMsg = SecureHandshakeFin(
                protocolVersion = config.protocolVersion,
                sessionId = resp.sessionId,
                keyConfirmationDigestHex = keyConfirmHex,
                initiatorSignatureHex = mySigHex
            )
            val finBytes = finMsg.toJson().toByteArray(Charsets.UTF_8)
            if (finBytes.size > config.maxHandshakeMessageBytes) {
                throw SecurityHandshakeException(SecurityEventType.OVERSIZED_FRAME_REJECTED, "Handshake fin exceeds maxHandshakeMessageBytes")
            }
            MessageFramer.writeFrame(outputStream, FrameType.SECURE_HANDSHAKE_FIN, finBytes, config.maxHandshakeMessageBytes)

            trustManager.recordAuthenticatedIdentity(resp.responderNodeId, resp.responderPublicKeyHex, remoteEndpointKey)

            val session = EncryptedTransportSession(
                sessionId = resp.sessionId,
                localNodeId = localIdentity.nodeId,
                remoteNodeId = resp.responderNodeId,
                remotePublicKeyHex = resp.responderPublicKeyHex.lowercase(),
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                cipherSuiteId = config.cipherSuiteId,
                isOutbound = true,
                sendKeyBytes = keyI2R.copyOf(),
                recvKeyBytes = keyR2I.copyOf(),
                createdAtMs = nowProvider(),
                ttlMs = config.sessionTtlMs,
                maxFramesPerSession = config.maxFramesPerSession,
                maxEncryptedFrameBytes = config.maxEncryptedFrameBytes
            )
            handoffSucceeded = true
            val latencyMs = (nowProvider() - startMs).coerceAtLeast(1L)
            return SecureHandshakeOutcome(session, latencyMs)
        } finally {
            myEphemeral.close()
            X25519KeyExchange.zeroize(eeSecret, keyI2R, keyR2I)
            if (!handoffSucceeded) {
                // Nothing leaked; keys already zeroized above
            }
        }
    }

    @Throws(IOException::class)
    fun performResponderHandshake(
        inputStream: InputStream,
        outputStream: OutputStream,
        remoteEndpointKey: String? = null,
        nowProvider: () -> Long = { System.currentTimeMillis() }
    ): SecureHandshakeOutcome {
        val startMs = nowProvider()
        val localIdentity = identityManager.getActiveIdentity()
            ?: throw SecurityHandshakeException(SecurityEventType.HANDSHAKE_FAILED, "Local node identity not initialized")

        val myEphemeral = X25519KeyExchange.generateEphemeralKeyPair(secureRandom)
        var eeSecret: ByteArray? = null
        var keyI2R: ByteArray? = null
        var keyR2I: ByteArray? = null

        try {
            val initFrame = MessageFramer.readFrame(inputStream, config.maxHandshakeMessageBytes)
                ?: throw SecurityHandshakeException(SecurityEventType.HANDSHAKE_FAILED, "Remote peer closed before sending handshake init")

            if (initFrame.first == FrameType.HANDSHAKE_HELLO) {
                throw SecurityHandshakeException(
                    SecurityEventType.DOWNGRADE_REJECTED,
                    "Rejected legacy v2 HANDSHAKE_HELLO downgrade attempt"
                )
            }
            if (initFrame.first != FrameType.SECURE_HANDSHAKE_INIT) {
                throw SecurityHandshakeException(
                    SecurityEventType.MALFORMED_FRAME_REJECTED,
                    "Expected SECURE_HANDSHAKE_INIT (0x04), got 0x%02X".format(initFrame.first)
                )
            }

            val init = SecureHandshakeInit.fromJson(String(initFrame.second, Charsets.UTF_8))
                ?: throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed SECURE_HANDSHAKE_INIT payload")

            validateCommonVersionAndSuite(
                peerVersion = init.protocolVersion,
                peerMinVersion = init.minSupportedVersion,
                peerChainId = init.chainId,
                peerSuite = init.cipherSuiteId,
                peerTimestamp = init.timestamp,
                nowMs = nowProvider()
            )
            if (!HEX_64_REGEX.matches(init.challengeHex.lowercase())) {
                throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed initiator challenge format")
            }
            if (init.sessionIdProposal.length < 16 || init.sessionIdProposal.length > 48) {
                throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed initiator sessionIdProposal")
            }

            val initIdentityPubBytes = validateRemoteNodeIdentity(
                claimedNodeId = init.senderNodeId,
                publicKeyHex = init.senderPublicKeyHex,
                localNodeId = localIdentity.nodeId,
                expectedRemoteNodeId = null,
                endpointKey = remoteEndpointKey
            )
            val initEphemeralBytes = parseAndValidateX25519Pub(init.ephemeralX25519PubHex)

            try {
                replayCache.checkAndRegisterChallenge(init.challengeHex)
            } catch (e: IOException) {
                throw SecurityHandshakeException(SecurityEventType.REPLAY_REJECTED, e.message ?: "Handshake challenge replay rejected")
            }

            val myChallenge = generateRandomHex32()
            val respNonce = UUID.randomUUID().toString().replace("-", "").take(16)
            val finalSessionId = "${init.sessionIdProposal}_${respNonce}"

            val unsignedResp = SecureHandshakeResp(
                protocolVersion = config.protocolVersion,
                minSupportedVersion = config.minSupportedProtocolVersion,
                chainId = config.chainId,
                cipherSuiteId = config.cipherSuiteId,
                responderNodeId = localIdentity.nodeId,
                responderPublicKeyHex = localIdentity.publicKeyHex.lowercase(),
                ephemeralX25519PubHex = cryptoProvider.toHex(myEphemeral.publicKeyBytes),
                counterChallengeHex = myChallenge,
                sessionId = finalSessionId,
                timestamp = nowProvider(),
                responderSignatureHex = ""
            )

            val schedule = buildAndPopulateTranscript(
                init = init,
                initPubBytes = initIdentityPubBytes,
                initEphemeralBytes = initEphemeralBytes,
                resp = unsignedResp,
                respPubBytes = cryptoProvider.fromHex(localIdentity.publicKeyHex),
                respEphemeralBytes = myEphemeral.publicKeyBytes
            )
            val transcriptHash = schedule.currentTranscriptHash()

            val respSigHex = cryptoProvider.toHex(
                identityManager.signRawData(buildResponderSigningInput(transcriptHash))
            )
            val signedResp = unsignedResp.copy(responderSignatureHex = respSigHex)
            val respBytes = signedResp.toJson().toByteArray(Charsets.UTF_8)
            if (respBytes.size > config.maxHandshakeMessageBytes) {
                throw SecurityHandshakeException(SecurityEventType.OVERSIZED_FRAME_REJECTED, "Handshake resp exceeds maxHandshakeMessageBytes")
            }
            MessageFramer.writeFrame(outputStream, FrameType.SECURE_HANDSHAKE_RESP, respBytes, config.maxHandshakeMessageBytes)

            // Read SECURE_HANDSHAKE_FIN
            val finFrame = MessageFramer.readFrame(inputStream, config.maxHandshakeMessageBytes)
                ?: throw SecurityHandshakeException(SecurityEventType.HANDSHAKE_FAILED, "Remote peer closed before sending handshake final")

            if (finFrame.first != FrameType.SECURE_HANDSHAKE_FIN) {
                throw SecurityHandshakeException(
                    SecurityEventType.MALFORMED_FRAME_REJECTED,
                    "Expected SECURE_HANDSHAKE_FIN (0x06), got 0x%02X".format(finFrame.first)
                )
            }
            val fin = SecureHandshakeFin.fromJson(String(finFrame.second, Charsets.UTF_8))
                ?: throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed SECURE_HANDSHAKE_FIN payload")

            if (fin.protocolVersion != config.protocolVersion || fin.sessionId != finalSessionId) {
                throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Handshake final session or version mismatch")
            }
            if (!HEX_64_REGEX.matches(fin.keyConfirmationDigestHex.lowercase()) ||
                !HEX_128_REGEX.matches(fin.initiatorSignatureHex.lowercase())
            ) {
                throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "Invalid initiator final confirmation or signature format")
            }

            // Compute X25519 ECDH shared secret and split keys
            eeSecret = myEphemeral.computeAgreement(initEphemeralBytes)
            val derivedKeys = schedule.mixKeyAndSplit(eeSecret, finalSessionId)
            keyI2R = derivedKeys.initiatorToResponderKey
            keyR2I = derivedKeys.responderToInitiatorKey

            val expectedConfirmDigest = computeKeyConfirmationDigest(
                transcriptHash = transcriptHash,
                keyI2R = keyI2R,
                keyR2I = keyR2I
            )
            val receivedConfirmDigest = cryptoProvider.fromHex(fin.keyConfirmationDigestHex)
            if (!MessageDigest.isEqual(expectedConfirmDigest, receivedConfirmDigest)) {
                trustManager.recordAuthenticationFailed(init.senderNodeId)
                throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "Initiator key confirmation digest mismatch")
            }

            val initSigBytes = cryptoProvider.fromHex(fin.initiatorSignatureHex)
            val expectedInitSignInput = buildInitiatorSigningInput(transcriptHash, expectedConfirmDigest)
            if (!cryptoProvider.verify(initIdentityPubBytes, expectedInitSignInput, initSigBytes)) {
                trustManager.recordAuthenticationFailed(init.senderNodeId)
                throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "Initiator Ed25519 signature verification failed")
            }

            trustManager.recordAuthenticatedIdentity(init.senderNodeId, init.senderPublicKeyHex, remoteEndpointKey)

            val session = EncryptedTransportSession(
                sessionId = finalSessionId,
                localNodeId = localIdentity.nodeId,
                remoteNodeId = init.senderNodeId,
                remotePublicKeyHex = init.senderPublicKeyHex.lowercase(),
                chainId = config.chainId,
                protocolVersion = config.protocolVersion,
                cipherSuiteId = config.cipherSuiteId,
                isOutbound = false,
                sendKeyBytes = keyR2I.copyOf(),
                recvKeyBytes = keyI2R.copyOf(),
                createdAtMs = nowProvider(),
                ttlMs = config.sessionTtlMs,
                maxFramesPerSession = config.maxFramesPerSession,
                maxEncryptedFrameBytes = config.maxEncryptedFrameBytes
            )
            val latencyMs = (nowProvider() - startMs).coerceAtLeast(1L)
            return SecureHandshakeOutcome(session, latencyMs)
        } finally {
            myEphemeral.close()
            X25519KeyExchange.zeroize(eeSecret, keyI2R, keyR2I)
        }
    }

    private fun validateCommonVersionAndSuite(
        peerVersion: Int,
        peerMinVersion: Int,
        peerChainId: String,
        peerSuite: String,
        peerTimestamp: Long,
        nowMs: Long
    ) {
        if (peerVersion < config.minSupportedProtocolVersion || peerMinVersion < config.minSupportedProtocolVersion) {
            throw SecurityHandshakeException(
                SecurityEventType.DOWNGRADE_REJECTED,
                "Downgrade attempt rejected: peer version=$peerVersion min=$peerMinVersion < required=${config.minSupportedProtocolVersion}"
            )
        }
        if (peerVersion != config.protocolVersion) {
            throw SecurityHandshakeException(
                SecurityEventType.DOWNGRADE_REJECTED,
                "Unsupported transport protocol version: $peerVersion (expected ${config.protocolVersion})"
            )
        }
        if (peerChainId != config.chainId) {
            throw SecurityHandshakeException(
                SecurityEventType.CHAIN_MISMATCH_REJECTED,
                "Chain ID mismatch: peer sent '$peerChainId', expected '${config.chainId}'"
            )
        }
        if (peerSuite != config.cipherSuiteId) {
            throw SecurityHandshakeException(
                SecurityEventType.DOWNGRADE_REJECTED,
                "Unsupported or downgraded cipher suite: $peerSuite"
            )
        }
        if (kotlin.math.abs(nowMs - peerTimestamp) > config.maxHandshakeDriftMs) {
            throw SecurityHandshakeException(
                SecurityEventType.HANDSHAKE_FAILED,
                "Handshake timestamp outside freshness window (${config.maxHandshakeDriftMs}ms)"
            )
        }
    }

    private fun validateChallengeAndSessionId(challengeHex: String, sessionId: String) {
        if (!HEX_64_REGEX.matches(challengeHex.lowercase())) {
            throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed responder challenge hex")
        }
        if (sessionId.isBlank() || sessionId.length > 96) {
            throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed sessionId")
        }
    }

    private fun validateRemoteNodeIdentity(
        claimedNodeId: String,
        publicKeyHex: String,
        localNodeId: String,
        expectedRemoteNodeId: String?,
        endpointKey: String?
    ): ByteArray {
        if (!HEX_64_REGEX.matches(publicKeyHex.lowercase())) {
            throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "Invalid Ed25519 public key format")
        }
        val pubBytes = cryptoProvider.fromHex(publicKeyHex)
        if (pubBytes.all { it == 0.toByte() }) {
            throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "All-zero Ed25519 public key rejected")
        }
        val derived = cryptoProvider.deriveNodeId(pubBytes)
        if (!derived.equals(claimedNodeId, ignoreCase = true)) {
            throw SecurityHandshakeException(SecurityEventType.SIGNATURE_INVALID, "Peer Node ID does not match SHA-256 of Ed25519 key")
        }
        if (claimedNodeId.equals(localNodeId, ignoreCase = true)) {
            throw SecurityHandshakeException(SecurityEventType.HANDSHAKE_FAILED, "Loopback self-connection rejected")
        }

        when (val trust = trustManager.checkHandshakeIdentityAllowed(claimedNodeId, publicKeyHex, endpointKey, expectedRemoteNodeId)) {
            is IdentityTrustCheckResult.Revoked -> {
                throw SecurityHandshakeException(SecurityEventType.PEER_REVOKED, "Revoked peer identity rejected: ${trust.reason}")
            }
            is IdentityTrustCheckResult.IdentityMismatch -> {
                throw SecurityHandshakeException(SecurityEventType.IDENTITY_CHANGE_DETECTED, trust.reason)
            }
            IdentityTrustCheckResult.Allowed -> Unit
        }
        return pubBytes
    }

    private fun parseAndValidateX25519Pub(hex: String): ByteArray {
        if (!HEX_64_REGEX.matches(hex.lowercase())) {
            throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "Malformed ephemeral X25519 public key format")
        }
        val bytes = cryptoProvider.fromHex(hex)
        if (!X25519KeyExchange.isValidPublicKey(bytes)) {
            throw SecurityHandshakeException(SecurityEventType.MALFORMED_FRAME_REJECTED, "All-zero ephemeral X25519 key rejected")
        }
        return bytes
    }

    private fun buildAndPopulateTranscript(
        init: SecureHandshakeInit,
        initPubBytes: ByteArray,
        initEphemeralBytes: ByteArray,
        resp: SecureHandshakeResp,
        respPubBytes: ByteArray,
        respEphemeralBytes: ByteArray
    ): NoiseStyleKeySchedule {
        val schedule = NoiseStyleKeySchedule(
            chainId = config.chainId,
            protocolVersion = config.protocolVersion,
            cipherSuiteId = config.cipherSuiteId,
            minSupportedProtocolVersion = config.minSupportedProtocolVersion
        )
        schedule.mixHash("init_node", init.senderNodeId.toByteArray(Charsets.UTF_8))
        schedule.mixHash("init_ed25519", initPubBytes)
        schedule.mixHash("init_x25519", initEphemeralBytes)
        schedule.mixHash("init_challenge", cryptoProvider.fromHex(init.challengeHex))
        schedule.mixHash("init_ts", longToBigEndian(init.timestamp))

        schedule.mixHash("resp_node", resp.responderNodeId.toByteArray(Charsets.UTF_8))
        schedule.mixHash("resp_ed25519", respPubBytes)
        schedule.mixHash("resp_x25519", respEphemeralBytes)
        schedule.mixHash("resp_challenge", cryptoProvider.fromHex(resp.counterChallengeHex))
        schedule.mixHash("resp_ts", longToBigEndian(resp.timestamp))

        schedule.mixHash("session_id", resp.sessionId.toByteArray(Charsets.UTF_8))
        return schedule
    }

    private fun buildResponderSigningInput(transcriptHash: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream()
        baos.write(RESP_SIGN_DOMAIN.toByteArray(Charsets.UTF_8))
        baos.write(transcriptHash)
        return baos.toByteArray()
    }

    private fun computeKeyConfirmationDigest(
        transcriptHash: ByteArray,
        keyI2R: ByteArray,
        keyR2I: ByteArray
    ): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.write(KEY_CONFIRM_DOMAIN.toByteArray(Charsets.UTF_8))
        dos.write(transcriptHash)
        dos.write(keyI2R)
        dos.write(keyR2I)
        dos.flush()
        return cryptoProvider.sha256(baos.toByteArray())
    }

    private fun buildInitiatorSigningInput(transcriptHash: ByteArray, keyConfirmDigest: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream()
        baos.write(INIT_SIGN_DOMAIN.toByteArray(Charsets.UTF_8))
        baos.write(transcriptHash)
        baos.write(keyConfirmDigest)
        return baos.toByteArray()
    }

    private fun longToBigEndian(value: Long): ByteArray = byteArrayOf(
        ((value ushr 56) and 0xFF).toByte(),
        ((value ushr 48) and 0xFF).toByte(),
        ((value ushr 40) and 0xFF).toByte(),
        ((value ushr 32) and 0xFF).toByte(),
        ((value ushr 24) and 0xFF).toByte(),
        ((value ushr 16) and 0xFF).toByte(),
        ((value ushr 8) and 0xFF).toByte(),
        (value and 0xFF).toByte()
    )
}
