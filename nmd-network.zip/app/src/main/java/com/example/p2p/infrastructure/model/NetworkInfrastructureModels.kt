package com.example.p2p.infrastructure.model

import com.example.blockchain.config.GenesisConfig
import com.example.blockchain.config.NmdGenesisConfigs
import com.example.blockchain.crypto.BlockHasher
import com.example.blockchain.genesis.GenesisBlockFactory
import com.example.crypto.model.NodeIdentity
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import kotlin.math.min
import kotlin.random.Random

/**
 * Separated NMD Network profiles for Stage 15.
 * MAINNET remains disabled until an explicit, valid configuration with matching
 * Chain ID and Genesis Hash is provided externally.
 */
enum class NmdNetworkProfile {
    DEVELOPMENT,
    TESTNET,
    MAINNET
}

enum class BootstrapTransportProtocol {
    HTTPS,
    HTTP_DEV_ONLY
}

enum class EndpointHealthState {
    UNKNOWN,
    HEALTHY,
    DEGRADED,
    COOLDOWN,
    UNAVAILABLE,
    CONFIG_INVALID
}

enum class SignalingTransportStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    AUTHENTICATED,
    RECONNECTING,
    TLS_ERROR,
    FAILED
}

/**
 * Authoritative deterministic mapping between Stage 15 Network Profiles and Stage 8 Genesis configs.
 * Never fabricates public endpoints or enables mainnet automatically.
 */
object NetworkProfileRegistry {
    private val genesisFactory = GenesisBlockFactory(BlockHasher())

    fun genesisConfigFor(profile: NmdNetworkProfile): GenesisConfig = when (profile) {
        NmdNetworkProfile.DEVELOPMENT -> NmdGenesisConfigs.LOCAL_DEV
        NmdNetworkProfile.TESTNET -> NmdGenesisConfigs.PRIVATE_TESTNET
        NmdNetworkProfile.MAINNET -> NmdGenesisConfigs.MAINNET_FUTURE
    }

    fun canonicalGenesisHashFor(profile: NmdNetworkProfile): String {
        return genesisFactory.createGenesisBlock(genesisConfigFor(profile)).hash
    }

    fun defaultConfigFor(profile: NmdNetworkProfile): NetworkProfileConfig {
        val g = genesisConfigFor(profile)
        val genesisHash = genesisFactory.createGenesisBlock(g).hash
        return NetworkProfileConfig(
            profile = profile,
            chainId = g.chainId,
            expectedGenesisHash = genesisHash,
            protocolVersion = g.parameters.protocolVersion,
            isMainnetActivated = false,
            bootstrapEndpoints = emptyList(),
            signalingEndpoints = emptyList(),
            allowLocalTestOverride = (profile == NmdNetworkProfile.DEVELOPMENT)
        )
    }
}

/**
 * Configurable bootstrap endpoint descriptor.
 * Never embeds invented production domains or private credentials.
 */
data class BootstrapEndpointConfig(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val protocol: BootstrapTransportProtocol = BootstrapTransportProtocol.HTTPS,
    val requireTls: Boolean = true,
    val pinnedTlsSha256: String? = null,
    val expectedNodeId: String? = null,
    val expectedPublicKeyHex: String? = null,
    val networkProfile: NmdNetworkProfile = NmdNetworkProfile.TESTNET,
    val isEnabled: Boolean = true,
    val priority: Int = 10,
    val lastSuccessfulConnectionMs: Long? = null,
    val lastAttemptMs: Long? = null,
    val consecutiveFailures: Int = 0,
    val cooldownUntilEpochMs: Long = 0L,
    val healthState: EndpointHealthState = EndpointHealthState.UNKNOWN,
    val lastError: String? = null
) {
    companion object {
        const val BASE_COOLDOWN_MS = 3_000L
        const val MAX_COOLDOWN_MS = 120_000L

        fun computeBackoffWithJitterMs(failures: Int, random: Random = Random.Default): Long {
            if (failures <= 0) return 0L
            val shift = min(failures - 1, 5)
            val base = min(MAX_COOLDOWN_MS, BASE_COOLDOWN_MS * (1L shl shift))
            val jitter = random.nextLong(0L, (base / 4L).coerceAtLeast(1L))
            return min(MAX_COOLDOWN_MS, base + jitter)
        }

        fun isLoopbackOrDevHost(host: String): Boolean {
            val h = host.trim().lowercase()
            return h == "localhost" ||
                h == "127.0.0.1" ||
                h == "::1" ||
                h == "[::1]" ||
                h == "10.0.2.2" ||
                h.endsWith(".local")
        }

        fun fromJson(json: JSONObject): BootstrapEndpointConfig? {
            return try {
                BootstrapEndpointConfig(
                    id = json.getString("id"),
                    name = json.getString("name"),
                    host = json.getString("host"),
                    port = json.getInt("port"),
                    protocol = BootstrapTransportProtocol.valueOf(json.optString("protocol", "HTTPS")),
                    requireTls = json.optBoolean("require_tls", true),
                    pinnedTlsSha256 = json.optString("pinned_tls_sha256", "").ifBlank { null },
                    expectedNodeId = json.optString("expected_node_id", "").ifBlank { null },
                    expectedPublicKeyHex = json.optString("expected_pubkey_hex", "").ifBlank { null },
                    networkProfile = NmdNetworkProfile.valueOf(json.optString("network_profile", "TESTNET")),
                    isEnabled = json.optBoolean("is_enabled", true),
                    priority = json.optInt("priority", 10),
                    lastSuccessfulConnectionMs = if (json.has("last_success_ms")) json.getLong("last_success_ms") else null,
                    lastAttemptMs = if (json.has("last_attempt_ms")) json.getLong("last_attempt_ms") else null,
                    consecutiveFailures = json.optInt("consecutive_failures", 0),
                    cooldownUntilEpochMs = json.optLong("cooldown_until_ms", 0L),
                    healthState = EndpointHealthState.valueOf(json.optString("health_state", "UNKNOWN")),
                    lastError = json.optString("last_error", "").ifBlank { null }
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    val baseUrl: String
        get() {
            val scheme = if (protocol == BootstrapTransportProtocol.HTTPS) "https" else "http"
            val formattedHost = if (host.contains(":") && !host.startsWith("[")) "[$host]" else host
            return "$scheme://$formattedHost:$port"
        }

    fun isInCooldown(nowMs: Long = System.currentTimeMillis()): Boolean = nowMs < cooldownUntilEpochMs

    fun validateForProfile(
        targetProfile: NmdNetworkProfile,
        allowLocalTestOverride: Boolean = false
    ): String? {
        if (host.isBlank() || host.length > 253 || host.any { it.isWhitespace() || it == '\r' || it == '\n' }) {
            return "Invalid bootstrap hostname/IP"
        }
        if (port !in 1..65535) {
            return "Bootstrap port must be in 1..65535"
        }
        if (networkProfile != targetProfile) {
            return "Endpoint profile ${networkProfile.name} does not match active profile ${targetProfile.name}"
        }
        if (targetProfile != NmdNetworkProfile.DEVELOPMENT) {
            if (requireTls && protocol != BootstrapTransportProtocol.HTTPS) {
                return "${targetProfile.name} requires HTTPS/TLS for bootstrap connections"
            }
            if (!allowLocalTestOverride && isLoopbackOrDevHost(host)) {
                return "Loopback/development host ($host) cannot be used in ${targetProfile.name}"
            }
        }
        if (pinnedTlsSha256 != null && !pinnedTlsSha256.startsWith("sha256/")) {
            return "TLS certificate pin must use 'sha256/...' format"
        }
        return null
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("host", host)
        put("port", port)
        put("protocol", protocol.name)
        put("require_tls", requireTls)
        if (pinnedTlsSha256 != null) put("pinned_tls_sha256", pinnedTlsSha256)
        if (expectedNodeId != null) put("expected_node_id", expectedNodeId)
        if (expectedPublicKeyHex != null) put("expected_pubkey_hex", expectedPublicKeyHex)
        put("network_profile", networkProfile.name)
        put("is_enabled", isEnabled)
        put("priority", priority)
        if (lastSuccessfulConnectionMs != null) put("last_success_ms", lastSuccessfulConnectionMs)
        if (lastAttemptMs != null) put("last_attempt_ms", lastAttemptMs)
        put("consecutive_failures", consecutiveFailures)
        put("cooldown_until_ms", cooldownUntilEpochMs)
        put("health_state", healthState.name)
        if (lastError != null) put("last_error", lastError)
    }
}

data class SignalingEndpointConfig(
    val id: String,
    val name: String,
    val url: String,
    val requireTls: Boolean = true,
    val pinnedTlsSha256: String? = null,
    val expectedServerPublicKeyHex: String? = null,
    val networkProfile: NmdNetworkProfile = NmdNetworkProfile.TESTNET,
    val isEnabled: Boolean = true,
    val priority: Int = 10,
    val lastConnectedMs: Long? = null,
    val consecutiveFailures: Int = 0,
    val cooldownUntilEpochMs: Long = 0L,
    val healthState: EndpointHealthState = EndpointHealthState.UNKNOWN,
    val lastError: String? = null
) {
    companion object {
        fun fromJson(json: JSONObject): SignalingEndpointConfig? {
            return try {
                SignalingEndpointConfig(
                    id = json.getString("id"),
                    name = json.getString("name"),
                    url = json.getString("url"),
                    requireTls = json.optBoolean("require_tls", true),
                    pinnedTlsSha256 = json.optString("pinned_tls_sha256", "").ifBlank { null },
                    expectedServerPublicKeyHex = json.optString("expected_pubkey_hex", "").ifBlank { null },
                    networkProfile = NmdNetworkProfile.valueOf(json.optString("network_profile", "TESTNET")),
                    isEnabled = json.optBoolean("is_enabled", true),
                    priority = json.optInt("priority", 10),
                    lastConnectedMs = if (json.has("last_connected_ms")) json.getLong("last_connected_ms") else null,
                    consecutiveFailures = json.optInt("consecutive_failures", 0),
                    cooldownUntilEpochMs = json.optLong("cooldown_until_ms", 0L),
                    healthState = EndpointHealthState.valueOf(json.optString("health_state", "UNKNOWN")),
                    lastError = json.optString("last_error", "").ifBlank { null }
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    fun validateForProfile(
        targetProfile: NmdNetworkProfile,
        allowLocalTestOverride: Boolean = false
    ): String? {
        val trimmed = url.trim()
        val isWss = trimmed.startsWith("wss://", ignoreCase = true)
        val isWs = trimmed.startsWith("ws://", ignoreCase = true)
        if (!isWss && !isWs) {
            return "Signaling URL must start with wss:// or ws://"
        }
        if (networkProfile != targetProfile) {
            return "Signaling endpoint profile ${networkProfile.name} mismatches ${targetProfile.name}"
        }
        val parsedUri = try {
            java.net.URI(trimmed)
        } catch (_: Exception) {
            return "Malformed signaling WebSocket URI"
        }
        val host = parsedUri.host.orEmpty()
        if (host.isBlank()) return "Signaling URI missing host"

        if (targetProfile != NmdNetworkProfile.DEVELOPMENT) {
            if (requireTls && !isWss) {
                return "${targetProfile.name} requires wss:// TLS WebSocket for signaling"
            }
            if (!allowLocalTestOverride && BootstrapEndpointConfig.isLoopbackOrDevHost(host)) {
                return "Loopback/development host ($host) cannot be used in ${targetProfile.name}"
            }
        }
        if (pinnedTlsSha256 != null && !pinnedTlsSha256.startsWith("sha256/")) {
            return "TLS pin must use 'sha256/...' format"
        }
        return null
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("url", url)
        put("require_tls", requireTls)
        if (pinnedTlsSha256 != null) put("pinned_tls_sha256", pinnedTlsSha256)
        if (expectedServerPublicKeyHex != null) put("expected_pubkey_hex", expectedServerPublicKeyHex)
        put("network_profile", networkProfile.name)
        put("is_enabled", isEnabled)
        put("priority", priority)
        if (lastConnectedMs != null) put("last_connected_ms", lastConnectedMs)
        put("consecutive_failures", consecutiveFailures)
        put("cooldown_until_ms", cooldownUntilEpochMs)
        put("health_state", healthState.name)
        if (lastError != null) put("last_error", lastError)
    }
}

data class NetworkProfileConfig(
    val profile: NmdNetworkProfile,
    val chainId: String,
    val expectedGenesisHash: String,
    val protocolVersion: Int = 1,
    val isMainnetActivated: Boolean = false,
    val bootstrapEndpoints: List<BootstrapEndpointConfig> = emptyList(),
    val signalingEndpoints: List<SignalingEndpointConfig> = emptyList(),
    val allowLocalTestOverride: Boolean = false
) {
    fun validate(): String? {
        if (chainId.isBlank()) return "Chain ID cannot be blank"
        if (expectedGenesisHash.length != 64 || !expectedGenesisHash.all { it.lowercaseChar() in '0'..'9' || it.lowercaseChar() in 'a'..'f' }) {
            return "Genesis hash must be a valid 64-character hex string"
        }
        val expectedCanonical = NetworkProfileRegistry.genesisConfigFor(profile)
        val expectedHash = NetworkProfileRegistry.canonicalGenesisHashFor(profile)
        if (chainId != expectedCanonical.chainId) {
            return "Chain ID '$chainId' does not match profile ${profile.name} ('${expectedCanonical.chainId}')"
        }
        if (!expectedGenesisHash.equals(expectedHash, ignoreCase = true)) {
            return "Genesis hash does not match deterministic ${profile.name} genesis block"
        }
        if (profile == NmdNetworkProfile.MAINNET) {
            if (!isMainnetActivated) {
                return "Mainnet is disabled until an explicit, externally verified mainnet deployment configuration is activated"
            }
            val validBootstrap = bootstrapEndpoints.count { it.isEnabled && it.validateForProfile(NmdNetworkProfile.MAINNET, allowLocalTestOverride) == null }
            val validSignaling = signalingEndpoints.count { it.isEnabled && it.validateForProfile(NmdNetworkProfile.MAINNET, allowLocalTestOverride) == null }
            if (validBootstrap == 0 || validSignaling == 0) {
                return "Mainnet requires at least one valid TLS bootstrap endpoint and one valid wss:// signaling endpoint"
            }
        }
        for (ep in bootstrapEndpoints) {
            val err = ep.validateForProfile(profile, allowLocalTestOverride)
            if (err != null) return err
        }
        for (sig in signalingEndpoints) {
            val err = sig.validateForProfile(profile, allowLocalTestOverride)
            if (err != null) return err
        }
        return null
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("profile", profile.name)
        put("chain_id", chainId)
        put("expected_genesis_hash", expectedGenesisHash)
        put("protocol_version", protocolVersion)
        put("is_mainnet_activated", isMainnetActivated)
        put("allow_local_test_override", allowLocalTestOverride)
        put("bootstrap_endpoints", JSONArray().apply { bootstrapEndpoints.forEach { put(it.toJson()) } })
        put("signaling_endpoints", JSONArray().apply { signalingEndpoints.forEach { put(it.toJson()) } })
    }

    companion object {
        fun fromJson(json: JSONObject): NetworkProfileConfig? {
            return try {
                val profile = NmdNetworkProfile.valueOf(json.getString("profile"))
                val bootstrapArr = json.optJSONArray("bootstrap_endpoints") ?: JSONArray()
                val bootstrap = buildList {
                    for (i in 0 until bootstrapArr.length()) {
                        BootstrapEndpointConfig.fromJson(bootstrapArr.getJSONObject(i))?.let { add(it) }
                    }
                }
                val signalingArr = json.optJSONArray("signaling_endpoints") ?: JSONArray()
                val signaling = buildList {
                    for (i in 0 until signalingArr.length()) {
                        SignalingEndpointConfig.fromJson(signalingArr.getJSONObject(i))?.let { add(it) }
                    }
                }
                NetworkProfileConfig(
                    profile = profile,
                    chainId = json.getString("chain_id"),
                    expectedGenesisHash = json.getString("expected_genesis_hash"),
                    protocolVersion = json.optInt("protocol_version", 1),
                    isMainnetActivated = json.optBoolean("is_mainnet_activated", false),
                    bootstrapEndpoints = bootstrap,
                    signalingEndpoints = signaling,
                    allowLocalTestOverride = json.optBoolean("allow_local_test_override", false)
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

data class BootstrapPeerRecord(
    val nodeId: String,
    val publicKeyHex: String,
    val protocolVersion: Int,
    val chainId: String,
    val genesisHash: String,
    val host: String,
    val port: Int,
    val lastSeenTimestampMs: Long,
    val capabilities: List<String>,
    val availabilityStatus: String
) {
    companion object {
        const val MAX_RECORD_AGE_MS = 20 * 60_000L
        const val MAX_FUTURE_DRIFT_MS = 120_000L

        fun validateDerivedIdentity(nodeId: String, publicKeyHex: String): Boolean {
            if (!nodeId.startsWith(NodeIdentity.NODE_ID_PREFIX) || publicKeyHex.length != 64) return false
            return try {
                val pubBytes = ByteArray(32) { i ->
                    publicKeyHex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                }
                val digest = MessageDigest.getInstance("SHA-256").digest(pubBytes)
                val expected = NodeIdentity.NODE_ID_PREFIX + digest.joinToString("") { "%02x".format(it) }.substring(0, 32)
                nodeId == expected
            } catch (_: Exception) {
                false
            }
        }

        fun fromJson(json: JSONObject): BootstrapPeerRecord? {
            return try {
                val capsArr = json.optJSONArray("capabilities") ?: JSONArray()
                val caps = buildList {
                    for (i in 0 until capsArr.length()) add(capsArr.getString(i))
                }
                BootstrapPeerRecord(
                    nodeId = json.getString("node_id"),
                    publicKeyHex = json.getString("public_key_hex"),
                    protocolVersion = json.getInt("protocol_version"),
                    chainId = json.getString("chain_id"),
                    genesisHash = json.getString("genesis_hash"),
                    host = json.getString("host"),
                    port = json.getInt("port"),
                    lastSeenTimestampMs = json.getLong("last_seen_ms"),
                    capabilities = caps,
                    availabilityStatus = json.optString("availability_status", "UNKNOWN")
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    fun validateAgainst(
        activeConfig: NetworkProfileConfig,
        localNodeId: String?,
        nowMs: Long = System.currentTimeMillis()
    ): String? {
        if (nodeId == localNodeId) return "Self node record skipped"
        if (chainId != activeConfig.chainId) return "Peer chainId '$chainId' != '${activeConfig.chainId}'"
        if (!genesisHash.equals(activeConfig.expectedGenesisHash, ignoreCase = true)) {
            return "Peer genesisHash mismatch"
        }
        if (protocolVersion != activeConfig.protocolVersion) {
            return "Incompatible protocol version $protocolVersion"
        }
        if (!validateDerivedIdentity(nodeId, publicKeyHex)) {
            return "Node ID does not match Ed25519 public key derivation"
        }
        if (host.isBlank() || host.length > 253 || host.any { it.isWhitespace() || it == '\r' || it == '\n' }) {
            return "Invalid advertised peer host"
        }
        if (port !in 1..65535) return "Invalid advertised peer port $port"
        if (nowMs - lastSeenTimestampMs > MAX_RECORD_AGE_MS) {
            return "Peer record expired (${(nowMs - lastSeenTimestampMs) / 1000L}s old)"
        }
        if (lastSeenTimestampMs - nowMs > MAX_FUTURE_DRIFT_MS) {
            return "Peer lastSeen timestamp too far in future"
        }
        return null
    }
}

data class NetworkInfrastructureSnapshot(
    val activeProfile: NmdNetworkProfile = NmdNetworkProfile.DEVELOPMENT,
    val isMainnetActivated: Boolean = false,
    val chainId: String = NmdGenesisConfigs.LOCAL_DEV.chainId,
    val genesisHashFull: String = NetworkProfileRegistry.canonicalGenesisHashFor(NmdNetworkProfile.DEVELOPMENT),
    val configuredBootstrapCount: Int = 0,
    val healthyBootstrapCount: Int = 0,
    val unavailableBootstrapCount: Int = 0,
    val bootstrapEndpoints: List<BootstrapEndpointConfig> = emptyList(),
    val activeSignalingEndpoint: String? = null,
    val signalingStatus: SignalingTransportStatus = SignalingTransportStatus.DISCONNECTED,
    val signalingEndpoints: List<SignalingEndpointConfig> = emptyList(),
    val discoveredPeersCount: Int = 0,
    val authenticatedPeersCount: Int = 0,
    val directConnectionsCount: Int = 0,
    val relayConnectionsCount: Int = 0,
    val lastDirectoryRefreshMs: Long? = null,
    val lastBootstrapSuccessMs: Long? = null,
    val currentEndpointFailures: Int = 0,
    val lastEndpointError: String? = null,
    val isOfflineOperatingOnExistingPeers: Boolean = false,
    val lastStatusSummary: String = "Bootstrap idle; configure endpoints to join external network"
) {
    val shortenedGenesisHash: String
        get() = if (genesisHashFull.length > 18) {
            "${genesisHashFull.take(10)}...${genesisHashFull.takeLast(8)}"
        } else {
            genesisHashFull
        }
}
