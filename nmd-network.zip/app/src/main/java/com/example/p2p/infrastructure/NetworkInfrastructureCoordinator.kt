package com.example.p2p.infrastructure

import android.content.Context
import com.example.crypto.NodeIdentityManager
import com.example.p2p.connectivity.PeerConnectivityManager
import com.example.p2p.connectivity.model.TransportPathType
import com.example.p2p.connectivity.signaling.SignalingChannel
import com.example.p2p.discovery.DistributedDiscoveryCoordinator
import com.example.p2p.infrastructure.bootstrap.BootstrapNodeManager
import com.example.p2p.infrastructure.model.EndpointHealthState
import com.example.p2p.infrastructure.model.NetworkInfrastructureSnapshot
import com.example.p2p.infrastructure.model.NetworkProfileConfig
import com.example.p2p.infrastructure.model.NetworkProfileRegistry
import com.example.p2p.infrastructure.model.NmdNetworkProfile
import com.example.p2p.infrastructure.model.SignalingTransportStatus
import com.example.p2p.infrastructure.signaling.WebSocketSignalingChannel
import com.example.p2p.manager.PeerConnectionManager
import com.example.p2p.model.RealPeerConnectionState
import com.example.p2p.transport.P2PTransport
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.Closeable

/**
 * Coordinates Stage 15 Public Network Infrastructure:
 * 1. Network Profile isolation (DEVELOPMENT / TESTNET / MAINNET-disabled-until-configured)
 * 2. Multi-endpoint Bootstrap discovery & health monitoring
 * 3. Production WebSocket (WSS) signaling channel lifecycle & automatic reconnection
 * 4. Startup onboarding: Bootstrap -> Validate Records -> Stage 14 ICE -> Stage 13 Auth -> Stage 7 PEX
 * 5. Continued peer operation when bootstrap servers go offline
 */
class NetworkInfrastructureCoordinator(
    private val context: Context?,
    private val identityManager: NodeIdentityManager,
    private val transport: P2PTransport,
    private val connectionManager: PeerConnectionManager,
    private val discoveryCoordinator: DistributedDiscoveryCoordinator,
    private val connectivityManager: PeerConnectivityManager,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    val bootstrapManager: BootstrapNodeManager = BootstrapNodeManager(
        context = context,
        identityManager = identityManager,
        peerRegistry = discoveryCoordinator.peerRegistry,
        trustManager = connectionManager.transportSecurityManager.trustManager,
        ioDispatcher = ioDispatcher
    ),
    val webSocketSignalingChannel: WebSocketSignalingChannel = WebSocketSignalingChannel(
        identityManager = identityManager,
        scope = scope,
        ioDispatcher = ioDispatcher
    )
) : Closeable {

    companion object {
        private const val PERIODIC_REFRESH_INTERVAL_MS = 5 * 60_000L // Battery-friendly 5 min directory refresh
    }

    private val _snapshot = MutableStateFlow(NetworkInfrastructureSnapshot())
    val snapshot: StateFlow<NetworkInfrastructureSnapshot> = _snapshot.asStateFlow()

    private val monitorJobs = mutableListOf<Job>()
    private var periodicRefreshJob: Job? = null

    @Volatile
    private var statusMessageOverride: String? = null

    init {
        monitorJobs += scope.launch(ioDispatcher) {
            bootstrapManager.activeProfileConfig.collect { rebuildSnapshot() }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            webSocketSignalingChannel.status.collect { rebuildSnapshot() }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            webSocketSignalingChannel.activeEndpointUrl.collect { rebuildSnapshot() }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            webSocketSignalingChannel.lastError.collect { rebuildSnapshot() }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            connectionManager.authenticatedPeers.collect { rebuildSnapshot() }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            discoveryCoordinator.registeredPeers.collect { rebuildSnapshot() }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            connectivityManager.diagnostics.collect { rebuildSnapshot() }
        }
        monitorJobs += scope.launch(ioDispatcher) {
            connectivityManager.networkMonitor.networkChanges.collect { change ->
                if (change.newType != com.example.p2p.connectivity.model.NetworkInterfaceType.NONE) {
                    webSocketSignalingChannel.triggerReconnect("Network changed to ${change.newType.name}")
                    bootstrapManager.probeAllEndpointsHealth()
                }
                rebuildSnapshot()
            }
        }
        rebuildSnapshot()
    }

    /**
     * Configures active network profile + bootstrap & signaling endpoints safely.
     * Enforces Chain ID & Genesis Hash consistency, attaches signaling transport if configured,
     * and prevents unsafe/unactivated MAINNET switching.
     */
    fun applyNetworkProfileConfig(
        newConfig: NetworkProfileConfig,
        attachWebSocketChannel: Boolean = true
    ): Result<NetworkProfileConfig> {
        val applied = bootstrapManager.applyProfileConfiguration(newConfig)
        if (applied.isFailure) {
            statusMessageOverride = applied.exceptionOrNull()?.message
            rebuildSnapshot()
            return applied
        }

        if (attachWebSocketChannel) {
            val sigRes = webSocketSignalingChannel.configureAndConnect(
                profile = newConfig.profile,
                chainId = newConfig.chainId,
                endpoints = newConfig.signalingEndpoints,
                allowLocalTestOverride = newConfig.allowLocalTestOverride
            )
            if (sigRes.isFailure) {
                statusMessageOverride = sigRes.exceptionOrNull()?.message
                rebuildSnapshot()
                return Result.failure(sigRes.exceptionOrNull()!!)
            }
            if (newConfig.signalingEndpoints.any { it.isEnabled }) {
                connectivityManager.attachSignalingChannel(webSocketSignalingChannel)
            }
        }
        statusMessageOverride = "Active profile set to ${newConfig.profile.name} (${newConfig.chainId})"
        rebuildSnapshot()
        return applied
    }

    fun attachCustomSignalingChannel(channel: SignalingChannel) {
        connectivityManager.attachSignalingChannel(channel)
        statusMessageOverride = "Signaling attached: ${channel.channelName}"
        rebuildSnapshot()
    }

    /**
     * Executes full device onboarding & peer discovery pipeline:
     * 1. Check active network configuration & Chain ID / Genesis Hash.
     * 2. Connect to prioritized bootstrap endpoints (with automatic failover).
     * 3. Validate returned peer records (reject malformed/wrong-chain/expired/revoked).
     * 4. Attempt connections via Stage 14 NAT traversal + Stage 13 X25519/Ed25519 authentication.
     * 5. Once authenticated peers exist, trigger Stage 7 PEX expansion (bootstrap no longer required).
     */
    suspend fun bootstrapAndSyncPeers(
        maxInitialConnections: Int = 4,
        registerSelfIfListening: Boolean = true
    ): Result<Int> {
        val cfg = bootstrapManager.activeProfileConfig.value
        val cfgErr = cfg.validate()
        if (cfgErr != null) {
            statusMessageOverride = cfgErr
            rebuildSnapshot()
            return Result.failure(IllegalStateException(cfgErr))
        }

        val boundPort = transport.boundPort.value
        if (registerSelfIfListening && boundPort != null && boundPort > 0) {
            bootstrapManager.registerLocalNodeWithBootstrap(
                advertisedHost = transport.getLocalIpAddress(),
                advertisedPort = boundPort
            )
        }

        val discoveryRes = bootstrapManager.discoverInitialPeers(limit = 30)
        if (discoveryRes.isFailure) {
            // Operational resilience: keep operating seamlessly if authenticated peers are already connected
            val activeAuth = connectionManager.authenticatedPeers.value.count { it.state == RealPeerConnectionState.AUTHENTICATED }
            statusMessageOverride = if (activeAuth > 0) {
                "Bootstrap unavailable; operating cleanly via $activeAuth active peer(s) & PEX"
            } else {
                discoveryRes.exceptionOrNull()?.message ?: "Bootstrap unavailable"
            }
            rebuildSnapshot()
            return if (activeAuth > 0) Result.success(0) else Result.failure(discoveryRes.exceptionOrNull()!!)
        }

        val outcome = discoveryRes.getOrThrow()
        var newlyConnected = 0
        for (peer in outcome.validPeersAccepted.take(maxInitialConnections)) {
            if (connectionManager.authenticatedPeers.value.size >= connectionManager.topologyManager.maxConnectedPeers) break
            val localEp = com.example.p2p.model.PeerEndpoint(peer.host, peer.port, peer.nodeId)
            val connRes = connectivityManager.connectToPeerSmart(
                targetNodeId = peer.nodeId,
                localEndpoint = localEp,
                preferRelayFallback = true
            )
            if (connRes.isSuccess) {
                newlyConnected++
            }
        }

        // Expand peer registry via Stage 7 decentralized PEX across authenticated sessions
        if (connectionManager.authenticatedPeers.value.isNotEmpty()) {
            runCatching { discoveryCoordinator.requestPeerExchangeFromAll() }
        }

        statusMessageOverride = "Discovered ${outcome.validPeersAccepted.size} valid peer(s); connected $newlyConnected"
        rebuildSnapshot()
        return Result.success(newlyConnected)
    }

    fun startPeriodicBackgroundRefresh() {
        if (periodicRefreshJob?.isActive == true) return
        periodicRefreshJob = scope.launch(ioDispatcher) {
            while (isActive) {
                delay(PERIODIC_REFRESH_INTERVAL_MS)
                val cfg = bootstrapManager.activeProfileConfig.value
                if (cfg.bootstrapEndpoints.any { it.isEnabled }) {
                    runCatching { bootstrapManager.probeAllEndpointsHealth() }
                    if (connectionManager.authenticatedPeers.value.isEmpty()) {
                        runCatching { bootstrapAndSyncPeers(maxInitialConnections = 3, registerSelfIfListening = false) }
                    } else {
                        runCatching { discoveryCoordinator.requestPeerExchangeFromAll() }
                    }
                }
            }
        }
    }

    fun stopPeriodicBackgroundRefresh() {
        periodicRefreshJob?.cancel()
        periodicRefreshJob = null
    }

    fun switchProfilePreset(profile: NmdNetworkProfile): Result<NetworkProfileConfig> {
        if (profile == NmdNetworkProfile.MAINNET) {
            statusMessageOverride = "Mainnet requires explicit valid endpoint & activation config"
            rebuildSnapshot()
            return Result.failure(IllegalStateException("Mainnet disabled until externally configured and activated"))
        }
        return applyNetworkProfileConfig(NetworkProfileRegistry.defaultConfigFor(profile))
    }

    private fun rebuildSnapshot() {
        val cfg = bootstrapManager.activeProfileConfig.value
        val bootstrapList = cfg.bootstrapEndpoints
        val healthyCount = bootstrapList.count { it.isEnabled && it.healthState == EndpointHealthState.HEALTHY }
        val unavailableCount = bootstrapList.count {
            it.isEnabled && (it.healthState == EndpointHealthState.UNAVAILABLE || it.healthState == EndpointHealthState.COOLDOWN || it.healthState == EndpointHealthState.CONFIG_INVALID)
        }
        val authPeers = connectionManager.authenticatedPeers.value.filter { it.state == RealPeerConnectionState.AUTHENTICATED }
        val directCount = authPeers.count {
            it.transportPathType == TransportPathType.LOCAL_DIRECT_TCP || it.transportPathType == TransportPathType.ICE_DIRECT
        }
        val relayCount = authPeers.count { it.transportPathType == TransportPathType.TURN_RELAY }
        val discoveredCount = discoveryCoordinator.registeredPeers.value.size
        val failureCount = bootstrapList.count { it.consecutiveFailures > 0 || it.lastError != null } +
            if (webSocketSignalingChannel.lastError.value != null) 1 else 0

        val isOperatingWithoutBootstrap = authPeers.isNotEmpty() &&
            (bootstrapList.isEmpty() || unavailableCount == bootstrapList.count { it.isEnabled })

        _snapshot.value = NetworkInfrastructureSnapshot(
            activeProfile = cfg.profile,
            isMainnetActivated = cfg.isMainnetActivated,
            chainId = cfg.chainId,
            genesisHashFull = cfg.expectedGenesisHash,
            configuredBootstrapCount = bootstrapList.count { it.isEnabled },
            healthyBootstrapCount = healthyCount,
            unavailableBootstrapCount = unavailableCount,
            bootstrapEndpoints = bootstrapList,
            activeSignalingEndpoint = webSocketSignalingChannel.activeEndpointUrl.value,
            signalingStatus = webSocketSignalingChannel.status.value,
            signalingEndpoints = cfg.signalingEndpoints,
            discoveredPeersCount = discoveredCount,
            authenticatedPeersCount = authPeers.size,
            directConnectionsCount = directCount,
            relayConnectionsCount = relayCount,
            lastDirectoryRefreshMs = bootstrapManager.lastDirectoryRefreshMs.value,
            lastBootstrapSuccessMs = bootstrapManager.lastBootstrapSuccessMs.value,
            currentEndpointFailures = failureCount,
            lastEndpointError = bootstrapManager.lastErrorSummary.value ?: webSocketSignalingChannel.lastError.value,
            isOfflineOperatingOnExistingPeers = isOperatingWithoutBootstrap,
            lastStatusSummary = statusMessageOverride
                ?: "Profile ${cfg.profile.name} (${cfg.chainId})"
        )
    }

    override fun close() {
        stopPeriodicBackgroundRefresh()
        monitorJobs.forEach { it.cancel() }
        monitorJobs.clear()
        webSocketSignalingChannel.close()
    }
}
