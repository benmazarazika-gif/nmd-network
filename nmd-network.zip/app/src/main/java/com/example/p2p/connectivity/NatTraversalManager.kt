package com.example.p2p.connectivity

import com.example.crypto.NodeIdentityManager
import com.example.p2p.connectivity.ice.IceEngine
import com.example.p2p.connectivity.ice.IcePeerSession
import com.example.p2p.connectivity.ice.IceSessionCallbacks
import com.example.p2p.connectivity.ice.IceSessionConfig
import com.example.p2p.connectivity.model.IceCandidateInfo
import com.example.p2p.connectivity.model.IceCandidateType
import com.example.p2p.connectivity.model.IceConnectionStatus
import com.example.p2p.connectivity.model.IceGatheringProgress
import com.example.p2p.connectivity.model.NatTraversalConfig
import com.example.p2p.connectivity.model.StunServerConfig
import com.example.p2p.connectivity.model.TransportPathType
import com.example.p2p.connectivity.model.TurnServerConfig
import com.example.p2p.connectivity.relay.RelayConnectionManager
import com.example.p2p.connectivity.selector.NetworkPathSelector
import com.example.p2p.connectivity.signaling.CandidateIngestOutcome
import com.example.p2p.connectivity.signaling.PeerSignalingService
import com.example.p2p.connectivity.signaling.SignalingChannel
import com.example.p2p.connectivity.signaling.SignalingEnvelope
import com.example.p2p.connectivity.signaling.SignalingMessageType
import com.example.p2p.connectivity.signaling.SignalingValidationResult
import com.example.p2p.connectivity.stun.StunDiscoveryService
import com.example.p2p.transport.TransportChannel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.Closeable
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class IceNegotiationOutcome(
    val signalingSessionId: String,
    val remoteNodeId: String,
    val channel: TransportChannel,
    val pathType: TransportPathType,
    val selectedCandidateType: IceCandidateType?,
    val candidatePairSummary: String?,
    val establishmentTimeMs: Long
)

data class NatTelemetrySnapshot(
    val gatheringState: IceGatheringProgress = IceGatheringProgress.NEW,
    val connectionState: IceConnectionStatus = IceConnectionStatus.NEW,
    val selectedCandidateType: IceCandidateType? = null,
    val selectedCandidatePairSummary: String? = null,
    val activeNegotiationsCount: Int = 0,
    val rateLimitedNegotiationsCount: Long = 0L,
    val lastEstablishmentMs: Long? = null,
    val lastNatEvent: String? = null
)

/**
 * Coordinates ICE session lifecycle, authenticated signaling exchange, candidate queuing/ranking,
 * direct vs TURN relay fallback, ICE restart on network transition, and timeout/abuse enforcement.
 */
class NatTraversalManager(
    private val identityManager: NodeIdentityManager,
    private val iceEngine: IceEngine,
    val signalingService: PeerSignalingService,
    val stunService: StunDiscoveryService,
    val relayManager: RelayConnectionManager,
    private val pathSelector: NetworkPathSelector,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    @Volatile var config: NatTraversalConfig = NatTraversalConfig()
) : Closeable {

    private data class ActiveNegotiation(
        val sessionId: String,
        val remoteNodeId: String,
        val isInitiator: Boolean,
        val startedAtMs: Long,
        var iceSession: IcePeerSession? = null,
        var allocationId: String? = null,
        var selectedPath: TransportPathType = TransportPathType.ICE_DIRECT,
        var selectedCandidate: IceCandidateType? = null,
        var pairSummary: String? = null,
        val deferredChannel: CompletableDeferred<Result<IceNegotiationOutcome>> = CompletableDeferred(),
        val restartAttempts: AtomicInteger = AtomicInteger(0)
    )

    private val activeNegotiations = ConcurrentHashMap<String, ActiveNegotiation>()
    private val signalingJobs = ConcurrentHashMap<String, Job>()
    private val outboundQueue = Channel<Pair<SignalingChannel, SignalingEnvelope>>(Channel.UNLIMITED)
    private val outboundSenderJob: Job = scope.launch(ioDispatcher) {
        for ((channel, env) in outboundQueue) {
            runCatching { channel.sendEnvelope(env) }
        }
    }
    private val rateLimitedCounter = AtomicLong(0L)

    @Volatile
    private var activeSignalingChannel: SignalingChannel? = null

    private val _natTelemetry = MutableStateFlow(NatTelemetrySnapshot())
    val natTelemetry: StateFlow<NatTelemetrySnapshot> = _natTelemetry.asStateFlow()

    var onInboundDataChannelReady: ((IceNegotiationOutcome) -> Unit)? = null
    var onNegotiationProgressEvent: ((String, Boolean) -> Unit)? = null

    fun attachSignalingChannel(channel: SignalingChannel) {
        if (activeSignalingChannel === channel) return
        signalingJobs.remove("main")?.cancel()
        activeSignalingChannel = channel
        signalingJobs["main"] = scope.launch(ioDispatcher) {
            channel.incomingEnvelopes.collect { envelope ->
                handleIncomingSignalingEnvelope(envelope)
            }
        }
    }

    fun updateServerConfigurations(
        stunServers: List<StunServerConfig>,
        turnServers: List<TurnServerConfig>
    ) {
        config = config.copy(stunServers = stunServers, turnServers = turnServers)
        stunService.configureServers(stunServers)
        relayManager.configureTurnServers(turnServers)
    }

    /**
     * Initiates an outbound ICE negotiation toward [remoteNodeId] using the attached [SignalingChannel].
     * Prefers direct ICE (`HOST`/`SRFLX`) and falls back to TURN relay when direct fails and TURN is valid.
     */
    suspend fun negotiateOutboundConnection(
        remoteNodeId: String,
        forceRelayOnly: Boolean = false
    ): Result<IceNegotiationOutcome> {
        val localIdentity = identityManager.getActiveIdentity()
            ?: return Result.failure(IllegalStateException("Local Ed25519 identity required before ICE signaling"))

        val signalingChannel = activeSignalingChannel
            ?: return Result.failure(IllegalStateException("No SignalingChannel attached for ICE negotiation"))

        val sessionId = UUID.randomUUID().toString()
        val reserve = signalingService.tryReserveOutboundNegotiation(sessionId, remoteNodeId)
        if (reserve.isFailure) {
            rateLimitedCounter.incrementAndGet()
            updateTelemetry(lastEvent = reserve.exceptionOrNull()?.message)
            return Result.failure(reserve.exceptionOrNull() ?: IllegalStateException("Negotiation rate limited"))
        }

        val startedAt = System.currentTimeMillis()
        val negotiation = ActiveNegotiation(
            sessionId = sessionId,
            remoteNodeId = remoteNodeId,
            isInitiator = true,
            startedAtMs = startedAt
        )
        activeNegotiations[sessionId] = negotiation

        var relayAllocationId: String? = null
        val validTurnServers = relayManager.getValidTurnServers()
        if (forceRelayOnly && validTurnServers.isNotEmpty()) {
            val alloc = relayManager.beginRelayFallbackAllocation(remoteNodeId)
            if (alloc.isFailure) {
                cleanupNegotiation(sessionId)
                return Result.failure(alloc.exceptionOrNull() ?: IllegalStateException("TURN allocation failed"))
            }
            relayAllocationId = alloc.getOrThrow().allocationId
            negotiation.allocationId = relayAllocationId
        }

        val callbacks = createCallbacksForNegotiation(negotiation, signalingChannel, localIdentity.nodeId)
        val iceConfig = IceSessionConfig(
            sessionId = sessionId,
            localNodeId = localIdentity.nodeId,
            remoteNodeId = remoteNodeId,
            isInitiator = true,
            stunServers = config.stunServers,
            turnServers = validTurnServers,
            forceRelayOnly = forceRelayOnly
        )

        return try {
            val iceSession = iceEngine.createSession(iceConfig, callbacks)
            negotiation.iceSession = iceSession
            updateTelemetry(lastEvent = "Gathering ICE candidates for ${remoteNodeId.take(12)}...")
            iceSession.startOffer()

            val result = withTimeoutOrNull(config.iceConnectivityTimeoutMs) {
                negotiation.deferredChannel.await()
            }
            if (result == null) {
                onNegotiationProgressEvent?.invoke("ICE connectivity timeout (${config.iceConnectivityTimeoutMs}ms) for ${remoteNodeId.take(12)}", true)
                cleanupNegotiation(sessionId)
                Result.failure(IllegalStateException("ICE connectivity check timed out after ${config.iceConnectivityTimeoutMs}ms"))
            } else {
                if (result.isFailure) {
                    cleanupNegotiation(sessionId)
                }
                result
            }
        } catch (e: Exception) {
            cleanupNegotiation(sessionId)
            Result.failure(e)
        }
    }

    /**
     * Triggers an ICE restart across active ICE sessions after an Android network transition.
     */
    fun triggerIceRestartAll(reason: String): Int {
        var restarted = 0
        activeNegotiations.values.forEach { neg ->
            val attempts = neg.restartAttempts.incrementAndGet()
            if (attempts <= config.maxIceRestartAttempts) {
                try {
                    neg.iceSession?.restartIce()
                    restarted++
                } catch (_: Exception) {
                }
            }
        }
        updateTelemetry(
            connectionState = if (restarted > 0) IceConnectionStatus.CHECKING else _natTelemetry.value.connectionState,
            lastEvent = "ICE restart ($restarted session(s)): $reason"
        )
        return restarted
    }

    private suspend fun handleIncomingSignalingEnvelope(envelope: SignalingEnvelope) {
        when (val validated = signalingService.verifyAndProcessIncoming(envelope)) {
            is SignalingValidationResult.Rejected -> {
                onNegotiationProgressEvent?.invoke(
                    "Rejected signaling ${envelope.messageType.name}: ${validated.reason}",
                    validated.isAuthFailure
                )
                updateTelemetry(lastEvent = "Signaling rejected: ${validated.reason}")
                return
            }
            is SignalingValidationResult.Valid -> {
                processValidEnvelope(validated.envelope)
            }
        }
    }

    private fun processValidEnvelope(envelope: SignalingEnvelope) {
        val localIdentity = identityManager.getActiveIdentity() ?: return
        val signalingChannel = activeSignalingChannel ?: return

        when (envelope.messageType) {
            SignalingMessageType.ICE_OFFER, SignalingMessageType.ICE_RESTART_REQUEST -> {
                val sdp = signalingService.parseSdpFromPayload(envelope) ?: return
                val existing = activeNegotiations[envelope.signalingSessionId]
                if (existing != null) {
                    existing.iceSession?.acceptRemoteOfferAndCreateAnswer(sdp)
                    drainAndApplyBufferedCandidates(existing)
                    return
                }

                val neg = ActiveNegotiation(
                    sessionId = envelope.signalingSessionId,
                    remoteNodeId = envelope.senderNodeId,
                    isInitiator = false,
                    startedAtMs = System.currentTimeMillis()
                )
                activeNegotiations[neg.sessionId] = neg

                val iceConfig = IceSessionConfig(
                    sessionId = neg.sessionId,
                    localNodeId = localIdentity.nodeId,
                    remoteNodeId = envelope.senderNodeId,
                    isInitiator = false,
                    stunServers = config.stunServers,
                    turnServers = relayManager.getValidTurnServers()
                )
                try {
                    val iceSession = iceEngine.createSession(
                        iceConfig,
                        createCallbacksForNegotiation(neg, signalingChannel, localIdentity.nodeId)
                    )
                    neg.iceSession = iceSession
                    iceSession.acceptRemoteOfferAndCreateAnswer(sdp)
                    drainAndApplyBufferedCandidates(neg)
                } catch (e: Exception) {
                    cleanupNegotiation(neg.sessionId)
                }
            }
            SignalingMessageType.ICE_ANSWER -> {
                val sdp = signalingService.parseSdpFromPayload(envelope) ?: return
                val neg = activeNegotiations[envelope.signalingSessionId] ?: return
                neg.iceSession?.acceptRemoteAnswer(sdp)
                drainAndApplyBufferedCandidates(neg)
            }
            SignalingMessageType.ICE_CANDIDATE -> {
                val candidate = signalingService.parseCandidateFromPayload(envelope) ?: return
                when (val outcome = signalingService.ingestRemoteCandidate(envelope.signalingSessionId, candidate)) {
                    is CandidateIngestOutcome.ReadyToApply -> {
                        val neg = activeNegotiations[envelope.signalingSessionId]
                        if (outcome.candidate.type == IceCandidateType.RELAY && neg != null && neg.allocationId == null) {
                            relayManager.beginRelayFallbackAllocation(neg.remoteNodeId).onSuccess {
                                neg.allocationId = it.allocationId
                            }
                        }
                        neg?.iceSession?.addRemoteCandidate(outcome.candidate)
                    }
                    CandidateIngestOutcome.BufferedEarly -> {
                        updateTelemetry(lastEvent = "Buffered early out-of-order ${candidate.type.sdpToken} candidate")
                    }
                    CandidateIngestOutcome.DuplicateIgnored,
                    CandidateIngestOutcome.QueueLimitExceeded,
                    CandidateIngestOutcome.UnknownSession -> Unit
                }
            }
            SignalingMessageType.SESSION_BYE -> {
                cleanupNegotiation(envelope.signalingSessionId)
            }
        }
    }

    private fun drainAndApplyBufferedCandidates(neg: ActiveNegotiation) {
        val buffered = signalingService.markRemoteSdpAppliedAndDrainCandidates(neg.sessionId)
        val ranked = pathSelector.rankCandidates(buffered)
        ranked.forEach { candidate ->
            if (candidate.type == IceCandidateType.RELAY && neg.allocationId == null) {
                relayManager.beginRelayFallbackAllocation(neg.remoteNodeId).onSuccess {
                    neg.allocationId = it.allocationId
                }
            }
            neg.iceSession?.addRemoteCandidate(candidate)
        }
    }

    private fun createCallbacksForNegotiation(
        neg: ActiveNegotiation,
        signalingChannel: SignalingChannel,
        @Suppress("UNUSED_PARAMETER") localNodeId: String
    ): IceSessionCallbacks {
        return object : IceSessionCallbacks {
            override fun onLocalOfferCreated(sdp: String) {
                val envRes = signalingService.createSignedOffer(neg.sessionId, neg.remoteNodeId, sdp)
                envRes.onSuccess { env ->
                    outboundQueue.trySend(signalingChannel to env)
                }.onFailure { err ->
                    neg.deferredChannel.complete(Result.failure(err))
                }
            }

            override fun onLocalAnswerCreated(sdp: String) {
                val envRes = signalingService.createSignedAnswer(neg.sessionId, neg.remoteNodeId, sdp)
                envRes.onSuccess { env ->
                    outboundQueue.trySend(signalingChannel to env)
                }
            }

            override fun onLocalIceCandidate(candidate: IceCandidateInfo) {
                if (!config.enableIpv6Candidates && candidate.ipVersion == com.example.p2p.connectivity.model.IpVersion.IPV6) {
                    return
                }
                if (candidate.type == IceCandidateType.SRFLX) {
                    stunService.recordIceReflexiveObservation(candidate.address, candidate.port, candidate.ipVersion)
                }
                val envRes = signalingService.createSignedCandidate(neg.sessionId, neg.remoteNodeId, candidate)
                envRes.onSuccess { env ->
                    outboundQueue.trySend(signalingChannel to env)
                }
            }

            override fun onGatheringStateChanged(state: IceGatheringProgress) {
                updateTelemetry(gatheringState = state)
            }

            override fun onConnectionStateChanged(state: IceConnectionStatus) {
                updateTelemetry(connectionState = state)
                if (state == IceConnectionStatus.FAILED) {
                    neg.allocationId?.let { relayManager.recordRelayFailure(neg.remoteNodeId, "ICE check failed") }
                    if (!neg.deferredChannel.isCompleted) {
                        neg.deferredChannel.complete(Result.failure(IllegalStateException("ICE connection checks failed")))
                    }
                }
            }

            override fun onSelectedCandidatePairChanged(
                localCandidateType: IceCandidateType,
                remoteCandidateType: IceCandidateType,
                pairSummary: String,
                activePathType: TransportPathType
            ) {
                neg.selectedPath = activePathType
                neg.selectedCandidate = localCandidateType
                neg.pairSummary = pairSummary
                if (activePathType == TransportPathType.TURN_RELAY && neg.allocationId == null) {
                    relayManager.beginRelayFallbackAllocation(neg.remoteNodeId).onSuccess {
                        neg.allocationId = it.allocationId
                    }
                }
                updateTelemetry(
                    selectedCandidateType = localCandidateType,
                    pairSummary = pairSummary,
                    lastEvent = "Selected pair: $pairSummary ($activePathType)"
                )
            }

            override fun onDataChannelOpen(channel: TransportChannel) {
                val elapsed = (System.currentTimeMillis() - neg.startedAtMs).coerceAtLeast(1L)
                val outcome = IceNegotiationOutcome(
                    signalingSessionId = neg.sessionId,
                    remoteNodeId = neg.remoteNodeId,
                    channel = channel,
                    pathType = neg.selectedPath,
                    selectedCandidateType = neg.selectedCandidate,
                    candidatePairSummary = neg.pairSummary,
                    establishmentTimeMs = elapsed
                )
                updateTelemetry(
                    connectionState = IceConnectionStatus.CONNECTED,
                    lastEstablishmentMs = elapsed,
                    lastEvent = "ICE DataChannel open via ${neg.selectedPath.name} (${elapsed}ms)"
                )
                if (neg.isInitiator) {
                    neg.deferredChannel.complete(Result.success(outcome))
                } else {
                    onInboundDataChannelReady?.invoke(outcome)
                }
            }

            override fun onError(reason: String) {
                updateTelemetry(lastEvent = "ICE error: $reason")
                if (!neg.deferredChannel.isCompleted) {
                    neg.deferredChannel.complete(Result.failure(IllegalStateException(reason)))
                }
            }
        }
    }

    fun cleanupNegotiation(sessionId: String) {
        val removed = activeNegotiations.remove(sessionId)
        signalingService.closeSession(sessionId)
        removed?.let {
            it.allocationId?.let { allocId -> relayManager.recordRelayDisconnected(allocId, "Negotiation closed") }
            try {
                it.iceSession?.close()
            } catch (_: Exception) {
            }
        }
        updateTelemetry()
    }

    fun closeAllNegotiations() {
        activeNegotiations.keys.toList().forEach { cleanupNegotiation(it) }
    }

    private fun updateTelemetry(
        gatheringState: IceGatheringProgress = _natTelemetry.value.gatheringState,
        connectionState: IceConnectionStatus = _natTelemetry.value.connectionState,
        selectedCandidateType: IceCandidateType? = _natTelemetry.value.selectedCandidateType,
        pairSummary: String? = _natTelemetry.value.selectedCandidatePairSummary,
        lastEstablishmentMs: Long? = _natTelemetry.value.lastEstablishmentMs,
        lastEvent: String? = _natTelemetry.value.lastNatEvent
    ) {
        _natTelemetry.value = NatTelemetrySnapshot(
            gatheringState = gatheringState,
            connectionState = connectionState,
            selectedCandidateType = selectedCandidateType,
            selectedCandidatePairSummary = pairSummary,
            activeNegotiationsCount = activeNegotiations.size,
            rateLimitedNegotiationsCount = rateLimitedCounter.get(),
            lastEstablishmentMs = lastEstablishmentMs,
            lastNatEvent = lastEvent
        )
    }

    override fun close() {
        outboundQueue.close()
        outboundSenderJob.cancel()
        signalingJobs.values.forEach { it.cancel() }
        signalingJobs.clear()
        closeAllNegotiations()
        iceEngine.close()
    }
}
