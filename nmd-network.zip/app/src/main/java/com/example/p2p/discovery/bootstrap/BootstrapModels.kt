package com.example.p2p.discovery.bootstrap

import com.example.p2p.model.PeerEndpoint
import org.json.JSONObject

enum class BootstrapStatus {
    IDLE,
    CONNECTING,
    CONNECTED,
    BACKOFF,
    FAILED
}

/**
 * Represents a bootstrap node configuration.
 *
 * Clearly labeled for development/local testnet environments when no public
 * infrastructure is deployed.
 */
data class BootstrapPeer(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val expectedNodeId: String? = null,
    val expectedPublicKeyHex: String? = null,
    val isEnabled: Boolean = true,
    val isPreconfiguredDev: Boolean = false,
    val status: BootstrapStatus = BootstrapStatus.IDLE,
    val lastAttemptEpochMs: Long = 0L,
    val consecutiveFailures: Int = 0,
    val backoffUntilEpochMs: Long = 0L,
    val lastError: String? = null
) {
    companion object {
        const val BASE_BACKOFF_MS = 2_000L
        const val MAX_BACKOFF_MS = 60_000L

        fun computeBackoffMs(failures: Int): Long {
            if (failures <= 0) return 0L
            val shift = Math.min(failures - 1, 5)
            val computed = BASE_BACKOFF_MS * (1L shl shift)
            return Math.min(MAX_BACKOFF_MS, computed)
        }

        fun fromJson(json: JSONObject): BootstrapPeer? {
            return try {
                BootstrapPeer(
                    id = json.getString("id"),
                    name = json.getString("name"),
                    host = json.getString("host"),
                    port = json.getInt("port"),
                    expectedNodeId = if (json.has("expected_node_id") && !json.isNull("expected_node_id")) json.getString("expected_node_id") else null,
                    expectedPublicKeyHex = if (json.has("expected_pubkey") && !json.isNull("expected_pubkey")) json.getString("expected_pubkey") else null,
                    isEnabled = json.optBoolean("is_enabled", true),
                    isPreconfiguredDev = json.optBoolean("is_dev", false)
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    val endpoint: PeerEndpoint
        get() = PeerEndpoint(host, port, expectedNodeId)

    val addressFormatted: String
        get() = "$host:$port"

    val isInBackoff: Boolean
        get() = System.currentTimeMillis() < backoffUntilEpochMs

    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("id", id)
        json.put("name", name)
        json.put("host", host)
        json.put("port", port)
        if (expectedNodeId != null) json.put("expected_node_id", expectedNodeId)
        if (expectedPublicKeyHex != null) json.put("expected_pubkey", expectedPublicKeyHex)
        json.put("is_enabled", isEnabled)
        json.put("is_dev", isPreconfiguredDev)
        return json
    }
}
