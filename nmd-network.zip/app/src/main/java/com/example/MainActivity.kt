package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.ui.navigation.NmdApp
import com.example.ui.theme.NmdNetworkTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      NmdNetworkTheme(darkTheme = true) {
        NmdApp()
      }
    }
  }
}

@Preview(showBackground = true)
@Composable
fun NmdAppPreview() {
  NmdNetworkTheme(darkTheme = true) {
    NmdApp()
  }
}
