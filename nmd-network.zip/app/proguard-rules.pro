# Preserve source file & line number metadata for crash triage while obfuscating symbols
-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile

# NMD models, DTOs, and reflection-accessed entities
-keep class com.example.blockchain.model.** { *; }
-keep class com.example.transaction.model.** { *; }
-keep class com.example.consensus.model.** { *; }
-keep class com.example.production.model.** { *; }
-keep class com.example.sync.model.** { *; }
-keep class com.example.p2p.model.** { *; }
-keep class com.example.p2p.protocol.** { *; }
-keep class com.example.p2p.connectivity.model.** { *; }
-keep class com.example.p2p.infrastructure.model.** { *; }
-keep class com.example.crypto.model.** { *; }
-keep class com.example.p2p.scalability.model.** { *; }
-keep class com.example.blockchain.tokenomics.** { *; }
-keep class com.example.crypto.backup.** { *; }
-keep class com.example.data.** { *; }
-keep class com.example.BuildConfig { *; }

# BouncyCastle (Ed25519 / X25519 / ChaCha20-Poly1305) & JCA Providers
-keep class org.bouncycastle.** { *; }
-keep class * implements java.security.Provider { *; }
-dontwarn org.bouncycastle.**

# Stream WebRTC ICE/STUN/TURN engine
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# Room persistence & SQLite
-keep class * extends androidx.room.RoomDatabase { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    public <init>();
}
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keepclassmembers class * {
    @androidx.room.TypeConverter *;
}

# Moshi & Retrofit serialization
-keepclassmembers class * {
    @com.squareup.moshi.Json <fields>;
    @com.squareup.moshi.FromJson <methods>;
    @com.squareup.moshi.ToJson <methods>;
}
-keep @com.squareup.moshi.JsonClass class * { *; }
-dontwarn retrofit2.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**

# Kotlin Coroutines & Enums
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
-dontwarn kotlinx.coroutines.debug.**
