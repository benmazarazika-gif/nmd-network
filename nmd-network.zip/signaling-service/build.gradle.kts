plugins {
    alias(libs.plugins.kotlin.jvm)
    application
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_11)
    }
}

application {
    mainClass.set("com.nmd.signaling.SignalingMainKt")
}

dependencies {
    implementation(libs.bouncycastle.bcprov)
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.moshi.kotlin)
    testImplementation(libs.junit)
    testImplementation(libs.okhttp)
}
