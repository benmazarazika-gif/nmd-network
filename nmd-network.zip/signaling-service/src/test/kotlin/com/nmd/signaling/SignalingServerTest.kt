package com.nmd.signaling

import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.bouncycastle.crypto.generators.Ed25519KeyPairGenerator
import org.bouncycastle.crypto.params.Ed25519KeyGenerationParameters
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class SignalingServerTest {

    private val client = OkHttpClient()
    private val moshi = Moshi.Builder().build()
    private val mapType = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
    private val mapAdapter = moshi.adapter<Map<String, Any?>>(mapType)
    private val servers = mutableListOf<SignalingServer>()

    @After
    fun cleanup() {
        servers.forEach { runCatching { it.close() } }
        servers.clear()
    }

    private fun openWs(port: Int, inbox: LinkedBlockingQueue<String>): Pair<WebSocket, String> {
        val opened = CountDownLatch(1)
        val ws = client.newWebSocket(
            Request.Builder().url("http://127.0.0.1:$port/ws").build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    opened.countDown()
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    inbox.offer(text)
                }
            }
        )
        assertTrue("WebSocket did not open", opened.await(3, TimeUnit.SECONDS))
        val challengeFrame = inbox.poll(2, TimeUnit.SECONDS)!!
        assertTrue("Expected CHALLENGE frame on open, got: $challengeFrame", challengeFrame.contains("CHALLENGE"))
        val nonce = (mapAdapter.fromJson(challengeFrame)?.get("nonce") as? String).orEmpty()
        assertTrue(nonce.isNotBlank())
        return ws to nonce
    }

    @Test
    fun `routes signaling envelopes between peers, delivers unexpired offline queue, and reports health`() {
        val now = AtomicLong(1_740_000_000_000L)
        val server = SignalingServer(
            config = SignalingServiceConfig(
                port = 0,
                chainId = "nmd-private-testnet-1",
                offlineQueueTtlMs = 5_000L,
                maxMessagesPerWindow = 50
            ),
            clockMs = { now.get() }
        ).also { servers.add(it) }

        val port = server.start()

        // 1. Health endpoint
        client.newCall(Request.Builder().url("http://127.0.0.1:$port/health").get().build()).execute().use { resp ->
            assertEquals(200, resp.code)
            val json = mapAdapter.fromJson(resp.body!!.string())!!
            assertEquals("OK", json["status"])
        }

        val inboxA = LinkedBlockingQueue<String>()
        val (wsA, _) = openWs(port, inboxA)
        val nodeA = "nmd_node_11111111111111111111111111111111"
        val nodeB = "nmd_node_22222222222222222222222222222222"

        wsA.send(mapAdapter.toJson(mapOf("type" to "REGISTER", "node_id" to nodeA, "chain_id" to "nmd-private-testnet-1")))
        val ackA = inboxA.poll(2, TimeUnit.SECONDS)!!
        assertTrue(ackA.contains("REGISTERED"))

        // 2. Peer A sends signed envelope while Peer B is offline -> stored in expiring offline queue
        val envelopeFrame = mapAdapter.toJson(
            mapOf(
                "type" to "ENVELOPE",
                "envelope" to mapOf(
                    "signaling_session_id" to "sess-offline-1",
                    "chain_id" to "nmd-private-testnet-1",
                    "sender_node_id" to nodeA,
                    "recipient_node_id" to nodeB,
                    "signature_hex" to "abcd1234",
                    "payload_json" to "{\"sdp\":\"v=0\"}"
                )
            )
        )
        wsA.send(envelopeFrame)
        Thread.sleep(150)

        // 3. Peer B connects & registers -> drains queued envelope verbatim
        val inboxB = LinkedBlockingQueue<String>()
        val (wsB, _) = openWs(port, inboxB)
        wsB.send(mapAdapter.toJson(mapOf("type" to "REGISTER", "node_id" to nodeB, "chain_id" to "nmd-private-testnet-1")))
        val ackB = inboxB.poll(2, TimeUnit.SECONDS)!!
        val queuedMsg = inboxB.poll(2, TimeUnit.SECONDS)!!
        assertTrue(ackB.contains("REGISTERED"))
        assertTrue(queuedMsg.contains("sess-offline-1"))

        wsA.close(1000, "done")
        wsB.close(1000, "done")
    }

    @Test
    fun `rejects wrong chain, malformed frames, oversized messages, and expires offline queue`() {
        val now = AtomicLong(1_740_000_000_000L)
        val server = SignalingServer(
            config = SignalingServiceConfig(
                port = 0,
                chainId = "nmd-private-testnet-1",
                maxMessageBytes = 2048,
                offlineQueueTtlMs = 2_000L,
                maxMessagesPerWindow = 4
            ),
            clockMs = { now.get() }
        ).also { servers.add(it) }
        val port = server.start()

        val inbox = LinkedBlockingQueue<String>()
        val (ws, _) = openWs(port, inbox)

        // Wrong chain rejected
        ws.send(mapAdapter.toJson(mapOf("type" to "REGISTER", "node_id" to "nmd_node_11111111111111111111111111111111", "chain_id" to "evil-chain")))
        val wrongChainResp = inbox.poll(2, TimeUnit.SECONDS)!!
        assertTrue(wrongChainResp.contains("CHAIN_MISMATCH"))

        // Malformed JSON rejected
        ws.send("{not-json")
        val malResp = inbox.poll(2, TimeUnit.SECONDS)!!
        assertTrue(malResp.contains("MALFORMED_JSON"))

        // Valid register + offline queue expires
        val nodeA = "nmd_node_11111111111111111111111111111111"
        val nodeC = "nmd_node_33333333333333333333333333333333"
        ws.send(mapAdapter.toJson(mapOf("type" to "REGISTER", "node_id" to nodeA, "chain_id" to "nmd-private-testnet-1")))
        assertTrue(inbox.poll(2, TimeUnit.SECONDS)!!.contains("REGISTERED"))

        ws.send(
            mapAdapter.toJson(
                mapOf(
                    "type" to "ENVELOPE",
                    "envelope" to mapOf(
                        "chain_id" to "nmd-private-testnet-1",
                        "sender_node_id" to nodeA,
                        "recipient_node_id" to nodeC,
                        "signature_hex" to "ff"
                    )
                )
            )
        )
        Thread.sleep(100)
        now.addAndGet(5_000L)
        assertEquals(1, server.pruneExpiredOfflineQueues())

        // Rate limit enforced cleanly
        ws.send(mapAdapter.toJson(mapOf("type" to "PING")))
        val rateResp = inbox.poll(2, TimeUnit.SECONDS)!!
        assertTrue(rateResp.contains("RATE_LIMITED"))

        // Oversized message closes WebSocket cleanly
        ws.send("x".repeat(3_000))
        Thread.sleep(150)

        client.newCall(Request.Builder().url("http://127.0.0.1:$port/metrics").get().build()).execute().use { resp ->
            assertEquals(200, resp.code)
            val metrics = mapAdapter.fromJson(resp.body!!.string())!!
            assertTrue(metrics.containsKey("requests_per_second"))
            assertTrue(metrics.containsKey("websocket_disconnections"))
            assertTrue(metrics.containsKey("queue_depth"))
            assertTrue(metrics.containsKey("rejected_requests"))
            assertTrue(metrics.containsKey("error_counts"))
            assertTrue(metrics.containsKey("uptime_ms"))
            assertTrue((metrics["heap_max_bytes"] as Number).toLong() > 0L)
        }

        client.newCall(Request.Builder().url("http://127.0.0.1:$port/metrics/prometheus").get().build()).execute().use { resp ->
            assertEquals(200, resp.code)
            val prom = resp.body!!.string()
            assertTrue(prom.contains("nmd_signaling_active_connections"))
            assertTrue(prom.contains("nmd_signaling_queue_depth"))
            assertTrue(prom.contains("nmd_signaling_websocket_disconnections"))
        }

        server.close()
        client.newCall(Request.Builder().url("http://127.0.0.1:$port/health").get().build()).runCatching { execute().close() }
    }

    @Test
    fun `enforces Ed25519 challenge response authentication when requireSignedAuth is enabled`() {
        val now = AtomicLong(1_740_000_000_000L)
        val server = SignalingServer(
            config = SignalingServiceConfig(
                port = 0,
                chainId = "nmd-private-testnet-1",
                requireSignedAuth = true
            ),
            clockMs = { now.get() }
        ).also { servers.add(it) }
        val port = server.start()

        val gen = Ed25519KeyPairGenerator()
        gen.init(Ed25519KeyGenerationParameters(SecureRandom()))
        val kp = gen.generateKeyPair()
        val priv = kp.private as Ed25519PrivateKeyParameters
        val pubBytes = (kp.public as Ed25519PublicKeyParameters).encoded
        val pubHex = pubBytes.joinToString("") { "%02x".format(it) }
        val nodeId = "nmd_node_" + MessageDigest.getInstance("SHA-256").digest(pubBytes).joinToString("") { "%02x".format(it) }.substring(0, 32)

        val inbox = LinkedBlockingQueue<String>()
        val (ws, nonce) = openWs(port, inbox)

        // Unsigned REGISTER must fail with AUTH_FAILED
        ws.send(mapAdapter.toJson(mapOf("type" to "REGISTER", "node_id" to nodeId, "chain_id" to "nmd-private-testnet-1")))
        assertTrue(inbox.poll(2, TimeUnit.SECONDS)!!.contains("AUTH_FAILED"))

        // Valid signed challenge response must succeed
        val ts = now.get()
        val canonical = "NMD-SIG-AUTH|$nodeId|nmd-private-testnet-1|$nonce|$ts".toByteArray(StandardCharsets.UTF_8)
        val signer = Ed25519Signer()
        signer.init(true, priv)
        signer.update(canonical, 0, canonical.size)
        val sigHex = signer.generateSignature().joinToString("") { "%02x".format(it) }

        ws.send(
            mapAdapter.toJson(
                mapOf(
                    "type" to "REGISTER",
                    "node_id" to nodeId,
                    "public_key_hex" to pubHex,
                    "chain_id" to "nmd-private-testnet-1",
                    "nonce" to nonce,
                    "timestamp_ms" to ts,
                    "signature_hex" to sigHex
                )
            )
        )
        assertTrue(inbox.poll(2, TimeUnit.SECONDS)!!.contains("REGISTERED"))
        ws.close(1000, "done")
    }

    @Test
    fun `enforces HTTP 503 overload protection when connection cap reached`() {
        val server = SignalingServer(
            config = SignalingServiceConfig(
                port = 0,
                chainId = "nmd-private-testnet-1",
                maxConcurrentConnections = 1
            )
        ).also { servers.add(it) }
        val port = server.start()

        val inbox1 = LinkedBlockingQueue<String>()
        val (ws1, _) = openWs(port, inbox1)
        ws1.send(mapAdapter.toJson(mapOf("type" to "REGISTER", "node_id" to "nmd_node_11111111111111111111111111111111", "chain_id" to "nmd-private-testnet-1")))
        assertTrue(inbox1.poll(2, TimeUnit.SECONDS)!!.contains("REGISTERED"))

        // Second HTTP request should receive 503 because connection limit = 1 is saturated by ws1
        client.newCall(Request.Builder().url("http://127.0.0.1:$port/health").get().build()).execute().use { resp ->
            assertEquals(503, resp.code)
        }

        ws1.close(1000, "done")
        server.close()
    }
}
