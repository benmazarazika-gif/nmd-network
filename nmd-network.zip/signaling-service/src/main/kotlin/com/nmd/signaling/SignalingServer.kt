package com.nmd.signaling

import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Instant
import java.util.Base64
import java.util.UUID
import kotlin.math.abs
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket

data class SignalingServiceConfig(
    val bindHost: String = "127.0.0.1",
    val port: Int = 8845,
    val chainId: String = "nmd-private-testnet-1",
    val maxMessageBytes: Int = 16_384,
    val maxConcurrentConnections: Int = 500,
    val maxQueuedPerPeer: Int = 32,
    val offlineQueueTtlMs: Long = 60_000L,
    val rateLimitWindowMs: Long = 10_000L,
    val maxMessagesPerWindow: Int = 40,
    val heartbeatIntervalMs: Long = 20_000L,
    val tlsKeystorePath: String? = null,
    val tlsKeystorePassword: String? = null,
    val maxTotalOfflineQueued: Int = 4_096,
    val requireSignedAuth: Boolean = false
) {
    init {
        require(port in 0..65535) { "Port must be in 0..65535" }
        require(chainId.isNotBlank()) { "chainId cannot be blank" }
        require(maxMessageBytes in 1024..262_144) { "maxMessageBytes out of range" }
        require(maxQueuedPerPeer in 1..256) { "maxQueuedPerPeer out of range" }
        require(offlineQueueTtlMs >= 1_000L) { "offlineQueueTtlMs must be >= 1000ms" }
        require(maxTotalOfflineQueued >= maxQueuedPerPeer) { "maxTotalOfflineQueued must be >= maxQueuedPerPeer" }
    }

    companion object {
        fun fromEnv(env: Map<String, String> = System.getenv()): SignalingServiceConfig {
            val chainId = env["NMD_CHAIN_ID"]?.takeIf { it.isNotBlank() }
                ?: error("NMD_CHAIN_ID must be configured externally")
            return SignalingServiceConfig(
                bindHost = env["NMD_SIGNALING_HOST"]?.takeIf { it.isNotBlank() } ?: "127.0.0.1",
                port = env["NMD_SIGNALING_PORT"]?.toIntOrNull() ?: 8845,
                chainId = chainId,
                maxMessageBytes = env["NMD_SIGNALING_MAX_BYTES"]?.toIntOrNull() ?: 16_384,
                maxConcurrentConnections = env["NMD_SIGNALING_MAX_CONNS"]?.toIntOrNull() ?: 500,
                maxQueuedPerPeer = env["NMD_SIGNALING_MAX_OFFLINE_QUEUE"]?.toIntOrNull() ?: 32,
                offlineQueueTtlMs = env["NMD_SIGNALING_OFFLINE_TTL_MS"]?.toLongOrNull() ?: 60_000L,
                rateLimitWindowMs = env["NMD_SIGNALING_RATE_WINDOW_MS"]?.toLongOrNull() ?: 10_000L,
                maxMessagesPerWindow = env["NMD_SIGNALING_RATE_MAX_MSGS"]?.toIntOrNull() ?: 40,
                heartbeatIntervalMs = env["NMD_SIGNALING_HEARTBEAT_MS"]?.toLongOrNull() ?: 20_000L,
                tlsKeystorePath = env["NMD_TLS_KEYSTORE_PATH"]?.takeIf { it.isNotBlank() },
                tlsKeystorePassword = env["NMD_TLS_KEYSTORE_PASSWORD"]?.takeIf { it.isNotBlank() },
                maxTotalOfflineQueued = env["NMD_SIGNALING_MAX_TOTAL_OFFLINE"]?.toIntOrNull() ?: 4_096,
                requireSignedAuth = env["NMD_SIGNALING_REQUIRE_AUTH"]?.toBooleanStrictOrNull() ?: true
            )
        }
    }
}

/**
 * Deployable NMD WebSocket Signaling Rendezvous Service (RFC 6455 + /health + /metrics).
 *
 * Zero-Trust Relay Guarantees:
 * - Relays signed Stage 14 Ed25519 SignalingEnvelopes strictly by recipient Node ID and Chain ID.
 * - Never holds user private keys, never forges peer signatures, and never persists plaintext session keys.
 * - Enforces frame size limits, per-peer rate limits, expiring offline queues, heartbeat pings, and clean shutdown.
 */
class SignalingServer(
    private val config: SignalingServiceConfig,
    private val clockMs: () -> Long = { System.currentTimeMillis() },
    private val logSink: (String) -> Unit = { println(it) }
) : Closeable {

    companion object {
        private const val WS_MAGIC_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    }

    private data class QueuedEnvelope(
        val jsonFrame: String,
        val expiresAtMs: Long
    )

    private class ClientSession(
        val sessionId: String,
        val socket: Socket,
        val output: OutputStream,
        val remoteIp: String
    ) {
        @Volatile
        var challengeNonce: String? = null
        @Volatile
        var registeredNodeId: String? = null
        @Volatile
        var lastActivityAtMs: Long = System.currentTimeMillis()
        val writeLock = Any()

        fun sendTextFrame(text: String) {
            val payload = text.toByteArray(StandardCharsets.UTF_8)
            sendWsFrame(opcode = 0x1, payload = payload)
        }

        fun sendPing() {
            sendWsFrame(opcode = 0x9, payload = ByteArray(0))
        }

        fun sendPong(payload: ByteArray) {
            sendWsFrame(opcode = 0xA, payload = payload)
        }

        fun sendClose(code: Int, reason: String) {
            val reasonBytes = reason.toByteArray(StandardCharsets.UTF_8).take(100).toByteArray()
            val payload = ByteArray(2 + reasonBytes.size)
            payload[0] = ((code shr 8) and 0xFF).toByte()
            payload[1] = (code and 0xFF).toByte()
            System.arraycopy(reasonBytes, 0, payload, 2, reasonBytes.size)
            runCatching { sendWsFrame(opcode = 0x8, payload = payload) }
        }

        private fun sendWsFrame(opcode: Int, payload: ByteArray) {
            synchronized(writeLock) {
                val len = payload.size
                val header = when {
                    len <= 125 -> byteArrayOf((0x80 or opcode).toByte(), len.toByte())
                    len <= 65_535 -> byteArrayOf(
                        (0x80 or opcode).toByte(),
                        126.toByte(),
                        ((len shr 8) and 0xFF).toByte(),
                        (len and 0xFF).toByte()
                    )
                    else -> throw IllegalArgumentException("Frame too large: $len")
                }
                output.write(header)
                output.write(payload)
                output.flush()
            }
        }
    }

    private val moshi = Moshi.Builder().build()
    private val mapType = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
    private val mapAdapter: JsonAdapter<Map<String, Any?>> = moshi.adapter(mapType)

    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null
    private val workerExecutor: ExecutorService = Executors.newCachedThreadPool()
    private var maintenanceScheduler: ScheduledExecutorService? = null

    private val sessionsById = ConcurrentHashMap<String, ClientSession>()
    private val nodeSessions = ConcurrentHashMap<String, ClientSession>()
    private val offlineQueues = ConcurrentHashMap<String, ArrayDeque<QueuedEnvelope>>()
    private val rateWindows = ConcurrentHashMap<String, ArrayDeque<Long>>()

    private val startedAtMs = clockMs()
    private val secureRandom = SecureRandom()
    private val routedMessages = AtomicLong(0L)
    private val queuedOffline = AtomicLong(0L)
    private val expiredOffline = AtomicLong(0L)
    private val rejectedMessages = AtomicLong(0L)
    private val rateLimitedCount = AtomicLong(0L)
    private val websocketDisconnections = AtomicLong(0L)
    private val overloadRejected503 = AtomicLong(0L)
    private val errorCounts = AtomicLong(0L)
    private val recentMessageTimestamps = ArrayDeque<Long>()

    @Volatile
    var boundPort: Int = config.port
        private set

    fun start(): Int {
        if (!running.compareAndSet(false, true)) return boundPort

        val bindAddr = InetAddress.getByName(config.bindHost)
        val socket: ServerSocket = if (!config.tlsKeystorePath.isNullOrBlank()) {
            val ssl = loadPkcs12SslContext(config.tlsKeystorePath, config.tlsKeystorePassword.orEmpty())
            val factory = ssl.serverSocketFactory
            (factory.createServerSocket(config.port, 128, bindAddr) as SSLServerSocket).apply {
                enabledProtocols = supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }.toTypedArray()
            }
        } else {
            ServerSocket(config.port, 128, bindAddr)
        }

        serverSocket = socket
        boundPort = socket.localPort

        acceptThread = Thread({
            while (running.get() && !socket.isClosed) {
                try {
                    val client = socket.accept()
                    if (sessionsById.size >= config.maxConcurrentConnections) {
                        overloadRejected503.incrementAndGet()
                        logStructured("WARN", "CONN_LIMIT_REACHED", "active=${sessionsById.size}")
                        workerExecutor.submit {
                            runCatching {
                                writeHttpJsonResponse(
                                    client.getOutputStream(),
                                    503,
                                    mapAdapter.toJson(mapOf("error" to "Service Unavailable: connection limit reached"))
                                )
                            }
                            runCatching { client.close() }
                        }
                        continue
                    }
                    workerExecutor.submit { handleClientSocket(client) }
                } catch (_: Exception) {
                    if (!running.get()) break
                }
            }
        }, "nmd-signaling-accept").apply { isDaemon = true; start() }

        maintenanceScheduler = Executors.newSingleThreadScheduledExecutor().apply {
            val interval = config.heartbeatIntervalMs.coerceAtLeast(1_000L)
            scheduleAtFixedRate({ runMaintenanceSweep() }, interval, interval, TimeUnit.MILLISECONDS)
        }

        logStructured("INFO", "SIGNALING_STARTED", "host=${config.bindHost} port=$boundPort tls=${!config.tlsKeystorePath.isNullOrBlank()}")
        return boundPort
    }

    fun pruneExpiredOfflineQueues(nowMs: Long = clockMs()): Int {
        var expired = 0
        val iter = offlineQueues.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next()
            synchronized(entry.value) {
                while (entry.value.isNotEmpty() && entry.value.first().expiresAtMs <= nowMs) {
                    entry.value.removeFirst()
                    expired++
                }
                if (entry.value.isEmpty()) {
                    iter.remove()
                }
            }
        }
        if (expired > 0) {
            expiredOffline.addAndGet(expired.toLong())
        }
        return expired
    }

    private fun runMaintenanceSweep() {
        pruneExpiredOfflineQueues()
        sessionsById.values.forEach { session ->
            runCatching { session.sendPing() }
        }
    }

    private fun handleClientSocket(socket: Socket) {
        val remoteIp = socket.inetAddress?.hostAddress ?: "unknown"
        val sessionId = UUID.randomUUID().toString()
        try {
            socket.soTimeout = 60_000
            val input = BufferedInputStream(socket.getInputStream())
            val output = socket.getOutputStream()

            val headers = readHttpHeaders(input) ?: run {
                socket.close()
                return
            }
            val requestLine = headers.first
            val headerMap = headers.second

            val parts = requestLine.split(" ")
            val method = parts.getOrNull(0).orEmpty()
            val path = parts.getOrNull(1)?.substringBefore("?").orEmpty()

            if (method == "GET" && (path == "/health" || path == "/metrics" || path == "/metrics/prometheus")) {
                pruneExpiredOfflineQueues()
                val now = clockMs()
                val queueDepth = currentTotalQueueDepth()
                val rt = Runtime.getRuntime()
                val heapUsed = (rt.totalMemory() - rt.freeMemory()).coerceAtLeast(0L)
                val heapMax = rt.maxMemory().coerceAtLeast(0L)
                val rps = computeMessagesPerSecond(now)
                val rejectedTotal = rejectedMessages.get() + rateLimitedCount.get() + overloadRejected503.get()
                when (path) {
                    "/health" -> {
                        val payload = mapOf(
                            "status" to "OK",
                            "service" to "nmd-signaling-service",
                            "chain_id" to config.chainId,
                            "active_sessions" to sessionsById.size,
                            "active_connections" to sessionsById.size,
                            "registered_nodes" to nodeSessions.size,
                            "authenticated_signaling_connections" to nodeSessions.size,
                            "queue_depth" to queueDepth,
                            "uptime_ms" to (now - startedAtMs).coerceAtLeast(0L)
                        )
                        writeHttpJsonResponse(output, 200, mapAdapter.toJson(payload))
                    }
                    "/metrics/prometheus" -> {
                        val prom = buildString {
                            appendLine("# TYPE nmd_signaling_active_connections gauge")
                            appendLine("nmd_signaling_active_connections ${sessionsById.size}")
                            appendLine("# TYPE nmd_signaling_authenticated_connections gauge")
                            appendLine("nmd_signaling_authenticated_connections ${nodeSessions.size}")
                            appendLine("# TYPE nmd_signaling_routed_messages counter")
                            appendLine("nmd_signaling_routed_messages ${routedMessages.get()}")
                            appendLine("# TYPE nmd_signaling_requests_per_second gauge")
                            appendLine("nmd_signaling_requests_per_second $rps")
                            appendLine("# TYPE nmd_signaling_rejected_requests counter")
                            appendLine("nmd_signaling_rejected_requests $rejectedTotal")
                            appendLine("# TYPE nmd_signaling_rate_limited_requests counter")
                            appendLine("nmd_signaling_rate_limited_requests ${rateLimitedCount.get()}")
                            appendLine("# TYPE nmd_signaling_websocket_disconnections counter")
                            appendLine("nmd_signaling_websocket_disconnections ${websocketDisconnections.get()}")
                            appendLine("# TYPE nmd_signaling_queue_depth gauge")
                            appendLine("nmd_signaling_queue_depth $queueDepth")
                            appendLine("# TYPE nmd_signaling_expired_offline counter")
                            appendLine("nmd_signaling_expired_offline ${expiredOffline.get()}")
                            appendLine("# TYPE nmd_signaling_error_counts counter")
                            appendLine("nmd_signaling_error_counts ${errorCounts.get() + rejectedMessages.get()}")
                            appendLine("# TYPE nmd_signaling_uptime_ms gauge")
                            appendLine("nmd_signaling_uptime_ms ${(now - startedAtMs).coerceAtLeast(0L)}")
                            appendLine("# TYPE nmd_signaling_heap_used_bytes gauge")
                            appendLine("nmd_signaling_heap_used_bytes $heapUsed")
                            appendLine("# TYPE nmd_signaling_heap_max_bytes gauge")
                            appendLine("nmd_signaling_heap_max_bytes $heapMax")
                        }
                        writeHttpTextResponse(output, 200, "text/plain; version=0.0.4; charset=utf-8", prom)
                    }
                    else -> {
                        val payload = linkedMapOf<String, Any?>(
                            "routed_messages" to routedMessages.get(),
                            "requests_per_second" to rps,
                            "queued_offline" to queuedOffline.get(),
                            "queue_depth" to queueDepth,
                            "expired_offline" to expiredOffline.get(),
                            "rejected_messages" to rejectedMessages.get(),
                            "rejected_requests" to rejectedTotal,
                            "rate_limited_count" to rateLimitedCount.get(),
                            "rate_limited_requests" to rateLimitedCount.get(),
                            "overload_rejected_503" to overloadRejected503.get(),
                            "websocket_disconnections" to websocketDisconnections.get(),
                            "error_counts" to (errorCounts.get() + rejectedMessages.get()),
                            "active_sessions" to sessionsById.size,
                            "active_connections" to sessionsById.size,
                            "registered_nodes" to nodeSessions.size,
                            "authenticated_signaling_connections" to nodeSessions.size,
                            "uptime_ms" to (now - startedAtMs).coerceAtLeast(0L),
                            "heap_used_bytes" to heapUsed,
                            "heap_max_bytes" to heapMax
                        )
                        writeHttpJsonResponse(output, 200, mapAdapter.toJson(payload))
                    }
                }
                socket.close()
                return
            }

            val upgrade = headerMap["upgrade"]?.lowercase()
            val wsKey = headerMap["sec-websocket-key"]
            if (method != "GET" || upgrade != "websocket" || wsKey.isNullOrBlank()) {
                writeHttpJsonResponse(output, 400, mapAdapter.toJson(mapOf("error" to "WebSocket Upgrade required")))
                socket.close()
                return
            }

            val acceptKey = computeWebSocketAccept(wsKey)
            val handshakeResp = buildString {
                append("HTTP/1.1 101 Switching Protocols\r\n")
                append("Upgrade: websocket\r\n")
                append("Connection: Upgrade\r\n")
                append("Sec-WebSocket-Accept: ").append(acceptKey).append("\r\n")
                append("\r\n")
            }
            output.write(handshakeResp.toByteArray(StandardCharsets.US_ASCII))
            output.flush()
            socket.soTimeout = 0

            val session = ClientSession(sessionId, socket, output, remoteIp)
            val challengeBytes = ByteArray(16).also { secureRandom.nextBytes(it) }
            val challengeNonce = challengeBytes.joinToString("") { "%02x".format(it) }
            session.challengeNonce = challengeNonce
            sessionsById[sessionId] = session
            session.sendTextFrame(
                mapAdapter.toJson(
                    mapOf(
                        "type" to "CHALLENGE",
                        "nonce" to challengeNonce,
                        "chain_id" to config.chainId
                    )
                )
            )

            val dataIn = DataInputStream(input)
            while (running.get() && !socket.isClosed) {
                val frame = readWsFrame(dataIn, config.maxMessageBytes) ?: break
                session.lastActivityAtMs = clockMs()
                when (frame.opcode) {
                    0x1 -> {
                        val text = String(frame.payload, StandardCharsets.UTF_8)
                        processIncomingWebSocketText(session, text)
                    }
                    0x8 -> {
                        session.sendClose(1000, "Normal closure")
                        break
                    }
                    0x9 -> session.sendPong(frame.payload)
                    0xA -> Unit // Pong heartbeat ACK
                    else -> {
                        rejectedMessages.incrementAndGet()
                        session.sendClose(1003, "Unsupported frame opcode")
                        break
                    }
                }
            }
        } catch (e: FrameTooLargeException) {
            rejectedMessages.incrementAndGet()
            logStructured("WARN", "FRAME_OVERSIZED", "remote=$remoteIp msg=${e.message}")
            sessionsById[sessionId]?.sendClose(1009, "Message too big")
        } catch (_: Exception) {
            errorCounts.incrementAndGet()
        } finally {
            val removed = sessionsById.remove(sessionId)
            if (removed != null) {
                websocketDisconnections.incrementAndGet()
                removed.registeredNodeId?.let { nodeId ->
                    nodeSessions.remove(nodeId, removed)
                }
            }
            runCatching { socket.close() }
        }
    }

    private fun currentTotalQueueDepth(): Int {
        var total = 0
        offlineQueues.values.forEach { q ->
            synchronized(q) { total += q.size }
        }
        return total
    }

    private fun recordMessageTimestamp(now: Long) {
        synchronized(recentMessageTimestamps) {
            recentMessageTimestamps.addLast(now)
            while (recentMessageTimestamps.isNotEmpty() && now - recentMessageTimestamps.first() > 10_000L) {
                recentMessageTimestamps.removeFirst()
            }
        }
    }

    private fun computeMessagesPerSecond(now: Long): Double {
        synchronized(recentMessageTimestamps) {
            while (recentMessageTimestamps.isNotEmpty() && now - recentMessageTimestamps.first() > 10_000L) {
                recentMessageTimestamps.removeFirst()
            }
            return recentMessageTimestamps.size / 10.0
        }
    }

    private fun processIncomingWebSocketText(session: ClientSession, rawText: String) {
        val now = clockMs()
        recordMessageTimestamp(now)
        val ipAllowed = checkRateLimit("ip:${session.remoteIp}", now)
        val nodeAllowed = session.registeredNodeId?.let { checkRateLimit("node:$it", now) } ?: true
        if (!ipAllowed || !nodeAllowed) {
            session.sendTextFrame(
                mapAdapter.toJson(mapOf("type" to "ERROR", "code" to "RATE_LIMITED", "message" to "Signaling rate limit exceeded"))
            )
            return
        }

        val parsed = try {
            mapAdapter.fromJson(rawText)
        } catch (_: Exception) {
            null
        }
        if (parsed == null) {
            rejectedMessages.incrementAndGet()
            session.sendTextFrame(
                mapAdapter.toJson(mapOf("type" to "ERROR", "code" to "MALFORMED_JSON", "message" to "Malformed JSON"))
            )
            return
        }

        when ((parsed["type"] as? String)?.uppercase()) {
            "REGISTER" -> {
                val nodeId = (parsed["node_id"] as? String)?.trim().orEmpty()
                val chainId = (parsed["chain_id"] as? String)?.trim().orEmpty()
                if (chainId != config.chainId) {
                    rejectedMessages.incrementAndGet()
                    logStructured("WARN", "WRONG_CHAIN_REGISTER", "got=$chainId expected=${config.chainId}")
                    session.sendTextFrame(
                        mapAdapter.toJson(mapOf("type" to "ERROR", "code" to "CHAIN_MISMATCH", "message" to "Chain ID mismatch"))
                    )
                    return
                }
                if (!nodeId.startsWith("nmd_node_") || nodeId.length < 24) {
                    rejectedMessages.incrementAndGet()
                    session.sendTextFrame(
                        mapAdapter.toJson(mapOf("type" to "ERROR", "code" to "INVALID_NODE_ID", "message" to "Invalid Node ID"))
                    )
                    return
                }

                val publicKeyHex = (parsed["public_key_hex"] as? String)?.trim()?.lowercase().orEmpty()
                val sigHex = (parsed["signature_hex"] as? String)?.trim()?.lowercase().orEmpty()
                val nonce = (parsed["nonce"] as? String)?.trim().orEmpty()
                val ts = (parsed["timestamp_ms"] as? Number)?.toLong()
                val authProvided = sigHex.isNotBlank() || publicKeyHex.isNotBlank()
                if (config.requireSignedAuth || authProvided) {
                    val expectedNonce = session.challengeNonce
                    if (
                        expectedNonce.isNullOrBlank() ||
                        nonce != expectedNonce ||
                        ts == null ||
                        abs(now - ts) > 120_000L ||
                        !isValidNodeIdentity(nodeId, publicKeyHex) ||
                        !verifyEd25519Hex(
                            publicKeyHex,
                            "NMD-SIG-AUTH|$nodeId|$chainId|$nonce|$ts".toByteArray(StandardCharsets.UTF_8),
                            sigHex
                        )
                    ) {
                        rejectedMessages.incrementAndGet()
                        logStructured("WARN", "SIGNALING_AUTH_FAILED", "node=${nodeId.take(18)}")
                        session.sendTextFrame(
                            mapAdapter.toJson(
                                mapOf(
                                    "type" to "ERROR",
                                    "code" to "AUTH_FAILED",
                                    "message" to "Ed25519 challenge-response authentication failed"
                                )
                            )
                        )
                        return
                    }
                    session.challengeNonce = null
                }

                session.registeredNodeId = nodeId
                nodeSessions[nodeId] = session
                session.sendTextFrame(
                    mapAdapter.toJson(mapOf("type" to "REGISTERED", "node_id" to nodeId, "chain_id" to config.chainId))
                )
                logStructured("INFO", "PEER_SIGNALING_REGISTERED", "node=${nodeId.take(18)}")
                drainOfflineQueueForPeer(nodeId, session, now)
            }
            "ENVELOPE" -> {
                val envMap = parsed["envelope"] as? Map<*, *>
                if (envMap == null) {
                    rejectedMessages.incrementAndGet()
                    session.sendTextFrame(mapAdapter.toJson(mapOf("type" to "ERROR", "code" to "MISSING_ENVELOPE")))
                    return
                }
                val envChain = envMap["chain_id"] as? String
                val sender = envMap["sender_node_id"] as? String
                val recipient = envMap["recipient_node_id"] as? String
                val signature = envMap["signature_hex"] as? String

                if (envChain != config.chainId || sender.isNullOrBlank() || recipient.isNullOrBlank() || signature.isNullOrBlank()) {
                    rejectedMessages.incrementAndGet()
                    logStructured("WARN", "ENVELOPE_REJECTED", "chain=$envChain sender=${sender?.take(14)}")
                    session.sendTextFrame(
                        mapAdapter.toJson(
                            mapOf(
                                "type" to "ERROR",
                                "code" to if (envChain != config.chainId) "CHAIN_MISMATCH" else "INVALID_ENVELOPE",
                                "message" to "Rejected signaling envelope"
                            )
                        )
                    )
                    return
                }

                // Never tamper with the signed envelope; relay exact original JSON string cleanly
                val targetSession = nodeSessions[recipient]
                if (targetSession != null && !targetSession.socket.isClosed) {
                    val delivered = runCatching {
                        targetSession.sendTextFrame(rawText)
                    }.isSuccess
                    if (delivered) {
                        routedMessages.incrementAndGet()
                        return
                    }
                }

                // Store in bounded expiring offline queue
                pruneExpiredOfflineQueues(now)
                if (currentTotalQueueDepth() >= config.maxTotalOfflineQueued) {
                    overloadRejected503.incrementAndGet()
                    rejectedMessages.incrementAndGet()
                    session.sendTextFrame(
                        mapAdapter.toJson(mapOf("type" to "ERROR", "code" to "SERVER_OVERLOADED", "message" to "Signaling offline queue capacity reached"))
                    )
                    return
                }
                val queue = offlineQueues.computeIfAbsent(recipient) { ArrayDeque() }
                synchronized(queue) {
                    while (queue.size >= config.maxQueuedPerPeer) {
                        queue.removeFirst()
                    }
                    queue.addLast(QueuedEnvelope(rawText, now + config.offlineQueueTtlMs))
                }
                queuedOffline.incrementAndGet()
            }
            "PING" -> {
                session.sendTextFrame(mapAdapter.toJson(mapOf("type" to "PONG", "ts" to now)))
            }
            else -> {
                rejectedMessages.incrementAndGet()
                session.sendTextFrame(mapAdapter.toJson(mapOf("type" to "ERROR", "code" to "UNKNOWN_FRAME_TYPE")))
            }
        }
    }

    private fun drainOfflineQueueForPeer(nodeId: String, session: ClientSession, nowMs: Long) {
        val queue = offlineQueues.remove(nodeId) ?: return
        synchronized(queue) {
            while (queue.isNotEmpty()) {
                val item = queue.removeFirst()
                if (item.expiresAtMs > nowMs) {
                    runCatching {
                        session.sendTextFrame(item.jsonFrame)
                        routedMessages.incrementAndGet()
                    }
                } else {
                    expiredOffline.incrementAndGet()
                }
            }
        }
    }

    private fun checkRateLimit(key: String, nowMs: Long): Boolean {
        val window = rateWindows.computeIfAbsent(key) { ArrayDeque() }
        synchronized(window) {
            while (window.isNotEmpty() && nowMs - window.first() > config.rateLimitWindowMs) {
                window.removeFirst()
            }
            if (window.size >= config.maxMessagesPerWindow) {
                rateLimitedCount.incrementAndGet()
                logStructured("WARN", "SIGNALING_RATE_LIMIT", "key=${key.take(18)}")
                return false
            }
            window.addLast(nowMs)
        }
        return true
    }

    private data class WsFrame(val opcode: Int, val payload: ByteArray)
    private class FrameTooLargeException(message: String) : Exception(message)

    private fun readWsFrame(input: DataInputStream, maxBytes: Int): WsFrame? {
        val b1 = input.read()
        if (b1 == -1) return null
        val b2 = input.read()
        if (b2 == -1) return null

        val opcode = b1 and 0x0F
        val masked = (b2 and 0x80) != 0
        var length = (b2 and 0x7F).toLong()
        if (length == 126L) {
            length = input.readUnsignedShort().toLong()
        } else if (length == 127L) {
            length = input.readLong()
        }

        if (length < 0 || length > maxBytes) {
            throw FrameTooLargeException("Frame length $length exceeds cap $maxBytes")
        }

        val maskKey = if (masked) ByteArray(4).also { input.readFully(it) } else null
        val payload = ByteArray(length.toInt())
        if (payload.isNotEmpty()) {
            input.readFully(payload)
            if (maskKey != null) {
                for (i in payload.indices) {
                    payload[i] = (payload[i].toInt() xor maskKey[i % 4].toInt()).toByte()
                }
            }
        }
        return WsFrame(opcode, payload)
    }

    private fun readHttpHeaders(input: InputStream): Pair<String, Map<String, String>>? {
        val buffer = ByteArrayOutputStream()
        var prev1 = 0
        var prev2 = 0
        var prev3 = 0
        while (buffer.size() < 8192) {
            val b = input.read()
            if (b == -1) return null
            buffer.write(b)
            if (prev3 == '\r'.code && prev2 == '\n'.code && prev1 == '\r'.code && b == '\n'.code) {
                break
            }
            prev3 = prev2
            prev2 = prev1
            prev1 = b
        }
        val raw = buffer.toString(StandardCharsets.US_ASCII)
        val lines = raw.split("\r\n").filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null
        val requestLine = lines[0]
        val headers = LinkedHashMap<String, String>()
        for (i in 1 until lines.size) {
            val idx = lines[i].indexOf(':')
            if (idx > 0) {
                headers[lines[i].substring(0, idx).trim().lowercase()] = lines[i].substring(idx + 1).trim()
            }
        }
        return requestLine to headers
    }

    private fun writeHttpJsonResponse(output: OutputStream, status: Int, json: String) {
        writeHttpTextResponse(output, status, "application/json; charset=utf-8", json)
    }

    private fun writeHttpTextResponse(output: OutputStream, status: Int, contentType: String, payloadText: String) {
        val body = payloadText.toByteArray(StandardCharsets.UTF_8)
        val statusText = when (status) {
            200 -> "OK"
            503 -> "Service Unavailable"
            else -> "Bad Request"
        }
        val headers = buildString {
            append("HTTP/1.1 ").append(status).append(" ").append(statusText).append("\r\n")
            append("Content-Type: ").append(contentType).append("\r\n")
            append("Content-Length: ").append(body.size).append("\r\n")
            append("Connection: close\r\n\r\n")
        }
        output.write(headers.toByteArray(StandardCharsets.US_ASCII))
        output.write(body)
        output.flush()
    }

    private fun computeWebSocketAccept(key: String): String {
        val md = MessageDigest.getInstance("SHA-1")
        val digest = md.digest((key.trim() + WS_MAGIC_GUID).toByteArray(StandardCharsets.US_ASCII))
        return Base64.getEncoder().encodeToString(digest)
    }

    private fun loadPkcs12SslContext(path: String, password: String): SSLContext {
        val ks = KeyStore.getInstance("PKCS12")
        FileInputStream(path).use { ks.load(it, password.toCharArray()) }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, password.toCharArray())
        return SSLContext.getInstance("TLS").apply { init(kmf.keyManagers, null, null) }
    }

    private fun isValidNodeIdentity(nodeId: String, publicKeyHex: String): Boolean {
        if (!nodeId.startsWith("nmd_node_") || publicKeyHex.length != 64) return false
        return try {
            val pubBytes = hexToBytes(publicKeyHex)
            if (pubBytes.size != 32) return false
            val hash = MessageDigest.getInstance("SHA-256").digest(pubBytes)
            val expectedNodeId = "nmd_node_" + bytesToHex(hash).substring(0, 32)
            nodeId == expectedNodeId
        } catch (_: Exception) {
            false
        }
    }

    private fun verifyEd25519Hex(publicKeyHex: String, data: ByteArray, signatureHex: String): Boolean {
        return try {
            val pubBytes = hexToBytes(publicKeyHex)
            val sigBytes = hexToBytes(signatureHex)
            if (pubBytes.size != 32 || sigBytes.size != 64) return false
            val verifier = Ed25519Signer()
            verifier.init(false, Ed25519PublicKeyParameters(pubBytes, 0))
            verifier.update(data, 0, data.size)
            verifier.verifySignature(sigBytes)
        } catch (_: Exception) {
            false
        }
    }

    private fun hexToBytes(hex: String): ByteArray {
        val clean = hex.trim().lowercase()
        require(clean.length % 2 == 0) { "Odd hex length" }
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    private fun bytesToHex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    private fun logStructured(level: String, event: String, detail: String) {
        logSink("{\"ts\":\"${Instant.now()}\",\"svc\":\"signaling\",\"level\":\"$level\",\"event\":\"$event\",\"detail\":\"$detail\"}")
    }

    override fun close() {
        if (!running.compareAndSet(true, false)) return
        logStructured("INFO", "SIGNALING_SHUTTING_DOWN", "activeSessions=${sessionsById.size}")
        maintenanceScheduler?.shutdownNow()
        maintenanceScheduler = null
        sessionsById.values.forEach {
            it.sendClose(1001, "Server shutting down")
            runCatching { it.socket.close() }
        }
        sessionsById.clear()
        nodeSessions.clear()
        offlineQueues.clear()
        runCatching { serverSocket?.close() }
        serverSocket = null
        acceptThread?.join(1_000L)
        workerExecutor.shutdownNow()
    }
}
