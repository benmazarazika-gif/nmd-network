package com.nmd.signaling

import java.util.concurrent.CountDownLatch

fun main() {
    val config = SignalingServiceConfig.fromEnv()
    val server = SignalingServer(config)
    val port = server.start()
    val shutdownLatch = CountDownLatch(1)

    Runtime.getRuntime().addShutdownHook(Thread {
        server.close()
        shutdownLatch.countDown()
    })

    println("{\"event\":\"SIGNALING_READY\",\"host\":\"${config.bindHost}\",\"port\":$port,\"chain_id\":\"${config.chainId}\"}")
    shutdownLatch.await()
}
