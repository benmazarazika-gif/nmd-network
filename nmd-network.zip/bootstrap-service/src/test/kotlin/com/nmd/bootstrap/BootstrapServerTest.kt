package com.nmd.bootstrap

import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.bouncycastle.crypto.generators.Ed25519KeyPairGenerator
import org.bouncycastle.crypto.params.Ed25519KeyGenerationParameters
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicLong

class BootstrapServerTest {

    private val client = OkHttpClient()
    private val moshi = Moshi.Builder().build()
    private val mapType = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
    private val mapAdapter = moshi.adapter<Map<String, Any?>>(mapType)
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val servers = mutableListOf<BootstrapServer>()

    private val testGenesisHash = "a".repeat(64)
    private val testChainId = "nmd-private-testnet-1"

    @After
    fun cleanup() {
        servers.forEach { runCatching { it.close() } }
        servers.clear()
    }

    private fun generateTestNode(): Pair<String, String> {
        val gen = Ed25519KeyPairGenerator()
        gen.init(Ed25519KeyGenerationParameters(SecureRandom()))
        val kp = gen.generateKeyPair()
        val pubBytes = (kp.public as Ed25519PublicKeyParameters).encoded
        val pubHex = pubBytes.joinToString("") { "%02x".format(it) }
        val hashHex = MessageDigest.getInstance("SHA-256").digest(pubBytes).joinToString("") { "%02x".format(it) }
        val nodeId = "nmd_node_" + hashHex.substring(0, 32)
        return nodeId to pubHex
    }

    private fun generateSigningSeedHex(): Pair<String, ByteArray> {
        val gen = Ed25519KeyPairGenerator()
        gen.init(Ed25519KeyGenerationParameters(SecureRandom()))
        val kp = gen.generateKeyPair()
        val priv = (kp.private as Ed25519PrivateKeyParameters).encoded
        val pub = (kp.public as Ed25519PublicKeyParameters).encoded
        return priv.joinToString("") { "%02x".format(it) } to pub
    }

    @Test
    fun `health endpoint, signed network config, peer registration, discovery, and graceful shutdown`() {
        val (privSeedHex, pubBytes) = generateSigningSeedHex()
        val now = AtomicLong(1_740_000_000_000L)
        val server = BootstrapServer(
            config = BootstrapServiceConfig(
                port = 0,
                chainId = testChainId,
                genesisHash = testGenesisHash,
                responseSigningPrivateKeyHex = privSeedHex
            ),
            clockMs = { now.get() }
        ).also { servers.add(it) }

        val port = server.start()
        val baseUrl = "http://127.0.0.1:$port"

        // 1. Health check
        client.newCall(Request.Builder().url("$baseUrl/health").get().build()).execute().use { resp ->
            assertEquals(200, resp.code)
            val body = mapAdapter.fromJson(resp.body!!.string())!!
            assertEquals("OK", body["status"])
            assertEquals(testChainId, body["chain_id"])
            assertEquals(testGenesisHash, body["genesis_hash"])
        }

        // 2. Signed network config check
        client.newCall(Request.Builder().url("$baseUrl/v1/network-config").get().build()).execute().use { resp ->
            assertEquals(200, resp.code)
            val body = mapAdapter.fromJson(resp.body!!.string())!!
            val sigHex = body["signature_hex"] as String
            val ts = (body["timestamp_ms"] as Number).toLong()
            val canonical = "${body["network_profile"]}|$testChainId|$testGenesisHash|1|$ts".toByteArray()
            val sigBytes = sigHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            val verifier = Ed25519Signer()
            verifier.init(false, Ed25519PublicKeyParameters(pubBytes, 0))
            verifier.update(canonical, 0, canonical.size)
            assertTrue(verifier.verifySignature(sigBytes))
        }

        // 3. Register valid peer
        val (nodeId, pubHex) = generateTestNode()
        val regPayload = mapAdapter.toJson(
            mapOf(
                "node_id" to nodeId,
                "public_key_hex" to pubHex,
                "protocol_version" to 1,
                "chain_id" to testChainId,
                "genesis_hash" to testGenesisHash,
                "host" to "198.51.100.12",
                "port" to 8765,
                "capabilities" to listOf("p2p", "stage7_discovery")
            )
        )
        client.newCall(
            Request.Builder().url("$baseUrl/v1/peers/register").post(regPayload.toRequestBody(jsonMedia)).build()
        ).execute().use { resp ->
            assertEquals(200, resp.code)
        }

        // 4. Discovery query returns registered peer
        client.newCall(
            Request.Builder().url("$baseUrl/v1/peers?chain_id=$testChainId&genesis_hash=$testGenesisHash").get().build()
        ).execute().use { resp ->
            assertEquals(200, resp.code)
            val body = mapAdapter.fromJson(resp.body!!.string())!!
            val peers = body["peers"] as List<*>
            assertEquals(1, peers.size)
        }

        // 5. Graceful shutdown closes port
        server.close()
        val failedAfterClose = runCatching {
            client.newCall(Request.Builder().url("$baseUrl/health").get().build()).execute().close()
        }.isFailure
        assertTrue(failedAfterClose)
    }

    @Test
    fun `rejects wrong chain, malformed requests, private secrets, expires stale peers, and enforces rate limits`() {
        val now = AtomicLong(1_740_000_000_000L)
        val server = BootstrapServer(
            config = BootstrapServiceConfig(
                port = 0,
                chainId = testChainId,
                genesisHash = testGenesisHash,
                peerRecordTtlMs = 5_000L,
                maxRequestsPerWindowPerIp = 6
            ),
            clockMs = { now.get() }
        ).also { servers.add(it) }
        val port = server.start()
        val baseUrl = "http://127.0.0.1:$port"

        val (nodeId, pubHex) = generateTestNode()

        // Wrong chain rejected (409)
        val wrongChain = mapAdapter.toJson(
            mapOf(
                "node_id" to nodeId,
                "public_key_hex" to pubHex,
                "protocol_version" to 1,
                "chain_id" to "wrong-chain",
                "genesis_hash" to testGenesisHash,
                "host" to "198.51.100.12",
                "port" to 8765
            )
        )
        client.newCall(Request.Builder().url("$baseUrl/v1/peers/register").post(wrongChain.toRequestBody(jsonMedia)).build()).execute().use {
            assertEquals(409, it.code)
        }

        // Private key leakage attempt rejected (400)
        val secretLeak = mapAdapter.toJson(
            mapOf(
                "node_id" to nodeId,
                "public_key_hex" to pubHex,
                "private_key" to "deadbeef",
                "protocol_version" to 1,
                "chain_id" to testChainId,
                "genesis_hash" to testGenesisHash,
                "host" to "198.51.100.12",
                "port" to 8765
            )
        )
        client.newCall(Request.Builder().url("$baseUrl/v1/peers/register").post(secretLeak.toRequestBody(jsonMedia)).build()).execute().use {
            assertEquals(400, it.code)
        }

        // Valid peer registered then expires cleanly
        val validReg = mapAdapter.toJson(
            mapOf(
                "node_id" to nodeId,
                "public_key_hex" to pubHex,
                "protocol_version" to 1,
                "chain_id" to testChainId,
                "genesis_hash" to testGenesisHash,
                "host" to "198.51.100.12",
                "port" to 8765
            )
        )
        client.newCall(Request.Builder().url("$baseUrl/v1/peers/register").post(validReg.toRequestBody(jsonMedia)).build()).execute().use {
            assertEquals(200, it.code)
        }

        // Advance clock beyond TTL -> expired
        now.addAndGet(10_000L)
        assertEquals(1, server.pruneExpiredPeers())

        // Trigger rate limit (> 6 requests in window)
        var got429 = false
        repeat(6) {
            client.newCall(Request.Builder().url("$baseUrl/v1/peers").get().build()).execute().use { resp ->
                if (resp.code == 429) got429 = true
            }
        }
        assertTrue("Expected rate limiter 429 response", got429)

        client.newCall(Request.Builder().url("$baseUrl/metrics").get().build()).execute().use { resp ->
            assertEquals(200, resp.code)
            val m = mapAdapter.fromJson(resp.body!!.string())!!
            assertFalse(m.isEmpty())
            assertTrue((m["rate_limited_requests"] as Number).toLong() >= 1L)
            assertTrue(m.containsKey("requests_per_second"))
            assertTrue(m.containsKey("active_connections"))
            assertTrue(m.containsKey("registered_peers"))
            assertTrue(m.containsKey("rejected_requests"))
            assertTrue(m.containsKey("expired_peer_records"))
            assertTrue(m.containsKey("uptime_ms"))
            assertTrue(m.containsKey("error_counts"))
            assertTrue((m["heap_max_bytes"] as Number).toLong() > 0L)
        }

        client.newCall(Request.Builder().url("$baseUrl/metrics/prometheus").get().build()).execute().use { resp ->
            assertEquals(200, resp.code)
            val prom = resp.body!!.string()
            assertTrue(prom.contains("nmd_bootstrap_requests_total"))
            assertTrue(prom.contains("nmd_bootstrap_registered_peers"))
            assertTrue(prom.contains("nmd_bootstrap_heap_used_bytes"))
        }
    }

    @Test
    fun `enforces Ed25519 signed registration and persists directory across restarts`() {
        val now = AtomicLong(1_740_000_000_000L)
        val tmpDir = java.nio.file.Files.createTempDirectory("nmd-boot-persist").toFile()
        val storageFile = java.io.File(tmpDir, "peers.json")

        val gen = Ed25519KeyPairGenerator()
        gen.init(Ed25519KeyGenerationParameters(SecureRandom()))
        val kp = gen.generateKeyPair()
        val priv = kp.private as Ed25519PrivateKeyParameters
        val pubBytes = (kp.public as Ed25519PublicKeyParameters).encoded
        val pubHex = pubBytes.joinToString("") { "%02x".format(it) }
        val nodeId = "nmd_node_" + MessageDigest.getInstance("SHA-256").digest(pubBytes).joinToString("") { "%02x".format(it) }.substring(0, 32)

        val server1 = BootstrapServer(
            config = BootstrapServiceConfig(
                port = 0,
                chainId = testChainId,
                genesisHash = testGenesisHash,
                requireSignedRegistrations = true,
                storagePath = storageFile.absolutePath
            ),
            clockMs = { now.get() }
        ).also { servers.add(it) }
        val port1 = server1.start()

        // Unsigned payload rejected with 401
        val unsignedPayload = mapAdapter.toJson(
            mapOf(
                "node_id" to nodeId,
                "public_key_hex" to pubHex,
                "protocol_version" to 1,
                "chain_id" to testChainId,
                "genesis_hash" to testGenesisHash,
                "host" to "198.51.100.55",
                "port" to 9876
            )
        )
        client.newCall(Request.Builder().url("http://127.0.0.1:$port1/v1/peers/register").post(unsignedPayload.toRequestBody(jsonMedia)).build()).execute().use {
            assertEquals(401, it.code)
        }

        // Signed registration accepted
        val ts = now.get()
        val canonical = "$nodeId|$pubHex|198.51.100.55|9876|$testChainId|$ts".toByteArray(java.nio.charset.StandardCharsets.UTF_8)
        val signer = Ed25519Signer()
        signer.init(true, priv)
        signer.update(canonical, 0, canonical.size)
        val sigHex = signer.generateSignature().joinToString("") { "%02x".format(it) }

        val signedPayload = mapAdapter.toJson(
            mapOf(
                "node_id" to nodeId,
                "public_key_hex" to pubHex,
                "protocol_version" to 1,
                "chain_id" to testChainId,
                "genesis_hash" to testGenesisHash,
                "host" to "198.51.100.55",
                "port" to 9876,
                "timestamp_ms" to ts,
                "signature_hex" to sigHex
            )
        )
        client.newCall(Request.Builder().url("http://127.0.0.1:$port1/v1/peers/register").post(signedPayload.toRequestBody(jsonMedia)).build()).execute().use {
            assertEquals(200, it.code)
        }
        server1.close()

        // Restart fresh BootstrapServer pointing at same storagePath -> directory survives!
        val server2 = BootstrapServer(
            config = BootstrapServiceConfig(
                port = 0,
                chainId = testChainId,
                genesisHash = testGenesisHash,
                requireSignedRegistrations = true,
                storagePath = storageFile.absolutePath
            ),
            clockMs = { now.get() }
        ).also { servers.add(it) }
        val port2 = server2.start()
        client.newCall(
            Request.Builder().url("http://127.0.0.1:$port2/v1/peers?chain_id=$testChainId&genesis_hash=$testGenesisHash").get().build()
        ).execute().use { resp ->
            assertEquals(200, resp.code)
            val peers = (mapAdapter.fromJson(resp.body!!.string())!!["peers"] as List<*>)
            assertEquals(1, peers.size)
        }
        server2.close()
        tmpDir.deleteRecursively()
    }
}
