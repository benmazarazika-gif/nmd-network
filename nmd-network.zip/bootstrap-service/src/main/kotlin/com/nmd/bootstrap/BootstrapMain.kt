package com.nmd.bootstrap

import java.util.concurrent.CountDownLatch

fun main() {
    val config = BootstrapServiceConfig.fromEnv()
    val server = BootstrapServer(config)
    val port = server.start()
    val shutdownLatch = CountDownLatch(1)

    Runtime.getRuntime().addShutdownHook(Thread {
        server.close()
        shutdownLatch.countDown()
    })

    println("{\"event\":\"BOOTSTRAP_READY\",\"host\":\"${config.bindHost}\",\"port\":$port,\"chain_id\":\"${config.chainId}\"}")
    shutdownLatch.await()
}
