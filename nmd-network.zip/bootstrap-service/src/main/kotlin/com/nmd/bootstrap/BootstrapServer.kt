package com.nmd.bootstrap

import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import com.sun.net.httpserver.HttpsConfigurator
import com.sun.net.httpserver.HttpsParameters
import com.sun.net.httpserver.HttpsServer
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.net.InetSocketAddress
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.math.abs
import java.security.KeyStore
import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext

enum class ServiceNetworkProfile {
    DEVELOPMENT,
    TESTNET,
    MAINNET
}

data class BootstrapServiceConfig(
    val bindHost: String = "127.0.0.1",
    val port: Int = 8844,
    val networkProfile: ServiceNetworkProfile = ServiceNetworkProfile.TESTNET,
    val chainId: String = "nmd-private-testnet-1",
    val genesisHash: String,
    val protocolVersion: Int = 1,
    val maxDirectorySize: Int = 2_000,
    val maxPeersPerResponse: Int = 50,
    val peerRecordTtlMs: Long = 15 * 60_000L,
    val maxRequestBodyBytes: Int = 16_384,
    val rateLimitWindowMs: Long = 60_000L,
    val maxRequestsPerWindowPerIp: Int = 60,
    val tlsKeystorePath: String? = null,
    val tlsKeystorePassword: String? = null,
    val responseSigningPrivateKeyHex: String? = null,
    val maxConcurrentRequests: Int = 128,
    val requireSignedRegistrations: Boolean = false,
    val registrationReplayWindowMs: Long = 300_000L,
    val storagePath: String? = null
) {
    init {
        require(maxConcurrentRequests in 1..4096) { "maxConcurrentRequests must be in 1..4096" }
        require(port in 0..65535) { "Port must be in 0..65535" }
        require(chainId.isNotBlank()) { "chainId cannot be blank" }
        require(genesisHash.length == 64 && genesisHash.all { it.lowercaseChar() in '0'..'9' || it.lowercaseChar() in 'a'..'f' }) {
            "genesisHash must be a 64-char hex SHA-256 hash"
        }
        require(maxDirectorySize > 0) { "maxDirectorySize must be > 0" }
        require(maxPeersPerResponse in 1..200) { "maxPeersPerResponse must be in 1..200" }
        require(peerRecordTtlMs >= 5_000L) { "peerRecordTtlMs must be >= 5000ms" }
        require(registrationReplayWindowMs >= 10_000L) { "registrationReplayWindowMs must be >= 10000ms" }
    }

    companion object {
        fun fromEnv(env: Map<String, String> = System.getenv()): BootstrapServiceConfig {
            val profile = env["NMD_NETWORK_PROFILE"]
                ?.let { runCatching { ServiceNetworkProfile.valueOf(it.uppercase()) }.getOrNull() }
                ?: ServiceNetworkProfile.TESTNET
            val chainId = env["NMD_CHAIN_ID"]?.takeIf { it.isNotBlank() }
                ?: error("NMD_CHAIN_ID must be configured externally")
            val genesisHash = env["NMD_GENESIS_HASH"]?.takeIf { it.isNotBlank() }
                ?: error("NMD_GENESIS_HASH must be configured externally")

            return BootstrapServiceConfig(
                bindHost = env["NMD_BOOTSTRAP_HOST"]?.takeIf { it.isNotBlank() } ?: "127.0.0.1",
                port = env["NMD_BOOTSTRAP_PORT"]?.toIntOrNull() ?: 8844,
                networkProfile = profile,
                chainId = chainId,
                genesisHash = genesisHash.lowercase(),
                protocolVersion = env["NMD_PROTOCOL_VERSION"]?.toIntOrNull() ?: 1,
                maxDirectorySize = env["NMD_MAX_DIRECTORY_SIZE"]?.toIntOrNull() ?: 2_000,
                maxPeersPerResponse = env["NMD_MAX_PEERS_PER_RESPONSE"]?.toIntOrNull() ?: 50,
                peerRecordTtlMs = env["NMD_PEER_TTL_MS"]?.toLongOrNull() ?: (15 * 60_000L),
                maxRequestBodyBytes = env["NMD_MAX_REQUEST_BYTES"]?.toIntOrNull() ?: 16_384,
                rateLimitWindowMs = env["NMD_RATE_WINDOW_MS"]?.toLongOrNull() ?: 60_000L,
                maxRequestsPerWindowPerIp = env["NMD_RATE_MAX_PER_IP"]?.toIntOrNull() ?: 60,
                tlsKeystorePath = env["NMD_TLS_KEYSTORE_PATH"]?.takeIf { it.isNotBlank() },
                tlsKeystorePassword = env["NMD_TLS_KEYSTORE_PASSWORD"]?.takeIf { it.isNotBlank() },
                responseSigningPrivateKeyHex = env["NMD_BOOTSTRAP_SIGNING_PRIVATE_KEY_HEX"]?.takeIf { it.isNotBlank() },
                maxConcurrentRequests = env["NMD_BOOTSTRAP_MAX_CONCURRENT_REQS"]?.toIntOrNull() ?: 128,
                requireSignedRegistrations = env["NMD_BOOTSTRAP_REQUIRE_SIGNED_REG"]?.toBooleanStrictOrNull() ?: true,
                registrationReplayWindowMs = env["NMD_BOOTSTRAP_REPLAY_WINDOW_MS"]?.toLongOrNull() ?: 300_000L,
                storagePath = env["NMD_BOOTSTRAP_STORAGE_PATH"]?.takeIf { it.isNotBlank() }
            )
        }
    }
}

data class DirectoryPeerEntry(
    val nodeId: String,
    val publicKeyHex: String,
    val protocolVersion: Int,
    val chainId: String,
    val genesisHash: String,
    val host: String,
    val port: Int,
    val capabilities: List<String>,
    val availabilityStatus: String,
    val lastSeenTimestampMs: Long,
    val expiresAtMs: Long
)

/**
 * Deployable stateless/directory-only NMD Bootstrap Node HTTP/HTTPS Service.
 *
 * Security & Decentralization Guarantees:
 * - Never stores private keys or user session secrets.
 * - Never validates blocks, overrides BFT consensus, or issues tokens.
 * - Verifies Node ID <-> Ed25519 public key derivation, Chain ID, Genesis Hash, and protocol bounds.
 * - Enforces bounded peer capacity, automatic TTL expiration, payload caps, and per-IP rate limiting.
 */
class BootstrapServer(
    private val config: BootstrapServiceConfig,
    private val clockMs: () -> Long = { System.currentTimeMillis() },
    private val logSink: (String) -> Unit = { println(it) }
) : Closeable {

    companion object {
        private const val NODE_ID_PREFIX = "nmd_node_"
        private val FORBIDDEN_SECRET_FIELDS = setOf("private_key", "privateKey", "session_key", "sessionKey", "seed", "mnemonic")
    }

    private val moshi = Moshi.Builder().build()
    private val mapType = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
    private val mapAdapter: JsonAdapter<Map<String, Any?>> = moshi.adapter(mapType)

    private val directory = ConcurrentHashMap<String, DirectoryPeerEntry>()
    private val rateWindows = ConcurrentHashMap<String, ArrayDeque<Long>>()
    private val executor = Executors.newFixedThreadPool(4)
    private var cleanupScheduler: ScheduledExecutorService? = null
    private var httpServer: HttpServer? = null

    private val startedAtMs = clockMs()
    private val requestsTotal = AtomicLong(0L)
    private val activeConnections = java.util.concurrent.atomic.AtomicInteger(0)
    private val registrationsAccepted = AtomicLong(0L)
    private val discoveryQueries = AtomicLong(0L)
    private val expiredPruned = AtomicLong(0L)
    private val rateLimitedRequests = AtomicLong(0L)
    private val malformedRejected = AtomicLong(0L)
    private val wrongChainRejected = AtomicLong(0L)
    private val overloadRejected503 = AtomicLong(0L)
    private val internalErrorCount = AtomicLong(0L)
    private val recentRequestTimestamps = ArrayDeque<Long>()

    private val signingKeyPair: Pair<ByteArray, String>? = config.responseSigningPrivateKeyHex?.let { privHex ->
        val privBytes = hexToBytes(privHex)
        require(privBytes.size == 32) { "NMD_BOOTSTRAP_SIGNING_PRIVATE_KEY_HEX must be 32-byte Ed25519 seed" }
        val privParam = Ed25519PrivateKeyParameters(privBytes, 0)
        val pubHex = bytesToHex(privParam.generatePublicKey().encoded)
        privBytes to pubHex
    }

    @Volatile
    var boundPort: Int = config.port
        private set

    fun start(): Int {
        if (httpServer != null) return boundPort

        loadDirectoryFromDisk()
        val address = InetSocketAddress(config.bindHost, config.port)
        val server: HttpServer = if (!config.tlsKeystorePath.isNullOrBlank()) {
            val sslContext = loadPkcs12SslContext(config.tlsKeystorePath, config.tlsKeystorePassword.orEmpty())
            HttpsServer.create(address, 64).apply {
                httpsConfigurator = object : HttpsConfigurator(sslContext) {
                    override fun configure(params: HttpsParameters) {
                        val engine = sslContext.createSSLEngine()
                        params.needClientAuth = false
                        params.cipherSuites = engine.enabledCipherSuites
                        params.protocols = arrayOf("TLSv1.3", "TLSv1.2").filter { it in engine.supportedProtocols }.toTypedArray()
                        params.setSSLParameters(sslContext.defaultSSLParameters)
                    }
                }
            }
        } else {
            HttpServer.create(address, 64)
        }

        server.executor = executor
        server.createContext("/health", wrapHandler(::handleHealth))
        server.createContext("/v1/network-config", wrapHandler(::handleNetworkConfig))
        server.createContext("/v1/peers/register", wrapHandler(::handleRegisterPeer))
        server.createContext("/v1/peers", wrapHandler(::handleGetPeers))
        server.createContext("/metrics", wrapHandler(::handleMetricsDispatch))
        server.start()

        httpServer = server
        boundPort = server.address.port

        cleanupScheduler = Executors.newSingleThreadScheduledExecutor().apply {
            scheduleAtFixedRate({ pruneExpiredPeers() }, 30L, 30L, TimeUnit.SECONDS)
        }

        logStructured("INFO", "BOOTSTRAP_STARTED", "host=${config.bindHost} port=$boundPort profile=${config.networkProfile.name} tls=${!config.tlsKeystorePath.isNullOrBlank()}")
        return boundPort
    }

    fun pruneExpiredPeers(nowMs: Long = clockMs()): Int {
        var removed = 0
        val iter = directory.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next()
            if (entry.value.expiresAtMs <= nowMs) {
                iter.remove()
                removed++
            }
        }
        if (removed > 0) {
            expiredPruned.addAndGet(removed.toLong())
            logStructured("INFO", "PEERS_EXPIRED_PRUNED", "count=$removed active=${directory.size}")
        }
        return removed
    }

    private fun wrapHandler(delegate: (HttpExchange) -> Unit): com.sun.net.httpserver.HttpHandler {
        return com.sun.net.httpserver.HttpHandler { exchange ->
            recordRequestTimestamp()
            val current = activeConnections.incrementAndGet()
            try {
                if (current > config.maxConcurrentRequests) {
                    overloadRejected503.incrementAndGet()
                    logStructured("WARN", "BOOTSTRAP_OVERLOAD_503", "active=$current cap=${config.maxConcurrentRequests}")
                    sendJson(exchange, 503, mapOf("error" to "Service Unavailable: server overloaded"))
                    return@HttpHandler
                }
                delegate(exchange)
            } catch (e: Exception) {
                internalErrorCount.incrementAndGet()
                logStructured("ERROR", "HTTP_HANDLER_EXCEPTION", "path=${exchange.requestURI.path} type=${e.javaClass.simpleName}")
                runCatching { sendJson(exchange, 500, mapOf("error" to "Internal Server Error")) }
            } finally {
                activeConnections.decrementAndGet()
            }
        }
    }

    private fun recordRequestTimestamp() {
        val now = clockMs()
        synchronized(recentRequestTimestamps) {
            recentRequestTimestamps.addLast(now)
            while (recentRequestTimestamps.isNotEmpty() && now - recentRequestTimestamps.first() > 10_000L) {
                recentRequestTimestamps.removeFirst()
            }
        }
    }

    private fun computeRequestsPerSecond(): Double {
        val now = clockMs()
        synchronized(recentRequestTimestamps) {
            while (recentRequestTimestamps.isNotEmpty() && now - recentRequestTimestamps.first() > 10_000L) {
                recentRequestTimestamps.removeFirst()
            }
            return recentRequestTimestamps.size / 10.0
        }
    }

    private fun handleHealth(exchange: HttpExchange) {
        requestsTotal.incrementAndGet()
        if (exchange.requestMethod != "GET") {
            sendJson(exchange, 405, mapOf("error" to "Method Not Allowed"))
            return
        }
        pruneExpiredPeers()
        val now = clockMs()
        sendJson(
            exchange,
            200,
            mapOf(
                "status" to "OK",
                "service" to "nmd-bootstrap-service",
                "network_profile" to config.networkProfile.name,
                "chain_id" to config.chainId,
                "genesis_hash" to config.genesisHash,
                "protocol_version" to config.protocolVersion,
                "active_peers" to directory.size,
                "uptime_ms" to (now - startedAtMs).coerceAtLeast(0L)
            )
        )
    }

    private fun handleNetworkConfig(exchange: HttpExchange) {
        requestsTotal.incrementAndGet()
        if (!checkRateLimit(exchange)) return
        if (exchange.requestMethod != "GET") {
            sendJson(exchange, 405, mapOf("error" to "Method Not Allowed"))
            return
        }

        val now = clockMs()
        val payloadMap = linkedMapOf<String, Any?>(
            "network_profile" to config.networkProfile.name,
            "chain_id" to config.chainId,
            "genesis_hash" to config.genesisHash,
            "protocol_version" to config.protocolVersion,
            "max_peers_per_response" to config.maxPeersPerResponse,
            "peer_ttl_ms" to config.peerRecordTtlMs,
            "timestamp_ms" to now
        )
        signingKeyPair?.let { (privBytes, pubHex) ->
            val canonical = "${config.networkProfile.name}|${config.chainId}|${config.genesisHash}|${config.protocolVersion}|$now"
            payloadMap["server_public_key_hex"] = pubHex
            payloadMap["signature_hex"] = signEd25519Hex(privBytes, canonical.toByteArray(StandardCharsets.UTF_8))
        }
        sendJson(exchange, 200, payloadMap)
    }

    private fun handleRegisterPeer(exchange: HttpExchange) {
        requestsTotal.incrementAndGet()
        if (!checkRateLimit(exchange)) return
        if (exchange.requestMethod != "POST") {
            sendJson(exchange, 405, mapOf("error" to "Method Not Allowed"))
            return
        }

        val rawBody = readBoundedBody(exchange, config.maxRequestBodyBytes)
        if (rawBody == null) {
            malformedRejected.incrementAndGet()
            logStructured("WARN", "REGISTRATION_OVERSIZED", "remote=${exchange.remoteAddress.address.hostAddress}")
            sendJson(exchange, 413, mapOf("error" to "Request body exceeds ${config.maxRequestBodyBytes} bytes"))
            return
        }

        val parsed = try {
            mapAdapter.fromJson(rawBody)
        } catch (_: Exception) {
            null
        }
        if (parsed == null) {
            malformedRejected.incrementAndGet()
            sendJson(exchange, 400, mapOf("error" to "Malformed JSON payload"))
            return
        }

        if (FORBIDDEN_SECRET_FIELDS.any { parsed.containsKey(it) }) {
            malformedRejected.incrementAndGet()
            logStructured("WARN", "FORBIDDEN_SECRET_REJECTED", "remote=${exchange.remoteAddress.address.hostAddress}")
            sendJson(exchange, 400, mapOf("error" to "Private keys or session secrets are forbidden"))
            return
        }

        val chainId = (parsed["chain_id"] as? String)?.trim().orEmpty()
        val genesisHash = (parsed["genesis_hash"] as? String)?.trim()?.lowercase().orEmpty()
        if (chainId != config.chainId || genesisHash != config.genesisHash) {
            wrongChainRejected.incrementAndGet()
            logStructured("WARN", "WRONG_CHAIN_REJECTED", "gotChain=$chainId expectedChain=${config.chainId}")
            sendJson(exchange, 409, mapOf("error" to "Chain ID or Genesis Hash mismatch"))
            return
        }

        val protocolVersion = (parsed["protocol_version"] as? Number)?.toInt() ?: -1
        if (protocolVersion != config.protocolVersion) {
            malformedRejected.incrementAndGet()
            sendJson(exchange, 400, mapOf("error" to "Unsupported protocol version: $protocolVersion"))
            return
        }

        val nodeId = (parsed["node_id"] as? String)?.trim().orEmpty()
        val publicKeyHex = (parsed["public_key_hex"] as? String)?.trim()?.lowercase().orEmpty()
        if (!isValidNodeIdentity(nodeId, publicKeyHex)) {
            malformedRejected.incrementAndGet()
            logStructured("WARN", "INVALID_NODE_ID_REJECTED", "nodeId=$nodeId")
            sendJson(exchange, 400, mapOf("error" to "Invalid Node ID or Ed25519 public key derivation"))
            return
        }

        val host = (parsed["host"] as? String)?.trim().orEmpty()
        val port = (parsed["port"] as? Number)?.toInt() ?: -1
        if (!isValidHost(host) || port !in 1..65535) {
            malformedRejected.incrementAndGet()
            sendJson(exchange, 400, mapOf("error" to "Invalid host or port"))
            return
        }

        val rawCaps = (parsed["capabilities"] as? List<*>)?.mapNotNull { it as? String }?.take(12).orEmpty()
        val availability = (parsed["availability_status"] as? String)?.trim()?.take(32)?.ifBlank { "ONLINE" } ?: "ONLINE"

        val now = clockMs()
        val sigHex = (parsed["signature_hex"] as? String)?.trim().orEmpty()
        val signedTs = (parsed["timestamp_ms"] as? Number)?.toLong()
        if (config.requireSignedRegistrations || sigHex.isNotBlank() || signedTs != null) {
            if (sigHex.isBlank() || signedTs == null || abs(now - signedTs) > config.registrationReplayWindowMs) {
                malformedRejected.incrementAndGet()
                sendJson(exchange, 401, mapOf("error" to "Missing or expired peer registration signature"))
                return
            }
            val canonicalReg = "$nodeId|$publicKeyHex|$host|$port|$chainId|$signedTs"
            if (!verifyEd25519Hex(publicKeyHex, canonicalReg.toByteArray(StandardCharsets.UTF_8), sigHex)) {
                malformedRejected.incrementAndGet()
                logStructured("WARN", "INVALID_PEER_REG_SIGNATURE", "nodeId=${nodeId.take(18)}")
                sendJson(exchange, 401, mapOf("error" to "Invalid Ed25519 registration signature"))
                return
            }
        }

        pruneExpiredPeers(now)
        if (directory.size >= config.maxDirectorySize && !directory.containsKey(nodeId)) {
            // Evict oldest expiring entry to maintain hard bound
            directory.entries.minByOrNull { it.value.lastSeenTimestampMs }?.key?.let { directory.remove(it) }
        }

        val entry = DirectoryPeerEntry(
            nodeId = nodeId,
            publicKeyHex = publicKeyHex,
            protocolVersion = protocolVersion,
            chainId = chainId,
            genesisHash = genesisHash,
            host = host,
            port = port,
            capabilities = rawCaps,
            availabilityStatus = availability,
            lastSeenTimestampMs = now,
            expiresAtMs = now + config.peerRecordTtlMs
        )
        directory[nodeId] = entry
        saveDirectoryToDisk()
        registrationsAccepted.incrementAndGet()
        logStructured("INFO", "PEER_REGISTERED", "nodeId=${nodeId.take(18)} port=$port active=${directory.size}")

        sendJson(
            exchange,
            200,
            mapOf(
                "registered" to true,
                "node_id" to nodeId,
                "expires_at_ms" to entry.expiresAtMs,
                "chain_id" to config.chainId
            )
        )
    }

    private fun handleGetPeers(exchange: HttpExchange) {
        requestsTotal.incrementAndGet()
        if (!checkRateLimit(exchange)) return
        if (exchange.requestMethod != "GET") {
            sendJson(exchange, 405, mapOf("error" to "Method Not Allowed"))
            return
        }

        val params = parseQueryParams(exchange.requestURI.rawQuery)
        val reqChain = params["chain_id"]
        val reqGenesis = params["genesis_hash"]?.lowercase()
        if ((reqChain != null && reqChain != config.chainId) || (reqGenesis != null && reqGenesis != config.genesisHash)) {
            wrongChainRejected.incrementAndGet()
            sendJson(exchange, 409, mapOf("error" to "Chain ID or Genesis Hash mismatch"))
            return
        }

        val now = clockMs()
        pruneExpiredPeers(now)
        discoveryQueries.incrementAndGet()

        val requestedLimit = params["limit"]?.toIntOrNull()?.coerceIn(1, config.maxPeersPerResponse)
            ?: config.maxPeersPerResponse

        val peersList = directory.values
            .asSequence()
            .filter { it.expiresAtMs > now }
            .sortedByDescending { it.lastSeenTimestampMs }
            .take(requestedLimit)
            .map { p ->
                linkedMapOf<String, Any?>(
                    "node_id" to p.nodeId,
                    "public_key_hex" to p.publicKeyHex,
                    "protocol_version" to p.protocolVersion,
                    "chain_id" to p.chainId,
                    "genesis_hash" to p.genesisHash,
                    "host" to p.host,
                    "port" to p.port,
                    "last_seen_ms" to p.lastSeenTimestampMs,
                    "capabilities" to p.capabilities,
                    "availability_status" to p.availabilityStatus
                )
            }
            .toList()

        val body = linkedMapOf<String, Any?>(
            "network_profile" to config.networkProfile.name,
            "chain_id" to config.chainId,
            "genesis_hash" to config.genesisHash,
            "protocol_version" to config.protocolVersion,
            "timestamp_ms" to now,
            "peers" to peersList
        )
        signingKeyPair?.let { (privBytes, pubHex) ->
            val summaryToSign = "${config.chainId}|${config.genesisHash}|$now|${peersList.joinToString(",") { it["node_id"].toString() }}"
            body["server_public_key_hex"] = pubHex
            body["signature_hex"] = signEd25519Hex(privBytes, summaryToSign.toByteArray(StandardCharsets.UTF_8))
        }
        sendJson(exchange, 200, body)
    }

    private fun handleMetricsDispatch(exchange: HttpExchange) {
        val path = exchange.requestURI.path.orEmpty()
        if (path.endsWith("/prometheus")) {
            handlePrometheusMetrics(exchange)
        } else {
            handleMetrics(exchange)
        }
    }

    private fun handleMetrics(exchange: HttpExchange) {
        requestsTotal.incrementAndGet()
        if (exchange.requestMethod != "GET") {
            sendJson(exchange, 405, mapOf("error" to "Method Not Allowed"))
            return
        }
        pruneExpiredPeers()
        val rt = Runtime.getRuntime()
        val heapUsed = (rt.totalMemory() - rt.freeMemory()).coerceAtLeast(0L)
        val heapMax = rt.maxMemory().coerceAtLeast(0L)
        val rejectedTotal = rateLimitedRequests.get() + malformedRejected.get() + wrongChainRejected.get() + overloadRejected503.get()
        val errorsTotal = internalErrorCount.get() + malformedRejected.get() + wrongChainRejected.get()
        val now = clockMs()
        sendJson(
            exchange,
            200,
            linkedMapOf(
                "requests_total" to requestsTotal.get(),
                "requests_per_second" to computeRequestsPerSecond(),
                "active_connections" to activeConnections.get(),
                "registered_peers" to directory.size,
                "active_directory_peers" to directory.size,
                "registrations_accepted" to registrationsAccepted.get(),
                "discovery_queries" to discoveryQueries.get(),
                "expired_peer_records" to expiredPruned.get(),
                "expired_pruned" to expiredPruned.get(),
                "rejected_requests" to rejectedTotal,
                "rate_limited_requests" to rateLimitedRequests.get(),
                "malformed_rejected" to malformedRejected.get(),
                "wrong_chain_rejected" to wrongChainRejected.get(),
                "overload_rejected_503" to overloadRejected503.get(),
                "error_counts" to errorsTotal,
                "uptime_ms" to (now - startedAtMs).coerceAtLeast(0L),
                "heap_used_bytes" to heapUsed,
                "heap_max_bytes" to heapMax
            )
        )
    }

    private fun handlePrometheusMetrics(exchange: HttpExchange) {
        requestsTotal.incrementAndGet()
        if (exchange.requestMethod != "GET") {
            sendJson(exchange, 405, mapOf("error" to "Method Not Allowed"))
            return
        }
        pruneExpiredPeers()
        val rt = Runtime.getRuntime()
        val heapUsed = (rt.totalMemory() - rt.freeMemory()).coerceAtLeast(0L)
        val heapMax = rt.maxMemory().coerceAtLeast(0L)
        val uptimeMs = (clockMs() - startedAtMs).coerceAtLeast(0L)
        val rejectedTotal = rateLimitedRequests.get() + malformedRejected.get() + wrongChainRejected.get() + overloadRejected503.get()
        val errorsTotal = internalErrorCount.get() + malformedRejected.get() + wrongChainRejected.get()
        val text = buildString {
            appendLine("# TYPE nmd_bootstrap_requests_total counter")
            appendLine("nmd_bootstrap_requests_total ${requestsTotal.get()}")
            appendLine("# TYPE nmd_bootstrap_requests_per_second gauge")
            appendLine("nmd_bootstrap_requests_per_second ${computeRequestsPerSecond()}")
            appendLine("# TYPE nmd_bootstrap_active_connections gauge")
            appendLine("nmd_bootstrap_active_connections ${activeConnections.get()}")
            appendLine("# TYPE nmd_bootstrap_registered_peers gauge")
            appendLine("nmd_bootstrap_registered_peers ${directory.size}")
            appendLine("# TYPE nmd_bootstrap_expired_peer_records counter")
            appendLine("nmd_bootstrap_expired_peer_records ${expiredPruned.get()}")
            appendLine("# TYPE nmd_bootstrap_rejected_requests counter")
            appendLine("nmd_bootstrap_rejected_requests $rejectedTotal")
            appendLine("# TYPE nmd_bootstrap_rate_limited_requests counter")
            appendLine("nmd_bootstrap_rate_limited_requests ${rateLimitedRequests.get()}")
            appendLine("# TYPE nmd_bootstrap_overload_503_total counter")
            appendLine("nmd_bootstrap_overload_503_total ${overloadRejected503.get()}")
            appendLine("# TYPE nmd_bootstrap_error_counts counter")
            appendLine("nmd_bootstrap_error_counts $errorsTotal")
            appendLine("# TYPE nmd_bootstrap_uptime_ms gauge")
            appendLine("nmd_bootstrap_uptime_ms $uptimeMs")
            appendLine("# TYPE nmd_bootstrap_heap_used_bytes gauge")
            appendLine("nmd_bootstrap_heap_used_bytes $heapUsed")
            appendLine("# TYPE nmd_bootstrap_heap_max_bytes gauge")
            appendLine("nmd_bootstrap_heap_max_bytes $heapMax")
        }
        val bytes = text.toByteArray(StandardCharsets.UTF_8)
        exchange.responseHeaders.set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
        exchange.responseHeaders.set("Cache-Control", "no-store")
        exchange.sendResponseHeaders(200, bytes.size.toLong())
        exchange.responseBody.use { it.write(bytes) }
    }

    private fun checkRateLimit(exchange: HttpExchange): Boolean {
        val ip = exchange.remoteAddress?.address?.hostAddress ?: "unknown"
        val now = clockMs()
        val window = rateWindows.computeIfAbsent(ip) { ArrayDeque() }
        synchronized(window) {
            while (window.isNotEmpty() && now - window.first() > config.rateLimitWindowMs) {
                window.removeFirst()
            }
            if (window.size >= config.maxRequestsPerWindowPerIp) {
                rateLimitedRequests.incrementAndGet()
                logStructured("WARN", "RATE_LIMIT_TRIGGERED", "ip=$ip")
                sendJson(exchange, 429, mapOf("error" to "Rate limit exceeded"))
                return false
            }
            window.addLast(now)
        }
        return true
    }

    private fun readBoundedBody(exchange: HttpExchange, maxBytes: Int): String? {
        val stream = exchange.requestBody
        val buffer = ByteArray(1024)
        val out = java.io.ByteArrayOutputStream()
        var total = 0
        while (true) {
            val read = stream.read(buffer)
            if (read == -1) break
            total += read
            if (total > maxBytes) return null
            out.write(buffer, 0, read)
        }
        return out.toString(StandardCharsets.UTF_8)
    }

    private fun sendJson(exchange: HttpExchange, statusCode: Int, payload: Map<String, Any?>) {
        val json = mapAdapter.toJson(payload)
        val bytes = json.toByteArray(StandardCharsets.UTF_8)
        exchange.responseHeaders.set("Content-Type", "application/json; charset=utf-8")
        exchange.responseHeaders.set("Cache-Control", "no-store")
        exchange.sendResponseHeaders(statusCode, bytes.size.toLong())
        exchange.responseBody.use { it.write(bytes) }
    }

    private fun isValidNodeIdentity(nodeId: String, publicKeyHex: String): Boolean {
        if (!nodeId.startsWith(NODE_ID_PREFIX) || publicKeyHex.length != 64) return false
        return try {
            val pubBytes = hexToBytes(publicKeyHex)
            if (pubBytes.size != 32) return false
            val hash = MessageDigest.getInstance("SHA-256").digest(pubBytes)
            val expectedNodeId = NODE_ID_PREFIX + bytesToHex(hash).substring(0, 32)
            nodeId.equals(expectedNodeId, ignoreCase = false)
        } catch (_: Exception) {
            false
        }
    }

    private fun isValidHost(host: String): Boolean {
        if (host.isBlank() || host.length > 253) return false
        return host.none { it == '\r' || it == '\n' || it.isWhitespace() }
    }

    private fun parseQueryParams(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split("&")
            .mapNotNull { part ->
                val idx = part.indexOf('=')
                if (idx <= 0) null
                else java.net.URLDecoder.decode(part.substring(0, idx), StandardCharsets.UTF_8) to
                    java.net.URLDecoder.decode(part.substring(idx + 1), StandardCharsets.UTF_8)
            }
            .toMap()
    }

    private fun loadPkcs12SslContext(path: String, password: String): SSLContext {
        val ks = KeyStore.getInstance("PKCS12")
        FileInputStream(path).use { ks.load(it, password.toCharArray()) }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, password.toCharArray())
        return SSLContext.getInstance("TLS").apply {
            init(kmf.keyManagers, null, null)
        }
    }

    private fun signEd25519Hex(privateKeyBytes: ByteArray, data: ByteArray): String {
        val signer = Ed25519Signer()
        signer.init(true, Ed25519PrivateKeyParameters(privateKeyBytes, 0))
        signer.update(data, 0, data.size)
        return bytesToHex(signer.generateSignature())
    }

    private fun verifyEd25519Hex(publicKeyHex: String, data: ByteArray, signatureHex: String): Boolean {
        return try {
            val pubBytes = hexToBytes(publicKeyHex)
            val sigBytes = hexToBytes(signatureHex)
            if (pubBytes.size != 32 || sigBytes.size != 64) return false
            val verifier = Ed25519Signer()
            verifier.init(false, Ed25519PublicKeyParameters(pubBytes, 0))
            verifier.update(data, 0, data.size)
            verifier.verifySignature(sigBytes)
        } catch (_: Exception) {
            false
        }
    }

    private val diskLock = Any()

    private fun saveDirectoryToDisk() {
        val path = config.storagePath ?: return
        synchronized(diskLock) {
            runCatching {
                val target = File(path)
                target.parentFile?.mkdirs()
                val now = clockMs()
                val entriesList = directory.values
                    .filter { it.expiresAtMs > now }
                    .map { p ->
                        linkedMapOf<String, Any?>(
                            "node_id" to p.nodeId,
                            "public_key_hex" to p.publicKeyHex,
                            "protocol_version" to p.protocolVersion,
                            "chain_id" to p.chainId,
                            "genesis_hash" to p.genesisHash,
                            "host" to p.host,
                            "port" to p.port,
                            "capabilities" to p.capabilities,
                            "availability_status" to p.availabilityStatus,
                            "last_seen_ms" to p.lastSeenTimestampMs,
                            "expires_at_ms" to p.expiresAtMs
                        )
                    }
                val json = mapAdapter.toJson(mapOf("chain_id" to config.chainId, "peers" to entriesList))
                val tmp = File(target.parentFile, "${target.name}.tmp")
                tmp.writeText(json, StandardCharsets.UTF_8)
                Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        }
    }

    private fun loadDirectoryFromDisk() {
        val path = config.storagePath ?: return
        synchronized(diskLock) {
            runCatching {
                val file = File(path)
                if (!file.exists()) return
                val parsed = mapAdapter.fromJson(file.readText(StandardCharsets.UTF_8)) ?: return
                if ((parsed["chain_id"] as? String) != config.chainId) return
                val peers = parsed["peers"] as? List<*> ?: return
                val now = clockMs()
                for (raw in peers) {
                    val m = raw as? Map<*, *> ?: continue
                    val nodeId = m["node_id"] as? String ?: continue
                    val pubHex = m["public_key_hex"] as? String ?: continue
                    val genesis = (m["genesis_hash"] as? String)?.lowercase() ?: continue
                    val host = m["host"] as? String ?: continue
                    val port = (m["port"] as? Number)?.toInt() ?: continue
                    val exp = (m["expires_at_ms"] as? Number)?.toLong() ?: continue
                    val lastSeen = (m["last_seen_ms"] as? Number)?.toLong() ?: now
                    val proto = (m["protocol_version"] as? Number)?.toInt() ?: config.protocolVersion
                    if (genesis != config.genesisHash || exp <= now || !isValidNodeIdentity(nodeId, pubHex)) continue
                    val caps = (m["capabilities"] as? List<*>)?.mapNotNull { it as? String }.orEmpty()
                    val status = (m["availability_status"] as? String) ?: "ONLINE"
                    directory[nodeId] = DirectoryPeerEntry(
                        nodeId = nodeId,
                        publicKeyHex = pubHex,
                        protocolVersion = proto,
                        chainId = config.chainId,
                        genesisHash = genesis,
                        host = host,
                        port = port,
                        capabilities = caps,
                        availabilityStatus = status,
                        lastSeenTimestampMs = lastSeen,
                        expiresAtMs = exp
                    )
                }
            }
        }
    }

    private fun hexToBytes(hex: String): ByteArray {
        val clean = hex.trim().lowercase()
        require(clean.length % 2 == 0) { "Odd hex length" }
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    private fun bytesToHex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    private fun logStructured(level: String, event: String, detail: String) {
        logSink("{\"ts\":\"${Instant.now()}\",\"svc\":\"bootstrap\",\"level\":\"$level\",\"event\":\"$event\",\"detail\":\"$detail\"}")
    }

    override fun close() {
        saveDirectoryToDisk()
        logStructured("INFO", "BOOTSTRAP_SHUTTING_DOWN", "activePeers=${directory.size}")
        cleanupScheduler?.shutdownNow()
        cleanupScheduler = null
        httpServer?.stop(1)
        httpServer = null
        executor.shutdownNow()
    }
}
