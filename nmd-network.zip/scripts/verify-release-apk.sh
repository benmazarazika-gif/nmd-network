#!/usr/bin/env bash
set -euo pipefail

APK_DIR="${1:-app/build/outputs/apk/release}"
EXPECTED_PACKAGE="${EXPECTED_PACKAGE:-com.aistudio.nmdnetwork.gateway}"
EXPECTED_VERSION_CODE="${EXPECTED_VERSION_CODE:-1}"
EXPECTED_VERSION_NAME="${EXPECTED_VERSION_NAME:-1.0}"
REQUIRED_ABIS=("arm64-v8a" "armeabi-v7a" "x86" "x86_64")

echo "=== NMD Network Release APK Integrity & Security Verification ==="

# 1. Verify exactly one non-debug Release APK exists
if [ ! -d "$APK_DIR" ]; then
  echo "::error::Release APK directory does not exist: $APK_DIR"
  exit 1
fi

mapfile -t APK_FILES < <(find "$APK_DIR" -maxdepth 1 -type f -name "*.apk" | sort)
if [ "${#APK_FILES[@]}" -ne 1 ]; then
  echo "::error::Expected exactly 1 Release APK in $APK_DIR, found ${#APK_FILES[@]}: ${APK_FILES[*]:-none}"
  exit 1
fi

APK_PATH="${APK_FILES[0]}"
APK_BASENAME="$(basename "$APK_PATH")"
if [ "$APK_BASENAME" != "app-release.apk" ]; then
  echo "::error::Expected APK filename 'app-release.apk', got '$APK_BASENAME' (unsigned or unexpected variant)."
  exit 1
fi
echo "[OK] Single installable Release APK found: $APK_PATH ($(du -h "$APK_PATH" | cut -f1))"

# Locate Android SDK build-tools (apksigner & aapt2)
SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK_DIR" ] || [ ! -d "$SDK_DIR/build-tools" ]; then
  echo "::error::Android SDK build-tools directory not found (ANDROID_HOME/ANDROID_SDK_ROOT unset)."
  exit 1
fi

APKSIGNER="$(find "$SDK_DIR/build-tools" -type f -name "apksigner" | sort -V | tail -n 1 || true)"
AAPT2="$(find "$SDK_DIR/build-tools" -type f -name "aapt2" | sort -V | tail -n 1 || true)"
if [ -z "$APKSIGNER" ] || [ -z "$AAPT2" ]; then
  echo "::error::Missing apksigner ($APKSIGNER) or aapt2 ($AAPT2) in $SDK_DIR/build-tools"
  exit 1
fi

# 2. Verify APK signature validity and ensure it is NOT signed with the Debug key
VERIFY_OUTPUT="$("$APKSIGNER" verify --verbose --print-certs "$APK_PATH" 2>&1)" || {
  echo "::error::apksigner signature verification failed:"
  echo "$VERIFY_OUTPUT"
  exit 1
}
echo "$VERIFY_OUTPUT"

if echo "$VERIFY_OUTPUT" | grep -qiE "CN=Android Debug|Signer #1 certificate DN:.*Android Debug"; then
  echo "::error::Release APK is signed with a Debug certificate (CN=Android Debug). Aborting!"
  exit 1
fi

if [ -f "debug.keystore.base64" ]; then
  TMP_DEBUG_KS="$(mktemp /tmp/nmd_dbg_check.XXXXXX.keystore)"
  trap 'rm -f "$TMP_DEBUG_KS"' EXIT
  tr -d '\n\r ' < debug.keystore.base64 | base64 --decode > "$TMP_DEBUG_KS"
  DEBUG_SHA256="$(keytool -list -v -keystore "$TMP_DEBUG_KS" -storepass android -alias androiddebugkey 2>/dev/null \
    | awk -F': ' '/SHA256:/ {gsub(/:/, "", $2); print tolower($2); exit}')"
  APK_CERT_SHA256="$(echo "$VERIFY_OUTPUT" \
    | awk -F': ' '/Signer #1 certificate SHA-256 digest:/ {print tolower($2); exit}')"
  if [ -n "$DEBUG_SHA256" ] && [ -n "$APK_CERT_SHA256" ] && [ "$DEBUG_SHA256" = "$APK_CERT_SHA256" ]; then
    echo "::error::Release APK certificate SHA-256 matches repository debug.keystore! Aborting!"
    exit 1
  fi
  rm -f "$TMP_DEBUG_KS"
fi
echo "[OK] APK signature verified and confirmed distinct from Debug signing key."

# 3. Verify package name, versionCode, versionName, and non-debuggable flag via aapt2
BADGING="$("$AAPT2" dump badging "$APK_PATH")"
read -r ACTUAL_PKG ACTUAL_VCODE ACTUAL_VNAME IS_DEBUGGABLE < <(python3 - "$BADGING" <<'PYEOF'
import re
import sys

badging = sys.argv[1]
pkg_line = ""
for line in badging.splitlines():
    if line.startswith("package:"):
        pkg_line = line
        break

name_m = re.search(r"\bname='([^']+)'", pkg_line)
vcode_m = re.search(r"\bversionCode='([^']+)'", pkg_line)
vname_m = re.search(r"\bversionName='([^']+)'", pkg_line)
debuggable = any(line.strip() == "application-debuggable" for line in badging.splitlines())

print(
    name_m.group(1) if name_m else "MISSING",
    vcode_m.group(1) if vcode_m else "MISSING",
    vname_m.group(1) if vname_m else "MISSING",
    "true" if debuggable else "false",
)
PYEOF
)

if [ "$ACTUAL_PKG" != "$EXPECTED_PACKAGE" ]; then
  echo "::error::Package name mismatch: expected '$EXPECTED_PACKAGE', got '$ACTUAL_PKG'"
  exit 1
fi
if [ "$ACTUAL_VCODE" != "$EXPECTED_VERSION_CODE" ]; then
  echo "::error::versionCode mismatch: expected '$EXPECTED_VERSION_CODE', got '$ACTUAL_VCODE'"
  exit 1
fi
if [ "$ACTUAL_VNAME" != "$EXPECTED_VERSION_NAME" ]; then
  echo "::error::versionName mismatch: expected '$EXPECTED_VERSION_NAME', got '$ACTUAL_VNAME'"
  exit 1
fi
if [ "$IS_DEBUGGABLE" = "true" ]; then
  echo "::error::Release APK has android:debuggable='true'!"
  exit 1
fi
echo "[OK] Metadata verified: package=$ACTUAL_PKG versionCode=$ACTUAL_VCODE versionName=$ACTUAL_VNAME (non-debuggable)"

# 4. Verify required ABIs and scan APK contents for leaked secrets/private keys
python3 - "$APK_PATH" "${REQUIRED_ABIS[@]}" <<'PYEOF'
import os
import re
import sys
import zipfile

apk_path = sys.argv[1]
required_abis = sys.argv[2:]

forbidden_name_patterns = [
    re.compile(r"(^|/)\.(env|env\..*)$", re.IGNORECASE),
    re.compile(r"\.(jks|keystore|p12|pfx|pem|key)$", re.IGNORECASE),
    re.compile(r"(^|/)debug\.keystore(\.base64)?$", re.IGNORECASE),
    re.compile(r"(^|/)google-services\.json$", re.IGNORECASE),
]

private_key_markers = [
    b"BEGIN PRIVATE KEY",
    b"BEGIN RSA PRIVATE KEY",
    b"BEGIN EC PRIVATE KEY",
    b"BEGIN OPENSSH PRIVATE KEY",
    b"NMD_BOOTSTRAP_SIGNING_PRIVATE_KEY",
]

env_secrets = []
for var in ("STORE_PASSWORD", "KEY_PASSWORD", "KEYSTORE_BASE64"):
    val = os.environ.get(var, "").strip()
    if len(val) >= 8:
        env_secrets.append((var, val.encode("utf-8")))

with zipfile.ZipFile(apk_path, "r") as zf:
    names = zf.namelist()

    # Check ABIs
    missing_abis = []
    for abi in required_abis:
        prefix = f"lib/{abi}/"
        so_files = [n for n in names if n.startswith(prefix) and n.endswith(".so")]
        if not so_files:
            missing_abis.append(abi)
        else:
            print(f"[OK] ABI {abi}: {len(so_files)} native library/ies ({', '.join(os.path.basename(f) for f in so_files)})")

    if missing_abis:
        print(f"::error::Missing required native ABI(s) inside APK: {', '.join(missing_abis)}", file=sys.stderr)
        sys.exit(1)

    # Check forbidden filenames inside APK
    for name in names:
        for pat in forbidden_name_patterns:
            if pat.search(name):
                print(f"::error::Forbidden sensitive file packaged inside APK: {name}", file=sys.stderr)
                sys.exit(1)

    # Scan APK payloads/DEX/configs for private keys or CI signing secrets
    for name in names:
        if name.startswith("lib/") and name.endswith(".so"):
            continue
        data = zf.read(name)
        for marker in private_key_markers:
            if marker in data:
                print(f"::error::Sensitive key marker ({marker.decode()}) found inside APK entry: {name}", file=sys.stderr)
                sys.exit(1)
        for var, secret_bytes in env_secrets:
            if secret_bytes in data:
                print(f"::error::CI secret value for {var} leaked inside APK entry: {name}", file=sys.stderr)
                sys.exit(1)

print("[OK] Security scan passed: no keystores, .env files, private key markers, or signing secrets embedded in APK.")
PYEOF

echo "=== ALL RELEASE APK VERIFICATION CHECKS PASSED ==="
